<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-24 06:44:13 --> Config Class Initialized
INFO - 2017-02-24 06:44:13 --> Hooks Class Initialized
DEBUG - 2017-02-24 06:44:13 --> UTF-8 Support Enabled
INFO - 2017-02-24 06:44:13 --> Utf8 Class Initialized
INFO - 2017-02-24 06:44:13 --> URI Class Initialized
DEBUG - 2017-02-24 06:44:13 --> No URI present. Default controller set.
INFO - 2017-02-24 06:44:13 --> Router Class Initialized
INFO - 2017-02-24 06:44:13 --> Output Class Initialized
INFO - 2017-02-24 06:44:13 --> Security Class Initialized
DEBUG - 2017-02-24 06:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 06:44:13 --> Input Class Initialized
INFO - 2017-02-24 06:44:13 --> Language Class Initialized
INFO - 2017-02-24 06:44:13 --> Language Class Initialized
INFO - 2017-02-24 06:44:13 --> Config Class Initialized
INFO - 2017-02-24 06:44:13 --> Loader Class Initialized
INFO - 2017-02-24 06:44:13 --> Helper loaded: form_helper
INFO - 2017-02-24 06:44:13 --> Helper loaded: url_helper
INFO - 2017-02-24 06:44:13 --> Helper loaded: utility_helper
INFO - 2017-02-24 06:44:13 --> Database Driver Class Initialized
DEBUG - 2017-02-24 06:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 06:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 06:44:14 --> User Agent Class Initialized
DEBUG - 2017-02-24 06:44:14 --> Template Class Initialized
INFO - 2017-02-24 06:44:14 --> Controller Class Initialized
INFO - 2017-02-24 06:44:14 --> Form Validation Class Initialized
INFO - 2017-02-24 06:44:14 --> Model Class Initialized
DEBUG - 2017-02-24 06:44:14 --> File loaded: C:\xampp\htdocs\silo\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-24 06:44:14 --> File loaded: C:\xampp\htdocs\silo\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-24 06:44:14 --> File loaded: C:\xampp\htdocs\silo\application\modules/frontend/views/frontpages/homepage.php
DEBUG - 2017-02-24 06:44:14 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-24 06:44:14 --> Final output sent to browser
DEBUG - 2017-02-24 06:44:14 --> Total execution time: 0.7919
INFO - 2017-02-24 06:46:37 --> Config Class Initialized
INFO - 2017-02-24 06:46:37 --> Hooks Class Initialized
DEBUG - 2017-02-24 06:46:37 --> UTF-8 Support Enabled
INFO - 2017-02-24 06:46:37 --> Utf8 Class Initialized
INFO - 2017-02-24 06:46:37 --> URI Class Initialized
DEBUG - 2017-02-24 06:46:37 --> No URI present. Default controller set.
INFO - 2017-02-24 06:46:37 --> Router Class Initialized
INFO - 2017-02-24 06:46:37 --> Output Class Initialized
INFO - 2017-02-24 06:46:37 --> Security Class Initialized
DEBUG - 2017-02-24 06:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 06:46:37 --> Input Class Initialized
INFO - 2017-02-24 06:46:37 --> Language Class Initialized
INFO - 2017-02-24 06:46:37 --> Language Class Initialized
INFO - 2017-02-24 06:46:37 --> Config Class Initialized
INFO - 2017-02-24 06:46:37 --> Loader Class Initialized
INFO - 2017-02-24 06:46:37 --> Helper loaded: form_helper
INFO - 2017-02-24 06:46:37 --> Helper loaded: url_helper
INFO - 2017-02-24 06:46:37 --> Helper loaded: utility_helper
INFO - 2017-02-24 06:46:37 --> Database Driver Class Initialized
DEBUG - 2017-02-24 06:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 06:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 06:46:37 --> User Agent Class Initialized
DEBUG - 2017-02-24 06:46:37 --> Template Class Initialized
INFO - 2017-02-24 06:46:37 --> Controller Class Initialized
INFO - 2017-02-24 06:46:37 --> Form Validation Class Initialized
INFO - 2017-02-24 06:46:37 --> Model Class Initialized
DEBUG - 2017-02-24 06:46:37 --> File loaded: C:\xampp\htdocs\silo\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-24 06:46:37 --> File loaded: C:\xampp\htdocs\silo\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-24 06:46:37 --> File loaded: C:\xampp\htdocs\silo\application\modules/frontend/views/frontpages/homepage.php
DEBUG - 2017-02-24 06:46:37 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-24 06:46:37 --> Final output sent to browser
DEBUG - 2017-02-24 06:46:37 --> Total execution time: 0.2573
INFO - 2017-02-24 06:47:53 --> Config Class Initialized
INFO - 2017-02-24 06:47:53 --> Hooks Class Initialized
DEBUG - 2017-02-24 06:47:53 --> UTF-8 Support Enabled
INFO - 2017-02-24 06:47:53 --> Utf8 Class Initialized
INFO - 2017-02-24 06:47:53 --> URI Class Initialized
INFO - 2017-02-24 06:47:53 --> Router Class Initialized
INFO - 2017-02-24 06:47:53 --> Output Class Initialized
INFO - 2017-02-24 06:47:53 --> Security Class Initialized
DEBUG - 2017-02-24 06:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 06:47:53 --> Input Class Initialized
INFO - 2017-02-24 06:47:53 --> Language Class Initialized
ERROR - 2017-02-24 06:47:53 --> 404 Page Not Found: /index
INFO - 2017-02-24 06:47:58 --> Config Class Initialized
INFO - 2017-02-24 06:47:58 --> Hooks Class Initialized
DEBUG - 2017-02-24 06:47:58 --> UTF-8 Support Enabled
INFO - 2017-02-24 06:47:58 --> Utf8 Class Initialized
INFO - 2017-02-24 06:47:58 --> URI Class Initialized
INFO - 2017-02-24 06:47:58 --> Router Class Initialized
INFO - 2017-02-24 06:47:58 --> Output Class Initialized
INFO - 2017-02-24 06:47:58 --> Security Class Initialized
DEBUG - 2017-02-24 06:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 06:47:58 --> Input Class Initialized
INFO - 2017-02-24 06:47:58 --> Language Class Initialized
INFO - 2017-02-24 06:47:58 --> Language Class Initialized
INFO - 2017-02-24 06:47:58 --> Config Class Initialized
INFO - 2017-02-24 06:47:58 --> Loader Class Initialized
INFO - 2017-02-24 06:47:58 --> Helper loaded: form_helper
INFO - 2017-02-24 06:47:58 --> Helper loaded: url_helper
INFO - 2017-02-24 06:47:58 --> Helper loaded: utility_helper
INFO - 2017-02-24 06:47:58 --> Database Driver Class Initialized
DEBUG - 2017-02-24 06:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 06:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 06:47:58 --> User Agent Class Initialized
DEBUG - 2017-02-24 06:47:58 --> Template Class Initialized
INFO - 2017-02-24 06:47:58 --> Controller Class Initialized
DEBUG - 2017-02-24 06:47:58 --> Login MX_Controller Initialized
INFO - 2017-02-24 06:47:58 --> Helper loaded: cookie_helper
INFO - 2017-02-24 06:47:58 --> Model Class Initialized
INFO - 2017-02-24 06:47:58 --> Form Validation Class Initialized
DEBUG - 2017-02-24 06:47:58 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/login.php
INFO - 2017-02-24 06:47:58 --> Final output sent to browser
DEBUG - 2017-02-24 06:47:58 --> Total execution time: 0.2561
INFO - 2017-02-24 06:48:03 --> Config Class Initialized
INFO - 2017-02-24 06:48:03 --> Hooks Class Initialized
DEBUG - 2017-02-24 06:48:03 --> UTF-8 Support Enabled
INFO - 2017-02-24 06:48:03 --> Utf8 Class Initialized
INFO - 2017-02-24 06:48:03 --> URI Class Initialized
INFO - 2017-02-24 06:48:03 --> Router Class Initialized
INFO - 2017-02-24 06:48:03 --> Output Class Initialized
INFO - 2017-02-24 06:48:03 --> Security Class Initialized
DEBUG - 2017-02-24 06:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 06:48:03 --> Input Class Initialized
INFO - 2017-02-24 06:48:03 --> Language Class Initialized
INFO - 2017-02-24 06:48:03 --> Language Class Initialized
INFO - 2017-02-24 06:48:03 --> Config Class Initialized
INFO - 2017-02-24 06:48:03 --> Loader Class Initialized
INFO - 2017-02-24 06:48:03 --> Helper loaded: form_helper
INFO - 2017-02-24 06:48:03 --> Helper loaded: url_helper
INFO - 2017-02-24 06:48:03 --> Helper loaded: utility_helper
INFO - 2017-02-24 06:48:03 --> Database Driver Class Initialized
DEBUG - 2017-02-24 06:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 06:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 06:48:03 --> User Agent Class Initialized
DEBUG - 2017-02-24 06:48:03 --> Template Class Initialized
INFO - 2017-02-24 06:48:03 --> Controller Class Initialized
DEBUG - 2017-02-24 06:48:03 --> Login MX_Controller Initialized
INFO - 2017-02-24 06:48:03 --> Helper loaded: cookie_helper
INFO - 2017-02-24 06:48:03 --> Model Class Initialized
INFO - 2017-02-24 06:48:03 --> Form Validation Class Initialized
INFO - 2017-02-24 06:48:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-24 06:48:03 --> Config Class Initialized
INFO - 2017-02-24 06:48:03 --> Hooks Class Initialized
DEBUG - 2017-02-24 06:48:03 --> UTF-8 Support Enabled
INFO - 2017-02-24 06:48:03 --> Utf8 Class Initialized
INFO - 2017-02-24 06:48:03 --> URI Class Initialized
INFO - 2017-02-24 06:48:03 --> Router Class Initialized
INFO - 2017-02-24 06:48:03 --> Output Class Initialized
INFO - 2017-02-24 06:48:03 --> Security Class Initialized
DEBUG - 2017-02-24 06:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 06:48:03 --> Input Class Initialized
INFO - 2017-02-24 06:48:03 --> Language Class Initialized
INFO - 2017-02-24 06:48:03 --> Language Class Initialized
INFO - 2017-02-24 06:48:03 --> Config Class Initialized
INFO - 2017-02-24 06:48:03 --> Loader Class Initialized
INFO - 2017-02-24 06:48:03 --> Helper loaded: form_helper
INFO - 2017-02-24 06:48:03 --> Helper loaded: url_helper
INFO - 2017-02-24 06:48:03 --> Helper loaded: utility_helper
INFO - 2017-02-24 06:48:03 --> Database Driver Class Initialized
DEBUG - 2017-02-24 06:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 06:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 06:48:03 --> User Agent Class Initialized
DEBUG - 2017-02-24 06:48:03 --> Template Class Initialized
INFO - 2017-02-24 06:48:03 --> Controller Class Initialized
DEBUG - 2017-02-24 06:48:03 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 06:48:03 --> Helper loaded: cookie_helper
INFO - 2017-02-24 06:48:03 --> Model Class Initialized
DEBUG - 2017-02-24 06:48:03 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 06:48:03 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 06:48:03 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 06:48:03 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 06:48:03 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 06:48:03 --> Final output sent to browser
DEBUG - 2017-02-24 06:48:03 --> Total execution time: 0.1870
INFO - 2017-02-24 06:51:29 --> Config Class Initialized
INFO - 2017-02-24 06:51:29 --> Hooks Class Initialized
DEBUG - 2017-02-24 06:51:29 --> UTF-8 Support Enabled
INFO - 2017-02-24 06:51:29 --> Utf8 Class Initialized
INFO - 2017-02-24 06:51:29 --> URI Class Initialized
INFO - 2017-02-24 06:51:29 --> Router Class Initialized
INFO - 2017-02-24 06:51:29 --> Output Class Initialized
INFO - 2017-02-24 06:51:29 --> Security Class Initialized
DEBUG - 2017-02-24 06:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 06:51:29 --> Input Class Initialized
INFO - 2017-02-24 06:51:29 --> Language Class Initialized
INFO - 2017-02-24 06:51:29 --> Language Class Initialized
INFO - 2017-02-24 06:51:29 --> Config Class Initialized
INFO - 2017-02-24 06:51:29 --> Loader Class Initialized
INFO - 2017-02-24 06:51:29 --> Helper loaded: form_helper
INFO - 2017-02-24 06:51:29 --> Helper loaded: url_helper
INFO - 2017-02-24 06:51:29 --> Helper loaded: utility_helper
INFO - 2017-02-24 06:51:29 --> Database Driver Class Initialized
DEBUG - 2017-02-24 06:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 06:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 06:51:29 --> User Agent Class Initialized
DEBUG - 2017-02-24 06:51:29 --> Template Class Initialized
INFO - 2017-02-24 06:51:29 --> Controller Class Initialized
DEBUG - 2017-02-24 06:51:29 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 06:51:29 --> Helper loaded: cookie_helper
INFO - 2017-02-24 06:51:29 --> Model Class Initialized
DEBUG - 2017-02-24 06:51:29 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 06:51:29 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 06:51:29 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 06:51:29 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 06:51:29 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 06:51:29 --> Final output sent to browser
DEBUG - 2017-02-24 06:51:29 --> Total execution time: 0.0618
INFO - 2017-02-24 06:51:33 --> Config Class Initialized
INFO - 2017-02-24 06:51:33 --> Hooks Class Initialized
DEBUG - 2017-02-24 06:51:33 --> UTF-8 Support Enabled
INFO - 2017-02-24 06:51:33 --> Utf8 Class Initialized
INFO - 2017-02-24 06:51:33 --> URI Class Initialized
INFO - 2017-02-24 06:51:33 --> Router Class Initialized
INFO - 2017-02-24 06:51:33 --> Output Class Initialized
INFO - 2017-02-24 06:51:33 --> Security Class Initialized
DEBUG - 2017-02-24 06:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 06:51:33 --> Input Class Initialized
INFO - 2017-02-24 06:51:33 --> Language Class Initialized
ERROR - 2017-02-24 06:51:33 --> 404 Page Not Found: /index
INFO - 2017-02-24 06:51:35 --> Config Class Initialized
INFO - 2017-02-24 06:51:35 --> Hooks Class Initialized
DEBUG - 2017-02-24 06:51:35 --> UTF-8 Support Enabled
INFO - 2017-02-24 06:51:35 --> Utf8 Class Initialized
INFO - 2017-02-24 06:51:35 --> URI Class Initialized
INFO - 2017-02-24 06:51:35 --> Router Class Initialized
INFO - 2017-02-24 06:51:35 --> Output Class Initialized
INFO - 2017-02-24 06:51:35 --> Security Class Initialized
DEBUG - 2017-02-24 06:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 06:51:35 --> Input Class Initialized
INFO - 2017-02-24 06:51:35 --> Language Class Initialized
INFO - 2017-02-24 06:51:35 --> Language Class Initialized
INFO - 2017-02-24 06:51:35 --> Config Class Initialized
INFO - 2017-02-24 06:51:35 --> Loader Class Initialized
INFO - 2017-02-24 06:51:35 --> Helper loaded: form_helper
INFO - 2017-02-24 06:51:35 --> Helper loaded: url_helper
INFO - 2017-02-24 06:51:35 --> Helper loaded: utility_helper
INFO - 2017-02-24 06:51:35 --> Database Driver Class Initialized
DEBUG - 2017-02-24 06:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 06:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 06:51:36 --> User Agent Class Initialized
DEBUG - 2017-02-24 06:51:36 --> Template Class Initialized
INFO - 2017-02-24 06:51:36 --> Controller Class Initialized
DEBUG - 2017-02-24 06:51:36 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 06:51:36 --> Helper loaded: cookie_helper
INFO - 2017-02-24 06:51:36 --> Model Class Initialized
DEBUG - 2017-02-24 06:51:36 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 06:51:36 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 06:51:36 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 06:51:36 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 06:51:36 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 06:51:36 --> Final output sent to browser
DEBUG - 2017-02-24 06:51:36 --> Total execution time: 0.2213
INFO - 2017-02-24 06:51:37 --> Config Class Initialized
INFO - 2017-02-24 06:51:37 --> Hooks Class Initialized
DEBUG - 2017-02-24 06:51:37 --> UTF-8 Support Enabled
INFO - 2017-02-24 06:51:37 --> Utf8 Class Initialized
INFO - 2017-02-24 06:51:37 --> URI Class Initialized
INFO - 2017-02-24 06:51:37 --> Router Class Initialized
INFO - 2017-02-24 06:51:37 --> Output Class Initialized
INFO - 2017-02-24 06:51:37 --> Security Class Initialized
DEBUG - 2017-02-24 06:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 06:51:37 --> Input Class Initialized
INFO - 2017-02-24 06:51:37 --> Language Class Initialized
INFO - 2017-02-24 06:51:37 --> Language Class Initialized
INFO - 2017-02-24 06:51:37 --> Config Class Initialized
INFO - 2017-02-24 06:51:37 --> Loader Class Initialized
INFO - 2017-02-24 06:51:37 --> Helper loaded: form_helper
INFO - 2017-02-24 06:51:37 --> Helper loaded: url_helper
INFO - 2017-02-24 06:51:37 --> Helper loaded: utility_helper
INFO - 2017-02-24 06:51:37 --> Database Driver Class Initialized
DEBUG - 2017-02-24 06:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 06:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 06:51:37 --> User Agent Class Initialized
DEBUG - 2017-02-24 06:51:37 --> Template Class Initialized
INFO - 2017-02-24 06:51:37 --> Controller Class Initialized
DEBUG - 2017-02-24 06:51:37 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-24 06:51:37 --> Model Class Initialized
INFO - 2017-02-24 06:51:37 --> Model Class Initialized
DEBUG - 2017-02-24 06:51:37 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 06:51:37 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 06:51:37 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 06:51:37 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/global-setting/globle_setting_list.php
DEBUG - 2017-02-24 06:51:37 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 06:51:37 --> Final output sent to browser
DEBUG - 2017-02-24 06:51:37 --> Total execution time: 0.1444
INFO - 2017-02-24 06:51:39 --> Config Class Initialized
INFO - 2017-02-24 06:51:39 --> Hooks Class Initialized
DEBUG - 2017-02-24 06:51:39 --> UTF-8 Support Enabled
INFO - 2017-02-24 06:51:39 --> Utf8 Class Initialized
INFO - 2017-02-24 06:51:39 --> URI Class Initialized
INFO - 2017-02-24 06:51:39 --> Router Class Initialized
INFO - 2017-02-24 06:51:39 --> Output Class Initialized
INFO - 2017-02-24 06:51:39 --> Security Class Initialized
DEBUG - 2017-02-24 06:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 06:51:39 --> Input Class Initialized
INFO - 2017-02-24 06:51:39 --> Language Class Initialized
INFO - 2017-02-24 06:51:39 --> Language Class Initialized
INFO - 2017-02-24 06:51:39 --> Config Class Initialized
INFO - 2017-02-24 06:51:39 --> Loader Class Initialized
INFO - 2017-02-24 06:51:39 --> Helper loaded: form_helper
INFO - 2017-02-24 06:51:39 --> Helper loaded: url_helper
INFO - 2017-02-24 06:51:39 --> Helper loaded: utility_helper
INFO - 2017-02-24 06:51:39 --> Database Driver Class Initialized
DEBUG - 2017-02-24 06:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 06:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 06:51:39 --> User Agent Class Initialized
DEBUG - 2017-02-24 06:51:39 --> Template Class Initialized
INFO - 2017-02-24 06:51:39 --> Controller Class Initialized
INFO - 2017-02-24 06:51:39 --> Model Class Initialized
INFO - 2017-02-24 06:51:39 --> Model Class Initialized
DEBUG - 2017-02-24 06:51:39 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 06:51:39 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 06:51:39 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 06:51:39 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/blog/blog_list.php
DEBUG - 2017-02-24 06:51:39 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 06:51:39 --> Final output sent to browser
DEBUG - 2017-02-24 06:51:39 --> Total execution time: 0.1268
INFO - 2017-02-24 06:51:41 --> Config Class Initialized
INFO - 2017-02-24 06:51:41 --> Hooks Class Initialized
DEBUG - 2017-02-24 06:51:41 --> UTF-8 Support Enabled
INFO - 2017-02-24 06:51:41 --> Utf8 Class Initialized
INFO - 2017-02-24 06:51:41 --> URI Class Initialized
INFO - 2017-02-24 06:51:41 --> Router Class Initialized
INFO - 2017-02-24 06:51:41 --> Output Class Initialized
INFO - 2017-02-24 06:51:41 --> Security Class Initialized
DEBUG - 2017-02-24 06:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 06:51:41 --> Input Class Initialized
INFO - 2017-02-24 06:51:41 --> Language Class Initialized
INFO - 2017-02-24 06:51:41 --> Language Class Initialized
INFO - 2017-02-24 06:51:41 --> Config Class Initialized
INFO - 2017-02-24 06:51:41 --> Loader Class Initialized
INFO - 2017-02-24 06:51:41 --> Helper loaded: form_helper
INFO - 2017-02-24 06:51:41 --> Helper loaded: url_helper
INFO - 2017-02-24 06:51:41 --> Helper loaded: utility_helper
INFO - 2017-02-24 06:51:41 --> Database Driver Class Initialized
DEBUG - 2017-02-24 06:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 06:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 06:51:41 --> User Agent Class Initialized
DEBUG - 2017-02-24 06:51:41 --> Template Class Initialized
INFO - 2017-02-24 06:51:41 --> Controller Class Initialized
INFO - 2017-02-24 06:51:41 --> Model Class Initialized
INFO - 2017-02-24 06:51:41 --> Model Class Initialized
DEBUG - 2017-02-24 06:51:41 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 06:51:41 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 06:51:41 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 06:51:41 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/category/category_list.php
DEBUG - 2017-02-24 06:51:41 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 06:51:41 --> Final output sent to browser
DEBUG - 2017-02-24 06:51:41 --> Total execution time: 0.1658
INFO - 2017-02-24 06:52:44 --> Config Class Initialized
INFO - 2017-02-24 06:52:44 --> Hooks Class Initialized
DEBUG - 2017-02-24 06:52:44 --> UTF-8 Support Enabled
INFO - 2017-02-24 06:52:44 --> Utf8 Class Initialized
INFO - 2017-02-24 06:52:44 --> URI Class Initialized
INFO - 2017-02-24 06:52:44 --> Router Class Initialized
INFO - 2017-02-24 06:52:44 --> Output Class Initialized
INFO - 2017-02-24 06:52:44 --> Security Class Initialized
DEBUG - 2017-02-24 06:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 06:52:44 --> Input Class Initialized
INFO - 2017-02-24 06:52:44 --> Language Class Initialized
INFO - 2017-02-24 06:52:44 --> Language Class Initialized
INFO - 2017-02-24 06:52:44 --> Config Class Initialized
INFO - 2017-02-24 06:52:44 --> Loader Class Initialized
INFO - 2017-02-24 06:52:44 --> Helper loaded: form_helper
INFO - 2017-02-24 06:52:44 --> Helper loaded: url_helper
INFO - 2017-02-24 06:52:44 --> Helper loaded: utility_helper
INFO - 2017-02-24 06:52:44 --> Database Driver Class Initialized
DEBUG - 2017-02-24 06:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 06:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 06:52:44 --> User Agent Class Initialized
DEBUG - 2017-02-24 06:52:44 --> Template Class Initialized
INFO - 2017-02-24 06:52:44 --> Controller Class Initialized
DEBUG - 2017-02-24 06:52:44 --> Login MX_Controller Initialized
INFO - 2017-02-24 06:52:44 --> Helper loaded: cookie_helper
INFO - 2017-02-24 06:52:44 --> Model Class Initialized
INFO - 2017-02-24 06:52:44 --> Form Validation Class Initialized
DEBUG - 2017-02-24 06:52:44 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/login.php
INFO - 2017-02-24 06:52:44 --> Final output sent to browser
DEBUG - 2017-02-24 06:52:44 --> Total execution time: 0.0468
INFO - 2017-02-24 06:58:44 --> Config Class Initialized
INFO - 2017-02-24 06:58:44 --> Hooks Class Initialized
DEBUG - 2017-02-24 06:58:44 --> UTF-8 Support Enabled
INFO - 2017-02-24 06:58:44 --> Utf8 Class Initialized
INFO - 2017-02-24 06:58:44 --> URI Class Initialized
INFO - 2017-02-24 06:58:44 --> Router Class Initialized
INFO - 2017-02-24 06:58:44 --> Output Class Initialized
INFO - 2017-02-24 06:58:44 --> Security Class Initialized
DEBUG - 2017-02-24 06:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 06:58:44 --> Input Class Initialized
INFO - 2017-02-24 06:58:44 --> Language Class Initialized
INFO - 2017-02-24 06:58:44 --> Language Class Initialized
INFO - 2017-02-24 06:58:44 --> Config Class Initialized
INFO - 2017-02-24 06:58:44 --> Loader Class Initialized
INFO - 2017-02-24 06:58:44 --> Helper loaded: form_helper
INFO - 2017-02-24 06:58:44 --> Helper loaded: url_helper
INFO - 2017-02-24 06:58:44 --> Helper loaded: utility_helper
INFO - 2017-02-24 06:58:44 --> Database Driver Class Initialized
DEBUG - 2017-02-24 06:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 06:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 06:58:44 --> User Agent Class Initialized
DEBUG - 2017-02-24 06:58:44 --> Template Class Initialized
INFO - 2017-02-24 06:58:44 --> Controller Class Initialized
INFO - 2017-02-24 06:58:44 --> Model Class Initialized
INFO - 2017-02-24 06:58:44 --> Model Class Initialized
DEBUG - 2017-02-24 06:58:44 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 06:58:44 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 06:58:44 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 06:58:44 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/category/category_list.php
DEBUG - 2017-02-24 06:58:44 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 06:58:44 --> Final output sent to browser
DEBUG - 2017-02-24 06:58:44 --> Total execution time: 0.1086
INFO - 2017-02-24 06:58:45 --> Config Class Initialized
INFO - 2017-02-24 06:58:45 --> Hooks Class Initialized
DEBUG - 2017-02-24 06:58:45 --> UTF-8 Support Enabled
INFO - 2017-02-24 06:58:45 --> Utf8 Class Initialized
INFO - 2017-02-24 06:58:45 --> URI Class Initialized
INFO - 2017-02-24 06:58:45 --> Router Class Initialized
INFO - 2017-02-24 06:58:45 --> Output Class Initialized
INFO - 2017-02-24 06:58:45 --> Security Class Initialized
DEBUG - 2017-02-24 06:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 06:58:45 --> Input Class Initialized
INFO - 2017-02-24 06:58:45 --> Language Class Initialized
INFO - 2017-02-24 06:58:45 --> Language Class Initialized
INFO - 2017-02-24 06:58:45 --> Config Class Initialized
INFO - 2017-02-24 06:58:45 --> Loader Class Initialized
INFO - 2017-02-24 06:58:45 --> Helper loaded: form_helper
INFO - 2017-02-24 06:58:45 --> Helper loaded: url_helper
INFO - 2017-02-24 06:58:45 --> Helper loaded: utility_helper
INFO - 2017-02-24 06:58:45 --> Database Driver Class Initialized
DEBUG - 2017-02-24 06:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 06:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 06:58:45 --> User Agent Class Initialized
DEBUG - 2017-02-24 06:58:45 --> Template Class Initialized
INFO - 2017-02-24 06:58:45 --> Controller Class Initialized
INFO - 2017-02-24 06:58:45 --> Model Class Initialized
INFO - 2017-02-24 06:58:45 --> Model Class Initialized
DEBUG - 2017-02-24 06:58:45 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 06:58:45 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 06:58:45 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 06:58:45 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/category/category_list.php
DEBUG - 2017-02-24 06:58:45 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 06:58:45 --> Final output sent to browser
DEBUG - 2017-02-24 06:58:45 --> Total execution time: 0.0690
INFO - 2017-02-24 06:58:46 --> Config Class Initialized
INFO - 2017-02-24 06:58:46 --> Hooks Class Initialized
DEBUG - 2017-02-24 06:58:46 --> UTF-8 Support Enabled
INFO - 2017-02-24 06:58:46 --> Utf8 Class Initialized
INFO - 2017-02-24 06:58:46 --> URI Class Initialized
INFO - 2017-02-24 06:58:46 --> Router Class Initialized
INFO - 2017-02-24 06:58:46 --> Output Class Initialized
INFO - 2017-02-24 06:58:46 --> Security Class Initialized
DEBUG - 2017-02-24 06:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 06:58:46 --> Input Class Initialized
INFO - 2017-02-24 06:58:46 --> Language Class Initialized
INFO - 2017-02-24 06:58:46 --> Language Class Initialized
INFO - 2017-02-24 06:58:46 --> Config Class Initialized
INFO - 2017-02-24 06:58:46 --> Loader Class Initialized
INFO - 2017-02-24 06:58:46 --> Helper loaded: form_helper
INFO - 2017-02-24 06:58:46 --> Helper loaded: url_helper
INFO - 2017-02-24 06:58:46 --> Helper loaded: utility_helper
INFO - 2017-02-24 06:58:46 --> Database Driver Class Initialized
DEBUG - 2017-02-24 06:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 06:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 06:58:46 --> User Agent Class Initialized
DEBUG - 2017-02-24 06:58:46 --> Template Class Initialized
INFO - 2017-02-24 06:58:46 --> Controller Class Initialized
INFO - 2017-02-24 06:58:46 --> Model Class Initialized
INFO - 2017-02-24 06:58:46 --> Model Class Initialized
DEBUG - 2017-02-24 06:58:46 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 06:58:46 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 06:58:46 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 06:58:46 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/category/category_list.php
DEBUG - 2017-02-24 06:58:46 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 06:58:46 --> Final output sent to browser
DEBUG - 2017-02-24 06:58:46 --> Total execution time: 0.0771
INFO - 2017-02-24 06:58:46 --> Config Class Initialized
INFO - 2017-02-24 06:58:46 --> Hooks Class Initialized
DEBUG - 2017-02-24 06:58:46 --> UTF-8 Support Enabled
INFO - 2017-02-24 06:58:46 --> Utf8 Class Initialized
INFO - 2017-02-24 06:58:46 --> URI Class Initialized
INFO - 2017-02-24 06:58:46 --> Router Class Initialized
INFO - 2017-02-24 06:58:46 --> Output Class Initialized
INFO - 2017-02-24 06:58:46 --> Security Class Initialized
DEBUG - 2017-02-24 06:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 06:58:46 --> Input Class Initialized
INFO - 2017-02-24 06:58:46 --> Language Class Initialized
INFO - 2017-02-24 06:58:46 --> Language Class Initialized
INFO - 2017-02-24 06:58:46 --> Config Class Initialized
INFO - 2017-02-24 06:58:46 --> Loader Class Initialized
INFO - 2017-02-24 06:58:46 --> Helper loaded: form_helper
INFO - 2017-02-24 06:58:46 --> Helper loaded: url_helper
INFO - 2017-02-24 06:58:46 --> Helper loaded: utility_helper
INFO - 2017-02-24 06:58:46 --> Database Driver Class Initialized
DEBUG - 2017-02-24 06:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 06:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 06:58:46 --> User Agent Class Initialized
DEBUG - 2017-02-24 06:58:46 --> Template Class Initialized
INFO - 2017-02-24 06:58:46 --> Controller Class Initialized
INFO - 2017-02-24 06:58:46 --> Model Class Initialized
INFO - 2017-02-24 06:58:46 --> Model Class Initialized
DEBUG - 2017-02-24 06:58:46 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 06:58:46 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 06:58:46 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 06:58:46 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/category/category_list.php
DEBUG - 2017-02-24 06:58:46 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 06:58:46 --> Final output sent to browser
DEBUG - 2017-02-24 06:58:46 --> Total execution time: 0.0733
INFO - 2017-02-24 06:58:47 --> Config Class Initialized
INFO - 2017-02-24 06:58:47 --> Hooks Class Initialized
DEBUG - 2017-02-24 06:58:47 --> UTF-8 Support Enabled
INFO - 2017-02-24 06:58:47 --> Utf8 Class Initialized
INFO - 2017-02-24 06:58:47 --> URI Class Initialized
INFO - 2017-02-24 06:58:47 --> Router Class Initialized
INFO - 2017-02-24 06:58:47 --> Output Class Initialized
INFO - 2017-02-24 06:58:47 --> Security Class Initialized
DEBUG - 2017-02-24 06:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 06:58:47 --> Input Class Initialized
INFO - 2017-02-24 06:58:47 --> Language Class Initialized
INFO - 2017-02-24 06:58:47 --> Language Class Initialized
INFO - 2017-02-24 06:58:47 --> Config Class Initialized
INFO - 2017-02-24 06:58:47 --> Loader Class Initialized
INFO - 2017-02-24 06:58:47 --> Helper loaded: form_helper
INFO - 2017-02-24 06:58:47 --> Helper loaded: url_helper
INFO - 2017-02-24 06:58:47 --> Helper loaded: utility_helper
INFO - 2017-02-24 06:58:47 --> Database Driver Class Initialized
DEBUG - 2017-02-24 06:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 06:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 06:58:47 --> User Agent Class Initialized
DEBUG - 2017-02-24 06:58:47 --> Template Class Initialized
INFO - 2017-02-24 06:58:47 --> Controller Class Initialized
INFO - 2017-02-24 06:58:47 --> Model Class Initialized
INFO - 2017-02-24 06:58:47 --> Model Class Initialized
DEBUG - 2017-02-24 06:58:47 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 06:58:47 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 06:58:47 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 06:58:47 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/category/category_list.php
DEBUG - 2017-02-24 06:58:47 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 06:58:47 --> Final output sent to browser
DEBUG - 2017-02-24 06:58:47 --> Total execution time: 0.0748
INFO - 2017-02-24 07:01:52 --> Config Class Initialized
INFO - 2017-02-24 07:01:52 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:01:52 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:01:52 --> Utf8 Class Initialized
INFO - 2017-02-24 07:01:52 --> URI Class Initialized
INFO - 2017-02-24 07:01:52 --> Router Class Initialized
INFO - 2017-02-24 07:01:52 --> Output Class Initialized
INFO - 2017-02-24 07:01:52 --> Security Class Initialized
DEBUG - 2017-02-24 07:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:01:52 --> Input Class Initialized
INFO - 2017-02-24 07:01:52 --> Language Class Initialized
INFO - 2017-02-24 07:01:52 --> Language Class Initialized
INFO - 2017-02-24 07:01:52 --> Config Class Initialized
INFO - 2017-02-24 07:01:52 --> Loader Class Initialized
INFO - 2017-02-24 07:01:52 --> Helper loaded: form_helper
INFO - 2017-02-24 07:01:52 --> Helper loaded: url_helper
INFO - 2017-02-24 07:01:52 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:01:52 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:01:52 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:01:52 --> Template Class Initialized
INFO - 2017-02-24 07:01:52 --> Controller Class Initialized
INFO - 2017-02-24 07:01:52 --> Model Class Initialized
INFO - 2017-02-24 07:01:52 --> Model Class Initialized
DEBUG - 2017-02-24 07:01:52 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:01:52 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:01:52 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:01:52 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/category/category_list.php
DEBUG - 2017-02-24 07:01:52 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:01:52 --> Final output sent to browser
DEBUG - 2017-02-24 07:01:52 --> Total execution time: 0.0782
INFO - 2017-02-24 07:01:55 --> Config Class Initialized
INFO - 2017-02-24 07:01:55 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:01:55 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:01:55 --> Utf8 Class Initialized
INFO - 2017-02-24 07:01:55 --> URI Class Initialized
INFO - 2017-02-24 07:01:55 --> Router Class Initialized
INFO - 2017-02-24 07:01:55 --> Output Class Initialized
INFO - 2017-02-24 07:01:55 --> Security Class Initialized
DEBUG - 2017-02-24 07:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:01:55 --> Input Class Initialized
INFO - 2017-02-24 07:01:55 --> Language Class Initialized
INFO - 2017-02-24 07:01:55 --> Language Class Initialized
INFO - 2017-02-24 07:01:55 --> Config Class Initialized
INFO - 2017-02-24 07:01:55 --> Loader Class Initialized
INFO - 2017-02-24 07:01:55 --> Helper loaded: form_helper
INFO - 2017-02-24 07:01:55 --> Helper loaded: url_helper
INFO - 2017-02-24 07:01:55 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:01:55 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:01:55 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:01:55 --> Template Class Initialized
INFO - 2017-02-24 07:01:55 --> Controller Class Initialized
INFO - 2017-02-24 07:01:55 --> Model Class Initialized
INFO - 2017-02-24 07:01:55 --> Model Class Initialized
DEBUG - 2017-02-24 07:01:55 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:01:55 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:01:55 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:01:55 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/category/category_list.php
DEBUG - 2017-02-24 07:01:55 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:01:55 --> Final output sent to browser
DEBUG - 2017-02-24 07:01:55 --> Total execution time: 0.0526
INFO - 2017-02-24 07:02:05 --> Config Class Initialized
INFO - 2017-02-24 07:02:05 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:02:05 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:02:05 --> Utf8 Class Initialized
INFO - 2017-02-24 07:02:05 --> URI Class Initialized
INFO - 2017-02-24 07:02:05 --> Router Class Initialized
INFO - 2017-02-24 07:02:05 --> Output Class Initialized
INFO - 2017-02-24 07:02:05 --> Security Class Initialized
DEBUG - 2017-02-24 07:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:02:05 --> Input Class Initialized
INFO - 2017-02-24 07:02:05 --> Language Class Initialized
INFO - 2017-02-24 07:02:05 --> Language Class Initialized
INFO - 2017-02-24 07:02:05 --> Config Class Initialized
INFO - 2017-02-24 07:02:05 --> Loader Class Initialized
INFO - 2017-02-24 07:02:05 --> Helper loaded: form_helper
INFO - 2017-02-24 07:02:05 --> Helper loaded: url_helper
INFO - 2017-02-24 07:02:05 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:02:05 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:02:05 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:02:05 --> Template Class Initialized
INFO - 2017-02-24 07:02:05 --> Controller Class Initialized
DEBUG - 2017-02-24 07:02:05 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:02:05 --> Helper loaded: cookie_helper
INFO - 2017-02-24 07:02:05 --> Model Class Initialized
DEBUG - 2017-02-24 07:02:05 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:02:05 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:02:05 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:02:05 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:02:05 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:02:05 --> Final output sent to browser
DEBUG - 2017-02-24 07:02:05 --> Total execution time: 0.0422
INFO - 2017-02-24 07:02:53 --> Config Class Initialized
INFO - 2017-02-24 07:02:53 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:02:53 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:02:53 --> Utf8 Class Initialized
INFO - 2017-02-24 07:02:53 --> URI Class Initialized
INFO - 2017-02-24 07:02:53 --> Router Class Initialized
INFO - 2017-02-24 07:02:53 --> Output Class Initialized
INFO - 2017-02-24 07:02:53 --> Security Class Initialized
DEBUG - 2017-02-24 07:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:02:53 --> Input Class Initialized
INFO - 2017-02-24 07:02:53 --> Language Class Initialized
INFO - 2017-02-24 07:02:53 --> Language Class Initialized
INFO - 2017-02-24 07:02:53 --> Config Class Initialized
INFO - 2017-02-24 07:02:53 --> Loader Class Initialized
INFO - 2017-02-24 07:02:53 --> Helper loaded: form_helper
INFO - 2017-02-24 07:02:53 --> Helper loaded: url_helper
INFO - 2017-02-24 07:02:53 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:02:53 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:02:53 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:02:53 --> Template Class Initialized
INFO - 2017-02-24 07:02:53 --> Controller Class Initialized
DEBUG - 2017-02-24 07:02:53 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:02:53 --> Helper loaded: cookie_helper
INFO - 2017-02-24 07:02:53 --> Model Class Initialized
DEBUG - 2017-02-24 07:02:53 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:02:53 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:02:53 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:02:53 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:02:53 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:02:53 --> Final output sent to browser
DEBUG - 2017-02-24 07:02:53 --> Total execution time: 0.0552
INFO - 2017-02-24 07:04:11 --> Config Class Initialized
INFO - 2017-02-24 07:04:11 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:04:11 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:04:11 --> Utf8 Class Initialized
INFO - 2017-02-24 07:04:11 --> URI Class Initialized
INFO - 2017-02-24 07:04:11 --> Router Class Initialized
INFO - 2017-02-24 07:04:11 --> Output Class Initialized
INFO - 2017-02-24 07:04:11 --> Security Class Initialized
DEBUG - 2017-02-24 07:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:04:11 --> Input Class Initialized
INFO - 2017-02-24 07:04:11 --> Language Class Initialized
INFO - 2017-02-24 07:04:11 --> Language Class Initialized
INFO - 2017-02-24 07:04:11 --> Config Class Initialized
INFO - 2017-02-24 07:04:11 --> Loader Class Initialized
INFO - 2017-02-24 07:04:11 --> Helper loaded: form_helper
INFO - 2017-02-24 07:04:11 --> Helper loaded: url_helper
INFO - 2017-02-24 07:04:11 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:04:11 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:04:11 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:04:11 --> Template Class Initialized
INFO - 2017-02-24 07:04:11 --> Controller Class Initialized
DEBUG - 2017-02-24 07:04:11 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:04:11 --> Helper loaded: cookie_helper
INFO - 2017-02-24 07:04:11 --> Model Class Initialized
ERROR - 2017-02-24 07:04:11 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
ERROR - 2017-02-24 07:04:11 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
DEBUG - 2017-02-24 07:04:11 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:04:11 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:04:11 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:04:11 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:04:11 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:04:11 --> Final output sent to browser
DEBUG - 2017-02-24 07:04:11 --> Total execution time: 0.0713
INFO - 2017-02-24 07:04:38 --> Config Class Initialized
INFO - 2017-02-24 07:04:38 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:04:38 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:04:38 --> Utf8 Class Initialized
INFO - 2017-02-24 07:04:38 --> URI Class Initialized
INFO - 2017-02-24 07:04:38 --> Router Class Initialized
INFO - 2017-02-24 07:04:38 --> Output Class Initialized
INFO - 2017-02-24 07:04:38 --> Security Class Initialized
DEBUG - 2017-02-24 07:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:04:38 --> Input Class Initialized
INFO - 2017-02-24 07:04:38 --> Language Class Initialized
INFO - 2017-02-24 07:04:38 --> Language Class Initialized
INFO - 2017-02-24 07:04:38 --> Config Class Initialized
INFO - 2017-02-24 07:04:38 --> Loader Class Initialized
INFO - 2017-02-24 07:04:38 --> Helper loaded: form_helper
INFO - 2017-02-24 07:04:38 --> Helper loaded: url_helper
INFO - 2017-02-24 07:04:38 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:04:38 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:04:38 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:04:38 --> Template Class Initialized
INFO - 2017-02-24 07:04:38 --> Controller Class Initialized
DEBUG - 2017-02-24 07:04:38 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:04:38 --> Helper loaded: cookie_helper
INFO - 2017-02-24 07:04:38 --> Model Class Initialized
ERROR - 2017-02-24 07:04:38 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
ERROR - 2017-02-24 07:04:38 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
DEBUG - 2017-02-24 07:04:38 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:04:38 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:04:38 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:04:38 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:04:38 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:04:38 --> Final output sent to browser
DEBUG - 2017-02-24 07:04:38 --> Total execution time: 0.0618
INFO - 2017-02-24 07:05:40 --> Config Class Initialized
INFO - 2017-02-24 07:05:40 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:05:40 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:05:40 --> Utf8 Class Initialized
INFO - 2017-02-24 07:05:40 --> URI Class Initialized
INFO - 2017-02-24 07:05:40 --> Router Class Initialized
INFO - 2017-02-24 07:05:40 --> Output Class Initialized
INFO - 2017-02-24 07:05:40 --> Security Class Initialized
DEBUG - 2017-02-24 07:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:05:40 --> Input Class Initialized
INFO - 2017-02-24 07:05:40 --> Language Class Initialized
ERROR - 2017-02-24 07:05:40 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\silo\application\config\config.php 519
INFO - 2017-02-24 07:06:01 --> Config Class Initialized
INFO - 2017-02-24 07:06:01 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:06:01 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:06:01 --> Utf8 Class Initialized
INFO - 2017-02-24 07:06:01 --> URI Class Initialized
INFO - 2017-02-24 07:06:01 --> Router Class Initialized
INFO - 2017-02-24 07:06:01 --> Output Class Initialized
INFO - 2017-02-24 07:06:01 --> Security Class Initialized
DEBUG - 2017-02-24 07:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:06:01 --> Input Class Initialized
INFO - 2017-02-24 07:06:01 --> Language Class Initialized
ERROR - 2017-02-24 07:06:01 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\silo\application\config\config.php 520
INFO - 2017-02-24 07:07:27 --> Config Class Initialized
INFO - 2017-02-24 07:07:27 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:07:27 --> Utf8 Class Initialized
INFO - 2017-02-24 07:07:27 --> URI Class Initialized
INFO - 2017-02-24 07:07:27 --> Router Class Initialized
INFO - 2017-02-24 07:07:27 --> Output Class Initialized
INFO - 2017-02-24 07:07:27 --> Security Class Initialized
DEBUG - 2017-02-24 07:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:07:27 --> Input Class Initialized
INFO - 2017-02-24 07:07:27 --> Language Class Initialized
ERROR - 2017-02-24 07:07:27 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\silo\application\config\config.php 520
INFO - 2017-02-24 07:07:27 --> Config Class Initialized
INFO - 2017-02-24 07:07:27 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:07:27 --> Utf8 Class Initialized
INFO - 2017-02-24 07:07:27 --> URI Class Initialized
INFO - 2017-02-24 07:07:27 --> Router Class Initialized
INFO - 2017-02-24 07:07:27 --> Output Class Initialized
INFO - 2017-02-24 07:07:27 --> Security Class Initialized
DEBUG - 2017-02-24 07:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:07:27 --> Input Class Initialized
INFO - 2017-02-24 07:07:27 --> Language Class Initialized
ERROR - 2017-02-24 07:07:27 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\silo\application\config\config.php 520
INFO - 2017-02-24 07:07:28 --> Config Class Initialized
INFO - 2017-02-24 07:07:28 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:07:28 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:07:28 --> Utf8 Class Initialized
INFO - 2017-02-24 07:07:28 --> URI Class Initialized
INFO - 2017-02-24 07:07:28 --> Router Class Initialized
INFO - 2017-02-24 07:07:28 --> Output Class Initialized
INFO - 2017-02-24 07:07:28 --> Security Class Initialized
DEBUG - 2017-02-24 07:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:07:28 --> Input Class Initialized
INFO - 2017-02-24 07:07:28 --> Language Class Initialized
ERROR - 2017-02-24 07:07:28 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\silo\application\config\config.php 520
INFO - 2017-02-24 07:07:43 --> Config Class Initialized
INFO - 2017-02-24 07:07:43 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:07:43 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:07:43 --> Utf8 Class Initialized
INFO - 2017-02-24 07:07:43 --> URI Class Initialized
INFO - 2017-02-24 07:07:43 --> Router Class Initialized
INFO - 2017-02-24 07:07:43 --> Output Class Initialized
INFO - 2017-02-24 07:07:43 --> Security Class Initialized
DEBUG - 2017-02-24 07:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:07:43 --> Input Class Initialized
INFO - 2017-02-24 07:07:43 --> Language Class Initialized
ERROR - 2017-02-24 07:07:43 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\silo\application\config\config.php 520
INFO - 2017-02-24 07:07:56 --> Config Class Initialized
INFO - 2017-02-24 07:07:56 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:07:56 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:07:56 --> Utf8 Class Initialized
INFO - 2017-02-24 07:07:56 --> URI Class Initialized
INFO - 2017-02-24 07:07:56 --> Router Class Initialized
INFO - 2017-02-24 07:07:56 --> Output Class Initialized
INFO - 2017-02-24 07:07:56 --> Security Class Initialized
DEBUG - 2017-02-24 07:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:07:56 --> Input Class Initialized
INFO - 2017-02-24 07:07:56 --> Language Class Initialized
ERROR - 2017-02-24 07:07:56 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\silo\application\config\config.php 520
INFO - 2017-02-24 07:07:57 --> Config Class Initialized
INFO - 2017-02-24 07:07:57 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:07:57 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:07:57 --> Utf8 Class Initialized
INFO - 2017-02-24 07:07:57 --> URI Class Initialized
INFO - 2017-02-24 07:07:57 --> Router Class Initialized
INFO - 2017-02-24 07:07:57 --> Output Class Initialized
INFO - 2017-02-24 07:07:57 --> Security Class Initialized
DEBUG - 2017-02-24 07:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:07:57 --> Input Class Initialized
INFO - 2017-02-24 07:07:57 --> Language Class Initialized
ERROR - 2017-02-24 07:07:57 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\silo\application\config\config.php 520
INFO - 2017-02-24 07:07:57 --> Config Class Initialized
INFO - 2017-02-24 07:07:57 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:07:57 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:07:57 --> Utf8 Class Initialized
INFO - 2017-02-24 07:07:57 --> URI Class Initialized
INFO - 2017-02-24 07:07:57 --> Router Class Initialized
INFO - 2017-02-24 07:07:57 --> Output Class Initialized
INFO - 2017-02-24 07:07:57 --> Security Class Initialized
DEBUG - 2017-02-24 07:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:07:57 --> Input Class Initialized
INFO - 2017-02-24 07:07:57 --> Language Class Initialized
ERROR - 2017-02-24 07:07:57 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\silo\application\config\config.php 520
INFO - 2017-02-24 07:08:12 --> Config Class Initialized
INFO - 2017-02-24 07:08:12 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:08:12 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:08:12 --> Utf8 Class Initialized
INFO - 2017-02-24 07:08:12 --> URI Class Initialized
INFO - 2017-02-24 07:08:12 --> Router Class Initialized
INFO - 2017-02-24 07:08:12 --> Output Class Initialized
INFO - 2017-02-24 07:08:12 --> Security Class Initialized
DEBUG - 2017-02-24 07:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:08:12 --> Input Class Initialized
INFO - 2017-02-24 07:08:12 --> Language Class Initialized
ERROR - 2017-02-24 07:08:12 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\silo\application\config\config.php 519
INFO - 2017-02-24 07:08:43 --> Config Class Initialized
INFO - 2017-02-24 07:08:43 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:08:43 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:08:43 --> Utf8 Class Initialized
INFO - 2017-02-24 07:08:43 --> URI Class Initialized
INFO - 2017-02-24 07:08:43 --> Router Class Initialized
INFO - 2017-02-24 07:08:43 --> Output Class Initialized
INFO - 2017-02-24 07:08:43 --> Security Class Initialized
DEBUG - 2017-02-24 07:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:08:43 --> Input Class Initialized
INFO - 2017-02-24 07:08:43 --> Language Class Initialized
ERROR - 2017-02-24 07:08:43 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\silo\application\config\config.php 519
INFO - 2017-02-24 07:26:30 --> Config Class Initialized
INFO - 2017-02-24 07:26:30 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:26:30 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:26:30 --> Utf8 Class Initialized
INFO - 2017-02-24 07:26:30 --> URI Class Initialized
INFO - 2017-02-24 07:26:30 --> Router Class Initialized
INFO - 2017-02-24 07:26:30 --> Output Class Initialized
INFO - 2017-02-24 07:26:30 --> Security Class Initialized
DEBUG - 2017-02-24 07:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:26:30 --> Input Class Initialized
INFO - 2017-02-24 07:26:30 --> Language Class Initialized
INFO - 2017-02-24 07:26:30 --> Language Class Initialized
INFO - 2017-02-24 07:26:30 --> Config Class Initialized
INFO - 2017-02-24 07:26:30 --> Loader Class Initialized
INFO - 2017-02-24 07:26:30 --> Helper loaded: form_helper
INFO - 2017-02-24 07:26:30 --> Helper loaded: url_helper
INFO - 2017-02-24 07:26:30 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:26:30 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:26:30 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:26:30 --> Template Class Initialized
INFO - 2017-02-24 07:26:30 --> Model Class Initialized
INFO - 2017-02-24 07:26:30 --> Controller Class Initialized
DEBUG - 2017-02-24 07:26:30 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:26:30 --> Helper loaded: cookie_helper
ERROR - 2017-02-24 07:26:30 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
ERROR - 2017-02-24 07:26:31 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
DEBUG - 2017-02-24 07:26:31 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:26:31 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:26:31 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:26:31 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:26:31 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:26:31 --> Final output sent to browser
DEBUG - 2017-02-24 07:26:31 --> Total execution time: 0.9400
INFO - 2017-02-24 07:27:19 --> Config Class Initialized
INFO - 2017-02-24 07:27:19 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:27:19 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:27:19 --> Utf8 Class Initialized
INFO - 2017-02-24 07:27:19 --> URI Class Initialized
INFO - 2017-02-24 07:27:19 --> Router Class Initialized
INFO - 2017-02-24 07:27:19 --> Output Class Initialized
INFO - 2017-02-24 07:27:19 --> Security Class Initialized
DEBUG - 2017-02-24 07:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:27:19 --> Input Class Initialized
INFO - 2017-02-24 07:27:19 --> Language Class Initialized
INFO - 2017-02-24 07:27:19 --> Language Class Initialized
INFO - 2017-02-24 07:27:19 --> Config Class Initialized
INFO - 2017-02-24 07:27:19 --> Loader Class Initialized
INFO - 2017-02-24 07:27:19 --> Helper loaded: form_helper
INFO - 2017-02-24 07:27:19 --> Helper loaded: url_helper
INFO - 2017-02-24 07:27:19 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:27:19 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:27:19 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:27:19 --> Template Class Initialized
INFO - 2017-02-24 07:27:19 --> Model Class Initialized
INFO - 2017-02-24 07:27:19 --> Controller Class Initialized
DEBUG - 2017-02-24 07:27:19 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:27:19 --> Helper loaded: cookie_helper
ERROR - 2017-02-24 07:27:19 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
ERROR - 2017-02-24 07:27:19 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
DEBUG - 2017-02-24 07:27:19 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:27:19 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:27:19 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:27:19 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:27:19 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:27:19 --> Final output sent to browser
DEBUG - 2017-02-24 07:27:19 --> Total execution time: 0.0849
INFO - 2017-02-24 07:28:41 --> Config Class Initialized
INFO - 2017-02-24 07:28:41 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:28:41 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:28:41 --> Utf8 Class Initialized
INFO - 2017-02-24 07:28:41 --> URI Class Initialized
INFO - 2017-02-24 07:28:41 --> Router Class Initialized
INFO - 2017-02-24 07:28:41 --> Output Class Initialized
INFO - 2017-02-24 07:28:41 --> Security Class Initialized
DEBUG - 2017-02-24 07:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:28:41 --> Input Class Initialized
INFO - 2017-02-24 07:28:41 --> Language Class Initialized
INFO - 2017-02-24 07:28:41 --> Language Class Initialized
INFO - 2017-02-24 07:28:41 --> Config Class Initialized
INFO - 2017-02-24 07:28:41 --> Loader Class Initialized
INFO - 2017-02-24 07:28:41 --> Helper loaded: form_helper
INFO - 2017-02-24 07:28:41 --> Helper loaded: url_helper
INFO - 2017-02-24 07:28:41 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:28:41 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:28:41 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:28:41 --> Template Class Initialized
INFO - 2017-02-24 07:28:41 --> Model Class Initialized
INFO - 2017-02-24 07:28:41 --> Controller Class Initialized
DEBUG - 2017-02-24 07:28:41 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:28:41 --> Helper loaded: cookie_helper
ERROR - 2017-02-24 07:28:41 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
ERROR - 2017-02-24 07:28:41 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\silo\application\hooks\Global_config.php 15
INFO - 2017-02-24 07:28:42 --> Config Class Initialized
INFO - 2017-02-24 07:28:42 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:28:42 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:28:42 --> Utf8 Class Initialized
INFO - 2017-02-24 07:28:42 --> URI Class Initialized
INFO - 2017-02-24 07:28:43 --> Router Class Initialized
INFO - 2017-02-24 07:28:43 --> Output Class Initialized
INFO - 2017-02-24 07:28:43 --> Security Class Initialized
DEBUG - 2017-02-24 07:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:28:43 --> Input Class Initialized
INFO - 2017-02-24 07:28:43 --> Language Class Initialized
INFO - 2017-02-24 07:28:43 --> Language Class Initialized
INFO - 2017-02-24 07:28:43 --> Config Class Initialized
INFO - 2017-02-24 07:28:43 --> Loader Class Initialized
INFO - 2017-02-24 07:28:43 --> Helper loaded: form_helper
INFO - 2017-02-24 07:28:43 --> Helper loaded: url_helper
INFO - 2017-02-24 07:28:43 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:28:43 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:28:43 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:28:43 --> Template Class Initialized
INFO - 2017-02-24 07:28:43 --> Model Class Initialized
INFO - 2017-02-24 07:28:43 --> Controller Class Initialized
DEBUG - 2017-02-24 07:28:43 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:28:43 --> Helper loaded: cookie_helper
ERROR - 2017-02-24 07:28:43 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
ERROR - 2017-02-24 07:28:43 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\silo\application\hooks\Global_config.php 15
INFO - 2017-02-24 07:28:55 --> Config Class Initialized
INFO - 2017-02-24 07:28:55 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:28:55 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:28:55 --> Utf8 Class Initialized
INFO - 2017-02-24 07:28:55 --> URI Class Initialized
INFO - 2017-02-24 07:28:55 --> Router Class Initialized
INFO - 2017-02-24 07:28:55 --> Output Class Initialized
INFO - 2017-02-24 07:28:55 --> Security Class Initialized
DEBUG - 2017-02-24 07:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:28:55 --> Input Class Initialized
INFO - 2017-02-24 07:28:55 --> Language Class Initialized
INFO - 2017-02-24 07:28:55 --> Language Class Initialized
INFO - 2017-02-24 07:28:55 --> Config Class Initialized
INFO - 2017-02-24 07:28:55 --> Loader Class Initialized
INFO - 2017-02-24 07:28:55 --> Helper loaded: form_helper
INFO - 2017-02-24 07:28:55 --> Helper loaded: url_helper
INFO - 2017-02-24 07:28:55 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:28:55 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:28:55 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:28:55 --> Template Class Initialized
INFO - 2017-02-24 07:28:55 --> Model Class Initialized
INFO - 2017-02-24 07:28:55 --> Controller Class Initialized
DEBUG - 2017-02-24 07:28:55 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:28:55 --> Helper loaded: cookie_helper
ERROR - 2017-02-24 07:28:55 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
ERROR - 2017-02-24 07:28:55 --> Severity: Notice --> Undefined property: Global_config::$common_model C:\xampp\htdocs\silo\application\hooks\Global_config.php 17
ERROR - 2017-02-24 07:28:55 --> Severity: Error --> Call to a member function getGlobalSettings() on null C:\xampp\htdocs\silo\application\hooks\Global_config.php 17
INFO - 2017-02-24 07:29:11 --> Config Class Initialized
INFO - 2017-02-24 07:29:11 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:29:11 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:29:11 --> Utf8 Class Initialized
INFO - 2017-02-24 07:29:11 --> URI Class Initialized
INFO - 2017-02-24 07:29:11 --> Router Class Initialized
INFO - 2017-02-24 07:29:11 --> Output Class Initialized
INFO - 2017-02-24 07:29:11 --> Security Class Initialized
DEBUG - 2017-02-24 07:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:29:11 --> Input Class Initialized
INFO - 2017-02-24 07:29:11 --> Language Class Initialized
INFO - 2017-02-24 07:29:11 --> Language Class Initialized
INFO - 2017-02-24 07:29:11 --> Config Class Initialized
INFO - 2017-02-24 07:29:11 --> Loader Class Initialized
INFO - 2017-02-24 07:29:11 --> Helper loaded: form_helper
INFO - 2017-02-24 07:29:11 --> Helper loaded: url_helper
INFO - 2017-02-24 07:29:11 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:29:11 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:29:11 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:29:11 --> Template Class Initialized
INFO - 2017-02-24 07:29:11 --> Model Class Initialized
INFO - 2017-02-24 07:29:11 --> Controller Class Initialized
DEBUG - 2017-02-24 07:29:11 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:29:11 --> Helper loaded: cookie_helper
ERROR - 2017-02-24 07:29:11 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
ERROR - 2017-02-24 07:29:11 --> Severity: Notice --> Undefined property: Global_config::$common_model C:\xampp\htdocs\silo\application\hooks\Global_config.php 15
ERROR - 2017-02-24 07:29:11 --> Severity: Error --> Call to a member function getGlobalSettings() on null C:\xampp\htdocs\silo\application\hooks\Global_config.php 15
INFO - 2017-02-24 07:29:12 --> Config Class Initialized
INFO - 2017-02-24 07:29:12 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:29:12 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:29:12 --> Utf8 Class Initialized
INFO - 2017-02-24 07:29:12 --> URI Class Initialized
INFO - 2017-02-24 07:29:12 --> Router Class Initialized
INFO - 2017-02-24 07:29:12 --> Output Class Initialized
INFO - 2017-02-24 07:29:12 --> Security Class Initialized
DEBUG - 2017-02-24 07:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:29:12 --> Input Class Initialized
INFO - 2017-02-24 07:29:12 --> Language Class Initialized
INFO - 2017-02-24 07:29:12 --> Language Class Initialized
INFO - 2017-02-24 07:29:12 --> Config Class Initialized
INFO - 2017-02-24 07:29:12 --> Loader Class Initialized
INFO - 2017-02-24 07:29:12 --> Helper loaded: form_helper
INFO - 2017-02-24 07:29:12 --> Helper loaded: url_helper
INFO - 2017-02-24 07:29:12 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:29:12 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:29:12 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:29:12 --> Template Class Initialized
INFO - 2017-02-24 07:29:12 --> Model Class Initialized
INFO - 2017-02-24 07:29:12 --> Controller Class Initialized
DEBUG - 2017-02-24 07:29:12 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:29:12 --> Helper loaded: cookie_helper
ERROR - 2017-02-24 07:29:12 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
ERROR - 2017-02-24 07:29:12 --> Severity: Notice --> Undefined property: Global_config::$common_model C:\xampp\htdocs\silo\application\hooks\Global_config.php 15
ERROR - 2017-02-24 07:29:12 --> Severity: Error --> Call to a member function getGlobalSettings() on null C:\xampp\htdocs\silo\application\hooks\Global_config.php 15
INFO - 2017-02-24 07:29:25 --> Config Class Initialized
INFO - 2017-02-24 07:29:25 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:29:25 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:29:25 --> Utf8 Class Initialized
INFO - 2017-02-24 07:29:25 --> URI Class Initialized
INFO - 2017-02-24 07:29:25 --> Router Class Initialized
INFO - 2017-02-24 07:29:25 --> Output Class Initialized
INFO - 2017-02-24 07:29:25 --> Security Class Initialized
DEBUG - 2017-02-24 07:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:29:25 --> Input Class Initialized
INFO - 2017-02-24 07:29:25 --> Language Class Initialized
INFO - 2017-02-24 07:29:25 --> Language Class Initialized
INFO - 2017-02-24 07:29:25 --> Config Class Initialized
INFO - 2017-02-24 07:29:25 --> Loader Class Initialized
INFO - 2017-02-24 07:29:25 --> Helper loaded: form_helper
INFO - 2017-02-24 07:29:25 --> Helper loaded: url_helper
INFO - 2017-02-24 07:29:25 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:29:25 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:29:25 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:29:25 --> Template Class Initialized
INFO - 2017-02-24 07:29:25 --> Model Class Initialized
INFO - 2017-02-24 07:29:25 --> Controller Class Initialized
DEBUG - 2017-02-24 07:29:25 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:29:25 --> Helper loaded: cookie_helper
ERROR - 2017-02-24 07:29:25 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
ERROR - 2017-02-24 07:29:25 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\silo\application\config\config.php 511
INFO - 2017-02-24 07:29:46 --> Config Class Initialized
INFO - 2017-02-24 07:29:46 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:29:46 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:29:46 --> Utf8 Class Initialized
INFO - 2017-02-24 07:29:46 --> URI Class Initialized
INFO - 2017-02-24 07:29:46 --> Router Class Initialized
INFO - 2017-02-24 07:29:46 --> Output Class Initialized
INFO - 2017-02-24 07:29:46 --> Security Class Initialized
DEBUG - 2017-02-24 07:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:29:46 --> Input Class Initialized
INFO - 2017-02-24 07:29:46 --> Language Class Initialized
INFO - 2017-02-24 07:29:46 --> Language Class Initialized
INFO - 2017-02-24 07:29:46 --> Config Class Initialized
INFO - 2017-02-24 07:29:46 --> Loader Class Initialized
INFO - 2017-02-24 07:29:46 --> Helper loaded: form_helper
INFO - 2017-02-24 07:29:46 --> Helper loaded: url_helper
INFO - 2017-02-24 07:29:46 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:29:46 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:29:46 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:29:46 --> Template Class Initialized
INFO - 2017-02-24 07:29:46 --> Model Class Initialized
INFO - 2017-02-24 07:29:46 --> Controller Class Initialized
DEBUG - 2017-02-24 07:29:46 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:29:46 --> Helper loaded: cookie_helper
ERROR - 2017-02-24 07:29:46 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
ERROR - 2017-02-24 07:29:46 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
DEBUG - 2017-02-24 07:29:46 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:29:46 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:29:46 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:29:46 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:29:46 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:29:46 --> Final output sent to browser
DEBUG - 2017-02-24 07:29:46 --> Total execution time: 0.1456
INFO - 2017-02-24 07:30:05 --> Config Class Initialized
INFO - 2017-02-24 07:30:05 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:30:05 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:30:05 --> Utf8 Class Initialized
INFO - 2017-02-24 07:30:05 --> URI Class Initialized
INFO - 2017-02-24 07:30:05 --> Router Class Initialized
INFO - 2017-02-24 07:30:05 --> Output Class Initialized
INFO - 2017-02-24 07:30:05 --> Security Class Initialized
DEBUG - 2017-02-24 07:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:30:05 --> Input Class Initialized
INFO - 2017-02-24 07:30:05 --> Language Class Initialized
INFO - 2017-02-24 07:30:05 --> Language Class Initialized
INFO - 2017-02-24 07:30:05 --> Config Class Initialized
INFO - 2017-02-24 07:30:05 --> Loader Class Initialized
INFO - 2017-02-24 07:30:05 --> Helper loaded: form_helper
INFO - 2017-02-24 07:30:05 --> Helper loaded: url_helper
INFO - 2017-02-24 07:30:05 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:30:05 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:30:05 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:30:05 --> Template Class Initialized
INFO - 2017-02-24 07:30:05 --> Model Class Initialized
INFO - 2017-02-24 07:30:05 --> Controller Class Initialized
DEBUG - 2017-02-24 07:30:05 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:30:05 --> Helper loaded: cookie_helper
ERROR - 2017-02-24 07:30:05 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
ERROR - 2017-02-24 07:30:05 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
DEBUG - 2017-02-24 07:30:05 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:30:05 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:30:05 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:30:05 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:30:05 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:30:05 --> Final output sent to browser
DEBUG - 2017-02-24 07:30:05 --> Total execution time: 0.0846
INFO - 2017-02-24 07:30:14 --> Config Class Initialized
INFO - 2017-02-24 07:30:14 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:30:14 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:30:14 --> Utf8 Class Initialized
INFO - 2017-02-24 07:30:14 --> URI Class Initialized
INFO - 2017-02-24 07:30:14 --> Router Class Initialized
INFO - 2017-02-24 07:30:14 --> Output Class Initialized
INFO - 2017-02-24 07:30:14 --> Security Class Initialized
DEBUG - 2017-02-24 07:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:30:14 --> Input Class Initialized
INFO - 2017-02-24 07:30:14 --> Language Class Initialized
INFO - 2017-02-24 07:30:14 --> Language Class Initialized
INFO - 2017-02-24 07:30:14 --> Config Class Initialized
INFO - 2017-02-24 07:30:14 --> Loader Class Initialized
INFO - 2017-02-24 07:30:14 --> Helper loaded: form_helper
INFO - 2017-02-24 07:30:14 --> Helper loaded: url_helper
INFO - 2017-02-24 07:30:14 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:30:14 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:30:14 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:30:14 --> Template Class Initialized
INFO - 2017-02-24 07:30:14 --> Model Class Initialized
INFO - 2017-02-24 07:30:14 --> Controller Class Initialized
DEBUG - 2017-02-24 07:30:14 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:30:14 --> Helper loaded: cookie_helper
ERROR - 2017-02-24 07:30:14 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
ERROR - 2017-02-24 07:30:14 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
DEBUG - 2017-02-24 07:30:14 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:30:14 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:30:14 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:30:14 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:30:14 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:30:14 --> Final output sent to browser
DEBUG - 2017-02-24 07:30:14 --> Total execution time: 0.0514
INFO - 2017-02-24 07:30:25 --> Config Class Initialized
INFO - 2017-02-24 07:30:25 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:30:25 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:30:25 --> Utf8 Class Initialized
INFO - 2017-02-24 07:30:25 --> URI Class Initialized
INFO - 2017-02-24 07:30:25 --> Router Class Initialized
INFO - 2017-02-24 07:30:25 --> Output Class Initialized
INFO - 2017-02-24 07:30:25 --> Security Class Initialized
DEBUG - 2017-02-24 07:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:30:25 --> Input Class Initialized
INFO - 2017-02-24 07:30:25 --> Language Class Initialized
INFO - 2017-02-24 07:30:25 --> Language Class Initialized
INFO - 2017-02-24 07:30:25 --> Config Class Initialized
INFO - 2017-02-24 07:30:25 --> Loader Class Initialized
INFO - 2017-02-24 07:30:25 --> Helper loaded: form_helper
INFO - 2017-02-24 07:30:25 --> Helper loaded: url_helper
INFO - 2017-02-24 07:30:25 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:30:25 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:30:25 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:30:25 --> Template Class Initialized
INFO - 2017-02-24 07:30:25 --> Model Class Initialized
INFO - 2017-02-24 07:30:25 --> Controller Class Initialized
DEBUG - 2017-02-24 07:30:25 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:30:25 --> Helper loaded: cookie_helper
ERROR - 2017-02-24 07:30:25 --> Severity: Notice --> Undefined property: CI::$global_setting C:\xampp\htdocs\silo\application\third_party\MX\Controller.php 62
DEBUG - 2017-02-24 07:30:25 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:30:25 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:30:25 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:30:25 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:30:25 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:30:25 --> Final output sent to browser
DEBUG - 2017-02-24 07:30:25 --> Total execution time: 0.1099
INFO - 2017-02-24 07:30:39 --> Config Class Initialized
INFO - 2017-02-24 07:30:39 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:30:39 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:30:39 --> Utf8 Class Initialized
INFO - 2017-02-24 07:30:39 --> URI Class Initialized
INFO - 2017-02-24 07:30:39 --> Router Class Initialized
INFO - 2017-02-24 07:30:39 --> Output Class Initialized
INFO - 2017-02-24 07:30:39 --> Security Class Initialized
DEBUG - 2017-02-24 07:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:30:39 --> Input Class Initialized
INFO - 2017-02-24 07:30:39 --> Language Class Initialized
INFO - 2017-02-24 07:30:39 --> Language Class Initialized
INFO - 2017-02-24 07:30:39 --> Config Class Initialized
INFO - 2017-02-24 07:30:39 --> Loader Class Initialized
INFO - 2017-02-24 07:30:39 --> Helper loaded: form_helper
INFO - 2017-02-24 07:30:39 --> Helper loaded: url_helper
INFO - 2017-02-24 07:30:39 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:30:39 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:30:39 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:30:39 --> Template Class Initialized
INFO - 2017-02-24 07:30:39 --> Model Class Initialized
INFO - 2017-02-24 07:30:39 --> Controller Class Initialized
DEBUG - 2017-02-24 07:30:39 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:30:39 --> Helper loaded: cookie_helper
DEBUG - 2017-02-24 07:30:39 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:30:39 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:30:39 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:30:39 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:30:39 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:30:39 --> Final output sent to browser
DEBUG - 2017-02-24 07:30:39 --> Total execution time: 0.0610
INFO - 2017-02-24 07:31:22 --> Config Class Initialized
INFO - 2017-02-24 07:31:22 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:31:22 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:31:22 --> Utf8 Class Initialized
INFO - 2017-02-24 07:31:22 --> URI Class Initialized
INFO - 2017-02-24 07:31:22 --> Router Class Initialized
INFO - 2017-02-24 07:31:22 --> Output Class Initialized
INFO - 2017-02-24 07:31:22 --> Security Class Initialized
DEBUG - 2017-02-24 07:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:31:22 --> Input Class Initialized
INFO - 2017-02-24 07:31:22 --> Language Class Initialized
INFO - 2017-02-24 07:31:22 --> Language Class Initialized
INFO - 2017-02-24 07:31:22 --> Config Class Initialized
INFO - 2017-02-24 07:31:22 --> Loader Class Initialized
INFO - 2017-02-24 07:31:22 --> Helper loaded: form_helper
INFO - 2017-02-24 07:31:22 --> Helper loaded: url_helper
INFO - 2017-02-24 07:31:22 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:31:22 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:31:22 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:31:22 --> Template Class Initialized
INFO - 2017-02-24 07:31:22 --> Model Class Initialized
INFO - 2017-02-24 07:31:22 --> Controller Class Initialized
DEBUG - 2017-02-24 07:31:22 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:31:22 --> Helper loaded: cookie_helper
INFO - 2017-02-24 07:31:23 --> Helper loaded: inflector_helper
DEBUG - 2017-02-24 07:31:23 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:31:23 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:31:23 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:31:23 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:31:23 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:31:23 --> Final output sent to browser
DEBUG - 2017-02-24 07:31:23 --> Total execution time: 0.1760
INFO - 2017-02-24 07:32:54 --> Config Class Initialized
INFO - 2017-02-24 07:32:54 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:32:54 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:32:54 --> Utf8 Class Initialized
INFO - 2017-02-24 07:32:54 --> URI Class Initialized
INFO - 2017-02-24 07:32:54 --> Router Class Initialized
INFO - 2017-02-24 07:32:54 --> Output Class Initialized
INFO - 2017-02-24 07:32:54 --> Security Class Initialized
DEBUG - 2017-02-24 07:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:32:54 --> Input Class Initialized
INFO - 2017-02-24 07:32:54 --> Language Class Initialized
INFO - 2017-02-24 07:32:54 --> Language Class Initialized
INFO - 2017-02-24 07:32:54 --> Config Class Initialized
INFO - 2017-02-24 07:32:54 --> Loader Class Initialized
INFO - 2017-02-24 07:32:54 --> Helper loaded: form_helper
INFO - 2017-02-24 07:32:54 --> Helper loaded: url_helper
INFO - 2017-02-24 07:32:54 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:32:54 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:32:54 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:32:54 --> Template Class Initialized
INFO - 2017-02-24 07:32:54 --> Model Class Initialized
INFO - 2017-02-24 07:32:54 --> Controller Class Initialized
DEBUG - 2017-02-24 07:32:54 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:32:54 --> Helper loaded: cookie_helper
DEBUG - 2017-02-24 07:32:54 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:32:54 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:32:54 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:32:54 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:32:54 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:32:54 --> Final output sent to browser
DEBUG - 2017-02-24 07:32:54 --> Total execution time: 0.0641
INFO - 2017-02-24 07:33:11 --> Config Class Initialized
INFO - 2017-02-24 07:33:11 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:33:11 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:33:11 --> Utf8 Class Initialized
INFO - 2017-02-24 07:33:11 --> URI Class Initialized
INFO - 2017-02-24 07:33:11 --> Router Class Initialized
INFO - 2017-02-24 07:33:11 --> Output Class Initialized
INFO - 2017-02-24 07:33:11 --> Security Class Initialized
DEBUG - 2017-02-24 07:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:33:11 --> Input Class Initialized
INFO - 2017-02-24 07:33:11 --> Language Class Initialized
INFO - 2017-02-24 07:33:11 --> Language Class Initialized
INFO - 2017-02-24 07:33:11 --> Config Class Initialized
INFO - 2017-02-24 07:33:11 --> Loader Class Initialized
INFO - 2017-02-24 07:33:11 --> Helper loaded: form_helper
INFO - 2017-02-24 07:33:11 --> Helper loaded: url_helper
INFO - 2017-02-24 07:33:11 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:33:11 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:33:11 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:33:11 --> Template Class Initialized
INFO - 2017-02-24 07:33:11 --> Model Class Initialized
INFO - 2017-02-24 07:33:11 --> Controller Class Initialized
DEBUG - 2017-02-24 07:33:11 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:33:11 --> Helper loaded: cookie_helper
INFO - 2017-02-24 07:33:11 --> Helper loaded: inflector_helper
DEBUG - 2017-02-24 07:33:11 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:33:11 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:33:11 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:33:11 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:33:11 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:33:11 --> Final output sent to browser
DEBUG - 2017-02-24 07:33:11 --> Total execution time: 0.1070
INFO - 2017-02-24 07:33:37 --> Config Class Initialized
INFO - 2017-02-24 07:33:37 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:33:37 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:33:37 --> Utf8 Class Initialized
INFO - 2017-02-24 07:33:37 --> URI Class Initialized
INFO - 2017-02-24 07:33:37 --> Router Class Initialized
INFO - 2017-02-24 07:33:37 --> Output Class Initialized
INFO - 2017-02-24 07:33:37 --> Security Class Initialized
DEBUG - 2017-02-24 07:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:33:37 --> Input Class Initialized
INFO - 2017-02-24 07:33:37 --> Language Class Initialized
INFO - 2017-02-24 07:33:37 --> Language Class Initialized
INFO - 2017-02-24 07:33:37 --> Config Class Initialized
INFO - 2017-02-24 07:33:37 --> Loader Class Initialized
INFO - 2017-02-24 07:33:37 --> Helper loaded: form_helper
INFO - 2017-02-24 07:33:37 --> Helper loaded: url_helper
INFO - 2017-02-24 07:33:37 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:33:37 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:33:37 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:33:37 --> Template Class Initialized
INFO - 2017-02-24 07:33:37 --> Model Class Initialized
INFO - 2017-02-24 07:33:37 --> Controller Class Initialized
DEBUG - 2017-02-24 07:33:37 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:33:37 --> Helper loaded: cookie_helper
INFO - 2017-02-24 07:33:37 --> Helper loaded: inflector_helper
DEBUG - 2017-02-24 07:33:37 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:33:37 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:33:37 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:33:37 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:33:37 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:33:37 --> Final output sent to browser
DEBUG - 2017-02-24 07:33:37 --> Total execution time: 0.0717
INFO - 2017-02-24 07:33:54 --> Config Class Initialized
INFO - 2017-02-24 07:33:54 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:33:54 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:33:54 --> Utf8 Class Initialized
INFO - 2017-02-24 07:33:54 --> URI Class Initialized
INFO - 2017-02-24 07:33:54 --> Router Class Initialized
INFO - 2017-02-24 07:33:54 --> Output Class Initialized
INFO - 2017-02-24 07:33:54 --> Security Class Initialized
DEBUG - 2017-02-24 07:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:33:54 --> Input Class Initialized
INFO - 2017-02-24 07:33:54 --> Language Class Initialized
INFO - 2017-02-24 07:33:54 --> Language Class Initialized
INFO - 2017-02-24 07:33:54 --> Config Class Initialized
INFO - 2017-02-24 07:33:54 --> Loader Class Initialized
INFO - 2017-02-24 07:33:54 --> Helper loaded: form_helper
INFO - 2017-02-24 07:33:54 --> Helper loaded: url_helper
INFO - 2017-02-24 07:33:54 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:33:54 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:33:54 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:33:54 --> Template Class Initialized
INFO - 2017-02-24 07:33:54 --> Model Class Initialized
INFO - 2017-02-24 07:33:54 --> Controller Class Initialized
DEBUG - 2017-02-24 07:33:54 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:33:54 --> Helper loaded: cookie_helper
ERROR - 2017-02-24 07:33:54 --> Severity: Notice --> Undefined variable: config_data C:\xampp\htdocs\silo\application\modules\backend\controllers\Dashboard.php 18
INFO - 2017-02-24 07:33:54 --> Helper loaded: inflector_helper
DEBUG - 2017-02-24 07:33:54 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:33:54 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:33:54 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:33:54 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:33:54 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:33:54 --> Final output sent to browser
DEBUG - 2017-02-24 07:33:54 --> Total execution time: 0.0740
INFO - 2017-02-24 07:48:31 --> Config Class Initialized
INFO - 2017-02-24 07:48:31 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:48:31 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:48:31 --> Utf8 Class Initialized
INFO - 2017-02-24 07:48:31 --> URI Class Initialized
INFO - 2017-02-24 07:48:31 --> Router Class Initialized
INFO - 2017-02-24 07:48:31 --> Output Class Initialized
INFO - 2017-02-24 07:48:31 --> Security Class Initialized
DEBUG - 2017-02-24 07:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:48:31 --> Input Class Initialized
INFO - 2017-02-24 07:48:31 --> Language Class Initialized
INFO - 2017-02-24 07:48:31 --> Language Class Initialized
INFO - 2017-02-24 07:48:31 --> Config Class Initialized
INFO - 2017-02-24 07:48:31 --> Loader Class Initialized
INFO - 2017-02-24 07:48:31 --> Helper loaded: form_helper
INFO - 2017-02-24 07:48:31 --> Helper loaded: url_helper
INFO - 2017-02-24 07:48:31 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:48:31 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:48:31 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:48:31 --> Template Class Initialized
INFO - 2017-02-24 07:48:31 --> Model Class Initialized
INFO - 2017-02-24 07:48:31 --> Controller Class Initialized
DEBUG - 2017-02-24 07:48:31 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:48:31 --> Helper loaded: cookie_helper
ERROR - 2017-02-24 07:48:31 --> Severity: Notice --> Undefined variable: config_data C:\xampp\htdocs\silo\application\modules\backend\controllers\Dashboard.php 18
INFO - 2017-02-24 07:48:31 --> Helper loaded: inflector_helper
DEBUG - 2017-02-24 07:48:31 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:48:31 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:48:31 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:48:31 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:48:31 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:48:31 --> Final output sent to browser
DEBUG - 2017-02-24 07:48:31 --> Total execution time: 0.5677
INFO - 2017-02-24 07:49:40 --> Config Class Initialized
INFO - 2017-02-24 07:49:40 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:49:40 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:49:40 --> Utf8 Class Initialized
INFO - 2017-02-24 07:49:40 --> URI Class Initialized
INFO - 2017-02-24 07:49:40 --> Router Class Initialized
INFO - 2017-02-24 07:49:40 --> Output Class Initialized
INFO - 2017-02-24 07:49:40 --> Security Class Initialized
DEBUG - 2017-02-24 07:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:49:40 --> Input Class Initialized
INFO - 2017-02-24 07:49:40 --> Language Class Initialized
INFO - 2017-02-24 07:49:40 --> Language Class Initialized
INFO - 2017-02-24 07:49:40 --> Config Class Initialized
INFO - 2017-02-24 07:49:40 --> Loader Class Initialized
INFO - 2017-02-24 07:49:40 --> Helper loaded: form_helper
INFO - 2017-02-24 07:49:40 --> Helper loaded: url_helper
INFO - 2017-02-24 07:49:40 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:49:40 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:49:40 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:49:40 --> Template Class Initialized
INFO - 2017-02-24 07:49:40 --> Model Class Initialized
INFO - 2017-02-24 07:49:40 --> Controller Class Initialized
DEBUG - 2017-02-24 07:49:40 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:49:40 --> Helper loaded: cookie_helper
ERROR - 2017-02-24 07:49:40 --> Severity: Notice --> Undefined variable: config_data C:\xampp\htdocs\silo\application\modules\backend\controllers\Dashboard.php 18
INFO - 2017-02-24 07:49:40 --> Helper loaded: inflector_helper
DEBUG - 2017-02-24 07:49:40 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:49:40 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:49:40 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:49:40 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:49:40 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:49:40 --> Final output sent to browser
DEBUG - 2017-02-24 07:49:40 --> Total execution time: 0.0508
INFO - 2017-02-24 07:54:36 --> Config Class Initialized
INFO - 2017-02-24 07:54:36 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:54:36 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:54:36 --> Utf8 Class Initialized
INFO - 2017-02-24 07:54:36 --> URI Class Initialized
INFO - 2017-02-24 07:54:36 --> Router Class Initialized
INFO - 2017-02-24 07:54:36 --> Output Class Initialized
INFO - 2017-02-24 07:54:36 --> Security Class Initialized
DEBUG - 2017-02-24 07:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:54:36 --> Input Class Initialized
INFO - 2017-02-24 07:54:36 --> Language Class Initialized
INFO - 2017-02-24 07:54:36 --> Language Class Initialized
INFO - 2017-02-24 07:54:36 --> Config Class Initialized
INFO - 2017-02-24 07:54:36 --> Loader Class Initialized
INFO - 2017-02-24 07:54:36 --> Helper loaded: form_helper
INFO - 2017-02-24 07:54:36 --> Helper loaded: url_helper
INFO - 2017-02-24 07:54:36 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:54:36 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:54:36 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:54:36 --> Template Class Initialized
INFO - 2017-02-24 07:54:36 --> Model Class Initialized
INFO - 2017-02-24 07:54:36 --> Controller Class Initialized
DEBUG - 2017-02-24 07:54:36 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:54:36 --> Helper loaded: cookie_helper
INFO - 2017-02-24 07:54:36 --> Helper loaded: inflector_helper
DEBUG - 2017-02-24 07:54:36 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:54:36 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:54:36 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:54:36 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:54:36 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:54:36 --> Final output sent to browser
DEBUG - 2017-02-24 07:54:36 --> Total execution time: 0.1582
INFO - 2017-02-24 07:54:52 --> Config Class Initialized
INFO - 2017-02-24 07:54:52 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:54:52 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:54:52 --> Utf8 Class Initialized
INFO - 2017-02-24 07:54:52 --> URI Class Initialized
INFO - 2017-02-24 07:54:52 --> Router Class Initialized
INFO - 2017-02-24 07:54:52 --> Output Class Initialized
INFO - 2017-02-24 07:54:52 --> Security Class Initialized
DEBUG - 2017-02-24 07:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:54:52 --> Input Class Initialized
INFO - 2017-02-24 07:54:52 --> Language Class Initialized
INFO - 2017-02-24 07:54:52 --> Language Class Initialized
INFO - 2017-02-24 07:54:52 --> Config Class Initialized
INFO - 2017-02-24 07:54:52 --> Loader Class Initialized
INFO - 2017-02-24 07:54:52 --> Helper loaded: form_helper
INFO - 2017-02-24 07:54:52 --> Helper loaded: url_helper
INFO - 2017-02-24 07:54:52 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:54:53 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:54:53 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:54:53 --> Template Class Initialized
INFO - 2017-02-24 07:54:53 --> Model Class Initialized
INFO - 2017-02-24 07:54:53 --> Controller Class Initialized
DEBUG - 2017-02-24 07:54:53 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:54:53 --> Helper loaded: cookie_helper
INFO - 2017-02-24 07:54:53 --> Helper loaded: inflector_helper
DEBUG - 2017-02-24 07:54:53 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:54:53 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:54:53 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:54:53 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:54:53 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:54:53 --> Final output sent to browser
DEBUG - 2017-02-24 07:54:53 --> Total execution time: 0.0485
INFO - 2017-02-24 07:55:30 --> Config Class Initialized
INFO - 2017-02-24 07:55:30 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:55:30 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:55:30 --> Utf8 Class Initialized
INFO - 2017-02-24 07:55:30 --> URI Class Initialized
INFO - 2017-02-24 07:55:30 --> Router Class Initialized
INFO - 2017-02-24 07:55:30 --> Output Class Initialized
INFO - 2017-02-24 07:55:30 --> Security Class Initialized
DEBUG - 2017-02-24 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:55:30 --> Input Class Initialized
INFO - 2017-02-24 07:55:30 --> Language Class Initialized
INFO - 2017-02-24 07:55:30 --> Language Class Initialized
INFO - 2017-02-24 07:55:30 --> Config Class Initialized
INFO - 2017-02-24 07:55:30 --> Loader Class Initialized
ERROR - 2017-02-24 07:55:30 --> Severity: Notice --> Undefined property: MX_Config::$load C:\xampp\htdocs\silo\application\config\global_setting.php 14
ERROR - 2017-02-24 07:55:30 --> Severity: Error --> Call to a member function model() on null C:\xampp\htdocs\silo\application\config\global_setting.php 14
INFO - 2017-02-24 07:56:56 --> Config Class Initialized
INFO - 2017-02-24 07:56:56 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:56:56 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:56:56 --> Utf8 Class Initialized
INFO - 2017-02-24 07:56:56 --> URI Class Initialized
INFO - 2017-02-24 07:56:56 --> Router Class Initialized
INFO - 2017-02-24 07:56:56 --> Output Class Initialized
INFO - 2017-02-24 07:56:56 --> Security Class Initialized
DEBUG - 2017-02-24 07:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:56:56 --> Input Class Initialized
INFO - 2017-02-24 07:56:56 --> Language Class Initialized
INFO - 2017-02-24 07:56:56 --> Language Class Initialized
INFO - 2017-02-24 07:56:56 --> Config Class Initialized
INFO - 2017-02-24 07:56:56 --> Loader Class Initialized
ERROR - 2017-02-24 07:56:56 --> Severity: Notice --> Undefined property: MX_Config::$CI C:\xampp\htdocs\silo\application\config\global_setting.php 14
ERROR - 2017-02-24 07:56:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\silo\application\config\global_setting.php 14
ERROR - 2017-02-24 07:56:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\silo\system\core\Exceptions.php:271) C:\xampp\htdocs\silo\system\core\Common.php 578
ERROR - 2017-02-24 07:56:56 --> Severity: Error --> Call to a member function getGlobalSettings() on null C:\xampp\htdocs\silo\application\config\global_setting.php 14
INFO - 2017-02-24 07:56:57 --> Config Class Initialized
INFO - 2017-02-24 07:56:57 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:56:57 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:56:57 --> Utf8 Class Initialized
INFO - 2017-02-24 07:56:57 --> URI Class Initialized
INFO - 2017-02-24 07:56:57 --> Router Class Initialized
INFO - 2017-02-24 07:56:57 --> Output Class Initialized
INFO - 2017-02-24 07:56:57 --> Security Class Initialized
DEBUG - 2017-02-24 07:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:56:57 --> Input Class Initialized
INFO - 2017-02-24 07:56:57 --> Language Class Initialized
INFO - 2017-02-24 07:56:57 --> Language Class Initialized
INFO - 2017-02-24 07:56:57 --> Config Class Initialized
INFO - 2017-02-24 07:56:57 --> Loader Class Initialized
ERROR - 2017-02-24 07:56:57 --> Severity: Notice --> Undefined property: MX_Config::$CI C:\xampp\htdocs\silo\application\config\global_setting.php 14
ERROR - 2017-02-24 07:56:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\silo\application\config\global_setting.php 14
ERROR - 2017-02-24 07:56:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\silo\system\core\Exceptions.php:271) C:\xampp\htdocs\silo\system\core\Common.php 578
ERROR - 2017-02-24 07:56:57 --> Severity: Error --> Call to a member function getGlobalSettings() on null C:\xampp\htdocs\silo\application\config\global_setting.php 14
INFO - 2017-02-24 07:57:04 --> Config Class Initialized
INFO - 2017-02-24 07:57:04 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:57:04 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:57:04 --> Utf8 Class Initialized
INFO - 2017-02-24 07:57:04 --> URI Class Initialized
INFO - 2017-02-24 07:57:04 --> Router Class Initialized
INFO - 2017-02-24 07:57:04 --> Output Class Initialized
INFO - 2017-02-24 07:57:04 --> Security Class Initialized
DEBUG - 2017-02-24 07:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:57:04 --> Input Class Initialized
INFO - 2017-02-24 07:57:04 --> Language Class Initialized
INFO - 2017-02-24 07:57:04 --> Language Class Initialized
INFO - 2017-02-24 07:57:04 --> Config Class Initialized
INFO - 2017-02-24 07:57:04 --> Loader Class Initialized
ERROR - 2017-02-24 07:57:04 --> Severity: Parsing Error --> syntax error, unexpected 'private' (T_PRIVATE) C:\xampp\htdocs\silo\application\config\global_setting.php 14
INFO - 2017-02-24 07:57:18 --> Config Class Initialized
INFO - 2017-02-24 07:57:18 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:57:18 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:57:18 --> Utf8 Class Initialized
INFO - 2017-02-24 07:57:18 --> URI Class Initialized
INFO - 2017-02-24 07:57:18 --> Router Class Initialized
INFO - 2017-02-24 07:57:18 --> Output Class Initialized
INFO - 2017-02-24 07:57:18 --> Security Class Initialized
DEBUG - 2017-02-24 07:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:57:18 --> Input Class Initialized
INFO - 2017-02-24 07:57:18 --> Language Class Initialized
INFO - 2017-02-24 07:57:18 --> Language Class Initialized
INFO - 2017-02-24 07:57:18 --> Config Class Initialized
INFO - 2017-02-24 07:57:18 --> Loader Class Initialized
ERROR - 2017-02-24 07:57:18 --> Severity: Notice --> Undefined property: MX_Config::$common_model C:\xampp\htdocs\silo\application\config\global_setting.php 15
ERROR - 2017-02-24 07:57:19 --> Severity: Error --> Call to a member function getGlobalSettings() on null C:\xampp\htdocs\silo\application\config\global_setting.php 15
INFO - 2017-02-24 07:57:20 --> Config Class Initialized
INFO - 2017-02-24 07:57:20 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:57:20 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:57:20 --> Utf8 Class Initialized
INFO - 2017-02-24 07:57:20 --> URI Class Initialized
INFO - 2017-02-24 07:57:20 --> Router Class Initialized
INFO - 2017-02-24 07:57:20 --> Output Class Initialized
INFO - 2017-02-24 07:57:20 --> Security Class Initialized
DEBUG - 2017-02-24 07:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:57:20 --> Input Class Initialized
INFO - 2017-02-24 07:57:20 --> Language Class Initialized
INFO - 2017-02-24 07:57:20 --> Language Class Initialized
INFO - 2017-02-24 07:57:20 --> Config Class Initialized
INFO - 2017-02-24 07:57:20 --> Loader Class Initialized
ERROR - 2017-02-24 07:57:20 --> Severity: Notice --> Undefined property: MX_Config::$common_model C:\xampp\htdocs\silo\application\config\global_setting.php 15
ERROR - 2017-02-24 07:57:20 --> Severity: Error --> Call to a member function getGlobalSettings() on null C:\xampp\htdocs\silo\application\config\global_setting.php 15
INFO - 2017-02-24 07:58:29 --> Config Class Initialized
INFO - 2017-02-24 07:58:29 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:58:29 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:58:29 --> Utf8 Class Initialized
INFO - 2017-02-24 07:58:29 --> URI Class Initialized
INFO - 2017-02-24 07:58:29 --> Router Class Initialized
INFO - 2017-02-24 07:58:29 --> Output Class Initialized
INFO - 2017-02-24 07:58:29 --> Security Class Initialized
DEBUG - 2017-02-24 07:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:58:29 --> Input Class Initialized
INFO - 2017-02-24 07:58:29 --> Language Class Initialized
INFO - 2017-02-24 07:58:29 --> Language Class Initialized
INFO - 2017-02-24 07:58:29 --> Config Class Initialized
INFO - 2017-02-24 07:58:29 --> Loader Class Initialized
INFO - 2017-02-24 07:58:29 --> Helper loaded: form_helper
INFO - 2017-02-24 07:58:29 --> Helper loaded: url_helper
INFO - 2017-02-24 07:58:29 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:58:29 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:58:29 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:58:29 --> Template Class Initialized
INFO - 2017-02-24 07:58:29 --> Controller Class Initialized
DEBUG - 2017-02-24 07:58:29 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 07:58:29 --> Helper loaded: cookie_helper
INFO - 2017-02-24 07:58:29 --> Model Class Initialized
DEBUG - 2017-02-24 07:58:29 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:58:29 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:58:29 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:58:29 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 07:58:29 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:58:29 --> Final output sent to browser
DEBUG - 2017-02-24 07:58:29 --> Total execution time: 0.1497
INFO - 2017-02-24 07:58:36 --> Config Class Initialized
INFO - 2017-02-24 07:58:36 --> Hooks Class Initialized
DEBUG - 2017-02-24 07:58:36 --> UTF-8 Support Enabled
INFO - 2017-02-24 07:58:36 --> Utf8 Class Initialized
INFO - 2017-02-24 07:58:36 --> URI Class Initialized
INFO - 2017-02-24 07:58:36 --> Router Class Initialized
INFO - 2017-02-24 07:58:36 --> Output Class Initialized
INFO - 2017-02-24 07:58:36 --> Security Class Initialized
DEBUG - 2017-02-24 07:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 07:58:36 --> Input Class Initialized
INFO - 2017-02-24 07:58:36 --> Language Class Initialized
INFO - 2017-02-24 07:58:37 --> Language Class Initialized
INFO - 2017-02-24 07:58:37 --> Config Class Initialized
INFO - 2017-02-24 07:58:37 --> Loader Class Initialized
INFO - 2017-02-24 07:58:37 --> Helper loaded: form_helper
INFO - 2017-02-24 07:58:37 --> Helper loaded: url_helper
INFO - 2017-02-24 07:58:37 --> Helper loaded: utility_helper
INFO - 2017-02-24 07:58:37 --> Database Driver Class Initialized
DEBUG - 2017-02-24 07:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 07:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 07:58:37 --> User Agent Class Initialized
DEBUG - 2017-02-24 07:58:37 --> Template Class Initialized
INFO - 2017-02-24 07:58:37 --> Controller Class Initialized
DEBUG - 2017-02-24 07:58:37 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-24 07:58:37 --> Model Class Initialized
INFO - 2017-02-24 07:58:37 --> Model Class Initialized
DEBUG - 2017-02-24 07:58:37 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 07:58:37 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 07:58:37 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 07:58:37 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/global-setting/globle_setting_list.php
DEBUG - 2017-02-24 07:58:37 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 07:58:37 --> Final output sent to browser
DEBUG - 2017-02-24 07:58:37 --> Total execution time: 0.1207
INFO - 2017-02-24 08:01:22 --> Config Class Initialized
INFO - 2017-02-24 08:01:22 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:01:22 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:01:22 --> Utf8 Class Initialized
INFO - 2017-02-24 08:01:22 --> URI Class Initialized
INFO - 2017-02-24 08:01:22 --> Router Class Initialized
INFO - 2017-02-24 08:01:22 --> Output Class Initialized
INFO - 2017-02-24 08:01:22 --> Security Class Initialized
DEBUG - 2017-02-24 08:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:01:22 --> Input Class Initialized
INFO - 2017-02-24 08:01:22 --> Language Class Initialized
INFO - 2017-02-24 08:01:22 --> Language Class Initialized
INFO - 2017-02-24 08:01:22 --> Config Class Initialized
INFO - 2017-02-24 08:01:22 --> Loader Class Initialized
INFO - 2017-02-24 08:01:22 --> Helper loaded: form_helper
INFO - 2017-02-24 08:01:22 --> Helper loaded: url_helper
INFO - 2017-02-24 08:01:22 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:01:22 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:01:22 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:01:22 --> Template Class Initialized
INFO - 2017-02-24 08:01:22 --> Controller Class Initialized
INFO - 2017-02-24 08:01:22 --> Model Class Initialized
INFO - 2017-02-24 08:01:22 --> Model Class Initialized
DEBUG - 2017-02-24 08:01:22 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:01:22 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:01:22 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:01:22 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/blog/blog_list.php
DEBUG - 2017-02-24 08:01:22 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:01:22 --> Final output sent to browser
DEBUG - 2017-02-24 08:01:22 --> Total execution time: 0.4776
INFO - 2017-02-24 08:01:26 --> Config Class Initialized
INFO - 2017-02-24 08:01:26 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:01:26 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:01:26 --> Utf8 Class Initialized
INFO - 2017-02-24 08:01:26 --> URI Class Initialized
INFO - 2017-02-24 08:01:26 --> Router Class Initialized
INFO - 2017-02-24 08:01:26 --> Output Class Initialized
INFO - 2017-02-24 08:01:26 --> Security Class Initialized
DEBUG - 2017-02-24 08:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:01:26 --> Input Class Initialized
INFO - 2017-02-24 08:01:26 --> Language Class Initialized
INFO - 2017-02-24 08:01:26 --> Language Class Initialized
INFO - 2017-02-24 08:01:26 --> Config Class Initialized
INFO - 2017-02-24 08:01:26 --> Loader Class Initialized
INFO - 2017-02-24 08:01:26 --> Helper loaded: form_helper
INFO - 2017-02-24 08:01:26 --> Helper loaded: url_helper
INFO - 2017-02-24 08:01:26 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:01:26 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:01:26 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:01:26 --> Template Class Initialized
INFO - 2017-02-24 08:01:26 --> Controller Class Initialized
INFO - 2017-02-24 08:01:26 --> Model Class Initialized
INFO - 2017-02-24 08:01:26 --> Model Class Initialized
DEBUG - 2017-02-24 08:01:26 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:01:26 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:01:26 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:01:26 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/category/category_list.php
DEBUG - 2017-02-24 08:01:26 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:01:26 --> Final output sent to browser
DEBUG - 2017-02-24 08:01:26 --> Total execution time: 0.1815
INFO - 2017-02-24 08:01:27 --> Config Class Initialized
INFO - 2017-02-24 08:01:27 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:01:27 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:01:27 --> Utf8 Class Initialized
INFO - 2017-02-24 08:01:27 --> URI Class Initialized
INFO - 2017-02-24 08:01:27 --> Router Class Initialized
INFO - 2017-02-24 08:01:27 --> Output Class Initialized
INFO - 2017-02-24 08:01:27 --> Security Class Initialized
DEBUG - 2017-02-24 08:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:01:27 --> Input Class Initialized
INFO - 2017-02-24 08:01:27 --> Language Class Initialized
INFO - 2017-02-24 08:01:27 --> Language Class Initialized
INFO - 2017-02-24 08:01:27 --> Config Class Initialized
INFO - 2017-02-24 08:01:27 --> Loader Class Initialized
INFO - 2017-02-24 08:01:27 --> Helper loaded: form_helper
INFO - 2017-02-24 08:01:27 --> Helper loaded: url_helper
INFO - 2017-02-24 08:01:27 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:01:27 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:01:27 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:01:27 --> Template Class Initialized
INFO - 2017-02-24 08:01:27 --> Controller Class Initialized
INFO - 2017-02-24 08:01:27 --> Model Class Initialized
INFO - 2017-02-24 08:01:27 --> Model Class Initialized
DEBUG - 2017-02-24 08:01:27 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:01:27 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:01:27 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:01:27 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/blog/blog_list.php
DEBUG - 2017-02-24 08:01:27 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:01:27 --> Final output sent to browser
DEBUG - 2017-02-24 08:01:27 --> Total execution time: 0.0434
INFO - 2017-02-24 08:01:28 --> Config Class Initialized
INFO - 2017-02-24 08:01:28 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:01:28 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:01:28 --> Utf8 Class Initialized
INFO - 2017-02-24 08:01:28 --> URI Class Initialized
INFO - 2017-02-24 08:01:28 --> Router Class Initialized
INFO - 2017-02-24 08:01:28 --> Output Class Initialized
INFO - 2017-02-24 08:01:28 --> Security Class Initialized
DEBUG - 2017-02-24 08:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:01:28 --> Input Class Initialized
INFO - 2017-02-24 08:01:28 --> Language Class Initialized
INFO - 2017-02-24 08:01:28 --> Language Class Initialized
INFO - 2017-02-24 08:01:28 --> Config Class Initialized
INFO - 2017-02-24 08:01:28 --> Loader Class Initialized
INFO - 2017-02-24 08:01:28 --> Helper loaded: form_helper
INFO - 2017-02-24 08:01:28 --> Helper loaded: url_helper
INFO - 2017-02-24 08:01:28 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:01:28 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:01:28 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:01:28 --> Template Class Initialized
INFO - 2017-02-24 08:01:28 --> Controller Class Initialized
INFO - 2017-02-24 08:01:28 --> Model Class Initialized
INFO - 2017-02-24 08:01:28 --> Model Class Initialized
DEBUG - 2017-02-24 08:01:28 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:01:28 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:01:28 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:01:29 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/blog/blog_add.php
DEBUG - 2017-02-24 08:01:29 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:01:29 --> Final output sent to browser
DEBUG - 2017-02-24 08:01:29 --> Total execution time: 0.3414
INFO - 2017-02-24 08:01:33 --> Config Class Initialized
INFO - 2017-02-24 08:01:33 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:01:33 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:01:33 --> Utf8 Class Initialized
INFO - 2017-02-24 08:01:33 --> URI Class Initialized
INFO - 2017-02-24 08:01:33 --> Router Class Initialized
INFO - 2017-02-24 08:01:33 --> Output Class Initialized
INFO - 2017-02-24 08:01:33 --> Security Class Initialized
DEBUG - 2017-02-24 08:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:01:33 --> Input Class Initialized
INFO - 2017-02-24 08:01:33 --> Language Class Initialized
INFO - 2017-02-24 08:01:33 --> Language Class Initialized
INFO - 2017-02-24 08:01:33 --> Config Class Initialized
INFO - 2017-02-24 08:01:33 --> Loader Class Initialized
INFO - 2017-02-24 08:01:33 --> Helper loaded: form_helper
INFO - 2017-02-24 08:01:33 --> Helper loaded: url_helper
INFO - 2017-02-24 08:01:33 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:01:33 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:01:33 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:01:33 --> Template Class Initialized
INFO - 2017-02-24 08:01:33 --> Controller Class Initialized
INFO - 2017-02-24 08:01:33 --> Model Class Initialized
INFO - 2017-02-24 08:01:33 --> Model Class Initialized
DEBUG - 2017-02-24 08:01:33 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:01:33 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:01:33 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:01:33 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/blog/blog_list.php
DEBUG - 2017-02-24 08:01:33 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:01:33 --> Final output sent to browser
DEBUG - 2017-02-24 08:01:33 --> Total execution time: 0.1016
INFO - 2017-02-24 08:01:35 --> Config Class Initialized
INFO - 2017-02-24 08:01:35 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:01:35 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:01:35 --> Utf8 Class Initialized
INFO - 2017-02-24 08:01:35 --> URI Class Initialized
INFO - 2017-02-24 08:01:35 --> Router Class Initialized
INFO - 2017-02-24 08:01:35 --> Output Class Initialized
INFO - 2017-02-24 08:01:35 --> Security Class Initialized
DEBUG - 2017-02-24 08:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:01:35 --> Input Class Initialized
INFO - 2017-02-24 08:01:35 --> Language Class Initialized
INFO - 2017-02-24 08:01:35 --> Language Class Initialized
INFO - 2017-02-24 08:01:35 --> Config Class Initialized
INFO - 2017-02-24 08:01:35 --> Loader Class Initialized
INFO - 2017-02-24 08:01:35 --> Helper loaded: form_helper
INFO - 2017-02-24 08:01:35 --> Helper loaded: url_helper
INFO - 2017-02-24 08:01:35 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:01:35 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:01:35 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:01:35 --> Template Class Initialized
INFO - 2017-02-24 08:01:35 --> Controller Class Initialized
INFO - 2017-02-24 08:01:35 --> Model Class Initialized
INFO - 2017-02-24 08:01:35 --> Model Class Initialized
DEBUG - 2017-02-24 08:01:35 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:01:35 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:01:35 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:01:35 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/blog/blog_edit.php
DEBUG - 2017-02-24 08:01:35 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:01:35 --> Final output sent to browser
DEBUG - 2017-02-24 08:01:35 --> Total execution time: 0.4068
INFO - 2017-02-24 08:01:35 --> Config Class Initialized
INFO - 2017-02-24 08:01:35 --> Hooks Class Initialized
INFO - 2017-02-24 08:01:35 --> Config Class Initialized
INFO - 2017-02-24 08:01:35 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:01:35 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:01:35 --> Utf8 Class Initialized
DEBUG - 2017-02-24 08:01:35 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:01:35 --> Utf8 Class Initialized
INFO - 2017-02-24 08:01:35 --> URI Class Initialized
INFO - 2017-02-24 08:01:35 --> URI Class Initialized
INFO - 2017-02-24 08:01:35 --> Router Class Initialized
INFO - 2017-02-24 08:01:35 --> Output Class Initialized
INFO - 2017-02-24 08:01:35 --> Security Class Initialized
DEBUG - 2017-02-24 08:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:01:35 --> Input Class Initialized
INFO - 2017-02-24 08:01:35 --> Language Class Initialized
ERROR - 2017-02-24 08:01:35 --> 404 Page Not Found: /index
INFO - 2017-02-24 08:01:35 --> Router Class Initialized
INFO - 2017-02-24 08:01:35 --> Output Class Initialized
INFO - 2017-02-24 08:01:35 --> Security Class Initialized
DEBUG - 2017-02-24 08:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:01:35 --> Input Class Initialized
INFO - 2017-02-24 08:01:35 --> Language Class Initialized
ERROR - 2017-02-24 08:01:35 --> 404 Page Not Found: /index
INFO - 2017-02-24 08:01:38 --> Config Class Initialized
INFO - 2017-02-24 08:01:38 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:01:38 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:01:38 --> Utf8 Class Initialized
INFO - 2017-02-24 08:01:38 --> URI Class Initialized
INFO - 2017-02-24 08:01:38 --> Router Class Initialized
INFO - 2017-02-24 08:01:38 --> Output Class Initialized
INFO - 2017-02-24 08:01:38 --> Security Class Initialized
DEBUG - 2017-02-24 08:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:01:38 --> Input Class Initialized
INFO - 2017-02-24 08:01:38 --> Language Class Initialized
INFO - 2017-02-24 08:01:38 --> Language Class Initialized
INFO - 2017-02-24 08:01:38 --> Config Class Initialized
INFO - 2017-02-24 08:01:38 --> Loader Class Initialized
INFO - 2017-02-24 08:01:38 --> Helper loaded: form_helper
INFO - 2017-02-24 08:01:38 --> Helper loaded: url_helper
INFO - 2017-02-24 08:01:38 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:01:38 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:01:38 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:01:38 --> Template Class Initialized
INFO - 2017-02-24 08:01:38 --> Controller Class Initialized
INFO - 2017-02-24 08:01:38 --> Model Class Initialized
INFO - 2017-02-24 08:01:38 --> Model Class Initialized
DEBUG - 2017-02-24 08:01:38 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:01:38 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:01:38 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:01:38 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/blog/blog_list.php
DEBUG - 2017-02-24 08:01:38 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:01:38 --> Final output sent to browser
DEBUG - 2017-02-24 08:01:38 --> Total execution time: 0.0652
INFO - 2017-02-24 08:01:39 --> Config Class Initialized
INFO - 2017-02-24 08:01:39 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:01:39 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:01:39 --> Utf8 Class Initialized
INFO - 2017-02-24 08:01:39 --> URI Class Initialized
INFO - 2017-02-24 08:01:39 --> Router Class Initialized
INFO - 2017-02-24 08:01:39 --> Output Class Initialized
INFO - 2017-02-24 08:01:39 --> Security Class Initialized
DEBUG - 2017-02-24 08:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:01:39 --> Input Class Initialized
INFO - 2017-02-24 08:01:39 --> Language Class Initialized
INFO - 2017-02-24 08:01:39 --> Language Class Initialized
INFO - 2017-02-24 08:01:39 --> Config Class Initialized
INFO - 2017-02-24 08:01:39 --> Loader Class Initialized
INFO - 2017-02-24 08:01:39 --> Helper loaded: form_helper
INFO - 2017-02-24 08:01:39 --> Helper loaded: url_helper
INFO - 2017-02-24 08:01:39 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:01:39 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:01:39 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:01:39 --> Template Class Initialized
INFO - 2017-02-24 08:01:39 --> Controller Class Initialized
INFO - 2017-02-24 08:01:39 --> Model Class Initialized
INFO - 2017-02-24 08:01:39 --> Model Class Initialized
DEBUG - 2017-02-24 08:01:39 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:01:39 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:01:39 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:01:40 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/blog/comment_list.php
DEBUG - 2017-02-24 08:01:40 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:01:40 --> Final output sent to browser
DEBUG - 2017-02-24 08:01:40 --> Total execution time: 0.9836
INFO - 2017-02-24 08:01:40 --> Config Class Initialized
INFO - 2017-02-24 08:01:40 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:01:40 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:01:40 --> Utf8 Class Initialized
INFO - 2017-02-24 08:01:40 --> URI Class Initialized
INFO - 2017-02-24 08:01:40 --> Router Class Initialized
INFO - 2017-02-24 08:01:40 --> Output Class Initialized
INFO - 2017-02-24 08:01:40 --> Security Class Initialized
DEBUG - 2017-02-24 08:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:01:40 --> Input Class Initialized
INFO - 2017-02-24 08:01:40 --> Language Class Initialized
ERROR - 2017-02-24 08:01:40 --> 404 Page Not Found: /index
INFO - 2017-02-24 08:01:43 --> Config Class Initialized
INFO - 2017-02-24 08:01:43 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:01:43 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:01:43 --> Utf8 Class Initialized
INFO - 2017-02-24 08:01:43 --> URI Class Initialized
INFO - 2017-02-24 08:01:43 --> Router Class Initialized
INFO - 2017-02-24 08:01:43 --> Output Class Initialized
INFO - 2017-02-24 08:01:43 --> Security Class Initialized
DEBUG - 2017-02-24 08:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:01:43 --> Input Class Initialized
INFO - 2017-02-24 08:01:43 --> Language Class Initialized
INFO - 2017-02-24 08:01:43 --> Language Class Initialized
INFO - 2017-02-24 08:01:43 --> Config Class Initialized
INFO - 2017-02-24 08:01:43 --> Loader Class Initialized
INFO - 2017-02-24 08:01:43 --> Helper loaded: form_helper
INFO - 2017-02-24 08:01:43 --> Helper loaded: url_helper
INFO - 2017-02-24 08:01:43 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:01:43 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:01:43 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:01:43 --> Template Class Initialized
INFO - 2017-02-24 08:01:43 --> Controller Class Initialized
INFO - 2017-02-24 08:01:43 --> Model Class Initialized
INFO - 2017-02-24 08:01:43 --> Model Class Initialized
DEBUG - 2017-02-24 08:01:43 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:01:43 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:01:43 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:01:43 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/blog/blog_list.php
DEBUG - 2017-02-24 08:01:43 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:01:43 --> Final output sent to browser
DEBUG - 2017-02-24 08:01:43 --> Total execution time: 0.0623
INFO - 2017-02-24 08:02:07 --> Config Class Initialized
INFO - 2017-02-24 08:02:07 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:02:07 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:02:07 --> Utf8 Class Initialized
INFO - 2017-02-24 08:02:07 --> URI Class Initialized
INFO - 2017-02-24 08:02:07 --> Router Class Initialized
INFO - 2017-02-24 08:02:07 --> Output Class Initialized
INFO - 2017-02-24 08:02:07 --> Security Class Initialized
DEBUG - 2017-02-24 08:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:02:07 --> Input Class Initialized
INFO - 2017-02-24 08:02:07 --> Language Class Initialized
INFO - 2017-02-24 08:02:07 --> Language Class Initialized
INFO - 2017-02-24 08:02:07 --> Config Class Initialized
INFO - 2017-02-24 08:02:07 --> Loader Class Initialized
INFO - 2017-02-24 08:02:07 --> Helper loaded: form_helper
INFO - 2017-02-24 08:02:07 --> Helper loaded: url_helper
INFO - 2017-02-24 08:02:07 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:02:07 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:02:07 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:02:07 --> Template Class Initialized
INFO - 2017-02-24 08:02:07 --> Controller Class Initialized
INFO - 2017-02-24 08:02:07 --> Model Class Initialized
INFO - 2017-02-24 08:02:07 --> Model Class Initialized
DEBUG - 2017-02-24 08:02:07 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:02:07 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:02:07 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:02:07 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/blog/blog_list.php
DEBUG - 2017-02-24 08:02:07 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:02:07 --> Final output sent to browser
DEBUG - 2017-02-24 08:02:07 --> Total execution time: 0.0627
INFO - 2017-02-24 08:02:09 --> Config Class Initialized
INFO - 2017-02-24 08:02:09 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:02:09 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:02:09 --> Utf8 Class Initialized
INFO - 2017-02-24 08:02:09 --> URI Class Initialized
INFO - 2017-02-24 08:02:09 --> Router Class Initialized
INFO - 2017-02-24 08:02:09 --> Output Class Initialized
INFO - 2017-02-24 08:02:09 --> Security Class Initialized
DEBUG - 2017-02-24 08:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:02:09 --> Input Class Initialized
INFO - 2017-02-24 08:02:09 --> Language Class Initialized
INFO - 2017-02-24 08:02:09 --> Language Class Initialized
INFO - 2017-02-24 08:02:09 --> Config Class Initialized
INFO - 2017-02-24 08:02:09 --> Loader Class Initialized
INFO - 2017-02-24 08:02:09 --> Helper loaded: form_helper
INFO - 2017-02-24 08:02:09 --> Helper loaded: url_helper
INFO - 2017-02-24 08:02:09 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:02:09 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:02:09 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:02:09 --> Template Class Initialized
INFO - 2017-02-24 08:02:09 --> Controller Class Initialized
DEBUG - 2017-02-24 08:02:09 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-24 08:02:09 --> Model Class Initialized
INFO - 2017-02-24 08:02:09 --> Model Class Initialized
DEBUG - 2017-02-24 08:02:09 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:02:09 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:02:09 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:02:09 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/global-setting/globle_setting_list.php
DEBUG - 2017-02-24 08:02:09 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:02:09 --> Final output sent to browser
DEBUG - 2017-02-24 08:02:09 --> Total execution time: 0.0423
INFO - 2017-02-24 08:02:12 --> Config Class Initialized
INFO - 2017-02-24 08:02:12 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:02:12 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:02:12 --> Utf8 Class Initialized
INFO - 2017-02-24 08:02:12 --> URI Class Initialized
INFO - 2017-02-24 08:02:12 --> Router Class Initialized
INFO - 2017-02-24 08:02:12 --> Output Class Initialized
INFO - 2017-02-24 08:02:12 --> Security Class Initialized
DEBUG - 2017-02-24 08:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:02:12 --> Input Class Initialized
INFO - 2017-02-24 08:02:12 --> Language Class Initialized
INFO - 2017-02-24 08:02:12 --> Language Class Initialized
INFO - 2017-02-24 08:02:12 --> Config Class Initialized
INFO - 2017-02-24 08:02:12 --> Loader Class Initialized
INFO - 2017-02-24 08:02:12 --> Helper loaded: form_helper
INFO - 2017-02-24 08:02:12 --> Helper loaded: url_helper
INFO - 2017-02-24 08:02:12 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:02:12 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:02:12 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:02:12 --> Template Class Initialized
INFO - 2017-02-24 08:02:12 --> Controller Class Initialized
DEBUG - 2017-02-24 08:02:12 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 08:02:12 --> Helper loaded: cookie_helper
INFO - 2017-02-24 08:02:12 --> Model Class Initialized
DEBUG - 2017-02-24 08:02:12 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:02:12 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:02:12 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:02:12 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 08:02:12 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:02:12 --> Final output sent to browser
DEBUG - 2017-02-24 08:02:12 --> Total execution time: 0.0421
INFO - 2017-02-24 08:02:15 --> Config Class Initialized
INFO - 2017-02-24 08:02:15 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:02:15 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:02:15 --> Utf8 Class Initialized
INFO - 2017-02-24 08:02:15 --> URI Class Initialized
INFO - 2017-02-24 08:02:15 --> Router Class Initialized
INFO - 2017-02-24 08:02:15 --> Output Class Initialized
INFO - 2017-02-24 08:02:15 --> Security Class Initialized
DEBUG - 2017-02-24 08:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:02:15 --> Input Class Initialized
INFO - 2017-02-24 08:02:15 --> Language Class Initialized
INFO - 2017-02-24 08:02:15 --> Language Class Initialized
INFO - 2017-02-24 08:02:15 --> Config Class Initialized
INFO - 2017-02-24 08:02:15 --> Loader Class Initialized
INFO - 2017-02-24 08:02:15 --> Helper loaded: form_helper
INFO - 2017-02-24 08:02:15 --> Helper loaded: url_helper
INFO - 2017-02-24 08:02:15 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:02:15 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:02:15 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:02:15 --> Template Class Initialized
INFO - 2017-02-24 08:02:15 --> Controller Class Initialized
INFO - 2017-02-24 08:02:15 --> Model Class Initialized
INFO - 2017-02-24 08:02:15 --> Model Class Initialized
DEBUG - 2017-02-24 08:02:15 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:02:15 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:02:15 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:02:15 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/category/category_list.php
DEBUG - 2017-02-24 08:02:15 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:02:15 --> Final output sent to browser
DEBUG - 2017-02-24 08:02:15 --> Total execution time: 0.0447
INFO - 2017-02-24 08:03:06 --> Config Class Initialized
INFO - 2017-02-24 08:03:06 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:03:06 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:03:06 --> Utf8 Class Initialized
INFO - 2017-02-24 08:03:06 --> URI Class Initialized
INFO - 2017-02-24 08:03:06 --> Router Class Initialized
INFO - 2017-02-24 08:03:06 --> Output Class Initialized
INFO - 2017-02-24 08:03:06 --> Security Class Initialized
DEBUG - 2017-02-24 08:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:03:06 --> Input Class Initialized
INFO - 2017-02-24 08:03:06 --> Language Class Initialized
INFO - 2017-02-24 08:03:06 --> Language Class Initialized
INFO - 2017-02-24 08:03:06 --> Config Class Initialized
INFO - 2017-02-24 08:03:06 --> Loader Class Initialized
INFO - 2017-02-24 08:03:06 --> Helper loaded: form_helper
INFO - 2017-02-24 08:03:06 --> Helper loaded: url_helper
INFO - 2017-02-24 08:03:06 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:03:06 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:03:06 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:03:06 --> Template Class Initialized
INFO - 2017-02-24 08:03:06 --> Controller Class Initialized
INFO - 2017-02-24 08:03:06 --> Model Class Initialized
INFO - 2017-02-24 08:03:06 --> Model Class Initialized
ERROR - 2017-02-24 08:03:06 --> Severity: Notice --> Undefined property: Category::$global_setting C:\xampp\htdocs\silo\application\modules\backend\controllers\Category.php 55
DEBUG - 2017-02-24 08:03:06 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:03:06 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:03:06 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:03:06 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/category/category_list.php
DEBUG - 2017-02-24 08:03:06 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:03:06 --> Final output sent to browser
DEBUG - 2017-02-24 08:03:06 --> Total execution time: 0.0856
INFO - 2017-02-24 08:03:23 --> Config Class Initialized
INFO - 2017-02-24 08:03:23 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:03:23 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:03:23 --> Utf8 Class Initialized
INFO - 2017-02-24 08:03:23 --> URI Class Initialized
INFO - 2017-02-24 08:03:23 --> Router Class Initialized
INFO - 2017-02-24 08:03:23 --> Output Class Initialized
INFO - 2017-02-24 08:03:23 --> Security Class Initialized
DEBUG - 2017-02-24 08:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:03:23 --> Input Class Initialized
INFO - 2017-02-24 08:03:23 --> Language Class Initialized
INFO - 2017-02-24 08:03:23 --> Language Class Initialized
INFO - 2017-02-24 08:03:23 --> Config Class Initialized
INFO - 2017-02-24 08:03:23 --> Loader Class Initialized
INFO - 2017-02-24 08:03:23 --> Helper loaded: form_helper
INFO - 2017-02-24 08:03:23 --> Helper loaded: url_helper
INFO - 2017-02-24 08:03:23 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:03:23 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:03:23 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:03:23 --> Template Class Initialized
INFO - 2017-02-24 08:03:23 --> Controller Class Initialized
INFO - 2017-02-24 08:03:23 --> Model Class Initialized
INFO - 2017-02-24 08:03:23 --> Model Class Initialized
DEBUG - 2017-02-24 08:03:23 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:03:23 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:03:23 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:03:23 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/category/category_list.php
DEBUG - 2017-02-24 08:03:23 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:03:23 --> Final output sent to browser
DEBUG - 2017-02-24 08:03:23 --> Total execution time: 0.0738
INFO - 2017-02-24 08:04:03 --> Config Class Initialized
INFO - 2017-02-24 08:04:03 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:04:03 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:04:03 --> Utf8 Class Initialized
INFO - 2017-02-24 08:04:03 --> URI Class Initialized
INFO - 2017-02-24 08:04:03 --> Router Class Initialized
INFO - 2017-02-24 08:04:03 --> Output Class Initialized
INFO - 2017-02-24 08:04:03 --> Security Class Initialized
DEBUG - 2017-02-24 08:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:04:03 --> Input Class Initialized
INFO - 2017-02-24 08:04:03 --> Language Class Initialized
INFO - 2017-02-24 08:04:03 --> Language Class Initialized
INFO - 2017-02-24 08:04:03 --> Config Class Initialized
INFO - 2017-02-24 08:04:03 --> Loader Class Initialized
INFO - 2017-02-24 08:04:03 --> Helper loaded: form_helper
INFO - 2017-02-24 08:04:03 --> Helper loaded: url_helper
INFO - 2017-02-24 08:04:03 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:04:03 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:04:03 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:04:03 --> Template Class Initialized
INFO - 2017-02-24 08:04:03 --> Model Class Initialized
INFO - 2017-02-24 08:04:03 --> Controller Class Initialized
INFO - 2017-02-24 08:04:03 --> Model Class Initialized
DEBUG - 2017-02-24 08:04:03 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:04:03 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:04:03 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:04:03 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/category/category_list.php
DEBUG - 2017-02-24 08:04:03 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:04:03 --> Final output sent to browser
DEBUG - 2017-02-24 08:04:03 --> Total execution time: 0.0795
INFO - 2017-02-24 08:04:07 --> Config Class Initialized
INFO - 2017-02-24 08:04:07 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:04:07 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:04:07 --> Utf8 Class Initialized
INFO - 2017-02-24 08:04:07 --> URI Class Initialized
INFO - 2017-02-24 08:04:07 --> Router Class Initialized
INFO - 2017-02-24 08:04:07 --> Output Class Initialized
INFO - 2017-02-24 08:04:07 --> Security Class Initialized
DEBUG - 2017-02-24 08:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:04:07 --> Input Class Initialized
INFO - 2017-02-24 08:04:07 --> Language Class Initialized
INFO - 2017-02-24 08:04:07 --> Language Class Initialized
INFO - 2017-02-24 08:04:07 --> Config Class Initialized
INFO - 2017-02-24 08:04:07 --> Loader Class Initialized
INFO - 2017-02-24 08:04:07 --> Helper loaded: form_helper
INFO - 2017-02-24 08:04:07 --> Helper loaded: url_helper
INFO - 2017-02-24 08:04:07 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:04:07 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:04:07 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:04:07 --> Template Class Initialized
INFO - 2017-02-24 08:04:07 --> Model Class Initialized
INFO - 2017-02-24 08:04:07 --> Controller Class Initialized
DEBUG - 2017-02-24 08:04:07 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-24 08:04:07 --> Model Class Initialized
DEBUG - 2017-02-24 08:04:07 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:04:07 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:04:07 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:04:07 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/global-setting/globle_setting_list.php
DEBUG - 2017-02-24 08:04:07 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:04:07 --> Final output sent to browser
DEBUG - 2017-02-24 08:04:07 --> Total execution time: 0.0501
INFO - 2017-02-24 08:04:08 --> Config Class Initialized
INFO - 2017-02-24 08:04:08 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:04:08 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:04:08 --> Utf8 Class Initialized
INFO - 2017-02-24 08:04:08 --> URI Class Initialized
INFO - 2017-02-24 08:04:08 --> Router Class Initialized
INFO - 2017-02-24 08:04:08 --> Output Class Initialized
INFO - 2017-02-24 08:04:08 --> Security Class Initialized
DEBUG - 2017-02-24 08:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:04:08 --> Input Class Initialized
INFO - 2017-02-24 08:04:08 --> Language Class Initialized
INFO - 2017-02-24 08:04:08 --> Language Class Initialized
INFO - 2017-02-24 08:04:08 --> Config Class Initialized
INFO - 2017-02-24 08:04:08 --> Loader Class Initialized
INFO - 2017-02-24 08:04:08 --> Helper loaded: form_helper
INFO - 2017-02-24 08:04:08 --> Helper loaded: url_helper
INFO - 2017-02-24 08:04:08 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:04:08 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:04:08 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:04:08 --> Template Class Initialized
INFO - 2017-02-24 08:04:08 --> Model Class Initialized
INFO - 2017-02-24 08:04:08 --> Controller Class Initialized
DEBUG - 2017-02-24 08:04:08 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 08:04:08 --> Helper loaded: cookie_helper
DEBUG - 2017-02-24 08:04:08 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:04:08 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:04:08 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:04:08 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 08:04:08 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:04:08 --> Final output sent to browser
DEBUG - 2017-02-24 08:04:08 --> Total execution time: 0.0420
INFO - 2017-02-24 08:05:08 --> Config Class Initialized
INFO - 2017-02-24 08:05:08 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:05:08 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:05:08 --> Utf8 Class Initialized
INFO - 2017-02-24 08:05:08 --> URI Class Initialized
INFO - 2017-02-24 08:05:08 --> Router Class Initialized
INFO - 2017-02-24 08:05:08 --> Output Class Initialized
INFO - 2017-02-24 08:05:08 --> Security Class Initialized
DEBUG - 2017-02-24 08:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:05:08 --> Input Class Initialized
INFO - 2017-02-24 08:05:08 --> Language Class Initialized
INFO - 2017-02-24 08:05:08 --> Language Class Initialized
INFO - 2017-02-24 08:05:08 --> Config Class Initialized
INFO - 2017-02-24 08:05:08 --> Loader Class Initialized
INFO - 2017-02-24 08:05:08 --> Helper loaded: form_helper
INFO - 2017-02-24 08:05:08 --> Helper loaded: url_helper
INFO - 2017-02-24 08:05:08 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:05:08 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:05:08 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:05:08 --> Template Class Initialized
INFO - 2017-02-24 08:05:08 --> Model Class Initialized
INFO - 2017-02-24 08:05:08 --> Controller Class Initialized
DEBUG - 2017-02-24 08:05:08 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 08:05:08 --> Helper loaded: cookie_helper
DEBUG - 2017-02-24 08:05:08 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:05:08 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:05:08 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:05:08 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 08:05:08 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:05:08 --> Final output sent to browser
DEBUG - 2017-02-24 08:05:08 --> Total execution time: 0.0482
INFO - 2017-02-24 08:05:53 --> Config Class Initialized
INFO - 2017-02-24 08:05:53 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:05:53 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:05:53 --> Utf8 Class Initialized
INFO - 2017-02-24 08:05:53 --> URI Class Initialized
INFO - 2017-02-24 08:05:53 --> Router Class Initialized
INFO - 2017-02-24 08:05:53 --> Output Class Initialized
INFO - 2017-02-24 08:05:53 --> Security Class Initialized
DEBUG - 2017-02-24 08:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:05:53 --> Input Class Initialized
INFO - 2017-02-24 08:05:53 --> Language Class Initialized
ERROR - 2017-02-24 08:05:53 --> 404 Page Not Found: /index
INFO - 2017-02-24 08:06:17 --> Config Class Initialized
INFO - 2017-02-24 08:06:17 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:06:17 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:06:17 --> Utf8 Class Initialized
INFO - 2017-02-24 08:06:17 --> URI Class Initialized
INFO - 2017-02-24 08:06:17 --> Router Class Initialized
INFO - 2017-02-24 08:06:17 --> Output Class Initialized
INFO - 2017-02-24 08:06:17 --> Security Class Initialized
DEBUG - 2017-02-24 08:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:06:17 --> Input Class Initialized
INFO - 2017-02-24 08:06:17 --> Language Class Initialized
INFO - 2017-02-24 08:06:17 --> Language Class Initialized
INFO - 2017-02-24 08:06:17 --> Config Class Initialized
INFO - 2017-02-24 08:06:17 --> Loader Class Initialized
INFO - 2017-02-24 08:06:17 --> Helper loaded: form_helper
INFO - 2017-02-24 08:06:17 --> Helper loaded: url_helper
INFO - 2017-02-24 08:06:17 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:06:17 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:06:17 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:06:17 --> Template Class Initialized
INFO - 2017-02-24 08:06:17 --> Model Class Initialized
INFO - 2017-02-24 08:06:17 --> Controller Class Initialized
DEBUG - 2017-02-24 08:06:17 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 08:06:17 --> Helper loaded: cookie_helper
DEBUG - 2017-02-24 08:06:17 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:06:17 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:06:17 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:06:17 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 08:06:17 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:06:17 --> Final output sent to browser
DEBUG - 2017-02-24 08:06:17 --> Total execution time: 0.0912
INFO - 2017-02-24 08:09:43 --> Config Class Initialized
INFO - 2017-02-24 08:09:43 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:09:43 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:09:43 --> Utf8 Class Initialized
INFO - 2017-02-24 08:09:43 --> URI Class Initialized
INFO - 2017-02-24 08:09:43 --> Router Class Initialized
INFO - 2017-02-24 08:09:43 --> Output Class Initialized
INFO - 2017-02-24 08:09:43 --> Security Class Initialized
DEBUG - 2017-02-24 08:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:09:43 --> Input Class Initialized
INFO - 2017-02-24 08:09:43 --> Language Class Initialized
INFO - 2017-02-24 08:09:43 --> Language Class Initialized
INFO - 2017-02-24 08:09:43 --> Config Class Initialized
INFO - 2017-02-24 08:09:43 --> Loader Class Initialized
INFO - 2017-02-24 08:09:43 --> Helper loaded: form_helper
INFO - 2017-02-24 08:09:43 --> Helper loaded: url_helper
INFO - 2017-02-24 08:09:43 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:09:43 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:09:43 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:09:43 --> Template Class Initialized
INFO - 2017-02-24 08:09:43 --> Model Class Initialized
INFO - 2017-02-24 08:09:43 --> Controller Class Initialized
DEBUG - 2017-02-24 08:09:43 --> Login MX_Controller Initialized
INFO - 2017-02-24 08:09:43 --> Helper loaded: cookie_helper
INFO - 2017-02-24 08:09:44 --> Form Validation Class Initialized
DEBUG - 2017-02-24 08:09:44 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/login.php
INFO - 2017-02-24 08:09:44 --> Final output sent to browser
DEBUG - 2017-02-24 08:09:44 --> Total execution time: 0.1909
INFO - 2017-02-24 08:10:56 --> Config Class Initialized
INFO - 2017-02-24 08:10:56 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:10:56 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:10:56 --> Utf8 Class Initialized
INFO - 2017-02-24 08:10:56 --> URI Class Initialized
DEBUG - 2017-02-24 08:10:56 --> No URI present. Default controller set.
INFO - 2017-02-24 08:10:56 --> Router Class Initialized
INFO - 2017-02-24 08:10:56 --> Output Class Initialized
INFO - 2017-02-24 08:10:56 --> Security Class Initialized
DEBUG - 2017-02-24 08:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:10:56 --> Input Class Initialized
INFO - 2017-02-24 08:10:56 --> Language Class Initialized
INFO - 2017-02-24 08:10:56 --> Language Class Initialized
INFO - 2017-02-24 08:10:56 --> Config Class Initialized
INFO - 2017-02-24 08:10:56 --> Loader Class Initialized
INFO - 2017-02-24 08:10:56 --> Helper loaded: form_helper
INFO - 2017-02-24 08:10:56 --> Helper loaded: url_helper
INFO - 2017-02-24 08:10:56 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:10:56 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:10:56 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:10:56 --> Template Class Initialized
INFO - 2017-02-24 08:10:56 --> Model Class Initialized
INFO - 2017-02-24 08:10:56 --> Controller Class Initialized
DEBUG - 2017-02-24 08:10:56 --> Login MX_Controller Initialized
INFO - 2017-02-24 08:10:56 --> Helper loaded: cookie_helper
INFO - 2017-02-24 08:10:56 --> Form Validation Class Initialized
DEBUG - 2017-02-24 08:10:56 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/login.php
INFO - 2017-02-24 08:10:56 --> Final output sent to browser
DEBUG - 2017-02-24 08:10:56 --> Total execution time: 0.0419
INFO - 2017-02-24 08:11:30 --> Config Class Initialized
INFO - 2017-02-24 08:11:30 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:11:30 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:11:30 --> Utf8 Class Initialized
INFO - 2017-02-24 08:11:30 --> URI Class Initialized
DEBUG - 2017-02-24 08:11:30 --> No URI present. Default controller set.
INFO - 2017-02-24 08:11:30 --> Router Class Initialized
INFO - 2017-02-24 08:11:30 --> Output Class Initialized
INFO - 2017-02-24 08:11:30 --> Security Class Initialized
DEBUG - 2017-02-24 08:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:11:30 --> Input Class Initialized
INFO - 2017-02-24 08:11:30 --> Language Class Initialized
INFO - 2017-02-24 08:11:30 --> Language Class Initialized
INFO - 2017-02-24 08:11:30 --> Config Class Initialized
INFO - 2017-02-24 08:11:30 --> Loader Class Initialized
INFO - 2017-02-24 08:11:30 --> Helper loaded: form_helper
INFO - 2017-02-24 08:11:30 --> Helper loaded: url_helper
INFO - 2017-02-24 08:11:30 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:11:30 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:11:30 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:11:30 --> Template Class Initialized
INFO - 2017-02-24 08:11:30 --> Model Class Initialized
INFO - 2017-02-24 08:11:30 --> Controller Class Initialized
DEBUG - 2017-02-24 08:11:30 --> Login MX_Controller Initialized
INFO - 2017-02-24 08:11:30 --> Helper loaded: cookie_helper
INFO - 2017-02-24 08:11:30 --> Form Validation Class Initialized
DEBUG - 2017-02-24 08:11:30 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/login.php
INFO - 2017-02-24 08:11:30 --> Final output sent to browser
DEBUG - 2017-02-24 08:11:30 --> Total execution time: 0.0611
INFO - 2017-02-24 08:11:31 --> Config Class Initialized
INFO - 2017-02-24 08:11:31 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:11:31 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:11:31 --> Utf8 Class Initialized
INFO - 2017-02-24 08:11:31 --> URI Class Initialized
INFO - 2017-02-24 08:11:31 --> Router Class Initialized
INFO - 2017-02-24 08:11:31 --> Output Class Initialized
INFO - 2017-02-24 08:11:31 --> Security Class Initialized
DEBUG - 2017-02-24 08:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:11:31 --> Input Class Initialized
INFO - 2017-02-24 08:11:31 --> Language Class Initialized
INFO - 2017-02-24 08:11:31 --> Language Class Initialized
INFO - 2017-02-24 08:11:31 --> Config Class Initialized
INFO - 2017-02-24 08:11:31 --> Loader Class Initialized
INFO - 2017-02-24 08:11:31 --> Helper loaded: form_helper
INFO - 2017-02-24 08:11:31 --> Helper loaded: url_helper
INFO - 2017-02-24 08:11:31 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:11:31 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:11:31 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:11:31 --> Template Class Initialized
INFO - 2017-02-24 08:11:31 --> Model Class Initialized
INFO - 2017-02-24 08:11:31 --> Controller Class Initialized
DEBUG - 2017-02-24 08:11:31 --> Login MX_Controller Initialized
INFO - 2017-02-24 08:11:31 --> Helper loaded: cookie_helper
INFO - 2017-02-24 08:11:31 --> Form Validation Class Initialized
INFO - 2017-02-24 08:11:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-24 08:11:32 --> Config Class Initialized
INFO - 2017-02-24 08:11:32 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:11:32 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:11:32 --> Utf8 Class Initialized
INFO - 2017-02-24 08:11:32 --> URI Class Initialized
INFO - 2017-02-24 08:11:32 --> Router Class Initialized
INFO - 2017-02-24 08:11:32 --> Output Class Initialized
INFO - 2017-02-24 08:11:32 --> Security Class Initialized
DEBUG - 2017-02-24 08:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:11:32 --> Input Class Initialized
INFO - 2017-02-24 08:11:32 --> Language Class Initialized
INFO - 2017-02-24 08:11:32 --> Language Class Initialized
INFO - 2017-02-24 08:11:32 --> Config Class Initialized
INFO - 2017-02-24 08:11:32 --> Loader Class Initialized
INFO - 2017-02-24 08:11:32 --> Helper loaded: form_helper
INFO - 2017-02-24 08:11:32 --> Helper loaded: url_helper
INFO - 2017-02-24 08:11:32 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:11:32 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:11:32 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:11:32 --> Template Class Initialized
INFO - 2017-02-24 08:11:32 --> Model Class Initialized
INFO - 2017-02-24 08:11:32 --> Controller Class Initialized
DEBUG - 2017-02-24 08:11:32 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 08:11:32 --> Helper loaded: cookie_helper
DEBUG - 2017-02-24 08:11:32 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:11:32 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:11:32 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:11:32 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 08:11:32 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:11:32 --> Final output sent to browser
DEBUG - 2017-02-24 08:11:32 --> Total execution time: 0.0852
INFO - 2017-02-24 08:11:41 --> Config Class Initialized
INFO - 2017-02-24 08:11:41 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:11:41 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:11:41 --> Utf8 Class Initialized
INFO - 2017-02-24 08:11:41 --> URI Class Initialized
INFO - 2017-02-24 08:11:41 --> Router Class Initialized
INFO - 2017-02-24 08:11:41 --> Output Class Initialized
INFO - 2017-02-24 08:11:41 --> Security Class Initialized
DEBUG - 2017-02-24 08:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:11:41 --> Input Class Initialized
INFO - 2017-02-24 08:11:41 --> Language Class Initialized
INFO - 2017-02-24 08:11:41 --> Language Class Initialized
INFO - 2017-02-24 08:11:41 --> Config Class Initialized
INFO - 2017-02-24 08:11:41 --> Loader Class Initialized
INFO - 2017-02-24 08:11:41 --> Helper loaded: form_helper
INFO - 2017-02-24 08:11:41 --> Helper loaded: url_helper
INFO - 2017-02-24 08:11:41 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:11:41 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:11:41 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:11:41 --> Template Class Initialized
INFO - 2017-02-24 08:11:41 --> Model Class Initialized
INFO - 2017-02-24 08:11:41 --> Controller Class Initialized
DEBUG - 2017-02-24 08:11:41 --> Dashboard MX_Controller Initialized
INFO - 2017-02-24 08:11:41 --> Helper loaded: cookie_helper
DEBUG - 2017-02-24 08:11:41 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-24 08:11:41 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-24 08:11:41 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-24 08:11:41 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-24 08:11:41 --> File loaded: C:\xampp\htdocs\silo\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-24 08:11:41 --> Final output sent to browser
DEBUG - 2017-02-24 08:11:41 --> Total execution time: 0.0470
INFO - 2017-02-24 08:24:34 --> Config Class Initialized
INFO - 2017-02-24 08:24:34 --> Hooks Class Initialized
DEBUG - 2017-02-24 08:24:35 --> UTF-8 Support Enabled
INFO - 2017-02-24 08:24:35 --> Utf8 Class Initialized
INFO - 2017-02-24 08:24:35 --> URI Class Initialized
INFO - 2017-02-24 08:24:35 --> Router Class Initialized
INFO - 2017-02-24 08:24:35 --> Output Class Initialized
INFO - 2017-02-24 08:24:35 --> Security Class Initialized
DEBUG - 2017-02-24 08:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-24 08:24:35 --> Input Class Initialized
INFO - 2017-02-24 08:24:35 --> Language Class Initialized
INFO - 2017-02-24 08:24:35 --> Language Class Initialized
INFO - 2017-02-24 08:24:35 --> Config Class Initialized
INFO - 2017-02-24 08:24:35 --> Loader Class Initialized
INFO - 2017-02-24 08:24:35 --> Helper loaded: form_helper
INFO - 2017-02-24 08:24:35 --> Helper loaded: url_helper
INFO - 2017-02-24 08:24:35 --> Helper loaded: utility_helper
INFO - 2017-02-24 08:24:35 --> Database Driver Class Initialized
DEBUG - 2017-02-24 08:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-24 08:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-24 08:24:35 --> User Agent Class Initialized
DEBUG - 2017-02-24 08:24:35 --> Template Class Initialized
INFO - 2017-02-24 08:24:35 --> Model Class Initialized
INFO - 2017-02-24 08:24:35 --> Controller Class Initialized
DEBUG - 2017-02-24 08:24:35 --> Login MX_Controller Initialized
INFO - 2017-02-24 08:24:35 --> Helper loaded: cookie_helper
INFO - 2017-02-24 08:24:35 --> Form Validation Class Initialized
DEBUG - 2017-02-24 08:24:35 --> File loaded: C:\xampp\htdocs\silo\application\modules/backend/views/login.php
INFO - 2017-02-24 08:24:35 --> Final output sent to browser
DEBUG - 2017-02-24 08:24:35 --> Total execution time: 1.1476
