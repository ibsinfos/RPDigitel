<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-08 12:00:26 --> Config Class Initialized
INFO - 2017-02-08 12:00:26 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:00:26 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:00:26 --> Utf8 Class Initialized
INFO - 2017-02-08 12:00:26 --> URI Class Initialized
INFO - 2017-02-08 12:00:27 --> Router Class Initialized
INFO - 2017-02-08 12:00:27 --> Output Class Initialized
INFO - 2017-02-08 12:00:27 --> Security Class Initialized
DEBUG - 2017-02-08 12:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:00:27 --> Input Class Initialized
INFO - 2017-02-08 12:00:27 --> Language Class Initialized
INFO - 2017-02-08 12:00:27 --> Language Class Initialized
INFO - 2017-02-08 12:00:27 --> Config Class Initialized
INFO - 2017-02-08 12:00:27 --> Loader Class Initialized
INFO - 2017-02-08 12:00:27 --> Helper loaded: form_helper
INFO - 2017-02-08 12:00:27 --> Helper loaded: url_helper
INFO - 2017-02-08 12:00:27 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:00:27 --> Database Driver Class Initialized
INFO - 2017-02-08 12:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:00:28 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:00:28 --> Template Class Initialized
INFO - 2017-02-08 12:00:28 --> Controller Class Initialized
DEBUG - 2017-02-08 12:00:28 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:00:29 --> Helper loaded: cookie_helper
ERROR - 2017-02-08 12:00:29 --> Severity: Warning --> parse_ini_file(C:\xampp\htdocs\mobile\application\config/FB.ini): failed to open stream: No such file or directory C:\xampp\htdocs\mobile\application\modules\backend\controllers\Login.php 9
INFO - 2017-02-08 12:00:49 --> Config Class Initialized
INFO - 2017-02-08 12:00:49 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:00:49 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:00:49 --> Utf8 Class Initialized
INFO - 2017-02-08 12:00:49 --> URI Class Initialized
INFO - 2017-02-08 12:00:49 --> Router Class Initialized
INFO - 2017-02-08 12:00:49 --> Output Class Initialized
INFO - 2017-02-08 12:00:49 --> Security Class Initialized
DEBUG - 2017-02-08 12:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:00:49 --> Input Class Initialized
INFO - 2017-02-08 12:00:49 --> Language Class Initialized
INFO - 2017-02-08 12:00:49 --> Language Class Initialized
INFO - 2017-02-08 12:00:49 --> Config Class Initialized
INFO - 2017-02-08 12:00:49 --> Loader Class Initialized
INFO - 2017-02-08 12:00:49 --> Helper loaded: form_helper
INFO - 2017-02-08 12:00:49 --> Helper loaded: url_helper
INFO - 2017-02-08 12:00:49 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:00:49 --> Database Driver Class Initialized
INFO - 2017-02-08 12:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:00:49 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:00:49 --> Template Class Initialized
INFO - 2017-02-08 12:00:49 --> Controller Class Initialized
DEBUG - 2017-02-08 12:00:49 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:00:49 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:01:01 --> Config Class Initialized
INFO - 2017-02-08 12:01:01 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:01:01 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:01:01 --> Utf8 Class Initialized
INFO - 2017-02-08 12:01:01 --> URI Class Initialized
INFO - 2017-02-08 12:01:01 --> Router Class Initialized
INFO - 2017-02-08 12:01:01 --> Output Class Initialized
INFO - 2017-02-08 12:01:01 --> Security Class Initialized
DEBUG - 2017-02-08 12:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:01:01 --> Input Class Initialized
INFO - 2017-02-08 12:01:01 --> Language Class Initialized
INFO - 2017-02-08 12:01:01 --> Language Class Initialized
INFO - 2017-02-08 12:01:01 --> Config Class Initialized
INFO - 2017-02-08 12:01:01 --> Loader Class Initialized
INFO - 2017-02-08 12:01:01 --> Helper loaded: form_helper
INFO - 2017-02-08 12:01:01 --> Helper loaded: url_helper
INFO - 2017-02-08 12:01:01 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:01:01 --> Database Driver Class Initialized
INFO - 2017-02-08 12:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:01:01 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:01:01 --> Template Class Initialized
INFO - 2017-02-08 12:01:01 --> Controller Class Initialized
DEBUG - 2017-02-08 12:01:01 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:01:01 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:01:02 --> Config Class Initialized
INFO - 2017-02-08 12:01:02 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:01:02 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:01:02 --> Utf8 Class Initialized
INFO - 2017-02-08 12:01:02 --> URI Class Initialized
INFO - 2017-02-08 12:01:02 --> Router Class Initialized
INFO - 2017-02-08 12:01:02 --> Output Class Initialized
INFO - 2017-02-08 12:01:02 --> Security Class Initialized
DEBUG - 2017-02-08 12:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:01:02 --> Input Class Initialized
INFO - 2017-02-08 12:01:02 --> Language Class Initialized
INFO - 2017-02-08 12:01:02 --> Language Class Initialized
INFO - 2017-02-08 12:01:02 --> Config Class Initialized
INFO - 2017-02-08 12:01:02 --> Loader Class Initialized
INFO - 2017-02-08 12:01:02 --> Helper loaded: form_helper
INFO - 2017-02-08 12:01:02 --> Helper loaded: url_helper
INFO - 2017-02-08 12:01:02 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:01:02 --> Database Driver Class Initialized
INFO - 2017-02-08 12:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:01:02 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:01:02 --> Template Class Initialized
INFO - 2017-02-08 12:01:02 --> Controller Class Initialized
DEBUG - 2017-02-08 12:01:02 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:01:02 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:01:37 --> Config Class Initialized
INFO - 2017-02-08 12:01:37 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:01:37 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:01:37 --> Utf8 Class Initialized
INFO - 2017-02-08 12:01:37 --> URI Class Initialized
INFO - 2017-02-08 12:01:37 --> Router Class Initialized
INFO - 2017-02-08 12:01:37 --> Output Class Initialized
INFO - 2017-02-08 12:01:37 --> Security Class Initialized
DEBUG - 2017-02-08 12:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:01:37 --> Input Class Initialized
INFO - 2017-02-08 12:01:37 --> Language Class Initialized
INFO - 2017-02-08 12:01:37 --> Language Class Initialized
INFO - 2017-02-08 12:01:37 --> Config Class Initialized
INFO - 2017-02-08 12:01:37 --> Loader Class Initialized
INFO - 2017-02-08 12:01:37 --> Helper loaded: form_helper
INFO - 2017-02-08 12:01:37 --> Helper loaded: url_helper
INFO - 2017-02-08 12:01:37 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:01:37 --> Database Driver Class Initialized
INFO - 2017-02-08 12:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:01:37 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:01:37 --> Template Class Initialized
INFO - 2017-02-08 12:01:37 --> Controller Class Initialized
DEBUG - 2017-02-08 12:01:37 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:01:37 --> Helper loaded: cookie_helper
DEBUG - 2017-02-08 12:01:37 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
ERROR - 2017-02-08 12:01:37 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 11
ERROR - 2017-02-08 12:01:37 --> Severity: Notice --> Undefined index: header C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 41
ERROR - 2017-02-08 12:01:37 --> Severity: Notice --> Undefined index: sidebar C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 45
ERROR - 2017-02-08 12:01:37 --> Severity: Notice --> Undefined index: footer C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 53
DEBUG - 2017-02-08 12:01:37 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:01:37 --> Final output sent to browser
DEBUG - 2017-02-08 12:01:37 --> Total execution time: 0.1498
INFO - 2017-02-08 12:01:37 --> Config Class Initialized
INFO - 2017-02-08 12:01:37 --> Hooks Class Initialized
INFO - 2017-02-08 12:01:37 --> Config Class Initialized
INFO - 2017-02-08 12:01:37 --> Config Class Initialized
INFO - 2017-02-08 12:01:37 --> Hooks Class Initialized
INFO - 2017-02-08 12:01:37 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:01:37 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:01:37 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:01:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:01:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:01:38 --> URI Class Initialized
INFO - 2017-02-08 12:01:38 --> URI Class Initialized
INFO - 2017-02-08 12:01:38 --> Config Class Initialized
INFO - 2017-02-08 12:01:38 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:01:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:01:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:01:38 --> URI Class Initialized
INFO - 2017-02-08 12:01:38 --> Router Class Initialized
INFO - 2017-02-08 12:01:38 --> Output Class Initialized
INFO - 2017-02-08 12:01:38 --> Router Class Initialized
INFO - 2017-02-08 12:01:38 --> Output Class Initialized
INFO - 2017-02-08 12:01:38 --> Security Class Initialized
INFO - 2017-02-08 12:01:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:01:38 --> Input Class Initialized
INFO - 2017-02-08 12:01:38 --> Language Class Initialized
ERROR - 2017-02-08 12:01:38 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:01:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:01:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:01:38 --> Router Class Initialized
INFO - 2017-02-08 12:01:38 --> Output Class Initialized
INFO - 2017-02-08 12:01:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:01:38 --> Input Class Initialized
INFO - 2017-02-08 12:01:38 --> Language Class Initialized
DEBUG - 2017-02-08 12:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:01:38 --> Input Class Initialized
ERROR - 2017-02-08 12:01:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:01:38 --> Language Class Initialized
INFO - 2017-02-08 12:01:38 --> URI Class Initialized
ERROR - 2017-02-08 12:01:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:01:38 --> Config Class Initialized
INFO - 2017-02-08 12:01:38 --> Hooks Class Initialized
INFO - 2017-02-08 12:01:38 --> Config Class Initialized
INFO - 2017-02-08 12:01:38 --> Router Class Initialized
DEBUG - 2017-02-08 12:01:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:01:38 --> Hooks Class Initialized
INFO - 2017-02-08 12:01:38 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:01:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:01:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:01:38 --> URI Class Initialized
INFO - 2017-02-08 12:01:38 --> URI Class Initialized
INFO - 2017-02-08 12:01:38 --> Config Class Initialized
INFO - 2017-02-08 12:01:38 --> Hooks Class Initialized
INFO - 2017-02-08 12:01:38 --> Output Class Initialized
INFO - 2017-02-08 12:01:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:01:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:01:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:01:38 --> URI Class Initialized
INFO - 2017-02-08 12:01:38 --> Router Class Initialized
INFO - 2017-02-08 12:01:38 --> Config Class Initialized
INFO - 2017-02-08 12:01:38 --> Output Class Initialized
INFO - 2017-02-08 12:01:38 --> Hooks Class Initialized
INFO - 2017-02-08 12:01:38 --> Router Class Initialized
INFO - 2017-02-08 12:01:38 --> Security Class Initialized
INFO - 2017-02-08 12:01:38 --> Output Class Initialized
DEBUG - 2017-02-08 12:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:01:38 --> Input Class Initialized
INFO - 2017-02-08 12:01:38 --> Security Class Initialized
INFO - 2017-02-08 12:01:38 --> Language Class Initialized
DEBUG - 2017-02-08 12:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:01:38 --> Input Class Initialized
ERROR - 2017-02-08 12:01:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:01:38 --> Language Class Initialized
ERROR - 2017-02-08 12:01:38 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:01:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:01:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:01:38 --> URI Class Initialized
INFO - 2017-02-08 12:01:38 --> Config Class Initialized
INFO - 2017-02-08 12:01:38 --> Hooks Class Initialized
INFO - 2017-02-08 12:01:38 --> Router Class Initialized
INFO - 2017-02-08 12:01:38 --> Output Class Initialized
DEBUG - 2017-02-08 12:01:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:01:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:01:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:01:38 --> URI Class Initialized
INFO - 2017-02-08 12:01:38 --> Input Class Initialized
DEBUG - 2017-02-08 12:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:01:38 --> Input Class Initialized
INFO - 2017-02-08 12:01:38 --> Language Class Initialized
INFO - 2017-02-08 12:01:38 --> Language Class Initialized
ERROR - 2017-02-08 12:01:38 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:01:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:01:38 --> Router Class Initialized
INFO - 2017-02-08 12:01:38 --> Output Class Initialized
INFO - 2017-02-08 12:01:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:01:38 --> Input Class Initialized
INFO - 2017-02-08 12:01:38 --> Language Class Initialized
ERROR - 2017-02-08 12:01:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:01:38 --> Router Class Initialized
INFO - 2017-02-08 12:01:38 --> Output Class Initialized
INFO - 2017-02-08 12:01:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:01:38 --> Input Class Initialized
INFO - 2017-02-08 12:01:38 --> Language Class Initialized
ERROR - 2017-02-08 12:01:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:01:39 --> Config Class Initialized
INFO - 2017-02-08 12:01:39 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:01:39 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:01:39 --> Utf8 Class Initialized
INFO - 2017-02-08 12:01:39 --> URI Class Initialized
INFO - 2017-02-08 12:01:39 --> Router Class Initialized
INFO - 2017-02-08 12:01:39 --> Output Class Initialized
INFO - 2017-02-08 12:01:39 --> Security Class Initialized
DEBUG - 2017-02-08 12:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:01:39 --> Input Class Initialized
INFO - 2017-02-08 12:01:39 --> Language Class Initialized
ERROR - 2017-02-08 12:01:39 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-08 12:02:50 --> Config Class Initialized
INFO - 2017-02-08 12:02:50 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:02:50 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:02:50 --> Utf8 Class Initialized
INFO - 2017-02-08 12:02:50 --> URI Class Initialized
INFO - 2017-02-08 12:02:50 --> Router Class Initialized
INFO - 2017-02-08 12:02:50 --> Output Class Initialized
INFO - 2017-02-08 12:02:50 --> Security Class Initialized
DEBUG - 2017-02-08 12:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:02:50 --> Input Class Initialized
INFO - 2017-02-08 12:02:50 --> Language Class Initialized
INFO - 2017-02-08 12:02:50 --> Language Class Initialized
INFO - 2017-02-08 12:02:50 --> Config Class Initialized
INFO - 2017-02-08 12:02:50 --> Loader Class Initialized
INFO - 2017-02-08 12:02:50 --> Helper loaded: form_helper
INFO - 2017-02-08 12:02:50 --> Helper loaded: url_helper
INFO - 2017-02-08 12:02:50 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:02:50 --> Database Driver Class Initialized
INFO - 2017-02-08 12:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:02:50 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:02:50 --> Template Class Initialized
INFO - 2017-02-08 12:02:50 --> Controller Class Initialized
DEBUG - 2017-02-08 12:02:50 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:02:50 --> Helper loaded: cookie_helper
DEBUG - 2017-02-08 12:02:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
ERROR - 2017-02-08 12:02:50 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 11
ERROR - 2017-02-08 12:02:50 --> Severity: Notice --> Undefined index: header C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 41
ERROR - 2017-02-08 12:02:50 --> Severity: Notice --> Undefined index: sidebar C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 45
ERROR - 2017-02-08 12:02:50 --> Severity: Notice --> Undefined index: footer C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 53
DEBUG - 2017-02-08 12:02:50 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:02:50 --> Final output sent to browser
DEBUG - 2017-02-08 12:02:50 --> Total execution time: 0.1324
INFO - 2017-02-08 12:02:51 --> Config Class Initialized
INFO - 2017-02-08 12:02:51 --> Hooks Class Initialized
INFO - 2017-02-08 12:02:51 --> Config Class Initialized
INFO - 2017-02-08 12:02:51 --> Hooks Class Initialized
INFO - 2017-02-08 12:02:51 --> Config Class Initialized
INFO - 2017-02-08 12:02:51 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:02:51 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:02:51 --> Utf8 Class Initialized
INFO - 2017-02-08 12:02:51 --> URI Class Initialized
DEBUG - 2017-02-08 12:02:51 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:02:51 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:02:51 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:02:51 --> Router Class Initialized
INFO - 2017-02-08 12:02:51 --> Utf8 Class Initialized
INFO - 2017-02-08 12:02:51 --> Config Class Initialized
INFO - 2017-02-08 12:02:51 --> Hooks Class Initialized
INFO - 2017-02-08 12:02:51 --> Output Class Initialized
INFO - 2017-02-08 12:02:51 --> Security Class Initialized
DEBUG - 2017-02-08 12:02:51 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:02:51 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:02:51 --> Input Class Initialized
INFO - 2017-02-08 12:02:51 --> URI Class Initialized
INFO - 2017-02-08 12:02:51 --> Language Class Initialized
INFO - 2017-02-08 12:02:51 --> Router Class Initialized
ERROR - 2017-02-08 12:02:51 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:02:51 --> Output Class Initialized
INFO - 2017-02-08 12:02:51 --> Security Class Initialized
INFO - 2017-02-08 12:02:51 --> URI Class Initialized
DEBUG - 2017-02-08 12:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:02:51 --> Input Class Initialized
INFO - 2017-02-08 12:02:51 --> Language Class Initialized
ERROR - 2017-02-08 12:02:51 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:02:51 --> Config Class Initialized
INFO - 2017-02-08 12:02:51 --> Hooks Class Initialized
INFO - 2017-02-08 12:02:51 --> URI Class Initialized
DEBUG - 2017-02-08 12:02:51 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:02:51 --> Utf8 Class Initialized
INFO - 2017-02-08 12:02:51 --> Router Class Initialized
INFO - 2017-02-08 12:02:51 --> URI Class Initialized
INFO - 2017-02-08 12:02:51 --> Config Class Initialized
INFO - 2017-02-08 12:02:51 --> Hooks Class Initialized
INFO - 2017-02-08 12:02:51 --> Output Class Initialized
INFO - 2017-02-08 12:02:51 --> Security Class Initialized
INFO - 2017-02-08 12:02:51 --> Router Class Initialized
INFO - 2017-02-08 12:02:51 --> Router Class Initialized
DEBUG - 2017-02-08 12:02:51 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:02:51 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:02:51 --> Input Class Initialized
INFO - 2017-02-08 12:02:51 --> Output Class Initialized
INFO - 2017-02-08 12:02:51 --> Output Class Initialized
INFO - 2017-02-08 12:02:51 --> URI Class Initialized
INFO - 2017-02-08 12:02:51 --> Language Class Initialized
INFO - 2017-02-08 12:02:51 --> Security Class Initialized
INFO - 2017-02-08 12:02:51 --> Security Class Initialized
DEBUG - 2017-02-08 12:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-08 12:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:02:51 --> Input Class Initialized
ERROR - 2017-02-08 12:02:51 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:02:51 --> Input Class Initialized
INFO - 2017-02-08 12:02:51 --> Router Class Initialized
INFO - 2017-02-08 12:02:51 --> Language Class Initialized
INFO - 2017-02-08 12:02:51 --> Language Class Initialized
INFO - 2017-02-08 12:02:51 --> Output Class Initialized
ERROR - 2017-02-08 12:02:51 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:02:51 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:02:51 --> Security Class Initialized
INFO - 2017-02-08 12:02:51 --> Config Class Initialized
DEBUG - 2017-02-08 12:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:02:51 --> Hooks Class Initialized
INFO - 2017-02-08 12:02:51 --> Input Class Initialized
INFO - 2017-02-08 12:02:51 --> Language Class Initialized
ERROR - 2017-02-08 12:02:51 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:02:51 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:02:51 --> Utf8 Class Initialized
INFO - 2017-02-08 12:02:51 --> URI Class Initialized
INFO - 2017-02-08 12:02:51 --> Router Class Initialized
INFO - 2017-02-08 12:02:51 --> Config Class Initialized
INFO - 2017-02-08 12:02:51 --> Hooks Class Initialized
INFO - 2017-02-08 12:02:51 --> Output Class Initialized
INFO - 2017-02-08 12:02:51 --> Security Class Initialized
DEBUG - 2017-02-08 12:02:51 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:02:51 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:02:51 --> URI Class Initialized
INFO - 2017-02-08 12:02:51 --> Input Class Initialized
INFO - 2017-02-08 12:02:51 --> Language Class Initialized
ERROR - 2017-02-08 12:02:51 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:02:51 --> Router Class Initialized
INFO - 2017-02-08 12:02:51 --> Output Class Initialized
INFO - 2017-02-08 12:02:51 --> Security Class Initialized
DEBUG - 2017-02-08 12:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:02:51 --> Input Class Initialized
INFO - 2017-02-08 12:02:51 --> Language Class Initialized
ERROR - 2017-02-08 12:02:51 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:02:51 --> Config Class Initialized
INFO - 2017-02-08 12:02:51 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:02:51 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:02:51 --> Utf8 Class Initialized
INFO - 2017-02-08 12:02:51 --> URI Class Initialized
INFO - 2017-02-08 12:02:51 --> Router Class Initialized
INFO - 2017-02-08 12:02:51 --> Output Class Initialized
INFO - 2017-02-08 12:02:51 --> Security Class Initialized
DEBUG - 2017-02-08 12:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:02:51 --> Input Class Initialized
INFO - 2017-02-08 12:02:51 --> Language Class Initialized
ERROR - 2017-02-08 12:02:51 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:03:42 --> Config Class Initialized
INFO - 2017-02-08 12:03:42 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:03:42 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:03:42 --> Utf8 Class Initialized
INFO - 2017-02-08 12:03:42 --> URI Class Initialized
INFO - 2017-02-08 12:03:42 --> Router Class Initialized
INFO - 2017-02-08 12:03:42 --> Output Class Initialized
INFO - 2017-02-08 12:03:42 --> Security Class Initialized
DEBUG - 2017-02-08 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:03:42 --> Input Class Initialized
INFO - 2017-02-08 12:03:42 --> Language Class Initialized
INFO - 2017-02-08 12:03:42 --> Language Class Initialized
INFO - 2017-02-08 12:03:42 --> Config Class Initialized
INFO - 2017-02-08 12:03:42 --> Loader Class Initialized
INFO - 2017-02-08 12:03:42 --> Helper loaded: form_helper
INFO - 2017-02-08 12:03:42 --> Helper loaded: url_helper
INFO - 2017-02-08 12:03:42 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:03:42 --> Database Driver Class Initialized
INFO - 2017-02-08 12:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:03:42 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:03:42 --> Template Class Initialized
INFO - 2017-02-08 12:03:42 --> Controller Class Initialized
DEBUG - 2017-02-08 12:03:42 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:03:42 --> Helper loaded: cookie_helper
DEBUG - 2017-02-08 12:03:42 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
ERROR - 2017-02-08 12:03:42 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 11
ERROR - 2017-02-08 12:03:42 --> Severity: Notice --> Undefined index: header C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 41
ERROR - 2017-02-08 12:03:42 --> Severity: Notice --> Undefined index: sidebar C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 45
ERROR - 2017-02-08 12:03:42 --> Severity: Notice --> Undefined index: footer C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 53
DEBUG - 2017-02-08 12:03:42 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:03:42 --> Final output sent to browser
DEBUG - 2017-02-08 12:03:42 --> Total execution time: 0.1637
INFO - 2017-02-08 12:03:42 --> Config Class Initialized
INFO - 2017-02-08 12:03:42 --> Hooks Class Initialized
INFO - 2017-02-08 12:03:42 --> Config Class Initialized
INFO - 2017-02-08 12:03:42 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:03:42 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:03:42 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:03:42 --> Config Class Initialized
INFO - 2017-02-08 12:03:42 --> Utf8 Class Initialized
INFO - 2017-02-08 12:03:42 --> Hooks Class Initialized
INFO - 2017-02-08 12:03:42 --> Utf8 Class Initialized
INFO - 2017-02-08 12:03:42 --> URI Class Initialized
INFO - 2017-02-08 12:03:42 --> URI Class Initialized
DEBUG - 2017-02-08 12:03:42 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:03:42 --> Utf8 Class Initialized
INFO - 2017-02-08 12:03:42 --> Router Class Initialized
INFO - 2017-02-08 12:03:42 --> URI Class Initialized
INFO - 2017-02-08 12:03:42 --> Output Class Initialized
INFO - 2017-02-08 12:03:42 --> Security Class Initialized
INFO - 2017-02-08 12:03:42 --> Router Class Initialized
INFO - 2017-02-08 12:03:42 --> Config Class Initialized
INFO - 2017-02-08 12:03:42 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:03:42 --> Input Class Initialized
INFO - 2017-02-08 12:03:42 --> Output Class Initialized
INFO - 2017-02-08 12:03:42 --> Language Class Initialized
INFO - 2017-02-08 12:03:42 --> Security Class Initialized
ERROR - 2017-02-08 12:03:42 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:03:42 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:03:42 --> Utf8 Class Initialized
INFO - 2017-02-08 12:03:42 --> Router Class Initialized
DEBUG - 2017-02-08 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:03:42 --> Input Class Initialized
INFO - 2017-02-08 12:03:42 --> URI Class Initialized
INFO - 2017-02-08 12:03:42 --> Language Class Initialized
ERROR - 2017-02-08 12:03:42 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:03:42 --> Router Class Initialized
INFO - 2017-02-08 12:03:42 --> Output Class Initialized
INFO - 2017-02-08 12:03:42 --> Output Class Initialized
INFO - 2017-02-08 12:03:42 --> Security Class Initialized
INFO - 2017-02-08 12:03:42 --> Security Class Initialized
DEBUG - 2017-02-08 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:03:42 --> Input Class Initialized
INFO - 2017-02-08 12:03:42 --> Language Class Initialized
DEBUG - 2017-02-08 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:03:42 --> Input Class Initialized
ERROR - 2017-02-08 12:03:42 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:03:42 --> Language Class Initialized
ERROR - 2017-02-08 12:03:42 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:03:42 --> Config Class Initialized
INFO - 2017-02-08 12:03:42 --> Hooks Class Initialized
INFO - 2017-02-08 12:03:42 --> Config Class Initialized
INFO - 2017-02-08 12:03:42 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:03:42 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:03:42 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:03:42 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:03:42 --> Utf8 Class Initialized
INFO - 2017-02-08 12:03:42 --> URI Class Initialized
INFO - 2017-02-08 12:03:42 --> URI Class Initialized
INFO - 2017-02-08 12:03:42 --> Config Class Initialized
INFO - 2017-02-08 12:03:42 --> Hooks Class Initialized
INFO - 2017-02-08 12:03:42 --> Router Class Initialized
INFO - 2017-02-08 12:03:42 --> Router Class Initialized
DEBUG - 2017-02-08 12:03:42 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:03:42 --> Utf8 Class Initialized
INFO - 2017-02-08 12:03:42 --> Output Class Initialized
INFO - 2017-02-08 12:03:42 --> URI Class Initialized
INFO - 2017-02-08 12:03:42 --> Output Class Initialized
INFO - 2017-02-08 12:03:42 --> Security Class Initialized
INFO - 2017-02-08 12:03:42 --> Security Class Initialized
DEBUG - 2017-02-08 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:03:42 --> Input Class Initialized
INFO - 2017-02-08 12:03:42 --> Config Class Initialized
INFO - 2017-02-08 12:03:42 --> Router Class Initialized
INFO - 2017-02-08 12:03:42 --> Language Class Initialized
INFO - 2017-02-08 12:03:42 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:03:42 --> Input Class Initialized
INFO - 2017-02-08 12:03:42 --> Language Class Initialized
INFO - 2017-02-08 12:03:42 --> Output Class Initialized
ERROR - 2017-02-08 12:03:42 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:03:42 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:03:42 --> Security Class Initialized
DEBUG - 2017-02-08 12:03:42 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:03:42 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:03:42 --> Input Class Initialized
INFO - 2017-02-08 12:03:42 --> URI Class Initialized
INFO - 2017-02-08 12:03:42 --> Language Class Initialized
ERROR - 2017-02-08 12:03:42 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:03:42 --> Router Class Initialized
INFO - 2017-02-08 12:03:42 --> Output Class Initialized
INFO - 2017-02-08 12:03:42 --> Security Class Initialized
DEBUG - 2017-02-08 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:03:42 --> Config Class Initialized
INFO - 2017-02-08 12:03:42 --> Input Class Initialized
INFO - 2017-02-08 12:03:42 --> Hooks Class Initialized
INFO - 2017-02-08 12:03:42 --> Language Class Initialized
ERROR - 2017-02-08 12:03:42 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:03:42 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:03:42 --> Utf8 Class Initialized
INFO - 2017-02-08 12:03:42 --> URI Class Initialized
INFO - 2017-02-08 12:03:42 --> Router Class Initialized
INFO - 2017-02-08 12:03:42 --> Output Class Initialized
INFO - 2017-02-08 12:03:42 --> Security Class Initialized
DEBUG - 2017-02-08 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:03:42 --> Input Class Initialized
INFO - 2017-02-08 12:03:42 --> Language Class Initialized
ERROR - 2017-02-08 12:03:42 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:04:09 --> Config Class Initialized
INFO - 2017-02-08 12:04:09 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:04:09 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:09 --> Utf8 Class Initialized
INFO - 2017-02-08 12:04:09 --> URI Class Initialized
INFO - 2017-02-08 12:04:09 --> Router Class Initialized
INFO - 2017-02-08 12:04:09 --> Output Class Initialized
INFO - 2017-02-08 12:04:09 --> Security Class Initialized
DEBUG - 2017-02-08 12:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:09 --> Input Class Initialized
INFO - 2017-02-08 12:04:09 --> Language Class Initialized
INFO - 2017-02-08 12:04:09 --> Language Class Initialized
INFO - 2017-02-08 12:04:09 --> Config Class Initialized
INFO - 2017-02-08 12:04:09 --> Loader Class Initialized
INFO - 2017-02-08 12:04:09 --> Helper loaded: form_helper
INFO - 2017-02-08 12:04:09 --> Helper loaded: url_helper
INFO - 2017-02-08 12:04:09 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:04:09 --> Database Driver Class Initialized
INFO - 2017-02-08 12:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:04:09 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:04:09 --> Template Class Initialized
INFO - 2017-02-08 12:04:09 --> Controller Class Initialized
DEBUG - 2017-02-08 12:04:09 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:04:09 --> Helper loaded: cookie_helper
DEBUG - 2017-02-08 12:04:09 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
ERROR - 2017-02-08 12:04:09 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 11
ERROR - 2017-02-08 12:04:09 --> Severity: Notice --> Undefined index: header C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 41
ERROR - 2017-02-08 12:04:09 --> Severity: Notice --> Undefined index: sidebar C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 45
ERROR - 2017-02-08 12:04:09 --> Severity: Notice --> Undefined index: footer C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 53
DEBUG - 2017-02-08 12:04:09 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:04:09 --> Final output sent to browser
DEBUG - 2017-02-08 12:04:09 --> Total execution time: 0.0831
INFO - 2017-02-08 12:04:09 --> Config Class Initialized
INFO - 2017-02-08 12:04:09 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:04:09 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:09 --> Config Class Initialized
INFO - 2017-02-08 12:04:09 --> Utf8 Class Initialized
INFO - 2017-02-08 12:04:09 --> Hooks Class Initialized
INFO - 2017-02-08 12:04:09 --> URI Class Initialized
DEBUG - 2017-02-08 12:04:09 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:09 --> Utf8 Class Initialized
INFO - 2017-02-08 12:04:09 --> Router Class Initialized
INFO - 2017-02-08 12:04:09 --> URI Class Initialized
INFO - 2017-02-08 12:04:09 --> Output Class Initialized
INFO - 2017-02-08 12:04:09 --> Security Class Initialized
INFO - 2017-02-08 12:04:09 --> Router Class Initialized
DEBUG - 2017-02-08 12:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:09 --> Input Class Initialized
INFO - 2017-02-08 12:04:09 --> Output Class Initialized
INFO - 2017-02-08 12:04:09 --> Security Class Initialized
DEBUG - 2017-02-08 12:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:09 --> Input Class Initialized
INFO - 2017-02-08 12:04:09 --> Language Class Initialized
ERROR - 2017-02-08 12:04:09 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:04:09 --> Config Class Initialized
INFO - 2017-02-08 12:04:09 --> Hooks Class Initialized
INFO - 2017-02-08 12:04:09 --> Config Class Initialized
INFO - 2017-02-08 12:04:09 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:04:09 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:09 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:04:09 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:09 --> Utf8 Class Initialized
INFO - 2017-02-08 12:04:09 --> Config Class Initialized
INFO - 2017-02-08 12:04:09 --> Config Class Initialized
INFO - 2017-02-08 12:04:09 --> URI Class Initialized
INFO - 2017-02-08 12:04:09 --> Language Class Initialized
INFO - 2017-02-08 12:04:09 --> Hooks Class Initialized
INFO - 2017-02-08 12:04:09 --> Hooks Class Initialized
INFO - 2017-02-08 12:04:09 --> URI Class Initialized
ERROR - 2017-02-08 12:04:09 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:04:09 --> Router Class Initialized
INFO - 2017-02-08 12:04:09 --> Router Class Initialized
INFO - 2017-02-08 12:04:09 --> Output Class Initialized
DEBUG - 2017-02-08 12:04:09 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:09 --> Utf8 Class Initialized
INFO - 2017-02-08 12:04:09 --> Output Class Initialized
DEBUG - 2017-02-08 12:04:09 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:09 --> Utf8 Class Initialized
INFO - 2017-02-08 12:04:09 --> Security Class Initialized
INFO - 2017-02-08 12:04:09 --> URI Class Initialized
INFO - 2017-02-08 12:04:09 --> URI Class Initialized
DEBUG - 2017-02-08 12:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:09 --> Input Class Initialized
INFO - 2017-02-08 12:04:09 --> Language Class Initialized
INFO - 2017-02-08 12:04:09 --> Config Class Initialized
INFO - 2017-02-08 12:04:09 --> Hooks Class Initialized
ERROR - 2017-02-08 12:04:09 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:04:09 --> Router Class Initialized
INFO - 2017-02-08 12:04:09 --> Router Class Initialized
DEBUG - 2017-02-08 12:04:09 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:09 --> Utf8 Class Initialized
INFO - 2017-02-08 12:04:09 --> Output Class Initialized
INFO - 2017-02-08 12:04:09 --> URI Class Initialized
INFO - 2017-02-08 12:04:09 --> Output Class Initialized
INFO - 2017-02-08 12:04:09 --> Security Class Initialized
INFO - 2017-02-08 12:04:09 --> Security Class Initialized
DEBUG - 2017-02-08 12:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:09 --> Router Class Initialized
INFO - 2017-02-08 12:04:09 --> Input Class Initialized
INFO - 2017-02-08 12:04:09 --> Language Class Initialized
DEBUG - 2017-02-08 12:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:09 --> Input Class Initialized
INFO - 2017-02-08 12:04:09 --> Output Class Initialized
ERROR - 2017-02-08 12:04:09 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:04:09 --> Language Class Initialized
INFO - 2017-02-08 12:04:09 --> Security Class Initialized
ERROR - 2017-02-08 12:04:09 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:09 --> Input Class Initialized
INFO - 2017-02-08 12:04:09 --> Language Class Initialized
ERROR - 2017-02-08 12:04:09 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:04:09 --> Security Class Initialized
DEBUG - 2017-02-08 12:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:09 --> Input Class Initialized
INFO - 2017-02-08 12:04:09 --> Language Class Initialized
ERROR - 2017-02-08 12:04:09 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:04:09 --> Config Class Initialized
INFO - 2017-02-08 12:04:09 --> Hooks Class Initialized
INFO - 2017-02-08 12:04:09 --> Config Class Initialized
INFO - 2017-02-08 12:04:09 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:04:09 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:09 --> Utf8 Class Initialized
INFO - 2017-02-08 12:04:09 --> URI Class Initialized
DEBUG - 2017-02-08 12:04:09 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:09 --> Utf8 Class Initialized
INFO - 2017-02-08 12:04:09 --> URI Class Initialized
INFO - 2017-02-08 12:04:09 --> Router Class Initialized
INFO - 2017-02-08 12:04:09 --> Output Class Initialized
INFO - 2017-02-08 12:04:09 --> Router Class Initialized
INFO - 2017-02-08 12:04:09 --> Security Class Initialized
INFO - 2017-02-08 12:04:09 --> Output Class Initialized
DEBUG - 2017-02-08 12:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:09 --> Input Class Initialized
INFO - 2017-02-08 12:04:09 --> Language Class Initialized
INFO - 2017-02-08 12:04:09 --> Security Class Initialized
ERROR - 2017-02-08 12:04:09 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:09 --> Input Class Initialized
INFO - 2017-02-08 12:04:09 --> Language Class Initialized
ERROR - 2017-02-08 12:04:09 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:04:53 --> Config Class Initialized
INFO - 2017-02-08 12:04:53 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:04:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:53 --> Utf8 Class Initialized
INFO - 2017-02-08 12:04:53 --> URI Class Initialized
INFO - 2017-02-08 12:04:53 --> Router Class Initialized
INFO - 2017-02-08 12:04:53 --> Output Class Initialized
INFO - 2017-02-08 12:04:53 --> Security Class Initialized
DEBUG - 2017-02-08 12:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:53 --> Input Class Initialized
INFO - 2017-02-08 12:04:53 --> Language Class Initialized
INFO - 2017-02-08 12:04:53 --> Language Class Initialized
INFO - 2017-02-08 12:04:53 --> Config Class Initialized
INFO - 2017-02-08 12:04:53 --> Loader Class Initialized
INFO - 2017-02-08 12:04:53 --> Helper loaded: form_helper
INFO - 2017-02-08 12:04:53 --> Helper loaded: url_helper
INFO - 2017-02-08 12:04:53 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:04:53 --> Database Driver Class Initialized
INFO - 2017-02-08 12:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:04:53 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:04:53 --> Template Class Initialized
INFO - 2017-02-08 12:04:53 --> Controller Class Initialized
DEBUG - 2017-02-08 12:04:53 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:04:53 --> Helper loaded: cookie_helper
DEBUG - 2017-02-08 12:04:53 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
ERROR - 2017-02-08 12:04:53 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 11
DEBUG - 2017-02-08 12:04:53 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:04:53 --> Final output sent to browser
DEBUG - 2017-02-08 12:04:53 --> Total execution time: 0.0746
INFO - 2017-02-08 12:04:53 --> Config Class Initialized
INFO - 2017-02-08 12:04:53 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:04:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:53 --> Utf8 Class Initialized
INFO - 2017-02-08 12:04:53 --> URI Class Initialized
INFO - 2017-02-08 12:04:53 --> Router Class Initialized
INFO - 2017-02-08 12:04:53 --> Output Class Initialized
INFO - 2017-02-08 12:04:53 --> Security Class Initialized
DEBUG - 2017-02-08 12:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:53 --> Input Class Initialized
INFO - 2017-02-08 12:04:53 --> Language Class Initialized
ERROR - 2017-02-08 12:04:53 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:04:53 --> Config Class Initialized
INFO - 2017-02-08 12:04:53 --> Hooks Class Initialized
INFO - 2017-02-08 12:04:53 --> Config Class Initialized
INFO - 2017-02-08 12:04:53 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:04:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:53 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:04:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:53 --> Utf8 Class Initialized
INFO - 2017-02-08 12:04:53 --> URI Class Initialized
INFO - 2017-02-08 12:04:53 --> Config Class Initialized
INFO - 2017-02-08 12:04:53 --> URI Class Initialized
INFO - 2017-02-08 12:04:53 --> Hooks Class Initialized
INFO - 2017-02-08 12:04:53 --> Router Class Initialized
DEBUG - 2017-02-08 12:04:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:53 --> Router Class Initialized
INFO - 2017-02-08 12:04:53 --> Utf8 Class Initialized
INFO - 2017-02-08 12:04:53 --> Output Class Initialized
INFO - 2017-02-08 12:04:53 --> URI Class Initialized
INFO - 2017-02-08 12:04:53 --> Output Class Initialized
INFO - 2017-02-08 12:04:53 --> Security Class Initialized
INFO - 2017-02-08 12:04:53 --> Router Class Initialized
DEBUG - 2017-02-08 12:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:53 --> Input Class Initialized
INFO - 2017-02-08 12:04:53 --> Language Class Initialized
INFO - 2017-02-08 12:04:53 --> Output Class Initialized
ERROR - 2017-02-08 12:04:53 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:04:53 --> Security Class Initialized
DEBUG - 2017-02-08 12:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:53 --> Input Class Initialized
INFO - 2017-02-08 12:04:53 --> Language Class Initialized
ERROR - 2017-02-08 12:04:53 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:04:53 --> Config Class Initialized
INFO - 2017-02-08 12:04:53 --> Hooks Class Initialized
INFO - 2017-02-08 12:04:53 --> Security Class Initialized
DEBUG - 2017-02-08 12:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:53 --> Input Class Initialized
DEBUG - 2017-02-08 12:04:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:53 --> Language Class Initialized
INFO - 2017-02-08 12:04:53 --> Utf8 Class Initialized
INFO - 2017-02-08 12:04:53 --> Config Class Initialized
INFO - 2017-02-08 12:04:53 --> URI Class Initialized
INFO - 2017-02-08 12:04:53 --> Hooks Class Initialized
ERROR - 2017-02-08 12:04:53 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:04:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:53 --> Utf8 Class Initialized
INFO - 2017-02-08 12:04:53 --> Router Class Initialized
INFO - 2017-02-08 12:04:53 --> URI Class Initialized
INFO - 2017-02-08 12:04:53 --> Output Class Initialized
INFO - 2017-02-08 12:04:53 --> Config Class Initialized
INFO - 2017-02-08 12:04:53 --> Hooks Class Initialized
INFO - 2017-02-08 12:04:53 --> Security Class Initialized
INFO - 2017-02-08 12:04:53 --> Router Class Initialized
DEBUG - 2017-02-08 12:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:53 --> Input Class Initialized
INFO - 2017-02-08 12:04:53 --> Language Class Initialized
DEBUG - 2017-02-08 12:04:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:53 --> Output Class Initialized
INFO - 2017-02-08 12:04:53 --> Utf8 Class Initialized
ERROR - 2017-02-08 12:04:53 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:04:53 --> URI Class Initialized
INFO - 2017-02-08 12:04:53 --> Security Class Initialized
DEBUG - 2017-02-08 12:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:53 --> Input Class Initialized
INFO - 2017-02-08 12:04:53 --> Language Class Initialized
INFO - 2017-02-08 12:04:53 --> Router Class Initialized
ERROR - 2017-02-08 12:04:53 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:04:53 --> Output Class Initialized
INFO - 2017-02-08 12:04:53 --> Security Class Initialized
DEBUG - 2017-02-08 12:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:53 --> Input Class Initialized
INFO - 2017-02-08 12:04:53 --> Language Class Initialized
ERROR - 2017-02-08 12:04:53 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:04:53 --> Config Class Initialized
INFO - 2017-02-08 12:04:53 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:04:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:53 --> Utf8 Class Initialized
INFO - 2017-02-08 12:04:53 --> URI Class Initialized
INFO - 2017-02-08 12:04:53 --> Config Class Initialized
INFO - 2017-02-08 12:04:53 --> Hooks Class Initialized
INFO - 2017-02-08 12:04:53 --> Router Class Initialized
INFO - 2017-02-08 12:04:53 --> Output Class Initialized
DEBUG - 2017-02-08 12:04:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:04:53 --> Security Class Initialized
INFO - 2017-02-08 12:04:53 --> Utf8 Class Initialized
INFO - 2017-02-08 12:04:53 --> URI Class Initialized
DEBUG - 2017-02-08 12:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:53 --> Input Class Initialized
INFO - 2017-02-08 12:04:53 --> Language Class Initialized
ERROR - 2017-02-08 12:04:53 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:04:53 --> Router Class Initialized
INFO - 2017-02-08 12:04:53 --> Output Class Initialized
INFO - 2017-02-08 12:04:53 --> Security Class Initialized
DEBUG - 2017-02-08 12:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:04:53 --> Input Class Initialized
INFO - 2017-02-08 12:04:53 --> Language Class Initialized
ERROR - 2017-02-08 12:04:53 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:00 --> Config Class Initialized
INFO - 2017-02-08 12:05:00 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:05:00 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:00 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:00 --> URI Class Initialized
INFO - 2017-02-08 12:05:00 --> Router Class Initialized
INFO - 2017-02-08 12:05:00 --> Output Class Initialized
INFO - 2017-02-08 12:05:00 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:00 --> Input Class Initialized
INFO - 2017-02-08 12:05:00 --> Language Class Initialized
INFO - 2017-02-08 12:05:00 --> Language Class Initialized
INFO - 2017-02-08 12:05:00 --> Config Class Initialized
INFO - 2017-02-08 12:05:00 --> Loader Class Initialized
INFO - 2017-02-08 12:05:00 --> Helper loaded: form_helper
INFO - 2017-02-08 12:05:00 --> Helper loaded: url_helper
INFO - 2017-02-08 12:05:00 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:05:00 --> Database Driver Class Initialized
INFO - 2017-02-08 12:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:05:00 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:05:00 --> Template Class Initialized
INFO - 2017-02-08 12:05:00 --> Controller Class Initialized
DEBUG - 2017-02-08 12:05:00 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:05:00 --> Helper loaded: cookie_helper
DEBUG - 2017-02-08 12:05:00 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
ERROR - 2017-02-08 12:05:00 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 11
DEBUG - 2017-02-08 12:05:00 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:05:00 --> Final output sent to browser
DEBUG - 2017-02-08 12:05:00 --> Total execution time: 0.1590
INFO - 2017-02-08 12:05:00 --> Config Class Initialized
INFO - 2017-02-08 12:05:00 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:05:00 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:00 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:00 --> Config Class Initialized
INFO - 2017-02-08 12:05:00 --> Config Class Initialized
INFO - 2017-02-08 12:05:00 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:00 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:00 --> URI Class Initialized
DEBUG - 2017-02-08 12:05:00 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:05:00 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:00 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:00 --> Router Class Initialized
INFO - 2017-02-08 12:05:00 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:00 --> URI Class Initialized
INFO - 2017-02-08 12:05:00 --> URI Class Initialized
INFO - 2017-02-08 12:05:00 --> Output Class Initialized
INFO - 2017-02-08 12:05:00 --> Security Class Initialized
INFO - 2017-02-08 12:05:00 --> Router Class Initialized
INFO - 2017-02-08 12:05:00 --> Router Class Initialized
DEBUG - 2017-02-08 12:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:00 --> Input Class Initialized
INFO - 2017-02-08 12:05:00 --> Output Class Initialized
INFO - 2017-02-08 12:05:00 --> Language Class Initialized
INFO - 2017-02-08 12:05:00 --> Output Class Initialized
INFO - 2017-02-08 12:05:00 --> Security Class Initialized
ERROR - 2017-02-08 12:05:00 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:00 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:00 --> Input Class Initialized
INFO - 2017-02-08 12:05:00 --> Language Class Initialized
DEBUG - 2017-02-08 12:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:00 --> Input Class Initialized
ERROR - 2017-02-08 12:05:00 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:00 --> Language Class Initialized
ERROR - 2017-02-08 12:05:00 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:00 --> Config Class Initialized
INFO - 2017-02-08 12:05:00 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:00 --> Config Class Initialized
INFO - 2017-02-08 12:05:00 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:05:00 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:00 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:00 --> Config Class Initialized
INFO - 2017-02-08 12:05:00 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:00 --> URI Class Initialized
DEBUG - 2017-02-08 12:05:00 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:00 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:00 --> Router Class Initialized
INFO - 2017-02-08 12:05:00 --> Config Class Initialized
INFO - 2017-02-08 12:05:00 --> URI Class Initialized
INFO - 2017-02-08 12:05:00 --> Config Class Initialized
INFO - 2017-02-08 12:05:00 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:00 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:00 --> Output Class Initialized
INFO - 2017-02-08 12:05:00 --> Security Class Initialized
INFO - 2017-02-08 12:05:00 --> Router Class Initialized
DEBUG - 2017-02-08 12:05:00 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:05:00 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:00 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:00 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:00 --> Input Class Initialized
INFO - 2017-02-08 12:05:00 --> Language Class Initialized
INFO - 2017-02-08 12:05:00 --> Output Class Initialized
INFO - 2017-02-08 12:05:00 --> URI Class Initialized
INFO - 2017-02-08 12:05:00 --> URI Class Initialized
ERROR - 2017-02-08 12:05:00 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:00 --> Security Class Initialized
INFO - 2017-02-08 12:05:00 --> Router Class Initialized
DEBUG - 2017-02-08 12:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:00 --> Router Class Initialized
INFO - 2017-02-08 12:05:00 --> Input Class Initialized
INFO - 2017-02-08 12:05:00 --> Output Class Initialized
INFO - 2017-02-08 12:05:00 --> Language Class Initialized
INFO - 2017-02-08 12:05:00 --> Output Class Initialized
ERROR - 2017-02-08 12:05:00 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:00 --> Security Class Initialized
INFO - 2017-02-08 12:05:00 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:00 --> Input Class Initialized
INFO - 2017-02-08 12:05:00 --> Config Class Initialized
DEBUG - 2017-02-08 12:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:00 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:00 --> Language Class Initialized
INFO - 2017-02-08 12:05:00 --> Input Class Initialized
INFO - 2017-02-08 12:05:00 --> Language Class Initialized
ERROR - 2017-02-08 12:05:00 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:05:00 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:05:00 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:00 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:00 --> URI Class Initialized
DEBUG - 2017-02-08 12:05:00 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:00 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:00 --> URI Class Initialized
INFO - 2017-02-08 12:05:00 --> Router Class Initialized
INFO - 2017-02-08 12:05:00 --> Output Class Initialized
INFO - 2017-02-08 12:05:00 --> Router Class Initialized
INFO - 2017-02-08 12:05:00 --> Security Class Initialized
INFO - 2017-02-08 12:05:00 --> Output Class Initialized
DEBUG - 2017-02-08 12:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:00 --> Input Class Initialized
INFO - 2017-02-08 12:05:00 --> Security Class Initialized
INFO - 2017-02-08 12:05:00 --> Language Class Initialized
DEBUG - 2017-02-08 12:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-08 12:05:00 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:00 --> Input Class Initialized
INFO - 2017-02-08 12:05:00 --> Language Class Initialized
ERROR - 2017-02-08 12:05:00 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:03 --> Config Class Initialized
INFO - 2017-02-08 12:05:03 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:05:03 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:03 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:03 --> URI Class Initialized
INFO - 2017-02-08 12:05:03 --> Router Class Initialized
INFO - 2017-02-08 12:05:03 --> Output Class Initialized
INFO - 2017-02-08 12:05:03 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:03 --> Input Class Initialized
INFO - 2017-02-08 12:05:03 --> Language Class Initialized
INFO - 2017-02-08 12:05:03 --> Language Class Initialized
INFO - 2017-02-08 12:05:03 --> Config Class Initialized
INFO - 2017-02-08 12:05:03 --> Loader Class Initialized
INFO - 2017-02-08 12:05:03 --> Helper loaded: form_helper
INFO - 2017-02-08 12:05:03 --> Helper loaded: url_helper
INFO - 2017-02-08 12:05:03 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:05:03 --> Database Driver Class Initialized
INFO - 2017-02-08 12:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:05:03 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:05:03 --> Template Class Initialized
INFO - 2017-02-08 12:05:03 --> Controller Class Initialized
DEBUG - 2017-02-08 12:05:03 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:05:03 --> Helper loaded: cookie_helper
DEBUG - 2017-02-08 12:05:03 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
ERROR - 2017-02-08 12:05:03 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 11
DEBUG - 2017-02-08 12:05:03 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:05:03 --> Final output sent to browser
DEBUG - 2017-02-08 12:05:03 --> Total execution time: 0.0465
INFO - 2017-02-08 12:05:38 --> Config Class Initialized
INFO - 2017-02-08 12:05:38 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:05:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:38 --> URI Class Initialized
INFO - 2017-02-08 12:05:38 --> Router Class Initialized
INFO - 2017-02-08 12:05:38 --> Output Class Initialized
INFO - 2017-02-08 12:05:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:38 --> Input Class Initialized
INFO - 2017-02-08 12:05:38 --> Language Class Initialized
INFO - 2017-02-08 12:05:38 --> Language Class Initialized
INFO - 2017-02-08 12:05:38 --> Config Class Initialized
INFO - 2017-02-08 12:05:38 --> Loader Class Initialized
INFO - 2017-02-08 12:05:38 --> Helper loaded: form_helper
INFO - 2017-02-08 12:05:38 --> Helper loaded: url_helper
INFO - 2017-02-08 12:05:38 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:05:38 --> Database Driver Class Initialized
INFO - 2017-02-08 12:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:05:38 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:05:38 --> Template Class Initialized
INFO - 2017-02-08 12:05:38 --> Controller Class Initialized
DEBUG - 2017-02-08 12:05:38 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:05:38 --> Helper loaded: cookie_helper
DEBUG - 2017-02-08 12:05:38 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
ERROR - 2017-02-08 12:05:38 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 11
DEBUG - 2017-02-08 12:05:38 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:05:38 --> Final output sent to browser
DEBUG - 2017-02-08 12:05:38 --> Total execution time: 0.0489
INFO - 2017-02-08 12:05:38 --> Config Class Initialized
INFO - 2017-02-08 12:05:38 --> Config Class Initialized
INFO - 2017-02-08 12:05:38 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:38 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:38 --> Config Class Initialized
DEBUG - 2017-02-08 12:05:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:38 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:38 --> URI Class Initialized
DEBUG - 2017-02-08 12:05:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:38 --> URI Class Initialized
INFO - 2017-02-08 12:05:38 --> Router Class Initialized
INFO - 2017-02-08 12:05:38 --> Config Class Initialized
INFO - 2017-02-08 12:05:38 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:38 --> Output Class Initialized
INFO - 2017-02-08 12:05:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:38 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:38 --> Input Class Initialized
INFO - 2017-02-08 12:05:38 --> URI Class Initialized
INFO - 2017-02-08 12:05:38 --> Language Class Initialized
ERROR - 2017-02-08 12:05:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:38 --> Router Class Initialized
INFO - 2017-02-08 12:05:38 --> Output Class Initialized
INFO - 2017-02-08 12:05:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:38 --> Input Class Initialized
INFO - 2017-02-08 12:05:38 --> Language Class Initialized
ERROR - 2017-02-08 12:05:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:38 --> Config Class Initialized
INFO - 2017-02-08 12:05:38 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:38 --> Config Class Initialized
INFO - 2017-02-08 12:05:38 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:05:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:38 --> URI Class Initialized
DEBUG - 2017-02-08 12:05:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:38 --> URI Class Initialized
INFO - 2017-02-08 12:05:38 --> Config Class Initialized
INFO - 2017-02-08 12:05:38 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:38 --> Router Class Initialized
INFO - 2017-02-08 12:05:38 --> Output Class Initialized
INFO - 2017-02-08 12:05:38 --> Router Class Initialized
DEBUG - 2017-02-08 12:05:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:38 --> Config Class Initialized
INFO - 2017-02-08 12:05:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:38 --> Security Class Initialized
INFO - 2017-02-08 12:05:38 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:38 --> Output Class Initialized
INFO - 2017-02-08 12:05:38 --> URI Class Initialized
DEBUG - 2017-02-08 12:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:38 --> Input Class Initialized
INFO - 2017-02-08 12:05:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:38 --> Language Class Initialized
DEBUG - 2017-02-08 12:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:38 --> Input Class Initialized
ERROR - 2017-02-08 12:05:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:38 --> URI Class Initialized
INFO - 2017-02-08 12:05:38 --> Router Class Initialized
INFO - 2017-02-08 12:05:38 --> Language Class Initialized
INFO - 2017-02-08 12:05:38 --> Output Class Initialized
INFO - 2017-02-08 12:05:38 --> Router Class Initialized
ERROR - 2017-02-08 12:05:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:38 --> Security Class Initialized
INFO - 2017-02-08 12:05:38 --> Output Class Initialized
DEBUG - 2017-02-08 12:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:38 --> Input Class Initialized
INFO - 2017-02-08 12:05:38 --> Language Class Initialized
INFO - 2017-02-08 12:05:38 --> Security Class Initialized
ERROR - 2017-02-08 12:05:38 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:38 --> Input Class Initialized
INFO - 2017-02-08 12:05:38 --> Language Class Initialized
INFO - 2017-02-08 12:05:38 --> Router Class Initialized
INFO - 2017-02-08 12:05:38 --> Config Class Initialized
INFO - 2017-02-08 12:05:38 --> Hooks Class Initialized
ERROR - 2017-02-08 12:05:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:38 --> Output Class Initialized
DEBUG - 2017-02-08 12:05:38 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:05:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:38 --> Security Class Initialized
INFO - 2017-02-08 12:05:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:38 --> URI Class Initialized
INFO - 2017-02-08 12:05:38 --> URI Class Initialized
DEBUG - 2017-02-08 12:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:38 --> Input Class Initialized
INFO - 2017-02-08 12:05:38 --> Language Class Initialized
INFO - 2017-02-08 12:05:38 --> Router Class Initialized
ERROR - 2017-02-08 12:05:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:38 --> Router Class Initialized
INFO - 2017-02-08 12:05:38 --> Output Class Initialized
INFO - 2017-02-08 12:05:38 --> Output Class Initialized
INFO - 2017-02-08 12:05:38 --> Security Class Initialized
INFO - 2017-02-08 12:05:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-08 12:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:38 --> Input Class Initialized
INFO - 2017-02-08 12:05:38 --> Input Class Initialized
INFO - 2017-02-08 12:05:38 --> Language Class Initialized
INFO - 2017-02-08 12:05:38 --> Language Class Initialized
ERROR - 2017-02-08 12:05:38 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:05:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:39 --> Config Class Initialized
INFO - 2017-02-08 12:05:39 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:05:39 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:39 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:39 --> URI Class Initialized
INFO - 2017-02-08 12:05:39 --> Router Class Initialized
INFO - 2017-02-08 12:05:39 --> Output Class Initialized
INFO - 2017-02-08 12:05:39 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:39 --> Input Class Initialized
INFO - 2017-02-08 12:05:39 --> Language Class Initialized
INFO - 2017-02-08 12:05:39 --> Language Class Initialized
INFO - 2017-02-08 12:05:39 --> Config Class Initialized
INFO - 2017-02-08 12:05:39 --> Loader Class Initialized
INFO - 2017-02-08 12:05:39 --> Helper loaded: form_helper
INFO - 2017-02-08 12:05:39 --> Helper loaded: url_helper
INFO - 2017-02-08 12:05:39 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:05:39 --> Database Driver Class Initialized
INFO - 2017-02-08 12:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:05:39 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:05:39 --> Template Class Initialized
INFO - 2017-02-08 12:05:39 --> Controller Class Initialized
DEBUG - 2017-02-08 12:05:39 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:05:39 --> Helper loaded: cookie_helper
DEBUG - 2017-02-08 12:05:39 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
ERROR - 2017-02-08 12:05:39 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 11
DEBUG - 2017-02-08 12:05:39 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:05:39 --> Final output sent to browser
DEBUG - 2017-02-08 12:05:39 --> Total execution time: 0.1060
INFO - 2017-02-08 12:05:39 --> Config Class Initialized
INFO - 2017-02-08 12:05:39 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:39 --> Config Class Initialized
INFO - 2017-02-08 12:05:39 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:39 --> Config Class Initialized
INFO - 2017-02-08 12:05:39 --> Config Class Initialized
INFO - 2017-02-08 12:05:39 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:39 --> Config Class Initialized
INFO - 2017-02-08 12:05:39 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:05:39 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:39 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:39 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:05:39 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:39 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:05:39 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:05:39 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:39 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:39 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:39 --> URI Class Initialized
INFO - 2017-02-08 12:05:39 --> URI Class Initialized
INFO - 2017-02-08 12:05:39 --> URI Class Initialized
DEBUG - 2017-02-08 12:05:39 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:39 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:39 --> URI Class Initialized
INFO - 2017-02-08 12:05:39 --> Router Class Initialized
INFO - 2017-02-08 12:05:39 --> Router Class Initialized
INFO - 2017-02-08 12:05:39 --> Router Class Initialized
INFO - 2017-02-08 12:05:39 --> Output Class Initialized
INFO - 2017-02-08 12:05:39 --> Output Class Initialized
INFO - 2017-02-08 12:05:39 --> Output Class Initialized
INFO - 2017-02-08 12:05:39 --> Router Class Initialized
INFO - 2017-02-08 12:05:39 --> Security Class Initialized
INFO - 2017-02-08 12:05:39 --> Security Class Initialized
INFO - 2017-02-08 12:05:39 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:39 --> Input Class Initialized
DEBUG - 2017-02-08 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:39 --> Output Class Initialized
DEBUG - 2017-02-08 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:39 --> Input Class Initialized
INFO - 2017-02-08 12:05:39 --> Input Class Initialized
INFO - 2017-02-08 12:05:39 --> Language Class Initialized
INFO - 2017-02-08 12:05:39 --> Language Class Initialized
INFO - 2017-02-08 12:05:39 --> Language Class Initialized
INFO - 2017-02-08 12:05:39 --> Security Class Initialized
ERROR - 2017-02-08 12:05:39 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:05:39 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:05:39 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:39 --> Input Class Initialized
INFO - 2017-02-08 12:05:39 --> Language Class Initialized
ERROR - 2017-02-08 12:05:39 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:39 --> URI Class Initialized
INFO - 2017-02-08 12:05:39 --> Config Class Initialized
INFO - 2017-02-08 12:05:39 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:05:39 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:39 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:39 --> Config Class Initialized
INFO - 2017-02-08 12:05:39 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:39 --> URI Class Initialized
DEBUG - 2017-02-08 12:05:39 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:39 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:39 --> URI Class Initialized
INFO - 2017-02-08 12:05:39 --> Router Class Initialized
INFO - 2017-02-08 12:05:39 --> Router Class Initialized
INFO - 2017-02-08 12:05:39 --> Output Class Initialized
INFO - 2017-02-08 12:05:39 --> Security Class Initialized
INFO - 2017-02-08 12:05:39 --> Output Class Initialized
DEBUG - 2017-02-08 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:39 --> Input Class Initialized
INFO - 2017-02-08 12:05:39 --> Security Class Initialized
INFO - 2017-02-08 12:05:39 --> Language Class Initialized
ERROR - 2017-02-08 12:05:39 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:39 --> Input Class Initialized
INFO - 2017-02-08 12:05:39 --> Config Class Initialized
INFO - 2017-02-08 12:05:39 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:39 --> Router Class Initialized
INFO - 2017-02-08 12:05:39 --> Language Class Initialized
DEBUG - 2017-02-08 12:05:39 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:39 --> Utf8 Class Initialized
ERROR - 2017-02-08 12:05:39 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:39 --> Config Class Initialized
INFO - 2017-02-08 12:05:39 --> URI Class Initialized
INFO - 2017-02-08 12:05:39 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:39 --> Output Class Initialized
INFO - 2017-02-08 12:05:39 --> Router Class Initialized
INFO - 2017-02-08 12:05:39 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:39 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:39 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:39 --> URI Class Initialized
INFO - 2017-02-08 12:05:39 --> Output Class Initialized
DEBUG - 2017-02-08 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:39 --> Input Class Initialized
INFO - 2017-02-08 12:05:39 --> Language Class Initialized
INFO - 2017-02-08 12:05:39 --> Security Class Initialized
INFO - 2017-02-08 12:05:39 --> Router Class Initialized
ERROR - 2017-02-08 12:05:39 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:39 --> Input Class Initialized
INFO - 2017-02-08 12:05:39 --> Language Class Initialized
INFO - 2017-02-08 12:05:39 --> Output Class Initialized
ERROR - 2017-02-08 12:05:39 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:39 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:39 --> Input Class Initialized
INFO - 2017-02-08 12:05:39 --> Language Class Initialized
ERROR - 2017-02-08 12:05:39 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:40 --> Config Class Initialized
INFO - 2017-02-08 12:05:40 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:05:40 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:40 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:40 --> URI Class Initialized
INFO - 2017-02-08 12:05:40 --> Router Class Initialized
INFO - 2017-02-08 12:05:40 --> Output Class Initialized
INFO - 2017-02-08 12:05:40 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:40 --> Input Class Initialized
INFO - 2017-02-08 12:05:40 --> Language Class Initialized
INFO - 2017-02-08 12:05:40 --> Language Class Initialized
INFO - 2017-02-08 12:05:40 --> Config Class Initialized
INFO - 2017-02-08 12:05:40 --> Loader Class Initialized
INFO - 2017-02-08 12:05:40 --> Helper loaded: form_helper
INFO - 2017-02-08 12:05:40 --> Helper loaded: url_helper
INFO - 2017-02-08 12:05:40 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:05:40 --> Database Driver Class Initialized
INFO - 2017-02-08 12:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:05:40 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:05:40 --> Template Class Initialized
INFO - 2017-02-08 12:05:40 --> Controller Class Initialized
DEBUG - 2017-02-08 12:05:40 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:05:40 --> Helper loaded: cookie_helper
DEBUG - 2017-02-08 12:05:40 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
ERROR - 2017-02-08 12:05:40 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 11
DEBUG - 2017-02-08 12:05:40 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:05:40 --> Final output sent to browser
DEBUG - 2017-02-08 12:05:40 --> Total execution time: 0.0596
INFO - 2017-02-08 12:05:40 --> Config Class Initialized
INFO - 2017-02-08 12:05:40 --> Config Class Initialized
INFO - 2017-02-08 12:05:40 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:40 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:05:40 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:40 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:05:40 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:40 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:40 --> URI Class Initialized
INFO - 2017-02-08 12:05:40 --> URI Class Initialized
INFO - 2017-02-08 12:05:41 --> Router Class Initialized
INFO - 2017-02-08 12:05:41 --> Router Class Initialized
INFO - 2017-02-08 12:05:41 --> Output Class Initialized
INFO - 2017-02-08 12:05:41 --> Output Class Initialized
INFO - 2017-02-08 12:05:41 --> Security Class Initialized
INFO - 2017-02-08 12:05:41 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:41 --> Input Class Initialized
DEBUG - 2017-02-08 12:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:41 --> Input Class Initialized
INFO - 2017-02-08 12:05:41 --> Language Class Initialized
INFO - 2017-02-08 12:05:41 --> Language Class Initialized
ERROR - 2017-02-08 12:05:41 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:05:41 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:41 --> Config Class Initialized
INFO - 2017-02-08 12:05:41 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:41 --> Config Class Initialized
INFO - 2017-02-08 12:05:41 --> Config Class Initialized
INFO - 2017-02-08 12:05:41 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:41 --> Config Class Initialized
INFO - 2017-02-08 12:05:41 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:41 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:05:41 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:41 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:41 --> URI Class Initialized
DEBUG - 2017-02-08 12:05:41 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:05:41 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:41 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:05:41 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:41 --> Router Class Initialized
INFO - 2017-02-08 12:05:41 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:41 --> URI Class Initialized
INFO - 2017-02-08 12:05:41 --> URI Class Initialized
INFO - 2017-02-08 12:05:41 --> Output Class Initialized
INFO - 2017-02-08 12:05:41 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:41 --> Router Class Initialized
INFO - 2017-02-08 12:05:41 --> Input Class Initialized
INFO - 2017-02-08 12:05:41 --> Language Class Initialized
ERROR - 2017-02-08 12:05:41 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:41 --> Output Class Initialized
INFO - 2017-02-08 12:05:41 --> Router Class Initialized
INFO - 2017-02-08 12:05:41 --> Security Class Initialized
INFO - 2017-02-08 12:05:41 --> Config Class Initialized
INFO - 2017-02-08 12:05:41 --> Config Class Initialized
INFO - 2017-02-08 12:05:41 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:41 --> Config Class Initialized
INFO - 2017-02-08 12:05:41 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:41 --> Output Class Initialized
DEBUG - 2017-02-08 12:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:41 --> Input Class Initialized
DEBUG - 2017-02-08 12:05:41 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:41 --> Security Class Initialized
INFO - 2017-02-08 12:05:41 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:41 --> Language Class Initialized
INFO - 2017-02-08 12:05:41 --> URI Class Initialized
ERROR - 2017-02-08 12:05:41 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-08 12:05:41 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:05:41 --> Input Class Initialized
INFO - 2017-02-08 12:05:41 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:41 --> Language Class Initialized
INFO - 2017-02-08 12:05:41 --> URI Class Initialized
INFO - 2017-02-08 12:05:41 --> Router Class Initialized
ERROR - 2017-02-08 12:05:41 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:41 --> Output Class Initialized
INFO - 2017-02-08 12:05:41 --> Router Class Initialized
INFO - 2017-02-08 12:05:41 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:41 --> Output Class Initialized
INFO - 2017-02-08 12:05:41 --> Hooks Class Initialized
INFO - 2017-02-08 12:05:41 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:41 --> Input Class Initialized
INFO - 2017-02-08 12:05:41 --> URI Class Initialized
INFO - 2017-02-08 12:05:41 --> Security Class Initialized
INFO - 2017-02-08 12:05:41 --> Language Class Initialized
DEBUG - 2017-02-08 12:05:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-08 12:05:41 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:41 --> Input Class Initialized
INFO - 2017-02-08 12:05:41 --> Language Class Initialized
INFO - 2017-02-08 12:05:41 --> Router Class Initialized
DEBUG - 2017-02-08 12:05:41 --> UTF-8 Support Enabled
ERROR - 2017-02-08 12:05:41 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:41 --> Utf8 Class Initialized
INFO - 2017-02-08 12:05:41 --> Output Class Initialized
INFO - 2017-02-08 12:05:41 --> URI Class Initialized
INFO - 2017-02-08 12:05:41 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:41 --> Input Class Initialized
INFO - 2017-02-08 12:05:41 --> Language Class Initialized
ERROR - 2017-02-08 12:05:41 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:05:41 --> Router Class Initialized
INFO - 2017-02-08 12:05:41 --> Output Class Initialized
INFO - 2017-02-08 12:05:41 --> Security Class Initialized
DEBUG - 2017-02-08 12:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:05:41 --> Input Class Initialized
INFO - 2017-02-08 12:05:41 --> Language Class Initialized
ERROR - 2017-02-08 12:05:41 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:02 --> Config Class Initialized
INFO - 2017-02-08 12:06:02 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:06:02 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:02 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:02 --> URI Class Initialized
INFO - 2017-02-08 12:06:02 --> Router Class Initialized
INFO - 2017-02-08 12:06:02 --> Output Class Initialized
INFO - 2017-02-08 12:06:02 --> Security Class Initialized
DEBUG - 2017-02-08 12:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:02 --> Input Class Initialized
INFO - 2017-02-08 12:06:02 --> Language Class Initialized
INFO - 2017-02-08 12:06:02 --> Language Class Initialized
INFO - 2017-02-08 12:06:02 --> Config Class Initialized
INFO - 2017-02-08 12:06:02 --> Loader Class Initialized
INFO - 2017-02-08 12:06:02 --> Helper loaded: form_helper
INFO - 2017-02-08 12:06:02 --> Helper loaded: url_helper
INFO - 2017-02-08 12:06:02 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:06:02 --> Database Driver Class Initialized
INFO - 2017-02-08 12:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:06:02 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:06:02 --> Template Class Initialized
INFO - 2017-02-08 12:06:02 --> Controller Class Initialized
DEBUG - 2017-02-08 12:06:02 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:06:02 --> Helper loaded: cookie_helper
DEBUG - 2017-02-08 12:06:02 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
ERROR - 2017-02-08 12:06:02 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 11
DEBUG - 2017-02-08 12:06:02 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:06:02 --> Final output sent to browser
DEBUG - 2017-02-08 12:06:02 --> Total execution time: 0.0416
INFO - 2017-02-08 12:06:02 --> Config Class Initialized
INFO - 2017-02-08 12:06:02 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:02 --> Config Class Initialized
INFO - 2017-02-08 12:06:02 --> Config Class Initialized
INFO - 2017-02-08 12:06:02 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:06:02 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:02 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:06:02 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:02 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:02 --> URI Class Initialized
INFO - 2017-02-08 12:06:02 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:02 --> Router Class Initialized
DEBUG - 2017-02-08 12:06:02 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:02 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:02 --> Output Class Initialized
INFO - 2017-02-08 12:06:02 --> URI Class Initialized
INFO - 2017-02-08 12:06:02 --> Security Class Initialized
DEBUG - 2017-02-08 12:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:02 --> Input Class Initialized
INFO - 2017-02-08 12:06:02 --> Language Class Initialized
INFO - 2017-02-08 12:06:02 --> Router Class Initialized
ERROR - 2017-02-08 12:06:02 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:02 --> Output Class Initialized
INFO - 2017-02-08 12:06:02 --> Security Class Initialized
INFO - 2017-02-08 12:06:02 --> URI Class Initialized
INFO - 2017-02-08 12:06:02 --> Router Class Initialized
DEBUG - 2017-02-08 12:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:02 --> Input Class Initialized
INFO - 2017-02-08 12:06:02 --> Output Class Initialized
INFO - 2017-02-08 12:06:02 --> Config Class Initialized
INFO - 2017-02-08 12:06:02 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:02 --> Config Class Initialized
INFO - 2017-02-08 12:06:02 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:02 --> Language Class Initialized
INFO - 2017-02-08 12:06:02 --> Config Class Initialized
INFO - 2017-02-08 12:06:02 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:06:02 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:02 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:06:02 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:02 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:02 --> URI Class Initialized
INFO - 2017-02-08 12:06:02 --> URI Class Initialized
DEBUG - 2017-02-08 12:06:02 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:02 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:02 --> URI Class Initialized
INFO - 2017-02-08 12:06:02 --> Router Class Initialized
INFO - 2017-02-08 12:06:02 --> Router Class Initialized
ERROR - 2017-02-08 12:06:02 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:02 --> Output Class Initialized
INFO - 2017-02-08 12:06:02 --> Security Class Initialized
DEBUG - 2017-02-08 12:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:02 --> Input Class Initialized
INFO - 2017-02-08 12:06:02 --> Language Class Initialized
ERROR - 2017-02-08 12:06:02 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:02 --> Config Class Initialized
INFO - 2017-02-08 12:06:02 --> Config Class Initialized
INFO - 2017-02-08 12:06:02 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:02 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:02 --> Router Class Initialized
INFO - 2017-02-08 12:06:02 --> Output Class Initialized
DEBUG - 2017-02-08 12:06:02 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:06:02 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:02 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:02 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:02 --> Config Class Initialized
INFO - 2017-02-08 12:06:02 --> Security Class Initialized
INFO - 2017-02-08 12:06:02 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:02 --> URI Class Initialized
DEBUG - 2017-02-08 12:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:02 --> Input Class Initialized
INFO - 2017-02-08 12:06:02 --> Language Class Initialized
INFO - 2017-02-08 12:06:02 --> Output Class Initialized
ERROR - 2017-02-08 12:06:02 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:02 --> Router Class Initialized
INFO - 2017-02-08 12:06:02 --> Security Class Initialized
INFO - 2017-02-08 12:06:02 --> Output Class Initialized
DEBUG - 2017-02-08 12:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:02 --> Security Class Initialized
INFO - 2017-02-08 12:06:02 --> Security Class Initialized
INFO - 2017-02-08 12:06:02 --> URI Class Initialized
DEBUG - 2017-02-08 12:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-08 12:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:02 --> Input Class Initialized
INFO - 2017-02-08 12:06:02 --> Input Class Initialized
INFO - 2017-02-08 12:06:02 --> Language Class Initialized
INFO - 2017-02-08 12:06:02 --> Language Class Initialized
ERROR - 2017-02-08 12:06:02 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:06:02 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:06:02 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:02 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:02 --> Input Class Initialized
INFO - 2017-02-08 12:06:02 --> URI Class Initialized
INFO - 2017-02-08 12:06:02 --> Language Class Initialized
ERROR - 2017-02-08 12:06:02 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:02 --> Router Class Initialized
INFO - 2017-02-08 12:06:02 --> Router Class Initialized
INFO - 2017-02-08 12:06:02 --> Output Class Initialized
INFO - 2017-02-08 12:06:02 --> Output Class Initialized
INFO - 2017-02-08 12:06:02 --> Security Class Initialized
INFO - 2017-02-08 12:06:02 --> Security Class Initialized
DEBUG - 2017-02-08 12:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-08 12:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:02 --> Input Class Initialized
INFO - 2017-02-08 12:06:02 --> Input Class Initialized
INFO - 2017-02-08 12:06:02 --> Language Class Initialized
INFO - 2017-02-08 12:06:02 --> Language Class Initialized
ERROR - 2017-02-08 12:06:02 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:06:02 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:03 --> Config Class Initialized
INFO - 2017-02-08 12:06:03 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:06:03 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:03 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:03 --> URI Class Initialized
INFO - 2017-02-08 12:06:03 --> Router Class Initialized
INFO - 2017-02-08 12:06:03 --> Output Class Initialized
INFO - 2017-02-08 12:06:03 --> Security Class Initialized
DEBUG - 2017-02-08 12:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:03 --> Input Class Initialized
INFO - 2017-02-08 12:06:03 --> Language Class Initialized
INFO - 2017-02-08 12:06:03 --> Language Class Initialized
INFO - 2017-02-08 12:06:03 --> Config Class Initialized
INFO - 2017-02-08 12:06:03 --> Loader Class Initialized
INFO - 2017-02-08 12:06:03 --> Helper loaded: form_helper
INFO - 2017-02-08 12:06:03 --> Helper loaded: url_helper
INFO - 2017-02-08 12:06:03 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:06:03 --> Database Driver Class Initialized
INFO - 2017-02-08 12:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:06:03 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:06:03 --> Template Class Initialized
INFO - 2017-02-08 12:06:03 --> Controller Class Initialized
DEBUG - 2017-02-08 12:06:03 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:06:03 --> Helper loaded: cookie_helper
DEBUG - 2017-02-08 12:06:04 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
ERROR - 2017-02-08 12:06:04 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\mobile\application\themes\default_theme\views\layouts\backend.php 11
DEBUG - 2017-02-08 12:06:04 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:06:04 --> Final output sent to browser
DEBUG - 2017-02-08 12:06:04 --> Total execution time: 0.1715
INFO - 2017-02-08 12:06:04 --> Config Class Initialized
INFO - 2017-02-08 12:06:04 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:04 --> Config Class Initialized
INFO - 2017-02-08 12:06:04 --> Config Class Initialized
INFO - 2017-02-08 12:06:04 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:04 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:06:04 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:06:04 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:06:04 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:04 --> Config Class Initialized
INFO - 2017-02-08 12:06:04 --> Config Class Initialized
INFO - 2017-02-08 12:06:04 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:04 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:04 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:04 --> URI Class Initialized
INFO - 2017-02-08 12:06:04 --> URI Class Initialized
INFO - 2017-02-08 12:06:04 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:04 --> Router Class Initialized
DEBUG - 2017-02-08 12:06:04 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:04 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:04 --> Output Class Initialized
INFO - 2017-02-08 12:06:04 --> URI Class Initialized
INFO - 2017-02-08 12:06:04 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:04 --> Security Class Initialized
INFO - 2017-02-08 12:06:04 --> URI Class Initialized
DEBUG - 2017-02-08 12:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:04 --> Input Class Initialized
INFO - 2017-02-08 12:06:04 --> Language Class Initialized
INFO - 2017-02-08 12:06:04 --> Router Class Initialized
INFO - 2017-02-08 12:06:04 --> Router Class Initialized
ERROR - 2017-02-08 12:06:04 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:04 --> Router Class Initialized
INFO - 2017-02-08 12:06:04 --> Output Class Initialized
INFO - 2017-02-08 12:06:04 --> Config Class Initialized
INFO - 2017-02-08 12:06:04 --> Security Class Initialized
INFO - 2017-02-08 12:06:04 --> Output Class Initialized
INFO - 2017-02-08 12:06:04 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:04 --> Output Class Initialized
INFO - 2017-02-08 12:06:04 --> Security Class Initialized
DEBUG - 2017-02-08 12:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:04 --> Input Class Initialized
DEBUG - 2017-02-08 12:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:04 --> Language Class Initialized
INFO - 2017-02-08 12:06:04 --> Input Class Initialized
INFO - 2017-02-08 12:06:04 --> Language Class Initialized
ERROR - 2017-02-08 12:06:04 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:06:04 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:04 --> Config Class Initialized
INFO - 2017-02-08 12:06:04 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:06:04 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:04 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:04 --> URI Class Initialized
INFO - 2017-02-08 12:06:04 --> Config Class Initialized
INFO - 2017-02-08 12:06:04 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:04 --> Config Class Initialized
INFO - 2017-02-08 12:06:04 --> Router Class Initialized
INFO - 2017-02-08 12:06:04 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:06:04 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:04 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:06:04 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:04 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:04 --> URI Class Initialized
INFO - 2017-02-08 12:06:04 --> Output Class Initialized
INFO - 2017-02-08 12:06:04 --> URI Class Initialized
DEBUG - 2017-02-08 12:06:04 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:04 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:04 --> Security Class Initialized
INFO - 2017-02-08 12:06:04 --> URI Class Initialized
INFO - 2017-02-08 12:06:04 --> Router Class Initialized
DEBUG - 2017-02-08 12:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:04 --> Router Class Initialized
INFO - 2017-02-08 12:06:04 --> Input Class Initialized
INFO - 2017-02-08 12:06:04 --> Output Class Initialized
INFO - 2017-02-08 12:06:04 --> Language Class Initialized
INFO - 2017-02-08 12:06:04 --> Security Class Initialized
INFO - 2017-02-08 12:06:04 --> Router Class Initialized
ERROR - 2017-02-08 12:06:04 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:04 --> Output Class Initialized
DEBUG - 2017-02-08 12:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:04 --> Input Class Initialized
INFO - 2017-02-08 12:06:04 --> Language Class Initialized
INFO - 2017-02-08 12:06:04 --> Output Class Initialized
ERROR - 2017-02-08 12:06:04 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:04 --> Security Class Initialized
INFO - 2017-02-08 12:06:04 --> Security Class Initialized
DEBUG - 2017-02-08 12:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:04 --> Input Class Initialized
DEBUG - 2017-02-08 12:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:04 --> Input Class Initialized
INFO - 2017-02-08 12:06:04 --> Language Class Initialized
INFO - 2017-02-08 12:06:04 --> Language Class Initialized
ERROR - 2017-02-08 12:06:04 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:06:04 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:04 --> Security Class Initialized
DEBUG - 2017-02-08 12:06:04 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:04 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:04 --> Input Class Initialized
INFO - 2017-02-08 12:06:04 --> URI Class Initialized
INFO - 2017-02-08 12:06:04 --> Language Class Initialized
ERROR - 2017-02-08 12:06:04 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:04 --> Router Class Initialized
INFO - 2017-02-08 12:06:04 --> Output Class Initialized
INFO - 2017-02-08 12:06:04 --> Security Class Initialized
DEBUG - 2017-02-08 12:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:04 --> Input Class Initialized
INFO - 2017-02-08 12:06:04 --> Language Class Initialized
ERROR - 2017-02-08 12:06:04 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:29 --> Config Class Initialized
INFO - 2017-02-08 12:06:29 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:06:29 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:29 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:29 --> URI Class Initialized
INFO - 2017-02-08 12:06:29 --> Router Class Initialized
INFO - 2017-02-08 12:06:29 --> Output Class Initialized
INFO - 2017-02-08 12:06:29 --> Security Class Initialized
DEBUG - 2017-02-08 12:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:29 --> Input Class Initialized
INFO - 2017-02-08 12:06:29 --> Language Class Initialized
INFO - 2017-02-08 12:06:29 --> Language Class Initialized
INFO - 2017-02-08 12:06:29 --> Config Class Initialized
INFO - 2017-02-08 12:06:29 --> Loader Class Initialized
INFO - 2017-02-08 12:06:29 --> Helper loaded: form_helper
INFO - 2017-02-08 12:06:29 --> Helper loaded: url_helper
INFO - 2017-02-08 12:06:29 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:06:29 --> Database Driver Class Initialized
INFO - 2017-02-08 12:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:06:29 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:06:29 --> Template Class Initialized
INFO - 2017-02-08 12:06:29 --> Controller Class Initialized
DEBUG - 2017-02-08 12:06:29 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:06:29 --> Helper loaded: cookie_helper
DEBUG - 2017-02-08 12:06:29 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-08 12:06:29 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:06:29 --> Final output sent to browser
DEBUG - 2017-02-08 12:06:29 --> Total execution time: 0.0612
INFO - 2017-02-08 12:06:29 --> Config Class Initialized
INFO - 2017-02-08 12:06:29 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:29 --> Config Class Initialized
INFO - 2017-02-08 12:06:29 --> Config Class Initialized
INFO - 2017-02-08 12:06:29 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:29 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:06:29 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:06:29 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:29 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:29 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:06:29 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:29 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:29 --> URI Class Initialized
INFO - 2017-02-08 12:06:29 --> URI Class Initialized
INFO - 2017-02-08 12:06:29 --> URI Class Initialized
INFO - 2017-02-08 12:06:29 --> Router Class Initialized
INFO - 2017-02-08 12:06:29 --> Router Class Initialized
INFO - 2017-02-08 12:06:29 --> Router Class Initialized
INFO - 2017-02-08 12:06:29 --> Output Class Initialized
INFO - 2017-02-08 12:06:29 --> Output Class Initialized
INFO - 2017-02-08 12:06:29 --> Output Class Initialized
INFO - 2017-02-08 12:06:29 --> Security Class Initialized
INFO - 2017-02-08 12:06:29 --> Security Class Initialized
INFO - 2017-02-08 12:06:29 --> Security Class Initialized
DEBUG - 2017-02-08 12:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:29 --> Input Class Initialized
DEBUG - 2017-02-08 12:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:29 --> Input Class Initialized
DEBUG - 2017-02-08 12:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:29 --> Language Class Initialized
INFO - 2017-02-08 12:06:29 --> Input Class Initialized
INFO - 2017-02-08 12:06:29 --> Language Class Initialized
INFO - 2017-02-08 12:06:29 --> Language Class Initialized
ERROR - 2017-02-08 12:06:29 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:06:29 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:29 --> Config Class Initialized
INFO - 2017-02-08 12:06:29 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:29 --> Config Class Initialized
INFO - 2017-02-08 12:06:29 --> Config Class Initialized
INFO - 2017-02-08 12:06:29 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:29 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:06:29 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:29 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:06:29 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:06:29 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:29 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:29 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:29 --> URI Class Initialized
INFO - 2017-02-08 12:06:29 --> URI Class Initialized
INFO - 2017-02-08 12:06:29 --> URI Class Initialized
ERROR - 2017-02-08 12:06:29 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:29 --> Router Class Initialized
INFO - 2017-02-08 12:06:29 --> Router Class Initialized
INFO - 2017-02-08 12:06:29 --> Router Class Initialized
INFO - 2017-02-08 12:06:29 --> Output Class Initialized
INFO - 2017-02-08 12:06:29 --> Output Class Initialized
INFO - 2017-02-08 12:06:29 --> Security Class Initialized
INFO - 2017-02-08 12:06:29 --> Output Class Initialized
INFO - 2017-02-08 12:06:29 --> Security Class Initialized
DEBUG - 2017-02-08 12:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:29 --> Config Class Initialized
INFO - 2017-02-08 12:06:29 --> Input Class Initialized
INFO - 2017-02-08 12:06:29 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:29 --> Security Class Initialized
INFO - 2017-02-08 12:06:29 --> Language Class Initialized
INFO - 2017-02-08 12:06:29 --> Input Class Initialized
DEBUG - 2017-02-08 12:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:29 --> Input Class Initialized
ERROR - 2017-02-08 12:06:29 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:06:29 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:29 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:29 --> Language Class Initialized
INFO - 2017-02-08 12:06:29 --> Language Class Initialized
INFO - 2017-02-08 12:06:29 --> URI Class Initialized
ERROR - 2017-02-08 12:06:29 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:06:29 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:29 --> Router Class Initialized
INFO - 2017-02-08 12:06:29 --> Output Class Initialized
INFO - 2017-02-08 12:06:29 --> Security Class Initialized
INFO - 2017-02-08 12:06:29 --> Config Class Initialized
DEBUG - 2017-02-08 12:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:29 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:29 --> Input Class Initialized
INFO - 2017-02-08 12:06:29 --> Language Class Initialized
ERROR - 2017-02-08 12:06:29 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:06:29 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:29 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:29 --> URI Class Initialized
INFO - 2017-02-08 12:06:29 --> Router Class Initialized
INFO - 2017-02-08 12:06:29 --> Output Class Initialized
INFO - 2017-02-08 12:06:29 --> Security Class Initialized
INFO - 2017-02-08 12:06:29 --> Config Class Initialized
INFO - 2017-02-08 12:06:29 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:29 --> Input Class Initialized
INFO - 2017-02-08 12:06:29 --> Language Class Initialized
ERROR - 2017-02-08 12:06:29 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:06:29 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:29 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:29 --> URI Class Initialized
INFO - 2017-02-08 12:06:29 --> Router Class Initialized
INFO - 2017-02-08 12:06:29 --> Output Class Initialized
INFO - 2017-02-08 12:06:29 --> Security Class Initialized
DEBUG - 2017-02-08 12:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:29 --> Input Class Initialized
INFO - 2017-02-08 12:06:29 --> Language Class Initialized
ERROR - 2017-02-08 12:06:29 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:30 --> Config Class Initialized
INFO - 2017-02-08 12:06:30 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:06:30 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:30 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:30 --> URI Class Initialized
INFO - 2017-02-08 12:06:30 --> Router Class Initialized
INFO - 2017-02-08 12:06:30 --> Output Class Initialized
INFO - 2017-02-08 12:06:30 --> Security Class Initialized
DEBUG - 2017-02-08 12:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:30 --> Input Class Initialized
INFO - 2017-02-08 12:06:30 --> Language Class Initialized
INFO - 2017-02-08 12:06:30 --> Language Class Initialized
INFO - 2017-02-08 12:06:30 --> Config Class Initialized
INFO - 2017-02-08 12:06:30 --> Loader Class Initialized
INFO - 2017-02-08 12:06:30 --> Helper loaded: form_helper
INFO - 2017-02-08 12:06:30 --> Helper loaded: url_helper
INFO - 2017-02-08 12:06:30 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:06:30 --> Database Driver Class Initialized
INFO - 2017-02-08 12:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:06:30 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:06:30 --> Template Class Initialized
INFO - 2017-02-08 12:06:30 --> Controller Class Initialized
DEBUG - 2017-02-08 12:06:30 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:06:30 --> Helper loaded: cookie_helper
DEBUG - 2017-02-08 12:06:30 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-08 12:06:30 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:06:30 --> Final output sent to browser
DEBUG - 2017-02-08 12:06:30 --> Total execution time: 0.0434
INFO - 2017-02-08 12:06:30 --> Config Class Initialized
INFO - 2017-02-08 12:06:30 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:30 --> Config Class Initialized
INFO - 2017-02-08 12:06:30 --> Config Class Initialized
INFO - 2017-02-08 12:06:30 --> Config Class Initialized
INFO - 2017-02-08 12:06:30 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:30 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:30 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:06:30 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:30 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:06:30 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:30 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:06:30 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:30 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:30 --> URI Class Initialized
INFO - 2017-02-08 12:06:30 --> URI Class Initialized
INFO - 2017-02-08 12:06:30 --> URI Class Initialized
INFO - 2017-02-08 12:06:30 --> Router Class Initialized
INFO - 2017-02-08 12:06:30 --> Router Class Initialized
INFO - 2017-02-08 12:06:30 --> Router Class Initialized
INFO - 2017-02-08 12:06:30 --> Output Class Initialized
INFO - 2017-02-08 12:06:30 --> Output Class Initialized
INFO - 2017-02-08 12:06:30 --> Output Class Initialized
INFO - 2017-02-08 12:06:30 --> Security Class Initialized
INFO - 2017-02-08 12:06:30 --> Security Class Initialized
INFO - 2017-02-08 12:06:30 --> Security Class Initialized
DEBUG - 2017-02-08 12:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:30 --> Input Class Initialized
DEBUG - 2017-02-08 12:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:30 --> Input Class Initialized
INFO - 2017-02-08 12:06:30 --> Language Class Initialized
INFO - 2017-02-08 12:06:30 --> Language Class Initialized
DEBUG - 2017-02-08 12:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:30 --> Input Class Initialized
ERROR - 2017-02-08 12:06:30 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:06:30 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:30 --> Language Class Initialized
ERROR - 2017-02-08 12:06:30 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:30 --> Config Class Initialized
INFO - 2017-02-08 12:06:30 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:06:30 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:30 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:06:30 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:30 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:30 --> URI Class Initialized
INFO - 2017-02-08 12:06:30 --> Config Class Initialized
INFO - 2017-02-08 12:06:30 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:30 --> Router Class Initialized
DEBUG - 2017-02-08 12:06:30 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:30 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:30 --> Output Class Initialized
INFO - 2017-02-08 12:06:30 --> URI Class Initialized
INFO - 2017-02-08 12:06:30 --> Config Class Initialized
INFO - 2017-02-08 12:06:30 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:30 --> Security Class Initialized
INFO - 2017-02-08 12:06:30 --> Router Class Initialized
DEBUG - 2017-02-08 12:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:30 --> Input Class Initialized
INFO - 2017-02-08 12:06:30 --> Output Class Initialized
INFO - 2017-02-08 12:06:30 --> Language Class Initialized
DEBUG - 2017-02-08 12:06:30 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:30 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:30 --> Security Class Initialized
INFO - 2017-02-08 12:06:30 --> URI Class Initialized
DEBUG - 2017-02-08 12:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:30 --> Input Class Initialized
INFO - 2017-02-08 12:06:30 --> Language Class Initialized
ERROR - 2017-02-08 12:06:30 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:06:30 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:30 --> Router Class Initialized
INFO - 2017-02-08 12:06:30 --> URI Class Initialized
INFO - 2017-02-08 12:06:30 --> Output Class Initialized
INFO - 2017-02-08 12:06:30 --> Config Class Initialized
INFO - 2017-02-08 12:06:30 --> Hooks Class Initialized
INFO - 2017-02-08 12:06:30 --> Security Class Initialized
DEBUG - 2017-02-08 12:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:30 --> Input Class Initialized
INFO - 2017-02-08 12:06:30 --> Router Class Initialized
INFO - 2017-02-08 12:06:30 --> Language Class Initialized
ERROR - 2017-02-08 12:06:30 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:30 --> Output Class Initialized
INFO - 2017-02-08 12:06:30 --> Security Class Initialized
INFO - 2017-02-08 12:06:30 --> Config Class Initialized
INFO - 2017-02-08 12:06:30 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:30 --> Input Class Initialized
INFO - 2017-02-08 12:06:30 --> Language Class Initialized
ERROR - 2017-02-08 12:06:30 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:06:30 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:30 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:06:30 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:06:30 --> Utf8 Class Initialized
INFO - 2017-02-08 12:06:30 --> URI Class Initialized
INFO - 2017-02-08 12:06:30 --> URI Class Initialized
INFO - 2017-02-08 12:06:30 --> Router Class Initialized
INFO - 2017-02-08 12:06:30 --> Output Class Initialized
INFO - 2017-02-08 12:06:30 --> Security Class Initialized
DEBUG - 2017-02-08 12:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:30 --> Input Class Initialized
INFO - 2017-02-08 12:06:30 --> Router Class Initialized
INFO - 2017-02-08 12:06:30 --> Language Class Initialized
ERROR - 2017-02-08 12:06:30 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:06:30 --> Output Class Initialized
INFO - 2017-02-08 12:06:30 --> Security Class Initialized
DEBUG - 2017-02-08 12:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:06:30 --> Input Class Initialized
INFO - 2017-02-08 12:06:30 --> Language Class Initialized
ERROR - 2017-02-08 12:06:30 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:16:36 --> Config Class Initialized
INFO - 2017-02-08 12:16:36 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:16:36 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:16:36 --> Utf8 Class Initialized
INFO - 2017-02-08 12:16:36 --> URI Class Initialized
INFO - 2017-02-08 12:16:36 --> Router Class Initialized
INFO - 2017-02-08 12:16:36 --> Output Class Initialized
INFO - 2017-02-08 12:16:36 --> Security Class Initialized
DEBUG - 2017-02-08 12:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:16:36 --> Input Class Initialized
INFO - 2017-02-08 12:16:36 --> Language Class Initialized
INFO - 2017-02-08 12:16:36 --> Language Class Initialized
INFO - 2017-02-08 12:16:36 --> Config Class Initialized
INFO - 2017-02-08 12:16:36 --> Loader Class Initialized
INFO - 2017-02-08 12:16:36 --> Helper loaded: form_helper
INFO - 2017-02-08 12:16:36 --> Helper loaded: url_helper
INFO - 2017-02-08 12:16:36 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:16:36 --> Database Driver Class Initialized
INFO - 2017-02-08 12:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:16:36 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:16:36 --> Template Class Initialized
INFO - 2017-02-08 12:16:36 --> Controller Class Initialized
DEBUG - 2017-02-08 12:16:36 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:16:36 --> Helper loaded: cookie_helper
DEBUG - 2017-02-08 12:16:36 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-08 12:16:36 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:16:36 --> Final output sent to browser
DEBUG - 2017-02-08 12:16:36 --> Total execution time: 0.0955
INFO - 2017-02-08 12:16:36 --> Config Class Initialized
INFO - 2017-02-08 12:16:36 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:16:36 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:16:36 --> Utf8 Class Initialized
INFO - 2017-02-08 12:16:36 --> URI Class Initialized
INFO - 2017-02-08 12:16:36 --> Config Class Initialized
INFO - 2017-02-08 12:16:36 --> Hooks Class Initialized
INFO - 2017-02-08 12:16:36 --> Router Class Initialized
INFO - 2017-02-08 12:16:36 --> Output Class Initialized
INFO - 2017-02-08 12:16:36 --> Config Class Initialized
DEBUG - 2017-02-08 12:16:36 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:16:36 --> Security Class Initialized
INFO - 2017-02-08 12:16:36 --> Utf8 Class Initialized
INFO - 2017-02-08 12:16:36 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:16:36 --> Input Class Initialized
INFO - 2017-02-08 12:16:36 --> URI Class Initialized
INFO - 2017-02-08 12:16:36 --> Language Class Initialized
ERROR - 2017-02-08 12:16:36 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:16:36 --> Router Class Initialized
INFO - 2017-02-08 12:16:36 --> Output Class Initialized
INFO - 2017-02-08 12:16:36 --> Security Class Initialized
DEBUG - 2017-02-08 12:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:16:36 --> Input Class Initialized
INFO - 2017-02-08 12:16:36 --> Language Class Initialized
ERROR - 2017-02-08 12:16:36 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:16:36 --> Config Class Initialized
INFO - 2017-02-08 12:16:36 --> Hooks Class Initialized
INFO - 2017-02-08 12:16:36 --> Config Class Initialized
INFO - 2017-02-08 12:16:36 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:16:36 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:16:36 --> Config Class Initialized
INFO - 2017-02-08 12:16:36 --> Hooks Class Initialized
INFO - 2017-02-08 12:16:36 --> Config Class Initialized
INFO - 2017-02-08 12:16:36 --> Hooks Class Initialized
INFO - 2017-02-08 12:16:36 --> Config Class Initialized
DEBUG - 2017-02-08 12:16:36 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:16:36 --> Hooks Class Initialized
INFO - 2017-02-08 12:16:36 --> Utf8 Class Initialized
INFO - 2017-02-08 12:16:36 --> URI Class Initialized
DEBUG - 2017-02-08 12:16:36 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:16:36 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:16:36 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:16:36 --> Utf8 Class Initialized
INFO - 2017-02-08 12:16:36 --> URI Class Initialized
INFO - 2017-02-08 12:16:36 --> URI Class Initialized
INFO - 2017-02-08 12:16:36 --> Router Class Initialized
INFO - 2017-02-08 12:16:37 --> Router Class Initialized
INFO - 2017-02-08 12:16:37 --> Output Class Initialized
INFO - 2017-02-08 12:16:37 --> Router Class Initialized
INFO - 2017-02-08 12:16:37 --> Output Class Initialized
INFO - 2017-02-08 12:16:37 --> Security Class Initialized
DEBUG - 2017-02-08 12:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:16:37 --> Security Class Initialized
INFO - 2017-02-08 12:16:37 --> Output Class Initialized
INFO - 2017-02-08 12:16:37 --> Input Class Initialized
INFO - 2017-02-08 12:16:37 --> Language Class Initialized
INFO - 2017-02-08 12:16:37 --> Security Class Initialized
ERROR - 2017-02-08 12:16:37 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:16:37 --> Input Class Initialized
DEBUG - 2017-02-08 12:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:16:37 --> Input Class Initialized
INFO - 2017-02-08 12:16:37 --> Language Class Initialized
INFO - 2017-02-08 12:16:37 --> Language Class Initialized
ERROR - 2017-02-08 12:16:37 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:16:37 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:16:37 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:16:37 --> Utf8 Class Initialized
INFO - 2017-02-08 12:16:37 --> URI Class Initialized
INFO - 2017-02-08 12:16:37 --> Config Class Initialized
INFO - 2017-02-08 12:16:37 --> Hooks Class Initialized
INFO - 2017-02-08 12:16:37 --> Router Class Initialized
DEBUG - 2017-02-08 12:16:37 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:16:37 --> Utf8 Class Initialized
INFO - 2017-02-08 12:16:37 --> Output Class Initialized
INFO - 2017-02-08 12:16:37 --> URI Class Initialized
INFO - 2017-02-08 12:16:37 --> Security Class Initialized
DEBUG - 2017-02-08 12:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:16:37 --> Input Class Initialized
INFO - 2017-02-08 12:16:37 --> Router Class Initialized
INFO - 2017-02-08 12:16:37 --> Language Class Initialized
ERROR - 2017-02-08 12:16:37 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:16:37 --> Output Class Initialized
INFO - 2017-02-08 12:16:37 --> Security Class Initialized
DEBUG - 2017-02-08 12:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:16:37 --> Input Class Initialized
DEBUG - 2017-02-08 12:16:37 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:16:37 --> Utf8 Class Initialized
INFO - 2017-02-08 12:16:37 --> Language Class Initialized
INFO - 2017-02-08 12:16:37 --> URI Class Initialized
ERROR - 2017-02-08 12:16:37 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:16:37 --> Utf8 Class Initialized
INFO - 2017-02-08 12:16:37 --> URI Class Initialized
INFO - 2017-02-08 12:16:37 --> Router Class Initialized
INFO - 2017-02-08 12:16:37 --> Router Class Initialized
INFO - 2017-02-08 12:16:37 --> Output Class Initialized
INFO - 2017-02-08 12:16:37 --> Security Class Initialized
INFO - 2017-02-08 12:16:37 --> Output Class Initialized
DEBUG - 2017-02-08 12:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:16:37 --> Input Class Initialized
INFO - 2017-02-08 12:16:37 --> Security Class Initialized
INFO - 2017-02-08 12:16:37 --> Language Class Initialized
DEBUG - 2017-02-08 12:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:16:37 --> Input Class Initialized
ERROR - 2017-02-08 12:16:37 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:16:37 --> Language Class Initialized
ERROR - 2017-02-08 12:16:37 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:18:00 --> Config Class Initialized
INFO - 2017-02-08 12:18:00 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:18:00 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:18:00 --> Utf8 Class Initialized
INFO - 2017-02-08 12:18:00 --> URI Class Initialized
INFO - 2017-02-08 12:18:00 --> Router Class Initialized
INFO - 2017-02-08 12:18:00 --> Output Class Initialized
INFO - 2017-02-08 12:18:00 --> Security Class Initialized
DEBUG - 2017-02-08 12:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:18:00 --> Input Class Initialized
INFO - 2017-02-08 12:18:00 --> Language Class Initialized
INFO - 2017-02-08 12:18:00 --> Language Class Initialized
INFO - 2017-02-08 12:18:00 --> Config Class Initialized
INFO - 2017-02-08 12:18:00 --> Loader Class Initialized
INFO - 2017-02-08 12:18:00 --> Helper loaded: form_helper
INFO - 2017-02-08 12:18:00 --> Helper loaded: url_helper
INFO - 2017-02-08 12:18:00 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:18:00 --> Database Driver Class Initialized
INFO - 2017-02-08 12:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:18:00 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:18:00 --> Template Class Initialized
INFO - 2017-02-08 12:18:00 --> Controller Class Initialized
DEBUG - 2017-02-08 12:18:00 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:18:00 --> Helper loaded: cookie_helper
DEBUG - 2017-02-08 12:18:00 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-08 12:18:00 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:18:00 --> Final output sent to browser
DEBUG - 2017-02-08 12:18:00 --> Total execution time: 0.0341
INFO - 2017-02-08 12:18:00 --> Config Class Initialized
INFO - 2017-02-08 12:18:00 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:18:00 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:18:00 --> Utf8 Class Initialized
INFO - 2017-02-08 12:18:00 --> Config Class Initialized
INFO - 2017-02-08 12:18:00 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:18:00 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:18:00 --> Utf8 Class Initialized
INFO - 2017-02-08 12:18:00 --> URI Class Initialized
INFO - 2017-02-08 12:18:00 --> Router Class Initialized
INFO - 2017-02-08 12:18:00 --> Output Class Initialized
INFO - 2017-02-08 12:18:00 --> Security Class Initialized
DEBUG - 2017-02-08 12:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:18:00 --> Input Class Initialized
INFO - 2017-02-08 12:18:00 --> Language Class Initialized
INFO - 2017-02-08 12:18:00 --> Config Class Initialized
INFO - 2017-02-08 12:18:00 --> Hooks Class Initialized
ERROR - 2017-02-08 12:18:00 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:18:00 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:18:00 --> Utf8 Class Initialized
INFO - 2017-02-08 12:18:00 --> URI Class Initialized
INFO - 2017-02-08 12:18:00 --> Router Class Initialized
INFO - 2017-02-08 12:18:00 --> Config Class Initialized
INFO - 2017-02-08 12:18:00 --> Hooks Class Initialized
INFO - 2017-02-08 12:18:00 --> Config Class Initialized
INFO - 2017-02-08 12:18:00 --> Hooks Class Initialized
INFO - 2017-02-08 12:18:00 --> Config Class Initialized
INFO - 2017-02-08 12:18:00 --> Hooks Class Initialized
INFO - 2017-02-08 12:18:00 --> Output Class Initialized
DEBUG - 2017-02-08 12:18:00 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:18:00 --> Utf8 Class Initialized
INFO - 2017-02-08 12:18:00 --> Security Class Initialized
DEBUG - 2017-02-08 12:18:00 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:18:00 --> Utf8 Class Initialized
INFO - 2017-02-08 12:18:00 --> URI Class Initialized
DEBUG - 2017-02-08 12:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:18:00 --> URI Class Initialized
INFO - 2017-02-08 12:18:00 --> Input Class Initialized
INFO - 2017-02-08 12:18:00 --> Language Class Initialized
ERROR - 2017-02-08 12:18:00 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:18:00 --> Router Class Initialized
INFO - 2017-02-08 12:18:00 --> Router Class Initialized
INFO - 2017-02-08 12:18:00 --> Config Class Initialized
INFO - 2017-02-08 12:18:00 --> Output Class Initialized
INFO - 2017-02-08 12:18:00 --> Hooks Class Initialized
INFO - 2017-02-08 12:18:00 --> Output Class Initialized
INFO - 2017-02-08 12:18:00 --> Security Class Initialized
INFO - 2017-02-08 12:18:00 --> Security Class Initialized
DEBUG - 2017-02-08 12:18:00 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:18:00 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:18:00 --> Input Class Initialized
DEBUG - 2017-02-08 12:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:18:00 --> Language Class Initialized
INFO - 2017-02-08 12:18:00 --> URI Class Initialized
INFO - 2017-02-08 12:18:00 --> Input Class Initialized
INFO - 2017-02-08 12:18:00 --> URI Class Initialized
INFO - 2017-02-08 12:18:00 --> Language Class Initialized
ERROR - 2017-02-08 12:18:00 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:18:00 --> UTF-8 Support Enabled
ERROR - 2017-02-08 12:18:00 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:18:00 --> Utf8 Class Initialized
INFO - 2017-02-08 12:18:00 --> Router Class Initialized
INFO - 2017-02-08 12:18:00 --> URI Class Initialized
INFO - 2017-02-08 12:18:00 --> Output Class Initialized
INFO - 2017-02-08 12:18:00 --> Security Class Initialized
INFO - 2017-02-08 12:18:00 --> Router Class Initialized
DEBUG - 2017-02-08 12:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:18:00 --> Input Class Initialized
INFO - 2017-02-08 12:18:00 --> Output Class Initialized
INFO - 2017-02-08 12:18:00 --> Language Class Initialized
INFO - 2017-02-08 12:18:00 --> Config Class Initialized
INFO - 2017-02-08 12:18:00 --> Security Class Initialized
INFO - 2017-02-08 12:18:00 --> Hooks Class Initialized
ERROR - 2017-02-08 12:18:00 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:18:00 --> Input Class Initialized
DEBUG - 2017-02-08 12:18:00 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:18:00 --> Utf8 Class Initialized
INFO - 2017-02-08 12:18:00 --> Language Class Initialized
INFO - 2017-02-08 12:18:00 --> URI Class Initialized
ERROR - 2017-02-08 12:18:00 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:18:00 --> Router Class Initialized
INFO - 2017-02-08 12:18:00 --> Output Class Initialized
INFO - 2017-02-08 12:18:00 --> Security Class Initialized
INFO - 2017-02-08 12:18:00 --> Router Class Initialized
DEBUG - 2017-02-08 12:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:18:00 --> Input Class Initialized
INFO - 2017-02-08 12:18:00 --> Output Class Initialized
INFO - 2017-02-08 12:18:00 --> Config Class Initialized
INFO - 2017-02-08 12:18:00 --> Language Class Initialized
INFO - 2017-02-08 12:18:00 --> Hooks Class Initialized
INFO - 2017-02-08 12:18:00 --> Security Class Initialized
ERROR - 2017-02-08 12:18:00 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:18:00 --> Input Class Initialized
DEBUG - 2017-02-08 12:18:00 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:18:00 --> Language Class Initialized
INFO - 2017-02-08 12:18:00 --> Utf8 Class Initialized
ERROR - 2017-02-08 12:18:00 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:18:00 --> URI Class Initialized
INFO - 2017-02-08 12:18:00 --> Router Class Initialized
INFO - 2017-02-08 12:18:00 --> Output Class Initialized
INFO - 2017-02-08 12:18:00 --> Security Class Initialized
DEBUG - 2017-02-08 12:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:18:00 --> Input Class Initialized
INFO - 2017-02-08 12:18:00 --> Language Class Initialized
ERROR - 2017-02-08 12:18:00 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:18:04 --> Config Class Initialized
INFO - 2017-02-08 12:18:04 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:18:04 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:18:04 --> Utf8 Class Initialized
INFO - 2017-02-08 12:18:04 --> URI Class Initialized
INFO - 2017-02-08 12:18:04 --> Router Class Initialized
INFO - 2017-02-08 12:18:04 --> Output Class Initialized
INFO - 2017-02-08 12:18:04 --> Security Class Initialized
DEBUG - 2017-02-08 12:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:18:04 --> Input Class Initialized
INFO - 2017-02-08 12:18:04 --> Language Class Initialized
INFO - 2017-02-08 12:18:04 --> Language Class Initialized
INFO - 2017-02-08 12:18:04 --> Config Class Initialized
INFO - 2017-02-08 12:18:04 --> Loader Class Initialized
INFO - 2017-02-08 12:18:04 --> Helper loaded: form_helper
INFO - 2017-02-08 12:18:04 --> Helper loaded: url_helper
INFO - 2017-02-08 12:18:04 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:18:04 --> Database Driver Class Initialized
INFO - 2017-02-08 12:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:18:04 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:18:04 --> Template Class Initialized
INFO - 2017-02-08 12:18:04 --> Controller Class Initialized
DEBUG - 2017-02-08 12:18:04 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:18:04 --> Helper loaded: cookie_helper
ERROR - 2017-02-08 12:18:04 --> Severity: Notice --> Undefined property: CI::$common_model C:\xampp\htdocs\mobile\application\third_party\MX\Controller.php 62
ERROR - 2017-02-08 12:18:04 --> Severity: Error --> Call to a member function getRecords() on null C:\xampp\htdocs\mobile\application\modules\backend\controllers\Login.php 21
INFO - 2017-02-08 12:18:22 --> Config Class Initialized
INFO - 2017-02-08 12:18:22 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:18:22 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:18:22 --> Utf8 Class Initialized
INFO - 2017-02-08 12:18:22 --> URI Class Initialized
INFO - 2017-02-08 12:18:22 --> Router Class Initialized
INFO - 2017-02-08 12:18:22 --> Output Class Initialized
INFO - 2017-02-08 12:18:22 --> Security Class Initialized
DEBUG - 2017-02-08 12:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:18:22 --> Input Class Initialized
INFO - 2017-02-08 12:18:22 --> Language Class Initialized
INFO - 2017-02-08 12:18:22 --> Language Class Initialized
INFO - 2017-02-08 12:18:22 --> Config Class Initialized
INFO - 2017-02-08 12:18:22 --> Loader Class Initialized
INFO - 2017-02-08 12:18:22 --> Helper loaded: form_helper
INFO - 2017-02-08 12:18:22 --> Helper loaded: url_helper
INFO - 2017-02-08 12:18:22 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:18:22 --> Database Driver Class Initialized
INFO - 2017-02-08 12:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:18:22 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:18:22 --> Template Class Initialized
INFO - 2017-02-08 12:18:22 --> Controller Class Initialized
DEBUG - 2017-02-08 12:18:22 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:18:22 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:18:22 --> Model Class Initialized
INFO - 2017-02-08 12:18:22 --> Model Class Initialized
INFO - 2017-02-08 12:18:22 --> Final output sent to browser
DEBUG - 2017-02-08 12:18:22 --> Total execution time: 0.1805
INFO - 2017-02-08 12:18:25 --> Config Class Initialized
INFO - 2017-02-08 12:18:25 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:18:25 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:18:25 --> Utf8 Class Initialized
INFO - 2017-02-08 12:18:25 --> URI Class Initialized
INFO - 2017-02-08 12:18:25 --> Router Class Initialized
INFO - 2017-02-08 12:18:25 --> Output Class Initialized
INFO - 2017-02-08 12:18:25 --> Security Class Initialized
DEBUG - 2017-02-08 12:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:18:25 --> Input Class Initialized
INFO - 2017-02-08 12:18:25 --> Language Class Initialized
INFO - 2017-02-08 12:18:25 --> Language Class Initialized
INFO - 2017-02-08 12:18:25 --> Config Class Initialized
INFO - 2017-02-08 12:18:25 --> Loader Class Initialized
INFO - 2017-02-08 12:18:25 --> Helper loaded: form_helper
INFO - 2017-02-08 12:18:25 --> Helper loaded: url_helper
INFO - 2017-02-08 12:18:25 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:18:25 --> Database Driver Class Initialized
INFO - 2017-02-08 12:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:18:25 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:18:25 --> Template Class Initialized
INFO - 2017-02-08 12:18:25 --> Controller Class Initialized
DEBUG - 2017-02-08 12:18:25 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:18:25 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:18:25 --> Model Class Initialized
INFO - 2017-02-08 12:18:25 --> Model Class Initialized
INFO - 2017-02-08 12:18:25 --> Final output sent to browser
DEBUG - 2017-02-08 12:18:25 --> Total execution time: 0.0498
INFO - 2017-02-08 12:18:57 --> Config Class Initialized
INFO - 2017-02-08 12:18:57 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:18:57 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:18:57 --> Utf8 Class Initialized
INFO - 2017-02-08 12:18:57 --> URI Class Initialized
INFO - 2017-02-08 12:18:57 --> Router Class Initialized
INFO - 2017-02-08 12:18:57 --> Output Class Initialized
INFO - 2017-02-08 12:18:57 --> Security Class Initialized
DEBUG - 2017-02-08 12:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:18:57 --> Input Class Initialized
INFO - 2017-02-08 12:18:57 --> Language Class Initialized
INFO - 2017-02-08 12:18:57 --> Language Class Initialized
INFO - 2017-02-08 12:18:57 --> Config Class Initialized
INFO - 2017-02-08 12:18:57 --> Loader Class Initialized
INFO - 2017-02-08 12:18:57 --> Helper loaded: form_helper
INFO - 2017-02-08 12:18:57 --> Helper loaded: url_helper
INFO - 2017-02-08 12:18:57 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:18:57 --> Database Driver Class Initialized
INFO - 2017-02-08 12:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:18:57 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:18:57 --> Template Class Initialized
INFO - 2017-02-08 12:18:57 --> Controller Class Initialized
DEBUG - 2017-02-08 12:18:57 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:18:57 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:18:57 --> Model Class Initialized
INFO - 2017-02-08 12:18:57 --> Model Class Initialized
INFO - 2017-02-08 12:18:57 --> Final output sent to browser
DEBUG - 2017-02-08 12:18:57 --> Total execution time: 0.0941
INFO - 2017-02-08 12:18:58 --> Config Class Initialized
INFO - 2017-02-08 12:18:58 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:18:58 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:18:58 --> Utf8 Class Initialized
INFO - 2017-02-08 12:18:58 --> URI Class Initialized
INFO - 2017-02-08 12:18:58 --> Router Class Initialized
INFO - 2017-02-08 12:18:58 --> Output Class Initialized
INFO - 2017-02-08 12:18:58 --> Security Class Initialized
DEBUG - 2017-02-08 12:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:18:58 --> Input Class Initialized
INFO - 2017-02-08 12:18:58 --> Language Class Initialized
INFO - 2017-02-08 12:18:58 --> Language Class Initialized
INFO - 2017-02-08 12:18:58 --> Config Class Initialized
INFO - 2017-02-08 12:18:58 --> Loader Class Initialized
INFO - 2017-02-08 12:18:58 --> Helper loaded: form_helper
INFO - 2017-02-08 12:18:58 --> Helper loaded: url_helper
INFO - 2017-02-08 12:18:58 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:18:58 --> Database Driver Class Initialized
INFO - 2017-02-08 12:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:18:58 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:18:58 --> Template Class Initialized
INFO - 2017-02-08 12:18:58 --> Controller Class Initialized
DEBUG - 2017-02-08 12:18:58 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:18:58 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:18:58 --> Model Class Initialized
INFO - 2017-02-08 12:18:58 --> Model Class Initialized
INFO - 2017-02-08 12:18:58 --> Final output sent to browser
DEBUG - 2017-02-08 12:18:58 --> Total execution time: 0.0449
INFO - 2017-02-08 12:18:59 --> Config Class Initialized
INFO - 2017-02-08 12:18:59 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:18:59 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:18:59 --> Utf8 Class Initialized
INFO - 2017-02-08 12:18:59 --> URI Class Initialized
INFO - 2017-02-08 12:18:59 --> Router Class Initialized
INFO - 2017-02-08 12:18:59 --> Output Class Initialized
INFO - 2017-02-08 12:18:59 --> Security Class Initialized
DEBUG - 2017-02-08 12:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:18:59 --> Input Class Initialized
INFO - 2017-02-08 12:18:59 --> Language Class Initialized
INFO - 2017-02-08 12:18:59 --> Language Class Initialized
INFO - 2017-02-08 12:18:59 --> Config Class Initialized
INFO - 2017-02-08 12:18:59 --> Loader Class Initialized
INFO - 2017-02-08 12:18:59 --> Helper loaded: form_helper
INFO - 2017-02-08 12:18:59 --> Helper loaded: url_helper
INFO - 2017-02-08 12:18:59 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:18:59 --> Database Driver Class Initialized
INFO - 2017-02-08 12:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:18:59 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:18:59 --> Template Class Initialized
INFO - 2017-02-08 12:18:59 --> Controller Class Initialized
DEBUG - 2017-02-08 12:18:59 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:18:59 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:18:59 --> Model Class Initialized
INFO - 2017-02-08 12:18:59 --> Model Class Initialized
INFO - 2017-02-08 12:18:59 --> Final output sent to browser
DEBUG - 2017-02-08 12:18:59 --> Total execution time: 0.1988
INFO - 2017-02-08 12:19:14 --> Config Class Initialized
INFO - 2017-02-08 12:19:14 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:19:14 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:19:14 --> Utf8 Class Initialized
INFO - 2017-02-08 12:19:14 --> URI Class Initialized
INFO - 2017-02-08 12:19:14 --> Router Class Initialized
INFO - 2017-02-08 12:19:14 --> Output Class Initialized
INFO - 2017-02-08 12:19:14 --> Security Class Initialized
DEBUG - 2017-02-08 12:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:19:14 --> Input Class Initialized
INFO - 2017-02-08 12:19:14 --> Language Class Initialized
INFO - 2017-02-08 12:19:14 --> Language Class Initialized
INFO - 2017-02-08 12:19:14 --> Config Class Initialized
INFO - 2017-02-08 12:19:14 --> Loader Class Initialized
INFO - 2017-02-08 12:19:14 --> Helper loaded: form_helper
INFO - 2017-02-08 12:19:14 --> Helper loaded: url_helper
INFO - 2017-02-08 12:19:14 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:19:14 --> Database Driver Class Initialized
INFO - 2017-02-08 12:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:19:14 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:19:14 --> Template Class Initialized
INFO - 2017-02-08 12:19:14 --> Controller Class Initialized
DEBUG - 2017-02-08 12:19:14 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:19:14 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:19:14 --> Model Class Initialized
INFO - 2017-02-08 12:19:14 --> Model Class Initialized
INFO - 2017-02-08 12:20:10 --> Config Class Initialized
INFO - 2017-02-08 12:20:10 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:20:10 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:10 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:10 --> URI Class Initialized
INFO - 2017-02-08 12:20:10 --> Router Class Initialized
INFO - 2017-02-08 12:20:10 --> Output Class Initialized
INFO - 2017-02-08 12:20:10 --> Security Class Initialized
DEBUG - 2017-02-08 12:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:10 --> Input Class Initialized
INFO - 2017-02-08 12:20:10 --> Language Class Initialized
INFO - 2017-02-08 12:20:10 --> Language Class Initialized
INFO - 2017-02-08 12:20:10 --> Config Class Initialized
INFO - 2017-02-08 12:20:10 --> Loader Class Initialized
INFO - 2017-02-08 12:20:10 --> Helper loaded: form_helper
INFO - 2017-02-08 12:20:10 --> Helper loaded: url_helper
INFO - 2017-02-08 12:20:10 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:20:10 --> Database Driver Class Initialized
INFO - 2017-02-08 12:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:20:10 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:20:10 --> Template Class Initialized
INFO - 2017-02-08 12:20:10 --> Controller Class Initialized
DEBUG - 2017-02-08 12:20:10 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:20:10 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:20:10 --> Model Class Initialized
INFO - 2017-02-08 12:20:10 --> Model Class Initialized
DEBUG - 2017-02-08 12:20:10 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-08 12:20:10 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:20:10 --> Final output sent to browser
DEBUG - 2017-02-08 12:20:10 --> Total execution time: 0.0520
INFO - 2017-02-08 12:20:12 --> Config Class Initialized
INFO - 2017-02-08 12:20:12 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:20:12 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:12 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:12 --> URI Class Initialized
INFO - 2017-02-08 12:20:12 --> Router Class Initialized
INFO - 2017-02-08 12:20:12 --> Output Class Initialized
INFO - 2017-02-08 12:20:12 --> Security Class Initialized
DEBUG - 2017-02-08 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:12 --> Input Class Initialized
INFO - 2017-02-08 12:20:12 --> Language Class Initialized
INFO - 2017-02-08 12:20:12 --> Language Class Initialized
INFO - 2017-02-08 12:20:12 --> Config Class Initialized
INFO - 2017-02-08 12:20:12 --> Loader Class Initialized
INFO - 2017-02-08 12:20:12 --> Helper loaded: form_helper
INFO - 2017-02-08 12:20:12 --> Helper loaded: url_helper
INFO - 2017-02-08 12:20:12 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:20:12 --> Database Driver Class Initialized
INFO - 2017-02-08 12:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:20:12 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:20:12 --> Template Class Initialized
INFO - 2017-02-08 12:20:12 --> Controller Class Initialized
DEBUG - 2017-02-08 12:20:12 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:20:12 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:20:12 --> Model Class Initialized
INFO - 2017-02-08 12:20:12 --> Model Class Initialized
DEBUG - 2017-02-08 12:20:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-08 12:20:12 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:20:12 --> Final output sent to browser
DEBUG - 2017-02-08 12:20:12 --> Total execution time: 0.0464
INFO - 2017-02-08 12:20:12 --> Config Class Initialized
INFO - 2017-02-08 12:20:12 --> Hooks Class Initialized
INFO - 2017-02-08 12:20:12 --> Config Class Initialized
INFO - 2017-02-08 12:20:12 --> Hooks Class Initialized
INFO - 2017-02-08 12:20:12 --> Config Class Initialized
INFO - 2017-02-08 12:20:12 --> Hooks Class Initialized
INFO - 2017-02-08 12:20:12 --> Config Class Initialized
INFO - 2017-02-08 12:20:12 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:20:12 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:12 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:20:12 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:20:12 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:12 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:12 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:12 --> URI Class Initialized
INFO - 2017-02-08 12:20:12 --> URI Class Initialized
INFO - 2017-02-08 12:20:12 --> URI Class Initialized
DEBUG - 2017-02-08 12:20:12 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:12 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:12 --> Router Class Initialized
INFO - 2017-02-08 12:20:12 --> Router Class Initialized
INFO - 2017-02-08 12:20:12 --> URI Class Initialized
INFO - 2017-02-08 12:20:12 --> Output Class Initialized
INFO - 2017-02-08 12:20:12 --> Config Class Initialized
INFO - 2017-02-08 12:20:12 --> Output Class Initialized
INFO - 2017-02-08 12:20:12 --> Router Class Initialized
INFO - 2017-02-08 12:20:12 --> Hooks Class Initialized
INFO - 2017-02-08 12:20:12 --> Security Class Initialized
INFO - 2017-02-08 12:20:12 --> Security Class Initialized
DEBUG - 2017-02-08 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:12 --> Input Class Initialized
DEBUG - 2017-02-08 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:12 --> Input Class Initialized
INFO - 2017-02-08 12:20:12 --> Language Class Initialized
INFO - 2017-02-08 12:20:12 --> Language Class Initialized
INFO - 2017-02-08 12:20:12 --> Router Class Initialized
ERROR - 2017-02-08 12:20:12 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:20:12 --> UTF-8 Support Enabled
ERROR - 2017-02-08 12:20:12 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:20:12 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:12 --> URI Class Initialized
INFO - 2017-02-08 12:20:12 --> Output Class Initialized
INFO - 2017-02-08 12:20:12 --> Security Class Initialized
DEBUG - 2017-02-08 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:12 --> Input Class Initialized
INFO - 2017-02-08 12:20:12 --> Router Class Initialized
INFO - 2017-02-08 12:20:12 --> Language Class Initialized
ERROR - 2017-02-08 12:20:12 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:20:12 --> Output Class Initialized
INFO - 2017-02-08 12:20:12 --> Config Class Initialized
INFO - 2017-02-08 12:20:12 --> Config Class Initialized
INFO - 2017-02-08 12:20:12 --> Hooks Class Initialized
INFO - 2017-02-08 12:20:12 --> Hooks Class Initialized
INFO - 2017-02-08 12:20:12 --> Security Class Initialized
INFO - 2017-02-08 12:20:12 --> Config Class Initialized
DEBUG - 2017-02-08 12:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-08 12:20:12 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:12 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:20:12 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:12 --> Input Class Initialized
INFO - 2017-02-08 12:20:12 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:12 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:12 --> URI Class Initialized
INFO - 2017-02-08 12:20:12 --> URI Class Initialized
INFO - 2017-02-08 12:20:12 --> Language Class Initialized
ERROR - 2017-02-08 12:20:12 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:20:12 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:12 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:12 --> Router Class Initialized
INFO - 2017-02-08 12:20:12 --> URI Class Initialized
INFO - 2017-02-08 12:20:12 --> Output Class Initialized
INFO - 2017-02-08 12:20:12 --> Security Class Initialized
DEBUG - 2017-02-08 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:12 --> Input Class Initialized
INFO - 2017-02-08 12:20:12 --> Router Class Initialized
INFO - 2017-02-08 12:20:12 --> Language Class Initialized
ERROR - 2017-02-08 12:20:12 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:20:12 --> Output Class Initialized
INFO - 2017-02-08 12:20:12 --> Security Class Initialized
DEBUG - 2017-02-08 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:12 --> Output Class Initialized
INFO - 2017-02-08 12:20:12 --> Input Class Initialized
INFO - 2017-02-08 12:20:12 --> Language Class Initialized
INFO - 2017-02-08 12:20:12 --> Security Class Initialized
ERROR - 2017-02-08 12:20:12 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:12 --> Input Class Initialized
INFO - 2017-02-08 12:20:12 --> Router Class Initialized
INFO - 2017-02-08 12:20:12 --> Language Class Initialized
ERROR - 2017-02-08 12:20:12 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:20:12 --> Output Class Initialized
INFO - 2017-02-08 12:20:12 --> Config Class Initialized
INFO - 2017-02-08 12:20:12 --> Security Class Initialized
INFO - 2017-02-08 12:20:12 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:12 --> Input Class Initialized
DEBUG - 2017-02-08 12:20:12 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:12 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:12 --> Language Class Initialized
INFO - 2017-02-08 12:20:12 --> URI Class Initialized
ERROR - 2017-02-08 12:20:12 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:20:12 --> Router Class Initialized
INFO - 2017-02-08 12:20:12 --> Output Class Initialized
INFO - 2017-02-08 12:20:12 --> Security Class Initialized
DEBUG - 2017-02-08 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:12 --> Input Class Initialized
INFO - 2017-02-08 12:20:12 --> Language Class Initialized
ERROR - 2017-02-08 12:20:12 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:20:16 --> Config Class Initialized
INFO - 2017-02-08 12:20:16 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:20:16 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:16 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:16 --> URI Class Initialized
INFO - 2017-02-08 12:20:16 --> Router Class Initialized
INFO - 2017-02-08 12:20:16 --> Output Class Initialized
INFO - 2017-02-08 12:20:16 --> Security Class Initialized
DEBUG - 2017-02-08 12:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:16 --> Input Class Initialized
INFO - 2017-02-08 12:20:16 --> Language Class Initialized
INFO - 2017-02-08 12:20:16 --> Language Class Initialized
INFO - 2017-02-08 12:20:16 --> Config Class Initialized
INFO - 2017-02-08 12:20:16 --> Loader Class Initialized
INFO - 2017-02-08 12:20:16 --> Helper loaded: form_helper
INFO - 2017-02-08 12:20:16 --> Helper loaded: url_helper
INFO - 2017-02-08 12:20:16 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:20:16 --> Database Driver Class Initialized
INFO - 2017-02-08 12:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:20:16 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:20:16 --> Template Class Initialized
INFO - 2017-02-08 12:20:16 --> Controller Class Initialized
DEBUG - 2017-02-08 12:20:16 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:20:16 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:20:16 --> Model Class Initialized
INFO - 2017-02-08 12:20:16 --> Model Class Initialized
ERROR - 2017-02-08 12:20:16 --> Severity: Notice --> Undefined index: verified C:\xampp\htdocs\mobile\application\modules\backend\controllers\Login.php 26
INFO - 2017-02-08 12:20:16 --> Final output sent to browser
DEBUG - 2017-02-08 12:20:16 --> Total execution time: 0.0552
INFO - 2017-02-08 12:20:36 --> Config Class Initialized
INFO - 2017-02-08 12:20:36 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:20:36 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:36 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:36 --> URI Class Initialized
INFO - 2017-02-08 12:20:36 --> Router Class Initialized
INFO - 2017-02-08 12:20:36 --> Output Class Initialized
INFO - 2017-02-08 12:20:36 --> Security Class Initialized
DEBUG - 2017-02-08 12:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:36 --> Input Class Initialized
INFO - 2017-02-08 12:20:36 --> Language Class Initialized
INFO - 2017-02-08 12:20:36 --> Language Class Initialized
INFO - 2017-02-08 12:20:36 --> Config Class Initialized
INFO - 2017-02-08 12:20:36 --> Loader Class Initialized
INFO - 2017-02-08 12:20:36 --> Helper loaded: form_helper
INFO - 2017-02-08 12:20:36 --> Helper loaded: url_helper
INFO - 2017-02-08 12:20:36 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:20:36 --> Database Driver Class Initialized
INFO - 2017-02-08 12:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:20:36 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:20:36 --> Template Class Initialized
INFO - 2017-02-08 12:20:36 --> Controller Class Initialized
DEBUG - 2017-02-08 12:20:36 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:20:36 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:20:36 --> Model Class Initialized
INFO - 2017-02-08 12:20:36 --> Model Class Initialized
ERROR - 2017-02-08 12:20:36 --> Severity: Notice --> Undefined index: mobile C:\xampp\htdocs\mobile\application\modules\backend\controllers\Login.php 31
INFO - 2017-02-08 12:20:36 --> Config Class Initialized
INFO - 2017-02-08 12:20:36 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:20:36 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:36 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:36 --> URI Class Initialized
INFO - 2017-02-08 12:20:36 --> Router Class Initialized
INFO - 2017-02-08 12:20:36 --> Output Class Initialized
INFO - 2017-02-08 12:20:36 --> Security Class Initialized
DEBUG - 2017-02-08 12:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:36 --> Input Class Initialized
INFO - 2017-02-08 12:20:36 --> Language Class Initialized
ERROR - 2017-02-08 12:20:36 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-08 12:20:44 --> Config Class Initialized
INFO - 2017-02-08 12:20:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:20:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:44 --> URI Class Initialized
INFO - 2017-02-08 12:20:44 --> Router Class Initialized
INFO - 2017-02-08 12:20:44 --> Output Class Initialized
INFO - 2017-02-08 12:20:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:44 --> Input Class Initialized
INFO - 2017-02-08 12:20:44 --> Language Class Initialized
INFO - 2017-02-08 12:20:44 --> Language Class Initialized
INFO - 2017-02-08 12:20:44 --> Config Class Initialized
INFO - 2017-02-08 12:20:44 --> Loader Class Initialized
INFO - 2017-02-08 12:20:44 --> Helper loaded: form_helper
INFO - 2017-02-08 12:20:44 --> Helper loaded: url_helper
INFO - 2017-02-08 12:20:44 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:20:44 --> Database Driver Class Initialized
INFO - 2017-02-08 12:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:20:44 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:20:44 --> Template Class Initialized
INFO - 2017-02-08 12:20:44 --> Controller Class Initialized
DEBUG - 2017-02-08 12:20:44 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:20:44 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:20:44 --> Model Class Initialized
INFO - 2017-02-08 12:20:44 --> Model Class Initialized
DEBUG - 2017-02-08 12:20:44 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-08 12:20:44 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:20:44 --> Final output sent to browser
DEBUG - 2017-02-08 12:20:44 --> Total execution time: 0.0506
INFO - 2017-02-08 12:20:44 --> Config Class Initialized
INFO - 2017-02-08 12:20:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:20:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:44 --> Config Class Initialized
INFO - 2017-02-08 12:20:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:20:44 --> URI Class Initialized
INFO - 2017-02-08 12:20:44 --> Config Class Initialized
INFO - 2017-02-08 12:20:44 --> Config Class Initialized
INFO - 2017-02-08 12:20:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:20:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:20:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:44 --> Router Class Initialized
DEBUG - 2017-02-08 12:20:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:44 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:20:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:44 --> URI Class Initialized
INFO - 2017-02-08 12:20:44 --> URI Class Initialized
INFO - 2017-02-08 12:20:44 --> Output Class Initialized
INFO - 2017-02-08 12:20:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:44 --> Router Class Initialized
INFO - 2017-02-08 12:20:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:44 --> URI Class Initialized
INFO - 2017-02-08 12:20:44 --> Input Class Initialized
INFO - 2017-02-08 12:20:44 --> Router Class Initialized
INFO - 2017-02-08 12:20:44 --> Language Class Initialized
INFO - 2017-02-08 12:20:44 --> Output Class Initialized
INFO - 2017-02-08 12:20:44 --> Config Class Initialized
INFO - 2017-02-08 12:20:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:20:44 --> Security Class Initialized
INFO - 2017-02-08 12:20:44 --> Router Class Initialized
INFO - 2017-02-08 12:20:44 --> Output Class Initialized
INFO - 2017-02-08 12:20:44 --> Security Class Initialized
INFO - 2017-02-08 12:20:44 --> Output Class Initialized
DEBUG - 2017-02-08 12:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:44 --> Input Class Initialized
DEBUG - 2017-02-08 12:20:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:44 --> Language Class Initialized
INFO - 2017-02-08 12:20:44 --> Security Class Initialized
INFO - 2017-02-08 12:20:44 --> URI Class Initialized
DEBUG - 2017-02-08 12:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-08 12:20:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-08 12:20:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:20:44 --> Input Class Initialized
INFO - 2017-02-08 12:20:44 --> Input Class Initialized
INFO - 2017-02-08 12:20:44 --> Language Class Initialized
INFO - 2017-02-08 12:20:44 --> Language Class Initialized
ERROR - 2017-02-08 12:20:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:20:44 --> Router Class Initialized
ERROR - 2017-02-08 12:20:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:20:44 --> Output Class Initialized
INFO - 2017-02-08 12:20:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:44 --> Config Class Initialized
INFO - 2017-02-08 12:20:44 --> Input Class Initialized
INFO - 2017-02-08 12:20:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:20:44 --> Config Class Initialized
INFO - 2017-02-08 12:20:44 --> Language Class Initialized
INFO - 2017-02-08 12:20:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:20:44 --> Config Class Initialized
INFO - 2017-02-08 12:20:44 --> Hooks Class Initialized
ERROR - 2017-02-08 12:20:44 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:20:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:44 --> URI Class Initialized
DEBUG - 2017-02-08 12:20:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:44 --> URI Class Initialized
INFO - 2017-02-08 12:20:44 --> Router Class Initialized
INFO - 2017-02-08 12:20:44 --> Output Class Initialized
INFO - 2017-02-08 12:20:44 --> Config Class Initialized
INFO - 2017-02-08 12:20:44 --> Security Class Initialized
INFO - 2017-02-08 12:20:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:44 --> Input Class Initialized
DEBUG - 2017-02-08 12:20:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:44 --> Language Class Initialized
INFO - 2017-02-08 12:20:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:44 --> Router Class Initialized
DEBUG - 2017-02-08 12:20:44 --> UTF-8 Support Enabled
ERROR - 2017-02-08 12:20:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:20:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:44 --> URI Class Initialized
INFO - 2017-02-08 12:20:44 --> URI Class Initialized
INFO - 2017-02-08 12:20:44 --> Router Class Initialized
INFO - 2017-02-08 12:20:44 --> Router Class Initialized
INFO - 2017-02-08 12:20:44 --> Output Class Initialized
INFO - 2017-02-08 12:20:44 --> Output Class Initialized
ERROR - 2017-02-08 12:20:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:20:44 --> Security Class Initialized
INFO - 2017-02-08 12:20:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-08 12:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:44 --> Input Class Initialized
INFO - 2017-02-08 12:20:45 --> Input Class Initialized
INFO - 2017-02-08 12:20:45 --> Language Class Initialized
INFO - 2017-02-08 12:20:45 --> Language Class Initialized
ERROR - 2017-02-08 12:20:45 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:20:45 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:20:45 --> Output Class Initialized
INFO - 2017-02-08 12:20:45 --> Security Class Initialized
DEBUG - 2017-02-08 12:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:45 --> Input Class Initialized
INFO - 2017-02-08 12:20:45 --> Language Class Initialized
ERROR - 2017-02-08 12:20:45 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:20:47 --> Config Class Initialized
INFO - 2017-02-08 12:20:47 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:20:47 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:20:47 --> Utf8 Class Initialized
INFO - 2017-02-08 12:20:47 --> URI Class Initialized
INFO - 2017-02-08 12:20:47 --> Router Class Initialized
INFO - 2017-02-08 12:20:47 --> Output Class Initialized
INFO - 2017-02-08 12:20:47 --> Security Class Initialized
DEBUG - 2017-02-08 12:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:20:47 --> Input Class Initialized
INFO - 2017-02-08 12:20:47 --> Language Class Initialized
INFO - 2017-02-08 12:20:47 --> Language Class Initialized
INFO - 2017-02-08 12:20:47 --> Config Class Initialized
INFO - 2017-02-08 12:20:47 --> Loader Class Initialized
INFO - 2017-02-08 12:20:47 --> Helper loaded: form_helper
INFO - 2017-02-08 12:20:47 --> Helper loaded: url_helper
INFO - 2017-02-08 12:20:47 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:20:47 --> Database Driver Class Initialized
INFO - 2017-02-08 12:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:20:47 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:20:47 --> Template Class Initialized
INFO - 2017-02-08 12:20:47 --> Controller Class Initialized
DEBUG - 2017-02-08 12:20:47 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:20:47 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:20:47 --> Model Class Initialized
INFO - 2017-02-08 12:20:47 --> Model Class Initialized
INFO - 2017-02-08 12:20:47 --> Final output sent to browser
DEBUG - 2017-02-08 12:20:47 --> Total execution time: 0.0953
INFO - 2017-02-08 12:21:22 --> Config Class Initialized
INFO - 2017-02-08 12:21:22 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:21:22 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:22 --> Utf8 Class Initialized
INFO - 2017-02-08 12:21:22 --> URI Class Initialized
INFO - 2017-02-08 12:21:22 --> Router Class Initialized
INFO - 2017-02-08 12:21:22 --> Output Class Initialized
INFO - 2017-02-08 12:21:22 --> Security Class Initialized
DEBUG - 2017-02-08 12:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:22 --> Input Class Initialized
INFO - 2017-02-08 12:21:22 --> Language Class Initialized
INFO - 2017-02-08 12:21:22 --> Language Class Initialized
INFO - 2017-02-08 12:21:22 --> Config Class Initialized
INFO - 2017-02-08 12:21:22 --> Loader Class Initialized
INFO - 2017-02-08 12:21:22 --> Helper loaded: form_helper
INFO - 2017-02-08 12:21:22 --> Helper loaded: url_helper
INFO - 2017-02-08 12:21:22 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:21:22 --> Database Driver Class Initialized
INFO - 2017-02-08 12:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:21:22 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:21:22 --> Template Class Initialized
INFO - 2017-02-08 12:21:22 --> Controller Class Initialized
DEBUG - 2017-02-08 12:21:22 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:21:22 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:21:22 --> Model Class Initialized
INFO - 2017-02-08 12:21:22 --> Model Class Initialized
DEBUG - 2017-02-08 12:21:22 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-08 12:21:22 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:21:22 --> Final output sent to browser
DEBUG - 2017-02-08 12:21:22 --> Total execution time: 0.0691
INFO - 2017-02-08 12:21:22 --> Config Class Initialized
INFO - 2017-02-08 12:21:22 --> Hooks Class Initialized
INFO - 2017-02-08 12:21:22 --> Config Class Initialized
INFO - 2017-02-08 12:21:22 --> Config Class Initialized
INFO - 2017-02-08 12:21:22 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:21:22 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:22 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:21:22 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:22 --> Utf8 Class Initialized
INFO - 2017-02-08 12:21:22 --> URI Class Initialized
INFO - 2017-02-08 12:21:22 --> URI Class Initialized
INFO - 2017-02-08 12:21:22 --> Router Class Initialized
INFO - 2017-02-08 12:21:22 --> Output Class Initialized
INFO - 2017-02-08 12:21:22 --> Security Class Initialized
INFO - 2017-02-08 12:21:22 --> Config Class Initialized
INFO - 2017-02-08 12:21:22 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:22 --> Input Class Initialized
INFO - 2017-02-08 12:21:22 --> Language Class Initialized
ERROR - 2017-02-08 12:21:22 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:21:22 --> Config Class Initialized
INFO - 2017-02-08 12:21:22 --> Hooks Class Initialized
INFO - 2017-02-08 12:21:22 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:21:22 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:22 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:21:22 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:22 --> Utf8 Class Initialized
INFO - 2017-02-08 12:21:22 --> URI Class Initialized
INFO - 2017-02-08 12:21:22 --> Config Class Initialized
INFO - 2017-02-08 12:21:22 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:21:22 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:22 --> Utf8 Class Initialized
INFO - 2017-02-08 12:21:22 --> URI Class Initialized
INFO - 2017-02-08 12:21:22 --> URI Class Initialized
INFO - 2017-02-08 12:21:22 --> Router Class Initialized
DEBUG - 2017-02-08 12:21:22 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:22 --> Utf8 Class Initialized
INFO - 2017-02-08 12:21:22 --> URI Class Initialized
INFO - 2017-02-08 12:21:22 --> Output Class Initialized
INFO - 2017-02-08 12:21:22 --> Router Class Initialized
INFO - 2017-02-08 12:21:22 --> Router Class Initialized
INFO - 2017-02-08 12:21:22 --> Security Class Initialized
DEBUG - 2017-02-08 12:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:22 --> Output Class Initialized
INFO - 2017-02-08 12:21:22 --> Router Class Initialized
INFO - 2017-02-08 12:21:22 --> Input Class Initialized
INFO - 2017-02-08 12:21:22 --> Output Class Initialized
INFO - 2017-02-08 12:21:22 --> Language Class Initialized
INFO - 2017-02-08 12:21:22 --> Security Class Initialized
INFO - 2017-02-08 12:21:22 --> Output Class Initialized
INFO - 2017-02-08 12:21:22 --> Security Class Initialized
ERROR - 2017-02-08 12:21:22 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:22 --> Input Class Initialized
DEBUG - 2017-02-08 12:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:22 --> Input Class Initialized
INFO - 2017-02-08 12:21:22 --> Security Class Initialized
INFO - 2017-02-08 12:21:22 --> Config Class Initialized
INFO - 2017-02-08 12:21:22 --> Hooks Class Initialized
INFO - 2017-02-08 12:21:22 --> Router Class Initialized
INFO - 2017-02-08 12:21:22 --> Language Class Initialized
INFO - 2017-02-08 12:21:22 --> Language Class Initialized
ERROR - 2017-02-08 12:21:22 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:21:22 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:22 --> Utf8 Class Initialized
ERROR - 2017-02-08 12:21:22 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:21:22 --> URI Class Initialized
INFO - 2017-02-08 12:21:22 --> Output Class Initialized
INFO - 2017-02-08 12:21:22 --> Security Class Initialized
INFO - 2017-02-08 12:21:22 --> Router Class Initialized
DEBUG - 2017-02-08 12:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:22 --> Output Class Initialized
INFO - 2017-02-08 12:21:22 --> Input Class Initialized
INFO - 2017-02-08 12:21:22 --> Language Class Initialized
INFO - 2017-02-08 12:21:22 --> Security Class Initialized
DEBUG - 2017-02-08 12:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:22 --> Input Class Initialized
DEBUG - 2017-02-08 12:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:22 --> Input Class Initialized
ERROR - 2017-02-08 12:21:22 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:21:22 --> Language Class Initialized
INFO - 2017-02-08 12:21:22 --> Language Class Initialized
ERROR - 2017-02-08 12:21:22 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:21:22 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:21:22 --> Config Class Initialized
INFO - 2017-02-08 12:21:22 --> Hooks Class Initialized
INFO - 2017-02-08 12:21:22 --> Config Class Initialized
INFO - 2017-02-08 12:21:22 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:21:22 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:22 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:21:22 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:22 --> Utf8 Class Initialized
INFO - 2017-02-08 12:21:22 --> URI Class Initialized
INFO - 2017-02-08 12:21:22 --> URI Class Initialized
INFO - 2017-02-08 12:21:22 --> Router Class Initialized
INFO - 2017-02-08 12:21:22 --> Router Class Initialized
INFO - 2017-02-08 12:21:22 --> Output Class Initialized
INFO - 2017-02-08 12:21:22 --> Security Class Initialized
INFO - 2017-02-08 12:21:22 --> Output Class Initialized
DEBUG - 2017-02-08 12:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:22 --> Input Class Initialized
INFO - 2017-02-08 12:21:22 --> Language Class Initialized
INFO - 2017-02-08 12:21:22 --> Security Class Initialized
ERROR - 2017-02-08 12:21:22 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:22 --> Input Class Initialized
INFO - 2017-02-08 12:21:22 --> Language Class Initialized
ERROR - 2017-02-08 12:21:22 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:21:22 --> Config Class Initialized
INFO - 2017-02-08 12:21:22 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:21:22 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:22 --> Utf8 Class Initialized
INFO - 2017-02-08 12:21:22 --> URI Class Initialized
INFO - 2017-02-08 12:21:23 --> Router Class Initialized
INFO - 2017-02-08 12:21:23 --> Output Class Initialized
INFO - 2017-02-08 12:21:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:23 --> Input Class Initialized
INFO - 2017-02-08 12:21:23 --> Language Class Initialized
INFO - 2017-02-08 12:21:23 --> Language Class Initialized
INFO - 2017-02-08 12:21:23 --> Config Class Initialized
INFO - 2017-02-08 12:21:23 --> Loader Class Initialized
INFO - 2017-02-08 12:21:23 --> Helper loaded: form_helper
INFO - 2017-02-08 12:21:23 --> Helper loaded: url_helper
INFO - 2017-02-08 12:21:23 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:21:23 --> Database Driver Class Initialized
INFO - 2017-02-08 12:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:21:23 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:21:23 --> Template Class Initialized
INFO - 2017-02-08 12:21:23 --> Controller Class Initialized
ERROR - 2017-02-08 12:21:23 --> 404 Page Not Found: ../modules/backend/controllers/Login/img
INFO - 2017-02-08 12:21:38 --> Config Class Initialized
INFO - 2017-02-08 12:21:38 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:21:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:21:38 --> URI Class Initialized
INFO - 2017-02-08 12:21:38 --> Router Class Initialized
INFO - 2017-02-08 12:21:38 --> Output Class Initialized
INFO - 2017-02-08 12:21:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:38 --> Input Class Initialized
INFO - 2017-02-08 12:21:38 --> Language Class Initialized
INFO - 2017-02-08 12:21:38 --> Language Class Initialized
INFO - 2017-02-08 12:21:38 --> Config Class Initialized
INFO - 2017-02-08 12:21:38 --> Loader Class Initialized
INFO - 2017-02-08 12:21:38 --> Helper loaded: form_helper
INFO - 2017-02-08 12:21:38 --> Helper loaded: url_helper
INFO - 2017-02-08 12:21:38 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:21:38 --> Database Driver Class Initialized
INFO - 2017-02-08 12:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:21:38 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:21:38 --> Template Class Initialized
INFO - 2017-02-08 12:21:38 --> Controller Class Initialized
DEBUG - 2017-02-08 12:21:38 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:21:38 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:21:38 --> Model Class Initialized
INFO - 2017-02-08 12:21:38 --> Model Class Initialized
DEBUG - 2017-02-08 12:21:38 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-08 12:21:38 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:21:38 --> Final output sent to browser
DEBUG - 2017-02-08 12:21:38 --> Total execution time: 0.0884
INFO - 2017-02-08 12:21:38 --> Config Class Initialized
INFO - 2017-02-08 12:21:38 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:21:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:21:38 --> URI Class Initialized
INFO - 2017-02-08 12:21:38 --> Router Class Initialized
INFO - 2017-02-08 12:21:38 --> Output Class Initialized
INFO - 2017-02-08 12:21:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:38 --> Input Class Initialized
INFO - 2017-02-08 12:21:38 --> Language Class Initialized
INFO - 2017-02-08 12:21:38 --> Config Class Initialized
INFO - 2017-02-08 12:21:38 --> Hooks Class Initialized
ERROR - 2017-02-08 12:21:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:21:38 --> Config Class Initialized
INFO - 2017-02-08 12:21:38 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:21:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:21:38 --> URI Class Initialized
DEBUG - 2017-02-08 12:21:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:21:38 --> URI Class Initialized
INFO - 2017-02-08 12:21:38 --> Router Class Initialized
INFO - 2017-02-08 12:21:38 --> Output Class Initialized
INFO - 2017-02-08 12:21:38 --> Router Class Initialized
INFO - 2017-02-08 12:21:38 --> Security Class Initialized
INFO - 2017-02-08 12:21:38 --> Config Class Initialized
INFO - 2017-02-08 12:21:38 --> Output Class Initialized
INFO - 2017-02-08 12:21:38 --> Hooks Class Initialized
INFO - 2017-02-08 12:21:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:38 --> Config Class Initialized
INFO - 2017-02-08 12:21:38 --> Hooks Class Initialized
INFO - 2017-02-08 12:21:38 --> Input Class Initialized
DEBUG - 2017-02-08 12:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:38 --> Input Class Initialized
INFO - 2017-02-08 12:21:38 --> Language Class Initialized
INFO - 2017-02-08 12:21:38 --> Language Class Initialized
ERROR - 2017-02-08 12:21:38 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:21:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:38 --> Utf8 Class Initialized
ERROR - 2017-02-08 12:21:38 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:21:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:21:38 --> URI Class Initialized
INFO - 2017-02-08 12:21:38 --> URI Class Initialized
INFO - 2017-02-08 12:21:38 --> Router Class Initialized
INFO - 2017-02-08 12:21:38 --> Router Class Initialized
INFO - 2017-02-08 12:21:38 --> Config Class Initialized
INFO - 2017-02-08 12:21:38 --> Hooks Class Initialized
INFO - 2017-02-08 12:21:38 --> Output Class Initialized
INFO - 2017-02-08 12:21:38 --> Config Class Initialized
INFO - 2017-02-08 12:21:38 --> Hooks Class Initialized
INFO - 2017-02-08 12:21:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:21:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:38 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:38 --> Config Class Initialized
INFO - 2017-02-08 12:21:38 --> Input Class Initialized
INFO - 2017-02-08 12:21:38 --> URI Class Initialized
INFO - 2017-02-08 12:21:38 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:21:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:21:38 --> Language Class Initialized
ERROR - 2017-02-08 12:21:38 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:21:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:38 --> Router Class Initialized
INFO - 2017-02-08 12:21:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:21:38 --> URI Class Initialized
INFO - 2017-02-08 12:21:38 --> URI Class Initialized
INFO - 2017-02-08 12:21:38 --> Output Class Initialized
INFO - 2017-02-08 12:21:38 --> Security Class Initialized
INFO - 2017-02-08 12:21:38 --> Router Class Initialized
INFO - 2017-02-08 12:21:38 --> Router Class Initialized
DEBUG - 2017-02-08 12:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:38 --> Input Class Initialized
INFO - 2017-02-08 12:21:38 --> Output Class Initialized
INFO - 2017-02-08 12:21:38 --> Language Class Initialized
INFO - 2017-02-08 12:21:38 --> Output Class Initialized
INFO - 2017-02-08 12:21:38 --> Security Class Initialized
ERROR - 2017-02-08 12:21:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:21:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:38 --> Input Class Initialized
INFO - 2017-02-08 12:21:38 --> Language Class Initialized
DEBUG - 2017-02-08 12:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:38 --> Input Class Initialized
INFO - 2017-02-08 12:21:38 --> Language Class Initialized
INFO - 2017-02-08 12:21:38 --> Output Class Initialized
ERROR - 2017-02-08 12:21:38 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:21:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:21:38 --> Config Class Initialized
INFO - 2017-02-08 12:21:38 --> Hooks Class Initialized
INFO - 2017-02-08 12:21:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:38 --> Input Class Initialized
DEBUG - 2017-02-08 12:21:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:21:38 --> Language Class Initialized
INFO - 2017-02-08 12:21:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:21:38 --> URI Class Initialized
ERROR - 2017-02-08 12:21:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:21:38 --> Router Class Initialized
INFO - 2017-02-08 12:21:38 --> Output Class Initialized
INFO - 2017-02-08 12:21:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:21:38 --> Input Class Initialized
INFO - 2017-02-08 12:21:38 --> Language Class Initialized
ERROR - 2017-02-08 12:21:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:22:07 --> Config Class Initialized
INFO - 2017-02-08 12:22:07 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:22:07 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:22:07 --> Utf8 Class Initialized
INFO - 2017-02-08 12:22:07 --> URI Class Initialized
INFO - 2017-02-08 12:22:07 --> Router Class Initialized
INFO - 2017-02-08 12:22:07 --> Output Class Initialized
INFO - 2017-02-08 12:22:07 --> Security Class Initialized
DEBUG - 2017-02-08 12:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:22:07 --> Input Class Initialized
INFO - 2017-02-08 12:22:07 --> Language Class Initialized
INFO - 2017-02-08 12:22:07 --> Language Class Initialized
INFO - 2017-02-08 12:22:07 --> Config Class Initialized
INFO - 2017-02-08 12:22:07 --> Loader Class Initialized
INFO - 2017-02-08 12:22:07 --> Helper loaded: form_helper
INFO - 2017-02-08 12:22:07 --> Helper loaded: url_helper
INFO - 2017-02-08 12:22:07 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:22:07 --> Database Driver Class Initialized
INFO - 2017-02-08 12:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:22:07 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:22:07 --> Template Class Initialized
INFO - 2017-02-08 12:22:07 --> Controller Class Initialized
DEBUG - 2017-02-08 12:22:07 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:22:07 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:22:07 --> Model Class Initialized
INFO - 2017-02-08 12:22:07 --> Model Class Initialized
DEBUG - 2017-02-08 12:22:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-08 12:22:07 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:22:07 --> Final output sent to browser
DEBUG - 2017-02-08 12:22:07 --> Total execution time: 0.1122
INFO - 2017-02-08 12:22:07 --> Config Class Initialized
INFO - 2017-02-08 12:22:07 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:22:07 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:22:07 --> Utf8 Class Initialized
INFO - 2017-02-08 12:22:07 --> URI Class Initialized
INFO - 2017-02-08 12:22:07 --> Router Class Initialized
INFO - 2017-02-08 12:22:07 --> Output Class Initialized
INFO - 2017-02-08 12:22:07 --> Security Class Initialized
DEBUG - 2017-02-08 12:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:22:07 --> Input Class Initialized
INFO - 2017-02-08 12:22:07 --> Language Class Initialized
ERROR - 2017-02-08 12:22:07 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:22:07 --> Config Class Initialized
INFO - 2017-02-08 12:22:07 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:22:07 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:22:07 --> Utf8 Class Initialized
INFO - 2017-02-08 12:22:07 --> URI Class Initialized
INFO - 2017-02-08 12:22:07 --> Config Class Initialized
INFO - 2017-02-08 12:22:07 --> Hooks Class Initialized
INFO - 2017-02-08 12:22:07 --> Router Class Initialized
INFO - 2017-02-08 12:22:07 --> Config Class Initialized
INFO - 2017-02-08 12:22:07 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:22:07 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:22:07 --> Utf8 Class Initialized
INFO - 2017-02-08 12:22:07 --> Output Class Initialized
INFO - 2017-02-08 12:22:07 --> URI Class Initialized
INFO - 2017-02-08 12:22:07 --> Security Class Initialized
DEBUG - 2017-02-08 12:22:07 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:22:07 --> Utf8 Class Initialized
INFO - 2017-02-08 12:22:07 --> URI Class Initialized
INFO - 2017-02-08 12:22:07 --> Router Class Initialized
INFO - 2017-02-08 12:22:07 --> Output Class Initialized
INFO - 2017-02-08 12:22:07 --> Router Class Initialized
INFO - 2017-02-08 12:22:07 --> Security Class Initialized
INFO - 2017-02-08 12:22:07 --> Output Class Initialized
DEBUG - 2017-02-08 12:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:22:07 --> Input Class Initialized
INFO - 2017-02-08 12:22:07 --> Security Class Initialized
INFO - 2017-02-08 12:22:07 --> Language Class Initialized
INFO - 2017-02-08 12:22:07 --> Config Class Initialized
INFO - 2017-02-08 12:22:07 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:22:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-08 12:22:07 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:22:07 --> Input Class Initialized
INFO - 2017-02-08 12:22:07 --> Language Class Initialized
DEBUG - 2017-02-08 12:22:07 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:22:07 --> Utf8 Class Initialized
ERROR - 2017-02-08 12:22:07 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:22:07 --> URI Class Initialized
INFO - 2017-02-08 12:22:07 --> Router Class Initialized
INFO - 2017-02-08 12:22:07 --> Config Class Initialized
INFO - 2017-02-08 12:22:07 --> Hooks Class Initialized
INFO - 2017-02-08 12:22:07 --> Output Class Initialized
INFO - 2017-02-08 12:22:07 --> Config Class Initialized
INFO - 2017-02-08 12:22:07 --> Hooks Class Initialized
INFO - 2017-02-08 12:22:07 --> Security Class Initialized
DEBUG - 2017-02-08 12:22:07 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:22:07 --> Config Class Initialized
INFO - 2017-02-08 12:22:07 --> Utf8 Class Initialized
INFO - 2017-02-08 12:22:07 --> URI Class Initialized
INFO - 2017-02-08 12:22:07 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:22:07 --> Input Class Initialized
DEBUG - 2017-02-08 12:22:07 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:22:07 --> Language Class Initialized
INFO - 2017-02-08 12:22:07 --> Utf8 Class Initialized
INFO - 2017-02-08 12:22:07 --> Router Class Initialized
DEBUG - 2017-02-08 12:22:07 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:22:07 --> Utf8 Class Initialized
INFO - 2017-02-08 12:22:07 --> URI Class Initialized
ERROR - 2017-02-08 12:22:07 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:22:07 --> Output Class Initialized
INFO - 2017-02-08 12:22:07 --> URI Class Initialized
INFO - 2017-02-08 12:22:07 --> Security Class Initialized
INFO - 2017-02-08 12:22:07 --> Router Class Initialized
DEBUG - 2017-02-08 12:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:22:07 --> Input Class Initialized
DEBUG - 2017-02-08 12:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:22:07 --> Input Class Initialized
INFO - 2017-02-08 12:22:07 --> Output Class Initialized
INFO - 2017-02-08 12:22:07 --> Language Class Initialized
INFO - 2017-02-08 12:22:07 --> Router Class Initialized
ERROR - 2017-02-08 12:22:07 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:22:07 --> Output Class Initialized
INFO - 2017-02-08 12:22:07 --> Security Class Initialized
INFO - 2017-02-08 12:22:07 --> Language Class Initialized
DEBUG - 2017-02-08 12:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:22:07 --> Input Class Initialized
INFO - 2017-02-08 12:22:07 --> Config Class Initialized
INFO - 2017-02-08 12:22:07 --> Language Class Initialized
INFO - 2017-02-08 12:22:07 --> Hooks Class Initialized
INFO - 2017-02-08 12:22:07 --> Security Class Initialized
ERROR - 2017-02-08 12:22:07 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:22:07 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:22:07 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:22:07 --> Utf8 Class Initialized
INFO - 2017-02-08 12:22:07 --> URI Class Initialized
DEBUG - 2017-02-08 12:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:22:07 --> Input Class Initialized
INFO - 2017-02-08 12:22:07 --> Language Class Initialized
INFO - 2017-02-08 12:22:07 --> Router Class Initialized
ERROR - 2017-02-08 12:22:07 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:22:07 --> Output Class Initialized
INFO - 2017-02-08 12:22:07 --> Security Class Initialized
DEBUG - 2017-02-08 12:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:22:07 --> Input Class Initialized
INFO - 2017-02-08 12:22:07 --> Language Class Initialized
ERROR - 2017-02-08 12:22:07 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:22:28 --> Config Class Initialized
INFO - 2017-02-08 12:22:28 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:22:28 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:22:28 --> Utf8 Class Initialized
INFO - 2017-02-08 12:22:28 --> URI Class Initialized
INFO - 2017-02-08 12:22:28 --> Router Class Initialized
INFO - 2017-02-08 12:22:28 --> Output Class Initialized
INFO - 2017-02-08 12:22:28 --> Security Class Initialized
DEBUG - 2017-02-08 12:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:22:28 --> Input Class Initialized
INFO - 2017-02-08 12:22:28 --> Language Class Initialized
INFO - 2017-02-08 12:22:28 --> Language Class Initialized
INFO - 2017-02-08 12:22:28 --> Config Class Initialized
INFO - 2017-02-08 12:22:28 --> Loader Class Initialized
INFO - 2017-02-08 12:22:28 --> Helper loaded: form_helper
INFO - 2017-02-08 12:22:28 --> Helper loaded: url_helper
INFO - 2017-02-08 12:22:28 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:22:28 --> Database Driver Class Initialized
INFO - 2017-02-08 12:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:22:28 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:22:28 --> Template Class Initialized
INFO - 2017-02-08 12:22:28 --> Controller Class Initialized
DEBUG - 2017-02-08 12:22:28 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:22:28 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:22:28 --> Model Class Initialized
INFO - 2017-02-08 12:22:28 --> Model Class Initialized
ERROR - 2017-02-08 12:22:28 --> Severity: Notice --> Undefined index: mobile C:\xampp\htdocs\mobile\application\modules\backend\controllers\Login.php 31
INFO - 2017-02-08 12:22:28 --> Config Class Initialized
INFO - 2017-02-08 12:22:28 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:22:28 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:22:28 --> Utf8 Class Initialized
INFO - 2017-02-08 12:22:28 --> URI Class Initialized
INFO - 2017-02-08 12:22:28 --> Router Class Initialized
INFO - 2017-02-08 12:22:28 --> Output Class Initialized
INFO - 2017-02-08 12:22:28 --> Security Class Initialized
DEBUG - 2017-02-08 12:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:22:28 --> Input Class Initialized
INFO - 2017-02-08 12:22:28 --> Language Class Initialized
ERROR - 2017-02-08 12:22:28 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-08 12:25:15 --> Config Class Initialized
INFO - 2017-02-08 12:25:15 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:15 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:15 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:15 --> URI Class Initialized
INFO - 2017-02-08 12:25:15 --> Router Class Initialized
INFO - 2017-02-08 12:25:15 --> Output Class Initialized
INFO - 2017-02-08 12:25:15 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:15 --> Input Class Initialized
INFO - 2017-02-08 12:25:15 --> Language Class Initialized
INFO - 2017-02-08 12:25:15 --> Language Class Initialized
INFO - 2017-02-08 12:25:15 --> Config Class Initialized
INFO - 2017-02-08 12:25:15 --> Loader Class Initialized
INFO - 2017-02-08 12:25:15 --> Helper loaded: form_helper
INFO - 2017-02-08 12:25:15 --> Helper loaded: url_helper
INFO - 2017-02-08 12:25:15 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:25:15 --> Database Driver Class Initialized
INFO - 2017-02-08 12:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:25:15 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:25:15 --> Template Class Initialized
INFO - 2017-02-08 12:25:15 --> Controller Class Initialized
DEBUG - 2017-02-08 12:25:15 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:25:15 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:25:15 --> Model Class Initialized
INFO - 2017-02-08 12:25:15 --> Model Class Initialized
INFO - 2017-02-08 12:25:16 --> Config Class Initialized
INFO - 2017-02-08 12:25:16 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:16 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:16 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:16 --> URI Class Initialized
INFO - 2017-02-08 12:25:16 --> Router Class Initialized
INFO - 2017-02-08 12:25:16 --> Output Class Initialized
INFO - 2017-02-08 12:25:16 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:16 --> Input Class Initialized
INFO - 2017-02-08 12:25:16 --> Language Class Initialized
INFO - 2017-02-08 12:25:16 --> Language Class Initialized
INFO - 2017-02-08 12:25:16 --> Config Class Initialized
INFO - 2017-02-08 12:25:16 --> Loader Class Initialized
INFO - 2017-02-08 12:25:16 --> Helper loaded: form_helper
INFO - 2017-02-08 12:25:16 --> Helper loaded: url_helper
INFO - 2017-02-08 12:25:16 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:25:16 --> Database Driver Class Initialized
INFO - 2017-02-08 12:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:25:16 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:25:16 --> Template Class Initialized
INFO - 2017-02-08 12:25:16 --> Controller Class Initialized
DEBUG - 2017-02-08 12:25:16 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:25:16 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:25:16 --> Model Class Initialized
INFO - 2017-02-08 12:25:16 --> Model Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Loader Class Initialized
INFO - 2017-02-08 12:25:31 --> Helper loaded: form_helper
INFO - 2017-02-08 12:25:31 --> Helper loaded: url_helper
INFO - 2017-02-08 12:25:31 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:25:31 --> Database Driver Class Initialized
INFO - 2017-02-08 12:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:25:31 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Template Class Initialized
INFO - 2017-02-08 12:25:31 --> Controller Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:25:31 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:25:31 --> Model Class Initialized
INFO - 2017-02-08 12:25:31 --> Model Class Initialized
DEBUG - 2017-02-08 12:25:31 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:25:31 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:25:31 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:25:31 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:25:31 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:25:31 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:25:31 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:25:31 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:25:31 --> Final output sent to browser
DEBUG - 2017-02-08 12:25:31 --> Total execution time: 0.0768
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:31 --> Config Class Initialized
INFO - 2017-02-08 12:25:31 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:31 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:31 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:31 --> URI Class Initialized
INFO - 2017-02-08 12:25:31 --> Router Class Initialized
INFO - 2017-02-08 12:25:31 --> Output Class Initialized
INFO - 2017-02-08 12:25:31 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:31 --> Input Class Initialized
INFO - 2017-02-08 12:25:31 --> Language Class Initialized
ERROR - 2017-02-08 12:25:31 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:32 --> Config Class Initialized
INFO - 2017-02-08 12:25:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:32 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:32 --> URI Class Initialized
INFO - 2017-02-08 12:25:32 --> Router Class Initialized
INFO - 2017-02-08 12:25:32 --> Output Class Initialized
INFO - 2017-02-08 12:25:32 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:32 --> Input Class Initialized
INFO - 2017-02-08 12:25:32 --> Language Class Initialized
ERROR - 2017-02-08 12:25:32 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:32 --> Config Class Initialized
INFO - 2017-02-08 12:25:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:32 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:32 --> URI Class Initialized
INFO - 2017-02-08 12:25:32 --> Router Class Initialized
INFO - 2017-02-08 12:25:32 --> Output Class Initialized
INFO - 2017-02-08 12:25:32 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:32 --> Input Class Initialized
INFO - 2017-02-08 12:25:32 --> Language Class Initialized
ERROR - 2017-02-08 12:25:32 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:32 --> Config Class Initialized
INFO - 2017-02-08 12:25:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:32 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:32 --> URI Class Initialized
INFO - 2017-02-08 12:25:32 --> Router Class Initialized
INFO - 2017-02-08 12:25:32 --> Output Class Initialized
INFO - 2017-02-08 12:25:32 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:32 --> Input Class Initialized
INFO - 2017-02-08 12:25:32 --> Language Class Initialized
ERROR - 2017-02-08 12:25:32 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:32 --> Config Class Initialized
INFO - 2017-02-08 12:25:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:32 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:32 --> URI Class Initialized
INFO - 2017-02-08 12:25:32 --> Router Class Initialized
INFO - 2017-02-08 12:25:32 --> Output Class Initialized
INFO - 2017-02-08 12:25:32 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:32 --> Input Class Initialized
INFO - 2017-02-08 12:25:32 --> Language Class Initialized
ERROR - 2017-02-08 12:25:32 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:32 --> Config Class Initialized
INFO - 2017-02-08 12:25:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:32 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:32 --> URI Class Initialized
INFO - 2017-02-08 12:25:32 --> Router Class Initialized
INFO - 2017-02-08 12:25:32 --> Output Class Initialized
INFO - 2017-02-08 12:25:32 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:32 --> Input Class Initialized
INFO - 2017-02-08 12:25:32 --> Language Class Initialized
ERROR - 2017-02-08 12:25:32 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:32 --> Config Class Initialized
INFO - 2017-02-08 12:25:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:32 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:32 --> URI Class Initialized
INFO - 2017-02-08 12:25:32 --> Router Class Initialized
INFO - 2017-02-08 12:25:32 --> Output Class Initialized
INFO - 2017-02-08 12:25:32 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:32 --> Input Class Initialized
INFO - 2017-02-08 12:25:32 --> Language Class Initialized
ERROR - 2017-02-08 12:25:32 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:32 --> Config Class Initialized
INFO - 2017-02-08 12:25:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:32 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:32 --> URI Class Initialized
INFO - 2017-02-08 12:25:32 --> Router Class Initialized
INFO - 2017-02-08 12:25:32 --> Output Class Initialized
INFO - 2017-02-08 12:25:32 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:32 --> Input Class Initialized
INFO - 2017-02-08 12:25:32 --> Language Class Initialized
ERROR - 2017-02-08 12:25:32 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:32 --> Config Class Initialized
INFO - 2017-02-08 12:25:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:32 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:32 --> URI Class Initialized
INFO - 2017-02-08 12:25:32 --> Router Class Initialized
INFO - 2017-02-08 12:25:32 --> Output Class Initialized
INFO - 2017-02-08 12:25:32 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:32 --> Input Class Initialized
INFO - 2017-02-08 12:25:32 --> Language Class Initialized
ERROR - 2017-02-08 12:25:32 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:32 --> Config Class Initialized
INFO - 2017-02-08 12:25:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:32 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:32 --> URI Class Initialized
INFO - 2017-02-08 12:25:32 --> Router Class Initialized
INFO - 2017-02-08 12:25:32 --> Output Class Initialized
INFO - 2017-02-08 12:25:32 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:32 --> Input Class Initialized
INFO - 2017-02-08 12:25:32 --> Language Class Initialized
ERROR - 2017-02-08 12:25:32 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:32 --> Config Class Initialized
INFO - 2017-02-08 12:25:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:32 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:32 --> URI Class Initialized
INFO - 2017-02-08 12:25:32 --> Router Class Initialized
INFO - 2017-02-08 12:25:32 --> Output Class Initialized
INFO - 2017-02-08 12:25:32 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:32 --> Input Class Initialized
INFO - 2017-02-08 12:25:32 --> Language Class Initialized
ERROR - 2017-02-08 12:25:32 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:32 --> Config Class Initialized
INFO - 2017-02-08 12:25:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:32 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:32 --> URI Class Initialized
INFO - 2017-02-08 12:25:32 --> Router Class Initialized
INFO - 2017-02-08 12:25:32 --> Output Class Initialized
INFO - 2017-02-08 12:25:32 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:32 --> Input Class Initialized
INFO - 2017-02-08 12:25:32 --> Language Class Initialized
ERROR - 2017-02-08 12:25:32 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:32 --> Config Class Initialized
INFO - 2017-02-08 12:25:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:32 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:32 --> URI Class Initialized
INFO - 2017-02-08 12:25:32 --> Router Class Initialized
INFO - 2017-02-08 12:25:32 --> Output Class Initialized
INFO - 2017-02-08 12:25:32 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:32 --> Input Class Initialized
INFO - 2017-02-08 12:25:32 --> Language Class Initialized
ERROR - 2017-02-08 12:25:32 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:25:32 --> Config Class Initialized
INFO - 2017-02-08 12:25:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:25:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:25:32 --> Utf8 Class Initialized
INFO - 2017-02-08 12:25:32 --> URI Class Initialized
INFO - 2017-02-08 12:25:32 --> Router Class Initialized
INFO - 2017-02-08 12:25:32 --> Output Class Initialized
INFO - 2017-02-08 12:25:32 --> Security Class Initialized
DEBUG - 2017-02-08 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:25:32 --> Input Class Initialized
INFO - 2017-02-08 12:25:32 --> Language Class Initialized
ERROR - 2017-02-08 12:25:32 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:19 --> Config Class Initialized
INFO - 2017-02-08 12:26:19 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:19 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:19 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:19 --> URI Class Initialized
INFO - 2017-02-08 12:26:19 --> Router Class Initialized
INFO - 2017-02-08 12:26:19 --> Output Class Initialized
INFO - 2017-02-08 12:26:19 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:19 --> Input Class Initialized
INFO - 2017-02-08 12:26:19 --> Language Class Initialized
INFO - 2017-02-08 12:26:19 --> Language Class Initialized
INFO - 2017-02-08 12:26:19 --> Config Class Initialized
INFO - 2017-02-08 12:26:19 --> Loader Class Initialized
INFO - 2017-02-08 12:26:19 --> Helper loaded: form_helper
INFO - 2017-02-08 12:26:19 --> Helper loaded: url_helper
INFO - 2017-02-08 12:26:19 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:26:19 --> Database Driver Class Initialized
INFO - 2017-02-08 12:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:26:19 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:26:19 --> Template Class Initialized
INFO - 2017-02-08 12:26:19 --> Controller Class Initialized
DEBUG - 2017-02-08 12:26:19 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:26:19 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:26:19 --> Model Class Initialized
INFO - 2017-02-08 12:26:19 --> Model Class Initialized
DEBUG - 2017-02-08 12:26:19 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:26:19 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:26:19 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:26:19 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:26:19 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:26:19 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:26:19 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:26:19 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:26:19 --> Final output sent to browser
DEBUG - 2017-02-08 12:26:19 --> Total execution time: 0.0718
INFO - 2017-02-08 12:26:19 --> Config Class Initialized
INFO - 2017-02-08 12:26:19 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:19 --> Config Class Initialized
INFO - 2017-02-08 12:26:19 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:19 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:19 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:19 --> URI Class Initialized
INFO - 2017-02-08 12:26:19 --> Config Class Initialized
INFO - 2017-02-08 12:26:19 --> Config Class Initialized
INFO - 2017-02-08 12:26:19 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:19 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:19 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:19 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:19 --> Config Class Initialized
INFO - 2017-02-08 12:26:19 --> URI Class Initialized
INFO - 2017-02-08 12:26:19 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:19 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:19 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:19 --> URI Class Initialized
INFO - 2017-02-08 12:26:19 --> Router Class Initialized
DEBUG - 2017-02-08 12:26:19 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:19 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:19 --> URI Class Initialized
INFO - 2017-02-08 12:26:19 --> Output Class Initialized
INFO - 2017-02-08 12:26:19 --> Security Class Initialized
INFO - 2017-02-08 12:26:19 --> Router Class Initialized
DEBUG - 2017-02-08 12:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:19 --> Input Class Initialized
INFO - 2017-02-08 12:26:19 --> Router Class Initialized
INFO - 2017-02-08 12:26:19 --> Output Class Initialized
INFO - 2017-02-08 12:26:19 --> Language Class Initialized
ERROR - 2017-02-08 12:26:19 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:19 --> Output Class Initialized
INFO - 2017-02-08 12:26:19 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:19 --> Input Class Initialized
INFO - 2017-02-08 12:26:19 --> Security Class Initialized
INFO - 2017-02-08 12:26:19 --> Language Class Initialized
DEBUG - 2017-02-08 12:26:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-08 12:26:19 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:19 --> Input Class Initialized
INFO - 2017-02-08 12:26:19 --> Language Class Initialized
ERROR - 2017-02-08 12:26:19 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:19 --> Config Class Initialized
INFO - 2017-02-08 12:26:19 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:19 --> Config Class Initialized
INFO - 2017-02-08 12:26:19 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:20 --> Config Class Initialized
INFO - 2017-02-08 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:20 --> URI Class Initialized
INFO - 2017-02-08 12:26:20 --> Router Class Initialized
INFO - 2017-02-08 12:26:20 --> Output Class Initialized
INFO - 2017-02-08 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:20 --> Input Class Initialized
INFO - 2017-02-08 12:26:20 --> Language Class Initialized
ERROR - 2017-02-08 12:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Loader Class Initialized
INFO - 2017-02-08 12:26:44 --> Helper loaded: form_helper
INFO - 2017-02-08 12:26:44 --> Helper loaded: url_helper
INFO - 2017-02-08 12:26:44 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:26:44 --> Database Driver Class Initialized
INFO - 2017-02-08 12:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:26:44 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Template Class Initialized
INFO - 2017-02-08 12:26:44 --> Controller Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:26:44 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:26:44 --> Model Class Initialized
INFO - 2017-02-08 12:26:44 --> Model Class Initialized
DEBUG - 2017-02-08 12:26:44 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:26:44 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:26:44 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:26:44 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:26:44 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:26:44 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:26:44 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:26:44 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:26:44 --> Final output sent to browser
DEBUG - 2017-02-08 12:26:44 --> Total execution time: 0.0612
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:44 --> Config Class Initialized
INFO - 2017-02-08 12:26:44 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:44 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:44 --> URI Class Initialized
INFO - 2017-02-08 12:26:44 --> Router Class Initialized
INFO - 2017-02-08 12:26:44 --> Output Class Initialized
INFO - 2017-02-08 12:26:44 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:44 --> Input Class Initialized
INFO - 2017-02-08 12:26:44 --> Language Class Initialized
ERROR - 2017-02-08 12:26:44 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:45 --> Config Class Initialized
INFO - 2017-02-08 12:26:45 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:45 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:45 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:45 --> URI Class Initialized
INFO - 2017-02-08 12:26:45 --> Router Class Initialized
INFO - 2017-02-08 12:26:45 --> Output Class Initialized
INFO - 2017-02-08 12:26:45 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:45 --> Input Class Initialized
INFO - 2017-02-08 12:26:45 --> Language Class Initialized
ERROR - 2017-02-08 12:26:45 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:45 --> Config Class Initialized
INFO - 2017-02-08 12:26:45 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:45 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:45 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:45 --> URI Class Initialized
INFO - 2017-02-08 12:26:45 --> Router Class Initialized
INFO - 2017-02-08 12:26:45 --> Output Class Initialized
INFO - 2017-02-08 12:26:45 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:45 --> Input Class Initialized
INFO - 2017-02-08 12:26:45 --> Language Class Initialized
ERROR - 2017-02-08 12:26:45 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:45 --> Config Class Initialized
INFO - 2017-02-08 12:26:45 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:45 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:45 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:45 --> URI Class Initialized
INFO - 2017-02-08 12:26:45 --> Router Class Initialized
INFO - 2017-02-08 12:26:45 --> Output Class Initialized
INFO - 2017-02-08 12:26:45 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:45 --> Input Class Initialized
INFO - 2017-02-08 12:26:45 --> Language Class Initialized
ERROR - 2017-02-08 12:26:45 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:45 --> Config Class Initialized
INFO - 2017-02-08 12:26:45 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:45 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:45 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:45 --> URI Class Initialized
INFO - 2017-02-08 12:26:45 --> Router Class Initialized
INFO - 2017-02-08 12:26:45 --> Output Class Initialized
INFO - 2017-02-08 12:26:45 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:45 --> Input Class Initialized
INFO - 2017-02-08 12:26:45 --> Language Class Initialized
ERROR - 2017-02-08 12:26:45 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:45 --> Config Class Initialized
INFO - 2017-02-08 12:26:45 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:45 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:45 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:45 --> URI Class Initialized
INFO - 2017-02-08 12:26:45 --> Router Class Initialized
INFO - 2017-02-08 12:26:45 --> Output Class Initialized
INFO - 2017-02-08 12:26:45 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:45 --> Input Class Initialized
INFO - 2017-02-08 12:26:45 --> Language Class Initialized
ERROR - 2017-02-08 12:26:45 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:45 --> Config Class Initialized
INFO - 2017-02-08 12:26:45 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:45 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:45 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:45 --> URI Class Initialized
INFO - 2017-02-08 12:26:45 --> Router Class Initialized
INFO - 2017-02-08 12:26:45 --> Output Class Initialized
INFO - 2017-02-08 12:26:45 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:45 --> Input Class Initialized
INFO - 2017-02-08 12:26:45 --> Language Class Initialized
ERROR - 2017-02-08 12:26:45 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:26:45 --> Config Class Initialized
INFO - 2017-02-08 12:26:45 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:26:45 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:26:45 --> Utf8 Class Initialized
INFO - 2017-02-08 12:26:45 --> URI Class Initialized
INFO - 2017-02-08 12:26:45 --> Router Class Initialized
INFO - 2017-02-08 12:26:45 --> Output Class Initialized
INFO - 2017-02-08 12:26:45 --> Security Class Initialized
DEBUG - 2017-02-08 12:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:26:45 --> Input Class Initialized
INFO - 2017-02-08 12:26:45 --> Language Class Initialized
ERROR - 2017-02-08 12:26:45 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Loader Class Initialized
INFO - 2017-02-08 12:27:23 --> Helper loaded: form_helper
INFO - 2017-02-08 12:27:23 --> Helper loaded: url_helper
INFO - 2017-02-08 12:27:23 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:27:23 --> Database Driver Class Initialized
INFO - 2017-02-08 12:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:27:23 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Template Class Initialized
INFO - 2017-02-08 12:27:23 --> Controller Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:27:23 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:27:23 --> Model Class Initialized
INFO - 2017-02-08 12:27:23 --> Model Class Initialized
DEBUG - 2017-02-08 12:27:23 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:27:23 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:27:23 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:27:23 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:27:23 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:27:23 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:27:23 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:27:23 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:27:23 --> Final output sent to browser
DEBUG - 2017-02-08 12:27:23 --> Total execution time: 0.0686
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:27:23 --> Config Class Initialized
INFO - 2017-02-08 12:27:23 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:27:23 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:27:23 --> Utf8 Class Initialized
INFO - 2017-02-08 12:27:23 --> URI Class Initialized
INFO - 2017-02-08 12:27:23 --> Router Class Initialized
INFO - 2017-02-08 12:27:23 --> Output Class Initialized
INFO - 2017-02-08 12:27:23 --> Security Class Initialized
DEBUG - 2017-02-08 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:27:23 --> Input Class Initialized
INFO - 2017-02-08 12:27:23 --> Language Class Initialized
ERROR - 2017-02-08 12:27:23 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:28:14 --> Config Class Initialized
INFO - 2017-02-08 12:28:14 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:28:14 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:28:14 --> Utf8 Class Initialized
INFO - 2017-02-08 12:28:14 --> URI Class Initialized
INFO - 2017-02-08 12:28:14 --> Router Class Initialized
INFO - 2017-02-08 12:28:14 --> Output Class Initialized
INFO - 2017-02-08 12:28:14 --> Security Class Initialized
DEBUG - 2017-02-08 12:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:28:14 --> Input Class Initialized
INFO - 2017-02-08 12:28:14 --> Language Class Initialized
INFO - 2017-02-08 12:28:14 --> Language Class Initialized
INFO - 2017-02-08 12:28:14 --> Config Class Initialized
INFO - 2017-02-08 12:28:14 --> Loader Class Initialized
INFO - 2017-02-08 12:28:14 --> Helper loaded: form_helper
INFO - 2017-02-08 12:28:14 --> Helper loaded: url_helper
INFO - 2017-02-08 12:28:14 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:28:14 --> Database Driver Class Initialized
INFO - 2017-02-08 12:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:28:14 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:28:14 --> Template Class Initialized
INFO - 2017-02-08 12:28:14 --> Controller Class Initialized
DEBUG - 2017-02-08 12:28:14 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:28:14 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:28:14 --> Model Class Initialized
INFO - 2017-02-08 12:28:14 --> Model Class Initialized
DEBUG - 2017-02-08 12:28:14 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:28:14 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:28:14 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:28:14 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:28:14 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:28:14 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:28:14 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:28:14 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:28:14 --> Final output sent to browser
DEBUG - 2017-02-08 12:28:14 --> Total execution time: 0.0663
INFO - 2017-02-08 12:28:35 --> Config Class Initialized
INFO - 2017-02-08 12:28:35 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:28:35 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:28:35 --> Utf8 Class Initialized
INFO - 2017-02-08 12:28:35 --> URI Class Initialized
INFO - 2017-02-08 12:28:35 --> Router Class Initialized
INFO - 2017-02-08 12:28:35 --> Output Class Initialized
INFO - 2017-02-08 12:28:35 --> Security Class Initialized
DEBUG - 2017-02-08 12:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:28:35 --> Input Class Initialized
INFO - 2017-02-08 12:28:35 --> Language Class Initialized
INFO - 2017-02-08 12:28:35 --> Language Class Initialized
INFO - 2017-02-08 12:28:35 --> Config Class Initialized
INFO - 2017-02-08 12:28:35 --> Loader Class Initialized
INFO - 2017-02-08 12:28:35 --> Helper loaded: form_helper
INFO - 2017-02-08 12:28:35 --> Helper loaded: url_helper
INFO - 2017-02-08 12:28:35 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:28:35 --> Database Driver Class Initialized
INFO - 2017-02-08 12:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:28:35 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:28:35 --> Template Class Initialized
INFO - 2017-02-08 12:28:35 --> Controller Class Initialized
DEBUG - 2017-02-08 12:28:35 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:28:35 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:28:35 --> Model Class Initialized
INFO - 2017-02-08 12:28:35 --> Model Class Initialized
ERROR - 2017-02-08 12:28:35 --> Severity: Notice --> Undefined variable: user_account C:\xampp\htdocs\mobile\application\modules\backend\views\partials\header.php 20
ERROR - 2017-02-08 12:28:35 --> Severity: Notice --> Undefined variable: user_account C:\xampp\htdocs\mobile\application\modules\backend\views\partials\header.php 21
DEBUG - 2017-02-08 12:28:35 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 12:28:35 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:28:35 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:28:35 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:28:35 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:28:35 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:28:35 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:28:35 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:28:35 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:28:35 --> Final output sent to browser
DEBUG - 2017-02-08 12:28:35 --> Total execution time: 0.0852
INFO - 2017-02-08 12:28:35 --> Config Class Initialized
INFO - 2017-02-08 12:28:35 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:28:35 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:28:35 --> Utf8 Class Initialized
INFO - 2017-02-08 12:28:35 --> Config Class Initialized
INFO - 2017-02-08 12:28:35 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:28:35 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:28:35 --> Utf8 Class Initialized
INFO - 2017-02-08 12:28:35 --> URI Class Initialized
INFO - 2017-02-08 12:28:35 --> Router Class Initialized
INFO - 2017-02-08 12:28:35 --> Output Class Initialized
INFO - 2017-02-08 12:28:35 --> Security Class Initialized
DEBUG - 2017-02-08 12:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:28:35 --> Input Class Initialized
INFO - 2017-02-08 12:28:35 --> Language Class Initialized
ERROR - 2017-02-08 12:28:35 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:28:54 --> Config Class Initialized
INFO - 2017-02-08 12:28:54 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:28:54 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:28:54 --> Utf8 Class Initialized
INFO - 2017-02-08 12:28:54 --> URI Class Initialized
INFO - 2017-02-08 12:28:54 --> Router Class Initialized
INFO - 2017-02-08 12:28:54 --> Output Class Initialized
INFO - 2017-02-08 12:28:54 --> Security Class Initialized
DEBUG - 2017-02-08 12:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:28:54 --> Input Class Initialized
INFO - 2017-02-08 12:28:54 --> Language Class Initialized
INFO - 2017-02-08 12:28:54 --> Language Class Initialized
INFO - 2017-02-08 12:28:54 --> Config Class Initialized
INFO - 2017-02-08 12:28:54 --> Loader Class Initialized
INFO - 2017-02-08 12:28:54 --> Helper loaded: form_helper
INFO - 2017-02-08 12:28:54 --> Helper loaded: url_helper
INFO - 2017-02-08 12:28:54 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:28:54 --> Database Driver Class Initialized
INFO - 2017-02-08 12:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:28:54 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:28:54 --> Template Class Initialized
INFO - 2017-02-08 12:28:54 --> Controller Class Initialized
DEBUG - 2017-02-08 12:28:54 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:28:54 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:28:54 --> Model Class Initialized
INFO - 2017-02-08 12:28:54 --> Model Class Initialized
ERROR - 2017-02-08 12:28:54 --> Severity: Notice --> Undefined variable: user_account C:\xampp\htdocs\mobile\application\modules\backend\views\partials\header.php 20
ERROR - 2017-02-08 12:28:54 --> Severity: Notice --> Undefined variable: user_account C:\xampp\htdocs\mobile\application\modules\backend\views\partials\header.php 21
DEBUG - 2017-02-08 12:28:54 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 12:28:54 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:28:54 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:28:54 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:28:54 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:28:54 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:28:54 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:28:54 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:28:54 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:28:54 --> Final output sent to browser
DEBUG - 2017-02-08 12:28:54 --> Total execution time: 0.0775
INFO - 2017-02-08 12:28:54 --> Config Class Initialized
INFO - 2017-02-08 12:28:54 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:28:54 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:28:54 --> Utf8 Class Initialized
INFO - 2017-02-08 12:28:54 --> Config Class Initialized
INFO - 2017-02-08 12:28:54 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:28:54 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:28:54 --> Utf8 Class Initialized
INFO - 2017-02-08 12:28:54 --> URI Class Initialized
INFO - 2017-02-08 12:28:54 --> Router Class Initialized
INFO - 2017-02-08 12:28:54 --> Output Class Initialized
INFO - 2017-02-08 12:28:54 --> Security Class Initialized
DEBUG - 2017-02-08 12:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:28:54 --> Input Class Initialized
INFO - 2017-02-08 12:28:54 --> Language Class Initialized
ERROR - 2017-02-08 12:28:54 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:29:45 --> Config Class Initialized
INFO - 2017-02-08 12:29:45 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:29:45 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:29:45 --> Utf8 Class Initialized
INFO - 2017-02-08 12:29:45 --> URI Class Initialized
INFO - 2017-02-08 12:29:45 --> Router Class Initialized
INFO - 2017-02-08 12:29:45 --> Output Class Initialized
INFO - 2017-02-08 12:29:45 --> Security Class Initialized
DEBUG - 2017-02-08 12:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:29:45 --> Input Class Initialized
INFO - 2017-02-08 12:29:45 --> Language Class Initialized
INFO - 2017-02-08 12:29:45 --> Language Class Initialized
INFO - 2017-02-08 12:29:45 --> Config Class Initialized
INFO - 2017-02-08 12:29:45 --> Loader Class Initialized
INFO - 2017-02-08 12:29:45 --> Helper loaded: form_helper
INFO - 2017-02-08 12:29:45 --> Helper loaded: url_helper
INFO - 2017-02-08 12:29:45 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:29:45 --> Database Driver Class Initialized
INFO - 2017-02-08 12:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:29:45 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:29:45 --> Template Class Initialized
INFO - 2017-02-08 12:29:45 --> Controller Class Initialized
DEBUG - 2017-02-08 12:29:45 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:29:45 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:29:45 --> Model Class Initialized
INFO - 2017-02-08 12:29:45 --> Model Class Initialized
DEBUG - 2017-02-08 12:29:45 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-08 12:29:45 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:29:45 --> Final output sent to browser
DEBUG - 2017-02-08 12:29:45 --> Total execution time: 0.0621
INFO - 2017-02-08 12:29:50 --> Config Class Initialized
INFO - 2017-02-08 12:29:50 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:29:50 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:29:50 --> Utf8 Class Initialized
INFO - 2017-02-08 12:29:50 --> URI Class Initialized
INFO - 2017-02-08 12:29:50 --> Router Class Initialized
INFO - 2017-02-08 12:29:50 --> Output Class Initialized
INFO - 2017-02-08 12:29:50 --> Security Class Initialized
DEBUG - 2017-02-08 12:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:29:50 --> Input Class Initialized
INFO - 2017-02-08 12:29:50 --> Language Class Initialized
INFO - 2017-02-08 12:29:50 --> Language Class Initialized
INFO - 2017-02-08 12:29:50 --> Config Class Initialized
INFO - 2017-02-08 12:29:50 --> Loader Class Initialized
INFO - 2017-02-08 12:29:50 --> Helper loaded: form_helper
INFO - 2017-02-08 12:29:50 --> Helper loaded: url_helper
INFO - 2017-02-08 12:29:50 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:29:50 --> Database Driver Class Initialized
INFO - 2017-02-08 12:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:29:50 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:29:50 --> Template Class Initialized
INFO - 2017-02-08 12:29:50 --> Controller Class Initialized
DEBUG - 2017-02-08 12:29:50 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:29:50 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:29:50 --> Model Class Initialized
INFO - 2017-02-08 12:29:50 --> Model Class Initialized
ERROR - 2017-02-08 12:29:50 --> Severity: Notice --> Undefined index: mobile C:\xampp\htdocs\mobile\application\modules\backend\controllers\Login.php 31
INFO - 2017-02-08 12:29:50 --> Config Class Initialized
INFO - 2017-02-08 12:29:50 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:29:50 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:29:50 --> Utf8 Class Initialized
INFO - 2017-02-08 12:29:50 --> URI Class Initialized
INFO - 2017-02-08 12:29:50 --> Router Class Initialized
INFO - 2017-02-08 12:29:50 --> Output Class Initialized
INFO - 2017-02-08 12:29:50 --> Security Class Initialized
DEBUG - 2017-02-08 12:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:29:50 --> Input Class Initialized
INFO - 2017-02-08 12:29:50 --> Language Class Initialized
INFO - 2017-02-08 12:29:50 --> Language Class Initialized
INFO - 2017-02-08 12:29:50 --> Config Class Initialized
INFO - 2017-02-08 12:29:50 --> Loader Class Initialized
INFO - 2017-02-08 12:29:50 --> Helper loaded: form_helper
INFO - 2017-02-08 12:29:50 --> Helper loaded: url_helper
INFO - 2017-02-08 12:29:50 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:29:50 --> Database Driver Class Initialized
INFO - 2017-02-08 12:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:29:50 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:29:50 --> Template Class Initialized
INFO - 2017-02-08 12:29:50 --> Controller Class Initialized
DEBUG - 2017-02-08 12:29:50 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:29:50 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:29:50 --> Model Class Initialized
INFO - 2017-02-08 12:29:50 --> Model Class Initialized
ERROR - 2017-02-08 12:29:50 --> Severity: Notice --> Undefined variable: user_account C:\xampp\htdocs\mobile\application\modules\backend\views\partials\header.php 20
ERROR - 2017-02-08 12:29:50 --> Severity: Notice --> Undefined variable: user_account C:\xampp\htdocs\mobile\application\modules\backend\views\partials\header.php 21
DEBUG - 2017-02-08 12:29:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 12:29:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:29:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:29:50 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:29:50 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:29:50 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:29:50 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:29:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:29:50 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:29:50 --> Final output sent to browser
DEBUG - 2017-02-08 12:29:50 --> Total execution time: 0.0591
INFO - 2017-02-08 12:29:50 --> Config Class Initialized
INFO - 2017-02-08 12:29:50 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:29:50 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:29:50 --> Utf8 Class Initialized
INFO - 2017-02-08 12:29:51 --> Config Class Initialized
INFO - 2017-02-08 12:29:51 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:29:51 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:29:51 --> Utf8 Class Initialized
INFO - 2017-02-08 12:29:51 --> URI Class Initialized
INFO - 2017-02-08 12:29:51 --> Router Class Initialized
INFO - 2017-02-08 12:29:51 --> Output Class Initialized
INFO - 2017-02-08 12:29:51 --> Security Class Initialized
DEBUG - 2017-02-08 12:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:29:51 --> Input Class Initialized
INFO - 2017-02-08 12:29:51 --> Language Class Initialized
ERROR - 2017-02-08 12:29:51 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:31:36 --> Config Class Initialized
INFO - 2017-02-08 12:31:36 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:31:36 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:31:36 --> Utf8 Class Initialized
INFO - 2017-02-08 12:31:36 --> URI Class Initialized
INFO - 2017-02-08 12:31:36 --> Router Class Initialized
INFO - 2017-02-08 12:31:36 --> Output Class Initialized
INFO - 2017-02-08 12:31:36 --> Security Class Initialized
DEBUG - 2017-02-08 12:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:31:36 --> Input Class Initialized
INFO - 2017-02-08 12:31:36 --> Language Class Initialized
INFO - 2017-02-08 12:31:36 --> Language Class Initialized
INFO - 2017-02-08 12:31:36 --> Config Class Initialized
INFO - 2017-02-08 12:31:36 --> Loader Class Initialized
INFO - 2017-02-08 12:31:36 --> Helper loaded: form_helper
INFO - 2017-02-08 12:31:36 --> Helper loaded: url_helper
INFO - 2017-02-08 12:31:36 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:31:36 --> Database Driver Class Initialized
INFO - 2017-02-08 12:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:31:36 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:31:36 --> Template Class Initialized
INFO - 2017-02-08 12:31:36 --> Controller Class Initialized
DEBUG - 2017-02-08 12:31:36 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:31:36 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:31:36 --> Model Class Initialized
INFO - 2017-02-08 12:31:36 --> Model Class Initialized
ERROR - 2017-02-08 12:31:37 --> Severity: Notice --> Undefined variable: user_account C:\xampp\htdocs\mobile\application\modules\backend\views\partials\header.php 20
ERROR - 2017-02-08 12:31:37 --> Severity: Notice --> Undefined variable: user_account C:\xampp\htdocs\mobile\application\modules\backend\views\partials\header.php 21
DEBUG - 2017-02-08 12:31:37 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 12:31:37 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:31:37 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:31:37 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:31:37 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:31:37 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:31:37 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:31:37 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:31:37 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:31:37 --> Final output sent to browser
DEBUG - 2017-02-08 12:31:37 --> Total execution time: 0.0726
INFO - 2017-02-08 12:31:37 --> Config Class Initialized
INFO - 2017-02-08 12:31:37 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:31:37 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:31:37 --> Utf8 Class Initialized
INFO - 2017-02-08 12:31:37 --> Config Class Initialized
INFO - 2017-02-08 12:31:37 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:31:37 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:31:37 --> Utf8 Class Initialized
INFO - 2017-02-08 12:31:37 --> URI Class Initialized
INFO - 2017-02-08 12:31:37 --> Router Class Initialized
INFO - 2017-02-08 12:31:37 --> Output Class Initialized
INFO - 2017-02-08 12:31:37 --> Security Class Initialized
DEBUG - 2017-02-08 12:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:31:37 --> Input Class Initialized
INFO - 2017-02-08 12:31:37 --> Language Class Initialized
ERROR - 2017-02-08 12:31:37 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:33:25 --> Config Class Initialized
INFO - 2017-02-08 12:33:25 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:33:25 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:33:25 --> Utf8 Class Initialized
INFO - 2017-02-08 12:33:25 --> URI Class Initialized
INFO - 2017-02-08 12:33:25 --> Router Class Initialized
INFO - 2017-02-08 12:33:25 --> Output Class Initialized
INFO - 2017-02-08 12:33:25 --> Security Class Initialized
DEBUG - 2017-02-08 12:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:33:25 --> Input Class Initialized
INFO - 2017-02-08 12:33:25 --> Language Class Initialized
INFO - 2017-02-08 12:33:25 --> Language Class Initialized
INFO - 2017-02-08 12:33:25 --> Config Class Initialized
INFO - 2017-02-08 12:33:25 --> Loader Class Initialized
INFO - 2017-02-08 12:33:25 --> Helper loaded: form_helper
INFO - 2017-02-08 12:33:25 --> Helper loaded: url_helper
INFO - 2017-02-08 12:33:25 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:33:25 --> Database Driver Class Initialized
INFO - 2017-02-08 12:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:33:25 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:33:25 --> Template Class Initialized
INFO - 2017-02-08 12:33:25 --> Controller Class Initialized
DEBUG - 2017-02-08 12:33:25 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:33:25 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:33:25 --> Model Class Initialized
INFO - 2017-02-08 12:33:25 --> Model Class Initialized
ERROR - 2017-02-08 12:33:25 --> Severity: Notice --> Undefined variable: user_account C:\xampp\htdocs\mobile\application\modules\backend\views\partials\header.php 20
ERROR - 2017-02-08 12:33:25 --> Severity: Notice --> Undefined variable: user_account C:\xampp\htdocs\mobile\application\modules\backend\views\partials\header.php 21
DEBUG - 2017-02-08 12:33:25 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 12:33:25 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:33:25 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:33:25 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:33:25 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:33:25 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:33:25 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:33:25 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:33:25 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:33:25 --> Final output sent to browser
DEBUG - 2017-02-08 12:33:25 --> Total execution time: 0.0574
INFO - 2017-02-08 12:33:25 --> Config Class Initialized
INFO - 2017-02-08 12:33:25 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:33:25 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:33:25 --> Utf8 Class Initialized
INFO - 2017-02-08 12:33:25 --> Config Class Initialized
INFO - 2017-02-08 12:33:25 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:33:25 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:33:25 --> Utf8 Class Initialized
INFO - 2017-02-08 12:33:25 --> URI Class Initialized
INFO - 2017-02-08 12:33:25 --> Router Class Initialized
INFO - 2017-02-08 12:33:25 --> Output Class Initialized
INFO - 2017-02-08 12:33:25 --> Security Class Initialized
DEBUG - 2017-02-08 12:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:33:25 --> Input Class Initialized
INFO - 2017-02-08 12:33:25 --> Language Class Initialized
ERROR - 2017-02-08 12:33:25 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:33:27 --> Config Class Initialized
INFO - 2017-02-08 12:33:27 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:33:28 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:33:28 --> Utf8 Class Initialized
INFO - 2017-02-08 12:33:28 --> URI Class Initialized
INFO - 2017-02-08 12:33:28 --> Router Class Initialized
INFO - 2017-02-08 12:33:28 --> Output Class Initialized
INFO - 2017-02-08 12:33:28 --> Security Class Initialized
DEBUG - 2017-02-08 12:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:33:28 --> Input Class Initialized
INFO - 2017-02-08 12:33:28 --> Language Class Initialized
INFO - 2017-02-08 12:33:28 --> Language Class Initialized
INFO - 2017-02-08 12:33:28 --> Config Class Initialized
INFO - 2017-02-08 12:33:28 --> Loader Class Initialized
INFO - 2017-02-08 12:33:28 --> Helper loaded: form_helper
INFO - 2017-02-08 12:33:28 --> Helper loaded: url_helper
INFO - 2017-02-08 12:33:28 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:33:28 --> Database Driver Class Initialized
INFO - 2017-02-08 12:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:33:28 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:33:28 --> Template Class Initialized
INFO - 2017-02-08 12:33:28 --> Controller Class Initialized
DEBUG - 2017-02-08 12:33:28 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:33:28 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:33:28 --> Model Class Initialized
INFO - 2017-02-08 12:33:28 --> Model Class Initialized
DEBUG - 2017-02-08 12:33:28 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-08 12:33:28 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:33:28 --> Final output sent to browser
DEBUG - 2017-02-08 12:33:28 --> Total execution time: 0.0558
INFO - 2017-02-08 12:33:32 --> Config Class Initialized
INFO - 2017-02-08 12:33:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:33:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:33:32 --> Utf8 Class Initialized
INFO - 2017-02-08 12:33:32 --> URI Class Initialized
INFO - 2017-02-08 12:33:32 --> Router Class Initialized
INFO - 2017-02-08 12:33:33 --> Output Class Initialized
INFO - 2017-02-08 12:33:33 --> Security Class Initialized
DEBUG - 2017-02-08 12:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:33:33 --> Input Class Initialized
INFO - 2017-02-08 12:33:33 --> Language Class Initialized
INFO - 2017-02-08 12:33:33 --> Language Class Initialized
INFO - 2017-02-08 12:33:33 --> Config Class Initialized
INFO - 2017-02-08 12:33:33 --> Loader Class Initialized
INFO - 2017-02-08 12:33:33 --> Helper loaded: form_helper
INFO - 2017-02-08 12:33:33 --> Helper loaded: url_helper
INFO - 2017-02-08 12:33:33 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:33:33 --> Database Driver Class Initialized
INFO - 2017-02-08 12:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:33:33 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:33:33 --> Template Class Initialized
INFO - 2017-02-08 12:33:33 --> Controller Class Initialized
DEBUG - 2017-02-08 12:33:33 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:33:33 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:33:33 --> Model Class Initialized
INFO - 2017-02-08 12:33:33 --> Model Class Initialized
ERROR - 2017-02-08 12:33:33 --> Severity: Notice --> Undefined index: mobile C:\xampp\htdocs\mobile\application\modules\backend\controllers\Login.php 31
INFO - 2017-02-08 12:33:33 --> Config Class Initialized
INFO - 2017-02-08 12:33:33 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:33:33 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:33:33 --> Utf8 Class Initialized
INFO - 2017-02-08 12:33:33 --> URI Class Initialized
INFO - 2017-02-08 12:33:33 --> Router Class Initialized
INFO - 2017-02-08 12:33:33 --> Output Class Initialized
INFO - 2017-02-08 12:33:33 --> Security Class Initialized
DEBUG - 2017-02-08 12:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:33:33 --> Input Class Initialized
INFO - 2017-02-08 12:33:33 --> Language Class Initialized
INFO - 2017-02-08 12:33:33 --> Language Class Initialized
INFO - 2017-02-08 12:33:33 --> Config Class Initialized
INFO - 2017-02-08 12:33:33 --> Loader Class Initialized
INFO - 2017-02-08 12:33:33 --> Helper loaded: form_helper
INFO - 2017-02-08 12:33:33 --> Helper loaded: url_helper
INFO - 2017-02-08 12:33:33 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:33:33 --> Database Driver Class Initialized
INFO - 2017-02-08 12:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:33:33 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:33:33 --> Template Class Initialized
INFO - 2017-02-08 12:33:33 --> Controller Class Initialized
DEBUG - 2017-02-08 12:33:33 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:33:33 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:33:33 --> Model Class Initialized
INFO - 2017-02-08 12:33:33 --> Model Class Initialized
ERROR - 2017-02-08 12:33:33 --> Severity: Notice --> Undefined variable: user_account C:\xampp\htdocs\mobile\application\modules\backend\views\partials\header.php 20
ERROR - 2017-02-08 12:33:33 --> Severity: Notice --> Undefined variable: user_account C:\xampp\htdocs\mobile\application\modules\backend\views\partials\header.php 21
DEBUG - 2017-02-08 12:33:33 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 12:33:33 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:33:33 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:33:33 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:33:33 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:33:33 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:33:33 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:33:33 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:33:33 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:33:33 --> Final output sent to browser
DEBUG - 2017-02-08 12:33:33 --> Total execution time: 0.0520
INFO - 2017-02-08 12:33:33 --> Config Class Initialized
INFO - 2017-02-08 12:33:33 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:33:33 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:33:33 --> Utf8 Class Initialized
INFO - 2017-02-08 12:33:33 --> Config Class Initialized
INFO - 2017-02-08 12:33:33 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:33:33 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:33:33 --> Utf8 Class Initialized
INFO - 2017-02-08 12:33:33 --> URI Class Initialized
INFO - 2017-02-08 12:33:33 --> Router Class Initialized
INFO - 2017-02-08 12:33:33 --> Output Class Initialized
INFO - 2017-02-08 12:33:33 --> Security Class Initialized
DEBUG - 2017-02-08 12:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:33:33 --> Input Class Initialized
INFO - 2017-02-08 12:33:33 --> Language Class Initialized
ERROR - 2017-02-08 12:33:33 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:34:04 --> Config Class Initialized
INFO - 2017-02-08 12:34:04 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:34:04 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:34:04 --> Utf8 Class Initialized
INFO - 2017-02-08 12:34:04 --> URI Class Initialized
INFO - 2017-02-08 12:34:04 --> Router Class Initialized
INFO - 2017-02-08 12:34:04 --> Output Class Initialized
INFO - 2017-02-08 12:34:04 --> Security Class Initialized
DEBUG - 2017-02-08 12:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:34:04 --> Input Class Initialized
INFO - 2017-02-08 12:34:04 --> Language Class Initialized
INFO - 2017-02-08 12:34:04 --> Language Class Initialized
INFO - 2017-02-08 12:34:04 --> Config Class Initialized
INFO - 2017-02-08 12:34:04 --> Loader Class Initialized
INFO - 2017-02-08 12:34:04 --> Helper loaded: form_helper
INFO - 2017-02-08 12:34:04 --> Helper loaded: url_helper
INFO - 2017-02-08 12:34:04 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:34:04 --> Database Driver Class Initialized
INFO - 2017-02-08 12:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:34:04 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:34:04 --> Template Class Initialized
INFO - 2017-02-08 12:34:04 --> Controller Class Initialized
DEBUG - 2017-02-08 12:34:04 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:34:04 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:34:04 --> Model Class Initialized
INFO - 2017-02-08 12:34:04 --> Model Class Initialized
ERROR - 2017-02-08 12:34:04 --> Severity: Notice --> Undefined variable: user_account C:\xampp\htdocs\mobile\application\modules\backend\views\partials\header.php 21
DEBUG - 2017-02-08 12:34:04 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 12:34:04 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:34:04 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:34:04 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:34:04 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:34:04 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:34:04 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:34:04 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:34:04 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:34:04 --> Final output sent to browser
DEBUG - 2017-02-08 12:34:04 --> Total execution time: 0.0577
INFO - 2017-02-08 12:34:04 --> Config Class Initialized
INFO - 2017-02-08 12:34:04 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:34:04 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:34:04 --> Utf8 Class Initialized
INFO - 2017-02-08 12:34:04 --> URI Class Initialized
INFO - 2017-02-08 12:34:04 --> Router Class Initialized
INFO - 2017-02-08 12:34:04 --> Output Class Initialized
INFO - 2017-02-08 12:34:04 --> Security Class Initialized
DEBUG - 2017-02-08 12:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:34:04 --> Input Class Initialized
INFO - 2017-02-08 12:34:04 --> Language Class Initialized
ERROR - 2017-02-08 12:34:04 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:34:04 --> Config Class Initialized
INFO - 2017-02-08 12:34:04 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:34:04 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:34:04 --> Utf8 Class Initialized
INFO - 2017-02-08 12:34:04 --> URI Class Initialized
INFO - 2017-02-08 12:34:04 --> Router Class Initialized
INFO - 2017-02-08 12:34:04 --> Output Class Initialized
INFO - 2017-02-08 12:34:04 --> Security Class Initialized
DEBUG - 2017-02-08 12:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:34:04 --> Input Class Initialized
INFO - 2017-02-08 12:34:04 --> Language Class Initialized
ERROR - 2017-02-08 12:34:04 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:34:22 --> Config Class Initialized
INFO - 2017-02-08 12:34:22 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:34:22 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:34:22 --> Utf8 Class Initialized
INFO - 2017-02-08 12:34:22 --> URI Class Initialized
INFO - 2017-02-08 12:34:22 --> Router Class Initialized
INFO - 2017-02-08 12:34:22 --> Output Class Initialized
INFO - 2017-02-08 12:34:22 --> Security Class Initialized
DEBUG - 2017-02-08 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:34:22 --> Input Class Initialized
INFO - 2017-02-08 12:34:22 --> Language Class Initialized
INFO - 2017-02-08 12:34:22 --> Language Class Initialized
INFO - 2017-02-08 12:34:22 --> Config Class Initialized
INFO - 2017-02-08 12:34:22 --> Loader Class Initialized
INFO - 2017-02-08 12:34:22 --> Helper loaded: form_helper
INFO - 2017-02-08 12:34:22 --> Helper loaded: url_helper
INFO - 2017-02-08 12:34:22 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:34:22 --> Database Driver Class Initialized
INFO - 2017-02-08 12:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:34:22 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:34:22 --> Template Class Initialized
INFO - 2017-02-08 12:34:22 --> Controller Class Initialized
DEBUG - 2017-02-08 12:34:22 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:34:22 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:34:22 --> Model Class Initialized
INFO - 2017-02-08 12:34:22 --> Model Class Initialized
ERROR - 2017-02-08 12:34:22 --> Severity: Notice --> Undefined variable: user_account C:\xampp\htdocs\mobile\application\modules\backend\views\partials\header.php 21
DEBUG - 2017-02-08 12:34:22 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 12:34:22 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:34:22 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:34:22 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:34:22 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:34:22 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:34:22 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:34:22 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:34:22 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:34:22 --> Final output sent to browser
DEBUG - 2017-02-08 12:34:22 --> Total execution time: 0.0581
INFO - 2017-02-08 12:34:22 --> Config Class Initialized
INFO - 2017-02-08 12:34:22 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:34:22 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:34:22 --> Utf8 Class Initialized
INFO - 2017-02-08 12:34:22 --> URI Class Initialized
INFO - 2017-02-08 12:34:22 --> Router Class Initialized
INFO - 2017-02-08 12:34:22 --> Output Class Initialized
INFO - 2017-02-08 12:34:22 --> Security Class Initialized
DEBUG - 2017-02-08 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:34:22 --> Input Class Initialized
INFO - 2017-02-08 12:34:22 --> Language Class Initialized
ERROR - 2017-02-08 12:34:22 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:34:22 --> Config Class Initialized
INFO - 2017-02-08 12:34:22 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:34:22 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:34:22 --> Utf8 Class Initialized
INFO - 2017-02-08 12:34:22 --> URI Class Initialized
INFO - 2017-02-08 12:34:22 --> Router Class Initialized
INFO - 2017-02-08 12:34:22 --> Output Class Initialized
INFO - 2017-02-08 12:34:22 --> Security Class Initialized
DEBUG - 2017-02-08 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:34:22 --> Input Class Initialized
INFO - 2017-02-08 12:34:22 --> Language Class Initialized
ERROR - 2017-02-08 12:34:22 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:34:26 --> Config Class Initialized
INFO - 2017-02-08 12:34:26 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:34:26 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:34:26 --> Utf8 Class Initialized
INFO - 2017-02-08 12:34:26 --> URI Class Initialized
INFO - 2017-02-08 12:34:26 --> Router Class Initialized
INFO - 2017-02-08 12:34:26 --> Output Class Initialized
INFO - 2017-02-08 12:34:26 --> Security Class Initialized
DEBUG - 2017-02-08 12:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:34:26 --> Input Class Initialized
INFO - 2017-02-08 12:34:26 --> Language Class Initialized
INFO - 2017-02-08 12:34:26 --> Language Class Initialized
INFO - 2017-02-08 12:34:26 --> Config Class Initialized
INFO - 2017-02-08 12:34:26 --> Loader Class Initialized
INFO - 2017-02-08 12:34:26 --> Helper loaded: form_helper
INFO - 2017-02-08 12:34:26 --> Helper loaded: url_helper
INFO - 2017-02-08 12:34:26 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:34:26 --> Database Driver Class Initialized
INFO - 2017-02-08 12:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:34:26 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:34:26 --> Template Class Initialized
INFO - 2017-02-08 12:34:26 --> Controller Class Initialized
DEBUG - 2017-02-08 12:34:26 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:34:26 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:34:26 --> Model Class Initialized
INFO - 2017-02-08 12:34:26 --> Model Class Initialized
DEBUG - 2017-02-08 12:34:26 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-08 12:34:26 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:34:26 --> Final output sent to browser
DEBUG - 2017-02-08 12:34:26 --> Total execution time: 0.0460
INFO - 2017-02-08 12:34:30 --> Config Class Initialized
INFO - 2017-02-08 12:34:30 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:34:30 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:34:30 --> Utf8 Class Initialized
INFO - 2017-02-08 12:34:30 --> URI Class Initialized
INFO - 2017-02-08 12:34:30 --> Router Class Initialized
INFO - 2017-02-08 12:34:30 --> Output Class Initialized
INFO - 2017-02-08 12:34:30 --> Security Class Initialized
DEBUG - 2017-02-08 12:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:34:30 --> Input Class Initialized
INFO - 2017-02-08 12:34:30 --> Language Class Initialized
INFO - 2017-02-08 12:34:30 --> Language Class Initialized
INFO - 2017-02-08 12:34:30 --> Config Class Initialized
INFO - 2017-02-08 12:34:30 --> Loader Class Initialized
INFO - 2017-02-08 12:34:30 --> Helper loaded: form_helper
INFO - 2017-02-08 12:34:30 --> Helper loaded: url_helper
INFO - 2017-02-08 12:34:30 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:34:30 --> Database Driver Class Initialized
INFO - 2017-02-08 12:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:34:30 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:34:30 --> Template Class Initialized
INFO - 2017-02-08 12:34:30 --> Controller Class Initialized
DEBUG - 2017-02-08 12:34:30 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:34:30 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:34:30 --> Model Class Initialized
INFO - 2017-02-08 12:34:30 --> Model Class Initialized
ERROR - 2017-02-08 12:34:30 --> Severity: Notice --> Undefined index: mobile C:\xampp\htdocs\mobile\application\modules\backend\controllers\Login.php 31
INFO - 2017-02-08 12:34:30 --> Config Class Initialized
INFO - 2017-02-08 12:34:30 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:34:30 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:34:30 --> Utf8 Class Initialized
INFO - 2017-02-08 12:34:30 --> URI Class Initialized
INFO - 2017-02-08 12:34:30 --> Router Class Initialized
INFO - 2017-02-08 12:34:30 --> Output Class Initialized
INFO - 2017-02-08 12:34:30 --> Security Class Initialized
DEBUG - 2017-02-08 12:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:34:30 --> Input Class Initialized
INFO - 2017-02-08 12:34:30 --> Language Class Initialized
INFO - 2017-02-08 12:34:30 --> Language Class Initialized
INFO - 2017-02-08 12:34:30 --> Config Class Initialized
INFO - 2017-02-08 12:34:30 --> Loader Class Initialized
INFO - 2017-02-08 12:34:30 --> Helper loaded: form_helper
INFO - 2017-02-08 12:34:30 --> Helper loaded: url_helper
INFO - 2017-02-08 12:34:30 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:34:30 --> Database Driver Class Initialized
INFO - 2017-02-08 12:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:34:30 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:34:30 --> Template Class Initialized
INFO - 2017-02-08 12:34:30 --> Controller Class Initialized
DEBUG - 2017-02-08 12:34:30 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:34:30 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:34:30 --> Model Class Initialized
INFO - 2017-02-08 12:34:30 --> Model Class Initialized
ERROR - 2017-02-08 12:34:30 --> Severity: Notice --> Undefined variable: user_account C:\xampp\htdocs\mobile\application\modules\backend\views\partials\header.php 21
DEBUG - 2017-02-08 12:34:30 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 12:34:30 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:34:30 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:34:30 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:34:30 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:34:30 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:34:30 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:34:30 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:34:30 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:34:30 --> Final output sent to browser
DEBUG - 2017-02-08 12:34:30 --> Total execution time: 0.0512
INFO - 2017-02-08 12:34:30 --> Config Class Initialized
INFO - 2017-02-08 12:34:30 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:34:30 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:34:30 --> Utf8 Class Initialized
INFO - 2017-02-08 12:34:30 --> URI Class Initialized
INFO - 2017-02-08 12:34:30 --> Router Class Initialized
INFO - 2017-02-08 12:34:30 --> Output Class Initialized
INFO - 2017-02-08 12:34:30 --> Security Class Initialized
DEBUG - 2017-02-08 12:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:34:30 --> Input Class Initialized
INFO - 2017-02-08 12:34:30 --> Language Class Initialized
ERROR - 2017-02-08 12:34:30 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:34:30 --> Config Class Initialized
INFO - 2017-02-08 12:34:30 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:34:30 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:34:30 --> Utf8 Class Initialized
INFO - 2017-02-08 12:34:30 --> URI Class Initialized
INFO - 2017-02-08 12:34:30 --> Router Class Initialized
INFO - 2017-02-08 12:34:30 --> Output Class Initialized
INFO - 2017-02-08 12:34:30 --> Security Class Initialized
DEBUG - 2017-02-08 12:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:34:30 --> Input Class Initialized
INFO - 2017-02-08 12:34:30 --> Language Class Initialized
ERROR - 2017-02-08 12:34:30 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:34:41 --> Config Class Initialized
INFO - 2017-02-08 12:34:41 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:34:41 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:34:41 --> Utf8 Class Initialized
INFO - 2017-02-08 12:34:41 --> URI Class Initialized
INFO - 2017-02-08 12:34:41 --> Router Class Initialized
INFO - 2017-02-08 12:34:41 --> Output Class Initialized
INFO - 2017-02-08 12:34:41 --> Security Class Initialized
DEBUG - 2017-02-08 12:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:34:41 --> Input Class Initialized
INFO - 2017-02-08 12:34:41 --> Language Class Initialized
INFO - 2017-02-08 12:34:41 --> Language Class Initialized
INFO - 2017-02-08 12:34:41 --> Config Class Initialized
INFO - 2017-02-08 12:34:41 --> Loader Class Initialized
INFO - 2017-02-08 12:34:41 --> Helper loaded: form_helper
INFO - 2017-02-08 12:34:41 --> Helper loaded: url_helper
INFO - 2017-02-08 12:34:41 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:34:41 --> Database Driver Class Initialized
INFO - 2017-02-08 12:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:34:41 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:34:41 --> Template Class Initialized
INFO - 2017-02-08 12:34:41 --> Controller Class Initialized
DEBUG - 2017-02-08 12:34:41 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:34:41 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:34:41 --> Model Class Initialized
INFO - 2017-02-08 12:34:41 --> Model Class Initialized
DEBUG - 2017-02-08 12:34:41 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 12:34:41 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:34:41 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:34:41 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:34:41 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:34:41 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:34:41 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:34:41 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:34:41 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:34:41 --> Final output sent to browser
DEBUG - 2017-02-08 12:34:41 --> Total execution time: 0.0710
INFO - 2017-02-08 12:34:41 --> Config Class Initialized
INFO - 2017-02-08 12:34:41 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:34:41 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:34:41 --> Utf8 Class Initialized
INFO - 2017-02-08 12:34:41 --> URI Class Initialized
INFO - 2017-02-08 12:34:41 --> Router Class Initialized
INFO - 2017-02-08 12:34:41 --> Output Class Initialized
INFO - 2017-02-08 12:34:41 --> Security Class Initialized
DEBUG - 2017-02-08 12:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:34:41 --> Input Class Initialized
INFO - 2017-02-08 12:34:41 --> Language Class Initialized
ERROR - 2017-02-08 12:34:42 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:34:42 --> Config Class Initialized
INFO - 2017-02-08 12:34:42 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:34:42 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:34:42 --> Utf8 Class Initialized
INFO - 2017-02-08 12:34:42 --> URI Class Initialized
INFO - 2017-02-08 12:34:42 --> Router Class Initialized
INFO - 2017-02-08 12:34:42 --> Output Class Initialized
INFO - 2017-02-08 12:34:42 --> Security Class Initialized
DEBUG - 2017-02-08 12:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:34:42 --> Input Class Initialized
INFO - 2017-02-08 12:34:42 --> Language Class Initialized
ERROR - 2017-02-08 12:34:42 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:35:29 --> Config Class Initialized
INFO - 2017-02-08 12:35:29 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:35:29 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:35:29 --> Utf8 Class Initialized
INFO - 2017-02-08 12:35:29 --> URI Class Initialized
INFO - 2017-02-08 12:35:29 --> Router Class Initialized
INFO - 2017-02-08 12:35:29 --> Output Class Initialized
INFO - 2017-02-08 12:35:29 --> Security Class Initialized
DEBUG - 2017-02-08 12:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:35:29 --> Input Class Initialized
INFO - 2017-02-08 12:35:29 --> Language Class Initialized
INFO - 2017-02-08 12:35:29 --> Language Class Initialized
INFO - 2017-02-08 12:35:29 --> Config Class Initialized
INFO - 2017-02-08 12:35:29 --> Loader Class Initialized
INFO - 2017-02-08 12:35:29 --> Helper loaded: form_helper
INFO - 2017-02-08 12:35:29 --> Helper loaded: url_helper
INFO - 2017-02-08 12:35:29 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:35:29 --> Database Driver Class Initialized
INFO - 2017-02-08 12:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:35:29 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:35:29 --> Template Class Initialized
INFO - 2017-02-08 12:35:29 --> Controller Class Initialized
DEBUG - 2017-02-08 12:35:29 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:35:29 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:35:29 --> Model Class Initialized
INFO - 2017-02-08 12:35:29 --> Model Class Initialized
DEBUG - 2017-02-08 12:35:29 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 12:35:29 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:35:29 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:35:29 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:35:29 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:35:29 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:35:29 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:35:29 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:35:29 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:35:29 --> Final output sent to browser
DEBUG - 2017-02-08 12:35:29 --> Total execution time: 0.0618
INFO - 2017-02-08 12:35:29 --> Config Class Initialized
INFO - 2017-02-08 12:35:29 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:35:29 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:35:29 --> Utf8 Class Initialized
INFO - 2017-02-08 12:35:29 --> URI Class Initialized
INFO - 2017-02-08 12:35:29 --> Router Class Initialized
INFO - 2017-02-08 12:35:29 --> Output Class Initialized
INFO - 2017-02-08 12:35:29 --> Security Class Initialized
DEBUG - 2017-02-08 12:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:35:29 --> Input Class Initialized
INFO - 2017-02-08 12:35:29 --> Language Class Initialized
ERROR - 2017-02-08 12:35:29 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:35:29 --> Config Class Initialized
INFO - 2017-02-08 12:35:29 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:35:29 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:35:29 --> Utf8 Class Initialized
INFO - 2017-02-08 12:35:29 --> URI Class Initialized
INFO - 2017-02-08 12:35:29 --> Router Class Initialized
INFO - 2017-02-08 12:35:29 --> Output Class Initialized
INFO - 2017-02-08 12:35:29 --> Security Class Initialized
DEBUG - 2017-02-08 12:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:35:30 --> Input Class Initialized
INFO - 2017-02-08 12:35:30 --> Language Class Initialized
ERROR - 2017-02-08 12:35:30 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:36:11 --> Config Class Initialized
INFO - 2017-02-08 12:36:11 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:36:11 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:36:11 --> Utf8 Class Initialized
INFO - 2017-02-08 12:36:11 --> URI Class Initialized
INFO - 2017-02-08 12:36:11 --> Router Class Initialized
INFO - 2017-02-08 12:36:11 --> Output Class Initialized
INFO - 2017-02-08 12:36:11 --> Security Class Initialized
DEBUG - 2017-02-08 12:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:36:11 --> Input Class Initialized
INFO - 2017-02-08 12:36:11 --> Language Class Initialized
INFO - 2017-02-08 12:36:11 --> Language Class Initialized
INFO - 2017-02-08 12:36:11 --> Config Class Initialized
INFO - 2017-02-08 12:36:11 --> Loader Class Initialized
INFO - 2017-02-08 12:36:11 --> Helper loaded: form_helper
INFO - 2017-02-08 12:36:11 --> Helper loaded: url_helper
INFO - 2017-02-08 12:36:11 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:36:11 --> Database Driver Class Initialized
INFO - 2017-02-08 12:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:36:11 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:36:11 --> Template Class Initialized
INFO - 2017-02-08 12:36:11 --> Controller Class Initialized
DEBUG - 2017-02-08 12:36:11 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:36:11 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:36:11 --> Model Class Initialized
INFO - 2017-02-08 12:36:11 --> Model Class Initialized
DEBUG - 2017-02-08 12:36:11 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 12:36:11 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:36:11 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:36:11 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:36:11 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:36:11 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:36:11 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:36:11 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:36:11 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:36:11 --> Final output sent to browser
DEBUG - 2017-02-08 12:36:11 --> Total execution time: 0.0556
INFO - 2017-02-08 12:36:11 --> Config Class Initialized
INFO - 2017-02-08 12:36:11 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:36:11 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:36:11 --> Utf8 Class Initialized
INFO - 2017-02-08 12:36:11 --> URI Class Initialized
INFO - 2017-02-08 12:36:11 --> Router Class Initialized
INFO - 2017-02-08 12:36:11 --> Output Class Initialized
INFO - 2017-02-08 12:36:11 --> Security Class Initialized
DEBUG - 2017-02-08 12:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:36:11 --> Input Class Initialized
INFO - 2017-02-08 12:36:11 --> Language Class Initialized
ERROR - 2017-02-08 12:36:11 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:36:11 --> Config Class Initialized
INFO - 2017-02-08 12:36:11 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:36:11 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:36:11 --> Utf8 Class Initialized
INFO - 2017-02-08 12:36:11 --> URI Class Initialized
INFO - 2017-02-08 12:36:11 --> Router Class Initialized
INFO - 2017-02-08 12:36:11 --> Output Class Initialized
INFO - 2017-02-08 12:36:11 --> Security Class Initialized
DEBUG - 2017-02-08 12:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:36:11 --> Input Class Initialized
INFO - 2017-02-08 12:36:11 --> Language Class Initialized
ERROR - 2017-02-08 12:36:11 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:36:53 --> Config Class Initialized
INFO - 2017-02-08 12:36:53 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:36:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:36:53 --> Utf8 Class Initialized
INFO - 2017-02-08 12:36:53 --> URI Class Initialized
INFO - 2017-02-08 12:36:53 --> Router Class Initialized
INFO - 2017-02-08 12:36:53 --> Output Class Initialized
INFO - 2017-02-08 12:36:53 --> Security Class Initialized
DEBUG - 2017-02-08 12:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:36:53 --> Input Class Initialized
INFO - 2017-02-08 12:36:53 --> Language Class Initialized
INFO - 2017-02-08 12:36:53 --> Language Class Initialized
INFO - 2017-02-08 12:36:53 --> Config Class Initialized
INFO - 2017-02-08 12:36:53 --> Loader Class Initialized
INFO - 2017-02-08 12:36:53 --> Helper loaded: form_helper
INFO - 2017-02-08 12:36:53 --> Helper loaded: url_helper
INFO - 2017-02-08 12:36:53 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:36:53 --> Database Driver Class Initialized
INFO - 2017-02-08 12:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:36:53 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:36:53 --> Template Class Initialized
INFO - 2017-02-08 12:36:53 --> Controller Class Initialized
DEBUG - 2017-02-08 12:36:53 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:36:53 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:36:53 --> Model Class Initialized
INFO - 2017-02-08 12:36:53 --> Model Class Initialized
DEBUG - 2017-02-08 12:36:53 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 12:36:53 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:36:53 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:36:53 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:36:53 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:36:53 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:36:53 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:36:53 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:36:53 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:36:53 --> Final output sent to browser
DEBUG - 2017-02-08 12:36:53 --> Total execution time: 0.0560
INFO - 2017-02-08 12:36:53 --> Config Class Initialized
INFO - 2017-02-08 12:36:53 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:36:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:36:53 --> Utf8 Class Initialized
INFO - 2017-02-08 12:36:53 --> URI Class Initialized
INFO - 2017-02-08 12:36:53 --> Router Class Initialized
INFO - 2017-02-08 12:36:53 --> Output Class Initialized
INFO - 2017-02-08 12:36:53 --> Security Class Initialized
DEBUG - 2017-02-08 12:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:36:53 --> Input Class Initialized
INFO - 2017-02-08 12:36:53 --> Language Class Initialized
ERROR - 2017-02-08 12:36:53 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:36:53 --> Config Class Initialized
INFO - 2017-02-08 12:36:53 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:36:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:36:53 --> Utf8 Class Initialized
INFO - 2017-02-08 12:36:53 --> URI Class Initialized
INFO - 2017-02-08 12:36:53 --> Router Class Initialized
INFO - 2017-02-08 12:36:53 --> Output Class Initialized
INFO - 2017-02-08 12:36:53 --> Security Class Initialized
DEBUG - 2017-02-08 12:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:36:53 --> Input Class Initialized
INFO - 2017-02-08 12:36:53 --> Language Class Initialized
ERROR - 2017-02-08 12:36:53 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:37:50 --> Config Class Initialized
INFO - 2017-02-08 12:37:50 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:37:50 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:37:50 --> Utf8 Class Initialized
INFO - 2017-02-08 12:37:50 --> URI Class Initialized
INFO - 2017-02-08 12:37:50 --> Router Class Initialized
INFO - 2017-02-08 12:37:50 --> Output Class Initialized
INFO - 2017-02-08 12:37:50 --> Security Class Initialized
DEBUG - 2017-02-08 12:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:37:50 --> Input Class Initialized
INFO - 2017-02-08 12:37:50 --> Language Class Initialized
INFO - 2017-02-08 12:37:50 --> Language Class Initialized
INFO - 2017-02-08 12:37:50 --> Config Class Initialized
INFO - 2017-02-08 12:37:50 --> Loader Class Initialized
INFO - 2017-02-08 12:37:50 --> Helper loaded: form_helper
INFO - 2017-02-08 12:37:50 --> Helper loaded: url_helper
INFO - 2017-02-08 12:37:50 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:37:50 --> Database Driver Class Initialized
INFO - 2017-02-08 12:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:37:50 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:37:50 --> Template Class Initialized
INFO - 2017-02-08 12:37:50 --> Controller Class Initialized
DEBUG - 2017-02-08 12:37:50 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:37:50 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:37:50 --> Model Class Initialized
INFO - 2017-02-08 12:37:50 --> Model Class Initialized
DEBUG - 2017-02-08 12:37:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 12:37:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:37:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:37:50 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:37:50 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:37:50 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:37:50 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:37:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:37:50 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:37:50 --> Final output sent to browser
DEBUG - 2017-02-08 12:37:50 --> Total execution time: 0.0534
INFO - 2017-02-08 12:37:50 --> Config Class Initialized
INFO - 2017-02-08 12:37:50 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:37:50 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:37:50 --> Utf8 Class Initialized
INFO - 2017-02-08 12:37:50 --> URI Class Initialized
INFO - 2017-02-08 12:37:50 --> Router Class Initialized
INFO - 2017-02-08 12:37:50 --> Output Class Initialized
INFO - 2017-02-08 12:37:50 --> Security Class Initialized
DEBUG - 2017-02-08 12:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:37:50 --> Input Class Initialized
INFO - 2017-02-08 12:37:50 --> Language Class Initialized
ERROR - 2017-02-08 12:37:50 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:37:50 --> Config Class Initialized
INFO - 2017-02-08 12:37:50 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:37:50 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:37:50 --> Utf8 Class Initialized
INFO - 2017-02-08 12:37:50 --> URI Class Initialized
INFO - 2017-02-08 12:37:50 --> Router Class Initialized
INFO - 2017-02-08 12:37:50 --> Output Class Initialized
INFO - 2017-02-08 12:37:50 --> Security Class Initialized
DEBUG - 2017-02-08 12:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:37:50 --> Input Class Initialized
INFO - 2017-02-08 12:37:50 --> Language Class Initialized
ERROR - 2017-02-08 12:37:50 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:37:53 --> Config Class Initialized
INFO - 2017-02-08 12:37:53 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:37:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:37:53 --> Utf8 Class Initialized
INFO - 2017-02-08 12:37:53 --> URI Class Initialized
INFO - 2017-02-08 12:37:53 --> Router Class Initialized
INFO - 2017-02-08 12:37:53 --> Output Class Initialized
INFO - 2017-02-08 12:37:53 --> Security Class Initialized
DEBUG - 2017-02-08 12:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:37:53 --> Input Class Initialized
INFO - 2017-02-08 12:37:53 --> Language Class Initialized
ERROR - 2017-02-08 12:37:53 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-08 12:37:55 --> Config Class Initialized
INFO - 2017-02-08 12:37:55 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:37:55 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:37:55 --> Utf8 Class Initialized
INFO - 2017-02-08 12:37:55 --> URI Class Initialized
INFO - 2017-02-08 12:37:55 --> Router Class Initialized
INFO - 2017-02-08 12:37:55 --> Output Class Initialized
INFO - 2017-02-08 12:37:55 --> Security Class Initialized
DEBUG - 2017-02-08 12:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:37:55 --> Input Class Initialized
INFO - 2017-02-08 12:37:55 --> Language Class Initialized
INFO - 2017-02-08 12:37:55 --> Language Class Initialized
INFO - 2017-02-08 12:37:55 --> Config Class Initialized
INFO - 2017-02-08 12:37:55 --> Loader Class Initialized
INFO - 2017-02-08 12:37:55 --> Helper loaded: form_helper
INFO - 2017-02-08 12:37:55 --> Helper loaded: url_helper
INFO - 2017-02-08 12:37:55 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:37:55 --> Database Driver Class Initialized
INFO - 2017-02-08 12:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:37:55 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:37:55 --> Template Class Initialized
INFO - 2017-02-08 12:37:55 --> Controller Class Initialized
DEBUG - 2017-02-08 12:37:55 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:37:55 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:37:55 --> Model Class Initialized
INFO - 2017-02-08 12:37:55 --> Model Class Initialized
DEBUG - 2017-02-08 12:37:55 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 12:37:55 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:37:55 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:37:55 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:37:55 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:37:55 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:37:55 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:37:55 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:37:55 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:37:55 --> Final output sent to browser
DEBUG - 2017-02-08 12:37:55 --> Total execution time: 0.0482
INFO - 2017-02-08 12:42:06 --> Config Class Initialized
INFO - 2017-02-08 12:42:06 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:42:06 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:42:06 --> Utf8 Class Initialized
INFO - 2017-02-08 12:42:06 --> URI Class Initialized
INFO - 2017-02-08 12:42:06 --> Router Class Initialized
INFO - 2017-02-08 12:42:06 --> Output Class Initialized
INFO - 2017-02-08 12:42:06 --> Security Class Initialized
DEBUG - 2017-02-08 12:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:42:06 --> Input Class Initialized
INFO - 2017-02-08 12:42:06 --> Language Class Initialized
ERROR - 2017-02-08 12:42:06 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-08 12:42:10 --> Config Class Initialized
INFO - 2017-02-08 12:42:10 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:42:10 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:42:10 --> Utf8 Class Initialized
INFO - 2017-02-08 12:42:10 --> URI Class Initialized
INFO - 2017-02-08 12:42:10 --> Router Class Initialized
INFO - 2017-02-08 12:42:10 --> Output Class Initialized
INFO - 2017-02-08 12:42:10 --> Security Class Initialized
DEBUG - 2017-02-08 12:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:42:10 --> Input Class Initialized
INFO - 2017-02-08 12:42:10 --> Language Class Initialized
ERROR - 2017-02-08 12:42:10 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-08 12:42:19 --> Config Class Initialized
INFO - 2017-02-08 12:42:19 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:42:19 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:42:19 --> Utf8 Class Initialized
INFO - 2017-02-08 12:42:19 --> URI Class Initialized
INFO - 2017-02-08 12:42:19 --> Router Class Initialized
INFO - 2017-02-08 12:42:19 --> Output Class Initialized
INFO - 2017-02-08 12:42:19 --> Security Class Initialized
DEBUG - 2017-02-08 12:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:42:19 --> Input Class Initialized
INFO - 2017-02-08 12:42:19 --> Language Class Initialized
INFO - 2017-02-08 12:42:19 --> Language Class Initialized
INFO - 2017-02-08 12:42:19 --> Config Class Initialized
INFO - 2017-02-08 12:42:19 --> Loader Class Initialized
INFO - 2017-02-08 12:42:19 --> Helper loaded: form_helper
INFO - 2017-02-08 12:42:19 --> Helper loaded: url_helper
INFO - 2017-02-08 12:42:19 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:42:19 --> Database Driver Class Initialized
INFO - 2017-02-08 12:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:42:19 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:42:19 --> Template Class Initialized
INFO - 2017-02-08 12:42:19 --> Controller Class Initialized
DEBUG - 2017-02-08 12:42:19 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 12:42:19 --> Model Class Initialized
INFO - 2017-02-08 12:42:35 --> Config Class Initialized
INFO - 2017-02-08 12:42:35 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:42:35 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:42:35 --> Utf8 Class Initialized
INFO - 2017-02-08 12:42:35 --> URI Class Initialized
INFO - 2017-02-08 12:42:35 --> Router Class Initialized
INFO - 2017-02-08 12:42:35 --> Output Class Initialized
INFO - 2017-02-08 12:42:35 --> Security Class Initialized
DEBUG - 2017-02-08 12:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:42:35 --> Input Class Initialized
INFO - 2017-02-08 12:42:35 --> Language Class Initialized
INFO - 2017-02-08 12:42:35 --> Language Class Initialized
INFO - 2017-02-08 12:42:35 --> Config Class Initialized
INFO - 2017-02-08 12:42:35 --> Loader Class Initialized
INFO - 2017-02-08 12:42:35 --> Helper loaded: form_helper
INFO - 2017-02-08 12:42:35 --> Helper loaded: url_helper
INFO - 2017-02-08 12:42:35 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:42:35 --> Database Driver Class Initialized
INFO - 2017-02-08 12:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:42:35 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:42:35 --> Template Class Initialized
INFO - 2017-02-08 12:42:35 --> Controller Class Initialized
DEBUG - 2017-02-08 12:42:35 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 12:42:35 --> Model Class Initialized
INFO - 2017-02-08 12:42:36 --> Config Class Initialized
INFO - 2017-02-08 12:42:36 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:42:36 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:42:36 --> Utf8 Class Initialized
INFO - 2017-02-08 12:42:36 --> URI Class Initialized
INFO - 2017-02-08 12:42:36 --> Router Class Initialized
INFO - 2017-02-08 12:42:36 --> Output Class Initialized
INFO - 2017-02-08 12:42:36 --> Security Class Initialized
DEBUG - 2017-02-08 12:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:42:36 --> Input Class Initialized
INFO - 2017-02-08 12:42:36 --> Language Class Initialized
INFO - 2017-02-08 12:42:36 --> Language Class Initialized
INFO - 2017-02-08 12:42:36 --> Config Class Initialized
INFO - 2017-02-08 12:42:36 --> Loader Class Initialized
INFO - 2017-02-08 12:42:36 --> Helper loaded: form_helper
INFO - 2017-02-08 12:42:36 --> Helper loaded: url_helper
INFO - 2017-02-08 12:42:36 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:42:36 --> Database Driver Class Initialized
INFO - 2017-02-08 12:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:42:36 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:42:36 --> Template Class Initialized
INFO - 2017-02-08 12:42:36 --> Controller Class Initialized
DEBUG - 2017-02-08 12:42:36 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 12:42:36 --> Model Class Initialized
INFO - 2017-02-08 12:42:37 --> Config Class Initialized
INFO - 2017-02-08 12:42:37 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:42:37 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:42:37 --> Utf8 Class Initialized
INFO - 2017-02-08 12:42:37 --> URI Class Initialized
INFO - 2017-02-08 12:42:37 --> Router Class Initialized
INFO - 2017-02-08 12:42:37 --> Output Class Initialized
INFO - 2017-02-08 12:42:37 --> Security Class Initialized
DEBUG - 2017-02-08 12:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:42:37 --> Input Class Initialized
INFO - 2017-02-08 12:42:37 --> Language Class Initialized
INFO - 2017-02-08 12:42:37 --> Language Class Initialized
INFO - 2017-02-08 12:42:37 --> Config Class Initialized
INFO - 2017-02-08 12:42:37 --> Loader Class Initialized
INFO - 2017-02-08 12:42:37 --> Helper loaded: form_helper
INFO - 2017-02-08 12:42:37 --> Helper loaded: url_helper
INFO - 2017-02-08 12:42:37 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:42:37 --> Database Driver Class Initialized
INFO - 2017-02-08 12:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:42:37 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:42:37 --> Template Class Initialized
INFO - 2017-02-08 12:42:37 --> Controller Class Initialized
DEBUG - 2017-02-08 12:42:37 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 12:42:37 --> Model Class Initialized
INFO - 2017-02-08 12:42:52 --> Config Class Initialized
INFO - 2017-02-08 12:42:52 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:42:52 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:42:52 --> Utf8 Class Initialized
INFO - 2017-02-08 12:42:52 --> URI Class Initialized
INFO - 2017-02-08 12:42:52 --> Router Class Initialized
INFO - 2017-02-08 12:42:52 --> Output Class Initialized
INFO - 2017-02-08 12:42:52 --> Security Class Initialized
DEBUG - 2017-02-08 12:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:42:52 --> Input Class Initialized
INFO - 2017-02-08 12:42:52 --> Language Class Initialized
INFO - 2017-02-08 12:42:52 --> Language Class Initialized
INFO - 2017-02-08 12:42:52 --> Config Class Initialized
INFO - 2017-02-08 12:42:52 --> Loader Class Initialized
INFO - 2017-02-08 12:42:52 --> Helper loaded: form_helper
INFO - 2017-02-08 12:42:52 --> Helper loaded: url_helper
INFO - 2017-02-08 12:42:52 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:42:52 --> Database Driver Class Initialized
INFO - 2017-02-08 12:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:42:52 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:42:52 --> Template Class Initialized
INFO - 2017-02-08 12:42:52 --> Controller Class Initialized
DEBUG - 2017-02-08 12:42:52 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 12:42:52 --> Model Class Initialized
INFO - 2017-02-08 12:42:53 --> Config Class Initialized
INFO - 2017-02-08 12:42:53 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:42:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:42:53 --> Utf8 Class Initialized
INFO - 2017-02-08 12:42:53 --> URI Class Initialized
INFO - 2017-02-08 12:42:53 --> Router Class Initialized
INFO - 2017-02-08 12:42:53 --> Output Class Initialized
INFO - 2017-02-08 12:42:53 --> Security Class Initialized
DEBUG - 2017-02-08 12:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:42:53 --> Input Class Initialized
INFO - 2017-02-08 12:42:53 --> Language Class Initialized
INFO - 2017-02-08 12:42:53 --> Language Class Initialized
INFO - 2017-02-08 12:42:53 --> Config Class Initialized
INFO - 2017-02-08 12:42:53 --> Loader Class Initialized
INFO - 2017-02-08 12:42:53 --> Helper loaded: form_helper
INFO - 2017-02-08 12:42:53 --> Helper loaded: url_helper
INFO - 2017-02-08 12:42:53 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:42:53 --> Database Driver Class Initialized
INFO - 2017-02-08 12:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:42:53 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:42:53 --> Template Class Initialized
INFO - 2017-02-08 12:42:53 --> Controller Class Initialized
DEBUG - 2017-02-08 12:42:53 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 12:42:53 --> Model Class Initialized
INFO - 2017-02-08 12:43:25 --> Config Class Initialized
INFO - 2017-02-08 12:43:25 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:43:25 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:43:25 --> Utf8 Class Initialized
INFO - 2017-02-08 12:43:25 --> URI Class Initialized
INFO - 2017-02-08 12:43:25 --> Router Class Initialized
INFO - 2017-02-08 12:43:25 --> Output Class Initialized
INFO - 2017-02-08 12:43:25 --> Security Class Initialized
DEBUG - 2017-02-08 12:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:43:25 --> Input Class Initialized
INFO - 2017-02-08 12:43:25 --> Language Class Initialized
INFO - 2017-02-08 12:43:25 --> Language Class Initialized
INFO - 2017-02-08 12:43:25 --> Config Class Initialized
INFO - 2017-02-08 12:43:25 --> Loader Class Initialized
INFO - 2017-02-08 12:43:25 --> Helper loaded: form_helper
INFO - 2017-02-08 12:43:25 --> Helper loaded: url_helper
INFO - 2017-02-08 12:43:25 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:43:25 --> Database Driver Class Initialized
INFO - 2017-02-08 12:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:43:25 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:43:25 --> Template Class Initialized
INFO - 2017-02-08 12:43:25 --> Controller Class Initialized
DEBUG - 2017-02-08 12:43:25 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 12:43:25 --> Model Class Initialized
INFO - 2017-02-08 12:43:25 --> Model Class Initialized
ERROR - 2017-02-08 12:43:25 --> Severity: Notice --> Undefined property: CI::$common_model C:\xampp\htdocs\mobile\application\third_party\MX\Controller.php 62
ERROR - 2017-02-08 12:43:25 --> Severity: Error --> Call to a member function isLoggedIn() on null C:\xampp\htdocs\mobile\application\modules\backend\controllers\Global_setting.php 18
INFO - 2017-02-08 12:43:38 --> Config Class Initialized
INFO - 2017-02-08 12:43:38 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:43:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:43:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:43:38 --> URI Class Initialized
INFO - 2017-02-08 12:43:38 --> Router Class Initialized
INFO - 2017-02-08 12:43:38 --> Output Class Initialized
INFO - 2017-02-08 12:43:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:43:38 --> Input Class Initialized
INFO - 2017-02-08 12:43:38 --> Language Class Initialized
INFO - 2017-02-08 12:43:38 --> Language Class Initialized
INFO - 2017-02-08 12:43:38 --> Config Class Initialized
INFO - 2017-02-08 12:43:38 --> Loader Class Initialized
INFO - 2017-02-08 12:43:38 --> Helper loaded: form_helper
INFO - 2017-02-08 12:43:38 --> Helper loaded: url_helper
INFO - 2017-02-08 12:43:38 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:43:38 --> Database Driver Class Initialized
INFO - 2017-02-08 12:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:43:38 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:43:38 --> Template Class Initialized
INFO - 2017-02-08 12:43:38 --> Controller Class Initialized
DEBUG - 2017-02-08 12:43:38 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 12:43:38 --> Model Class Initialized
INFO - 2017-02-08 12:43:38 --> Model Class Initialized
INFO - 2017-02-08 12:43:38 --> Model Class Initialized
INFO - 2017-02-08 12:43:38 --> Config Class Initialized
INFO - 2017-02-08 12:43:38 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:43:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:43:38 --> Utf8 Class Initialized
INFO - 2017-02-08 12:43:38 --> URI Class Initialized
INFO - 2017-02-08 12:43:38 --> Router Class Initialized
INFO - 2017-02-08 12:43:38 --> Output Class Initialized
INFO - 2017-02-08 12:43:38 --> Security Class Initialized
DEBUG - 2017-02-08 12:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:43:38 --> Input Class Initialized
INFO - 2017-02-08 12:43:38 --> Language Class Initialized
INFO - 2017-02-08 12:43:38 --> Language Class Initialized
INFO - 2017-02-08 12:43:38 --> Config Class Initialized
INFO - 2017-02-08 12:43:38 --> Loader Class Initialized
INFO - 2017-02-08 12:43:38 --> Helper loaded: form_helper
INFO - 2017-02-08 12:43:38 --> Helper loaded: url_helper
INFO - 2017-02-08 12:43:38 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:43:38 --> Database Driver Class Initialized
INFO - 2017-02-08 12:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:43:38 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:43:38 --> Template Class Initialized
INFO - 2017-02-08 12:43:38 --> Controller Class Initialized
DEBUG - 2017-02-08 12:43:38 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:43:38 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:43:38 --> Model Class Initialized
INFO - 2017-02-08 12:43:38 --> Model Class Initialized
DEBUG - 2017-02-08 12:43:38 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-08 12:43:38 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:43:38 --> Final output sent to browser
DEBUG - 2017-02-08 12:43:38 --> Total execution time: 0.0439
INFO - 2017-02-08 12:43:50 --> Config Class Initialized
INFO - 2017-02-08 12:43:50 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:43:50 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:43:50 --> Utf8 Class Initialized
INFO - 2017-02-08 12:43:50 --> URI Class Initialized
INFO - 2017-02-08 12:43:50 --> Router Class Initialized
INFO - 2017-02-08 12:43:50 --> Output Class Initialized
INFO - 2017-02-08 12:43:50 --> Security Class Initialized
DEBUG - 2017-02-08 12:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:43:50 --> Input Class Initialized
INFO - 2017-02-08 12:43:50 --> Language Class Initialized
INFO - 2017-02-08 12:43:50 --> Language Class Initialized
INFO - 2017-02-08 12:43:50 --> Config Class Initialized
INFO - 2017-02-08 12:43:50 --> Loader Class Initialized
INFO - 2017-02-08 12:43:50 --> Helper loaded: form_helper
INFO - 2017-02-08 12:43:50 --> Helper loaded: url_helper
INFO - 2017-02-08 12:43:50 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:43:50 --> Database Driver Class Initialized
INFO - 2017-02-08 12:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:43:50 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:43:50 --> Template Class Initialized
INFO - 2017-02-08 12:43:50 --> Controller Class Initialized
DEBUG - 2017-02-08 12:43:50 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:43:50 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:43:50 --> Model Class Initialized
INFO - 2017-02-08 12:43:50 --> Model Class Initialized
ERROR - 2017-02-08 12:43:50 --> Severity: Notice --> Undefined index: mobile C:\xampp\htdocs\mobile\application\modules\backend\controllers\Login.php 31
ERROR - 2017-02-08 12:43:50 --> Severity: Notice --> Undefined index: role_id C:\xampp\htdocs\mobile\application\modules\backend\controllers\Login.php 33
INFO - 2017-02-08 12:43:50 --> Config Class Initialized
INFO - 2017-02-08 12:43:50 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:43:50 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:43:50 --> Utf8 Class Initialized
INFO - 2017-02-08 12:43:50 --> URI Class Initialized
INFO - 2017-02-08 12:43:50 --> Router Class Initialized
INFO - 2017-02-08 12:43:50 --> Output Class Initialized
INFO - 2017-02-08 12:43:50 --> Security Class Initialized
DEBUG - 2017-02-08 12:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:43:50 --> Input Class Initialized
INFO - 2017-02-08 12:43:50 --> Language Class Initialized
INFO - 2017-02-08 12:43:50 --> Language Class Initialized
INFO - 2017-02-08 12:43:50 --> Config Class Initialized
INFO - 2017-02-08 12:43:50 --> Loader Class Initialized
INFO - 2017-02-08 12:43:50 --> Helper loaded: form_helper
INFO - 2017-02-08 12:43:50 --> Helper loaded: url_helper
INFO - 2017-02-08 12:43:50 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:43:50 --> Database Driver Class Initialized
INFO - 2017-02-08 12:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:43:50 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:43:50 --> Template Class Initialized
INFO - 2017-02-08 12:43:50 --> Controller Class Initialized
DEBUG - 2017-02-08 12:43:50 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:43:50 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:43:50 --> Model Class Initialized
INFO - 2017-02-08 12:43:50 --> Model Class Initialized
DEBUG - 2017-02-08 12:43:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 12:43:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:43:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:43:50 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:43:50 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:43:50 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:43:50 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:43:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:43:50 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:43:50 --> Final output sent to browser
DEBUG - 2017-02-08 12:43:50 --> Total execution time: 0.0522
INFO - 2017-02-08 12:43:50 --> Config Class Initialized
INFO - 2017-02-08 12:43:50 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:43:50 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:43:50 --> Utf8 Class Initialized
INFO - 2017-02-08 12:43:50 --> URI Class Initialized
INFO - 2017-02-08 12:43:50 --> Router Class Initialized
INFO - 2017-02-08 12:43:50 --> Output Class Initialized
INFO - 2017-02-08 12:43:50 --> Security Class Initialized
DEBUG - 2017-02-08 12:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:43:50 --> Input Class Initialized
INFO - 2017-02-08 12:43:50 --> Language Class Initialized
ERROR - 2017-02-08 12:43:50 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:43:50 --> Config Class Initialized
INFO - 2017-02-08 12:43:50 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:43:50 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:43:50 --> Utf8 Class Initialized
INFO - 2017-02-08 12:43:50 --> URI Class Initialized
INFO - 2017-02-08 12:43:50 --> Router Class Initialized
INFO - 2017-02-08 12:43:50 --> Output Class Initialized
INFO - 2017-02-08 12:43:50 --> Security Class Initialized
DEBUG - 2017-02-08 12:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:43:50 --> Input Class Initialized
INFO - 2017-02-08 12:43:50 --> Language Class Initialized
ERROR - 2017-02-08 12:43:50 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:44:01 --> Config Class Initialized
INFO - 2017-02-08 12:44:01 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:44:01 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:44:01 --> Utf8 Class Initialized
INFO - 2017-02-08 12:44:01 --> URI Class Initialized
INFO - 2017-02-08 12:44:01 --> Router Class Initialized
INFO - 2017-02-08 12:44:01 --> Output Class Initialized
INFO - 2017-02-08 12:44:01 --> Security Class Initialized
DEBUG - 2017-02-08 12:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:44:01 --> Input Class Initialized
INFO - 2017-02-08 12:44:01 --> Language Class Initialized
INFO - 2017-02-08 12:44:01 --> Language Class Initialized
INFO - 2017-02-08 12:44:01 --> Config Class Initialized
INFO - 2017-02-08 12:44:01 --> Loader Class Initialized
INFO - 2017-02-08 12:44:01 --> Helper loaded: form_helper
INFO - 2017-02-08 12:44:01 --> Helper loaded: url_helper
INFO - 2017-02-08 12:44:01 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:44:01 --> Database Driver Class Initialized
INFO - 2017-02-08 12:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:44:01 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:44:01 --> Template Class Initialized
INFO - 2017-02-08 12:44:01 --> Controller Class Initialized
DEBUG - 2017-02-08 12:44:01 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 12:44:01 --> Model Class Initialized
INFO - 2017-02-08 12:44:01 --> Model Class Initialized
INFO - 2017-02-08 12:44:01 --> Model Class Initialized
INFO - 2017-02-08 12:44:01 --> Config Class Initialized
INFO - 2017-02-08 12:44:01 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:44:01 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:44:01 --> Utf8 Class Initialized
INFO - 2017-02-08 12:44:01 --> URI Class Initialized
INFO - 2017-02-08 12:44:01 --> Router Class Initialized
INFO - 2017-02-08 12:44:01 --> Output Class Initialized
INFO - 2017-02-08 12:44:01 --> Security Class Initialized
DEBUG - 2017-02-08 12:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:44:01 --> Input Class Initialized
INFO - 2017-02-08 12:44:01 --> Language Class Initialized
INFO - 2017-02-08 12:44:01 --> Language Class Initialized
INFO - 2017-02-08 12:44:01 --> Config Class Initialized
INFO - 2017-02-08 12:44:01 --> Loader Class Initialized
INFO - 2017-02-08 12:44:01 --> Helper loaded: form_helper
INFO - 2017-02-08 12:44:01 --> Helper loaded: url_helper
INFO - 2017-02-08 12:44:01 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:44:01 --> Database Driver Class Initialized
INFO - 2017-02-08 12:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:44:01 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:44:01 --> Template Class Initialized
INFO - 2017-02-08 12:44:01 --> Controller Class Initialized
DEBUG - 2017-02-08 12:44:01 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:44:01 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:44:01 --> Model Class Initialized
INFO - 2017-02-08 12:44:01 --> Model Class Initialized
DEBUG - 2017-02-08 12:44:01 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-08 12:44:01 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:44:01 --> Final output sent to browser
DEBUG - 2017-02-08 12:44:01 --> Total execution time: 0.0391
INFO - 2017-02-08 12:44:27 --> Config Class Initialized
INFO - 2017-02-08 12:44:27 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:44:27 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:44:27 --> Utf8 Class Initialized
INFO - 2017-02-08 12:44:27 --> URI Class Initialized
INFO - 2017-02-08 12:44:27 --> Router Class Initialized
INFO - 2017-02-08 12:44:27 --> Output Class Initialized
INFO - 2017-02-08 12:44:27 --> Security Class Initialized
DEBUG - 2017-02-08 12:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:44:27 --> Input Class Initialized
INFO - 2017-02-08 12:44:27 --> Language Class Initialized
INFO - 2017-02-08 12:44:27 --> Language Class Initialized
INFO - 2017-02-08 12:44:27 --> Config Class Initialized
INFO - 2017-02-08 12:44:27 --> Loader Class Initialized
INFO - 2017-02-08 12:44:27 --> Helper loaded: form_helper
INFO - 2017-02-08 12:44:27 --> Helper loaded: url_helper
INFO - 2017-02-08 12:44:27 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:44:27 --> Database Driver Class Initialized
INFO - 2017-02-08 12:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:44:27 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:44:27 --> Template Class Initialized
INFO - 2017-02-08 12:44:27 --> Controller Class Initialized
DEBUG - 2017-02-08 12:44:27 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:44:27 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:44:27 --> Model Class Initialized
INFO - 2017-02-08 12:44:27 --> Model Class Initialized
DEBUG - 2017-02-08 12:44:27 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-08 12:44:27 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:44:27 --> Final output sent to browser
DEBUG - 2017-02-08 12:44:27 --> Total execution time: 0.0457
INFO - 2017-02-08 12:44:32 --> Config Class Initialized
INFO - 2017-02-08 12:44:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:44:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:44:32 --> Utf8 Class Initialized
INFO - 2017-02-08 12:44:32 --> URI Class Initialized
INFO - 2017-02-08 12:44:32 --> Router Class Initialized
INFO - 2017-02-08 12:44:32 --> Output Class Initialized
INFO - 2017-02-08 12:44:32 --> Security Class Initialized
DEBUG - 2017-02-08 12:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:44:32 --> Input Class Initialized
INFO - 2017-02-08 12:44:32 --> Language Class Initialized
INFO - 2017-02-08 12:44:32 --> Language Class Initialized
INFO - 2017-02-08 12:44:32 --> Config Class Initialized
INFO - 2017-02-08 12:44:32 --> Loader Class Initialized
INFO - 2017-02-08 12:44:32 --> Helper loaded: form_helper
INFO - 2017-02-08 12:44:32 --> Helper loaded: url_helper
INFO - 2017-02-08 12:44:32 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:44:32 --> Database Driver Class Initialized
INFO - 2017-02-08 12:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:44:32 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:44:32 --> Template Class Initialized
INFO - 2017-02-08 12:44:32 --> Controller Class Initialized
DEBUG - 2017-02-08 12:44:32 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:44:32 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:44:32 --> Model Class Initialized
INFO - 2017-02-08 12:44:32 --> Model Class Initialized
ERROR - 2017-02-08 12:44:32 --> Severity: Notice --> Undefined index: mobile C:\xampp\htdocs\mobile\application\modules\backend\controllers\Login.php 31
ERROR - 2017-02-08 12:44:32 --> Severity: Notice --> Undefined index: role_id C:\xampp\htdocs\mobile\application\modules\backend\controllers\Login.php 33
INFO - 2017-02-08 12:44:32 --> Config Class Initialized
INFO - 2017-02-08 12:44:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:44:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:44:32 --> Utf8 Class Initialized
INFO - 2017-02-08 12:44:32 --> URI Class Initialized
INFO - 2017-02-08 12:44:32 --> Router Class Initialized
INFO - 2017-02-08 12:44:32 --> Output Class Initialized
INFO - 2017-02-08 12:44:32 --> Security Class Initialized
DEBUG - 2017-02-08 12:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:44:32 --> Input Class Initialized
INFO - 2017-02-08 12:44:32 --> Language Class Initialized
INFO - 2017-02-08 12:44:32 --> Language Class Initialized
INFO - 2017-02-08 12:44:32 --> Config Class Initialized
INFO - 2017-02-08 12:44:32 --> Loader Class Initialized
INFO - 2017-02-08 12:44:32 --> Helper loaded: form_helper
INFO - 2017-02-08 12:44:32 --> Helper loaded: url_helper
INFO - 2017-02-08 12:44:32 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:44:32 --> Database Driver Class Initialized
INFO - 2017-02-08 12:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:44:32 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:44:32 --> Template Class Initialized
INFO - 2017-02-08 12:44:32 --> Controller Class Initialized
DEBUG - 2017-02-08 12:44:32 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:44:32 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:44:32 --> Model Class Initialized
INFO - 2017-02-08 12:44:32 --> Model Class Initialized
DEBUG - 2017-02-08 12:44:32 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 12:44:32 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:44:32 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:44:32 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:44:32 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:44:32 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:44:32 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:44:32 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:44:32 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:44:32 --> Final output sent to browser
DEBUG - 2017-02-08 12:44:32 --> Total execution time: 0.0458
INFO - 2017-02-08 12:44:32 --> Config Class Initialized
INFO - 2017-02-08 12:44:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:44:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:44:32 --> Utf8 Class Initialized
INFO - 2017-02-08 12:44:32 --> URI Class Initialized
INFO - 2017-02-08 12:44:32 --> Router Class Initialized
INFO - 2017-02-08 12:44:32 --> Output Class Initialized
INFO - 2017-02-08 12:44:32 --> Security Class Initialized
DEBUG - 2017-02-08 12:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:44:32 --> Input Class Initialized
INFO - 2017-02-08 12:44:32 --> Language Class Initialized
ERROR - 2017-02-08 12:44:32 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:44:32 --> Config Class Initialized
INFO - 2017-02-08 12:44:32 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:44:32 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:44:32 --> Utf8 Class Initialized
INFO - 2017-02-08 12:44:32 --> URI Class Initialized
INFO - 2017-02-08 12:44:32 --> Router Class Initialized
INFO - 2017-02-08 12:44:32 --> Output Class Initialized
INFO - 2017-02-08 12:44:32 --> Security Class Initialized
DEBUG - 2017-02-08 12:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:44:32 --> Input Class Initialized
INFO - 2017-02-08 12:44:32 --> Language Class Initialized
ERROR - 2017-02-08 12:44:32 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:44:34 --> Config Class Initialized
INFO - 2017-02-08 12:44:34 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:44:34 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:44:34 --> Utf8 Class Initialized
INFO - 2017-02-08 12:44:34 --> URI Class Initialized
INFO - 2017-02-08 12:44:34 --> Router Class Initialized
INFO - 2017-02-08 12:44:34 --> Output Class Initialized
INFO - 2017-02-08 12:44:34 --> Security Class Initialized
DEBUG - 2017-02-08 12:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:44:34 --> Input Class Initialized
INFO - 2017-02-08 12:44:34 --> Language Class Initialized
INFO - 2017-02-08 12:44:34 --> Language Class Initialized
INFO - 2017-02-08 12:44:34 --> Config Class Initialized
INFO - 2017-02-08 12:44:34 --> Loader Class Initialized
INFO - 2017-02-08 12:44:34 --> Helper loaded: form_helper
INFO - 2017-02-08 12:44:34 --> Helper loaded: url_helper
INFO - 2017-02-08 12:44:34 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:44:34 --> Database Driver Class Initialized
INFO - 2017-02-08 12:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:44:34 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:44:34 --> Template Class Initialized
INFO - 2017-02-08 12:44:34 --> Controller Class Initialized
DEBUG - 2017-02-08 12:44:34 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 12:44:34 --> Model Class Initialized
INFO - 2017-02-08 12:44:34 --> Model Class Initialized
INFO - 2017-02-08 12:44:34 --> Model Class Initialized
INFO - 2017-02-08 12:44:34 --> Config Class Initialized
INFO - 2017-02-08 12:44:34 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:44:34 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:44:34 --> Utf8 Class Initialized
INFO - 2017-02-08 12:44:34 --> URI Class Initialized
INFO - 2017-02-08 12:44:34 --> Router Class Initialized
INFO - 2017-02-08 12:44:34 --> Output Class Initialized
INFO - 2017-02-08 12:44:34 --> Security Class Initialized
DEBUG - 2017-02-08 12:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:44:34 --> Input Class Initialized
INFO - 2017-02-08 12:44:34 --> Language Class Initialized
ERROR - 2017-02-08 12:44:34 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-08 12:45:29 --> Config Class Initialized
INFO - 2017-02-08 12:45:29 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:45:29 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:45:29 --> Utf8 Class Initialized
INFO - 2017-02-08 12:45:29 --> URI Class Initialized
INFO - 2017-02-08 12:45:29 --> Router Class Initialized
INFO - 2017-02-08 12:45:29 --> Output Class Initialized
INFO - 2017-02-08 12:45:29 --> Security Class Initialized
DEBUG - 2017-02-08 12:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:45:29 --> Input Class Initialized
INFO - 2017-02-08 12:45:29 --> Language Class Initialized
INFO - 2017-02-08 12:45:29 --> Language Class Initialized
INFO - 2017-02-08 12:45:29 --> Config Class Initialized
INFO - 2017-02-08 12:45:29 --> Loader Class Initialized
INFO - 2017-02-08 12:45:29 --> Helper loaded: form_helper
INFO - 2017-02-08 12:45:29 --> Helper loaded: url_helper
INFO - 2017-02-08 12:45:29 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:45:29 --> Database Driver Class Initialized
INFO - 2017-02-08 12:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:45:29 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:45:29 --> Template Class Initialized
INFO - 2017-02-08 12:45:29 --> Controller Class Initialized
DEBUG - 2017-02-08 12:45:29 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:45:29 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:45:29 --> Model Class Initialized
INFO - 2017-02-08 12:45:29 --> Model Class Initialized
DEBUG - 2017-02-08 12:45:29 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-08 12:45:29 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:45:29 --> Final output sent to browser
DEBUG - 2017-02-08 12:45:29 --> Total execution time: 0.0511
INFO - 2017-02-08 12:45:33 --> Config Class Initialized
INFO - 2017-02-08 12:45:33 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:45:33 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:45:33 --> Utf8 Class Initialized
INFO - 2017-02-08 12:45:33 --> URI Class Initialized
INFO - 2017-02-08 12:45:33 --> Router Class Initialized
INFO - 2017-02-08 12:45:33 --> Output Class Initialized
INFO - 2017-02-08 12:45:33 --> Security Class Initialized
DEBUG - 2017-02-08 12:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:45:33 --> Input Class Initialized
INFO - 2017-02-08 12:45:33 --> Language Class Initialized
INFO - 2017-02-08 12:45:33 --> Language Class Initialized
INFO - 2017-02-08 12:45:33 --> Config Class Initialized
INFO - 2017-02-08 12:45:33 --> Loader Class Initialized
INFO - 2017-02-08 12:45:33 --> Helper loaded: form_helper
INFO - 2017-02-08 12:45:33 --> Helper loaded: url_helper
INFO - 2017-02-08 12:45:33 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:45:33 --> Database Driver Class Initialized
INFO - 2017-02-08 12:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:45:33 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:45:33 --> Template Class Initialized
INFO - 2017-02-08 12:45:33 --> Controller Class Initialized
DEBUG - 2017-02-08 12:45:33 --> Login MX_Controller Initialized
INFO - 2017-02-08 12:45:33 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:45:33 --> Model Class Initialized
INFO - 2017-02-08 12:45:33 --> Model Class Initialized
ERROR - 2017-02-08 12:45:33 --> Severity: Notice --> Undefined index: mobile C:\xampp\htdocs\mobile\application\modules\backend\controllers\Login.php 31
INFO - 2017-02-08 12:45:34 --> Config Class Initialized
INFO - 2017-02-08 12:45:34 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:45:34 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:45:34 --> Utf8 Class Initialized
INFO - 2017-02-08 12:45:34 --> URI Class Initialized
INFO - 2017-02-08 12:45:34 --> Router Class Initialized
INFO - 2017-02-08 12:45:34 --> Output Class Initialized
INFO - 2017-02-08 12:45:34 --> Security Class Initialized
DEBUG - 2017-02-08 12:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:45:34 --> Input Class Initialized
INFO - 2017-02-08 12:45:34 --> Language Class Initialized
INFO - 2017-02-08 12:45:34 --> Language Class Initialized
INFO - 2017-02-08 12:45:34 --> Config Class Initialized
INFO - 2017-02-08 12:45:34 --> Loader Class Initialized
INFO - 2017-02-08 12:45:34 --> Helper loaded: form_helper
INFO - 2017-02-08 12:45:34 --> Helper loaded: url_helper
INFO - 2017-02-08 12:45:34 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:45:34 --> Database Driver Class Initialized
INFO - 2017-02-08 12:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:45:34 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:45:34 --> Template Class Initialized
INFO - 2017-02-08 12:45:34 --> Controller Class Initialized
DEBUG - 2017-02-08 12:45:34 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 12:45:34 --> Helper loaded: cookie_helper
INFO - 2017-02-08 12:45:34 --> Model Class Initialized
INFO - 2017-02-08 12:45:34 --> Model Class Initialized
DEBUG - 2017-02-08 12:45:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 12:45:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 12:45:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 12:45:34 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 12:45:34 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 12:45:34 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 12:45:34 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 12:45:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 12:45:34 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 12:45:34 --> Final output sent to browser
DEBUG - 2017-02-08 12:45:34 --> Total execution time: 0.0461
INFO - 2017-02-08 12:45:34 --> Config Class Initialized
INFO - 2017-02-08 12:45:34 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:45:34 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:45:34 --> Utf8 Class Initialized
INFO - 2017-02-08 12:45:34 --> URI Class Initialized
INFO - 2017-02-08 12:45:34 --> Router Class Initialized
INFO - 2017-02-08 12:45:34 --> Output Class Initialized
INFO - 2017-02-08 12:45:34 --> Security Class Initialized
DEBUG - 2017-02-08 12:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:45:34 --> Input Class Initialized
INFO - 2017-02-08 12:45:34 --> Language Class Initialized
ERROR - 2017-02-08 12:45:34 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:45:34 --> Config Class Initialized
INFO - 2017-02-08 12:45:34 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:45:34 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:45:34 --> Utf8 Class Initialized
INFO - 2017-02-08 12:45:34 --> URI Class Initialized
INFO - 2017-02-08 12:45:34 --> Router Class Initialized
INFO - 2017-02-08 12:45:34 --> Output Class Initialized
INFO - 2017-02-08 12:45:34 --> Security Class Initialized
DEBUG - 2017-02-08 12:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:45:34 --> Input Class Initialized
INFO - 2017-02-08 12:45:34 --> Language Class Initialized
ERROR - 2017-02-08 12:45:34 --> 404 Page Not Found: /index
INFO - 2017-02-08 12:45:36 --> Config Class Initialized
INFO - 2017-02-08 12:45:36 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:45:36 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:45:36 --> Utf8 Class Initialized
INFO - 2017-02-08 12:45:36 --> URI Class Initialized
INFO - 2017-02-08 12:45:36 --> Router Class Initialized
INFO - 2017-02-08 12:45:36 --> Output Class Initialized
INFO - 2017-02-08 12:45:36 --> Security Class Initialized
DEBUG - 2017-02-08 12:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:45:36 --> Input Class Initialized
INFO - 2017-02-08 12:45:36 --> Language Class Initialized
INFO - 2017-02-08 12:45:36 --> Language Class Initialized
INFO - 2017-02-08 12:45:36 --> Config Class Initialized
INFO - 2017-02-08 12:45:36 --> Loader Class Initialized
INFO - 2017-02-08 12:45:36 --> Helper loaded: form_helper
INFO - 2017-02-08 12:45:36 --> Helper loaded: url_helper
INFO - 2017-02-08 12:45:36 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:45:36 --> Database Driver Class Initialized
INFO - 2017-02-08 12:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:45:36 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:45:36 --> Template Class Initialized
INFO - 2017-02-08 12:45:36 --> Controller Class Initialized
DEBUG - 2017-02-08 12:45:36 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 12:45:36 --> Model Class Initialized
INFO - 2017-02-08 12:45:36 --> Model Class Initialized
INFO - 2017-02-08 12:45:36 --> Model Class Initialized
ERROR - 2017-02-08 12:45:36 --> Query error: Unknown column 'user_type' in 'where clause' - Invalid query: SELECT *
FROM `tbl_users`
WHERE `user_type` = '1'
AND `user_status` = '1'
INFO - 2017-02-08 12:45:36 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-08 12:45:36 --> Config Class Initialized
INFO - 2017-02-08 12:45:36 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:45:36 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:45:36 --> Utf8 Class Initialized
INFO - 2017-02-08 12:45:36 --> URI Class Initialized
INFO - 2017-02-08 12:45:36 --> Router Class Initialized
INFO - 2017-02-08 12:45:36 --> Output Class Initialized
INFO - 2017-02-08 12:45:36 --> Security Class Initialized
DEBUG - 2017-02-08 12:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:45:36 --> Input Class Initialized
INFO - 2017-02-08 12:45:36 --> Language Class Initialized
INFO - 2017-02-08 12:45:36 --> Language Class Initialized
INFO - 2017-02-08 12:45:36 --> Config Class Initialized
INFO - 2017-02-08 12:45:36 --> Loader Class Initialized
INFO - 2017-02-08 12:45:36 --> Helper loaded: form_helper
INFO - 2017-02-08 12:45:36 --> Helper loaded: url_helper
INFO - 2017-02-08 12:45:36 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:45:36 --> Database Driver Class Initialized
INFO - 2017-02-08 12:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:45:36 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:45:36 --> Template Class Initialized
INFO - 2017-02-08 12:45:36 --> Controller Class Initialized
DEBUG - 2017-02-08 12:45:36 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 12:45:36 --> Model Class Initialized
INFO - 2017-02-08 12:45:36 --> Model Class Initialized
INFO - 2017-02-08 12:45:36 --> Model Class Initialized
ERROR - 2017-02-08 12:45:36 --> Query error: Unknown column 'user_type' in 'where clause' - Invalid query: SELECT *
FROM `tbl_users`
WHERE `user_type` = '1'
AND `user_status` = '1'
INFO - 2017-02-08 12:45:36 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-08 12:46:03 --> Config Class Initialized
INFO - 2017-02-08 12:46:03 --> Hooks Class Initialized
DEBUG - 2017-02-08 12:46:03 --> UTF-8 Support Enabled
INFO - 2017-02-08 12:46:03 --> Utf8 Class Initialized
INFO - 2017-02-08 12:46:03 --> URI Class Initialized
INFO - 2017-02-08 12:46:03 --> Router Class Initialized
INFO - 2017-02-08 12:46:03 --> Output Class Initialized
INFO - 2017-02-08 12:46:03 --> Security Class Initialized
DEBUG - 2017-02-08 12:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 12:46:03 --> Input Class Initialized
INFO - 2017-02-08 12:46:03 --> Language Class Initialized
INFO - 2017-02-08 12:46:03 --> Language Class Initialized
INFO - 2017-02-08 12:46:03 --> Config Class Initialized
INFO - 2017-02-08 12:46:03 --> Loader Class Initialized
INFO - 2017-02-08 12:46:03 --> Helper loaded: form_helper
INFO - 2017-02-08 12:46:03 --> Helper loaded: url_helper
INFO - 2017-02-08 12:46:03 --> Helper loaded: utility_helper
INFO - 2017-02-08 12:46:03 --> Database Driver Class Initialized
INFO - 2017-02-08 12:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 12:46:03 --> User Agent Class Initialized
DEBUG - 2017-02-08 12:46:03 --> Template Class Initialized
INFO - 2017-02-08 12:46:03 --> Controller Class Initialized
DEBUG - 2017-02-08 12:46:03 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 12:46:03 --> Model Class Initialized
INFO - 2017-02-08 12:46:03 --> Model Class Initialized
INFO - 2017-02-08 12:46:03 --> Model Class Initialized
ERROR - 2017-02-08 12:46:03 --> Query error: Table 'mobile.mst_global_settings' doesn't exist - Invalid query: SELECT `mst_global`.`global_name_id` as `global_id`, `mst_global`.`name`, `trans_global`.*
FROM `mst_global_settings` as `mst_global`
LEFT JOIN `trans_global_settings` as `trans_global` ON `mst_global`.`global_name_id` = `trans_global`.`global_name_id`
INFO - 2017-02-08 12:46:03 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-08 15:12:13 --> Config Class Initialized
INFO - 2017-02-08 15:12:13 --> Hooks Class Initialized
DEBUG - 2017-02-08 15:12:15 --> UTF-8 Support Enabled
INFO - 2017-02-08 15:12:15 --> Utf8 Class Initialized
INFO - 2017-02-08 15:12:15 --> URI Class Initialized
INFO - 2017-02-08 15:12:17 --> Router Class Initialized
INFO - 2017-02-08 15:12:17 --> Output Class Initialized
INFO - 2017-02-08 15:12:18 --> Security Class Initialized
DEBUG - 2017-02-08 15:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 15:12:18 --> Input Class Initialized
INFO - 2017-02-08 15:12:18 --> Language Class Initialized
ERROR - 2017-02-08 15:12:19 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-08 15:12:53 --> Config Class Initialized
INFO - 2017-02-08 15:12:53 --> Hooks Class Initialized
DEBUG - 2017-02-08 15:12:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 15:12:53 --> Utf8 Class Initialized
INFO - 2017-02-08 15:12:53 --> URI Class Initialized
INFO - 2017-02-08 15:12:53 --> Router Class Initialized
INFO - 2017-02-08 15:12:53 --> Output Class Initialized
INFO - 2017-02-08 15:12:53 --> Security Class Initialized
DEBUG - 2017-02-08 15:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 15:12:53 --> Input Class Initialized
INFO - 2017-02-08 15:12:53 --> Language Class Initialized
INFO - 2017-02-08 15:12:53 --> Language Class Initialized
INFO - 2017-02-08 15:12:53 --> Config Class Initialized
INFO - 2017-02-08 15:12:53 --> Loader Class Initialized
INFO - 2017-02-08 15:12:54 --> Helper loaded: form_helper
INFO - 2017-02-08 15:12:54 --> Helper loaded: url_helper
INFO - 2017-02-08 15:12:54 --> Helper loaded: utility_helper
INFO - 2017-02-08 15:12:55 --> Database Driver Class Initialized
INFO - 2017-02-08 15:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 15:12:59 --> User Agent Class Initialized
DEBUG - 2017-02-08 15:12:59 --> Template Class Initialized
INFO - 2017-02-08 15:12:59 --> Controller Class Initialized
DEBUG - 2017-02-08 15:12:59 --> Login MX_Controller Initialized
INFO - 2017-02-08 15:12:59 --> Helper loaded: cookie_helper
INFO - 2017-02-08 15:12:59 --> Model Class Initialized
INFO - 2017-02-08 15:12:59 --> Model Class Initialized
DEBUG - 2017-02-08 15:13:00 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-08 15:13:00 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 15:13:00 --> Final output sent to browser
DEBUG - 2017-02-08 15:13:00 --> Total execution time: 7.0566
INFO - 2017-02-08 16:03:56 --> Config Class Initialized
INFO - 2017-02-08 16:03:56 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:03:56 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:03:56 --> Utf8 Class Initialized
INFO - 2017-02-08 16:03:56 --> URI Class Initialized
INFO - 2017-02-08 16:03:56 --> Router Class Initialized
INFO - 2017-02-08 16:03:56 --> Output Class Initialized
INFO - 2017-02-08 16:03:56 --> Security Class Initialized
DEBUG - 2017-02-08 16:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:03:56 --> Input Class Initialized
INFO - 2017-02-08 16:03:56 --> Language Class Initialized
INFO - 2017-02-08 16:03:56 --> Language Class Initialized
INFO - 2017-02-08 16:03:56 --> Config Class Initialized
INFO - 2017-02-08 16:03:56 --> Loader Class Initialized
INFO - 2017-02-08 16:03:56 --> Helper loaded: form_helper
INFO - 2017-02-08 16:03:56 --> Helper loaded: url_helper
INFO - 2017-02-08 16:03:56 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:03:56 --> Database Driver Class Initialized
INFO - 2017-02-08 16:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:03:57 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:03:57 --> Template Class Initialized
INFO - 2017-02-08 16:03:57 --> Controller Class Initialized
DEBUG - 2017-02-08 16:03:57 --> Login MX_Controller Initialized
INFO - 2017-02-08 16:03:57 --> Helper loaded: cookie_helper
INFO - 2017-02-08 16:03:57 --> Model Class Initialized
INFO - 2017-02-08 16:03:57 --> Model Class Initialized
ERROR - 2017-02-08 16:03:57 --> Severity: Notice --> Undefined index: mobile C:\xampp\htdocs\mobile\application\modules\backend\controllers\Login.php 31
INFO - 2017-02-08 16:03:57 --> Config Class Initialized
INFO - 2017-02-08 16:03:57 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:03:57 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:03:57 --> Utf8 Class Initialized
INFO - 2017-02-08 16:03:57 --> URI Class Initialized
INFO - 2017-02-08 16:03:57 --> Router Class Initialized
INFO - 2017-02-08 16:03:57 --> Output Class Initialized
INFO - 2017-02-08 16:03:57 --> Security Class Initialized
DEBUG - 2017-02-08 16:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:03:57 --> Input Class Initialized
INFO - 2017-02-08 16:03:57 --> Language Class Initialized
INFO - 2017-02-08 16:03:57 --> Language Class Initialized
INFO - 2017-02-08 16:03:57 --> Config Class Initialized
INFO - 2017-02-08 16:03:57 --> Loader Class Initialized
INFO - 2017-02-08 16:03:57 --> Helper loaded: form_helper
INFO - 2017-02-08 16:03:57 --> Helper loaded: url_helper
INFO - 2017-02-08 16:03:57 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:03:57 --> Database Driver Class Initialized
INFO - 2017-02-08 16:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:03:57 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:03:57 --> Template Class Initialized
INFO - 2017-02-08 16:03:57 --> Controller Class Initialized
DEBUG - 2017-02-08 16:03:57 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 16:03:57 --> Helper loaded: cookie_helper
INFO - 2017-02-08 16:03:57 --> Model Class Initialized
INFO - 2017-02-08 16:03:57 --> Model Class Initialized
DEBUG - 2017-02-08 16:03:58 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 16:03:58 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 16:03:58 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 16:03:58 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 16:03:58 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 16:03:58 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 16:03:58 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 16:03:58 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 16:03:58 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 16:03:58 --> Final output sent to browser
DEBUG - 2017-02-08 16:03:58 --> Total execution time: 0.4358
INFO - 2017-02-08 16:03:58 --> Config Class Initialized
INFO - 2017-02-08 16:03:58 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:03:58 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:03:58 --> Utf8 Class Initialized
INFO - 2017-02-08 16:03:58 --> URI Class Initialized
INFO - 2017-02-08 16:03:58 --> Router Class Initialized
INFO - 2017-02-08 16:03:58 --> Output Class Initialized
INFO - 2017-02-08 16:03:58 --> Security Class Initialized
DEBUG - 2017-02-08 16:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:03:58 --> Input Class Initialized
INFO - 2017-02-08 16:03:58 --> Language Class Initialized
ERROR - 2017-02-08 16:03:58 --> 404 Page Not Found: /index
INFO - 2017-02-08 16:03:59 --> Config Class Initialized
INFO - 2017-02-08 16:03:59 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:03:59 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:03:59 --> Utf8 Class Initialized
INFO - 2017-02-08 16:03:59 --> URI Class Initialized
INFO - 2017-02-08 16:03:59 --> Router Class Initialized
INFO - 2017-02-08 16:03:59 --> Output Class Initialized
INFO - 2017-02-08 16:03:59 --> Security Class Initialized
DEBUG - 2017-02-08 16:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:03:59 --> Input Class Initialized
INFO - 2017-02-08 16:03:59 --> Language Class Initialized
ERROR - 2017-02-08 16:03:59 --> 404 Page Not Found: /index
INFO - 2017-02-08 16:04:05 --> Config Class Initialized
INFO - 2017-02-08 16:04:05 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:04:05 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:04:05 --> Utf8 Class Initialized
INFO - 2017-02-08 16:04:05 --> URI Class Initialized
INFO - 2017-02-08 16:04:05 --> Router Class Initialized
INFO - 2017-02-08 16:04:05 --> Output Class Initialized
INFO - 2017-02-08 16:04:05 --> Security Class Initialized
DEBUG - 2017-02-08 16:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:04:05 --> Input Class Initialized
INFO - 2017-02-08 16:04:05 --> Language Class Initialized
ERROR - 2017-02-08 16:04:05 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-08 16:04:07 --> Config Class Initialized
INFO - 2017-02-08 16:04:07 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:04:07 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:04:07 --> Utf8 Class Initialized
INFO - 2017-02-08 16:04:07 --> URI Class Initialized
INFO - 2017-02-08 16:04:07 --> Router Class Initialized
INFO - 2017-02-08 16:04:07 --> Output Class Initialized
INFO - 2017-02-08 16:04:07 --> Security Class Initialized
DEBUG - 2017-02-08 16:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:04:07 --> Input Class Initialized
INFO - 2017-02-08 16:04:07 --> Language Class Initialized
INFO - 2017-02-08 16:04:07 --> Language Class Initialized
INFO - 2017-02-08 16:04:07 --> Config Class Initialized
INFO - 2017-02-08 16:04:07 --> Loader Class Initialized
INFO - 2017-02-08 16:04:07 --> Helper loaded: form_helper
INFO - 2017-02-08 16:04:07 --> Helper loaded: url_helper
INFO - 2017-02-08 16:04:07 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:04:07 --> Database Driver Class Initialized
INFO - 2017-02-08 16:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:04:07 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:04:07 --> Template Class Initialized
INFO - 2017-02-08 16:04:07 --> Controller Class Initialized
DEBUG - 2017-02-08 16:04:07 --> Dashboard MX_Controller Initialized
INFO - 2017-02-08 16:04:07 --> Helper loaded: cookie_helper
INFO - 2017-02-08 16:04:07 --> Model Class Initialized
INFO - 2017-02-08 16:04:07 --> Model Class Initialized
DEBUG - 2017-02-08 16:04:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 16:04:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 16:04:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 16:04:07 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-08 16:04:07 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-08 16:04:07 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-08 16:04:07 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-08 16:04:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-08 16:04:07 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 16:04:07 --> Final output sent to browser
DEBUG - 2017-02-08 16:04:07 --> Total execution time: 0.4473
INFO - 2017-02-08 16:04:25 --> Config Class Initialized
INFO - 2017-02-08 16:04:25 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:04:25 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:04:25 --> Utf8 Class Initialized
INFO - 2017-02-08 16:04:25 --> URI Class Initialized
INFO - 2017-02-08 16:04:25 --> Router Class Initialized
INFO - 2017-02-08 16:04:25 --> Output Class Initialized
INFO - 2017-02-08 16:04:25 --> Security Class Initialized
DEBUG - 2017-02-08 16:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:04:25 --> Input Class Initialized
INFO - 2017-02-08 16:04:25 --> Language Class Initialized
INFO - 2017-02-08 16:04:25 --> Language Class Initialized
INFO - 2017-02-08 16:04:25 --> Config Class Initialized
INFO - 2017-02-08 16:04:25 --> Loader Class Initialized
INFO - 2017-02-08 16:04:25 --> Helper loaded: form_helper
INFO - 2017-02-08 16:04:25 --> Helper loaded: url_helper
INFO - 2017-02-08 16:04:25 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:04:25 --> Database Driver Class Initialized
INFO - 2017-02-08 16:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:04:25 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:04:25 --> Template Class Initialized
INFO - 2017-02-08 16:04:25 --> Controller Class Initialized
DEBUG - 2017-02-08 16:04:25 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:04:25 --> Model Class Initialized
INFO - 2017-02-08 16:04:26 --> Model Class Initialized
INFO - 2017-02-08 16:04:26 --> Model Class Initialized
ERROR - 2017-02-08 16:04:26 --> Query error: Table 'mobile.mst_global_settings' doesn't exist - Invalid query: SELECT `mst_global`.`global_name_id` as `global_id`, `mst_global`.`name`, `trans_global`.*
FROM `mst_global_settings` as `mst_global`
LEFT JOIN `trans_global_settings` as `trans_global` ON `mst_global`.`global_name_id` = `trans_global`.`global_name_id`
INFO - 2017-02-08 16:04:26 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-08 16:05:57 --> Config Class Initialized
INFO - 2017-02-08 16:05:57 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:05:57 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:05:57 --> Utf8 Class Initialized
INFO - 2017-02-08 16:05:57 --> URI Class Initialized
INFO - 2017-02-08 16:05:57 --> Router Class Initialized
INFO - 2017-02-08 16:05:57 --> Output Class Initialized
INFO - 2017-02-08 16:05:57 --> Security Class Initialized
DEBUG - 2017-02-08 16:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:05:57 --> Input Class Initialized
INFO - 2017-02-08 16:05:57 --> Language Class Initialized
INFO - 2017-02-08 16:05:57 --> Language Class Initialized
INFO - 2017-02-08 16:05:57 --> Config Class Initialized
INFO - 2017-02-08 16:05:57 --> Loader Class Initialized
INFO - 2017-02-08 16:05:57 --> Helper loaded: form_helper
INFO - 2017-02-08 16:05:57 --> Helper loaded: url_helper
INFO - 2017-02-08 16:05:57 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:05:57 --> Database Driver Class Initialized
INFO - 2017-02-08 16:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:05:57 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:05:57 --> Template Class Initialized
INFO - 2017-02-08 16:05:57 --> Controller Class Initialized
DEBUG - 2017-02-08 16:05:57 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:05:57 --> Model Class Initialized
INFO - 2017-02-08 16:05:57 --> Model Class Initialized
INFO - 2017-02-08 16:05:57 --> Model Class Initialized
ERROR - 2017-02-08 16:05:57 --> Query error: Table 'mobile.mst_global_settings' doesn't exist - Invalid query: SELECT `mst_global`.`global_name_id` as `global_id`, `mst_global`.`name`, `trans_global`.*
FROM `mst_global_settings` as `mst_global`
LEFT JOIN `trans_global_settings` as `trans_global` ON `mst_global`.`global_name_id` = `trans_global`.`global_name_id`
INFO - 2017-02-08 16:05:57 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-08 16:05:57 --> Config Class Initialized
INFO - 2017-02-08 16:05:57 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:05:57 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:05:57 --> Utf8 Class Initialized
INFO - 2017-02-08 16:05:57 --> URI Class Initialized
INFO - 2017-02-08 16:05:57 --> Router Class Initialized
INFO - 2017-02-08 16:05:57 --> Output Class Initialized
INFO - 2017-02-08 16:05:57 --> Security Class Initialized
DEBUG - 2017-02-08 16:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:05:57 --> Input Class Initialized
INFO - 2017-02-08 16:05:57 --> Language Class Initialized
INFO - 2017-02-08 16:05:57 --> Language Class Initialized
INFO - 2017-02-08 16:05:57 --> Config Class Initialized
INFO - 2017-02-08 16:05:57 --> Loader Class Initialized
INFO - 2017-02-08 16:05:58 --> Helper loaded: form_helper
INFO - 2017-02-08 16:05:58 --> Helper loaded: url_helper
INFO - 2017-02-08 16:05:58 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:05:58 --> Database Driver Class Initialized
INFO - 2017-02-08 16:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:05:58 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:05:58 --> Template Class Initialized
INFO - 2017-02-08 16:05:58 --> Controller Class Initialized
DEBUG - 2017-02-08 16:05:58 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:05:58 --> Model Class Initialized
INFO - 2017-02-08 16:05:58 --> Model Class Initialized
INFO - 2017-02-08 16:05:58 --> Model Class Initialized
ERROR - 2017-02-08 16:05:58 --> Query error: Table 'mobile.mst_global_settings' doesn't exist - Invalid query: SELECT `mst_global`.`global_name_id` as `global_id`, `mst_global`.`name`, `trans_global`.*
FROM `mst_global_settings` as `mst_global`
LEFT JOIN `trans_global_settings` as `trans_global` ON `mst_global`.`global_name_id` = `trans_global`.`global_name_id`
INFO - 2017-02-08 16:05:58 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-08 16:06:00 --> Config Class Initialized
INFO - 2017-02-08 16:06:00 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:06:00 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:06:00 --> Utf8 Class Initialized
INFO - 2017-02-08 16:06:00 --> URI Class Initialized
INFO - 2017-02-08 16:06:00 --> Router Class Initialized
INFO - 2017-02-08 16:06:00 --> Output Class Initialized
INFO - 2017-02-08 16:06:00 --> Security Class Initialized
DEBUG - 2017-02-08 16:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:06:00 --> Input Class Initialized
INFO - 2017-02-08 16:06:00 --> Language Class Initialized
INFO - 2017-02-08 16:06:00 --> Language Class Initialized
INFO - 2017-02-08 16:06:00 --> Config Class Initialized
INFO - 2017-02-08 16:06:00 --> Loader Class Initialized
INFO - 2017-02-08 16:06:00 --> Helper loaded: form_helper
INFO - 2017-02-08 16:06:00 --> Helper loaded: url_helper
INFO - 2017-02-08 16:06:00 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:06:00 --> Database Driver Class Initialized
INFO - 2017-02-08 16:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:06:00 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:06:00 --> Template Class Initialized
INFO - 2017-02-08 16:06:00 --> Controller Class Initialized
DEBUG - 2017-02-08 16:06:00 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:06:00 --> Model Class Initialized
INFO - 2017-02-08 16:06:00 --> Model Class Initialized
INFO - 2017-02-08 16:06:00 --> Model Class Initialized
ERROR - 2017-02-08 16:06:00 --> Query error: Table 'mobile.mst_global_settings' doesn't exist - Invalid query: SELECT `mst_global`.`global_name_id` as `global_id`, `mst_global`.`name`, `trans_global`.*
FROM `mst_global_settings` as `mst_global`
LEFT JOIN `trans_global_settings` as `trans_global` ON `mst_global`.`global_name_id` = `trans_global`.`global_name_id`
INFO - 2017-02-08 16:06:00 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-08 16:06:01 --> Config Class Initialized
INFO - 2017-02-08 16:06:01 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:06:01 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:06:01 --> Utf8 Class Initialized
INFO - 2017-02-08 16:06:01 --> URI Class Initialized
INFO - 2017-02-08 16:06:01 --> Router Class Initialized
INFO - 2017-02-08 16:06:01 --> Output Class Initialized
INFO - 2017-02-08 16:06:01 --> Security Class Initialized
DEBUG - 2017-02-08 16:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:06:01 --> Input Class Initialized
INFO - 2017-02-08 16:06:01 --> Language Class Initialized
INFO - 2017-02-08 16:06:01 --> Language Class Initialized
INFO - 2017-02-08 16:06:01 --> Config Class Initialized
INFO - 2017-02-08 16:06:01 --> Loader Class Initialized
INFO - 2017-02-08 16:06:01 --> Helper loaded: form_helper
INFO - 2017-02-08 16:06:01 --> Helper loaded: url_helper
INFO - 2017-02-08 16:06:01 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:06:01 --> Database Driver Class Initialized
INFO - 2017-02-08 16:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:06:01 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:06:01 --> Template Class Initialized
INFO - 2017-02-08 16:06:01 --> Controller Class Initialized
DEBUG - 2017-02-08 16:06:01 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:06:01 --> Model Class Initialized
INFO - 2017-02-08 16:06:01 --> Model Class Initialized
INFO - 2017-02-08 16:06:01 --> Model Class Initialized
ERROR - 2017-02-08 16:06:01 --> Query error: Table 'mobile.mst_global_settings' doesn't exist - Invalid query: SELECT `mst_global`.`global_name_id` as `global_id`, `mst_global`.`name`, `trans_global`.*
FROM `mst_global_settings` as `mst_global`
LEFT JOIN `trans_global_settings` as `trans_global` ON `mst_global`.`global_name_id` = `trans_global`.`global_name_id`
INFO - 2017-02-08 16:06:01 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-08 16:06:02 --> Config Class Initialized
INFO - 2017-02-08 16:06:02 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:06:02 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:06:02 --> Utf8 Class Initialized
INFO - 2017-02-08 16:06:02 --> URI Class Initialized
INFO - 2017-02-08 16:06:02 --> Router Class Initialized
INFO - 2017-02-08 16:06:02 --> Output Class Initialized
INFO - 2017-02-08 16:06:02 --> Security Class Initialized
DEBUG - 2017-02-08 16:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:06:02 --> Input Class Initialized
INFO - 2017-02-08 16:06:02 --> Language Class Initialized
INFO - 2017-02-08 16:06:02 --> Language Class Initialized
INFO - 2017-02-08 16:06:02 --> Config Class Initialized
INFO - 2017-02-08 16:06:02 --> Loader Class Initialized
INFO - 2017-02-08 16:06:02 --> Helper loaded: form_helper
INFO - 2017-02-08 16:06:02 --> Helper loaded: url_helper
INFO - 2017-02-08 16:06:02 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:06:02 --> Database Driver Class Initialized
INFO - 2017-02-08 16:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:06:02 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:06:02 --> Template Class Initialized
INFO - 2017-02-08 16:06:02 --> Controller Class Initialized
DEBUG - 2017-02-08 16:06:02 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:06:02 --> Model Class Initialized
INFO - 2017-02-08 16:06:02 --> Model Class Initialized
INFO - 2017-02-08 16:06:02 --> Model Class Initialized
ERROR - 2017-02-08 16:06:02 --> Query error: Table 'mobile.mst_global_settings' doesn't exist - Invalid query: SELECT `mst_global`.`global_name_id` as `global_id`, `mst_global`.`name`, `trans_global`.*
FROM `mst_global_settings` as `mst_global`
LEFT JOIN `trans_global_settings` as `trans_global` ON `mst_global`.`global_name_id` = `trans_global`.`global_name_id`
INFO - 2017-02-08 16:06:02 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-08 16:06:02 --> Config Class Initialized
INFO - 2017-02-08 16:06:02 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:06:02 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:06:02 --> Utf8 Class Initialized
INFO - 2017-02-08 16:06:02 --> URI Class Initialized
INFO - 2017-02-08 16:06:02 --> Router Class Initialized
INFO - 2017-02-08 16:06:02 --> Output Class Initialized
INFO - 2017-02-08 16:06:02 --> Security Class Initialized
DEBUG - 2017-02-08 16:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:06:02 --> Input Class Initialized
INFO - 2017-02-08 16:06:02 --> Language Class Initialized
INFO - 2017-02-08 16:06:02 --> Language Class Initialized
INFO - 2017-02-08 16:06:02 --> Config Class Initialized
INFO - 2017-02-08 16:06:02 --> Loader Class Initialized
INFO - 2017-02-08 16:06:02 --> Helper loaded: form_helper
INFO - 2017-02-08 16:06:02 --> Helper loaded: url_helper
INFO - 2017-02-08 16:06:02 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:06:02 --> Database Driver Class Initialized
INFO - 2017-02-08 16:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:06:02 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:06:02 --> Template Class Initialized
INFO - 2017-02-08 16:06:02 --> Controller Class Initialized
DEBUG - 2017-02-08 16:06:02 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:06:02 --> Model Class Initialized
INFO - 2017-02-08 16:06:02 --> Model Class Initialized
INFO - 2017-02-08 16:06:02 --> Model Class Initialized
ERROR - 2017-02-08 16:06:02 --> Query error: Table 'mobile.mst_global_settings' doesn't exist - Invalid query: SELECT `mst_global`.`global_name_id` as `global_id`, `mst_global`.`name`, `trans_global`.*
FROM `mst_global_settings` as `mst_global`
LEFT JOIN `trans_global_settings` as `trans_global` ON `mst_global`.`global_name_id` = `trans_global`.`global_name_id`
INFO - 2017-02-08 16:06:02 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-08 16:06:03 --> Config Class Initialized
INFO - 2017-02-08 16:06:03 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:06:03 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:06:03 --> Utf8 Class Initialized
INFO - 2017-02-08 16:06:03 --> URI Class Initialized
INFO - 2017-02-08 16:06:03 --> Router Class Initialized
INFO - 2017-02-08 16:06:03 --> Output Class Initialized
INFO - 2017-02-08 16:06:03 --> Security Class Initialized
DEBUG - 2017-02-08 16:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:06:03 --> Input Class Initialized
INFO - 2017-02-08 16:06:03 --> Language Class Initialized
INFO - 2017-02-08 16:06:03 --> Language Class Initialized
INFO - 2017-02-08 16:06:03 --> Config Class Initialized
INFO - 2017-02-08 16:06:03 --> Loader Class Initialized
INFO - 2017-02-08 16:06:03 --> Helper loaded: form_helper
INFO - 2017-02-08 16:06:03 --> Helper loaded: url_helper
INFO - 2017-02-08 16:06:03 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:06:03 --> Database Driver Class Initialized
INFO - 2017-02-08 16:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:06:03 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:06:03 --> Template Class Initialized
INFO - 2017-02-08 16:06:03 --> Controller Class Initialized
DEBUG - 2017-02-08 16:06:03 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:06:03 --> Model Class Initialized
INFO - 2017-02-08 16:06:03 --> Model Class Initialized
INFO - 2017-02-08 16:06:03 --> Model Class Initialized
ERROR - 2017-02-08 16:06:03 --> Query error: Table 'mobile.mst_global_settings' doesn't exist - Invalid query: SELECT `mst_global`.`global_name_id` as `global_id`, `mst_global`.`name`, `trans_global`.*
FROM `mst_global_settings` as `mst_global`
LEFT JOIN `trans_global_settings` as `trans_global` ON `mst_global`.`global_name_id` = `trans_global`.`global_name_id`
INFO - 2017-02-08 16:06:03 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-08 16:06:04 --> Config Class Initialized
INFO - 2017-02-08 16:06:04 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:06:04 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:06:04 --> Utf8 Class Initialized
INFO - 2017-02-08 16:06:04 --> URI Class Initialized
INFO - 2017-02-08 16:06:04 --> Router Class Initialized
INFO - 2017-02-08 16:06:04 --> Output Class Initialized
INFO - 2017-02-08 16:06:04 --> Security Class Initialized
DEBUG - 2017-02-08 16:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:06:04 --> Input Class Initialized
INFO - 2017-02-08 16:06:04 --> Language Class Initialized
INFO - 2017-02-08 16:06:04 --> Language Class Initialized
INFO - 2017-02-08 16:06:04 --> Config Class Initialized
INFO - 2017-02-08 16:06:04 --> Loader Class Initialized
INFO - 2017-02-08 16:06:04 --> Helper loaded: form_helper
INFO - 2017-02-08 16:06:04 --> Helper loaded: url_helper
INFO - 2017-02-08 16:06:04 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:06:04 --> Database Driver Class Initialized
INFO - 2017-02-08 16:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:06:04 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:06:04 --> Template Class Initialized
INFO - 2017-02-08 16:06:04 --> Controller Class Initialized
DEBUG - 2017-02-08 16:06:04 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:06:04 --> Model Class Initialized
INFO - 2017-02-08 16:06:04 --> Model Class Initialized
INFO - 2017-02-08 16:06:04 --> Model Class Initialized
ERROR - 2017-02-08 16:06:04 --> Query error: Table 'mobile.mst_global_settings' doesn't exist - Invalid query: SELECT `mst_global`.`global_name_id` as `global_id`, `mst_global`.`name`, `trans_global`.*
FROM `mst_global_settings` as `mst_global`
LEFT JOIN `trans_global_settings` as `trans_global` ON `mst_global`.`global_name_id` = `trans_global`.`global_name_id`
INFO - 2017-02-08 16:06:04 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-08 16:06:33 --> Config Class Initialized
INFO - 2017-02-08 16:06:33 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:06:33 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:06:33 --> Utf8 Class Initialized
INFO - 2017-02-08 16:06:33 --> URI Class Initialized
INFO - 2017-02-08 16:06:33 --> Router Class Initialized
INFO - 2017-02-08 16:06:33 --> Output Class Initialized
INFO - 2017-02-08 16:06:33 --> Security Class Initialized
DEBUG - 2017-02-08 16:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:06:33 --> Input Class Initialized
INFO - 2017-02-08 16:06:33 --> Language Class Initialized
INFO - 2017-02-08 16:06:33 --> Language Class Initialized
INFO - 2017-02-08 16:06:33 --> Config Class Initialized
INFO - 2017-02-08 16:06:33 --> Loader Class Initialized
INFO - 2017-02-08 16:06:33 --> Helper loaded: form_helper
INFO - 2017-02-08 16:06:33 --> Helper loaded: url_helper
INFO - 2017-02-08 16:06:33 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:06:33 --> Database Driver Class Initialized
INFO - 2017-02-08 16:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:06:33 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:06:33 --> Template Class Initialized
INFO - 2017-02-08 16:06:33 --> Controller Class Initialized
DEBUG - 2017-02-08 16:06:33 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:06:33 --> Model Class Initialized
INFO - 2017-02-08 16:06:33 --> Model Class Initialized
INFO - 2017-02-08 16:06:33 --> Model Class Initialized
ERROR - 2017-02-08 16:06:33 --> Query error: Table 'mobile.trans_global_settings' doesn't exist - Invalid query: SELECT `mst_global`.`global_name_id` as `global_id`, `mst_global`.`name`, `trans_global`.*
FROM `mst_global_settings` as `mst_global`
LEFT JOIN `trans_global_settings` as `trans_global` ON `mst_global`.`global_name_id` = `trans_global`.`global_name_id`
INFO - 2017-02-08 16:06:33 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-08 16:06:34 --> Config Class Initialized
INFO - 2017-02-08 16:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:06:34 --> Utf8 Class Initialized
INFO - 2017-02-08 16:06:34 --> URI Class Initialized
INFO - 2017-02-08 16:06:34 --> Router Class Initialized
INFO - 2017-02-08 16:06:34 --> Output Class Initialized
INFO - 2017-02-08 16:06:34 --> Security Class Initialized
DEBUG - 2017-02-08 16:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:06:34 --> Input Class Initialized
INFO - 2017-02-08 16:06:34 --> Language Class Initialized
INFO - 2017-02-08 16:06:34 --> Language Class Initialized
INFO - 2017-02-08 16:06:34 --> Config Class Initialized
INFO - 2017-02-08 16:06:34 --> Loader Class Initialized
INFO - 2017-02-08 16:06:34 --> Helper loaded: form_helper
INFO - 2017-02-08 16:06:34 --> Helper loaded: url_helper
INFO - 2017-02-08 16:06:34 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:06:34 --> Database Driver Class Initialized
INFO - 2017-02-08 16:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:06:34 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:06:34 --> Template Class Initialized
INFO - 2017-02-08 16:06:34 --> Controller Class Initialized
DEBUG - 2017-02-08 16:06:34 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:06:34 --> Model Class Initialized
INFO - 2017-02-08 16:06:34 --> Model Class Initialized
INFO - 2017-02-08 16:06:34 --> Model Class Initialized
ERROR - 2017-02-08 16:06:34 --> Query error: Table 'mobile.trans_global_settings' doesn't exist - Invalid query: SELECT `mst_global`.`global_name_id` as `global_id`, `mst_global`.`name`, `trans_global`.*
FROM `mst_global_settings` as `mst_global`
LEFT JOIN `trans_global_settings` as `trans_global` ON `mst_global`.`global_name_id` = `trans_global`.`global_name_id`
INFO - 2017-02-08 16:06:34 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-08 16:06:51 --> Config Class Initialized
INFO - 2017-02-08 16:06:51 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:06:51 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:06:51 --> Utf8 Class Initialized
INFO - 2017-02-08 16:06:51 --> URI Class Initialized
INFO - 2017-02-08 16:06:51 --> Router Class Initialized
INFO - 2017-02-08 16:06:51 --> Output Class Initialized
INFO - 2017-02-08 16:06:51 --> Security Class Initialized
DEBUG - 2017-02-08 16:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:06:51 --> Input Class Initialized
INFO - 2017-02-08 16:06:51 --> Language Class Initialized
INFO - 2017-02-08 16:06:51 --> Language Class Initialized
INFO - 2017-02-08 16:06:51 --> Config Class Initialized
INFO - 2017-02-08 16:06:51 --> Loader Class Initialized
INFO - 2017-02-08 16:06:51 --> Helper loaded: form_helper
INFO - 2017-02-08 16:06:51 --> Helper loaded: url_helper
INFO - 2017-02-08 16:06:51 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:06:51 --> Database Driver Class Initialized
INFO - 2017-02-08 16:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:06:51 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:06:51 --> Template Class Initialized
INFO - 2017-02-08 16:06:51 --> Controller Class Initialized
DEBUG - 2017-02-08 16:06:51 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:06:51 --> Model Class Initialized
INFO - 2017-02-08 16:06:51 --> Model Class Initialized
INFO - 2017-02-08 16:06:51 --> Model Class Initialized
DEBUG - 2017-02-08 16:06:51 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 16:06:51 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 16:06:51 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
INFO - 2017-02-08 16:07:43 --> Config Class Initialized
INFO - 2017-02-08 16:07:43 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:07:43 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:07:43 --> Utf8 Class Initialized
INFO - 2017-02-08 16:07:43 --> URI Class Initialized
INFO - 2017-02-08 16:07:43 --> Router Class Initialized
INFO - 2017-02-08 16:07:43 --> Output Class Initialized
INFO - 2017-02-08 16:07:43 --> Security Class Initialized
DEBUG - 2017-02-08 16:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:07:43 --> Input Class Initialized
INFO - 2017-02-08 16:07:43 --> Language Class Initialized
INFO - 2017-02-08 16:07:43 --> Language Class Initialized
INFO - 2017-02-08 16:07:43 --> Config Class Initialized
INFO - 2017-02-08 16:07:43 --> Loader Class Initialized
INFO - 2017-02-08 16:07:43 --> Helper loaded: form_helper
INFO - 2017-02-08 16:07:43 --> Helper loaded: url_helper
INFO - 2017-02-08 16:07:43 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:07:43 --> Database Driver Class Initialized
INFO - 2017-02-08 16:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:07:43 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:07:43 --> Template Class Initialized
INFO - 2017-02-08 16:07:43 --> Controller Class Initialized
DEBUG - 2017-02-08 16:07:43 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:07:43 --> Model Class Initialized
INFO - 2017-02-08 16:07:43 --> Model Class Initialized
INFO - 2017-02-08 16:07:43 --> Model Class Initialized
DEBUG - 2017-02-08 16:07:43 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 16:07:43 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 16:07:43 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 16:07:43 --> Severity: Notice --> Undefined variable: arr_global_settings C:\xampp\htdocs\mobile\application\modules\backend\views\global-settings\globle_setting_list.php 22
ERROR - 2017-02-08 16:07:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mobile\application\modules\backend\views\global-settings\globle_setting_list.php 22
DEBUG - 2017-02-08 16:07:43 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/global-settings/globle_setting_list.php
DEBUG - 2017-02-08 16:07:43 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 16:07:43 --> Final output sent to browser
DEBUG - 2017-02-08 16:07:43 --> Total execution time: 0.0488
INFO - 2017-02-08 16:07:43 --> Config Class Initialized
INFO - 2017-02-08 16:07:43 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:07:43 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:07:43 --> Utf8 Class Initialized
INFO - 2017-02-08 16:07:43 --> URI Class Initialized
INFO - 2017-02-08 16:07:43 --> Router Class Initialized
INFO - 2017-02-08 16:07:43 --> Output Class Initialized
INFO - 2017-02-08 16:07:43 --> Security Class Initialized
DEBUG - 2017-02-08 16:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:07:43 --> Input Class Initialized
INFO - 2017-02-08 16:07:43 --> Language Class Initialized
ERROR - 2017-02-08 16:07:43 --> 404 Page Not Found: /index
INFO - 2017-02-08 16:07:43 --> Config Class Initialized
INFO - 2017-02-08 16:07:43 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:07:43 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:07:43 --> Utf8 Class Initialized
INFO - 2017-02-08 16:07:43 --> URI Class Initialized
INFO - 2017-02-08 16:07:43 --> Router Class Initialized
INFO - 2017-02-08 16:07:43 --> Output Class Initialized
INFO - 2017-02-08 16:07:43 --> Security Class Initialized
DEBUG - 2017-02-08 16:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:07:43 --> Input Class Initialized
INFO - 2017-02-08 16:07:43 --> Language Class Initialized
ERROR - 2017-02-08 16:07:43 --> 404 Page Not Found: /index
INFO - 2017-02-08 16:08:38 --> Config Class Initialized
INFO - 2017-02-08 16:08:38 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:08:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:08:38 --> Utf8 Class Initialized
INFO - 2017-02-08 16:08:38 --> URI Class Initialized
INFO - 2017-02-08 16:08:38 --> Router Class Initialized
INFO - 2017-02-08 16:08:38 --> Output Class Initialized
INFO - 2017-02-08 16:08:38 --> Security Class Initialized
DEBUG - 2017-02-08 16:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:08:38 --> Input Class Initialized
INFO - 2017-02-08 16:08:38 --> Language Class Initialized
INFO - 2017-02-08 16:08:38 --> Language Class Initialized
INFO - 2017-02-08 16:08:38 --> Config Class Initialized
INFO - 2017-02-08 16:08:38 --> Loader Class Initialized
INFO - 2017-02-08 16:08:38 --> Helper loaded: form_helper
INFO - 2017-02-08 16:08:38 --> Helper loaded: url_helper
INFO - 2017-02-08 16:08:38 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:08:38 --> Database Driver Class Initialized
INFO - 2017-02-08 16:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:08:38 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:08:38 --> Template Class Initialized
INFO - 2017-02-08 16:08:38 --> Controller Class Initialized
DEBUG - 2017-02-08 16:08:38 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:08:38 --> Model Class Initialized
INFO - 2017-02-08 16:08:38 --> Model Class Initialized
INFO - 2017-02-08 16:08:38 --> Model Class Initialized
DEBUG - 2017-02-08 16:08:38 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 16:08:38 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 16:08:38 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-08 16:08:38 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/global-settings/globle_setting_list.php
DEBUG - 2017-02-08 16:08:38 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 16:08:38 --> Final output sent to browser
DEBUG - 2017-02-08 16:08:38 --> Total execution time: 0.0540
INFO - 2017-02-08 16:08:38 --> Config Class Initialized
INFO - 2017-02-08 16:08:38 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:08:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:08:38 --> Utf8 Class Initialized
INFO - 2017-02-08 16:08:38 --> URI Class Initialized
INFO - 2017-02-08 16:08:38 --> Router Class Initialized
INFO - 2017-02-08 16:08:38 --> Output Class Initialized
INFO - 2017-02-08 16:08:38 --> Security Class Initialized
DEBUG - 2017-02-08 16:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:08:38 --> Input Class Initialized
INFO - 2017-02-08 16:08:38 --> Language Class Initialized
ERROR - 2017-02-08 16:08:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 16:08:38 --> Config Class Initialized
INFO - 2017-02-08 16:08:38 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:08:38 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:08:38 --> Utf8 Class Initialized
INFO - 2017-02-08 16:08:38 --> URI Class Initialized
INFO - 2017-02-08 16:08:38 --> Router Class Initialized
INFO - 2017-02-08 16:08:38 --> Output Class Initialized
INFO - 2017-02-08 16:08:38 --> Security Class Initialized
DEBUG - 2017-02-08 16:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:08:38 --> Input Class Initialized
INFO - 2017-02-08 16:08:38 --> Language Class Initialized
ERROR - 2017-02-08 16:08:38 --> 404 Page Not Found: /index
INFO - 2017-02-08 16:08:48 --> Config Class Initialized
INFO - 2017-02-08 16:08:48 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:08:48 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:08:48 --> Utf8 Class Initialized
INFO - 2017-02-08 16:08:52 --> Config Class Initialized
INFO - 2017-02-08 16:08:52 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:08:52 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:08:52 --> Utf8 Class Initialized
INFO - 2017-02-08 16:08:52 --> URI Class Initialized
INFO - 2017-02-08 16:08:52 --> Router Class Initialized
INFO - 2017-02-08 16:08:52 --> Output Class Initialized
INFO - 2017-02-08 16:08:52 --> Security Class Initialized
DEBUG - 2017-02-08 16:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:08:52 --> Input Class Initialized
INFO - 2017-02-08 16:08:52 --> Language Class Initialized
INFO - 2017-02-08 16:08:52 --> Language Class Initialized
INFO - 2017-02-08 16:08:52 --> Config Class Initialized
INFO - 2017-02-08 16:08:52 --> Loader Class Initialized
INFO - 2017-02-08 16:08:52 --> Helper loaded: form_helper
INFO - 2017-02-08 16:08:52 --> Helper loaded: url_helper
INFO - 2017-02-08 16:08:52 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:08:52 --> Database Driver Class Initialized
INFO - 2017-02-08 16:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:08:52 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:08:52 --> Template Class Initialized
INFO - 2017-02-08 16:08:52 --> Controller Class Initialized
DEBUG - 2017-02-08 16:08:52 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:08:52 --> Model Class Initialized
INFO - 2017-02-08 16:08:52 --> Model Class Initialized
INFO - 2017-02-08 16:08:52 --> Model Class Initialized
DEBUG - 2017-02-08 16:08:52 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 16:08:52 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 16:08:52 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-08 16:08:52 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/global-settings/globle_setting_list.php
DEBUG - 2017-02-08 16:08:52 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 16:08:52 --> Final output sent to browser
DEBUG - 2017-02-08 16:08:52 --> Total execution time: 0.0632
INFO - 2017-02-08 16:10:02 --> Config Class Initialized
INFO - 2017-02-08 16:10:02 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:10:02 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:10:02 --> Utf8 Class Initialized
INFO - 2017-02-08 16:10:02 --> URI Class Initialized
INFO - 2017-02-08 16:10:02 --> Router Class Initialized
INFO - 2017-02-08 16:10:02 --> Output Class Initialized
INFO - 2017-02-08 16:10:02 --> Security Class Initialized
DEBUG - 2017-02-08 16:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:10:02 --> Input Class Initialized
INFO - 2017-02-08 16:10:02 --> Language Class Initialized
INFO - 2017-02-08 16:10:02 --> Language Class Initialized
INFO - 2017-02-08 16:10:02 --> Config Class Initialized
INFO - 2017-02-08 16:10:02 --> Loader Class Initialized
INFO - 2017-02-08 16:10:02 --> Helper loaded: form_helper
INFO - 2017-02-08 16:10:02 --> Helper loaded: url_helper
INFO - 2017-02-08 16:10:02 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:10:02 --> Database Driver Class Initialized
INFO - 2017-02-08 16:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:10:02 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:10:02 --> Template Class Initialized
INFO - 2017-02-08 16:10:02 --> Controller Class Initialized
DEBUG - 2017-02-08 16:10:02 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:10:02 --> Model Class Initialized
INFO - 2017-02-08 16:10:02 --> Model Class Initialized
INFO - 2017-02-08 16:10:02 --> Model Class Initialized
DEBUG - 2017-02-08 16:10:02 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 16:10:02 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 16:10:02 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-08 16:10:02 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/global-settings/globle_setting_list.php
DEBUG - 2017-02-08 16:10:02 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 16:10:02 --> Final output sent to browser
DEBUG - 2017-02-08 16:10:02 --> Total execution time: 0.0430
INFO - 2017-02-08 16:10:02 --> Config Class Initialized
INFO - 2017-02-08 16:10:02 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:10:02 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:10:02 --> Utf8 Class Initialized
INFO - 2017-02-08 16:10:02 --> URI Class Initialized
INFO - 2017-02-08 16:10:02 --> Router Class Initialized
INFO - 2017-02-08 16:10:02 --> Output Class Initialized
INFO - 2017-02-08 16:10:02 --> Security Class Initialized
DEBUG - 2017-02-08 16:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:10:02 --> Input Class Initialized
INFO - 2017-02-08 16:10:02 --> Language Class Initialized
ERROR - 2017-02-08 16:10:02 --> 404 Page Not Found: /index
INFO - 2017-02-08 16:10:02 --> Config Class Initialized
INFO - 2017-02-08 16:10:02 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:10:02 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:10:02 --> Utf8 Class Initialized
INFO - 2017-02-08 16:10:02 --> URI Class Initialized
INFO - 2017-02-08 16:10:02 --> Router Class Initialized
INFO - 2017-02-08 16:10:02 --> Output Class Initialized
INFO - 2017-02-08 16:10:02 --> Security Class Initialized
DEBUG - 2017-02-08 16:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:10:02 --> Input Class Initialized
INFO - 2017-02-08 16:10:02 --> Language Class Initialized
ERROR - 2017-02-08 16:10:02 --> 404 Page Not Found: /index
INFO - 2017-02-08 16:10:03 --> Config Class Initialized
INFO - 2017-02-08 16:10:03 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:10:03 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:10:03 --> Utf8 Class Initialized
INFO - 2017-02-08 16:10:25 --> Config Class Initialized
INFO - 2017-02-08 16:10:25 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:10:25 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:10:25 --> Utf8 Class Initialized
INFO - 2017-02-08 16:10:25 --> URI Class Initialized
INFO - 2017-02-08 16:10:25 --> Router Class Initialized
INFO - 2017-02-08 16:10:25 --> Output Class Initialized
INFO - 2017-02-08 16:10:25 --> Security Class Initialized
DEBUG - 2017-02-08 16:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:10:25 --> Input Class Initialized
INFO - 2017-02-08 16:10:25 --> Language Class Initialized
INFO - 2017-02-08 16:10:25 --> Language Class Initialized
INFO - 2017-02-08 16:10:25 --> Config Class Initialized
INFO - 2017-02-08 16:10:25 --> Loader Class Initialized
INFO - 2017-02-08 16:10:25 --> Helper loaded: form_helper
INFO - 2017-02-08 16:10:25 --> Helper loaded: url_helper
INFO - 2017-02-08 16:10:25 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:10:25 --> Database Driver Class Initialized
INFO - 2017-02-08 16:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:10:25 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:10:25 --> Template Class Initialized
INFO - 2017-02-08 16:10:25 --> Controller Class Initialized
DEBUG - 2017-02-08 16:10:25 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:10:25 --> Model Class Initialized
INFO - 2017-02-08 16:10:25 --> Model Class Initialized
INFO - 2017-02-08 16:10:25 --> Model Class Initialized
ERROR - 2017-02-08 16:10:25 --> Query error: Table 'mobile.mst_users' doesn't exist - Invalid query: SELECT *
FROM `mst_users`
WHERE `user_type` = '1'
AND `user_status` = '1'
INFO - 2017-02-08 16:10:25 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-08 16:11:42 --> Config Class Initialized
INFO - 2017-02-08 16:11:42 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:11:42 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:11:42 --> Utf8 Class Initialized
INFO - 2017-02-08 16:11:42 --> URI Class Initialized
INFO - 2017-02-08 16:11:42 --> Router Class Initialized
INFO - 2017-02-08 16:11:42 --> Output Class Initialized
INFO - 2017-02-08 16:11:42 --> Security Class Initialized
DEBUG - 2017-02-08 16:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:11:42 --> Input Class Initialized
INFO - 2017-02-08 16:11:42 --> Language Class Initialized
INFO - 2017-02-08 16:11:42 --> Language Class Initialized
INFO - 2017-02-08 16:11:42 --> Config Class Initialized
INFO - 2017-02-08 16:11:42 --> Loader Class Initialized
INFO - 2017-02-08 16:11:42 --> Helper loaded: form_helper
INFO - 2017-02-08 16:11:42 --> Helper loaded: url_helper
INFO - 2017-02-08 16:11:42 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:11:42 --> Database Driver Class Initialized
INFO - 2017-02-08 16:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:11:42 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:11:42 --> Template Class Initialized
INFO - 2017-02-08 16:11:42 --> Controller Class Initialized
DEBUG - 2017-02-08 16:11:42 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:11:42 --> Model Class Initialized
INFO - 2017-02-08 16:11:42 --> Model Class Initialized
INFO - 2017-02-08 16:11:42 --> Model Class Initialized
INFO - 2017-02-08 16:12:29 --> Config Class Initialized
INFO - 2017-02-08 16:12:29 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:12:29 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:12:29 --> Utf8 Class Initialized
INFO - 2017-02-08 16:12:29 --> URI Class Initialized
INFO - 2017-02-08 16:12:29 --> Router Class Initialized
INFO - 2017-02-08 16:12:29 --> Output Class Initialized
INFO - 2017-02-08 16:12:29 --> Security Class Initialized
DEBUG - 2017-02-08 16:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:12:29 --> Input Class Initialized
INFO - 2017-02-08 16:12:29 --> Language Class Initialized
INFO - 2017-02-08 16:12:29 --> Language Class Initialized
INFO - 2017-02-08 16:12:29 --> Config Class Initialized
INFO - 2017-02-08 16:12:29 --> Loader Class Initialized
INFO - 2017-02-08 16:12:29 --> Helper loaded: form_helper
INFO - 2017-02-08 16:12:29 --> Helper loaded: url_helper
INFO - 2017-02-08 16:12:29 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:12:29 --> Database Driver Class Initialized
INFO - 2017-02-08 16:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:12:29 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:12:29 --> Template Class Initialized
INFO - 2017-02-08 16:12:29 --> Controller Class Initialized
DEBUG - 2017-02-08 16:12:29 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:12:29 --> Model Class Initialized
INFO - 2017-02-08 16:12:29 --> Model Class Initialized
INFO - 2017-02-08 16:12:29 --> Model Class Initialized
DEBUG - 2017-02-08 16:12:29 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 16:12:29 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 16:12:29 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
INFO - 2017-02-08 16:12:56 --> Config Class Initialized
INFO - 2017-02-08 16:12:56 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:12:56 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:12:56 --> Utf8 Class Initialized
INFO - 2017-02-08 16:12:56 --> URI Class Initialized
INFO - 2017-02-08 16:12:57 --> Router Class Initialized
INFO - 2017-02-08 16:12:57 --> Output Class Initialized
INFO - 2017-02-08 16:12:57 --> Security Class Initialized
DEBUG - 2017-02-08 16:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:12:57 --> Input Class Initialized
INFO - 2017-02-08 16:12:57 --> Language Class Initialized
INFO - 2017-02-08 16:12:57 --> Language Class Initialized
INFO - 2017-02-08 16:12:57 --> Config Class Initialized
INFO - 2017-02-08 16:12:57 --> Loader Class Initialized
INFO - 2017-02-08 16:12:57 --> Helper loaded: form_helper
INFO - 2017-02-08 16:12:57 --> Helper loaded: url_helper
INFO - 2017-02-08 16:12:57 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:12:57 --> Database Driver Class Initialized
INFO - 2017-02-08 16:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:12:57 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:12:57 --> Template Class Initialized
INFO - 2017-02-08 16:12:57 --> Controller Class Initialized
DEBUG - 2017-02-08 16:12:57 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:12:57 --> Model Class Initialized
INFO - 2017-02-08 16:12:57 --> Model Class Initialized
INFO - 2017-02-08 16:12:57 --> Model Class Initialized
DEBUG - 2017-02-08 16:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 16:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 16:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-08 16:12:57 --> Severity: Notice --> Undefined variable: edit_id C:\xampp\htdocs\mobile\application\modules\backend\views\global-settings\globle_setting_edit.php 155
ERROR - 2017-02-08 16:12:57 --> Severity: Notice --> Undefined variable: edit_id C:\xampp\htdocs\mobile\application\modules\backend\views\global-settings\globle_setting_edit.php 188
DEBUG - 2017-02-08 16:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/global-settings/globle_setting_edit.php
DEBUG - 2017-02-08 16:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 16:12:57 --> Final output sent to browser
DEBUG - 2017-02-08 16:12:57 --> Total execution time: 0.0974
INFO - 2017-02-08 16:12:57 --> Config Class Initialized
INFO - 2017-02-08 16:12:57 --> Hooks Class Initialized
INFO - 2017-02-08 16:12:57 --> Config Class Initialized
DEBUG - 2017-02-08 16:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:12:57 --> Hooks Class Initialized
INFO - 2017-02-08 16:12:57 --> Utf8 Class Initialized
INFO - 2017-02-08 16:12:57 --> URI Class Initialized
DEBUG - 2017-02-08 16:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:12:57 --> Utf8 Class Initialized
INFO - 2017-02-08 16:12:57 --> URI Class Initialized
INFO - 2017-02-08 16:12:57 --> Router Class Initialized
INFO - 2017-02-08 16:12:57 --> Output Class Initialized
INFO - 2017-02-08 16:12:57 --> Router Class Initialized
INFO - 2017-02-08 16:12:57 --> Security Class Initialized
INFO - 2017-02-08 16:12:57 --> Output Class Initialized
DEBUG - 2017-02-08 16:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:12:57 --> Input Class Initialized
INFO - 2017-02-08 16:12:57 --> Security Class Initialized
INFO - 2017-02-08 16:12:57 --> Language Class Initialized
DEBUG - 2017-02-08 16:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:12:57 --> Input Class Initialized
ERROR - 2017-02-08 16:12:57 --> 404 Page Not Found: /index
INFO - 2017-02-08 16:12:57 --> Language Class Initialized
ERROR - 2017-02-08 16:12:57 --> 404 Page Not Found: /index
INFO - 2017-02-08 16:12:57 --> Config Class Initialized
INFO - 2017-02-08 16:12:57 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:12:57 --> Utf8 Class Initialized
INFO - 2017-02-08 16:12:57 --> URI Class Initialized
INFO - 2017-02-08 16:12:57 --> Router Class Initialized
INFO - 2017-02-08 16:12:57 --> Output Class Initialized
INFO - 2017-02-08 16:12:57 --> Security Class Initialized
DEBUG - 2017-02-08 16:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:12:57 --> Input Class Initialized
INFO - 2017-02-08 16:12:57 --> Language Class Initialized
ERROR - 2017-02-08 16:12:57 --> 404 Page Not Found: /index
INFO - 2017-02-08 16:12:57 --> Config Class Initialized
INFO - 2017-02-08 16:12:57 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:12:57 --> Utf8 Class Initialized
INFO - 2017-02-08 16:12:57 --> URI Class Initialized
INFO - 2017-02-08 16:12:57 --> Router Class Initialized
INFO - 2017-02-08 16:12:57 --> Output Class Initialized
INFO - 2017-02-08 16:12:57 --> Security Class Initialized
DEBUG - 2017-02-08 16:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:12:57 --> Input Class Initialized
INFO - 2017-02-08 16:12:57 --> Language Class Initialized
ERROR - 2017-02-08 16:12:57 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-08 16:13:53 --> Config Class Initialized
INFO - 2017-02-08 16:13:53 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:13:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:13:53 --> Utf8 Class Initialized
INFO - 2017-02-08 16:13:53 --> URI Class Initialized
INFO - 2017-02-08 16:13:53 --> Router Class Initialized
INFO - 2017-02-08 16:13:53 --> Output Class Initialized
INFO - 2017-02-08 16:13:53 --> Security Class Initialized
DEBUG - 2017-02-08 16:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:13:53 --> Input Class Initialized
INFO - 2017-02-08 16:13:53 --> Language Class Initialized
INFO - 2017-02-08 16:13:53 --> Language Class Initialized
INFO - 2017-02-08 16:13:53 --> Config Class Initialized
INFO - 2017-02-08 16:13:53 --> Loader Class Initialized
INFO - 2017-02-08 16:13:53 --> Helper loaded: form_helper
INFO - 2017-02-08 16:13:53 --> Helper loaded: url_helper
INFO - 2017-02-08 16:13:53 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:13:53 --> Database Driver Class Initialized
INFO - 2017-02-08 16:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:13:53 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:13:53 --> Template Class Initialized
INFO - 2017-02-08 16:13:53 --> Controller Class Initialized
DEBUG - 2017-02-08 16:13:53 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:13:53 --> Model Class Initialized
INFO - 2017-02-08 16:13:53 --> Model Class Initialized
INFO - 2017-02-08 16:13:53 --> Model Class Initialized
DEBUG - 2017-02-08 16:13:53 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 16:13:53 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 16:13:53 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-08 16:13:53 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/global-settings/globle_setting_edit.php
DEBUG - 2017-02-08 16:13:53 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 16:13:53 --> Final output sent to browser
DEBUG - 2017-02-08 16:13:53 --> Total execution time: 0.0641
INFO - 2017-02-08 16:13:53 --> Config Class Initialized
INFO - 2017-02-08 16:13:53 --> Hooks Class Initialized
INFO - 2017-02-08 16:13:53 --> Config Class Initialized
INFO - 2017-02-08 16:13:53 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:13:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:13:53 --> Utf8 Class Initialized
DEBUG - 2017-02-08 16:13:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:13:53 --> URI Class Initialized
INFO - 2017-02-08 16:13:53 --> Utf8 Class Initialized
INFO - 2017-02-08 16:13:53 --> URI Class Initialized
INFO - 2017-02-08 16:13:53 --> Router Class Initialized
INFO - 2017-02-08 16:13:53 --> Output Class Initialized
INFO - 2017-02-08 16:13:53 --> Router Class Initialized
INFO - 2017-02-08 16:13:53 --> Security Class Initialized
INFO - 2017-02-08 16:13:53 --> Output Class Initialized
DEBUG - 2017-02-08 16:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:13:53 --> Input Class Initialized
INFO - 2017-02-08 16:13:53 --> Security Class Initialized
INFO - 2017-02-08 16:13:53 --> Language Class Initialized
DEBUG - 2017-02-08 16:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:13:53 --> Input Class Initialized
ERROR - 2017-02-08 16:13:53 --> 404 Page Not Found: /index
INFO - 2017-02-08 16:13:53 --> Language Class Initialized
ERROR - 2017-02-08 16:13:53 --> 404 Page Not Found: /index
INFO - 2017-02-08 16:13:53 --> Config Class Initialized
INFO - 2017-02-08 16:13:53 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:13:53 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:13:53 --> Utf8 Class Initialized
INFO - 2017-02-08 16:13:53 --> URI Class Initialized
INFO - 2017-02-08 16:13:53 --> Router Class Initialized
INFO - 2017-02-08 16:13:53 --> Output Class Initialized
INFO - 2017-02-08 16:13:53 --> Security Class Initialized
DEBUG - 2017-02-08 16:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:13:53 --> Input Class Initialized
INFO - 2017-02-08 16:13:53 --> Language Class Initialized
ERROR - 2017-02-08 16:13:53 --> 404 Page Not Found: /index
INFO - 2017-02-08 16:14:07 --> Config Class Initialized
INFO - 2017-02-08 16:14:07 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:14:07 --> Utf8 Class Initialized
INFO - 2017-02-08 16:14:07 --> URI Class Initialized
INFO - 2017-02-08 16:14:07 --> Router Class Initialized
INFO - 2017-02-08 16:14:07 --> Output Class Initialized
INFO - 2017-02-08 16:14:07 --> Security Class Initialized
DEBUG - 2017-02-08 16:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:14:07 --> Input Class Initialized
INFO - 2017-02-08 16:14:07 --> Language Class Initialized
INFO - 2017-02-08 16:14:07 --> Language Class Initialized
INFO - 2017-02-08 16:14:07 --> Config Class Initialized
INFO - 2017-02-08 16:14:07 --> Loader Class Initialized
INFO - 2017-02-08 16:14:07 --> Helper loaded: form_helper
INFO - 2017-02-08 16:14:07 --> Helper loaded: url_helper
INFO - 2017-02-08 16:14:07 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:14:07 --> Database Driver Class Initialized
INFO - 2017-02-08 16:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:14:07 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:14:07 --> Template Class Initialized
INFO - 2017-02-08 16:14:07 --> Controller Class Initialized
DEBUG - 2017-02-08 16:14:07 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:14:07 --> Model Class Initialized
INFO - 2017-02-08 16:14:07 --> Model Class Initialized
INFO - 2017-02-08 16:14:07 --> Model Class Initialized
ERROR - 2017-02-08 16:14:08 --> Severity: Notice --> Undefined index: absolute_path C:\xampp\htdocs\mobile\application\modules\backend\controllers\Global_setting.php 72
ERROR - 2017-02-08 16:14:08 --> Severity: Warning --> fopen(application/views/backend/global-setting/global-settings-17): failed to open stream: No such file or directory C:\xampp\htdocs\mobile\application\modules\backend\controllers\Global_setting.php 72
ERROR - 2017-02-08 16:14:08 --> Severity: Error --> Call to undefined method Common_Model::getGlobalSettings() C:\xampp\htdocs\mobile\application\modules\backend\controllers\Global_setting.php 73
INFO - 2017-02-08 16:14:15 --> Config Class Initialized
INFO - 2017-02-08 16:14:15 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:14:15 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:14:15 --> Utf8 Class Initialized
INFO - 2017-02-08 16:14:15 --> URI Class Initialized
INFO - 2017-02-08 16:14:15 --> Router Class Initialized
INFO - 2017-02-08 16:14:15 --> Output Class Initialized
INFO - 2017-02-08 16:14:15 --> Security Class Initialized
DEBUG - 2017-02-08 16:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:14:15 --> Input Class Initialized
INFO - 2017-02-08 16:14:15 --> Language Class Initialized
INFO - 2017-02-08 16:14:15 --> Language Class Initialized
INFO - 2017-02-08 16:14:15 --> Config Class Initialized
INFO - 2017-02-08 16:14:15 --> Loader Class Initialized
INFO - 2017-02-08 16:14:15 --> Helper loaded: form_helper
INFO - 2017-02-08 16:14:15 --> Helper loaded: url_helper
INFO - 2017-02-08 16:14:15 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:14:15 --> Database Driver Class Initialized
INFO - 2017-02-08 16:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:14:15 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:14:15 --> Template Class Initialized
INFO - 2017-02-08 16:14:15 --> Controller Class Initialized
DEBUG - 2017-02-08 16:14:15 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:14:15 --> Model Class Initialized
INFO - 2017-02-08 16:14:15 --> Model Class Initialized
INFO - 2017-02-08 16:14:15 --> Model Class Initialized
DEBUG - 2017-02-08 16:14:15 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 16:14:15 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 16:14:15 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-08 16:14:15 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/global-settings/globle_setting_edit.php
DEBUG - 2017-02-08 16:14:15 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 16:14:15 --> Final output sent to browser
DEBUG - 2017-02-08 16:14:15 --> Total execution time: 0.0566
INFO - 2017-02-08 16:14:18 --> Config Class Initialized
INFO - 2017-02-08 16:14:18 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:14:18 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:14:18 --> Utf8 Class Initialized
INFO - 2017-02-08 16:14:18 --> URI Class Initialized
INFO - 2017-02-08 16:14:18 --> Router Class Initialized
INFO - 2017-02-08 16:14:18 --> Output Class Initialized
INFO - 2017-02-08 16:14:18 --> Security Class Initialized
DEBUG - 2017-02-08 16:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:14:18 --> Input Class Initialized
INFO - 2017-02-08 16:14:18 --> Language Class Initialized
INFO - 2017-02-08 16:14:18 --> Language Class Initialized
INFO - 2017-02-08 16:14:18 --> Config Class Initialized
INFO - 2017-02-08 16:14:18 --> Loader Class Initialized
INFO - 2017-02-08 16:14:18 --> Helper loaded: form_helper
INFO - 2017-02-08 16:14:18 --> Helper loaded: url_helper
INFO - 2017-02-08 16:14:18 --> Helper loaded: utility_helper
INFO - 2017-02-08 16:14:18 --> Database Driver Class Initialized
INFO - 2017-02-08 16:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-08 16:14:18 --> User Agent Class Initialized
DEBUG - 2017-02-08 16:14:18 --> Template Class Initialized
INFO - 2017-02-08 16:14:18 --> Controller Class Initialized
DEBUG - 2017-02-08 16:14:18 --> Global_Setting MX_Controller Initialized
INFO - 2017-02-08 16:14:18 --> Model Class Initialized
INFO - 2017-02-08 16:14:18 --> Model Class Initialized
INFO - 2017-02-08 16:14:18 --> Model Class Initialized
DEBUG - 2017-02-08 16:14:18 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-08 16:14:18 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-08 16:14:18 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-08 16:14:18 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/global-settings/globle_setting_edit.php
DEBUG - 2017-02-08 16:14:18 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-08 16:14:18 --> Final output sent to browser
DEBUG - 2017-02-08 16:14:18 --> Total execution time: 0.0390
INFO - 2017-02-08 16:14:18 --> Config Class Initialized
INFO - 2017-02-08 16:14:18 --> Config Class Initialized
INFO - 2017-02-08 16:14:18 --> Hooks Class Initialized
INFO - 2017-02-08 16:14:18 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:14:18 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:14:18 --> Utf8 Class Initialized
INFO - 2017-02-08 16:14:18 --> URI Class Initialized
INFO - 2017-02-08 16:14:18 --> Router Class Initialized
DEBUG - 2017-02-08 16:14:18 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:14:18 --> Utf8 Class Initialized
INFO - 2017-02-08 16:14:18 --> Output Class Initialized
INFO - 2017-02-08 16:14:18 --> Security Class Initialized
INFO - 2017-02-08 16:14:18 --> URI Class Initialized
DEBUG - 2017-02-08 16:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:14:18 --> Input Class Initialized
INFO - 2017-02-08 16:14:18 --> Language Class Initialized
ERROR - 2017-02-08 16:14:18 --> 404 Page Not Found: /index
INFO - 2017-02-08 16:14:18 --> Router Class Initialized
INFO - 2017-02-08 16:14:18 --> Output Class Initialized
INFO - 2017-02-08 16:14:18 --> Security Class Initialized
DEBUG - 2017-02-08 16:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:14:18 --> Input Class Initialized
INFO - 2017-02-08 16:14:18 --> Language Class Initialized
ERROR - 2017-02-08 16:14:18 --> 404 Page Not Found: /index
INFO - 2017-02-08 16:14:18 --> Config Class Initialized
INFO - 2017-02-08 16:14:18 --> Hooks Class Initialized
DEBUG - 2017-02-08 16:14:18 --> UTF-8 Support Enabled
INFO - 2017-02-08 16:14:18 --> Utf8 Class Initialized
INFO - 2017-02-08 16:14:18 --> URI Class Initialized
INFO - 2017-02-08 16:14:18 --> Router Class Initialized
INFO - 2017-02-08 16:14:18 --> Output Class Initialized
INFO - 2017-02-08 16:14:18 --> Security Class Initialized
DEBUG - 2017-02-08 16:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-08 16:14:18 --> Input Class Initialized
INFO - 2017-02-08 16:14:18 --> Language Class Initialized
ERROR - 2017-02-08 16:14:18 --> 404 Page Not Found: /index
