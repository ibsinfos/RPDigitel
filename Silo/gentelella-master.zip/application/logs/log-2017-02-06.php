<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-06 06:20:56 --> Config Class Initialized
INFO - 2017-02-06 06:20:56 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:20:56 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:20:56 --> Utf8 Class Initialized
INFO - 2017-02-06 06:20:56 --> URI Class Initialized
DEBUG - 2017-02-06 06:20:56 --> No URI present. Default controller set.
INFO - 2017-02-06 06:20:56 --> Router Class Initialized
INFO - 2017-02-06 06:20:56 --> Output Class Initialized
INFO - 2017-02-06 06:20:56 --> Security Class Initialized
DEBUG - 2017-02-06 06:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:20:57 --> Input Class Initialized
INFO - 2017-02-06 06:20:57 --> Language Class Initialized
INFO - 2017-02-06 06:20:57 --> Language Class Initialized
INFO - 2017-02-06 06:20:57 --> Config Class Initialized
INFO - 2017-02-06 06:20:57 --> Loader Class Initialized
INFO - 2017-02-06 06:20:57 --> Helper loaded: form_helper
INFO - 2017-02-06 06:20:57 --> Helper loaded: url_helper
INFO - 2017-02-06 06:20:57 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:20:57 --> Database Driver Class Initialized
INFO - 2017-02-06 06:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:20:57 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:20:57 --> Template Class Initialized
INFO - 2017-02-06 06:20:57 --> Controller Class Initialized
INFO - 2017-02-06 06:20:57 --> Form Validation Class Initialized
DEBUG - 2017-02-06 06:20:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-06 06:20:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-06 06:20:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-06 06:20:57 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:20:57 --> Final output sent to browser
DEBUG - 2017-02-06 06:20:57 --> Total execution time: 0.6219
INFO - 2017-02-06 06:21:06 --> Config Class Initialized
INFO - 2017-02-06 06:21:06 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:21:06 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:21:06 --> Utf8 Class Initialized
INFO - 2017-02-06 06:21:06 --> URI Class Initialized
INFO - 2017-02-06 06:21:06 --> Router Class Initialized
INFO - 2017-02-06 06:21:06 --> Output Class Initialized
INFO - 2017-02-06 06:21:06 --> Security Class Initialized
DEBUG - 2017-02-06 06:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:21:06 --> Input Class Initialized
INFO - 2017-02-06 06:21:06 --> Language Class Initialized
ERROR - 2017-02-06 06:21:06 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:21:11 --> Config Class Initialized
INFO - 2017-02-06 06:21:11 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:21:11 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:21:11 --> Utf8 Class Initialized
INFO - 2017-02-06 06:21:11 --> URI Class Initialized
INFO - 2017-02-06 06:21:11 --> Router Class Initialized
INFO - 2017-02-06 06:21:11 --> Output Class Initialized
INFO - 2017-02-06 06:21:11 --> Security Class Initialized
DEBUG - 2017-02-06 06:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:21:11 --> Input Class Initialized
INFO - 2017-02-06 06:21:11 --> Language Class Initialized
ERROR - 2017-02-06 06:21:11 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:21:12 --> Config Class Initialized
INFO - 2017-02-06 06:21:12 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:21:12 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:21:12 --> Utf8 Class Initialized
INFO - 2017-02-06 06:21:12 --> URI Class Initialized
INFO - 2017-02-06 06:21:12 --> Router Class Initialized
INFO - 2017-02-06 06:21:12 --> Output Class Initialized
INFO - 2017-02-06 06:21:12 --> Security Class Initialized
DEBUG - 2017-02-06 06:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:21:12 --> Input Class Initialized
INFO - 2017-02-06 06:21:12 --> Language Class Initialized
INFO - 2017-02-06 06:21:12 --> Language Class Initialized
INFO - 2017-02-06 06:21:12 --> Config Class Initialized
INFO - 2017-02-06 06:21:12 --> Loader Class Initialized
INFO - 2017-02-06 06:21:12 --> Helper loaded: form_helper
INFO - 2017-02-06 06:21:12 --> Helper loaded: url_helper
INFO - 2017-02-06 06:21:12 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:21:12 --> Database Driver Class Initialized
INFO - 2017-02-06 06:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:21:12 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:21:12 --> Template Class Initialized
INFO - 2017-02-06 06:21:12 --> Controller Class Initialized
INFO - 2017-02-06 06:21:12 --> Form Validation Class Initialized
DEBUG - 2017-02-06 06:21:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-06 06:21:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-06 06:21:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/how_it_works.php
DEBUG - 2017-02-06 06:21:12 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:21:12 --> Final output sent to browser
DEBUG - 2017-02-06 06:21:12 --> Total execution time: 0.0616
INFO - 2017-02-06 06:21:25 --> Config Class Initialized
INFO - 2017-02-06 06:21:25 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:21:25 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:21:25 --> Utf8 Class Initialized
INFO - 2017-02-06 06:21:25 --> URI Class Initialized
INFO - 2017-02-06 06:21:25 --> Router Class Initialized
INFO - 2017-02-06 06:21:25 --> Output Class Initialized
INFO - 2017-02-06 06:21:25 --> Security Class Initialized
DEBUG - 2017-02-06 06:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:21:25 --> Input Class Initialized
INFO - 2017-02-06 06:21:25 --> Language Class Initialized
ERROR - 2017-02-06 06:21:25 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:21:25 --> Config Class Initialized
INFO - 2017-02-06 06:21:25 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:21:25 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:21:25 --> Utf8 Class Initialized
INFO - 2017-02-06 06:21:25 --> URI Class Initialized
INFO - 2017-02-06 06:21:25 --> Router Class Initialized
INFO - 2017-02-06 06:21:25 --> Output Class Initialized
INFO - 2017-02-06 06:21:25 --> Security Class Initialized
DEBUG - 2017-02-06 06:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:21:25 --> Input Class Initialized
INFO - 2017-02-06 06:21:25 --> Language Class Initialized
ERROR - 2017-02-06 06:21:25 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:21:25 --> Config Class Initialized
INFO - 2017-02-06 06:21:25 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:21:25 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:21:25 --> Utf8 Class Initialized
INFO - 2017-02-06 06:21:25 --> URI Class Initialized
INFO - 2017-02-06 06:21:25 --> Router Class Initialized
INFO - 2017-02-06 06:21:25 --> Output Class Initialized
INFO - 2017-02-06 06:21:25 --> Security Class Initialized
DEBUG - 2017-02-06 06:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:21:25 --> Input Class Initialized
INFO - 2017-02-06 06:21:25 --> Language Class Initialized
ERROR - 2017-02-06 06:21:25 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:21:26 --> Config Class Initialized
INFO - 2017-02-06 06:21:26 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:21:26 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:21:26 --> Utf8 Class Initialized
INFO - 2017-02-06 06:21:26 --> URI Class Initialized
INFO - 2017-02-06 06:21:26 --> Router Class Initialized
INFO - 2017-02-06 06:21:26 --> Output Class Initialized
INFO - 2017-02-06 06:21:26 --> Security Class Initialized
DEBUG - 2017-02-06 06:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:21:26 --> Input Class Initialized
INFO - 2017-02-06 06:21:26 --> Language Class Initialized
INFO - 2017-02-06 06:21:26 --> Language Class Initialized
INFO - 2017-02-06 06:21:26 --> Config Class Initialized
INFO - 2017-02-06 06:21:26 --> Loader Class Initialized
INFO - 2017-02-06 06:21:26 --> Helper loaded: form_helper
INFO - 2017-02-06 06:21:26 --> Helper loaded: url_helper
INFO - 2017-02-06 06:21:26 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:21:26 --> Database Driver Class Initialized
INFO - 2017-02-06 06:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:21:26 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:21:26 --> Template Class Initialized
INFO - 2017-02-06 06:21:26 --> Controller Class Initialized
INFO - 2017-02-06 06:21:26 --> Form Validation Class Initialized
DEBUG - 2017-02-06 06:21:26 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-06 06:21:26 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-06 06:21:26 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/pricing.php
DEBUG - 2017-02-06 06:21:26 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:21:26 --> Final output sent to browser
DEBUG - 2017-02-06 06:21:26 --> Total execution time: 0.0737
INFO - 2017-02-06 06:21:36 --> Config Class Initialized
INFO - 2017-02-06 06:21:36 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:21:36 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:21:36 --> Utf8 Class Initialized
INFO - 2017-02-06 06:21:36 --> URI Class Initialized
INFO - 2017-02-06 06:21:36 --> Router Class Initialized
INFO - 2017-02-06 06:21:36 --> Output Class Initialized
INFO - 2017-02-06 06:21:36 --> Security Class Initialized
DEBUG - 2017-02-06 06:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:21:36 --> Input Class Initialized
INFO - 2017-02-06 06:21:36 --> Language Class Initialized
ERROR - 2017-02-06 06:21:36 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:21:37 --> Config Class Initialized
INFO - 2017-02-06 06:21:37 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:21:37 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:21:37 --> Utf8 Class Initialized
INFO - 2017-02-06 06:21:37 --> URI Class Initialized
INFO - 2017-02-06 06:21:37 --> Router Class Initialized
INFO - 2017-02-06 06:21:37 --> Output Class Initialized
INFO - 2017-02-06 06:21:37 --> Security Class Initialized
DEBUG - 2017-02-06 06:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:21:37 --> Input Class Initialized
INFO - 2017-02-06 06:21:37 --> Language Class Initialized
INFO - 2017-02-06 06:21:37 --> Language Class Initialized
INFO - 2017-02-06 06:21:37 --> Config Class Initialized
INFO - 2017-02-06 06:21:37 --> Loader Class Initialized
INFO - 2017-02-06 06:21:37 --> Helper loaded: form_helper
INFO - 2017-02-06 06:21:37 --> Helper loaded: url_helper
INFO - 2017-02-06 06:21:37 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:21:37 --> Database Driver Class Initialized
INFO - 2017-02-06 06:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:21:37 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:21:37 --> Template Class Initialized
INFO - 2017-02-06 06:21:37 --> Controller Class Initialized
INFO - 2017-02-06 06:21:37 --> Form Validation Class Initialized
DEBUG - 2017-02-06 06:21:37 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-06 06:21:37 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-06 06:21:37 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-06 06:21:37 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:21:37 --> Final output sent to browser
DEBUG - 2017-02-06 06:21:37 --> Total execution time: 0.0530
INFO - 2017-02-06 06:21:44 --> Config Class Initialized
INFO - 2017-02-06 06:21:44 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:21:44 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:21:44 --> Utf8 Class Initialized
INFO - 2017-02-06 06:21:44 --> URI Class Initialized
INFO - 2017-02-06 06:21:44 --> Router Class Initialized
INFO - 2017-02-06 06:21:44 --> Output Class Initialized
INFO - 2017-02-06 06:21:44 --> Security Class Initialized
DEBUG - 2017-02-06 06:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:21:44 --> Input Class Initialized
INFO - 2017-02-06 06:21:44 --> Language Class Initialized
ERROR - 2017-02-06 06:21:44 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:21:44 --> Config Class Initialized
INFO - 2017-02-06 06:21:44 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:21:44 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:21:44 --> Utf8 Class Initialized
INFO - 2017-02-06 06:21:44 --> URI Class Initialized
INFO - 2017-02-06 06:21:44 --> Router Class Initialized
INFO - 2017-02-06 06:21:44 --> Output Class Initialized
INFO - 2017-02-06 06:21:44 --> Security Class Initialized
DEBUG - 2017-02-06 06:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:21:44 --> Input Class Initialized
INFO - 2017-02-06 06:21:44 --> Language Class Initialized
ERROR - 2017-02-06 06:21:44 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:21:45 --> Config Class Initialized
INFO - 2017-02-06 06:21:45 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:21:45 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:21:45 --> Utf8 Class Initialized
INFO - 2017-02-06 06:21:45 --> URI Class Initialized
INFO - 2017-02-06 06:21:45 --> Router Class Initialized
INFO - 2017-02-06 06:21:45 --> Output Class Initialized
INFO - 2017-02-06 06:21:45 --> Security Class Initialized
DEBUG - 2017-02-06 06:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:21:45 --> Input Class Initialized
INFO - 2017-02-06 06:21:45 --> Language Class Initialized
ERROR - 2017-02-06 06:21:45 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:21:51 --> Config Class Initialized
INFO - 2017-02-06 06:21:51 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:21:51 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:21:51 --> Utf8 Class Initialized
INFO - 2017-02-06 06:21:51 --> URI Class Initialized
INFO - 2017-02-06 06:21:51 --> Router Class Initialized
INFO - 2017-02-06 06:21:51 --> Output Class Initialized
INFO - 2017-02-06 06:21:51 --> Security Class Initialized
DEBUG - 2017-02-06 06:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:21:51 --> Input Class Initialized
INFO - 2017-02-06 06:21:51 --> Language Class Initialized
ERROR - 2017-02-06 06:21:51 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:22:01 --> Config Class Initialized
INFO - 2017-02-06 06:22:01 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:22:01 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:22:01 --> Utf8 Class Initialized
INFO - 2017-02-06 06:22:01 --> URI Class Initialized
INFO - 2017-02-06 06:22:01 --> Router Class Initialized
INFO - 2017-02-06 06:22:01 --> Output Class Initialized
INFO - 2017-02-06 06:22:01 --> Security Class Initialized
DEBUG - 2017-02-06 06:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:22:01 --> Input Class Initialized
INFO - 2017-02-06 06:22:01 --> Language Class Initialized
INFO - 2017-02-06 06:22:02 --> Language Class Initialized
INFO - 2017-02-06 06:22:02 --> Config Class Initialized
INFO - 2017-02-06 06:22:02 --> Loader Class Initialized
INFO - 2017-02-06 06:22:02 --> Helper loaded: form_helper
INFO - 2017-02-06 06:22:02 --> Helper loaded: url_helper
INFO - 2017-02-06 06:22:02 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:22:02 --> Database Driver Class Initialized
INFO - 2017-02-06 06:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:22:02 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:22:02 --> Template Class Initialized
INFO - 2017-02-06 06:22:02 --> Controller Class Initialized
DEBUG - 2017-02-06 06:22:02 --> Login MX_Controller Initialized
INFO - 2017-02-06 06:22:02 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 06:22:02 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/login.php
DEBUG - 2017-02-06 06:22:02 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:22:02 --> Final output sent to browser
DEBUG - 2017-02-06 06:22:02 --> Total execution time: 0.0834
INFO - 2017-02-06 06:22:02 --> Config Class Initialized
INFO - 2017-02-06 06:22:02 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:22:02 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:22:02 --> Utf8 Class Initialized
INFO - 2017-02-06 06:22:02 --> URI Class Initialized
INFO - 2017-02-06 06:22:02 --> Router Class Initialized
INFO - 2017-02-06 06:22:02 --> Output Class Initialized
INFO - 2017-02-06 06:22:02 --> Security Class Initialized
DEBUG - 2017-02-06 06:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:22:02 --> Input Class Initialized
INFO - 2017-02-06 06:22:02 --> Language Class Initialized
ERROR - 2017-02-06 06:22:02 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:22:24 --> Config Class Initialized
INFO - 2017-02-06 06:22:24 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:22:24 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:22:24 --> Utf8 Class Initialized
INFO - 2017-02-06 06:22:24 --> Config Class Initialized
INFO - 2017-02-06 06:22:24 --> Hooks Class Initialized
INFO - 2017-02-06 06:22:24 --> URI Class Initialized
DEBUG - 2017-02-06 06:22:24 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:22:24 --> Utf8 Class Initialized
INFO - 2017-02-06 06:22:24 --> URI Class Initialized
INFO - 2017-02-06 06:22:24 --> Router Class Initialized
INFO - 2017-02-06 06:22:24 --> Output Class Initialized
INFO - 2017-02-06 06:22:24 --> Router Class Initialized
INFO - 2017-02-06 06:22:24 --> Security Class Initialized
INFO - 2017-02-06 06:22:24 --> Output Class Initialized
DEBUG - 2017-02-06 06:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:22:24 --> Input Class Initialized
INFO - 2017-02-06 06:22:24 --> Security Class Initialized
INFO - 2017-02-06 06:22:24 --> Language Class Initialized
DEBUG - 2017-02-06 06:22:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-06 06:22:24 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:22:24 --> Input Class Initialized
INFO - 2017-02-06 06:22:24 --> Language Class Initialized
ERROR - 2017-02-06 06:22:24 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:22:24 --> Config Class Initialized
INFO - 2017-02-06 06:22:24 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:22:24 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:22:24 --> Utf8 Class Initialized
INFO - 2017-02-06 06:22:24 --> URI Class Initialized
INFO - 2017-02-06 06:22:24 --> Router Class Initialized
INFO - 2017-02-06 06:22:24 --> Output Class Initialized
INFO - 2017-02-06 06:22:24 --> Security Class Initialized
DEBUG - 2017-02-06 06:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:22:24 --> Input Class Initialized
INFO - 2017-02-06 06:22:24 --> Language Class Initialized
ERROR - 2017-02-06 06:22:24 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:22:24 --> Config Class Initialized
INFO - 2017-02-06 06:22:24 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:22:24 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:22:24 --> Utf8 Class Initialized
INFO - 2017-02-06 06:22:24 --> URI Class Initialized
INFO - 2017-02-06 06:22:24 --> Router Class Initialized
INFO - 2017-02-06 06:22:24 --> Output Class Initialized
INFO - 2017-02-06 06:22:24 --> Security Class Initialized
DEBUG - 2017-02-06 06:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:22:24 --> Input Class Initialized
INFO - 2017-02-06 06:22:24 --> Language Class Initialized
ERROR - 2017-02-06 06:22:24 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:22:42 --> Config Class Initialized
INFO - 2017-02-06 06:22:42 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:22:42 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:22:42 --> Utf8 Class Initialized
INFO - 2017-02-06 06:22:42 --> URI Class Initialized
INFO - 2017-02-06 06:22:42 --> Router Class Initialized
INFO - 2017-02-06 06:22:42 --> Output Class Initialized
INFO - 2017-02-06 06:22:42 --> Security Class Initialized
DEBUG - 2017-02-06 06:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:22:42 --> Input Class Initialized
INFO - 2017-02-06 06:22:42 --> Language Class Initialized
INFO - 2017-02-06 06:22:42 --> Language Class Initialized
INFO - 2017-02-06 06:22:42 --> Config Class Initialized
INFO - 2017-02-06 06:22:42 --> Loader Class Initialized
INFO - 2017-02-06 06:22:42 --> Helper loaded: form_helper
INFO - 2017-02-06 06:22:42 --> Helper loaded: url_helper
INFO - 2017-02-06 06:22:42 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:22:42 --> Database Driver Class Initialized
INFO - 2017-02-06 06:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:22:42 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:22:42 --> Template Class Initialized
INFO - 2017-02-06 06:22:42 --> Controller Class Initialized
INFO - 2017-02-06 06:22:42 --> Form Validation Class Initialized
DEBUG - 2017-02-06 06:22:42 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-06 06:22:42 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-06 06:22:42 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-06 06:22:42 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:22:42 --> Final output sent to browser
DEBUG - 2017-02-06 06:22:42 --> Total execution time: 0.0345
INFO - 2017-02-06 06:48:49 --> Config Class Initialized
INFO - 2017-02-06 06:48:49 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:48:49 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:48:49 --> Utf8 Class Initialized
INFO - 2017-02-06 06:48:49 --> URI Class Initialized
INFO - 2017-02-06 06:48:49 --> Router Class Initialized
INFO - 2017-02-06 06:48:49 --> Output Class Initialized
INFO - 2017-02-06 06:48:49 --> Security Class Initialized
DEBUG - 2017-02-06 06:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:48:49 --> Input Class Initialized
INFO - 2017-02-06 06:48:49 --> Language Class Initialized
INFO - 2017-02-06 06:48:49 --> Language Class Initialized
INFO - 2017-02-06 06:48:49 --> Config Class Initialized
INFO - 2017-02-06 06:48:49 --> Loader Class Initialized
INFO - 2017-02-06 06:48:49 --> Helper loaded: form_helper
INFO - 2017-02-06 06:48:49 --> Helper loaded: url_helper
INFO - 2017-02-06 06:48:49 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:48:49 --> Database Driver Class Initialized
INFO - 2017-02-06 06:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:48:49 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:48:49 --> Template Class Initialized
INFO - 2017-02-06 06:48:49 --> Controller Class Initialized
INFO - 2017-02-06 06:48:49 --> Form Validation Class Initialized
DEBUG - 2017-02-06 06:48:49 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-06 06:48:49 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-06 06:48:49 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-06 06:48:49 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:48:49 --> Final output sent to browser
DEBUG - 2017-02-06 06:48:49 --> Total execution time: 0.3964
INFO - 2017-02-06 06:49:00 --> Config Class Initialized
INFO - 2017-02-06 06:49:00 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:49:00 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:49:00 --> Utf8 Class Initialized
INFO - 2017-02-06 06:49:00 --> URI Class Initialized
INFO - 2017-02-06 06:49:00 --> Router Class Initialized
INFO - 2017-02-06 06:49:00 --> Output Class Initialized
INFO - 2017-02-06 06:49:00 --> Security Class Initialized
DEBUG - 2017-02-06 06:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:49:00 --> Input Class Initialized
INFO - 2017-02-06 06:49:00 --> Language Class Initialized
ERROR - 2017-02-06 06:49:00 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:49:10 --> Config Class Initialized
INFO - 2017-02-06 06:49:10 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:49:10 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:49:10 --> Utf8 Class Initialized
INFO - 2017-02-06 06:49:10 --> URI Class Initialized
INFO - 2017-02-06 06:49:10 --> Router Class Initialized
INFO - 2017-02-06 06:49:10 --> Output Class Initialized
INFO - 2017-02-06 06:49:10 --> Security Class Initialized
DEBUG - 2017-02-06 06:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:49:10 --> Input Class Initialized
INFO - 2017-02-06 06:49:10 --> Language Class Initialized
ERROR - 2017-02-06 06:49:10 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:50:23 --> Config Class Initialized
INFO - 2017-02-06 06:50:23 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:50:23 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:50:23 --> Utf8 Class Initialized
INFO - 2017-02-06 06:50:23 --> URI Class Initialized
INFO - 2017-02-06 06:50:23 --> Router Class Initialized
INFO - 2017-02-06 06:50:23 --> Output Class Initialized
INFO - 2017-02-06 06:50:23 --> Security Class Initialized
DEBUG - 2017-02-06 06:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:50:23 --> Input Class Initialized
INFO - 2017-02-06 06:50:23 --> Language Class Initialized
INFO - 2017-02-06 06:50:23 --> Language Class Initialized
INFO - 2017-02-06 06:50:23 --> Config Class Initialized
INFO - 2017-02-06 06:50:23 --> Loader Class Initialized
INFO - 2017-02-06 06:50:23 --> Helper loaded: form_helper
INFO - 2017-02-06 06:50:23 --> Helper loaded: url_helper
INFO - 2017-02-06 06:50:23 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:50:23 --> Database Driver Class Initialized
INFO - 2017-02-06 06:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:50:23 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:50:23 --> Template Class Initialized
INFO - 2017-02-06 06:50:23 --> Controller Class Initialized
DEBUG - 2017-02-06 06:50:23 --> Login MX_Controller Initialized
INFO - 2017-02-06 06:50:23 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 06:50:23 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/login.php
DEBUG - 2017-02-06 06:50:23 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:50:23 --> Final output sent to browser
DEBUG - 2017-02-06 06:50:23 --> Total execution time: 0.0750
INFO - 2017-02-06 06:50:24 --> Config Class Initialized
INFO - 2017-02-06 06:50:24 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:50:24 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:50:24 --> Utf8 Class Initialized
INFO - 2017-02-06 06:50:24 --> URI Class Initialized
INFO - 2017-02-06 06:50:24 --> Router Class Initialized
INFO - 2017-02-06 06:50:24 --> Output Class Initialized
INFO - 2017-02-06 06:50:24 --> Security Class Initialized
DEBUG - 2017-02-06 06:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:50:24 --> Input Class Initialized
INFO - 2017-02-06 06:50:24 --> Language Class Initialized
ERROR - 2017-02-06 06:50:24 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:50:43 --> Config Class Initialized
INFO - 2017-02-06 06:50:43 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:50:43 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:50:43 --> Utf8 Class Initialized
INFO - 2017-02-06 06:50:43 --> URI Class Initialized
INFO - 2017-02-06 06:50:43 --> Router Class Initialized
INFO - 2017-02-06 06:50:43 --> Output Class Initialized
INFO - 2017-02-06 06:50:44 --> Security Class Initialized
INFO - 2017-02-06 06:50:44 --> Config Class Initialized
DEBUG - 2017-02-06 06:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:50:44 --> Hooks Class Initialized
INFO - 2017-02-06 06:50:44 --> Input Class Initialized
INFO - 2017-02-06 06:50:44 --> Language Class Initialized
ERROR - 2017-02-06 06:50:44 --> 404 Page Not Found: /index
DEBUG - 2017-02-06 06:50:44 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:50:44 --> Utf8 Class Initialized
INFO - 2017-02-06 06:50:44 --> URI Class Initialized
INFO - 2017-02-06 06:50:44 --> Router Class Initialized
INFO - 2017-02-06 06:50:44 --> Output Class Initialized
INFO - 2017-02-06 06:50:44 --> Security Class Initialized
DEBUG - 2017-02-06 06:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:50:44 --> Input Class Initialized
INFO - 2017-02-06 06:50:44 --> Language Class Initialized
ERROR - 2017-02-06 06:50:44 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:50:44 --> Config Class Initialized
INFO - 2017-02-06 06:50:44 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:50:44 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:50:44 --> Utf8 Class Initialized
INFO - 2017-02-06 06:50:44 --> URI Class Initialized
INFO - 2017-02-06 06:50:44 --> Router Class Initialized
INFO - 2017-02-06 06:50:44 --> Output Class Initialized
INFO - 2017-02-06 06:50:44 --> Security Class Initialized
DEBUG - 2017-02-06 06:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:50:44 --> Input Class Initialized
INFO - 2017-02-06 06:50:44 --> Language Class Initialized
ERROR - 2017-02-06 06:50:44 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:50:47 --> Config Class Initialized
INFO - 2017-02-06 06:50:47 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:50:47 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:50:47 --> Utf8 Class Initialized
INFO - 2017-02-06 06:50:47 --> URI Class Initialized
INFO - 2017-02-06 06:50:47 --> Router Class Initialized
INFO - 2017-02-06 06:50:47 --> Output Class Initialized
INFO - 2017-02-06 06:50:47 --> Security Class Initialized
DEBUG - 2017-02-06 06:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:50:47 --> Input Class Initialized
INFO - 2017-02-06 06:50:47 --> Language Class Initialized
INFO - 2017-02-06 06:50:47 --> Language Class Initialized
INFO - 2017-02-06 06:50:47 --> Config Class Initialized
INFO - 2017-02-06 06:50:47 --> Loader Class Initialized
INFO - 2017-02-06 06:50:47 --> Helper loaded: form_helper
INFO - 2017-02-06 06:50:47 --> Helper loaded: url_helper
INFO - 2017-02-06 06:50:47 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:50:47 --> Database Driver Class Initialized
INFO - 2017-02-06 06:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:50:47 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:50:47 --> Template Class Initialized
INFO - 2017-02-06 06:50:47 --> Controller Class Initialized
DEBUG - 2017-02-06 06:50:47 --> Login MX_Controller Initialized
INFO - 2017-02-06 06:50:47 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 06:50:47 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 06:50:47 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:50:47 --> Final output sent to browser
DEBUG - 2017-02-06 06:50:47 --> Total execution time: 0.1124
INFO - 2017-02-06 06:50:47 --> Config Class Initialized
INFO - 2017-02-06 06:50:47 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:50:47 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:50:47 --> Utf8 Class Initialized
INFO - 2017-02-06 06:50:47 --> URI Class Initialized
INFO - 2017-02-06 06:50:47 --> Router Class Initialized
INFO - 2017-02-06 06:50:47 --> Output Class Initialized
INFO - 2017-02-06 06:50:47 --> Security Class Initialized
DEBUG - 2017-02-06 06:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:50:47 --> Input Class Initialized
INFO - 2017-02-06 06:50:47 --> Language Class Initialized
ERROR - 2017-02-06 06:50:47 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:51:07 --> Config Class Initialized
INFO - 2017-02-06 06:51:07 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:51:07 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:51:07 --> Utf8 Class Initialized
INFO - 2017-02-06 06:51:07 --> URI Class Initialized
INFO - 2017-02-06 06:51:07 --> Router Class Initialized
INFO - 2017-02-06 06:51:07 --> Output Class Initialized
INFO - 2017-02-06 06:51:07 --> Security Class Initialized
DEBUG - 2017-02-06 06:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:51:07 --> Input Class Initialized
INFO - 2017-02-06 06:51:07 --> Language Class Initialized
ERROR - 2017-02-06 06:51:07 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:51:07 --> Config Class Initialized
INFO - 2017-02-06 06:51:07 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:51:07 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:51:07 --> Utf8 Class Initialized
INFO - 2017-02-06 06:51:07 --> URI Class Initialized
INFO - 2017-02-06 06:51:07 --> Router Class Initialized
INFO - 2017-02-06 06:51:07 --> Output Class Initialized
INFO - 2017-02-06 06:51:07 --> Security Class Initialized
DEBUG - 2017-02-06 06:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:51:07 --> Input Class Initialized
INFO - 2017-02-06 06:51:07 --> Language Class Initialized
ERROR - 2017-02-06 06:51:07 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:51:07 --> Config Class Initialized
INFO - 2017-02-06 06:51:07 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:51:07 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:51:07 --> Utf8 Class Initialized
INFO - 2017-02-06 06:51:07 --> URI Class Initialized
INFO - 2017-02-06 06:51:07 --> Router Class Initialized
INFO - 2017-02-06 06:51:07 --> Output Class Initialized
INFO - 2017-02-06 06:51:07 --> Security Class Initialized
DEBUG - 2017-02-06 06:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:51:07 --> Input Class Initialized
INFO - 2017-02-06 06:51:07 --> Language Class Initialized
ERROR - 2017-02-06 06:51:07 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:56:41 --> Config Class Initialized
INFO - 2017-02-06 06:56:41 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:56:41 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:56:41 --> Utf8 Class Initialized
INFO - 2017-02-06 06:56:41 --> URI Class Initialized
INFO - 2017-02-06 06:56:41 --> Router Class Initialized
INFO - 2017-02-06 06:56:41 --> Output Class Initialized
INFO - 2017-02-06 06:56:41 --> Security Class Initialized
DEBUG - 2017-02-06 06:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:56:41 --> Input Class Initialized
INFO - 2017-02-06 06:56:41 --> Language Class Initialized
INFO - 2017-02-06 06:56:41 --> Language Class Initialized
INFO - 2017-02-06 06:56:41 --> Config Class Initialized
INFO - 2017-02-06 06:56:41 --> Loader Class Initialized
INFO - 2017-02-06 06:56:41 --> Helper loaded: form_helper
INFO - 2017-02-06 06:56:41 --> Helper loaded: url_helper
INFO - 2017-02-06 06:56:41 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:56:41 --> Database Driver Class Initialized
INFO - 2017-02-06 06:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:56:41 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:56:41 --> Template Class Initialized
INFO - 2017-02-06 06:56:41 --> Controller Class Initialized
DEBUG - 2017-02-06 06:56:41 --> Login MX_Controller Initialized
INFO - 2017-02-06 06:56:41 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 06:56:41 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 06:56:41 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:56:41 --> Final output sent to browser
DEBUG - 2017-02-06 06:56:41 --> Total execution time: 0.0448
INFO - 2017-02-06 06:56:41 --> Config Class Initialized
INFO - 2017-02-06 06:56:41 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:56:41 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:56:41 --> Utf8 Class Initialized
INFO - 2017-02-06 06:56:41 --> URI Class Initialized
INFO - 2017-02-06 06:56:41 --> Router Class Initialized
INFO - 2017-02-06 06:56:41 --> Output Class Initialized
INFO - 2017-02-06 06:56:41 --> Security Class Initialized
DEBUG - 2017-02-06 06:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:56:41 --> Input Class Initialized
INFO - 2017-02-06 06:56:41 --> Language Class Initialized
ERROR - 2017-02-06 06:56:41 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:56:42 --> Config Class Initialized
INFO - 2017-02-06 06:56:42 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:56:42 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:56:42 --> Utf8 Class Initialized
INFO - 2017-02-06 06:56:42 --> URI Class Initialized
INFO - 2017-02-06 06:56:42 --> Router Class Initialized
INFO - 2017-02-06 06:56:42 --> Output Class Initialized
INFO - 2017-02-06 06:56:42 --> Security Class Initialized
DEBUG - 2017-02-06 06:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:56:42 --> Input Class Initialized
INFO - 2017-02-06 06:56:42 --> Language Class Initialized
ERROR - 2017-02-06 06:56:42 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:56:42 --> Config Class Initialized
INFO - 2017-02-06 06:56:42 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:56:42 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:56:42 --> Utf8 Class Initialized
INFO - 2017-02-06 06:56:42 --> URI Class Initialized
INFO - 2017-02-06 06:56:42 --> Router Class Initialized
INFO - 2017-02-06 06:56:42 --> Output Class Initialized
INFO - 2017-02-06 06:56:42 --> Security Class Initialized
DEBUG - 2017-02-06 06:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:56:42 --> Input Class Initialized
INFO - 2017-02-06 06:56:42 --> Language Class Initialized
ERROR - 2017-02-06 06:56:42 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:56:59 --> Config Class Initialized
INFO - 2017-02-06 06:56:59 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:56:59 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:56:59 --> Utf8 Class Initialized
INFO - 2017-02-06 06:56:59 --> URI Class Initialized
INFO - 2017-02-06 06:56:59 --> Router Class Initialized
INFO - 2017-02-06 06:56:59 --> Output Class Initialized
INFO - 2017-02-06 06:56:59 --> Security Class Initialized
DEBUG - 2017-02-06 06:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:56:59 --> Input Class Initialized
INFO - 2017-02-06 06:56:59 --> Language Class Initialized
INFO - 2017-02-06 06:56:59 --> Language Class Initialized
INFO - 2017-02-06 06:56:59 --> Config Class Initialized
INFO - 2017-02-06 06:56:59 --> Loader Class Initialized
INFO - 2017-02-06 06:56:59 --> Helper loaded: form_helper
INFO - 2017-02-06 06:56:59 --> Helper loaded: url_helper
INFO - 2017-02-06 06:56:59 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:56:59 --> Database Driver Class Initialized
INFO - 2017-02-06 06:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:56:59 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:56:59 --> Template Class Initialized
INFO - 2017-02-06 06:56:59 --> Controller Class Initialized
DEBUG - 2017-02-06 06:56:59 --> Login MX_Controller Initialized
INFO - 2017-02-06 06:56:59 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 06:56:59 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 06:56:59 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:56:59 --> Final output sent to browser
DEBUG - 2017-02-06 06:56:59 --> Total execution time: 0.0516
INFO - 2017-02-06 06:56:59 --> Config Class Initialized
INFO - 2017-02-06 06:56:59 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:56:59 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:56:59 --> Utf8 Class Initialized
INFO - 2017-02-06 06:56:59 --> URI Class Initialized
INFO - 2017-02-06 06:56:59 --> Router Class Initialized
INFO - 2017-02-06 06:56:59 --> Output Class Initialized
INFO - 2017-02-06 06:56:59 --> Security Class Initialized
DEBUG - 2017-02-06 06:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:56:59 --> Input Class Initialized
INFO - 2017-02-06 06:56:59 --> Language Class Initialized
ERROR - 2017-02-06 06:56:59 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:56:59 --> Config Class Initialized
INFO - 2017-02-06 06:56:59 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:56:59 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:56:59 --> Utf8 Class Initialized
INFO - 2017-02-06 06:56:59 --> URI Class Initialized
INFO - 2017-02-06 06:56:59 --> Router Class Initialized
INFO - 2017-02-06 06:56:59 --> Output Class Initialized
INFO - 2017-02-06 06:56:59 --> Security Class Initialized
DEBUG - 2017-02-06 06:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:56:59 --> Input Class Initialized
INFO - 2017-02-06 06:56:59 --> Language Class Initialized
ERROR - 2017-02-06 06:56:59 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:56:59 --> Config Class Initialized
INFO - 2017-02-06 06:56:59 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:56:59 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:56:59 --> Utf8 Class Initialized
INFO - 2017-02-06 06:56:59 --> URI Class Initialized
INFO - 2017-02-06 06:56:59 --> Router Class Initialized
INFO - 2017-02-06 06:56:59 --> Output Class Initialized
INFO - 2017-02-06 06:56:59 --> Security Class Initialized
DEBUG - 2017-02-06 06:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:56:59 --> Input Class Initialized
INFO - 2017-02-06 06:56:59 --> Language Class Initialized
ERROR - 2017-02-06 06:56:59 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:56:59 --> Config Class Initialized
INFO - 2017-02-06 06:56:59 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:56:59 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:56:59 --> Utf8 Class Initialized
INFO - 2017-02-06 06:56:59 --> URI Class Initialized
INFO - 2017-02-06 06:56:59 --> Router Class Initialized
INFO - 2017-02-06 06:56:59 --> Output Class Initialized
INFO - 2017-02-06 06:56:59 --> Security Class Initialized
DEBUG - 2017-02-06 06:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:56:59 --> Input Class Initialized
INFO - 2017-02-06 06:56:59 --> Language Class Initialized
ERROR - 2017-02-06 06:56:59 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:57:00 --> Config Class Initialized
INFO - 2017-02-06 06:57:00 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:57:00 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:57:00 --> Utf8 Class Initialized
INFO - 2017-02-06 06:57:00 --> URI Class Initialized
INFO - 2017-02-06 06:57:00 --> Router Class Initialized
INFO - 2017-02-06 06:57:00 --> Output Class Initialized
INFO - 2017-02-06 06:57:00 --> Security Class Initialized
DEBUG - 2017-02-06 06:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:57:00 --> Input Class Initialized
INFO - 2017-02-06 06:57:00 --> Language Class Initialized
INFO - 2017-02-06 06:57:00 --> Language Class Initialized
INFO - 2017-02-06 06:57:00 --> Config Class Initialized
INFO - 2017-02-06 06:57:00 --> Loader Class Initialized
INFO - 2017-02-06 06:57:00 --> Helper loaded: form_helper
INFO - 2017-02-06 06:57:00 --> Helper loaded: url_helper
INFO - 2017-02-06 06:57:00 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:57:00 --> Database Driver Class Initialized
INFO - 2017-02-06 06:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:57:00 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:57:00 --> Template Class Initialized
INFO - 2017-02-06 06:57:00 --> Controller Class Initialized
DEBUG - 2017-02-06 06:57:00 --> Login MX_Controller Initialized
INFO - 2017-02-06 06:57:00 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 06:57:00 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 06:57:00 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:57:00 --> Final output sent to browser
DEBUG - 2017-02-06 06:57:00 --> Total execution time: 0.0526
INFO - 2017-02-06 06:57:00 --> Config Class Initialized
INFO - 2017-02-06 06:57:00 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:57:00 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:57:00 --> Utf8 Class Initialized
INFO - 2017-02-06 06:57:00 --> URI Class Initialized
INFO - 2017-02-06 06:57:00 --> Router Class Initialized
INFO - 2017-02-06 06:57:00 --> Output Class Initialized
INFO - 2017-02-06 06:57:00 --> Security Class Initialized
DEBUG - 2017-02-06 06:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:57:00 --> Input Class Initialized
INFO - 2017-02-06 06:57:00 --> Language Class Initialized
ERROR - 2017-02-06 06:57:00 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:57:00 --> Config Class Initialized
INFO - 2017-02-06 06:57:00 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:57:00 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:57:00 --> Utf8 Class Initialized
INFO - 2017-02-06 06:57:00 --> URI Class Initialized
INFO - 2017-02-06 06:57:00 --> Router Class Initialized
INFO - 2017-02-06 06:57:00 --> Output Class Initialized
INFO - 2017-02-06 06:57:00 --> Security Class Initialized
DEBUG - 2017-02-06 06:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:57:00 --> Input Class Initialized
INFO - 2017-02-06 06:57:00 --> Language Class Initialized
ERROR - 2017-02-06 06:57:00 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:57:00 --> Config Class Initialized
INFO - 2017-02-06 06:57:00 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:57:00 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:57:00 --> Utf8 Class Initialized
INFO - 2017-02-06 06:57:00 --> URI Class Initialized
INFO - 2017-02-06 06:57:00 --> Router Class Initialized
INFO - 2017-02-06 06:57:00 --> Output Class Initialized
INFO - 2017-02-06 06:57:00 --> Security Class Initialized
DEBUG - 2017-02-06 06:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:57:00 --> Input Class Initialized
INFO - 2017-02-06 06:57:00 --> Language Class Initialized
ERROR - 2017-02-06 06:57:00 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:57:00 --> Config Class Initialized
INFO - 2017-02-06 06:57:00 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:57:00 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:57:00 --> Utf8 Class Initialized
INFO - 2017-02-06 06:57:00 --> URI Class Initialized
INFO - 2017-02-06 06:57:00 --> Router Class Initialized
INFO - 2017-02-06 06:57:00 --> Output Class Initialized
INFO - 2017-02-06 06:57:00 --> Security Class Initialized
DEBUG - 2017-02-06 06:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:57:00 --> Input Class Initialized
INFO - 2017-02-06 06:57:00 --> Language Class Initialized
ERROR - 2017-02-06 06:57:00 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:02 --> Config Class Initialized
INFO - 2017-02-06 06:58:02 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:02 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:02 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:02 --> URI Class Initialized
INFO - 2017-02-06 06:58:02 --> Router Class Initialized
INFO - 2017-02-06 06:58:02 --> Output Class Initialized
INFO - 2017-02-06 06:58:02 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:02 --> Input Class Initialized
INFO - 2017-02-06 06:58:02 --> Language Class Initialized
INFO - 2017-02-06 06:58:02 --> Language Class Initialized
INFO - 2017-02-06 06:58:02 --> Config Class Initialized
INFO - 2017-02-06 06:58:02 --> Loader Class Initialized
INFO - 2017-02-06 06:58:02 --> Helper loaded: form_helper
INFO - 2017-02-06 06:58:02 --> Helper loaded: url_helper
INFO - 2017-02-06 06:58:02 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:58:02 --> Database Driver Class Initialized
INFO - 2017-02-06 06:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:58:02 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:58:02 --> Template Class Initialized
INFO - 2017-02-06 06:58:02 --> Controller Class Initialized
DEBUG - 2017-02-06 06:58:02 --> Login MX_Controller Initialized
INFO - 2017-02-06 06:58:02 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 06:58:02 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 06:58:02 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:58:02 --> Final output sent to browser
DEBUG - 2017-02-06 06:58:02 --> Total execution time: 0.0533
INFO - 2017-02-06 06:58:02 --> Config Class Initialized
INFO - 2017-02-06 06:58:02 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:02 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:02 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:02 --> URI Class Initialized
INFO - 2017-02-06 06:58:02 --> Router Class Initialized
INFO - 2017-02-06 06:58:02 --> Output Class Initialized
INFO - 2017-02-06 06:58:02 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:02 --> Input Class Initialized
INFO - 2017-02-06 06:58:02 --> Language Class Initialized
ERROR - 2017-02-06 06:58:02 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:02 --> Config Class Initialized
INFO - 2017-02-06 06:58:02 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:02 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:02 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:02 --> URI Class Initialized
INFO - 2017-02-06 06:58:02 --> Router Class Initialized
INFO - 2017-02-06 06:58:02 --> Output Class Initialized
INFO - 2017-02-06 06:58:02 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:02 --> Input Class Initialized
INFO - 2017-02-06 06:58:02 --> Language Class Initialized
ERROR - 2017-02-06 06:58:02 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:02 --> Config Class Initialized
INFO - 2017-02-06 06:58:02 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:02 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:02 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:02 --> URI Class Initialized
INFO - 2017-02-06 06:58:02 --> Router Class Initialized
INFO - 2017-02-06 06:58:02 --> Output Class Initialized
INFO - 2017-02-06 06:58:02 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:02 --> Input Class Initialized
INFO - 2017-02-06 06:58:02 --> Language Class Initialized
ERROR - 2017-02-06 06:58:02 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:02 --> Config Class Initialized
INFO - 2017-02-06 06:58:02 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:02 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:02 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:02 --> URI Class Initialized
INFO - 2017-02-06 06:58:02 --> Router Class Initialized
INFO - 2017-02-06 06:58:02 --> Output Class Initialized
INFO - 2017-02-06 06:58:02 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:02 --> Input Class Initialized
INFO - 2017-02-06 06:58:02 --> Language Class Initialized
ERROR - 2017-02-06 06:58:02 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:04 --> Config Class Initialized
INFO - 2017-02-06 06:58:04 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:04 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:04 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:04 --> URI Class Initialized
INFO - 2017-02-06 06:58:04 --> Router Class Initialized
INFO - 2017-02-06 06:58:04 --> Output Class Initialized
INFO - 2017-02-06 06:58:04 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:04 --> Input Class Initialized
INFO - 2017-02-06 06:58:04 --> Language Class Initialized
INFO - 2017-02-06 06:58:04 --> Language Class Initialized
INFO - 2017-02-06 06:58:04 --> Config Class Initialized
INFO - 2017-02-06 06:58:04 --> Loader Class Initialized
INFO - 2017-02-06 06:58:04 --> Helper loaded: form_helper
INFO - 2017-02-06 06:58:04 --> Helper loaded: url_helper
INFO - 2017-02-06 06:58:04 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:58:04 --> Database Driver Class Initialized
INFO - 2017-02-06 06:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:58:04 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:58:04 --> Template Class Initialized
INFO - 2017-02-06 06:58:04 --> Controller Class Initialized
DEBUG - 2017-02-06 06:58:04 --> Login MX_Controller Initialized
INFO - 2017-02-06 06:58:04 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 06:58:04 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 06:58:04 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:58:04 --> Final output sent to browser
DEBUG - 2017-02-06 06:58:04 --> Total execution time: 0.0787
INFO - 2017-02-06 06:58:04 --> Config Class Initialized
INFO - 2017-02-06 06:58:04 --> Hooks Class Initialized
INFO - 2017-02-06 06:58:04 --> Config Class Initialized
INFO - 2017-02-06 06:58:04 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:04 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:04 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:04 --> URI Class Initialized
DEBUG - 2017-02-06 06:58:04 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:04 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:04 --> URI Class Initialized
INFO - 2017-02-06 06:58:04 --> Router Class Initialized
INFO - 2017-02-06 06:58:04 --> Output Class Initialized
INFO - 2017-02-06 06:58:04 --> Router Class Initialized
INFO - 2017-02-06 06:58:04 --> Security Class Initialized
INFO - 2017-02-06 06:58:04 --> Output Class Initialized
INFO - 2017-02-06 06:58:04 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:04 --> Input Class Initialized
DEBUG - 2017-02-06 06:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:04 --> Language Class Initialized
INFO - 2017-02-06 06:58:04 --> Input Class Initialized
ERROR - 2017-02-06 06:58:04 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:04 --> Language Class Initialized
ERROR - 2017-02-06 06:58:04 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:04 --> Config Class Initialized
INFO - 2017-02-06 06:58:04 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:04 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:04 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:04 --> URI Class Initialized
INFO - 2017-02-06 06:58:04 --> Router Class Initialized
INFO - 2017-02-06 06:58:04 --> Output Class Initialized
INFO - 2017-02-06 06:58:04 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:04 --> Input Class Initialized
INFO - 2017-02-06 06:58:04 --> Language Class Initialized
ERROR - 2017-02-06 06:58:04 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:04 --> Config Class Initialized
INFO - 2017-02-06 06:58:04 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:04 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:04 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:04 --> URI Class Initialized
INFO - 2017-02-06 06:58:04 --> Router Class Initialized
INFO - 2017-02-06 06:58:04 --> Output Class Initialized
INFO - 2017-02-06 06:58:04 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:04 --> Input Class Initialized
INFO - 2017-02-06 06:58:04 --> Language Class Initialized
ERROR - 2017-02-06 06:58:04 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:21 --> Config Class Initialized
INFO - 2017-02-06 06:58:21 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:21 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:21 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:21 --> URI Class Initialized
INFO - 2017-02-06 06:58:21 --> Router Class Initialized
INFO - 2017-02-06 06:58:21 --> Output Class Initialized
INFO - 2017-02-06 06:58:21 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:21 --> Input Class Initialized
INFO - 2017-02-06 06:58:21 --> Language Class Initialized
INFO - 2017-02-06 06:58:21 --> Language Class Initialized
INFO - 2017-02-06 06:58:21 --> Config Class Initialized
INFO - 2017-02-06 06:58:21 --> Loader Class Initialized
INFO - 2017-02-06 06:58:21 --> Helper loaded: form_helper
INFO - 2017-02-06 06:58:21 --> Helper loaded: url_helper
INFO - 2017-02-06 06:58:22 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:58:22 --> Database Driver Class Initialized
INFO - 2017-02-06 06:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:58:22 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:58:22 --> Template Class Initialized
INFO - 2017-02-06 06:58:22 --> Controller Class Initialized
DEBUG - 2017-02-06 06:58:22 --> Login MX_Controller Initialized
INFO - 2017-02-06 06:58:22 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 06:58:22 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 06:58:22 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:58:22 --> Final output sent to browser
DEBUG - 2017-02-06 06:58:22 --> Total execution time: 0.0823
INFO - 2017-02-06 06:58:22 --> Config Class Initialized
INFO - 2017-02-06 06:58:22 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:22 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:22 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:22 --> URI Class Initialized
INFO - 2017-02-06 06:58:22 --> Router Class Initialized
INFO - 2017-02-06 06:58:22 --> Output Class Initialized
INFO - 2017-02-06 06:58:22 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:22 --> Input Class Initialized
INFO - 2017-02-06 06:58:22 --> Language Class Initialized
ERROR - 2017-02-06 06:58:22 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:22 --> Config Class Initialized
INFO - 2017-02-06 06:58:22 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:22 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:22 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:22 --> URI Class Initialized
INFO - 2017-02-06 06:58:22 --> Router Class Initialized
INFO - 2017-02-06 06:58:22 --> Output Class Initialized
INFO - 2017-02-06 06:58:22 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:22 --> Input Class Initialized
INFO - 2017-02-06 06:58:22 --> Language Class Initialized
ERROR - 2017-02-06 06:58:22 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:22 --> Config Class Initialized
INFO - 2017-02-06 06:58:22 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:22 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:22 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:22 --> URI Class Initialized
INFO - 2017-02-06 06:58:22 --> Router Class Initialized
INFO - 2017-02-06 06:58:22 --> Output Class Initialized
INFO - 2017-02-06 06:58:22 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:22 --> Input Class Initialized
INFO - 2017-02-06 06:58:22 --> Language Class Initialized
ERROR - 2017-02-06 06:58:22 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:22 --> Config Class Initialized
INFO - 2017-02-06 06:58:22 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:22 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:22 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:22 --> URI Class Initialized
INFO - 2017-02-06 06:58:22 --> Router Class Initialized
INFO - 2017-02-06 06:58:22 --> Output Class Initialized
INFO - 2017-02-06 06:58:22 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:22 --> Input Class Initialized
INFO - 2017-02-06 06:58:22 --> Language Class Initialized
ERROR - 2017-02-06 06:58:22 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:35 --> Config Class Initialized
INFO - 2017-02-06 06:58:35 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:35 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:35 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:35 --> URI Class Initialized
INFO - 2017-02-06 06:58:35 --> Router Class Initialized
INFO - 2017-02-06 06:58:35 --> Output Class Initialized
INFO - 2017-02-06 06:58:35 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:35 --> Input Class Initialized
INFO - 2017-02-06 06:58:35 --> Language Class Initialized
INFO - 2017-02-06 06:58:35 --> Language Class Initialized
INFO - 2017-02-06 06:58:35 --> Config Class Initialized
INFO - 2017-02-06 06:58:35 --> Loader Class Initialized
INFO - 2017-02-06 06:58:35 --> Helper loaded: form_helper
INFO - 2017-02-06 06:58:35 --> Helper loaded: url_helper
INFO - 2017-02-06 06:58:35 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:58:35 --> Database Driver Class Initialized
INFO - 2017-02-06 06:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:58:35 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:58:35 --> Template Class Initialized
INFO - 2017-02-06 06:58:35 --> Controller Class Initialized
DEBUG - 2017-02-06 06:58:35 --> Login MX_Controller Initialized
INFO - 2017-02-06 06:58:35 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 06:58:35 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 06:58:35 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:58:35 --> Final output sent to browser
DEBUG - 2017-02-06 06:58:35 --> Total execution time: 0.0653
INFO - 2017-02-06 06:58:35 --> Config Class Initialized
INFO - 2017-02-06 06:58:35 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:35 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:35 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:35 --> URI Class Initialized
INFO - 2017-02-06 06:58:35 --> Router Class Initialized
INFO - 2017-02-06 06:58:35 --> Output Class Initialized
INFO - 2017-02-06 06:58:35 --> Security Class Initialized
INFO - 2017-02-06 06:58:35 --> Config Class Initialized
INFO - 2017-02-06 06:58:35 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:35 --> Input Class Initialized
INFO - 2017-02-06 06:58:35 --> Language Class Initialized
ERROR - 2017-02-06 06:58:35 --> 404 Page Not Found: /index
DEBUG - 2017-02-06 06:58:35 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:35 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:35 --> URI Class Initialized
INFO - 2017-02-06 06:58:35 --> Router Class Initialized
INFO - 2017-02-06 06:58:35 --> Output Class Initialized
INFO - 2017-02-06 06:58:35 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:35 --> Input Class Initialized
INFO - 2017-02-06 06:58:35 --> Language Class Initialized
ERROR - 2017-02-06 06:58:35 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:36 --> Config Class Initialized
INFO - 2017-02-06 06:58:36 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:36 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:36 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:36 --> URI Class Initialized
INFO - 2017-02-06 06:58:36 --> Router Class Initialized
INFO - 2017-02-06 06:58:36 --> Output Class Initialized
INFO - 2017-02-06 06:58:36 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:36 --> Input Class Initialized
INFO - 2017-02-06 06:58:36 --> Language Class Initialized
INFO - 2017-02-06 06:58:36 --> Language Class Initialized
INFO - 2017-02-06 06:58:36 --> Config Class Initialized
INFO - 2017-02-06 06:58:36 --> Loader Class Initialized
INFO - 2017-02-06 06:58:36 --> Helper loaded: form_helper
INFO - 2017-02-06 06:58:36 --> Helper loaded: url_helper
INFO - 2017-02-06 06:58:36 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:58:36 --> Database Driver Class Initialized
INFO - 2017-02-06 06:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:58:36 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:58:36 --> Template Class Initialized
INFO - 2017-02-06 06:58:36 --> Controller Class Initialized
DEBUG - 2017-02-06 06:58:36 --> Login MX_Controller Initialized
INFO - 2017-02-06 06:58:36 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 06:58:36 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 06:58:36 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:58:36 --> Final output sent to browser
DEBUG - 2017-02-06 06:58:36 --> Total execution time: 0.0639
INFO - 2017-02-06 06:58:36 --> Config Class Initialized
INFO - 2017-02-06 06:58:36 --> Hooks Class Initialized
INFO - 2017-02-06 06:58:36 --> Config Class Initialized
INFO - 2017-02-06 06:58:36 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:36 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:36 --> Utf8 Class Initialized
DEBUG - 2017-02-06 06:58:36 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:36 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:36 --> URI Class Initialized
INFO - 2017-02-06 06:58:36 --> URI Class Initialized
INFO - 2017-02-06 06:58:36 --> Router Class Initialized
INFO - 2017-02-06 06:58:36 --> Router Class Initialized
INFO - 2017-02-06 06:58:36 --> Output Class Initialized
INFO - 2017-02-06 06:58:36 --> Output Class Initialized
INFO - 2017-02-06 06:58:36 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:36 --> Security Class Initialized
INFO - 2017-02-06 06:58:36 --> Input Class Initialized
INFO - 2017-02-06 06:58:36 --> Language Class Initialized
DEBUG - 2017-02-06 06:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:36 --> Input Class Initialized
ERROR - 2017-02-06 06:58:36 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:36 --> Language Class Initialized
ERROR - 2017-02-06 06:58:36 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:40 --> Config Class Initialized
INFO - 2017-02-06 06:58:40 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:40 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:40 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:40 --> URI Class Initialized
INFO - 2017-02-06 06:58:40 --> Router Class Initialized
INFO - 2017-02-06 06:58:40 --> Output Class Initialized
INFO - 2017-02-06 06:58:40 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:40 --> Input Class Initialized
INFO - 2017-02-06 06:58:40 --> Language Class Initialized
INFO - 2017-02-06 06:58:40 --> Language Class Initialized
INFO - 2017-02-06 06:58:40 --> Config Class Initialized
INFO - 2017-02-06 06:58:40 --> Loader Class Initialized
INFO - 2017-02-06 06:58:40 --> Helper loaded: form_helper
INFO - 2017-02-06 06:58:40 --> Helper loaded: url_helper
INFO - 2017-02-06 06:58:40 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:58:40 --> Database Driver Class Initialized
INFO - 2017-02-06 06:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:58:40 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:58:40 --> Template Class Initialized
INFO - 2017-02-06 06:58:40 --> Controller Class Initialized
DEBUG - 2017-02-06 06:58:40 --> Login MX_Controller Initialized
INFO - 2017-02-06 06:58:40 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 06:58:40 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 06:58:40 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:58:40 --> Final output sent to browser
DEBUG - 2017-02-06 06:58:40 --> Total execution time: 0.0387
INFO - 2017-02-06 06:58:57 --> Config Class Initialized
INFO - 2017-02-06 06:58:57 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:57 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:57 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:57 --> URI Class Initialized
INFO - 2017-02-06 06:58:57 --> Router Class Initialized
INFO - 2017-02-06 06:58:57 --> Output Class Initialized
INFO - 2017-02-06 06:58:57 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:57 --> Input Class Initialized
INFO - 2017-02-06 06:58:57 --> Language Class Initialized
INFO - 2017-02-06 06:58:57 --> Language Class Initialized
INFO - 2017-02-06 06:58:57 --> Config Class Initialized
INFO - 2017-02-06 06:58:57 --> Loader Class Initialized
INFO - 2017-02-06 06:58:57 --> Helper loaded: form_helper
INFO - 2017-02-06 06:58:57 --> Helper loaded: url_helper
INFO - 2017-02-06 06:58:57 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:58:57 --> Database Driver Class Initialized
INFO - 2017-02-06 06:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:58:57 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:58:57 --> Template Class Initialized
INFO - 2017-02-06 06:58:57 --> Controller Class Initialized
DEBUG - 2017-02-06 06:58:57 --> Login MX_Controller Initialized
INFO - 2017-02-06 06:58:57 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 06:58:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 06:58:57 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:58:57 --> Final output sent to browser
DEBUG - 2017-02-06 06:58:57 --> Total execution time: 0.0520
INFO - 2017-02-06 06:58:57 --> Config Class Initialized
INFO - 2017-02-06 06:58:57 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:57 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:57 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:57 --> URI Class Initialized
INFO - 2017-02-06 06:58:57 --> Config Class Initialized
INFO - 2017-02-06 06:58:57 --> Hooks Class Initialized
INFO - 2017-02-06 06:58:57 --> Router Class Initialized
INFO - 2017-02-06 06:58:57 --> Output Class Initialized
INFO - 2017-02-06 06:58:57 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:57 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:57 --> Utf8 Class Initialized
DEBUG - 2017-02-06 06:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:57 --> Input Class Initialized
INFO - 2017-02-06 06:58:57 --> URI Class Initialized
INFO - 2017-02-06 06:58:57 --> Language Class Initialized
ERROR - 2017-02-06 06:58:57 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:57 --> Router Class Initialized
INFO - 2017-02-06 06:58:57 --> Output Class Initialized
INFO - 2017-02-06 06:58:57 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:57 --> Input Class Initialized
INFO - 2017-02-06 06:58:57 --> Language Class Initialized
ERROR - 2017-02-06 06:58:57 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:58 --> Config Class Initialized
INFO - 2017-02-06 06:58:58 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:58 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:58 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:58 --> URI Class Initialized
INFO - 2017-02-06 06:58:58 --> Router Class Initialized
INFO - 2017-02-06 06:58:58 --> Output Class Initialized
INFO - 2017-02-06 06:58:58 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:58 --> Input Class Initialized
INFO - 2017-02-06 06:58:58 --> Language Class Initialized
INFO - 2017-02-06 06:58:58 --> Language Class Initialized
INFO - 2017-02-06 06:58:58 --> Config Class Initialized
INFO - 2017-02-06 06:58:58 --> Loader Class Initialized
INFO - 2017-02-06 06:58:58 --> Helper loaded: form_helper
INFO - 2017-02-06 06:58:58 --> Helper loaded: url_helper
INFO - 2017-02-06 06:58:58 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:58:58 --> Database Driver Class Initialized
INFO - 2017-02-06 06:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:58:58 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:58:58 --> Template Class Initialized
INFO - 2017-02-06 06:58:58 --> Controller Class Initialized
DEBUG - 2017-02-06 06:58:58 --> Login MX_Controller Initialized
INFO - 2017-02-06 06:58:58 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 06:58:58 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 06:58:58 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:58:58 --> Final output sent to browser
DEBUG - 2017-02-06 06:58:58 --> Total execution time: 0.0704
INFO - 2017-02-06 06:58:58 --> Config Class Initialized
INFO - 2017-02-06 06:58:58 --> Hooks Class Initialized
INFO - 2017-02-06 06:58:58 --> Config Class Initialized
INFO - 2017-02-06 06:58:58 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:58:58 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:58 --> Utf8 Class Initialized
DEBUG - 2017-02-06 06:58:58 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:58:58 --> URI Class Initialized
INFO - 2017-02-06 06:58:58 --> Utf8 Class Initialized
INFO - 2017-02-06 06:58:58 --> URI Class Initialized
INFO - 2017-02-06 06:58:58 --> Router Class Initialized
INFO - 2017-02-06 06:58:58 --> Router Class Initialized
INFO - 2017-02-06 06:58:58 --> Output Class Initialized
INFO - 2017-02-06 06:58:58 --> Output Class Initialized
INFO - 2017-02-06 06:58:58 --> Security Class Initialized
INFO - 2017-02-06 06:58:58 --> Security Class Initialized
DEBUG - 2017-02-06 06:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:58 --> Input Class Initialized
INFO - 2017-02-06 06:58:58 --> Language Class Initialized
DEBUG - 2017-02-06 06:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:58:58 --> Input Class Initialized
ERROR - 2017-02-06 06:58:58 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:58:58 --> Language Class Initialized
ERROR - 2017-02-06 06:58:58 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:59:50 --> Config Class Initialized
INFO - 2017-02-06 06:59:50 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:59:50 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:59:50 --> Utf8 Class Initialized
INFO - 2017-02-06 06:59:50 --> URI Class Initialized
INFO - 2017-02-06 06:59:50 --> Router Class Initialized
INFO - 2017-02-06 06:59:50 --> Output Class Initialized
INFO - 2017-02-06 06:59:50 --> Security Class Initialized
DEBUG - 2017-02-06 06:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:59:50 --> Input Class Initialized
INFO - 2017-02-06 06:59:50 --> Language Class Initialized
INFO - 2017-02-06 06:59:50 --> Language Class Initialized
INFO - 2017-02-06 06:59:50 --> Config Class Initialized
INFO - 2017-02-06 06:59:50 --> Loader Class Initialized
INFO - 2017-02-06 06:59:50 --> Helper loaded: form_helper
INFO - 2017-02-06 06:59:50 --> Helper loaded: url_helper
INFO - 2017-02-06 06:59:50 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:59:50 --> Database Driver Class Initialized
INFO - 2017-02-06 06:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:59:50 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:59:50 --> Template Class Initialized
INFO - 2017-02-06 06:59:50 --> Controller Class Initialized
DEBUG - 2017-02-06 06:59:50 --> Login MX_Controller Initialized
INFO - 2017-02-06 06:59:50 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 06:59:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 06:59:50 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:59:50 --> Final output sent to browser
DEBUG - 2017-02-06 06:59:50 --> Total execution time: 0.0742
INFO - 2017-02-06 06:59:50 --> Config Class Initialized
INFO - 2017-02-06 06:59:50 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:59:50 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:59:50 --> Utf8 Class Initialized
INFO - 2017-02-06 06:59:50 --> URI Class Initialized
INFO - 2017-02-06 06:59:50 --> Router Class Initialized
INFO - 2017-02-06 06:59:50 --> Output Class Initialized
INFO - 2017-02-06 06:59:50 --> Security Class Initialized
DEBUG - 2017-02-06 06:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:59:50 --> Input Class Initialized
INFO - 2017-02-06 06:59:50 --> Config Class Initialized
INFO - 2017-02-06 06:59:50 --> Language Class Initialized
INFO - 2017-02-06 06:59:50 --> Hooks Class Initialized
ERROR - 2017-02-06 06:59:50 --> 404 Page Not Found: /index
DEBUG - 2017-02-06 06:59:50 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:59:50 --> Utf8 Class Initialized
INFO - 2017-02-06 06:59:50 --> URI Class Initialized
INFO - 2017-02-06 06:59:50 --> Router Class Initialized
INFO - 2017-02-06 06:59:50 --> Output Class Initialized
INFO - 2017-02-06 06:59:50 --> Security Class Initialized
DEBUG - 2017-02-06 06:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:59:50 --> Input Class Initialized
INFO - 2017-02-06 06:59:50 --> Language Class Initialized
ERROR - 2017-02-06 06:59:50 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:59:51 --> Config Class Initialized
INFO - 2017-02-06 06:59:51 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:59:51 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:59:51 --> Utf8 Class Initialized
INFO - 2017-02-06 06:59:51 --> URI Class Initialized
INFO - 2017-02-06 06:59:51 --> Router Class Initialized
INFO - 2017-02-06 06:59:51 --> Output Class Initialized
INFO - 2017-02-06 06:59:51 --> Security Class Initialized
DEBUG - 2017-02-06 06:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:59:51 --> Input Class Initialized
INFO - 2017-02-06 06:59:51 --> Language Class Initialized
INFO - 2017-02-06 06:59:51 --> Language Class Initialized
INFO - 2017-02-06 06:59:51 --> Config Class Initialized
INFO - 2017-02-06 06:59:51 --> Loader Class Initialized
INFO - 2017-02-06 06:59:51 --> Helper loaded: form_helper
INFO - 2017-02-06 06:59:51 --> Helper loaded: url_helper
INFO - 2017-02-06 06:59:51 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:59:51 --> Database Driver Class Initialized
INFO - 2017-02-06 06:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:59:51 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:59:51 --> Template Class Initialized
INFO - 2017-02-06 06:59:51 --> Controller Class Initialized
DEBUG - 2017-02-06 06:59:51 --> Login MX_Controller Initialized
INFO - 2017-02-06 06:59:51 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 06:59:51 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 06:59:51 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:59:51 --> Final output sent to browser
DEBUG - 2017-02-06 06:59:51 --> Total execution time: 0.0805
INFO - 2017-02-06 06:59:51 --> Config Class Initialized
INFO - 2017-02-06 06:59:51 --> Hooks Class Initialized
INFO - 2017-02-06 06:59:51 --> Config Class Initialized
INFO - 2017-02-06 06:59:51 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:59:51 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:59:51 --> Utf8 Class Initialized
INFO - 2017-02-06 06:59:51 --> URI Class Initialized
DEBUG - 2017-02-06 06:59:51 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:59:51 --> Utf8 Class Initialized
INFO - 2017-02-06 06:59:51 --> URI Class Initialized
INFO - 2017-02-06 06:59:51 --> Router Class Initialized
INFO - 2017-02-06 06:59:51 --> Router Class Initialized
INFO - 2017-02-06 06:59:51 --> Output Class Initialized
INFO - 2017-02-06 06:59:51 --> Security Class Initialized
INFO - 2017-02-06 06:59:51 --> Output Class Initialized
DEBUG - 2017-02-06 06:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:59:51 --> Input Class Initialized
INFO - 2017-02-06 06:59:51 --> Security Class Initialized
INFO - 2017-02-06 06:59:51 --> Language Class Initialized
DEBUG - 2017-02-06 06:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:59:51 --> Input Class Initialized
ERROR - 2017-02-06 06:59:51 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:59:51 --> Language Class Initialized
ERROR - 2017-02-06 06:59:51 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:59:59 --> Config Class Initialized
INFO - 2017-02-06 06:59:59 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:59:59 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:59:59 --> Utf8 Class Initialized
INFO - 2017-02-06 06:59:59 --> URI Class Initialized
INFO - 2017-02-06 06:59:59 --> Router Class Initialized
INFO - 2017-02-06 06:59:59 --> Output Class Initialized
INFO - 2017-02-06 06:59:59 --> Security Class Initialized
DEBUG - 2017-02-06 06:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:59:59 --> Input Class Initialized
INFO - 2017-02-06 06:59:59 --> Language Class Initialized
INFO - 2017-02-06 06:59:59 --> Language Class Initialized
INFO - 2017-02-06 06:59:59 --> Config Class Initialized
INFO - 2017-02-06 06:59:59 --> Loader Class Initialized
INFO - 2017-02-06 06:59:59 --> Helper loaded: form_helper
INFO - 2017-02-06 06:59:59 --> Helper loaded: url_helper
INFO - 2017-02-06 06:59:59 --> Helper loaded: utility_helper
INFO - 2017-02-06 06:59:59 --> Database Driver Class Initialized
INFO - 2017-02-06 06:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 06:59:59 --> User Agent Class Initialized
DEBUG - 2017-02-06 06:59:59 --> Template Class Initialized
INFO - 2017-02-06 06:59:59 --> Controller Class Initialized
DEBUG - 2017-02-06 06:59:59 --> Login MX_Controller Initialized
INFO - 2017-02-06 06:59:59 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 06:59:59 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 06:59:59 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 06:59:59 --> Final output sent to browser
DEBUG - 2017-02-06 06:59:59 --> Total execution time: 0.0711
INFO - 2017-02-06 06:59:59 --> Config Class Initialized
INFO - 2017-02-06 06:59:59 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:59:59 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:59:59 --> Utf8 Class Initialized
INFO - 2017-02-06 06:59:59 --> URI Class Initialized
INFO - 2017-02-06 06:59:59 --> Router Class Initialized
INFO - 2017-02-06 06:59:59 --> Output Class Initialized
INFO - 2017-02-06 06:59:59 --> Config Class Initialized
INFO - 2017-02-06 06:59:59 --> Security Class Initialized
INFO - 2017-02-06 06:59:59 --> Hooks Class Initialized
DEBUG - 2017-02-06 06:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:59:59 --> Input Class Initialized
INFO - 2017-02-06 06:59:59 --> Language Class Initialized
DEBUG - 2017-02-06 06:59:59 --> UTF-8 Support Enabled
INFO - 2017-02-06 06:59:59 --> Utf8 Class Initialized
ERROR - 2017-02-06 06:59:59 --> 404 Page Not Found: /index
INFO - 2017-02-06 06:59:59 --> URI Class Initialized
INFO - 2017-02-06 06:59:59 --> Router Class Initialized
INFO - 2017-02-06 06:59:59 --> Output Class Initialized
INFO - 2017-02-06 06:59:59 --> Security Class Initialized
DEBUG - 2017-02-06 06:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 06:59:59 --> Input Class Initialized
INFO - 2017-02-06 06:59:59 --> Language Class Initialized
ERROR - 2017-02-06 06:59:59 --> 404 Page Not Found: /index
INFO - 2017-02-06 07:04:46 --> Config Class Initialized
INFO - 2017-02-06 07:04:46 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:04:46 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:04:46 --> Utf8 Class Initialized
INFO - 2017-02-06 07:04:46 --> URI Class Initialized
INFO - 2017-02-06 07:04:46 --> Router Class Initialized
INFO - 2017-02-06 07:04:46 --> Output Class Initialized
INFO - 2017-02-06 07:04:46 --> Security Class Initialized
DEBUG - 2017-02-06 07:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:04:46 --> Input Class Initialized
INFO - 2017-02-06 07:04:46 --> Language Class Initialized
INFO - 2017-02-06 07:04:46 --> Language Class Initialized
INFO - 2017-02-06 07:04:46 --> Config Class Initialized
INFO - 2017-02-06 07:04:46 --> Loader Class Initialized
INFO - 2017-02-06 07:04:46 --> Helper loaded: form_helper
INFO - 2017-02-06 07:04:46 --> Helper loaded: url_helper
INFO - 2017-02-06 07:04:46 --> Helper loaded: utility_helper
INFO - 2017-02-06 07:04:46 --> Database Driver Class Initialized
INFO - 2017-02-06 07:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 07:04:46 --> User Agent Class Initialized
DEBUG - 2017-02-06 07:04:46 --> Template Class Initialized
INFO - 2017-02-06 07:04:46 --> Controller Class Initialized
DEBUG - 2017-02-06 07:04:46 --> Login MX_Controller Initialized
INFO - 2017-02-06 07:04:46 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 07:04:46 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 07:04:46 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 07:04:46 --> Final output sent to browser
DEBUG - 2017-02-06 07:04:46 --> Total execution time: 0.0445
INFO - 2017-02-06 07:04:46 --> Config Class Initialized
INFO - 2017-02-06 07:04:46 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:04:46 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:04:46 --> Utf8 Class Initialized
INFO - 2017-02-06 07:04:46 --> URI Class Initialized
INFO - 2017-02-06 07:04:46 --> Router Class Initialized
INFO - 2017-02-06 07:04:46 --> Output Class Initialized
INFO - 2017-02-06 07:04:46 --> Security Class Initialized
DEBUG - 2017-02-06 07:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:04:46 --> Input Class Initialized
INFO - 2017-02-06 07:04:46 --> Language Class Initialized
ERROR - 2017-02-06 07:04:46 --> 404 Page Not Found: /index
INFO - 2017-02-06 07:04:48 --> Config Class Initialized
INFO - 2017-02-06 07:04:48 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:04:48 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:04:48 --> Utf8 Class Initialized
INFO - 2017-02-06 07:04:48 --> URI Class Initialized
INFO - 2017-02-06 07:04:48 --> Router Class Initialized
INFO - 2017-02-06 07:04:48 --> Output Class Initialized
INFO - 2017-02-06 07:04:48 --> Security Class Initialized
DEBUG - 2017-02-06 07:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:04:48 --> Input Class Initialized
INFO - 2017-02-06 07:04:48 --> Language Class Initialized
INFO - 2017-02-06 07:04:48 --> Language Class Initialized
INFO - 2017-02-06 07:04:48 --> Config Class Initialized
INFO - 2017-02-06 07:04:48 --> Loader Class Initialized
INFO - 2017-02-06 07:04:48 --> Helper loaded: form_helper
INFO - 2017-02-06 07:04:48 --> Helper loaded: url_helper
INFO - 2017-02-06 07:04:48 --> Helper loaded: utility_helper
INFO - 2017-02-06 07:04:48 --> Database Driver Class Initialized
INFO - 2017-02-06 07:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 07:04:48 --> User Agent Class Initialized
DEBUG - 2017-02-06 07:04:48 --> Template Class Initialized
INFO - 2017-02-06 07:04:48 --> Controller Class Initialized
DEBUG - 2017-02-06 07:04:48 --> Login MX_Controller Initialized
INFO - 2017-02-06 07:04:48 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 07:04:48 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 07:04:48 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 07:04:48 --> Final output sent to browser
DEBUG - 2017-02-06 07:04:48 --> Total execution time: 0.0642
INFO - 2017-02-06 07:04:48 --> Config Class Initialized
INFO - 2017-02-06 07:04:48 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:04:48 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:04:48 --> Utf8 Class Initialized
INFO - 2017-02-06 07:04:48 --> URI Class Initialized
INFO - 2017-02-06 07:04:48 --> Router Class Initialized
INFO - 2017-02-06 07:04:48 --> Output Class Initialized
INFO - 2017-02-06 07:04:48 --> Security Class Initialized
DEBUG - 2017-02-06 07:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:04:48 --> Input Class Initialized
INFO - 2017-02-06 07:04:48 --> Language Class Initialized
ERROR - 2017-02-06 07:04:48 --> 404 Page Not Found: /index
INFO - 2017-02-06 07:05:05 --> Config Class Initialized
INFO - 2017-02-06 07:05:05 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:05:05 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:05:05 --> Utf8 Class Initialized
INFO - 2017-02-06 07:05:05 --> URI Class Initialized
INFO - 2017-02-06 07:05:05 --> Router Class Initialized
INFO - 2017-02-06 07:05:05 --> Output Class Initialized
INFO - 2017-02-06 07:05:05 --> Security Class Initialized
DEBUG - 2017-02-06 07:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:05:05 --> Input Class Initialized
INFO - 2017-02-06 07:05:05 --> Language Class Initialized
INFO - 2017-02-06 07:05:05 --> Language Class Initialized
INFO - 2017-02-06 07:05:05 --> Config Class Initialized
INFO - 2017-02-06 07:05:05 --> Loader Class Initialized
INFO - 2017-02-06 07:05:05 --> Helper loaded: form_helper
INFO - 2017-02-06 07:05:05 --> Helper loaded: url_helper
INFO - 2017-02-06 07:05:05 --> Helper loaded: utility_helper
INFO - 2017-02-06 07:05:05 --> Database Driver Class Initialized
INFO - 2017-02-06 07:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 07:05:05 --> User Agent Class Initialized
DEBUG - 2017-02-06 07:05:05 --> Template Class Initialized
INFO - 2017-02-06 07:05:05 --> Controller Class Initialized
DEBUG - 2017-02-06 07:05:05 --> Login MX_Controller Initialized
INFO - 2017-02-06 07:05:05 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 07:05:05 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 07:05:05 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 07:05:05 --> Final output sent to browser
DEBUG - 2017-02-06 07:05:05 --> Total execution time: 0.0326
INFO - 2017-02-06 07:05:06 --> Config Class Initialized
INFO - 2017-02-06 07:05:06 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:05:06 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:05:06 --> Utf8 Class Initialized
INFO - 2017-02-06 07:05:06 --> URI Class Initialized
INFO - 2017-02-06 07:05:06 --> Router Class Initialized
INFO - 2017-02-06 07:05:06 --> Output Class Initialized
INFO - 2017-02-06 07:05:06 --> Security Class Initialized
DEBUG - 2017-02-06 07:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:05:06 --> Input Class Initialized
INFO - 2017-02-06 07:05:06 --> Language Class Initialized
ERROR - 2017-02-06 07:05:06 --> 404 Page Not Found: /index
INFO - 2017-02-06 07:24:48 --> Config Class Initialized
INFO - 2017-02-06 07:24:48 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:24:48 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:24:48 --> Utf8 Class Initialized
INFO - 2017-02-06 07:24:48 --> URI Class Initialized
INFO - 2017-02-06 07:24:48 --> Router Class Initialized
INFO - 2017-02-06 07:24:48 --> Output Class Initialized
INFO - 2017-02-06 07:24:48 --> Security Class Initialized
DEBUG - 2017-02-06 07:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:24:48 --> Input Class Initialized
INFO - 2017-02-06 07:24:48 --> Language Class Initialized
INFO - 2017-02-06 07:24:48 --> Language Class Initialized
INFO - 2017-02-06 07:24:48 --> Config Class Initialized
INFO - 2017-02-06 07:24:48 --> Loader Class Initialized
INFO - 2017-02-06 07:24:48 --> Helper loaded: form_helper
INFO - 2017-02-06 07:24:48 --> Helper loaded: url_helper
INFO - 2017-02-06 07:24:48 --> Helper loaded: utility_helper
INFO - 2017-02-06 07:24:48 --> Database Driver Class Initialized
INFO - 2017-02-06 07:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 07:24:48 --> User Agent Class Initialized
DEBUG - 2017-02-06 07:24:48 --> Template Class Initialized
INFO - 2017-02-06 07:24:48 --> Controller Class Initialized
DEBUG - 2017-02-06 07:24:48 --> Login MX_Controller Initialized
INFO - 2017-02-06 07:24:48 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 07:24:48 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/login.php
DEBUG - 2017-02-06 07:24:48 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 07:24:48 --> Final output sent to browser
DEBUG - 2017-02-06 07:24:48 --> Total execution time: 0.0394
INFO - 2017-02-06 07:24:49 --> Config Class Initialized
INFO - 2017-02-06 07:24:49 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:24:49 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:24:49 --> Utf8 Class Initialized
INFO - 2017-02-06 07:24:49 --> URI Class Initialized
DEBUG - 2017-02-06 07:24:49 --> No URI present. Default controller set.
INFO - 2017-02-06 07:24:49 --> Router Class Initialized
INFO - 2017-02-06 07:24:49 --> Output Class Initialized
INFO - 2017-02-06 07:24:49 --> Security Class Initialized
DEBUG - 2017-02-06 07:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:24:49 --> Input Class Initialized
INFO - 2017-02-06 07:24:49 --> Language Class Initialized
INFO - 2017-02-06 07:24:49 --> Language Class Initialized
INFO - 2017-02-06 07:24:49 --> Config Class Initialized
INFO - 2017-02-06 07:24:49 --> Loader Class Initialized
INFO - 2017-02-06 07:24:49 --> Helper loaded: form_helper
INFO - 2017-02-06 07:24:49 --> Helper loaded: url_helper
INFO - 2017-02-06 07:24:49 --> Helper loaded: utility_helper
INFO - 2017-02-06 07:24:49 --> Database Driver Class Initialized
INFO - 2017-02-06 07:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 07:24:49 --> User Agent Class Initialized
DEBUG - 2017-02-06 07:24:49 --> Template Class Initialized
INFO - 2017-02-06 07:24:49 --> Controller Class Initialized
INFO - 2017-02-06 07:24:49 --> Form Validation Class Initialized
DEBUG - 2017-02-06 07:24:49 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-06 07:24:49 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-06 07:24:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-06 07:24:50 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 07:24:50 --> Final output sent to browser
DEBUG - 2017-02-06 07:24:50 --> Total execution time: 0.1647
INFO - 2017-02-06 07:24:50 --> Config Class Initialized
INFO - 2017-02-06 07:24:50 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:24:50 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:24:50 --> Utf8 Class Initialized
INFO - 2017-02-06 07:24:50 --> URI Class Initialized
INFO - 2017-02-06 07:24:50 --> Router Class Initialized
INFO - 2017-02-06 07:24:50 --> Output Class Initialized
INFO - 2017-02-06 07:24:50 --> Security Class Initialized
DEBUG - 2017-02-06 07:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:24:50 --> Input Class Initialized
INFO - 2017-02-06 07:24:50 --> Language Class Initialized
ERROR - 2017-02-06 07:24:50 --> 404 Page Not Found: /index
INFO - 2017-02-06 07:24:54 --> Config Class Initialized
INFO - 2017-02-06 07:24:54 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:24:54 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:24:54 --> Utf8 Class Initialized
INFO - 2017-02-06 07:24:54 --> URI Class Initialized
INFO - 2017-02-06 07:24:54 --> Router Class Initialized
INFO - 2017-02-06 07:24:54 --> Output Class Initialized
INFO - 2017-02-06 07:24:54 --> Security Class Initialized
DEBUG - 2017-02-06 07:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:24:54 --> Input Class Initialized
INFO - 2017-02-06 07:24:54 --> Language Class Initialized
INFO - 2017-02-06 07:24:54 --> Language Class Initialized
INFO - 2017-02-06 07:24:54 --> Config Class Initialized
INFO - 2017-02-06 07:24:54 --> Loader Class Initialized
INFO - 2017-02-06 07:24:54 --> Helper loaded: form_helper
INFO - 2017-02-06 07:24:54 --> Helper loaded: url_helper
INFO - 2017-02-06 07:24:54 --> Helper loaded: utility_helper
INFO - 2017-02-06 07:24:54 --> Database Driver Class Initialized
INFO - 2017-02-06 07:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 07:24:54 --> User Agent Class Initialized
DEBUG - 2017-02-06 07:24:54 --> Template Class Initialized
INFO - 2017-02-06 07:24:54 --> Controller Class Initialized
INFO - 2017-02-06 07:24:54 --> Form Validation Class Initialized
DEBUG - 2017-02-06 07:24:54 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-06 07:24:54 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-06 07:24:54 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/how_it_works.php
DEBUG - 2017-02-06 07:24:54 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 07:24:54 --> Final output sent to browser
DEBUG - 2017-02-06 07:24:54 --> Total execution time: 0.0502
INFO - 2017-02-06 07:24:54 --> Config Class Initialized
INFO - 2017-02-06 07:24:54 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:24:54 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:24:54 --> Utf8 Class Initialized
INFO - 2017-02-06 07:24:54 --> URI Class Initialized
INFO - 2017-02-06 07:24:54 --> Router Class Initialized
INFO - 2017-02-06 07:24:54 --> Output Class Initialized
INFO - 2017-02-06 07:24:54 --> Security Class Initialized
DEBUG - 2017-02-06 07:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:24:54 --> Input Class Initialized
INFO - 2017-02-06 07:24:54 --> Language Class Initialized
ERROR - 2017-02-06 07:24:54 --> 404 Page Not Found: /index
INFO - 2017-02-06 07:24:54 --> Config Class Initialized
INFO - 2017-02-06 07:24:54 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:24:54 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:24:54 --> Utf8 Class Initialized
INFO - 2017-02-06 07:24:54 --> URI Class Initialized
INFO - 2017-02-06 07:24:54 --> Router Class Initialized
INFO - 2017-02-06 07:24:54 --> Output Class Initialized
INFO - 2017-02-06 07:24:54 --> Security Class Initialized
DEBUG - 2017-02-06 07:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:24:54 --> Input Class Initialized
INFO - 2017-02-06 07:24:54 --> Language Class Initialized
ERROR - 2017-02-06 07:24:54 --> 404 Page Not Found: /index
INFO - 2017-02-06 07:25:42 --> Config Class Initialized
INFO - 2017-02-06 07:25:42 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:25:42 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:25:42 --> Utf8 Class Initialized
INFO - 2017-02-06 07:25:42 --> URI Class Initialized
INFO - 2017-02-06 07:25:42 --> Router Class Initialized
INFO - 2017-02-06 07:25:42 --> Output Class Initialized
INFO - 2017-02-06 07:25:42 --> Security Class Initialized
DEBUG - 2017-02-06 07:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:25:42 --> Input Class Initialized
INFO - 2017-02-06 07:25:42 --> Language Class Initialized
INFO - 2017-02-06 07:25:42 --> Language Class Initialized
INFO - 2017-02-06 07:25:42 --> Config Class Initialized
INFO - 2017-02-06 07:25:42 --> Loader Class Initialized
INFO - 2017-02-06 07:25:42 --> Helper loaded: form_helper
INFO - 2017-02-06 07:25:42 --> Helper loaded: url_helper
INFO - 2017-02-06 07:25:42 --> Helper loaded: utility_helper
INFO - 2017-02-06 07:25:42 --> Database Driver Class Initialized
INFO - 2017-02-06 07:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 07:25:42 --> User Agent Class Initialized
DEBUG - 2017-02-06 07:25:42 --> Template Class Initialized
INFO - 2017-02-06 07:25:42 --> Controller Class Initialized
INFO - 2017-02-06 07:25:42 --> Form Validation Class Initialized
DEBUG - 2017-02-06 07:25:42 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-06 07:25:42 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-06 07:25:42 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/how_it_works.php
DEBUG - 2017-02-06 07:25:42 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 07:25:42 --> Final output sent to browser
DEBUG - 2017-02-06 07:25:42 --> Total execution time: 0.0357
INFO - 2017-02-06 07:25:42 --> Config Class Initialized
INFO - 2017-02-06 07:25:42 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:25:42 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:25:42 --> Utf8 Class Initialized
INFO - 2017-02-06 07:25:42 --> URI Class Initialized
INFO - 2017-02-06 07:25:42 --> Router Class Initialized
INFO - 2017-02-06 07:25:42 --> Output Class Initialized
INFO - 2017-02-06 07:25:42 --> Security Class Initialized
DEBUG - 2017-02-06 07:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:25:42 --> Input Class Initialized
INFO - 2017-02-06 07:25:42 --> Language Class Initialized
ERROR - 2017-02-06 07:25:42 --> 404 Page Not Found: /index
INFO - 2017-02-06 07:25:42 --> Config Class Initialized
INFO - 2017-02-06 07:25:42 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:25:42 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:25:42 --> Utf8 Class Initialized
INFO - 2017-02-06 07:25:42 --> URI Class Initialized
INFO - 2017-02-06 07:25:42 --> Router Class Initialized
INFO - 2017-02-06 07:25:42 --> Output Class Initialized
INFO - 2017-02-06 07:25:42 --> Security Class Initialized
DEBUG - 2017-02-06 07:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:25:42 --> Input Class Initialized
INFO - 2017-02-06 07:25:42 --> Language Class Initialized
ERROR - 2017-02-06 07:25:42 --> 404 Page Not Found: /index
INFO - 2017-02-06 07:29:09 --> Config Class Initialized
INFO - 2017-02-06 07:29:09 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:29:09 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:29:09 --> Utf8 Class Initialized
INFO - 2017-02-06 07:29:09 --> URI Class Initialized
INFO - 2017-02-06 07:29:09 --> Router Class Initialized
INFO - 2017-02-06 07:29:09 --> Output Class Initialized
INFO - 2017-02-06 07:29:09 --> Security Class Initialized
DEBUG - 2017-02-06 07:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:29:09 --> Input Class Initialized
INFO - 2017-02-06 07:29:09 --> Language Class Initialized
INFO - 2017-02-06 07:29:09 --> Language Class Initialized
INFO - 2017-02-06 07:29:09 --> Config Class Initialized
INFO - 2017-02-06 07:29:09 --> Loader Class Initialized
INFO - 2017-02-06 07:29:09 --> Helper loaded: form_helper
INFO - 2017-02-06 07:29:09 --> Helper loaded: url_helper
INFO - 2017-02-06 07:29:09 --> Helper loaded: utility_helper
INFO - 2017-02-06 07:29:09 --> Database Driver Class Initialized
INFO - 2017-02-06 07:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 07:29:09 --> User Agent Class Initialized
DEBUG - 2017-02-06 07:29:09 --> Template Class Initialized
INFO - 2017-02-06 07:29:09 --> Controller Class Initialized
INFO - 2017-02-06 07:29:09 --> Form Validation Class Initialized
DEBUG - 2017-02-06 07:29:09 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-06 07:29:09 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-06 07:29:09 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/how_it_works.php
DEBUG - 2017-02-06 07:29:09 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 07:29:09 --> Final output sent to browser
DEBUG - 2017-02-06 07:29:09 --> Total execution time: 0.0339
INFO - 2017-02-06 07:29:09 --> Config Class Initialized
INFO - 2017-02-06 07:29:09 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:29:09 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:29:09 --> Utf8 Class Initialized
INFO - 2017-02-06 07:29:09 --> URI Class Initialized
INFO - 2017-02-06 07:29:09 --> Router Class Initialized
INFO - 2017-02-06 07:29:09 --> Output Class Initialized
INFO - 2017-02-06 07:29:09 --> Security Class Initialized
DEBUG - 2017-02-06 07:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:29:09 --> Input Class Initialized
INFO - 2017-02-06 07:29:09 --> Language Class Initialized
ERROR - 2017-02-06 07:29:09 --> 404 Page Not Found: /index
INFO - 2017-02-06 07:29:12 --> Config Class Initialized
INFO - 2017-02-06 07:29:12 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:29:12 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:29:12 --> Utf8 Class Initialized
INFO - 2017-02-06 07:29:12 --> URI Class Initialized
INFO - 2017-02-06 07:29:12 --> Router Class Initialized
INFO - 2017-02-06 07:29:12 --> Output Class Initialized
INFO - 2017-02-06 07:29:12 --> Security Class Initialized
DEBUG - 2017-02-06 07:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:29:12 --> Input Class Initialized
INFO - 2017-02-06 07:29:12 --> Language Class Initialized
INFO - 2017-02-06 07:29:12 --> Language Class Initialized
INFO - 2017-02-06 07:29:12 --> Config Class Initialized
INFO - 2017-02-06 07:29:12 --> Loader Class Initialized
INFO - 2017-02-06 07:29:12 --> Helper loaded: form_helper
INFO - 2017-02-06 07:29:12 --> Helper loaded: url_helper
INFO - 2017-02-06 07:29:12 --> Helper loaded: utility_helper
INFO - 2017-02-06 07:29:12 --> Database Driver Class Initialized
INFO - 2017-02-06 07:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 07:29:12 --> User Agent Class Initialized
DEBUG - 2017-02-06 07:29:12 --> Template Class Initialized
INFO - 2017-02-06 07:29:12 --> Controller Class Initialized
INFO - 2017-02-06 07:29:12 --> Form Validation Class Initialized
DEBUG - 2017-02-06 07:29:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-06 07:29:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-06 07:29:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/pricing.php
DEBUG - 2017-02-06 07:29:12 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 07:29:12 --> Final output sent to browser
DEBUG - 2017-02-06 07:29:12 --> Total execution time: 0.0548
INFO - 2017-02-06 07:29:12 --> Config Class Initialized
INFO - 2017-02-06 07:29:12 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:29:12 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:29:12 --> Utf8 Class Initialized
INFO - 2017-02-06 07:29:12 --> URI Class Initialized
INFO - 2017-02-06 07:29:12 --> Router Class Initialized
INFO - 2017-02-06 07:29:12 --> Output Class Initialized
INFO - 2017-02-06 07:29:12 --> Security Class Initialized
DEBUG - 2017-02-06 07:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:29:12 --> Input Class Initialized
INFO - 2017-02-06 07:29:12 --> Language Class Initialized
ERROR - 2017-02-06 07:29:12 --> 404 Page Not Found: /index
INFO - 2017-02-06 07:29:15 --> Config Class Initialized
INFO - 2017-02-06 07:29:15 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:29:15 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:29:15 --> Utf8 Class Initialized
INFO - 2017-02-06 07:29:15 --> URI Class Initialized
INFO - 2017-02-06 07:29:15 --> Router Class Initialized
INFO - 2017-02-06 07:29:15 --> Output Class Initialized
INFO - 2017-02-06 07:29:15 --> Security Class Initialized
DEBUG - 2017-02-06 07:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:29:15 --> Input Class Initialized
INFO - 2017-02-06 07:29:15 --> Language Class Initialized
INFO - 2017-02-06 07:29:15 --> Language Class Initialized
INFO - 2017-02-06 07:29:15 --> Config Class Initialized
INFO - 2017-02-06 07:29:15 --> Loader Class Initialized
INFO - 2017-02-06 07:29:15 --> Helper loaded: form_helper
INFO - 2017-02-06 07:29:15 --> Helper loaded: url_helper
INFO - 2017-02-06 07:29:15 --> Helper loaded: utility_helper
INFO - 2017-02-06 07:29:15 --> Database Driver Class Initialized
INFO - 2017-02-06 07:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 07:29:15 --> User Agent Class Initialized
DEBUG - 2017-02-06 07:29:15 --> Template Class Initialized
INFO - 2017-02-06 07:29:15 --> Controller Class Initialized
INFO - 2017-02-06 07:29:15 --> Form Validation Class Initialized
DEBUG - 2017-02-06 07:29:15 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-06 07:29:15 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-06 07:29:15 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-06 07:29:15 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 07:29:15 --> Final output sent to browser
DEBUG - 2017-02-06 07:29:15 --> Total execution time: 0.0344
INFO - 2017-02-06 07:29:15 --> Config Class Initialized
INFO - 2017-02-06 07:29:15 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:29:15 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:29:15 --> Utf8 Class Initialized
INFO - 2017-02-06 07:29:15 --> URI Class Initialized
INFO - 2017-02-06 07:29:15 --> Router Class Initialized
INFO - 2017-02-06 07:29:15 --> Output Class Initialized
INFO - 2017-02-06 07:29:15 --> Security Class Initialized
DEBUG - 2017-02-06 07:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:29:15 --> Input Class Initialized
INFO - 2017-02-06 07:29:15 --> Language Class Initialized
ERROR - 2017-02-06 07:29:15 --> 404 Page Not Found: /index
INFO - 2017-02-06 07:29:21 --> Config Class Initialized
INFO - 2017-02-06 07:29:21 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:29:21 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:29:21 --> Utf8 Class Initialized
INFO - 2017-02-06 07:29:21 --> URI Class Initialized
INFO - 2017-02-06 07:29:21 --> Router Class Initialized
INFO - 2017-02-06 07:29:21 --> Output Class Initialized
INFO - 2017-02-06 07:29:21 --> Security Class Initialized
DEBUG - 2017-02-06 07:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:29:21 --> Input Class Initialized
INFO - 2017-02-06 07:29:21 --> Language Class Initialized
INFO - 2017-02-06 07:29:21 --> Language Class Initialized
INFO - 2017-02-06 07:29:21 --> Config Class Initialized
INFO - 2017-02-06 07:29:21 --> Loader Class Initialized
INFO - 2017-02-06 07:29:21 --> Helper loaded: form_helper
INFO - 2017-02-06 07:29:21 --> Helper loaded: url_helper
INFO - 2017-02-06 07:29:21 --> Helper loaded: utility_helper
INFO - 2017-02-06 07:29:21 --> Database Driver Class Initialized
INFO - 2017-02-06 07:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 07:29:21 --> User Agent Class Initialized
DEBUG - 2017-02-06 07:29:21 --> Template Class Initialized
INFO - 2017-02-06 07:29:21 --> Controller Class Initialized
DEBUG - 2017-02-06 07:29:21 --> Login MX_Controller Initialized
INFO - 2017-02-06 07:29:21 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 07:29:21 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/login.php
DEBUG - 2017-02-06 07:29:21 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 07:29:21 --> Final output sent to browser
DEBUG - 2017-02-06 07:29:21 --> Total execution time: 0.0344
INFO - 2017-02-06 07:29:21 --> Config Class Initialized
INFO - 2017-02-06 07:29:21 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:29:21 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:29:21 --> Utf8 Class Initialized
INFO - 2017-02-06 07:29:21 --> URI Class Initialized
INFO - 2017-02-06 07:29:21 --> Router Class Initialized
INFO - 2017-02-06 07:29:21 --> Output Class Initialized
INFO - 2017-02-06 07:29:21 --> Security Class Initialized
DEBUG - 2017-02-06 07:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:29:21 --> Input Class Initialized
INFO - 2017-02-06 07:29:21 --> Language Class Initialized
ERROR - 2017-02-06 07:29:21 --> 404 Page Not Found: /index
INFO - 2017-02-06 07:29:21 --> Config Class Initialized
INFO - 2017-02-06 07:29:21 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:29:21 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:29:21 --> Utf8 Class Initialized
INFO - 2017-02-06 07:29:21 --> Config Class Initialized
INFO - 2017-02-06 07:29:21 --> URI Class Initialized
INFO - 2017-02-06 07:29:21 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:29:21 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:29:21 --> Router Class Initialized
INFO - 2017-02-06 07:29:21 --> Utf8 Class Initialized
INFO - 2017-02-06 07:29:21 --> URI Class Initialized
INFO - 2017-02-06 07:29:21 --> Output Class Initialized
INFO - 2017-02-06 07:29:21 --> Security Class Initialized
DEBUG - 2017-02-06 07:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:29:21 --> Input Class Initialized
INFO - 2017-02-06 07:29:21 --> Router Class Initialized
INFO - 2017-02-06 07:29:21 --> Language Class Initialized
INFO - 2017-02-06 07:29:21 --> Output Class Initialized
ERROR - 2017-02-06 07:29:21 --> 404 Page Not Found: /index
INFO - 2017-02-06 07:29:21 --> Security Class Initialized
DEBUG - 2017-02-06 07:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:29:21 --> Input Class Initialized
INFO - 2017-02-06 07:29:21 --> Language Class Initialized
ERROR - 2017-02-06 07:29:21 --> 404 Page Not Found: /index
INFO - 2017-02-06 07:29:21 --> Config Class Initialized
INFO - 2017-02-06 07:29:21 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:29:21 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:29:21 --> Utf8 Class Initialized
INFO - 2017-02-06 07:29:21 --> URI Class Initialized
INFO - 2017-02-06 07:29:21 --> Router Class Initialized
INFO - 2017-02-06 07:29:21 --> Output Class Initialized
INFO - 2017-02-06 07:29:21 --> Security Class Initialized
DEBUG - 2017-02-06 07:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:29:21 --> Input Class Initialized
INFO - 2017-02-06 07:29:21 --> Language Class Initialized
ERROR - 2017-02-06 07:29:21 --> 404 Page Not Found: /index
INFO - 2017-02-06 07:29:22 --> Config Class Initialized
INFO - 2017-02-06 07:29:22 --> Hooks Class Initialized
DEBUG - 2017-02-06 07:29:22 --> UTF-8 Support Enabled
INFO - 2017-02-06 07:29:22 --> Utf8 Class Initialized
INFO - 2017-02-06 07:29:22 --> URI Class Initialized
INFO - 2017-02-06 07:29:22 --> Router Class Initialized
INFO - 2017-02-06 07:29:22 --> Output Class Initialized
INFO - 2017-02-06 07:29:22 --> Security Class Initialized
DEBUG - 2017-02-06 07:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 07:29:22 --> Input Class Initialized
INFO - 2017-02-06 07:29:22 --> Language Class Initialized
INFO - 2017-02-06 07:29:22 --> Language Class Initialized
INFO - 2017-02-06 07:29:22 --> Config Class Initialized
INFO - 2017-02-06 07:29:22 --> Loader Class Initialized
INFO - 2017-02-06 07:29:22 --> Helper loaded: form_helper
INFO - 2017-02-06 07:29:22 --> Helper loaded: url_helper
INFO - 2017-02-06 07:29:22 --> Helper loaded: utility_helper
INFO - 2017-02-06 07:29:22 --> Database Driver Class Initialized
INFO - 2017-02-06 07:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 07:29:22 --> User Agent Class Initialized
DEBUG - 2017-02-06 07:29:22 --> Template Class Initialized
INFO - 2017-02-06 07:29:22 --> Controller Class Initialized
INFO - 2017-02-06 07:29:22 --> Form Validation Class Initialized
DEBUG - 2017-02-06 07:29:22 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-06 07:29:22 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-06 07:29:22 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-06 07:29:22 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 07:29:22 --> Final output sent to browser
DEBUG - 2017-02-06 07:29:22 --> Total execution time: 0.0351
INFO - 2017-02-06 08:07:09 --> Config Class Initialized
INFO - 2017-02-06 08:07:10 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:07:10 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:10 --> Utf8 Class Initialized
INFO - 2017-02-06 08:07:10 --> URI Class Initialized
INFO - 2017-02-06 08:07:10 --> Router Class Initialized
INFO - 2017-02-06 08:07:10 --> Output Class Initialized
INFO - 2017-02-06 08:07:10 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:10 --> Input Class Initialized
INFO - 2017-02-06 08:07:10 --> Language Class Initialized
INFO - 2017-02-06 08:07:10 --> Language Class Initialized
INFO - 2017-02-06 08:07:10 --> Config Class Initialized
INFO - 2017-02-06 08:07:10 --> Loader Class Initialized
INFO - 2017-02-06 08:07:10 --> Helper loaded: form_helper
INFO - 2017-02-06 08:07:10 --> Helper loaded: url_helper
INFO - 2017-02-06 08:07:10 --> Helper loaded: utility_helper
INFO - 2017-02-06 08:07:10 --> Database Driver Class Initialized
INFO - 2017-02-06 08:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 08:07:10 --> User Agent Class Initialized
DEBUG - 2017-02-06 08:07:10 --> Template Class Initialized
INFO - 2017-02-06 08:07:10 --> Controller Class Initialized
DEBUG - 2017-02-06 08:07:10 --> Login MX_Controller Initialized
INFO - 2017-02-06 08:07:10 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 08:07:10 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/login.php
DEBUG - 2017-02-06 08:07:10 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 08:07:10 --> Final output sent to browser
DEBUG - 2017-02-06 08:07:10 --> Total execution time: 0.1070
INFO - 2017-02-06 08:07:10 --> Config Class Initialized
INFO - 2017-02-06 08:07:10 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:07:10 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:10 --> Utf8 Class Initialized
INFO - 2017-02-06 08:07:10 --> URI Class Initialized
INFO - 2017-02-06 08:07:10 --> Router Class Initialized
INFO - 2017-02-06 08:07:10 --> Output Class Initialized
INFO - 2017-02-06 08:07:10 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:10 --> Input Class Initialized
INFO - 2017-02-06 08:07:10 --> Language Class Initialized
ERROR - 2017-02-06 08:07:10 --> 404 Page Not Found: /index
INFO - 2017-02-06 08:07:10 --> Config Class Initialized
INFO - 2017-02-06 08:07:10 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:07:10 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:10 --> Utf8 Class Initialized
INFO - 2017-02-06 08:07:10 --> URI Class Initialized
INFO - 2017-02-06 08:07:10 --> Router Class Initialized
INFO - 2017-02-06 08:07:10 --> Output Class Initialized
INFO - 2017-02-06 08:07:10 --> Config Class Initialized
INFO - 2017-02-06 08:07:10 --> Hooks Class Initialized
INFO - 2017-02-06 08:07:10 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:10 --> Input Class Initialized
INFO - 2017-02-06 08:07:10 --> Language Class Initialized
DEBUG - 2017-02-06 08:07:10 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:10 --> Utf8 Class Initialized
ERROR - 2017-02-06 08:07:10 --> 404 Page Not Found: /index
INFO - 2017-02-06 08:07:10 --> URI Class Initialized
INFO - 2017-02-06 08:07:10 --> Router Class Initialized
INFO - 2017-02-06 08:07:10 --> Output Class Initialized
INFO - 2017-02-06 08:07:10 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:10 --> Input Class Initialized
INFO - 2017-02-06 08:07:10 --> Language Class Initialized
ERROR - 2017-02-06 08:07:10 --> 404 Page Not Found: /index
INFO - 2017-02-06 08:07:10 --> Config Class Initialized
INFO - 2017-02-06 08:07:10 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:07:10 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:10 --> Utf8 Class Initialized
INFO - 2017-02-06 08:07:10 --> URI Class Initialized
INFO - 2017-02-06 08:07:10 --> Router Class Initialized
INFO - 2017-02-06 08:07:10 --> Output Class Initialized
INFO - 2017-02-06 08:07:10 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:10 --> Input Class Initialized
INFO - 2017-02-06 08:07:10 --> Language Class Initialized
ERROR - 2017-02-06 08:07:10 --> 404 Page Not Found: /index
INFO - 2017-02-06 08:07:11 --> Config Class Initialized
INFO - 2017-02-06 08:07:11 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:07:11 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:11 --> Utf8 Class Initialized
INFO - 2017-02-06 08:07:11 --> URI Class Initialized
INFO - 2017-02-06 08:07:11 --> Router Class Initialized
INFO - 2017-02-06 08:07:11 --> Output Class Initialized
INFO - 2017-02-06 08:07:11 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:11 --> Input Class Initialized
INFO - 2017-02-06 08:07:11 --> Language Class Initialized
INFO - 2017-02-06 08:07:11 --> Language Class Initialized
INFO - 2017-02-06 08:07:11 --> Config Class Initialized
INFO - 2017-02-06 08:07:11 --> Loader Class Initialized
INFO - 2017-02-06 08:07:11 --> Helper loaded: form_helper
INFO - 2017-02-06 08:07:11 --> Helper loaded: url_helper
INFO - 2017-02-06 08:07:11 --> Helper loaded: utility_helper
INFO - 2017-02-06 08:07:11 --> Database Driver Class Initialized
INFO - 2017-02-06 08:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 08:07:11 --> User Agent Class Initialized
DEBUG - 2017-02-06 08:07:11 --> Template Class Initialized
INFO - 2017-02-06 08:07:11 --> Controller Class Initialized
DEBUG - 2017-02-06 08:07:11 --> Login MX_Controller Initialized
INFO - 2017-02-06 08:07:11 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 08:07:11 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 08:07:11 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 08:07:11 --> Final output sent to browser
DEBUG - 2017-02-06 08:07:11 --> Total execution time: 0.0673
INFO - 2017-02-06 08:07:11 --> Config Class Initialized
INFO - 2017-02-06 08:07:11 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:07:11 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:11 --> Utf8 Class Initialized
INFO - 2017-02-06 08:07:11 --> URI Class Initialized
INFO - 2017-02-06 08:07:11 --> Router Class Initialized
INFO - 2017-02-06 08:07:11 --> Output Class Initialized
INFO - 2017-02-06 08:07:11 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:11 --> Input Class Initialized
INFO - 2017-02-06 08:07:11 --> Language Class Initialized
ERROR - 2017-02-06 08:07:11 --> 404 Page Not Found: /index
INFO - 2017-02-06 08:07:18 --> Config Class Initialized
INFO - 2017-02-06 08:07:18 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:07:18 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:18 --> Utf8 Class Initialized
INFO - 2017-02-06 08:07:18 --> URI Class Initialized
INFO - 2017-02-06 08:07:18 --> Router Class Initialized
INFO - 2017-02-06 08:07:18 --> Output Class Initialized
INFO - 2017-02-06 08:07:18 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:18 --> Input Class Initialized
INFO - 2017-02-06 08:07:18 --> Language Class Initialized
ERROR - 2017-02-06 08:07:18 --> 404 Page Not Found: /index
INFO - 2017-02-06 08:07:19 --> Config Class Initialized
INFO - 2017-02-06 08:07:19 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:07:19 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:19 --> Utf8 Class Initialized
INFO - 2017-02-06 08:07:19 --> URI Class Initialized
INFO - 2017-02-06 08:07:19 --> Router Class Initialized
INFO - 2017-02-06 08:07:19 --> Output Class Initialized
INFO - 2017-02-06 08:07:19 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:19 --> Input Class Initialized
INFO - 2017-02-06 08:07:19 --> Language Class Initialized
ERROR - 2017-02-06 08:07:19 --> 404 Page Not Found: /index
INFO - 2017-02-06 08:07:19 --> Config Class Initialized
INFO - 2017-02-06 08:07:19 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:07:19 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:19 --> Utf8 Class Initialized
INFO - 2017-02-06 08:07:19 --> URI Class Initialized
INFO - 2017-02-06 08:07:19 --> Router Class Initialized
INFO - 2017-02-06 08:07:19 --> Output Class Initialized
INFO - 2017-02-06 08:07:19 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:19 --> Input Class Initialized
INFO - 2017-02-06 08:07:19 --> Language Class Initialized
ERROR - 2017-02-06 08:07:19 --> 404 Page Not Found: /index
INFO - 2017-02-06 08:07:36 --> Config Class Initialized
INFO - 2017-02-06 08:07:36 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:07:36 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:36 --> Utf8 Class Initialized
INFO - 2017-02-06 08:07:36 --> URI Class Initialized
DEBUG - 2017-02-06 08:07:36 --> No URI present. Default controller set.
INFO - 2017-02-06 08:07:36 --> Router Class Initialized
INFO - 2017-02-06 08:07:36 --> Output Class Initialized
INFO - 2017-02-06 08:07:36 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:36 --> Input Class Initialized
INFO - 2017-02-06 08:07:36 --> Language Class Initialized
INFO - 2017-02-06 08:07:36 --> Language Class Initialized
INFO - 2017-02-06 08:07:36 --> Config Class Initialized
INFO - 2017-02-06 08:07:36 --> Loader Class Initialized
INFO - 2017-02-06 08:07:36 --> Helper loaded: form_helper
INFO - 2017-02-06 08:07:36 --> Helper loaded: url_helper
INFO - 2017-02-06 08:07:36 --> Helper loaded: utility_helper
INFO - 2017-02-06 08:07:36 --> Database Driver Class Initialized
INFO - 2017-02-06 08:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 08:07:36 --> User Agent Class Initialized
DEBUG - 2017-02-06 08:07:36 --> Template Class Initialized
INFO - 2017-02-06 08:07:36 --> Controller Class Initialized
INFO - 2017-02-06 08:07:36 --> Form Validation Class Initialized
DEBUG - 2017-02-06 08:07:36 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-06 08:07:36 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-06 08:07:36 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-06 08:07:36 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 08:07:36 --> Final output sent to browser
DEBUG - 2017-02-06 08:07:36 --> Total execution time: 0.1512
INFO - 2017-02-06 08:07:36 --> Config Class Initialized
INFO - 2017-02-06 08:07:36 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:07:36 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:36 --> Utf8 Class Initialized
INFO - 2017-02-06 08:07:36 --> URI Class Initialized
INFO - 2017-02-06 08:07:36 --> Router Class Initialized
INFO - 2017-02-06 08:07:36 --> Output Class Initialized
INFO - 2017-02-06 08:07:36 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:36 --> Input Class Initialized
INFO - 2017-02-06 08:07:36 --> Language Class Initialized
ERROR - 2017-02-06 08:07:36 --> 404 Page Not Found: /index
INFO - 2017-02-06 08:07:38 --> Config Class Initialized
INFO - 2017-02-06 08:07:38 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:07:38 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:38 --> Utf8 Class Initialized
INFO - 2017-02-06 08:07:38 --> URI Class Initialized
INFO - 2017-02-06 08:07:38 --> Router Class Initialized
INFO - 2017-02-06 08:07:38 --> Output Class Initialized
INFO - 2017-02-06 08:07:38 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:38 --> Input Class Initialized
INFO - 2017-02-06 08:07:38 --> Language Class Initialized
INFO - 2017-02-06 08:07:38 --> Language Class Initialized
INFO - 2017-02-06 08:07:38 --> Config Class Initialized
INFO - 2017-02-06 08:07:38 --> Loader Class Initialized
INFO - 2017-02-06 08:07:38 --> Helper loaded: form_helper
INFO - 2017-02-06 08:07:38 --> Helper loaded: url_helper
INFO - 2017-02-06 08:07:38 --> Helper loaded: utility_helper
INFO - 2017-02-06 08:07:38 --> Database Driver Class Initialized
INFO - 2017-02-06 08:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 08:07:38 --> User Agent Class Initialized
DEBUG - 2017-02-06 08:07:38 --> Template Class Initialized
INFO - 2017-02-06 08:07:38 --> Controller Class Initialized
DEBUG - 2017-02-06 08:07:38 --> Login MX_Controller Initialized
INFO - 2017-02-06 08:07:38 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 08:07:38 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/login.php
DEBUG - 2017-02-06 08:07:38 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 08:07:38 --> Final output sent to browser
DEBUG - 2017-02-06 08:07:38 --> Total execution time: 0.0410
INFO - 2017-02-06 08:07:39 --> Config Class Initialized
INFO - 2017-02-06 08:07:39 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:07:39 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:39 --> Utf8 Class Initialized
INFO - 2017-02-06 08:07:39 --> URI Class Initialized
INFO - 2017-02-06 08:07:39 --> Router Class Initialized
INFO - 2017-02-06 08:07:39 --> Output Class Initialized
INFO - 2017-02-06 08:07:39 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:39 --> Input Class Initialized
INFO - 2017-02-06 08:07:39 --> Language Class Initialized
ERROR - 2017-02-06 08:07:39 --> 404 Page Not Found: /index
INFO - 2017-02-06 08:07:39 --> Config Class Initialized
INFO - 2017-02-06 08:07:39 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:07:39 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:39 --> Config Class Initialized
INFO - 2017-02-06 08:07:39 --> Utf8 Class Initialized
INFO - 2017-02-06 08:07:39 --> Hooks Class Initialized
INFO - 2017-02-06 08:07:39 --> URI Class Initialized
INFO - 2017-02-06 08:07:39 --> Router Class Initialized
DEBUG - 2017-02-06 08:07:39 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:39 --> Utf8 Class Initialized
INFO - 2017-02-06 08:07:39 --> Output Class Initialized
INFO - 2017-02-06 08:07:39 --> URI Class Initialized
INFO - 2017-02-06 08:07:39 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:39 --> Input Class Initialized
INFO - 2017-02-06 08:07:39 --> Language Class Initialized
INFO - 2017-02-06 08:07:39 --> Router Class Initialized
ERROR - 2017-02-06 08:07:39 --> 404 Page Not Found: /index
INFO - 2017-02-06 08:07:39 --> Output Class Initialized
INFO - 2017-02-06 08:07:39 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:39 --> Input Class Initialized
INFO - 2017-02-06 08:07:39 --> Language Class Initialized
ERROR - 2017-02-06 08:07:39 --> 404 Page Not Found: /index
INFO - 2017-02-06 08:07:39 --> Config Class Initialized
INFO - 2017-02-06 08:07:39 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:07:39 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:39 --> Utf8 Class Initialized
INFO - 2017-02-06 08:07:39 --> URI Class Initialized
INFO - 2017-02-06 08:07:39 --> Router Class Initialized
INFO - 2017-02-06 08:07:39 --> Output Class Initialized
INFO - 2017-02-06 08:07:39 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:39 --> Input Class Initialized
INFO - 2017-02-06 08:07:39 --> Language Class Initialized
ERROR - 2017-02-06 08:07:39 --> 404 Page Not Found: /index
INFO - 2017-02-06 08:07:40 --> Config Class Initialized
INFO - 2017-02-06 08:07:40 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:07:40 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:40 --> Utf8 Class Initialized
INFO - 2017-02-06 08:07:40 --> URI Class Initialized
INFO - 2017-02-06 08:07:40 --> Router Class Initialized
INFO - 2017-02-06 08:07:40 --> Output Class Initialized
INFO - 2017-02-06 08:07:40 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:40 --> Input Class Initialized
INFO - 2017-02-06 08:07:40 --> Language Class Initialized
INFO - 2017-02-06 08:07:40 --> Language Class Initialized
INFO - 2017-02-06 08:07:40 --> Config Class Initialized
INFO - 2017-02-06 08:07:40 --> Loader Class Initialized
INFO - 2017-02-06 08:07:40 --> Helper loaded: form_helper
INFO - 2017-02-06 08:07:40 --> Helper loaded: url_helper
INFO - 2017-02-06 08:07:40 --> Helper loaded: utility_helper
INFO - 2017-02-06 08:07:40 --> Database Driver Class Initialized
INFO - 2017-02-06 08:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 08:07:40 --> User Agent Class Initialized
DEBUG - 2017-02-06 08:07:40 --> Template Class Initialized
INFO - 2017-02-06 08:07:40 --> Controller Class Initialized
DEBUG - 2017-02-06 08:07:40 --> Login MX_Controller Initialized
INFO - 2017-02-06 08:07:40 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 08:07:40 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 08:07:40 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 08:07:40 --> Final output sent to browser
DEBUG - 2017-02-06 08:07:40 --> Total execution time: 0.0324
INFO - 2017-02-06 08:07:40 --> Config Class Initialized
INFO - 2017-02-06 08:07:40 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:07:40 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:07:40 --> Utf8 Class Initialized
INFO - 2017-02-06 08:07:40 --> URI Class Initialized
INFO - 2017-02-06 08:07:40 --> Router Class Initialized
INFO - 2017-02-06 08:07:40 --> Output Class Initialized
INFO - 2017-02-06 08:07:40 --> Security Class Initialized
DEBUG - 2017-02-06 08:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:07:40 --> Input Class Initialized
INFO - 2017-02-06 08:07:40 --> Language Class Initialized
ERROR - 2017-02-06 08:07:40 --> 404 Page Not Found: /index
INFO - 2017-02-06 08:08:05 --> Config Class Initialized
INFO - 2017-02-06 08:08:05 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:08:05 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:08:05 --> Utf8 Class Initialized
INFO - 2017-02-06 08:08:05 --> URI Class Initialized
INFO - 2017-02-06 08:08:05 --> Router Class Initialized
INFO - 2017-02-06 08:08:05 --> Output Class Initialized
INFO - 2017-02-06 08:08:05 --> Security Class Initialized
DEBUG - 2017-02-06 08:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:08:05 --> Input Class Initialized
INFO - 2017-02-06 08:08:05 --> Language Class Initialized
INFO - 2017-02-06 08:08:05 --> Language Class Initialized
INFO - 2017-02-06 08:08:05 --> Config Class Initialized
INFO - 2017-02-06 08:08:05 --> Loader Class Initialized
INFO - 2017-02-06 08:08:05 --> Helper loaded: form_helper
INFO - 2017-02-06 08:08:05 --> Helper loaded: url_helper
INFO - 2017-02-06 08:08:05 --> Helper loaded: utility_helper
INFO - 2017-02-06 08:08:05 --> Database Driver Class Initialized
INFO - 2017-02-06 08:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 08:08:05 --> User Agent Class Initialized
DEBUG - 2017-02-06 08:08:05 --> Template Class Initialized
INFO - 2017-02-06 08:08:05 --> Controller Class Initialized
DEBUG - 2017-02-06 08:08:05 --> Login MX_Controller Initialized
INFO - 2017-02-06 08:08:05 --> Helper loaded: cookie_helper
INFO - 2017-02-06 08:08:05 --> Model Class Initialized
INFO - 2017-02-06 08:08:05 --> Model Class Initialized
INFO - 2017-02-06 08:08:05 --> Form Validation Class Initialized
INFO - 2017-02-06 08:08:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-06 08:08:05 --> Final output sent to browser
DEBUG - 2017-02-06 08:08:05 --> Total execution time: 0.1406
INFO - 2017-02-06 08:08:10 --> Config Class Initialized
INFO - 2017-02-06 08:08:10 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:08:10 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:08:10 --> Utf8 Class Initialized
INFO - 2017-02-06 08:08:10 --> URI Class Initialized
INFO - 2017-02-06 08:08:10 --> Router Class Initialized
INFO - 2017-02-06 08:08:10 --> Output Class Initialized
INFO - 2017-02-06 08:08:10 --> Security Class Initialized
DEBUG - 2017-02-06 08:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:08:10 --> Input Class Initialized
INFO - 2017-02-06 08:08:10 --> Language Class Initialized
INFO - 2017-02-06 08:08:10 --> Language Class Initialized
INFO - 2017-02-06 08:08:10 --> Config Class Initialized
INFO - 2017-02-06 08:08:10 --> Loader Class Initialized
INFO - 2017-02-06 08:08:10 --> Helper loaded: form_helper
INFO - 2017-02-06 08:08:10 --> Helper loaded: url_helper
INFO - 2017-02-06 08:08:10 --> Helper loaded: utility_helper
INFO - 2017-02-06 08:08:10 --> Database Driver Class Initialized
INFO - 2017-02-06 08:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 08:08:10 --> User Agent Class Initialized
DEBUG - 2017-02-06 08:08:10 --> Template Class Initialized
INFO - 2017-02-06 08:08:10 --> Controller Class Initialized
DEBUG - 2017-02-06 08:08:10 --> Login MX_Controller Initialized
INFO - 2017-02-06 08:08:10 --> Helper loaded: cookie_helper
INFO - 2017-02-06 08:08:10 --> Model Class Initialized
INFO - 2017-02-06 08:08:10 --> Model Class Initialized
INFO - 2017-02-06 08:08:10 --> Form Validation Class Initialized
INFO - 2017-02-06 08:08:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-06 08:08:10 --> Model Class Initialized
INFO - 2017-02-06 08:08:10 --> Final output sent to browser
DEBUG - 2017-02-06 08:08:10 --> Total execution time: 0.1757
INFO - 2017-02-06 08:08:11 --> Config Class Initialized
INFO - 2017-02-06 08:08:11 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:08:11 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:08:11 --> Utf8 Class Initialized
INFO - 2017-02-06 08:08:11 --> URI Class Initialized
INFO - 2017-02-06 08:08:11 --> Router Class Initialized
INFO - 2017-02-06 08:08:11 --> Output Class Initialized
INFO - 2017-02-06 08:08:11 --> Security Class Initialized
INFO - 2017-02-06 08:08:11 --> Config Class Initialized
INFO - 2017-02-06 08:08:11 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:08:11 --> Input Class Initialized
INFO - 2017-02-06 08:08:11 --> Language Class Initialized
DEBUG - 2017-02-06 08:08:11 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:08:11 --> Utf8 Class Initialized
INFO - 2017-02-06 08:08:11 --> URI Class Initialized
INFO - 2017-02-06 08:08:11 --> Language Class Initialized
INFO - 2017-02-06 08:08:11 --> Config Class Initialized
INFO - 2017-02-06 08:08:11 --> Loader Class Initialized
INFO - 2017-02-06 08:08:11 --> Router Class Initialized
INFO - 2017-02-06 08:08:11 --> Helper loaded: form_helper
INFO - 2017-02-06 08:08:11 --> Output Class Initialized
INFO - 2017-02-06 08:08:11 --> Helper loaded: url_helper
INFO - 2017-02-06 08:08:11 --> Security Class Initialized
INFO - 2017-02-06 08:08:11 --> Helper loaded: utility_helper
DEBUG - 2017-02-06 08:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:08:11 --> Input Class Initialized
INFO - 2017-02-06 08:08:11 --> Language Class Initialized
INFO - 2017-02-06 08:08:11 --> Database Driver Class Initialized
INFO - 2017-02-06 08:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 08:08:11 --> User Agent Class Initialized
DEBUG - 2017-02-06 08:08:11 --> Template Class Initialized
INFO - 2017-02-06 08:08:11 --> Controller Class Initialized
DEBUG - 2017-02-06 08:08:11 --> Login MX_Controller Initialized
INFO - 2017-02-06 08:08:11 --> Helper loaded: cookie_helper
INFO - 2017-02-06 08:08:11 --> Model Class Initialized
INFO - 2017-02-06 08:08:11 --> Model Class Initialized
INFO - 2017-02-06 08:08:11 --> Form Validation Class Initialized
INFO - 2017-02-06 08:08:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-06 08:08:11 --> Final output sent to browser
DEBUG - 2017-02-06 08:08:11 --> Total execution time: 0.0464
INFO - 2017-02-06 08:08:11 --> Language Class Initialized
INFO - 2017-02-06 08:08:11 --> Config Class Initialized
INFO - 2017-02-06 08:08:11 --> Loader Class Initialized
INFO - 2017-02-06 08:08:11 --> Helper loaded: form_helper
INFO - 2017-02-06 08:08:11 --> Helper loaded: url_helper
INFO - 2017-02-06 08:08:11 --> Helper loaded: utility_helper
INFO - 2017-02-06 08:08:11 --> Database Driver Class Initialized
INFO - 2017-02-06 08:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 08:08:11 --> User Agent Class Initialized
DEBUG - 2017-02-06 08:08:11 --> Template Class Initialized
INFO - 2017-02-06 08:08:11 --> Controller Class Initialized
INFO - 2017-02-06 08:08:11 --> Form Validation Class Initialized
DEBUG - 2017-02-06 08:08:11 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/payment.php
INFO - 2017-02-06 08:08:11 --> Final output sent to browser
DEBUG - 2017-02-06 08:08:11 --> Total execution time: 0.0841
INFO - 2017-02-06 08:08:59 --> Config Class Initialized
INFO - 2017-02-06 08:08:59 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:08:59 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:08:59 --> Utf8 Class Initialized
INFO - 2017-02-06 08:08:59 --> URI Class Initialized
INFO - 2017-02-06 08:08:59 --> Router Class Initialized
INFO - 2017-02-06 08:08:59 --> Output Class Initialized
INFO - 2017-02-06 08:08:59 --> Security Class Initialized
DEBUG - 2017-02-06 08:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:08:59 --> Input Class Initialized
INFO - 2017-02-06 08:08:59 --> Language Class Initialized
INFO - 2017-02-06 08:08:59 --> Language Class Initialized
INFO - 2017-02-06 08:08:59 --> Config Class Initialized
INFO - 2017-02-06 08:08:59 --> Loader Class Initialized
INFO - 2017-02-06 08:08:59 --> Helper loaded: form_helper
INFO - 2017-02-06 08:08:59 --> Helper loaded: url_helper
INFO - 2017-02-06 08:08:59 --> Helper loaded: utility_helper
INFO - 2017-02-06 08:08:59 --> Database Driver Class Initialized
INFO - 2017-02-06 08:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 08:08:59 --> User Agent Class Initialized
DEBUG - 2017-02-06 08:08:59 --> Template Class Initialized
INFO - 2017-02-06 08:08:59 --> Controller Class Initialized
INFO - 2017-02-06 08:08:59 --> Form Validation Class Initialized
INFO - 2017-02-06 08:08:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-06 08:09:02 --> Config Class Initialized
INFO - 2017-02-06 08:09:02 --> Hooks Class Initialized
DEBUG - 2017-02-06 08:09:02 --> UTF-8 Support Enabled
INFO - 2017-02-06 08:09:02 --> Utf8 Class Initialized
INFO - 2017-02-06 08:09:02 --> URI Class Initialized
INFO - 2017-02-06 08:09:02 --> Router Class Initialized
INFO - 2017-02-06 08:09:02 --> Output Class Initialized
INFO - 2017-02-06 08:09:02 --> Security Class Initialized
DEBUG - 2017-02-06 08:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 08:09:02 --> Input Class Initialized
INFO - 2017-02-06 08:09:02 --> Language Class Initialized
ERROR - 2017-02-06 08:09:02 --> 404 Page Not Found: /index
INFO - 2017-02-06 09:10:53 --> Config Class Initialized
INFO - 2017-02-06 09:10:53 --> Hooks Class Initialized
DEBUG - 2017-02-06 09:10:53 --> UTF-8 Support Enabled
INFO - 2017-02-06 09:10:53 --> Utf8 Class Initialized
INFO - 2017-02-06 09:10:53 --> URI Class Initialized
INFO - 2017-02-06 09:10:53 --> Router Class Initialized
INFO - 2017-02-06 09:10:53 --> Output Class Initialized
INFO - 2017-02-06 09:10:53 --> Security Class Initialized
DEBUG - 2017-02-06 09:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 09:10:53 --> Input Class Initialized
INFO - 2017-02-06 09:10:53 --> Language Class Initialized
ERROR - 2017-02-06 09:10:53 --> 404 Page Not Found: /index
INFO - 2017-02-06 09:10:56 --> Config Class Initialized
INFO - 2017-02-06 09:10:56 --> Hooks Class Initialized
DEBUG - 2017-02-06 09:10:56 --> UTF-8 Support Enabled
INFO - 2017-02-06 09:10:56 --> Utf8 Class Initialized
INFO - 2017-02-06 09:10:56 --> URI Class Initialized
INFO - 2017-02-06 09:10:56 --> Router Class Initialized
INFO - 2017-02-06 09:10:56 --> Output Class Initialized
INFO - 2017-02-06 09:10:56 --> Security Class Initialized
DEBUG - 2017-02-06 09:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 09:10:56 --> Input Class Initialized
INFO - 2017-02-06 09:10:56 --> Language Class Initialized
ERROR - 2017-02-06 09:10:56 --> 404 Page Not Found: /index
INFO - 2017-02-06 09:11:33 --> Config Class Initialized
INFO - 2017-02-06 09:11:33 --> Hooks Class Initialized
DEBUG - 2017-02-06 09:11:33 --> UTF-8 Support Enabled
INFO - 2017-02-06 09:11:33 --> Utf8 Class Initialized
INFO - 2017-02-06 09:11:33 --> URI Class Initialized
INFO - 2017-02-06 09:11:33 --> Router Class Initialized
INFO - 2017-02-06 09:11:33 --> Output Class Initialized
INFO - 2017-02-06 09:11:33 --> Security Class Initialized
DEBUG - 2017-02-06 09:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 09:11:33 --> Input Class Initialized
INFO - 2017-02-06 09:11:33 --> Language Class Initialized
ERROR - 2017-02-06 09:11:33 --> 404 Page Not Found: /index
INFO - 2017-02-06 09:11:33 --> Config Class Initialized
INFO - 2017-02-06 09:11:33 --> Hooks Class Initialized
DEBUG - 2017-02-06 09:11:33 --> UTF-8 Support Enabled
INFO - 2017-02-06 09:11:33 --> Utf8 Class Initialized
INFO - 2017-02-06 09:11:33 --> URI Class Initialized
INFO - 2017-02-06 09:11:33 --> Router Class Initialized
INFO - 2017-02-06 09:11:33 --> Output Class Initialized
INFO - 2017-02-06 09:11:33 --> Security Class Initialized
DEBUG - 2017-02-06 09:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 09:11:33 --> Input Class Initialized
INFO - 2017-02-06 09:11:33 --> Language Class Initialized
ERROR - 2017-02-06 09:11:33 --> 404 Page Not Found: /index
INFO - 2017-02-06 09:11:35 --> Config Class Initialized
INFO - 2017-02-06 09:11:35 --> Hooks Class Initialized
DEBUG - 2017-02-06 09:11:35 --> UTF-8 Support Enabled
INFO - 2017-02-06 09:11:35 --> Utf8 Class Initialized
INFO - 2017-02-06 09:11:35 --> URI Class Initialized
INFO - 2017-02-06 09:11:35 --> Router Class Initialized
INFO - 2017-02-06 09:11:35 --> Output Class Initialized
INFO - 2017-02-06 09:11:35 --> Security Class Initialized
DEBUG - 2017-02-06 09:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 09:11:35 --> Input Class Initialized
INFO - 2017-02-06 09:11:35 --> Language Class Initialized
INFO - 2017-02-06 09:11:35 --> Language Class Initialized
INFO - 2017-02-06 09:11:35 --> Config Class Initialized
INFO - 2017-02-06 09:11:35 --> Loader Class Initialized
INFO - 2017-02-06 09:11:35 --> Helper loaded: form_helper
INFO - 2017-02-06 09:11:35 --> Helper loaded: url_helper
INFO - 2017-02-06 09:11:35 --> Helper loaded: utility_helper
INFO - 2017-02-06 09:11:35 --> Database Driver Class Initialized
INFO - 2017-02-06 09:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 09:11:35 --> User Agent Class Initialized
DEBUG - 2017-02-06 09:11:35 --> Template Class Initialized
INFO - 2017-02-06 09:11:35 --> Controller Class Initialized
INFO - 2017-02-06 09:11:36 --> Form Validation Class Initialized
DEBUG - 2017-02-06 09:11:36 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-06 09:11:36 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-06 09:11:36 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/how_it_works.php
DEBUG - 2017-02-06 09:11:36 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 09:11:36 --> Final output sent to browser
DEBUG - 2017-02-06 09:11:36 --> Total execution time: 0.2105
INFO - 2017-02-06 09:11:36 --> Config Class Initialized
INFO - 2017-02-06 09:11:36 --> Hooks Class Initialized
DEBUG - 2017-02-06 09:11:36 --> UTF-8 Support Enabled
INFO - 2017-02-06 09:11:36 --> Utf8 Class Initialized
INFO - 2017-02-06 09:11:36 --> URI Class Initialized
INFO - 2017-02-06 09:11:36 --> Router Class Initialized
INFO - 2017-02-06 09:11:36 --> Output Class Initialized
INFO - 2017-02-06 09:11:36 --> Security Class Initialized
DEBUG - 2017-02-06 09:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 09:11:36 --> Input Class Initialized
INFO - 2017-02-06 09:11:36 --> Language Class Initialized
ERROR - 2017-02-06 09:11:36 --> 404 Page Not Found: /index
INFO - 2017-02-06 09:11:36 --> Config Class Initialized
INFO - 2017-02-06 09:11:37 --> Hooks Class Initialized
DEBUG - 2017-02-06 09:11:37 --> UTF-8 Support Enabled
INFO - 2017-02-06 09:11:37 --> Utf8 Class Initialized
INFO - 2017-02-06 09:11:37 --> URI Class Initialized
INFO - 2017-02-06 09:11:37 --> Router Class Initialized
INFO - 2017-02-06 09:11:37 --> Output Class Initialized
INFO - 2017-02-06 09:11:37 --> Security Class Initialized
DEBUG - 2017-02-06 09:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 09:11:37 --> Input Class Initialized
INFO - 2017-02-06 09:11:37 --> Language Class Initialized
ERROR - 2017-02-06 09:11:37 --> 404 Page Not Found: /index
INFO - 2017-02-06 13:25:22 --> Config Class Initialized
INFO - 2017-02-06 13:25:22 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:25:22 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:25:22 --> Utf8 Class Initialized
INFO - 2017-02-06 13:25:22 --> URI Class Initialized
INFO - 2017-02-06 13:25:22 --> Router Class Initialized
INFO - 2017-02-06 13:25:22 --> Output Class Initialized
INFO - 2017-02-06 13:25:22 --> Security Class Initialized
DEBUG - 2017-02-06 13:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:25:22 --> Input Class Initialized
INFO - 2017-02-06 13:25:22 --> Language Class Initialized
INFO - 2017-02-06 13:25:23 --> Language Class Initialized
INFO - 2017-02-06 13:25:23 --> Config Class Initialized
INFO - 2017-02-06 13:25:23 --> Loader Class Initialized
INFO - 2017-02-06 13:25:23 --> Config Class Initialized
INFO - 2017-02-06 13:25:23 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:25:23 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:25:23 --> Utf8 Class Initialized
INFO - 2017-02-06 13:25:23 --> Helper loaded: form_helper
INFO - 2017-02-06 13:25:23 --> URI Class Initialized
INFO - 2017-02-06 13:25:23 --> Helper loaded: url_helper
INFO - 2017-02-06 13:25:23 --> Router Class Initialized
INFO - 2017-02-06 13:25:23 --> Output Class Initialized
INFO - 2017-02-06 13:25:23 --> Security Class Initialized
DEBUG - 2017-02-06 13:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:25:23 --> Input Class Initialized
INFO - 2017-02-06 13:25:23 --> Language Class Initialized
INFO - 2017-02-06 13:25:23 --> Helper loaded: utility_helper
INFO - 2017-02-06 13:25:23 --> Language Class Initialized
INFO - 2017-02-06 13:25:23 --> Config Class Initialized
INFO - 2017-02-06 13:25:23 --> Loader Class Initialized
INFO - 2017-02-06 13:25:23 --> Helper loaded: form_helper
INFO - 2017-02-06 13:25:23 --> Helper loaded: url_helper
INFO - 2017-02-06 13:25:23 --> Database Driver Class Initialized
INFO - 2017-02-06 13:25:23 --> Helper loaded: utility_helper
INFO - 2017-02-06 13:25:23 --> Database Driver Class Initialized
INFO - 2017-02-06 13:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 13:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 13:25:25 --> User Agent Class Initialized
DEBUG - 2017-02-06 13:25:25 --> Template Class Initialized
INFO - 2017-02-06 13:25:25 --> Controller Class Initialized
DEBUG - 2017-02-06 13:25:25 --> Login MX_Controller Initialized
INFO - 2017-02-06 13:25:25 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 13:25:25 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 13:25:25 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 13:25:25 --> Final output sent to browser
DEBUG - 2017-02-06 13:25:25 --> Total execution time: 2.4502
INFO - 2017-02-06 13:25:25 --> User Agent Class Initialized
DEBUG - 2017-02-06 13:25:25 --> Template Class Initialized
INFO - 2017-02-06 13:25:25 --> Controller Class Initialized
DEBUG - 2017-02-06 13:25:25 --> Login MX_Controller Initialized
INFO - 2017-02-06 13:25:25 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 13:25:25 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 13:25:25 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 13:25:25 --> Final output sent to browser
DEBUG - 2017-02-06 13:25:25 --> Total execution time: 3.6739
INFO - 2017-02-06 13:25:29 --> Config Class Initialized
INFO - 2017-02-06 13:25:29 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:25:29 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:25:29 --> Utf8 Class Initialized
INFO - 2017-02-06 13:25:29 --> URI Class Initialized
DEBUG - 2017-02-06 13:25:29 --> No URI present. Default controller set.
INFO - 2017-02-06 13:25:29 --> Router Class Initialized
INFO - 2017-02-06 13:25:29 --> Output Class Initialized
INFO - 2017-02-06 13:25:29 --> Security Class Initialized
DEBUG - 2017-02-06 13:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:25:29 --> Input Class Initialized
INFO - 2017-02-06 13:25:29 --> Language Class Initialized
INFO - 2017-02-06 13:25:29 --> Language Class Initialized
INFO - 2017-02-06 13:25:29 --> Config Class Initialized
INFO - 2017-02-06 13:25:29 --> Loader Class Initialized
INFO - 2017-02-06 13:25:29 --> Helper loaded: form_helper
INFO - 2017-02-06 13:25:29 --> Helper loaded: url_helper
INFO - 2017-02-06 13:25:29 --> Helper loaded: utility_helper
INFO - 2017-02-06 13:25:29 --> Database Driver Class Initialized
INFO - 2017-02-06 13:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 13:25:29 --> User Agent Class Initialized
DEBUG - 2017-02-06 13:25:29 --> Template Class Initialized
INFO - 2017-02-06 13:25:29 --> Controller Class Initialized
INFO - 2017-02-06 13:25:29 --> Form Validation Class Initialized
DEBUG - 2017-02-06 13:25:29 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-06 13:25:29 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-06 13:25:29 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-06 13:25:29 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 13:25:29 --> Final output sent to browser
DEBUG - 2017-02-06 13:25:29 --> Total execution time: 1.0980
INFO - 2017-02-06 13:25:30 --> Config Class Initialized
INFO - 2017-02-06 13:25:30 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:25:30 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:25:30 --> Utf8 Class Initialized
INFO - 2017-02-06 13:25:30 --> URI Class Initialized
INFO - 2017-02-06 13:25:31 --> Router Class Initialized
INFO - 2017-02-06 13:25:31 --> Output Class Initialized
INFO - 2017-02-06 13:25:31 --> Security Class Initialized
DEBUG - 2017-02-06 13:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:25:31 --> Input Class Initialized
INFO - 2017-02-06 13:25:31 --> Language Class Initialized
ERROR - 2017-02-06 13:25:31 --> 404 Page Not Found: /index
INFO - 2017-02-06 13:25:33 --> Config Class Initialized
INFO - 2017-02-06 13:25:33 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:25:33 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:25:33 --> Utf8 Class Initialized
INFO - 2017-02-06 13:25:33 --> URI Class Initialized
INFO - 2017-02-06 13:25:33 --> Router Class Initialized
INFO - 2017-02-06 13:25:33 --> Output Class Initialized
INFO - 2017-02-06 13:25:33 --> Security Class Initialized
DEBUG - 2017-02-06 13:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:25:33 --> Input Class Initialized
INFO - 2017-02-06 13:25:33 --> Language Class Initialized
ERROR - 2017-02-06 13:25:33 --> 404 Page Not Found: /index
INFO - 2017-02-06 13:25:33 --> Config Class Initialized
INFO - 2017-02-06 13:25:33 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:25:33 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:25:33 --> Utf8 Class Initialized
INFO - 2017-02-06 13:25:33 --> URI Class Initialized
INFO - 2017-02-06 13:25:33 --> Router Class Initialized
INFO - 2017-02-06 13:25:33 --> Output Class Initialized
INFO - 2017-02-06 13:25:33 --> Security Class Initialized
DEBUG - 2017-02-06 13:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:25:33 --> Input Class Initialized
INFO - 2017-02-06 13:25:33 --> Language Class Initialized
ERROR - 2017-02-06 13:25:33 --> 404 Page Not Found: /index
INFO - 2017-02-06 13:25:40 --> Config Class Initialized
INFO - 2017-02-06 13:25:40 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:25:40 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:25:40 --> Utf8 Class Initialized
INFO - 2017-02-06 13:25:40 --> URI Class Initialized
INFO - 2017-02-06 13:25:40 --> Router Class Initialized
INFO - 2017-02-06 13:25:40 --> Output Class Initialized
INFO - 2017-02-06 13:25:40 --> Security Class Initialized
DEBUG - 2017-02-06 13:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:25:40 --> Input Class Initialized
INFO - 2017-02-06 13:25:40 --> Language Class Initialized
INFO - 2017-02-06 13:25:40 --> Language Class Initialized
INFO - 2017-02-06 13:25:40 --> Config Class Initialized
INFO - 2017-02-06 13:25:40 --> Loader Class Initialized
INFO - 2017-02-06 13:25:40 --> Helper loaded: form_helper
INFO - 2017-02-06 13:25:40 --> Helper loaded: url_helper
INFO - 2017-02-06 13:25:40 --> Helper loaded: utility_helper
INFO - 2017-02-06 13:25:40 --> Database Driver Class Initialized
INFO - 2017-02-06 13:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 13:25:40 --> User Agent Class Initialized
DEBUG - 2017-02-06 13:25:40 --> Template Class Initialized
INFO - 2017-02-06 13:25:40 --> Controller Class Initialized
DEBUG - 2017-02-06 13:25:40 --> Login MX_Controller Initialized
INFO - 2017-02-06 13:25:40 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 13:25:41 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/login.php
DEBUG - 2017-02-06 13:25:41 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 13:25:41 --> Final output sent to browser
DEBUG - 2017-02-06 13:25:41 --> Total execution time: 0.6908
INFO - 2017-02-06 13:25:41 --> Config Class Initialized
INFO - 2017-02-06 13:25:41 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:25:41 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:25:41 --> Utf8 Class Initialized
INFO - 2017-02-06 13:25:41 --> URI Class Initialized
INFO - 2017-02-06 13:25:41 --> Router Class Initialized
INFO - 2017-02-06 13:25:41 --> Output Class Initialized
INFO - 2017-02-06 13:25:41 --> Security Class Initialized
DEBUG - 2017-02-06 13:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:25:41 --> Input Class Initialized
INFO - 2017-02-06 13:25:41 --> Language Class Initialized
ERROR - 2017-02-06 13:25:41 --> 404 Page Not Found: /index
INFO - 2017-02-06 13:25:41 --> Config Class Initialized
INFO - 2017-02-06 13:25:41 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:25:41 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:25:41 --> Utf8 Class Initialized
INFO - 2017-02-06 13:25:41 --> URI Class Initialized
INFO - 2017-02-06 13:25:41 --> Router Class Initialized
INFO - 2017-02-06 13:25:41 --> Output Class Initialized
INFO - 2017-02-06 13:25:41 --> Security Class Initialized
DEBUG - 2017-02-06 13:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:25:41 --> Input Class Initialized
INFO - 2017-02-06 13:25:41 --> Language Class Initialized
ERROR - 2017-02-06 13:25:41 --> 404 Page Not Found: /index
INFO - 2017-02-06 13:25:41 --> Config Class Initialized
INFO - 2017-02-06 13:25:41 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:25:41 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:25:41 --> Utf8 Class Initialized
INFO - 2017-02-06 13:25:41 --> URI Class Initialized
INFO - 2017-02-06 13:25:41 --> Config Class Initialized
INFO - 2017-02-06 13:25:41 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:25:41 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:25:41 --> Utf8 Class Initialized
INFO - 2017-02-06 13:25:41 --> Router Class Initialized
INFO - 2017-02-06 13:25:41 --> Output Class Initialized
INFO - 2017-02-06 13:25:41 --> Security Class Initialized
INFO - 2017-02-06 13:25:41 --> URI Class Initialized
DEBUG - 2017-02-06 13:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:25:41 --> Input Class Initialized
INFO - 2017-02-06 13:25:41 --> Language Class Initialized
ERROR - 2017-02-06 13:25:41 --> 404 Page Not Found: /index
INFO - 2017-02-06 13:25:41 --> Router Class Initialized
INFO - 2017-02-06 13:25:41 --> Output Class Initialized
INFO - 2017-02-06 13:25:41 --> Security Class Initialized
DEBUG - 2017-02-06 13:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:25:41 --> Input Class Initialized
INFO - 2017-02-06 13:25:41 --> Language Class Initialized
ERROR - 2017-02-06 13:25:41 --> 404 Page Not Found: /index
INFO - 2017-02-06 13:25:46 --> Config Class Initialized
INFO - 2017-02-06 13:25:46 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:25:46 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:25:46 --> Utf8 Class Initialized
INFO - 2017-02-06 13:25:46 --> URI Class Initialized
INFO - 2017-02-06 13:25:46 --> Router Class Initialized
INFO - 2017-02-06 13:25:46 --> Output Class Initialized
INFO - 2017-02-06 13:25:46 --> Security Class Initialized
DEBUG - 2017-02-06 13:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:25:46 --> Input Class Initialized
INFO - 2017-02-06 13:25:46 --> Language Class Initialized
INFO - 2017-02-06 13:25:46 --> Language Class Initialized
INFO - 2017-02-06 13:25:46 --> Config Class Initialized
INFO - 2017-02-06 13:25:46 --> Loader Class Initialized
INFO - 2017-02-06 13:25:46 --> Helper loaded: form_helper
INFO - 2017-02-06 13:25:46 --> Helper loaded: url_helper
INFO - 2017-02-06 13:25:46 --> Helper loaded: utility_helper
INFO - 2017-02-06 13:25:46 --> Database Driver Class Initialized
INFO - 2017-02-06 13:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 13:25:46 --> User Agent Class Initialized
DEBUG - 2017-02-06 13:25:46 --> Template Class Initialized
INFO - 2017-02-06 13:25:46 --> Controller Class Initialized
DEBUG - 2017-02-06 13:25:46 --> Login MX_Controller Initialized
INFO - 2017-02-06 13:25:46 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 13:25:46 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 13:25:46 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 13:25:47 --> Final output sent to browser
DEBUG - 2017-02-06 13:25:47 --> Total execution time: 0.1872
INFO - 2017-02-06 13:25:47 --> Config Class Initialized
INFO - 2017-02-06 13:25:47 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:25:47 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:25:47 --> Utf8 Class Initialized
INFO - 2017-02-06 13:25:47 --> URI Class Initialized
INFO - 2017-02-06 13:25:47 --> Router Class Initialized
INFO - 2017-02-06 13:25:47 --> Output Class Initialized
INFO - 2017-02-06 13:25:47 --> Security Class Initialized
DEBUG - 2017-02-06 13:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:25:47 --> Input Class Initialized
INFO - 2017-02-06 13:25:47 --> Language Class Initialized
ERROR - 2017-02-06 13:25:47 --> 404 Page Not Found: /index
INFO - 2017-02-06 13:26:19 --> Config Class Initialized
INFO - 2017-02-06 13:26:19 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:26:19 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:26:19 --> Utf8 Class Initialized
INFO - 2017-02-06 13:26:19 --> URI Class Initialized
INFO - 2017-02-06 13:26:19 --> Router Class Initialized
INFO - 2017-02-06 13:26:19 --> Output Class Initialized
INFO - 2017-02-06 13:26:19 --> Security Class Initialized
DEBUG - 2017-02-06 13:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:26:19 --> Input Class Initialized
INFO - 2017-02-06 13:26:19 --> Language Class Initialized
INFO - 2017-02-06 13:26:19 --> Language Class Initialized
INFO - 2017-02-06 13:26:19 --> Config Class Initialized
INFO - 2017-02-06 13:26:19 --> Loader Class Initialized
INFO - 2017-02-06 13:26:19 --> Helper loaded: form_helper
INFO - 2017-02-06 13:26:19 --> Helper loaded: url_helper
INFO - 2017-02-06 13:26:19 --> Helper loaded: utility_helper
INFO - 2017-02-06 13:26:19 --> Database Driver Class Initialized
INFO - 2017-02-06 13:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 13:26:19 --> User Agent Class Initialized
DEBUG - 2017-02-06 13:26:19 --> Template Class Initialized
INFO - 2017-02-06 13:26:19 --> Controller Class Initialized
DEBUG - 2017-02-06 13:26:19 --> Login MX_Controller Initialized
INFO - 2017-02-06 13:26:19 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 13:26:19 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/signup.php
DEBUG - 2017-02-06 13:26:19 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 13:26:19 --> Final output sent to browser
DEBUG - 2017-02-06 13:26:19 --> Total execution time: 0.0392
INFO - 2017-02-06 13:26:19 --> Config Class Initialized
INFO - 2017-02-06 13:26:19 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:26:19 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:26:19 --> Utf8 Class Initialized
INFO - 2017-02-06 13:26:19 --> URI Class Initialized
INFO - 2017-02-06 13:26:19 --> Router Class Initialized
INFO - 2017-02-06 13:26:19 --> Output Class Initialized
INFO - 2017-02-06 13:26:19 --> Security Class Initialized
DEBUG - 2017-02-06 13:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:26:19 --> Input Class Initialized
INFO - 2017-02-06 13:26:19 --> Language Class Initialized
ERROR - 2017-02-06 13:26:19 --> 404 Page Not Found: /index
INFO - 2017-02-06 13:26:42 --> Config Class Initialized
INFO - 2017-02-06 13:26:42 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:26:42 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:26:42 --> Utf8 Class Initialized
INFO - 2017-02-06 13:26:42 --> URI Class Initialized
INFO - 2017-02-06 13:26:42 --> Router Class Initialized
INFO - 2017-02-06 13:26:42 --> Output Class Initialized
INFO - 2017-02-06 13:26:42 --> Security Class Initialized
DEBUG - 2017-02-06 13:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:26:42 --> Input Class Initialized
INFO - 2017-02-06 13:26:42 --> Language Class Initialized
INFO - 2017-02-06 13:26:42 --> Language Class Initialized
INFO - 2017-02-06 13:26:42 --> Config Class Initialized
INFO - 2017-02-06 13:26:42 --> Loader Class Initialized
INFO - 2017-02-06 13:26:42 --> Helper loaded: form_helper
INFO - 2017-02-06 13:26:42 --> Helper loaded: url_helper
INFO - 2017-02-06 13:26:42 --> Helper loaded: utility_helper
INFO - 2017-02-06 13:26:42 --> Database Driver Class Initialized
INFO - 2017-02-06 13:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 13:26:42 --> User Agent Class Initialized
DEBUG - 2017-02-06 13:26:42 --> Template Class Initialized
INFO - 2017-02-06 13:26:42 --> Controller Class Initialized
DEBUG - 2017-02-06 13:26:42 --> Login MX_Controller Initialized
INFO - 2017-02-06 13:26:42 --> Helper loaded: cookie_helper
INFO - 2017-02-06 13:26:42 --> Model Class Initialized
INFO - 2017-02-06 13:26:42 --> Model Class Initialized
INFO - 2017-02-06 13:26:42 --> Form Validation Class Initialized
INFO - 2017-02-06 13:26:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-06 13:26:42 --> Model Class Initialized
INFO - 2017-02-06 13:26:42 --> Final output sent to browser
DEBUG - 2017-02-06 13:26:42 --> Total execution time: 0.4224
INFO - 2017-02-06 13:26:42 --> Config Class Initialized
INFO - 2017-02-06 13:26:42 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:26:42 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:26:42 --> Utf8 Class Initialized
INFO - 2017-02-06 13:26:42 --> URI Class Initialized
INFO - 2017-02-06 13:26:42 --> Router Class Initialized
INFO - 2017-02-06 13:26:42 --> Output Class Initialized
INFO - 2017-02-06 13:26:42 --> Security Class Initialized
DEBUG - 2017-02-06 13:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:26:42 --> Input Class Initialized
INFO - 2017-02-06 13:26:42 --> Language Class Initialized
INFO - 2017-02-06 13:26:42 --> Language Class Initialized
INFO - 2017-02-06 13:26:42 --> Config Class Initialized
INFO - 2017-02-06 13:26:42 --> Loader Class Initialized
INFO - 2017-02-06 13:26:42 --> Helper loaded: form_helper
INFO - 2017-02-06 13:26:42 --> Helper loaded: url_helper
INFO - 2017-02-06 13:26:42 --> Helper loaded: utility_helper
INFO - 2017-02-06 13:26:42 --> Database Driver Class Initialized
INFO - 2017-02-06 13:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 13:26:42 --> User Agent Class Initialized
DEBUG - 2017-02-06 13:26:42 --> Template Class Initialized
INFO - 2017-02-06 13:26:42 --> Controller Class Initialized
INFO - 2017-02-06 13:26:42 --> Form Validation Class Initialized
DEBUG - 2017-02-06 13:26:42 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/payment.php
INFO - 2017-02-06 13:26:42 --> Final output sent to browser
DEBUG - 2017-02-06 13:26:42 --> Total execution time: 0.0894
INFO - 2017-02-06 13:28:07 --> Config Class Initialized
INFO - 2017-02-06 13:28:07 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:28:07 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:28:07 --> Utf8 Class Initialized
INFO - 2017-02-06 13:28:07 --> URI Class Initialized
INFO - 2017-02-06 13:28:07 --> Router Class Initialized
INFO - 2017-02-06 13:28:07 --> Output Class Initialized
INFO - 2017-02-06 13:28:07 --> Security Class Initialized
DEBUG - 2017-02-06 13:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:28:07 --> Input Class Initialized
INFO - 2017-02-06 13:28:07 --> Language Class Initialized
INFO - 2017-02-06 13:28:07 --> Language Class Initialized
INFO - 2017-02-06 13:28:07 --> Config Class Initialized
INFO - 2017-02-06 13:28:07 --> Loader Class Initialized
INFO - 2017-02-06 13:28:07 --> Helper loaded: form_helper
INFO - 2017-02-06 13:28:07 --> Helper loaded: url_helper
INFO - 2017-02-06 13:28:07 --> Helper loaded: utility_helper
INFO - 2017-02-06 13:28:07 --> Database Driver Class Initialized
INFO - 2017-02-06 13:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 13:28:07 --> User Agent Class Initialized
DEBUG - 2017-02-06 13:28:07 --> Template Class Initialized
INFO - 2017-02-06 13:28:07 --> Controller Class Initialized
INFO - 2017-02-06 13:28:07 --> Form Validation Class Initialized
DEBUG - 2017-02-06 13:28:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/payment.php
INFO - 2017-02-06 13:28:07 --> Final output sent to browser
DEBUG - 2017-02-06 13:28:07 --> Total execution time: 0.0362
INFO - 2017-02-06 13:28:20 --> Config Class Initialized
INFO - 2017-02-06 13:28:20 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:28:20 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:28:20 --> Utf8 Class Initialized
INFO - 2017-02-06 13:28:20 --> URI Class Initialized
INFO - 2017-02-06 13:28:20 --> Router Class Initialized
INFO - 2017-02-06 13:28:20 --> Output Class Initialized
INFO - 2017-02-06 13:28:20 --> Security Class Initialized
DEBUG - 2017-02-06 13:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:28:20 --> Input Class Initialized
INFO - 2017-02-06 13:28:20 --> Language Class Initialized
INFO - 2017-02-06 13:28:20 --> Language Class Initialized
INFO - 2017-02-06 13:28:20 --> Config Class Initialized
INFO - 2017-02-06 13:28:20 --> Loader Class Initialized
INFO - 2017-02-06 13:28:20 --> Helper loaded: form_helper
INFO - 2017-02-06 13:28:20 --> Helper loaded: url_helper
INFO - 2017-02-06 13:28:20 --> Helper loaded: utility_helper
INFO - 2017-02-06 13:28:20 --> Database Driver Class Initialized
INFO - 2017-02-06 13:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 13:28:20 --> User Agent Class Initialized
DEBUG - 2017-02-06 13:28:20 --> Template Class Initialized
INFO - 2017-02-06 13:28:20 --> Controller Class Initialized
INFO - 2017-02-06 13:28:20 --> Form Validation Class Initialized
INFO - 2017-02-06 13:28:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-06 13:28:25 --> Config Class Initialized
INFO - 2017-02-06 13:28:25 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:28:25 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:28:25 --> Utf8 Class Initialized
INFO - 2017-02-06 13:28:25 --> URI Class Initialized
INFO - 2017-02-06 13:28:25 --> Router Class Initialized
INFO - 2017-02-06 13:28:25 --> Output Class Initialized
INFO - 2017-02-06 13:28:25 --> Security Class Initialized
DEBUG - 2017-02-06 13:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:28:25 --> Input Class Initialized
INFO - 2017-02-06 13:28:25 --> Language Class Initialized
ERROR - 2017-02-06 13:28:25 --> 404 Page Not Found: /index
INFO - 2017-02-06 13:28:25 --> Config Class Initialized
INFO - 2017-02-06 13:28:25 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:28:25 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:28:25 --> Utf8 Class Initialized
INFO - 2017-02-06 13:28:25 --> URI Class Initialized
INFO - 2017-02-06 13:28:25 --> Router Class Initialized
INFO - 2017-02-06 13:28:25 --> Output Class Initialized
INFO - 2017-02-06 13:28:25 --> Security Class Initialized
DEBUG - 2017-02-06 13:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:28:25 --> Input Class Initialized
INFO - 2017-02-06 13:28:25 --> Language Class Initialized
ERROR - 2017-02-06 13:28:25 --> 404 Page Not Found: /index
INFO - 2017-02-06 13:28:25 --> Config Class Initialized
INFO - 2017-02-06 13:28:25 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:28:25 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:28:25 --> Utf8 Class Initialized
INFO - 2017-02-06 13:28:25 --> URI Class Initialized
INFO - 2017-02-06 13:28:25 --> Router Class Initialized
INFO - 2017-02-06 13:28:25 --> Output Class Initialized
INFO - 2017-02-06 13:28:25 --> Security Class Initialized
DEBUG - 2017-02-06 13:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:28:25 --> Input Class Initialized
INFO - 2017-02-06 13:28:25 --> Language Class Initialized
ERROR - 2017-02-06 13:28:25 --> 404 Page Not Found: /index
INFO - 2017-02-06 13:49:49 --> Config Class Initialized
INFO - 2017-02-06 13:49:49 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:49:50 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:49:50 --> Utf8 Class Initialized
INFO - 2017-02-06 13:49:50 --> URI Class Initialized
DEBUG - 2017-02-06 13:49:50 --> No URI present. Default controller set.
INFO - 2017-02-06 13:49:50 --> Router Class Initialized
INFO - 2017-02-06 13:49:50 --> Output Class Initialized
INFO - 2017-02-06 13:49:50 --> Security Class Initialized
DEBUG - 2017-02-06 13:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:49:50 --> Input Class Initialized
INFO - 2017-02-06 13:49:50 --> Language Class Initialized
INFO - 2017-02-06 13:49:50 --> Language Class Initialized
INFO - 2017-02-06 13:49:50 --> Config Class Initialized
INFO - 2017-02-06 13:49:50 --> Loader Class Initialized
INFO - 2017-02-06 13:49:50 --> Helper loaded: form_helper
INFO - 2017-02-06 13:49:50 --> Helper loaded: url_helper
INFO - 2017-02-06 13:49:50 --> Helper loaded: utility_helper
INFO - 2017-02-06 13:49:50 --> Database Driver Class Initialized
INFO - 2017-02-06 13:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 13:49:50 --> User Agent Class Initialized
DEBUG - 2017-02-06 13:49:50 --> Template Class Initialized
INFO - 2017-02-06 13:49:50 --> Controller Class Initialized
INFO - 2017-02-06 13:49:50 --> Form Validation Class Initialized
DEBUG - 2017-02-06 13:49:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-06 13:49:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-06 13:49:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-06 13:49:50 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 13:49:50 --> Final output sent to browser
DEBUG - 2017-02-06 13:49:50 --> Total execution time: 0.2491
INFO - 2017-02-06 13:49:50 --> Config Class Initialized
INFO - 2017-02-06 13:49:50 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:49:50 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:49:50 --> Utf8 Class Initialized
INFO - 2017-02-06 13:49:50 --> URI Class Initialized
INFO - 2017-02-06 13:49:50 --> Router Class Initialized
INFO - 2017-02-06 13:49:50 --> Output Class Initialized
INFO - 2017-02-06 13:49:50 --> Security Class Initialized
DEBUG - 2017-02-06 13:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:49:50 --> Input Class Initialized
INFO - 2017-02-06 13:49:50 --> Language Class Initialized
ERROR - 2017-02-06 13:49:50 --> 404 Page Not Found: /index
INFO - 2017-02-06 13:49:51 --> Config Class Initialized
INFO - 2017-02-06 13:49:51 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:49:51 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:49:51 --> Utf8 Class Initialized
INFO - 2017-02-06 13:49:51 --> URI Class Initialized
INFO - 2017-02-06 13:49:51 --> Router Class Initialized
INFO - 2017-02-06 13:49:51 --> Output Class Initialized
INFO - 2017-02-06 13:49:51 --> Security Class Initialized
DEBUG - 2017-02-06 13:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:49:51 --> Input Class Initialized
INFO - 2017-02-06 13:49:51 --> Language Class Initialized
ERROR - 2017-02-06 13:49:51 --> 404 Page Not Found: /index
INFO - 2017-02-06 13:52:12 --> Config Class Initialized
INFO - 2017-02-06 13:52:12 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:52:12 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:52:12 --> Utf8 Class Initialized
INFO - 2017-02-06 13:52:12 --> URI Class Initialized
INFO - 2017-02-06 13:52:12 --> Router Class Initialized
INFO - 2017-02-06 13:52:12 --> Output Class Initialized
INFO - 2017-02-06 13:52:12 --> Security Class Initialized
DEBUG - 2017-02-06 13:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:52:12 --> Input Class Initialized
INFO - 2017-02-06 13:52:12 --> Language Class Initialized
INFO - 2017-02-06 13:52:12 --> Language Class Initialized
INFO - 2017-02-06 13:52:12 --> Config Class Initialized
INFO - 2017-02-06 13:52:12 --> Loader Class Initialized
INFO - 2017-02-06 13:52:12 --> Helper loaded: form_helper
INFO - 2017-02-06 13:52:12 --> Helper loaded: url_helper
INFO - 2017-02-06 13:52:12 --> Helper loaded: utility_helper
INFO - 2017-02-06 13:52:12 --> Database Driver Class Initialized
INFO - 2017-02-06 13:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 13:52:12 --> User Agent Class Initialized
DEBUG - 2017-02-06 13:52:12 --> Template Class Initialized
INFO - 2017-02-06 13:52:12 --> Controller Class Initialized
DEBUG - 2017-02-06 13:52:12 --> Login MX_Controller Initialized
INFO - 2017-02-06 13:52:12 --> Helper loaded: cookie_helper
DEBUG - 2017-02-06 13:52:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/login.php
DEBUG - 2017-02-06 13:52:12 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 13:52:12 --> Final output sent to browser
DEBUG - 2017-02-06 13:52:12 --> Total execution time: 0.1669
INFO - 2017-02-06 13:52:12 --> Config Class Initialized
INFO - 2017-02-06 13:52:12 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:52:12 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:52:12 --> Utf8 Class Initialized
INFO - 2017-02-06 13:52:12 --> URI Class Initialized
INFO - 2017-02-06 13:52:12 --> Router Class Initialized
INFO - 2017-02-06 13:52:12 --> Output Class Initialized
INFO - 2017-02-06 13:52:12 --> Security Class Initialized
DEBUG - 2017-02-06 13:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:52:12 --> Input Class Initialized
INFO - 2017-02-06 13:52:12 --> Language Class Initialized
ERROR - 2017-02-06 13:52:12 --> 404 Page Not Found: /index
INFO - 2017-02-06 13:52:13 --> Config Class Initialized
INFO - 2017-02-06 13:52:13 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:52:13 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:52:13 --> Utf8 Class Initialized
INFO - 2017-02-06 13:52:13 --> URI Class Initialized
INFO - 2017-02-06 13:52:13 --> Router Class Initialized
INFO - 2017-02-06 13:52:13 --> Output Class Initialized
INFO - 2017-02-06 13:52:13 --> Security Class Initialized
DEBUG - 2017-02-06 13:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:52:13 --> Input Class Initialized
INFO - 2017-02-06 13:52:13 --> Language Class Initialized
ERROR - 2017-02-06 13:52:13 --> 404 Page Not Found: /index
INFO - 2017-02-06 13:52:13 --> Config Class Initialized
INFO - 2017-02-06 13:52:13 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:52:13 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:52:13 --> Utf8 Class Initialized
INFO - 2017-02-06 13:52:13 --> URI Class Initialized
INFO - 2017-02-06 13:52:13 --> Router Class Initialized
INFO - 2017-02-06 13:52:13 --> Output Class Initialized
INFO - 2017-02-06 13:52:13 --> Security Class Initialized
DEBUG - 2017-02-06 13:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:52:13 --> Input Class Initialized
INFO - 2017-02-06 13:52:13 --> Language Class Initialized
ERROR - 2017-02-06 13:52:13 --> 404 Page Not Found: /index
INFO - 2017-02-06 13:52:13 --> Config Class Initialized
INFO - 2017-02-06 13:52:13 --> Hooks Class Initialized
DEBUG - 2017-02-06 13:52:13 --> UTF-8 Support Enabled
INFO - 2017-02-06 13:52:13 --> Utf8 Class Initialized
INFO - 2017-02-06 13:52:13 --> URI Class Initialized
INFO - 2017-02-06 13:52:13 --> Router Class Initialized
INFO - 2017-02-06 13:52:13 --> Output Class Initialized
INFO - 2017-02-06 13:52:13 --> Security Class Initialized
DEBUG - 2017-02-06 13:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 13:52:13 --> Input Class Initialized
INFO - 2017-02-06 13:52:13 --> Language Class Initialized
ERROR - 2017-02-06 13:52:13 --> 404 Page Not Found: /index
INFO - 2017-02-06 15:51:08 --> Config Class Initialized
INFO - 2017-02-06 15:51:08 --> Hooks Class Initialized
DEBUG - 2017-02-06 15:51:08 --> UTF-8 Support Enabled
INFO - 2017-02-06 15:51:08 --> Utf8 Class Initialized
INFO - 2017-02-06 15:51:08 --> URI Class Initialized
DEBUG - 2017-02-06 15:51:09 --> No URI present. Default controller set.
INFO - 2017-02-06 15:51:09 --> Router Class Initialized
INFO - 2017-02-06 15:51:09 --> Output Class Initialized
INFO - 2017-02-06 15:51:09 --> Security Class Initialized
DEBUG - 2017-02-06 15:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 15:51:09 --> Input Class Initialized
INFO - 2017-02-06 15:51:09 --> Language Class Initialized
INFO - 2017-02-06 15:51:09 --> Language Class Initialized
INFO - 2017-02-06 15:51:09 --> Config Class Initialized
INFO - 2017-02-06 15:51:09 --> Loader Class Initialized
INFO - 2017-02-06 15:51:09 --> Helper loaded: form_helper
INFO - 2017-02-06 15:51:09 --> Helper loaded: url_helper
INFO - 2017-02-06 15:51:09 --> Helper loaded: utility_helper
INFO - 2017-02-06 15:51:09 --> Database Driver Class Initialized
INFO - 2017-02-06 15:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-06 15:51:09 --> User Agent Class Initialized
DEBUG - 2017-02-06 15:51:09 --> Template Class Initialized
INFO - 2017-02-06 15:51:09 --> Controller Class Initialized
INFO - 2017-02-06 15:51:09 --> Form Validation Class Initialized
DEBUG - 2017-02-06 15:51:09 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-06 15:51:09 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-06 15:51:09 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-06 15:51:09 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-06 15:51:09 --> Final output sent to browser
DEBUG - 2017-02-06 15:51:09 --> Total execution time: 1.3114
INFO - 2017-02-06 15:51:10 --> Config Class Initialized
INFO - 2017-02-06 15:51:10 --> Hooks Class Initialized
DEBUG - 2017-02-06 15:51:11 --> UTF-8 Support Enabled
INFO - 2017-02-06 15:51:11 --> Utf8 Class Initialized
INFO - 2017-02-06 15:51:11 --> URI Class Initialized
INFO - 2017-02-06 15:51:11 --> Router Class Initialized
INFO - 2017-02-06 15:51:11 --> Output Class Initialized
INFO - 2017-02-06 15:51:11 --> Security Class Initialized
DEBUG - 2017-02-06 15:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 15:51:11 --> Input Class Initialized
INFO - 2017-02-06 15:51:11 --> Language Class Initialized
ERROR - 2017-02-06 15:51:11 --> 404 Page Not Found: /index
INFO - 2017-02-06 16:31:05 --> Config Class Initialized
INFO - 2017-02-06 16:31:05 --> Hooks Class Initialized
DEBUG - 2017-02-06 16:31:05 --> UTF-8 Support Enabled
INFO - 2017-02-06 16:31:05 --> Utf8 Class Initialized
INFO - 2017-02-06 16:31:05 --> URI Class Initialized
INFO - 2017-02-06 16:31:05 --> Router Class Initialized
INFO - 2017-02-06 16:31:05 --> Output Class Initialized
INFO - 2017-02-06 16:31:05 --> Security Class Initialized
DEBUG - 2017-02-06 16:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-06 16:31:05 --> Input Class Initialized
INFO - 2017-02-06 16:31:05 --> Language Class Initialized
ERROR - 2017-02-06 16:31:05 --> 404 Page Not Found: ../modules/frontend/controllers/Dashboard/index
