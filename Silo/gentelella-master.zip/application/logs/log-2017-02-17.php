<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-17 11:26:44 --> Config Class Initialized
INFO - 2017-02-17 11:26:44 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:26:44 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:26:44 --> Utf8 Class Initialized
INFO - 2017-02-17 11:26:44 --> URI Class Initialized
DEBUG - 2017-02-17 11:26:44 --> No URI present. Default controller set.
INFO - 2017-02-17 11:26:44 --> Router Class Initialized
INFO - 2017-02-17 11:26:44 --> Output Class Initialized
INFO - 2017-02-17 11:26:44 --> Security Class Initialized
DEBUG - 2017-02-17 11:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:26:44 --> Input Class Initialized
INFO - 2017-02-17 11:26:44 --> Language Class Initialized
INFO - 2017-02-17 11:26:44 --> Language Class Initialized
INFO - 2017-02-17 11:26:44 --> Config Class Initialized
INFO - 2017-02-17 11:26:44 --> Loader Class Initialized
INFO - 2017-02-17 11:26:44 --> Helper loaded: form_helper
INFO - 2017-02-17 11:26:44 --> Helper loaded: url_helper
INFO - 2017-02-17 11:26:44 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:26:44 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:26:45 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:26:45 --> Template Class Initialized
INFO - 2017-02-17 11:26:45 --> Controller Class Initialized
DEBUG - 2017-02-17 11:26:45 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:26:45 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:26:45 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:26:45 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:26:45 --> Final output sent to browser
DEBUG - 2017-02-17 11:26:45 --> Total execution time: 1.7455
INFO - 2017-02-17 11:28:00 --> Config Class Initialized
INFO - 2017-02-17 11:28:00 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:28:00 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:28:00 --> Utf8 Class Initialized
INFO - 2017-02-17 11:28:00 --> URI Class Initialized
DEBUG - 2017-02-17 11:28:00 --> No URI present. Default controller set.
INFO - 2017-02-17 11:28:00 --> Router Class Initialized
INFO - 2017-02-17 11:28:00 --> Output Class Initialized
INFO - 2017-02-17 11:28:00 --> Security Class Initialized
DEBUG - 2017-02-17 11:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:28:00 --> Input Class Initialized
INFO - 2017-02-17 11:28:00 --> Language Class Initialized
INFO - 2017-02-17 11:28:00 --> Language Class Initialized
INFO - 2017-02-17 11:28:00 --> Config Class Initialized
INFO - 2017-02-17 11:28:00 --> Loader Class Initialized
INFO - 2017-02-17 11:28:00 --> Helper loaded: form_helper
INFO - 2017-02-17 11:28:00 --> Helper loaded: url_helper
INFO - 2017-02-17 11:28:00 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:28:00 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:28:00 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:28:00 --> Template Class Initialized
INFO - 2017-02-17 11:28:00 --> Controller Class Initialized
DEBUG - 2017-02-17 11:28:00 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:28:00 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:28:00 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:28:00 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:28:00 --> Final output sent to browser
DEBUG - 2017-02-17 11:28:00 --> Total execution time: 0.1441
INFO - 2017-02-17 11:28:01 --> Config Class Initialized
INFO - 2017-02-17 11:28:01 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:28:01 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:28:01 --> Utf8 Class Initialized
INFO - 2017-02-17 11:28:01 --> URI Class Initialized
DEBUG - 2017-02-17 11:28:01 --> No URI present. Default controller set.
INFO - 2017-02-17 11:28:01 --> Router Class Initialized
INFO - 2017-02-17 11:28:01 --> Output Class Initialized
INFO - 2017-02-17 11:28:01 --> Security Class Initialized
DEBUG - 2017-02-17 11:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:28:01 --> Input Class Initialized
INFO - 2017-02-17 11:28:01 --> Language Class Initialized
INFO - 2017-02-17 11:28:01 --> Language Class Initialized
INFO - 2017-02-17 11:28:01 --> Config Class Initialized
INFO - 2017-02-17 11:28:01 --> Loader Class Initialized
INFO - 2017-02-17 11:28:01 --> Helper loaded: form_helper
INFO - 2017-02-17 11:28:01 --> Helper loaded: url_helper
INFO - 2017-02-17 11:28:01 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:28:01 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:28:01 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:28:01 --> Template Class Initialized
INFO - 2017-02-17 11:28:01 --> Controller Class Initialized
DEBUG - 2017-02-17 11:28:01 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:28:01 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:28:01 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:28:01 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:28:01 --> Final output sent to browser
DEBUG - 2017-02-17 11:28:01 --> Total execution time: 0.1304
INFO - 2017-02-17 11:28:30 --> Config Class Initialized
INFO - 2017-02-17 11:28:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:28:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:28:30 --> Utf8 Class Initialized
INFO - 2017-02-17 11:28:30 --> URI Class Initialized
DEBUG - 2017-02-17 11:28:30 --> No URI present. Default controller set.
INFO - 2017-02-17 11:28:30 --> Router Class Initialized
INFO - 2017-02-17 11:28:30 --> Output Class Initialized
INFO - 2017-02-17 11:28:30 --> Security Class Initialized
DEBUG - 2017-02-17 11:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:28:30 --> Input Class Initialized
INFO - 2017-02-17 11:28:30 --> Language Class Initialized
INFO - 2017-02-17 11:28:30 --> Language Class Initialized
INFO - 2017-02-17 11:28:30 --> Config Class Initialized
INFO - 2017-02-17 11:28:30 --> Loader Class Initialized
INFO - 2017-02-17 11:28:30 --> Helper loaded: form_helper
INFO - 2017-02-17 11:28:30 --> Helper loaded: url_helper
INFO - 2017-02-17 11:28:30 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:28:30 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:28:31 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:28:31 --> Template Class Initialized
INFO - 2017-02-17 11:28:31 --> Controller Class Initialized
DEBUG - 2017-02-17 11:28:31 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:28:31 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:28:31 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:28:31 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:28:31 --> Final output sent to browser
DEBUG - 2017-02-17 11:28:31 --> Total execution time: 0.3553
INFO - 2017-02-17 11:28:56 --> Config Class Initialized
INFO - 2017-02-17 11:28:56 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:28:56 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:28:56 --> Utf8 Class Initialized
INFO - 2017-02-17 11:28:56 --> URI Class Initialized
DEBUG - 2017-02-17 11:28:56 --> No URI present. Default controller set.
INFO - 2017-02-17 11:28:56 --> Router Class Initialized
INFO - 2017-02-17 11:28:56 --> Output Class Initialized
INFO - 2017-02-17 11:28:56 --> Security Class Initialized
DEBUG - 2017-02-17 11:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:28:56 --> Input Class Initialized
INFO - 2017-02-17 11:28:56 --> Language Class Initialized
INFO - 2017-02-17 11:28:56 --> Language Class Initialized
INFO - 2017-02-17 11:28:56 --> Config Class Initialized
INFO - 2017-02-17 11:28:56 --> Loader Class Initialized
INFO - 2017-02-17 11:28:56 --> Helper loaded: form_helper
INFO - 2017-02-17 11:28:56 --> Helper loaded: url_helper
INFO - 2017-02-17 11:28:56 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:28:56 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:28:56 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:28:56 --> Template Class Initialized
INFO - 2017-02-17 11:28:56 --> Controller Class Initialized
DEBUG - 2017-02-17 11:28:56 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:28:56 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:28:56 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:28:56 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:28:56 --> Final output sent to browser
DEBUG - 2017-02-17 11:28:56 --> Total execution time: 0.0759
INFO - 2017-02-17 11:29:34 --> Config Class Initialized
INFO - 2017-02-17 11:29:34 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:29:34 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:29:34 --> Utf8 Class Initialized
INFO - 2017-02-17 11:29:34 --> URI Class Initialized
DEBUG - 2017-02-17 11:29:34 --> No URI present. Default controller set.
INFO - 2017-02-17 11:29:34 --> Router Class Initialized
INFO - 2017-02-17 11:29:34 --> Output Class Initialized
INFO - 2017-02-17 11:29:34 --> Security Class Initialized
DEBUG - 2017-02-17 11:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:29:34 --> Input Class Initialized
INFO - 2017-02-17 11:29:34 --> Language Class Initialized
INFO - 2017-02-17 11:29:34 --> Language Class Initialized
INFO - 2017-02-17 11:29:34 --> Config Class Initialized
INFO - 2017-02-17 11:29:34 --> Loader Class Initialized
INFO - 2017-02-17 11:29:34 --> Helper loaded: form_helper
INFO - 2017-02-17 11:29:34 --> Helper loaded: url_helper
INFO - 2017-02-17 11:29:34 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:29:34 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:29:34 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:29:34 --> Template Class Initialized
INFO - 2017-02-17 11:29:34 --> Controller Class Initialized
DEBUG - 2017-02-17 11:29:34 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:29:34 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:29:34 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:29:34 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:29:34 --> Final output sent to browser
DEBUG - 2017-02-17 11:29:34 --> Total execution time: 0.1176
INFO - 2017-02-17 11:30:52 --> Config Class Initialized
INFO - 2017-02-17 11:30:52 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:30:52 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:30:52 --> Utf8 Class Initialized
INFO - 2017-02-17 11:30:52 --> URI Class Initialized
DEBUG - 2017-02-17 11:30:52 --> No URI present. Default controller set.
INFO - 2017-02-17 11:30:52 --> Router Class Initialized
INFO - 2017-02-17 11:30:52 --> Output Class Initialized
INFO - 2017-02-17 11:30:52 --> Security Class Initialized
DEBUG - 2017-02-17 11:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:30:52 --> Input Class Initialized
INFO - 2017-02-17 11:30:52 --> Language Class Initialized
INFO - 2017-02-17 11:30:52 --> Language Class Initialized
INFO - 2017-02-17 11:30:52 --> Config Class Initialized
INFO - 2017-02-17 11:30:52 --> Loader Class Initialized
INFO - 2017-02-17 11:30:52 --> Helper loaded: form_helper
INFO - 2017-02-17 11:30:52 --> Helper loaded: url_helper
INFO - 2017-02-17 11:30:52 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:30:52 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:30:52 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:30:52 --> Template Class Initialized
INFO - 2017-02-17 11:30:52 --> Controller Class Initialized
DEBUG - 2017-02-17 11:30:52 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:30:52 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:30:52 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
ERROR - 2017-02-17 11:30:52 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\default.php 14
INFO - 2017-02-17 11:30:53 --> Config Class Initialized
INFO - 2017-02-17 11:30:53 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:30:53 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:30:53 --> Utf8 Class Initialized
INFO - 2017-02-17 11:30:53 --> URI Class Initialized
DEBUG - 2017-02-17 11:30:53 --> No URI present. Default controller set.
INFO - 2017-02-17 11:30:53 --> Router Class Initialized
INFO - 2017-02-17 11:30:53 --> Output Class Initialized
INFO - 2017-02-17 11:30:53 --> Security Class Initialized
DEBUG - 2017-02-17 11:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:30:53 --> Input Class Initialized
INFO - 2017-02-17 11:30:53 --> Language Class Initialized
INFO - 2017-02-17 11:30:53 --> Language Class Initialized
INFO - 2017-02-17 11:30:53 --> Config Class Initialized
INFO - 2017-02-17 11:30:53 --> Loader Class Initialized
INFO - 2017-02-17 11:30:53 --> Helper loaded: form_helper
INFO - 2017-02-17 11:30:53 --> Helper loaded: url_helper
INFO - 2017-02-17 11:30:53 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:30:53 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:30:53 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:30:53 --> Template Class Initialized
INFO - 2017-02-17 11:30:53 --> Controller Class Initialized
DEBUG - 2017-02-17 11:30:53 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:30:53 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:30:53 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
ERROR - 2017-02-17 11:30:53 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\default.php 14
INFO - 2017-02-17 11:31:22 --> Config Class Initialized
INFO - 2017-02-17 11:31:22 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:31:22 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:31:22 --> Utf8 Class Initialized
INFO - 2017-02-17 11:31:22 --> URI Class Initialized
DEBUG - 2017-02-17 11:31:22 --> No URI present. Default controller set.
INFO - 2017-02-17 11:31:22 --> Router Class Initialized
INFO - 2017-02-17 11:31:22 --> Output Class Initialized
INFO - 2017-02-17 11:31:22 --> Security Class Initialized
DEBUG - 2017-02-17 11:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:31:22 --> Input Class Initialized
INFO - 2017-02-17 11:31:22 --> Language Class Initialized
INFO - 2017-02-17 11:31:22 --> Language Class Initialized
INFO - 2017-02-17 11:31:22 --> Config Class Initialized
INFO - 2017-02-17 11:31:22 --> Loader Class Initialized
INFO - 2017-02-17 11:31:22 --> Helper loaded: form_helper
INFO - 2017-02-17 11:31:22 --> Helper loaded: url_helper
INFO - 2017-02-17 11:31:22 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:31:22 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:31:22 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:31:22 --> Template Class Initialized
INFO - 2017-02-17 11:31:22 --> Controller Class Initialized
DEBUG - 2017-02-17 11:31:22 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:31:22 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:31:22 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
ERROR - 2017-02-17 11:31:22 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\default.php 14
INFO - 2017-02-17 11:31:23 --> Config Class Initialized
INFO - 2017-02-17 11:31:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:31:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:31:23 --> Utf8 Class Initialized
INFO - 2017-02-17 11:31:23 --> URI Class Initialized
DEBUG - 2017-02-17 11:31:23 --> No URI present. Default controller set.
INFO - 2017-02-17 11:31:23 --> Router Class Initialized
INFO - 2017-02-17 11:31:23 --> Output Class Initialized
INFO - 2017-02-17 11:31:23 --> Security Class Initialized
DEBUG - 2017-02-17 11:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:31:23 --> Input Class Initialized
INFO - 2017-02-17 11:31:23 --> Language Class Initialized
INFO - 2017-02-17 11:31:23 --> Language Class Initialized
INFO - 2017-02-17 11:31:23 --> Config Class Initialized
INFO - 2017-02-17 11:31:23 --> Loader Class Initialized
INFO - 2017-02-17 11:31:23 --> Helper loaded: form_helper
INFO - 2017-02-17 11:31:23 --> Helper loaded: url_helper
INFO - 2017-02-17 11:31:23 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:31:24 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:31:24 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:31:24 --> Template Class Initialized
INFO - 2017-02-17 11:31:24 --> Controller Class Initialized
DEBUG - 2017-02-17 11:31:24 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:31:24 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:31:24 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
ERROR - 2017-02-17 11:31:24 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\default.php 14
INFO - 2017-02-17 11:31:39 --> Config Class Initialized
INFO - 2017-02-17 11:31:39 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:31:39 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:31:39 --> Utf8 Class Initialized
INFO - 2017-02-17 11:31:39 --> URI Class Initialized
DEBUG - 2017-02-17 11:31:39 --> No URI present. Default controller set.
INFO - 2017-02-17 11:31:39 --> Router Class Initialized
INFO - 2017-02-17 11:31:39 --> Output Class Initialized
INFO - 2017-02-17 11:31:39 --> Security Class Initialized
DEBUG - 2017-02-17 11:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:31:39 --> Input Class Initialized
INFO - 2017-02-17 11:31:39 --> Language Class Initialized
INFO - 2017-02-17 11:31:39 --> Language Class Initialized
INFO - 2017-02-17 11:31:39 --> Config Class Initialized
INFO - 2017-02-17 11:31:39 --> Loader Class Initialized
INFO - 2017-02-17 11:31:39 --> Helper loaded: form_helper
INFO - 2017-02-17 11:31:39 --> Helper loaded: url_helper
INFO - 2017-02-17 11:31:39 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:31:39 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:31:39 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:31:39 --> Template Class Initialized
INFO - 2017-02-17 11:31:39 --> Controller Class Initialized
DEBUG - 2017-02-17 11:31:39 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:31:39 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:31:39 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
ERROR - 2017-02-17 11:31:39 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\default.php 14
INFO - 2017-02-17 11:31:54 --> Config Class Initialized
INFO - 2017-02-17 11:31:54 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:31:54 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:31:54 --> Utf8 Class Initialized
INFO - 2017-02-17 11:31:54 --> URI Class Initialized
DEBUG - 2017-02-17 11:31:54 --> No URI present. Default controller set.
INFO - 2017-02-17 11:31:54 --> Router Class Initialized
INFO - 2017-02-17 11:31:54 --> Output Class Initialized
INFO - 2017-02-17 11:31:54 --> Security Class Initialized
DEBUG - 2017-02-17 11:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:31:54 --> Input Class Initialized
INFO - 2017-02-17 11:31:54 --> Language Class Initialized
INFO - 2017-02-17 11:31:54 --> Language Class Initialized
INFO - 2017-02-17 11:31:54 --> Config Class Initialized
INFO - 2017-02-17 11:31:54 --> Loader Class Initialized
INFO - 2017-02-17 11:31:54 --> Helper loaded: form_helper
INFO - 2017-02-17 11:31:54 --> Helper loaded: url_helper
INFO - 2017-02-17 11:31:54 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:31:54 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:31:54 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:31:54 --> Template Class Initialized
INFO - 2017-02-17 11:31:54 --> Controller Class Initialized
DEBUG - 2017-02-17 11:31:54 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:31:54 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:31:54 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
ERROR - 2017-02-17 11:31:54 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\default.php 52
INFO - 2017-02-17 11:33:15 --> Config Class Initialized
INFO - 2017-02-17 11:33:15 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:33:15 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:33:15 --> Utf8 Class Initialized
INFO - 2017-02-17 11:33:15 --> URI Class Initialized
DEBUG - 2017-02-17 11:33:15 --> No URI present. Default controller set.
INFO - 2017-02-17 11:33:15 --> Router Class Initialized
INFO - 2017-02-17 11:33:15 --> Output Class Initialized
INFO - 2017-02-17 11:33:15 --> Security Class Initialized
DEBUG - 2017-02-17 11:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:33:15 --> Input Class Initialized
INFO - 2017-02-17 11:33:15 --> Language Class Initialized
INFO - 2017-02-17 11:33:15 --> Language Class Initialized
INFO - 2017-02-17 11:33:15 --> Config Class Initialized
INFO - 2017-02-17 11:33:15 --> Loader Class Initialized
INFO - 2017-02-17 11:33:15 --> Helper loaded: form_helper
INFO - 2017-02-17 11:33:15 --> Helper loaded: url_helper
INFO - 2017-02-17 11:33:15 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:33:15 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:33:15 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:33:15 --> Template Class Initialized
INFO - 2017-02-17 11:33:15 --> Controller Class Initialized
DEBUG - 2017-02-17 11:33:15 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:33:15 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:33:15 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
ERROR - 2017-02-17 11:33:15 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\default.php 52
INFO - 2017-02-17 11:35:19 --> Config Class Initialized
INFO - 2017-02-17 11:35:19 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:35:19 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:35:19 --> Utf8 Class Initialized
INFO - 2017-02-17 11:35:19 --> URI Class Initialized
DEBUG - 2017-02-17 11:35:19 --> No URI present. Default controller set.
INFO - 2017-02-17 11:35:19 --> Router Class Initialized
INFO - 2017-02-17 11:35:19 --> Output Class Initialized
INFO - 2017-02-17 11:35:19 --> Security Class Initialized
DEBUG - 2017-02-17 11:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:35:19 --> Input Class Initialized
INFO - 2017-02-17 11:35:19 --> Language Class Initialized
INFO - 2017-02-17 11:35:19 --> Language Class Initialized
INFO - 2017-02-17 11:35:19 --> Config Class Initialized
INFO - 2017-02-17 11:35:19 --> Loader Class Initialized
INFO - 2017-02-17 11:35:19 --> Helper loaded: form_helper
INFO - 2017-02-17 11:35:19 --> Helper loaded: url_helper
INFO - 2017-02-17 11:35:19 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:35:19 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:35:19 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:35:19 --> Template Class Initialized
INFO - 2017-02-17 11:35:19 --> Controller Class Initialized
DEBUG - 2017-02-17 11:35:19 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:35:19 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:35:19 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
ERROR - 2017-02-17 11:35:19 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\default.php 52
INFO - 2017-02-17 11:37:07 --> Config Class Initialized
INFO - 2017-02-17 11:37:07 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:37:07 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:37:07 --> Utf8 Class Initialized
INFO - 2017-02-17 11:37:07 --> URI Class Initialized
DEBUG - 2017-02-17 11:37:07 --> No URI present. Default controller set.
INFO - 2017-02-17 11:37:07 --> Router Class Initialized
INFO - 2017-02-17 11:37:07 --> Output Class Initialized
INFO - 2017-02-17 11:37:07 --> Security Class Initialized
DEBUG - 2017-02-17 11:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:37:07 --> Input Class Initialized
INFO - 2017-02-17 11:37:07 --> Language Class Initialized
INFO - 2017-02-17 11:37:07 --> Language Class Initialized
INFO - 2017-02-17 11:37:07 --> Config Class Initialized
INFO - 2017-02-17 11:37:07 --> Loader Class Initialized
INFO - 2017-02-17 11:37:07 --> Helper loaded: form_helper
INFO - 2017-02-17 11:37:07 --> Helper loaded: url_helper
INFO - 2017-02-17 11:37:07 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:37:07 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:37:07 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:37:07 --> Template Class Initialized
INFO - 2017-02-17 11:37:07 --> Controller Class Initialized
DEBUG - 2017-02-17 11:37:07 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:37:07 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:37:07 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
ERROR - 2017-02-17 11:37:07 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\default.php 52
INFO - 2017-02-17 11:37:08 --> Config Class Initialized
INFO - 2017-02-17 11:37:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:37:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:37:08 --> Utf8 Class Initialized
INFO - 2017-02-17 11:37:08 --> URI Class Initialized
DEBUG - 2017-02-17 11:37:08 --> No URI present. Default controller set.
INFO - 2017-02-17 11:37:08 --> Router Class Initialized
INFO - 2017-02-17 11:37:08 --> Output Class Initialized
INFO - 2017-02-17 11:37:08 --> Security Class Initialized
DEBUG - 2017-02-17 11:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:37:08 --> Input Class Initialized
INFO - 2017-02-17 11:37:08 --> Language Class Initialized
INFO - 2017-02-17 11:37:08 --> Language Class Initialized
INFO - 2017-02-17 11:37:08 --> Config Class Initialized
INFO - 2017-02-17 11:37:08 --> Loader Class Initialized
INFO - 2017-02-17 11:37:08 --> Helper loaded: form_helper
INFO - 2017-02-17 11:37:08 --> Helper loaded: url_helper
INFO - 2017-02-17 11:37:08 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:37:08 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:37:08 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:37:08 --> Template Class Initialized
INFO - 2017-02-17 11:37:08 --> Controller Class Initialized
DEBUG - 2017-02-17 11:37:08 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:37:08 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:37:08 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
ERROR - 2017-02-17 11:37:08 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\default.php 52
INFO - 2017-02-17 11:37:09 --> Config Class Initialized
INFO - 2017-02-17 11:37:09 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:37:09 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:37:09 --> Utf8 Class Initialized
INFO - 2017-02-17 11:37:09 --> URI Class Initialized
DEBUG - 2017-02-17 11:37:09 --> No URI present. Default controller set.
INFO - 2017-02-17 11:37:09 --> Router Class Initialized
INFO - 2017-02-17 11:37:09 --> Output Class Initialized
INFO - 2017-02-17 11:37:09 --> Security Class Initialized
DEBUG - 2017-02-17 11:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:37:09 --> Input Class Initialized
INFO - 2017-02-17 11:37:09 --> Language Class Initialized
INFO - 2017-02-17 11:37:09 --> Language Class Initialized
INFO - 2017-02-17 11:37:09 --> Config Class Initialized
INFO - 2017-02-17 11:37:09 --> Loader Class Initialized
INFO - 2017-02-17 11:37:09 --> Helper loaded: form_helper
INFO - 2017-02-17 11:37:09 --> Helper loaded: url_helper
INFO - 2017-02-17 11:37:09 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:37:09 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:37:09 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:37:09 --> Template Class Initialized
INFO - 2017-02-17 11:37:09 --> Controller Class Initialized
DEBUG - 2017-02-17 11:37:09 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:37:09 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:37:09 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
ERROR - 2017-02-17 11:37:09 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\default.php 52
INFO - 2017-02-17 11:37:09 --> Config Class Initialized
INFO - 2017-02-17 11:37:09 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:37:09 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:37:09 --> Utf8 Class Initialized
INFO - 2017-02-17 11:37:09 --> URI Class Initialized
DEBUG - 2017-02-17 11:37:09 --> No URI present. Default controller set.
INFO - 2017-02-17 11:37:09 --> Router Class Initialized
INFO - 2017-02-17 11:37:09 --> Output Class Initialized
INFO - 2017-02-17 11:37:09 --> Security Class Initialized
DEBUG - 2017-02-17 11:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:37:09 --> Input Class Initialized
INFO - 2017-02-17 11:37:09 --> Language Class Initialized
INFO - 2017-02-17 11:37:09 --> Language Class Initialized
INFO - 2017-02-17 11:37:09 --> Config Class Initialized
INFO - 2017-02-17 11:37:09 --> Loader Class Initialized
INFO - 2017-02-17 11:37:09 --> Helper loaded: form_helper
INFO - 2017-02-17 11:37:09 --> Helper loaded: url_helper
INFO - 2017-02-17 11:37:09 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:37:09 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:37:09 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:37:09 --> Template Class Initialized
INFO - 2017-02-17 11:37:09 --> Controller Class Initialized
DEBUG - 2017-02-17 11:37:09 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:37:09 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:37:09 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
ERROR - 2017-02-17 11:37:09 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\default.php 52
INFO - 2017-02-17 11:37:12 --> Config Class Initialized
INFO - 2017-02-17 11:37:12 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:37:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:37:12 --> Utf8 Class Initialized
INFO - 2017-02-17 11:37:12 --> URI Class Initialized
DEBUG - 2017-02-17 11:37:12 --> No URI present. Default controller set.
INFO - 2017-02-17 11:37:12 --> Router Class Initialized
INFO - 2017-02-17 11:37:12 --> Output Class Initialized
INFO - 2017-02-17 11:37:12 --> Security Class Initialized
DEBUG - 2017-02-17 11:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:37:12 --> Input Class Initialized
INFO - 2017-02-17 11:37:12 --> Language Class Initialized
INFO - 2017-02-17 11:37:12 --> Language Class Initialized
INFO - 2017-02-17 11:37:12 --> Config Class Initialized
INFO - 2017-02-17 11:37:12 --> Loader Class Initialized
INFO - 2017-02-17 11:37:12 --> Helper loaded: form_helper
INFO - 2017-02-17 11:37:12 --> Helper loaded: url_helper
INFO - 2017-02-17 11:37:12 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:37:12 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:37:12 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:37:12 --> Template Class Initialized
INFO - 2017-02-17 11:37:12 --> Controller Class Initialized
DEBUG - 2017-02-17 11:37:12 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:37:12 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:37:12 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
ERROR - 2017-02-17 11:37:12 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\default.php 52
INFO - 2017-02-17 11:37:29 --> Config Class Initialized
INFO - 2017-02-17 11:37:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:37:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:37:29 --> Utf8 Class Initialized
INFO - 2017-02-17 11:37:29 --> URI Class Initialized
DEBUG - 2017-02-17 11:37:29 --> No URI present. Default controller set.
INFO - 2017-02-17 11:37:29 --> Router Class Initialized
INFO - 2017-02-17 11:37:29 --> Output Class Initialized
INFO - 2017-02-17 11:37:29 --> Security Class Initialized
DEBUG - 2017-02-17 11:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:37:29 --> Input Class Initialized
INFO - 2017-02-17 11:37:29 --> Language Class Initialized
INFO - 2017-02-17 11:37:29 --> Language Class Initialized
INFO - 2017-02-17 11:37:29 --> Config Class Initialized
INFO - 2017-02-17 11:37:29 --> Loader Class Initialized
INFO - 2017-02-17 11:37:29 --> Helper loaded: form_helper
INFO - 2017-02-17 11:37:29 --> Helper loaded: url_helper
INFO - 2017-02-17 11:37:29 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:37:29 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:37:29 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:37:29 --> Template Class Initialized
INFO - 2017-02-17 11:37:29 --> Controller Class Initialized
DEBUG - 2017-02-17 11:37:29 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:37:29 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:37:29 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
ERROR - 2017-02-17 11:37:29 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\default.php 52
INFO - 2017-02-17 11:38:20 --> Config Class Initialized
INFO - 2017-02-17 11:38:20 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:38:20 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:38:20 --> Utf8 Class Initialized
INFO - 2017-02-17 11:38:20 --> URI Class Initialized
DEBUG - 2017-02-17 11:38:20 --> No URI present. Default controller set.
INFO - 2017-02-17 11:38:20 --> Router Class Initialized
INFO - 2017-02-17 11:38:20 --> Output Class Initialized
INFO - 2017-02-17 11:38:20 --> Security Class Initialized
DEBUG - 2017-02-17 11:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:38:20 --> Input Class Initialized
INFO - 2017-02-17 11:38:20 --> Language Class Initialized
INFO - 2017-02-17 11:38:20 --> Language Class Initialized
INFO - 2017-02-17 11:38:20 --> Config Class Initialized
INFO - 2017-02-17 11:38:20 --> Loader Class Initialized
INFO - 2017-02-17 11:38:20 --> Helper loaded: form_helper
INFO - 2017-02-17 11:38:20 --> Helper loaded: url_helper
INFO - 2017-02-17 11:38:20 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:38:20 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:38:20 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:38:20 --> Template Class Initialized
INFO - 2017-02-17 11:38:20 --> Controller Class Initialized
DEBUG - 2017-02-17 11:38:20 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:38:20 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:38:20 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:38:20 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:38:20 --> Final output sent to browser
DEBUG - 2017-02-17 11:38:20 --> Total execution time: 0.0569
INFO - 2017-02-17 11:38:57 --> Config Class Initialized
INFO - 2017-02-17 11:38:57 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:38:57 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:38:57 --> Utf8 Class Initialized
INFO - 2017-02-17 11:38:57 --> URI Class Initialized
DEBUG - 2017-02-17 11:38:57 --> No URI present. Default controller set.
INFO - 2017-02-17 11:38:57 --> Router Class Initialized
INFO - 2017-02-17 11:38:57 --> Output Class Initialized
INFO - 2017-02-17 11:38:57 --> Security Class Initialized
DEBUG - 2017-02-17 11:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:38:57 --> Input Class Initialized
INFO - 2017-02-17 11:38:57 --> Language Class Initialized
INFO - 2017-02-17 11:38:57 --> Language Class Initialized
INFO - 2017-02-17 11:38:57 --> Config Class Initialized
INFO - 2017-02-17 11:38:57 --> Loader Class Initialized
INFO - 2017-02-17 11:38:57 --> Helper loaded: form_helper
INFO - 2017-02-17 11:38:57 --> Helper loaded: url_helper
INFO - 2017-02-17 11:38:57 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:38:57 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:38:57 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:38:57 --> Template Class Initialized
INFO - 2017-02-17 11:38:57 --> Controller Class Initialized
DEBUG - 2017-02-17 11:38:57 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:38:57 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:38:57 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:38:57 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:38:57 --> Final output sent to browser
DEBUG - 2017-02-17 11:38:57 --> Total execution time: 0.0573
INFO - 2017-02-17 11:39:13 --> Config Class Initialized
INFO - 2017-02-17 11:39:13 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:39:13 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:39:13 --> Utf8 Class Initialized
INFO - 2017-02-17 11:39:13 --> URI Class Initialized
DEBUG - 2017-02-17 11:39:13 --> No URI present. Default controller set.
INFO - 2017-02-17 11:39:13 --> Router Class Initialized
INFO - 2017-02-17 11:39:13 --> Output Class Initialized
INFO - 2017-02-17 11:39:13 --> Security Class Initialized
DEBUG - 2017-02-17 11:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:39:13 --> Input Class Initialized
INFO - 2017-02-17 11:39:13 --> Language Class Initialized
INFO - 2017-02-17 11:39:13 --> Language Class Initialized
INFO - 2017-02-17 11:39:13 --> Config Class Initialized
INFO - 2017-02-17 11:39:13 --> Loader Class Initialized
INFO - 2017-02-17 11:39:13 --> Helper loaded: form_helper
INFO - 2017-02-17 11:39:13 --> Helper loaded: url_helper
INFO - 2017-02-17 11:39:13 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:39:13 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:39:13 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:39:13 --> Template Class Initialized
INFO - 2017-02-17 11:39:13 --> Controller Class Initialized
DEBUG - 2017-02-17 11:39:13 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:39:13 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:39:13 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:39:13 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:39:13 --> Final output sent to browser
DEBUG - 2017-02-17 11:39:13 --> Total execution time: 0.0491
INFO - 2017-02-17 11:42:17 --> Config Class Initialized
INFO - 2017-02-17 11:42:17 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:42:17 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:42:17 --> Utf8 Class Initialized
INFO - 2017-02-17 11:42:17 --> URI Class Initialized
DEBUG - 2017-02-17 11:42:17 --> No URI present. Default controller set.
INFO - 2017-02-17 11:42:17 --> Router Class Initialized
INFO - 2017-02-17 11:42:17 --> Output Class Initialized
INFO - 2017-02-17 11:42:17 --> Security Class Initialized
DEBUG - 2017-02-17 11:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:42:17 --> Input Class Initialized
INFO - 2017-02-17 11:42:17 --> Language Class Initialized
INFO - 2017-02-17 11:42:17 --> Language Class Initialized
INFO - 2017-02-17 11:42:17 --> Config Class Initialized
INFO - 2017-02-17 11:42:17 --> Loader Class Initialized
INFO - 2017-02-17 11:42:17 --> Helper loaded: form_helper
INFO - 2017-02-17 11:42:17 --> Helper loaded: url_helper
INFO - 2017-02-17 11:42:17 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:42:17 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:42:17 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:42:17 --> Template Class Initialized
INFO - 2017-02-17 11:42:17 --> Controller Class Initialized
DEBUG - 2017-02-17 11:42:17 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:42:17 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:42:17 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:42:17 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:42:17 --> Final output sent to browser
DEBUG - 2017-02-17 11:42:17 --> Total execution time: 0.0487
INFO - 2017-02-17 11:44:06 --> Config Class Initialized
INFO - 2017-02-17 11:44:06 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:44:06 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:44:06 --> Utf8 Class Initialized
INFO - 2017-02-17 11:44:06 --> URI Class Initialized
DEBUG - 2017-02-17 11:44:06 --> No URI present. Default controller set.
INFO - 2017-02-17 11:44:06 --> Router Class Initialized
INFO - 2017-02-17 11:44:06 --> Output Class Initialized
INFO - 2017-02-17 11:44:06 --> Security Class Initialized
DEBUG - 2017-02-17 11:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:44:06 --> Input Class Initialized
INFO - 2017-02-17 11:44:06 --> Language Class Initialized
INFO - 2017-02-17 11:44:06 --> Language Class Initialized
INFO - 2017-02-17 11:44:06 --> Config Class Initialized
INFO - 2017-02-17 11:44:06 --> Loader Class Initialized
INFO - 2017-02-17 11:44:06 --> Helper loaded: form_helper
INFO - 2017-02-17 11:44:06 --> Helper loaded: url_helper
INFO - 2017-02-17 11:44:06 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:44:06 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:44:06 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:44:06 --> Template Class Initialized
INFO - 2017-02-17 11:44:06 --> Controller Class Initialized
DEBUG - 2017-02-17 11:44:06 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:44:06 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:44:06 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:44:06 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:44:06 --> Final output sent to browser
DEBUG - 2017-02-17 11:44:06 --> Total execution time: 0.0492
INFO - 2017-02-17 11:49:37 --> Config Class Initialized
INFO - 2017-02-17 11:49:37 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:49:37 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:49:37 --> Utf8 Class Initialized
INFO - 2017-02-17 11:49:37 --> URI Class Initialized
DEBUG - 2017-02-17 11:49:37 --> No URI present. Default controller set.
INFO - 2017-02-17 11:49:37 --> Router Class Initialized
INFO - 2017-02-17 11:49:37 --> Output Class Initialized
INFO - 2017-02-17 11:49:37 --> Security Class Initialized
DEBUG - 2017-02-17 11:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:49:37 --> Input Class Initialized
INFO - 2017-02-17 11:49:37 --> Language Class Initialized
INFO - 2017-02-17 11:49:37 --> Language Class Initialized
INFO - 2017-02-17 11:49:37 --> Config Class Initialized
INFO - 2017-02-17 11:49:37 --> Loader Class Initialized
INFO - 2017-02-17 11:49:37 --> Helper loaded: form_helper
INFO - 2017-02-17 11:49:37 --> Helper loaded: url_helper
INFO - 2017-02-17 11:49:37 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:49:37 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:49:37 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:49:37 --> Template Class Initialized
INFO - 2017-02-17 11:49:37 --> Controller Class Initialized
DEBUG - 2017-02-17 11:49:37 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:49:37 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:49:37 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:49:37 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:49:37 --> Final output sent to browser
DEBUG - 2017-02-17 11:49:37 --> Total execution time: 0.0606
INFO - 2017-02-17 11:49:38 --> Config Class Initialized
INFO - 2017-02-17 11:49:38 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:49:38 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:49:38 --> Utf8 Class Initialized
INFO - 2017-02-17 11:49:38 --> URI Class Initialized
DEBUG - 2017-02-17 11:49:38 --> No URI present. Default controller set.
INFO - 2017-02-17 11:49:38 --> Router Class Initialized
INFO - 2017-02-17 11:49:38 --> Output Class Initialized
INFO - 2017-02-17 11:49:38 --> Security Class Initialized
DEBUG - 2017-02-17 11:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:49:38 --> Input Class Initialized
INFO - 2017-02-17 11:49:38 --> Language Class Initialized
INFO - 2017-02-17 11:49:38 --> Language Class Initialized
INFO - 2017-02-17 11:49:38 --> Config Class Initialized
INFO - 2017-02-17 11:49:38 --> Loader Class Initialized
INFO - 2017-02-17 11:49:38 --> Helper loaded: form_helper
INFO - 2017-02-17 11:49:38 --> Helper loaded: url_helper
INFO - 2017-02-17 11:49:38 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:49:38 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:49:38 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:49:38 --> Template Class Initialized
INFO - 2017-02-17 11:49:38 --> Controller Class Initialized
DEBUG - 2017-02-17 11:49:38 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:49:38 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:49:38 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:49:38 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:49:38 --> Final output sent to browser
DEBUG - 2017-02-17 11:49:38 --> Total execution time: 0.0916
INFO - 2017-02-17 11:49:44 --> Config Class Initialized
INFO - 2017-02-17 11:49:44 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:49:44 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:49:44 --> Utf8 Class Initialized
INFO - 2017-02-17 11:49:44 --> URI Class Initialized
DEBUG - 2017-02-17 11:49:44 --> No URI present. Default controller set.
INFO - 2017-02-17 11:49:44 --> Router Class Initialized
INFO - 2017-02-17 11:49:44 --> Output Class Initialized
INFO - 2017-02-17 11:49:44 --> Security Class Initialized
DEBUG - 2017-02-17 11:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:49:44 --> Input Class Initialized
INFO - 2017-02-17 11:49:44 --> Language Class Initialized
INFO - 2017-02-17 11:49:44 --> Language Class Initialized
INFO - 2017-02-17 11:49:44 --> Config Class Initialized
INFO - 2017-02-17 11:49:44 --> Loader Class Initialized
INFO - 2017-02-17 11:49:44 --> Helper loaded: form_helper
INFO - 2017-02-17 11:49:44 --> Helper loaded: url_helper
INFO - 2017-02-17 11:49:44 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:49:44 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:49:44 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:49:44 --> Template Class Initialized
INFO - 2017-02-17 11:49:44 --> Controller Class Initialized
DEBUG - 2017-02-17 11:49:44 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:49:44 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:49:44 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:49:44 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:49:44 --> Final output sent to browser
DEBUG - 2017-02-17 11:49:44 --> Total execution time: 0.0399
INFO - 2017-02-17 11:50:06 --> Config Class Initialized
INFO - 2017-02-17 11:50:06 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:50:06 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:50:06 --> Utf8 Class Initialized
INFO - 2017-02-17 11:50:06 --> URI Class Initialized
DEBUG - 2017-02-17 11:50:06 --> No URI present. Default controller set.
INFO - 2017-02-17 11:50:06 --> Router Class Initialized
INFO - 2017-02-17 11:50:06 --> Output Class Initialized
INFO - 2017-02-17 11:50:06 --> Security Class Initialized
DEBUG - 2017-02-17 11:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:50:06 --> Input Class Initialized
INFO - 2017-02-17 11:50:06 --> Language Class Initialized
INFO - 2017-02-17 11:50:06 --> Language Class Initialized
INFO - 2017-02-17 11:50:06 --> Config Class Initialized
INFO - 2017-02-17 11:50:06 --> Loader Class Initialized
INFO - 2017-02-17 11:50:06 --> Helper loaded: form_helper
INFO - 2017-02-17 11:50:06 --> Helper loaded: url_helper
INFO - 2017-02-17 11:50:06 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:50:06 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:50:06 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:50:06 --> Template Class Initialized
INFO - 2017-02-17 11:50:06 --> Controller Class Initialized
DEBUG - 2017-02-17 11:50:06 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:50:06 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:50:06 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:50:06 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:50:06 --> Final output sent to browser
DEBUG - 2017-02-17 11:50:06 --> Total execution time: 0.0962
INFO - 2017-02-17 11:50:12 --> Config Class Initialized
INFO - 2017-02-17 11:50:12 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:50:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:50:12 --> Utf8 Class Initialized
INFO - 2017-02-17 11:50:12 --> URI Class Initialized
DEBUG - 2017-02-17 11:50:12 --> No URI present. Default controller set.
INFO - 2017-02-17 11:50:12 --> Router Class Initialized
INFO - 2017-02-17 11:50:12 --> Output Class Initialized
INFO - 2017-02-17 11:50:12 --> Security Class Initialized
DEBUG - 2017-02-17 11:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:50:12 --> Input Class Initialized
INFO - 2017-02-17 11:50:12 --> Language Class Initialized
INFO - 2017-02-17 11:50:12 --> Language Class Initialized
INFO - 2017-02-17 11:50:12 --> Config Class Initialized
INFO - 2017-02-17 11:50:12 --> Loader Class Initialized
INFO - 2017-02-17 11:50:12 --> Helper loaded: form_helper
INFO - 2017-02-17 11:50:12 --> Helper loaded: url_helper
INFO - 2017-02-17 11:50:12 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:50:12 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:50:12 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:50:12 --> Template Class Initialized
INFO - 2017-02-17 11:50:12 --> Controller Class Initialized
DEBUG - 2017-02-17 11:50:12 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:50:12 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:50:12 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:50:12 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:50:12 --> Final output sent to browser
DEBUG - 2017-02-17 11:50:12 --> Total execution time: 0.0369
INFO - 2017-02-17 11:51:36 --> Config Class Initialized
INFO - 2017-02-17 11:51:36 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:51:36 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:51:36 --> Utf8 Class Initialized
INFO - 2017-02-17 11:51:36 --> URI Class Initialized
DEBUG - 2017-02-17 11:51:36 --> No URI present. Default controller set.
INFO - 2017-02-17 11:51:36 --> Router Class Initialized
INFO - 2017-02-17 11:51:36 --> Output Class Initialized
INFO - 2017-02-17 11:51:36 --> Security Class Initialized
DEBUG - 2017-02-17 11:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:51:36 --> Input Class Initialized
INFO - 2017-02-17 11:51:36 --> Language Class Initialized
INFO - 2017-02-17 11:51:36 --> Language Class Initialized
INFO - 2017-02-17 11:51:36 --> Config Class Initialized
INFO - 2017-02-17 11:51:36 --> Loader Class Initialized
INFO - 2017-02-17 11:51:36 --> Helper loaded: form_helper
INFO - 2017-02-17 11:51:36 --> Helper loaded: url_helper
INFO - 2017-02-17 11:51:36 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:51:36 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:51:36 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:51:36 --> Template Class Initialized
INFO - 2017-02-17 11:51:36 --> Controller Class Initialized
DEBUG - 2017-02-17 11:51:36 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:51:36 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:51:36 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:51:36 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:51:36 --> Final output sent to browser
DEBUG - 2017-02-17 11:51:36 --> Total execution time: 0.0540
INFO - 2017-02-17 11:51:47 --> Config Class Initialized
INFO - 2017-02-17 11:51:47 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:51:47 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:51:47 --> Utf8 Class Initialized
INFO - 2017-02-17 11:51:47 --> URI Class Initialized
DEBUG - 2017-02-17 11:51:47 --> No URI present. Default controller set.
INFO - 2017-02-17 11:51:47 --> Router Class Initialized
INFO - 2017-02-17 11:51:47 --> Output Class Initialized
INFO - 2017-02-17 11:51:47 --> Security Class Initialized
DEBUG - 2017-02-17 11:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:51:47 --> Input Class Initialized
INFO - 2017-02-17 11:51:47 --> Language Class Initialized
INFO - 2017-02-17 11:51:47 --> Language Class Initialized
INFO - 2017-02-17 11:51:47 --> Config Class Initialized
INFO - 2017-02-17 11:51:47 --> Loader Class Initialized
INFO - 2017-02-17 11:51:47 --> Helper loaded: form_helper
INFO - 2017-02-17 11:51:47 --> Helper loaded: url_helper
INFO - 2017-02-17 11:51:47 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:51:47 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:51:47 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:51:47 --> Template Class Initialized
INFO - 2017-02-17 11:51:47 --> Controller Class Initialized
DEBUG - 2017-02-17 11:51:47 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:51:47 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:51:47 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:51:47 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:51:47 --> Final output sent to browser
DEBUG - 2017-02-17 11:51:47 --> Total execution time: 0.0359
INFO - 2017-02-17 11:52:25 --> Config Class Initialized
INFO - 2017-02-17 11:52:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:52:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:52:25 --> Utf8 Class Initialized
INFO - 2017-02-17 11:52:25 --> URI Class Initialized
DEBUG - 2017-02-17 11:52:25 --> No URI present. Default controller set.
INFO - 2017-02-17 11:52:25 --> Router Class Initialized
INFO - 2017-02-17 11:52:25 --> Output Class Initialized
INFO - 2017-02-17 11:52:25 --> Security Class Initialized
DEBUG - 2017-02-17 11:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:52:25 --> Input Class Initialized
INFO - 2017-02-17 11:52:25 --> Language Class Initialized
INFO - 2017-02-17 11:52:25 --> Language Class Initialized
INFO - 2017-02-17 11:52:25 --> Config Class Initialized
INFO - 2017-02-17 11:52:25 --> Loader Class Initialized
INFO - 2017-02-17 11:52:25 --> Helper loaded: form_helper
INFO - 2017-02-17 11:52:25 --> Helper loaded: url_helper
INFO - 2017-02-17 11:52:25 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:52:25 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:52:25 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:52:25 --> Template Class Initialized
INFO - 2017-02-17 11:52:25 --> Controller Class Initialized
DEBUG - 2017-02-17 11:52:25 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:52:25 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:52:25 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:52:25 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:52:25 --> Final output sent to browser
DEBUG - 2017-02-17 11:52:25 --> Total execution time: 0.0360
INFO - 2017-02-17 11:52:29 --> Config Class Initialized
INFO - 2017-02-17 11:52:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:52:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:52:29 --> Utf8 Class Initialized
INFO - 2017-02-17 11:52:29 --> URI Class Initialized
DEBUG - 2017-02-17 11:52:29 --> No URI present. Default controller set.
INFO - 2017-02-17 11:52:29 --> Router Class Initialized
INFO - 2017-02-17 11:52:29 --> Output Class Initialized
INFO - 2017-02-17 11:52:29 --> Security Class Initialized
DEBUG - 2017-02-17 11:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:52:29 --> Input Class Initialized
INFO - 2017-02-17 11:52:29 --> Language Class Initialized
INFO - 2017-02-17 11:52:29 --> Language Class Initialized
INFO - 2017-02-17 11:52:29 --> Config Class Initialized
INFO - 2017-02-17 11:52:29 --> Loader Class Initialized
INFO - 2017-02-17 11:52:29 --> Helper loaded: form_helper
INFO - 2017-02-17 11:52:29 --> Helper loaded: url_helper
INFO - 2017-02-17 11:52:29 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:52:29 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:52:29 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:52:29 --> Template Class Initialized
INFO - 2017-02-17 11:52:29 --> Controller Class Initialized
DEBUG - 2017-02-17 11:52:29 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:52:29 --> Helper loaded: cookie_helper
DEBUG - 2017-02-17 11:52:29 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/login.php
DEBUG - 2017-02-17 11:52:29 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 11:52:29 --> Final output sent to browser
DEBUG - 2017-02-17 11:52:29 --> Total execution time: 0.0365
INFO - 2017-02-17 11:52:50 --> Config Class Initialized
INFO - 2017-02-17 11:52:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:52:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:52:50 --> Utf8 Class Initialized
INFO - 2017-02-17 11:52:50 --> URI Class Initialized
DEBUG - 2017-02-17 11:52:50 --> No URI present. Default controller set.
INFO - 2017-02-17 11:52:50 --> Router Class Initialized
INFO - 2017-02-17 11:52:50 --> Output Class Initialized
INFO - 2017-02-17 11:52:50 --> Security Class Initialized
DEBUG - 2017-02-17 11:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:52:50 --> Input Class Initialized
INFO - 2017-02-17 11:52:50 --> Language Class Initialized
INFO - 2017-02-17 11:52:50 --> Language Class Initialized
INFO - 2017-02-17 11:52:50 --> Config Class Initialized
INFO - 2017-02-17 11:52:50 --> Loader Class Initialized
INFO - 2017-02-17 11:52:50 --> Helper loaded: form_helper
INFO - 2017-02-17 11:52:50 --> Helper loaded: url_helper
INFO - 2017-02-17 11:52:50 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:52:50 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:52:50 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:52:50 --> Template Class Initialized
INFO - 2017-02-17 11:52:50 --> Controller Class Initialized
DEBUG - 2017-02-17 11:52:50 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:52:50 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:52:50 --> Model Class Initialized
ERROR - 2017-02-17 11:52:50 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\razor\application\modules\backend\views\login.php 14
INFO - 2017-02-17 11:52:52 --> Config Class Initialized
INFO - 2017-02-17 11:52:52 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:52:52 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:52:52 --> Utf8 Class Initialized
INFO - 2017-02-17 11:52:52 --> URI Class Initialized
DEBUG - 2017-02-17 11:52:52 --> No URI present. Default controller set.
INFO - 2017-02-17 11:52:52 --> Router Class Initialized
INFO - 2017-02-17 11:52:52 --> Output Class Initialized
INFO - 2017-02-17 11:52:52 --> Security Class Initialized
DEBUG - 2017-02-17 11:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:52:52 --> Input Class Initialized
INFO - 2017-02-17 11:52:52 --> Language Class Initialized
INFO - 2017-02-17 11:52:52 --> Language Class Initialized
INFO - 2017-02-17 11:52:52 --> Config Class Initialized
INFO - 2017-02-17 11:52:52 --> Loader Class Initialized
INFO - 2017-02-17 11:52:52 --> Helper loaded: form_helper
INFO - 2017-02-17 11:52:52 --> Helper loaded: url_helper
INFO - 2017-02-17 11:52:52 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:52:52 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:52:52 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:52:52 --> Template Class Initialized
INFO - 2017-02-17 11:52:52 --> Controller Class Initialized
DEBUG - 2017-02-17 11:52:52 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:52:52 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:52:52 --> Model Class Initialized
ERROR - 2017-02-17 11:52:52 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\razor\application\modules\backend\views\login.php 14
INFO - 2017-02-17 11:53:23 --> Config Class Initialized
INFO - 2017-02-17 11:53:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:53:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:53:23 --> Utf8 Class Initialized
INFO - 2017-02-17 11:53:23 --> URI Class Initialized
DEBUG - 2017-02-17 11:53:23 --> No URI present. Default controller set.
INFO - 2017-02-17 11:53:23 --> Router Class Initialized
INFO - 2017-02-17 11:53:23 --> Output Class Initialized
INFO - 2017-02-17 11:53:23 --> Security Class Initialized
DEBUG - 2017-02-17 11:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:53:23 --> Input Class Initialized
INFO - 2017-02-17 11:53:23 --> Language Class Initialized
INFO - 2017-02-17 11:53:23 --> Language Class Initialized
INFO - 2017-02-17 11:53:23 --> Config Class Initialized
INFO - 2017-02-17 11:53:23 --> Loader Class Initialized
INFO - 2017-02-17 11:53:23 --> Helper loaded: form_helper
INFO - 2017-02-17 11:53:23 --> Helper loaded: url_helper
INFO - 2017-02-17 11:53:23 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:53:23 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:53:23 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:53:23 --> Template Class Initialized
INFO - 2017-02-17 11:53:23 --> Controller Class Initialized
DEBUG - 2017-02-17 11:53:23 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:53:23 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:53:23 --> Model Class Initialized
DEBUG - 2017-02-17 11:53:23 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
ERROR - 2017-02-17 11:53:23 --> Severity: Error --> Call to undefined function asset_url() C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\backend.php 14
INFO - 2017-02-17 11:53:54 --> Config Class Initialized
INFO - 2017-02-17 11:53:54 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:53:54 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:53:54 --> Utf8 Class Initialized
INFO - 2017-02-17 11:53:54 --> URI Class Initialized
DEBUG - 2017-02-17 11:53:54 --> No URI present. Default controller set.
INFO - 2017-02-17 11:53:54 --> Router Class Initialized
INFO - 2017-02-17 11:53:54 --> Output Class Initialized
INFO - 2017-02-17 11:53:54 --> Security Class Initialized
DEBUG - 2017-02-17 11:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:53:54 --> Input Class Initialized
INFO - 2017-02-17 11:53:54 --> Language Class Initialized
INFO - 2017-02-17 11:53:54 --> Language Class Initialized
INFO - 2017-02-17 11:53:54 --> Config Class Initialized
INFO - 2017-02-17 11:53:54 --> Loader Class Initialized
INFO - 2017-02-17 11:53:54 --> Helper loaded: form_helper
INFO - 2017-02-17 11:53:54 --> Helper loaded: url_helper
INFO - 2017-02-17 11:53:54 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:53:54 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:53:54 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:53:54 --> Template Class Initialized
INFO - 2017-02-17 11:53:54 --> Controller Class Initialized
DEBUG - 2017-02-17 11:53:54 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:53:54 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:53:54 --> Model Class Initialized
DEBUG - 2017-02-17 11:53:54 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:53:54 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:53:54 --> Final output sent to browser
DEBUG - 2017-02-17 11:53:54 --> Total execution time: 0.0618
INFO - 2017-02-17 11:54:01 --> Config Class Initialized
INFO - 2017-02-17 11:54:01 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:54:01 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:54:01 --> Utf8 Class Initialized
INFO - 2017-02-17 11:54:01 --> URI Class Initialized
DEBUG - 2017-02-17 11:54:01 --> No URI present. Default controller set.
INFO - 2017-02-17 11:54:01 --> Router Class Initialized
INFO - 2017-02-17 11:54:01 --> Output Class Initialized
INFO - 2017-02-17 11:54:01 --> Security Class Initialized
DEBUG - 2017-02-17 11:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:54:01 --> Input Class Initialized
INFO - 2017-02-17 11:54:01 --> Language Class Initialized
INFO - 2017-02-17 11:54:01 --> Language Class Initialized
INFO - 2017-02-17 11:54:01 --> Config Class Initialized
INFO - 2017-02-17 11:54:01 --> Loader Class Initialized
INFO - 2017-02-17 11:54:01 --> Helper loaded: form_helper
INFO - 2017-02-17 11:54:01 --> Helper loaded: url_helper
INFO - 2017-02-17 11:54:01 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:54:01 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:54:01 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:54:01 --> Template Class Initialized
INFO - 2017-02-17 11:54:01 --> Controller Class Initialized
DEBUG - 2017-02-17 11:54:01 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:54:01 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:54:01 --> Model Class Initialized
DEBUG - 2017-02-17 11:54:01 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:54:01 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:54:01 --> Final output sent to browser
DEBUG - 2017-02-17 11:54:01 --> Total execution time: 0.0396
INFO - 2017-02-17 11:54:14 --> Config Class Initialized
INFO - 2017-02-17 11:54:14 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:54:14 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:54:14 --> Utf8 Class Initialized
INFO - 2017-02-17 11:54:14 --> URI Class Initialized
DEBUG - 2017-02-17 11:54:14 --> No URI present. Default controller set.
INFO - 2017-02-17 11:54:14 --> Router Class Initialized
INFO - 2017-02-17 11:54:14 --> Output Class Initialized
INFO - 2017-02-17 11:54:14 --> Security Class Initialized
DEBUG - 2017-02-17 11:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:54:14 --> Input Class Initialized
INFO - 2017-02-17 11:54:14 --> Language Class Initialized
INFO - 2017-02-17 11:54:14 --> Language Class Initialized
INFO - 2017-02-17 11:54:14 --> Config Class Initialized
INFO - 2017-02-17 11:54:14 --> Loader Class Initialized
INFO - 2017-02-17 11:54:14 --> Helper loaded: form_helper
INFO - 2017-02-17 11:54:14 --> Helper loaded: url_helper
INFO - 2017-02-17 11:54:14 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:54:14 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:54:14 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:54:14 --> Template Class Initialized
INFO - 2017-02-17 11:54:14 --> Controller Class Initialized
DEBUG - 2017-02-17 11:54:14 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:54:14 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:54:14 --> Model Class Initialized
DEBUG - 2017-02-17 11:54:14 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:54:14 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:54:14 --> Final output sent to browser
DEBUG - 2017-02-17 11:54:14 --> Total execution time: 0.0546
INFO - 2017-02-17 11:54:15 --> Config Class Initialized
INFO - 2017-02-17 11:54:15 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:54:15 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:54:15 --> Utf8 Class Initialized
INFO - 2017-02-17 11:54:15 --> URI Class Initialized
INFO - 2017-02-17 11:54:15 --> Router Class Initialized
INFO - 2017-02-17 11:54:15 --> Output Class Initialized
INFO - 2017-02-17 11:54:15 --> Security Class Initialized
DEBUG - 2017-02-17 11:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:54:15 --> Input Class Initialized
INFO - 2017-02-17 11:54:15 --> Language Class Initialized
INFO - 2017-02-17 11:54:15 --> Language Class Initialized
INFO - 2017-02-17 11:54:15 --> Config Class Initialized
INFO - 2017-02-17 11:54:15 --> Loader Class Initialized
INFO - 2017-02-17 11:54:15 --> Helper loaded: form_helper
INFO - 2017-02-17 11:54:15 --> Helper loaded: url_helper
INFO - 2017-02-17 11:54:15 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:54:15 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:54:15 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:54:15 --> Template Class Initialized
INFO - 2017-02-17 11:54:15 --> Controller Class Initialized
DEBUG - 2017-02-17 11:54:15 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:54:15 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:54:15 --> Model Class Initialized
ERROR - 2017-02-17 11:54:15 --> Severity: Notice --> Undefined property: CI::$form_validation C:\xampp\htdocs\razor\application\third_party\MX\Controller.php 62
ERROR - 2017-02-17 11:54:15 --> Severity: Error --> Call to a member function set_rules() on null C:\xampp\htdocs\razor\application\modules\backend\controllers\Login.php 26
INFO - 2017-02-17 11:54:41 --> Config Class Initialized
INFO - 2017-02-17 11:54:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:54:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:54:41 --> Utf8 Class Initialized
INFO - 2017-02-17 11:54:41 --> URI Class Initialized
INFO - 2017-02-17 11:54:41 --> Router Class Initialized
INFO - 2017-02-17 11:54:41 --> Output Class Initialized
INFO - 2017-02-17 11:54:41 --> Security Class Initialized
DEBUG - 2017-02-17 11:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:54:41 --> Input Class Initialized
INFO - 2017-02-17 11:54:41 --> Language Class Initialized
INFO - 2017-02-17 11:54:41 --> Language Class Initialized
INFO - 2017-02-17 11:54:41 --> Config Class Initialized
INFO - 2017-02-17 11:54:41 --> Loader Class Initialized
INFO - 2017-02-17 11:54:41 --> Helper loaded: form_helper
INFO - 2017-02-17 11:54:41 --> Helper loaded: url_helper
INFO - 2017-02-17 11:54:41 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:54:41 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:54:41 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:54:41 --> Template Class Initialized
INFO - 2017-02-17 11:54:41 --> Controller Class Initialized
DEBUG - 2017-02-17 11:54:41 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:54:41 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:54:41 --> Model Class Initialized
INFO - 2017-02-17 11:54:41 --> Form Validation Class Initialized
INFO - 2017-02-17 11:54:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 11:54:41 --> Query error: Unknown column 'username' in 'where clause' - Invalid query: SELECT *
FROM `tbl_users`
WHERE `username` = 'lejardin_admin'
AND `password` = 'f9312ac569e17bb3fc31632928b21984'
AND `role_id` = 1
INFO - 2017-02-17 11:54:41 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-17 11:55:28 --> Config Class Initialized
INFO - 2017-02-17 11:55:28 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:55:28 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:55:28 --> Utf8 Class Initialized
INFO - 2017-02-17 11:55:28 --> URI Class Initialized
INFO - 2017-02-17 11:55:28 --> Router Class Initialized
INFO - 2017-02-17 11:55:28 --> Output Class Initialized
INFO - 2017-02-17 11:55:28 --> Security Class Initialized
DEBUG - 2017-02-17 11:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:55:28 --> Input Class Initialized
INFO - 2017-02-17 11:55:28 --> Language Class Initialized
INFO - 2017-02-17 11:55:28 --> Language Class Initialized
INFO - 2017-02-17 11:55:28 --> Config Class Initialized
INFO - 2017-02-17 11:55:28 --> Loader Class Initialized
INFO - 2017-02-17 11:55:28 --> Helper loaded: form_helper
INFO - 2017-02-17 11:55:28 --> Helper loaded: url_helper
INFO - 2017-02-17 11:55:28 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:55:28 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:55:28 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:55:28 --> Template Class Initialized
INFO - 2017-02-17 11:55:28 --> Controller Class Initialized
DEBUG - 2017-02-17 11:55:28 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:55:28 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:55:28 --> Model Class Initialized
INFO - 2017-02-17 11:55:28 --> Form Validation Class Initialized
INFO - 2017-02-17 11:55:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:55:28 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:55:28 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:55:28 --> Final output sent to browser
DEBUG - 2017-02-17 11:55:28 --> Total execution time: 0.0953
INFO - 2017-02-17 11:55:57 --> Config Class Initialized
INFO - 2017-02-17 11:55:57 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:55:57 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:55:57 --> Utf8 Class Initialized
INFO - 2017-02-17 11:55:57 --> URI Class Initialized
INFO - 2017-02-17 11:55:57 --> Router Class Initialized
INFO - 2017-02-17 11:55:57 --> Output Class Initialized
INFO - 2017-02-17 11:55:57 --> Security Class Initialized
DEBUG - 2017-02-17 11:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:55:57 --> Input Class Initialized
INFO - 2017-02-17 11:55:57 --> Language Class Initialized
INFO - 2017-02-17 11:55:57 --> Language Class Initialized
INFO - 2017-02-17 11:55:57 --> Config Class Initialized
INFO - 2017-02-17 11:55:57 --> Loader Class Initialized
INFO - 2017-02-17 11:55:57 --> Helper loaded: form_helper
INFO - 2017-02-17 11:55:57 --> Helper loaded: url_helper
INFO - 2017-02-17 11:55:57 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:55:57 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:55:57 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:55:57 --> Template Class Initialized
INFO - 2017-02-17 11:55:57 --> Controller Class Initialized
DEBUG - 2017-02-17 11:55:57 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:55:57 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:55:57 --> Model Class Initialized
INFO - 2017-02-17 11:55:57 --> Form Validation Class Initialized
INFO - 2017-02-17 11:55:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:55:57 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:55:57 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:55:57 --> Final output sent to browser
DEBUG - 2017-02-17 11:55:57 --> Total execution time: 0.0864
INFO - 2017-02-17 11:55:59 --> Config Class Initialized
INFO - 2017-02-17 11:55:59 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:55:59 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:55:59 --> Utf8 Class Initialized
INFO - 2017-02-17 11:55:59 --> URI Class Initialized
INFO - 2017-02-17 11:55:59 --> Router Class Initialized
INFO - 2017-02-17 11:55:59 --> Output Class Initialized
INFO - 2017-02-17 11:55:59 --> Security Class Initialized
DEBUG - 2017-02-17 11:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:55:59 --> Input Class Initialized
INFO - 2017-02-17 11:55:59 --> Language Class Initialized
INFO - 2017-02-17 11:55:59 --> Language Class Initialized
INFO - 2017-02-17 11:55:59 --> Config Class Initialized
INFO - 2017-02-17 11:55:59 --> Loader Class Initialized
INFO - 2017-02-17 11:55:59 --> Helper loaded: form_helper
INFO - 2017-02-17 11:55:59 --> Helper loaded: url_helper
INFO - 2017-02-17 11:55:59 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:55:59 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:55:59 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:55:59 --> Template Class Initialized
INFO - 2017-02-17 11:55:59 --> Controller Class Initialized
DEBUG - 2017-02-17 11:55:59 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:55:59 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:55:59 --> Model Class Initialized
INFO - 2017-02-17 11:55:59 --> Form Validation Class Initialized
INFO - 2017-02-17 11:55:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:55:59 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:55:59 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:55:59 --> Final output sent to browser
DEBUG - 2017-02-17 11:55:59 --> Total execution time: 0.0441
INFO - 2017-02-17 11:56:00 --> Config Class Initialized
INFO - 2017-02-17 11:56:00 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:56:00 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:56:00 --> Utf8 Class Initialized
INFO - 2017-02-17 11:56:00 --> URI Class Initialized
INFO - 2017-02-17 11:56:00 --> Router Class Initialized
INFO - 2017-02-17 11:56:00 --> Output Class Initialized
INFO - 2017-02-17 11:56:00 --> Security Class Initialized
DEBUG - 2017-02-17 11:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:56:00 --> Input Class Initialized
INFO - 2017-02-17 11:56:00 --> Language Class Initialized
INFO - 2017-02-17 11:56:00 --> Language Class Initialized
INFO - 2017-02-17 11:56:00 --> Config Class Initialized
INFO - 2017-02-17 11:56:00 --> Loader Class Initialized
INFO - 2017-02-17 11:56:00 --> Helper loaded: form_helper
INFO - 2017-02-17 11:56:00 --> Helper loaded: url_helper
INFO - 2017-02-17 11:56:00 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:56:00 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:56:00 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:56:00 --> Template Class Initialized
INFO - 2017-02-17 11:56:00 --> Controller Class Initialized
DEBUG - 2017-02-17 11:56:00 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:56:00 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:56:00 --> Model Class Initialized
INFO - 2017-02-17 11:56:00 --> Form Validation Class Initialized
INFO - 2017-02-17 11:56:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:56:00 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:56:00 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:56:00 --> Final output sent to browser
DEBUG - 2017-02-17 11:56:00 --> Total execution time: 0.0401
INFO - 2017-02-17 11:56:09 --> Config Class Initialized
INFO - 2017-02-17 11:56:09 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:56:09 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:56:09 --> Utf8 Class Initialized
INFO - 2017-02-17 11:56:09 --> URI Class Initialized
INFO - 2017-02-17 11:56:09 --> Router Class Initialized
INFO - 2017-02-17 11:56:09 --> Output Class Initialized
INFO - 2017-02-17 11:56:09 --> Security Class Initialized
DEBUG - 2017-02-17 11:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:56:09 --> Input Class Initialized
INFO - 2017-02-17 11:56:09 --> Language Class Initialized
INFO - 2017-02-17 11:56:09 --> Language Class Initialized
INFO - 2017-02-17 11:56:09 --> Config Class Initialized
INFO - 2017-02-17 11:56:09 --> Loader Class Initialized
INFO - 2017-02-17 11:56:09 --> Helper loaded: form_helper
INFO - 2017-02-17 11:56:09 --> Helper loaded: url_helper
INFO - 2017-02-17 11:56:09 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:56:09 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:56:09 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:56:09 --> Template Class Initialized
INFO - 2017-02-17 11:56:09 --> Controller Class Initialized
DEBUG - 2017-02-17 11:56:09 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:56:09 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:56:09 --> Model Class Initialized
INFO - 2017-02-17 11:56:09 --> Form Validation Class Initialized
INFO - 2017-02-17 11:56:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:56:09 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:56:09 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:56:09 --> Final output sent to browser
DEBUG - 2017-02-17 11:56:09 --> Total execution time: 0.0411
INFO - 2017-02-17 11:57:06 --> Config Class Initialized
INFO - 2017-02-17 11:57:06 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:57:06 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:57:06 --> Utf8 Class Initialized
INFO - 2017-02-17 11:57:06 --> URI Class Initialized
INFO - 2017-02-17 11:57:06 --> Router Class Initialized
INFO - 2017-02-17 11:57:06 --> Output Class Initialized
INFO - 2017-02-17 11:57:06 --> Security Class Initialized
DEBUG - 2017-02-17 11:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:57:06 --> Input Class Initialized
INFO - 2017-02-17 11:57:06 --> Language Class Initialized
INFO - 2017-02-17 11:57:06 --> Language Class Initialized
INFO - 2017-02-17 11:57:06 --> Config Class Initialized
INFO - 2017-02-17 11:57:06 --> Loader Class Initialized
INFO - 2017-02-17 11:57:06 --> Helper loaded: form_helper
INFO - 2017-02-17 11:57:06 --> Helper loaded: url_helper
INFO - 2017-02-17 11:57:06 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:57:06 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:57:06 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:57:06 --> Template Class Initialized
INFO - 2017-02-17 11:57:06 --> Controller Class Initialized
DEBUG - 2017-02-17 11:57:06 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:57:06 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:57:06 --> Model Class Initialized
INFO - 2017-02-17 11:57:06 --> Form Validation Class Initialized
INFO - 2017-02-17 11:57:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:57:06 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:57:06 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:57:06 --> Final output sent to browser
DEBUG - 2017-02-17 11:57:06 --> Total execution time: 0.0680
INFO - 2017-02-17 11:57:15 --> Config Class Initialized
INFO - 2017-02-17 11:57:15 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:57:15 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:57:15 --> Utf8 Class Initialized
INFO - 2017-02-17 11:57:15 --> URI Class Initialized
INFO - 2017-02-17 11:57:15 --> Router Class Initialized
INFO - 2017-02-17 11:57:15 --> Output Class Initialized
INFO - 2017-02-17 11:57:15 --> Security Class Initialized
DEBUG - 2017-02-17 11:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:57:15 --> Input Class Initialized
INFO - 2017-02-17 11:57:15 --> Language Class Initialized
INFO - 2017-02-17 11:57:15 --> Language Class Initialized
INFO - 2017-02-17 11:57:15 --> Config Class Initialized
INFO - 2017-02-17 11:57:15 --> Loader Class Initialized
INFO - 2017-02-17 11:57:15 --> Helper loaded: form_helper
INFO - 2017-02-17 11:57:15 --> Helper loaded: url_helper
INFO - 2017-02-17 11:57:15 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:57:15 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:57:15 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:57:15 --> Template Class Initialized
INFO - 2017-02-17 11:57:15 --> Controller Class Initialized
DEBUG - 2017-02-17 11:57:15 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:57:15 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:57:15 --> Model Class Initialized
INFO - 2017-02-17 11:57:15 --> Form Validation Class Initialized
INFO - 2017-02-17 11:57:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:57:15 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:57:15 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:57:15 --> Final output sent to browser
DEBUG - 2017-02-17 11:57:15 --> Total execution time: 0.0410
INFO - 2017-02-17 11:57:27 --> Config Class Initialized
INFO - 2017-02-17 11:57:27 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:57:27 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:57:27 --> Utf8 Class Initialized
INFO - 2017-02-17 11:57:27 --> URI Class Initialized
INFO - 2017-02-17 11:57:27 --> Router Class Initialized
INFO - 2017-02-17 11:57:27 --> Output Class Initialized
INFO - 2017-02-17 11:57:27 --> Security Class Initialized
DEBUG - 2017-02-17 11:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:57:27 --> Input Class Initialized
INFO - 2017-02-17 11:57:27 --> Language Class Initialized
INFO - 2017-02-17 11:57:27 --> Language Class Initialized
INFO - 2017-02-17 11:57:27 --> Config Class Initialized
INFO - 2017-02-17 11:57:27 --> Loader Class Initialized
INFO - 2017-02-17 11:57:27 --> Helper loaded: form_helper
INFO - 2017-02-17 11:57:27 --> Helper loaded: url_helper
INFO - 2017-02-17 11:57:27 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:57:27 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:57:27 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:57:27 --> Template Class Initialized
INFO - 2017-02-17 11:57:27 --> Controller Class Initialized
DEBUG - 2017-02-17 11:57:27 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:57:27 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:57:27 --> Model Class Initialized
INFO - 2017-02-17 11:57:27 --> Form Validation Class Initialized
INFO - 2017-02-17 11:57:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:57:27 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:57:27 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:57:27 --> Final output sent to browser
DEBUG - 2017-02-17 11:57:27 --> Total execution time: 0.0586
INFO - 2017-02-17 11:57:33 --> Config Class Initialized
INFO - 2017-02-17 11:57:33 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:57:33 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:57:33 --> Utf8 Class Initialized
INFO - 2017-02-17 11:57:33 --> URI Class Initialized
INFO - 2017-02-17 11:57:33 --> Router Class Initialized
INFO - 2017-02-17 11:57:33 --> Output Class Initialized
INFO - 2017-02-17 11:57:33 --> Security Class Initialized
DEBUG - 2017-02-17 11:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:57:33 --> Input Class Initialized
INFO - 2017-02-17 11:57:33 --> Language Class Initialized
INFO - 2017-02-17 11:57:33 --> Language Class Initialized
INFO - 2017-02-17 11:57:33 --> Config Class Initialized
INFO - 2017-02-17 11:57:33 --> Loader Class Initialized
INFO - 2017-02-17 11:57:33 --> Helper loaded: form_helper
INFO - 2017-02-17 11:57:33 --> Helper loaded: url_helper
INFO - 2017-02-17 11:57:33 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:57:33 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:57:33 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:57:33 --> Template Class Initialized
INFO - 2017-02-17 11:57:33 --> Controller Class Initialized
DEBUG - 2017-02-17 11:57:33 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:57:33 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:57:33 --> Model Class Initialized
INFO - 2017-02-17 11:57:33 --> Form Validation Class Initialized
INFO - 2017-02-17 11:57:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:57:33 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:57:33 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:57:33 --> Final output sent to browser
DEBUG - 2017-02-17 11:57:33 --> Total execution time: 0.0429
INFO - 2017-02-17 11:58:17 --> Config Class Initialized
INFO - 2017-02-17 11:58:17 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:58:17 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:58:17 --> Utf8 Class Initialized
INFO - 2017-02-17 11:58:17 --> URI Class Initialized
INFO - 2017-02-17 11:58:17 --> Router Class Initialized
INFO - 2017-02-17 11:58:17 --> Output Class Initialized
INFO - 2017-02-17 11:58:17 --> Security Class Initialized
DEBUG - 2017-02-17 11:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:58:17 --> Input Class Initialized
INFO - 2017-02-17 11:58:17 --> Language Class Initialized
INFO - 2017-02-17 11:58:17 --> Language Class Initialized
INFO - 2017-02-17 11:58:17 --> Config Class Initialized
INFO - 2017-02-17 11:58:17 --> Loader Class Initialized
INFO - 2017-02-17 11:58:17 --> Helper loaded: form_helper
INFO - 2017-02-17 11:58:17 --> Helper loaded: url_helper
INFO - 2017-02-17 11:58:17 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:58:17 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:58:17 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:58:17 --> Template Class Initialized
INFO - 2017-02-17 11:58:17 --> Controller Class Initialized
DEBUG - 2017-02-17 11:58:17 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:58:17 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:58:17 --> Model Class Initialized
INFO - 2017-02-17 11:58:17 --> Form Validation Class Initialized
DEBUG - 2017-02-17 11:58:17 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:58:17 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:58:17 --> Final output sent to browser
DEBUG - 2017-02-17 11:58:17 --> Total execution time: 0.0412
INFO - 2017-02-17 11:58:18 --> Config Class Initialized
INFO - 2017-02-17 11:58:18 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:58:18 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:58:18 --> Utf8 Class Initialized
INFO - 2017-02-17 11:58:18 --> URI Class Initialized
INFO - 2017-02-17 11:58:18 --> Router Class Initialized
INFO - 2017-02-17 11:58:18 --> Output Class Initialized
INFO - 2017-02-17 11:58:18 --> Security Class Initialized
DEBUG - 2017-02-17 11:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:58:18 --> Input Class Initialized
INFO - 2017-02-17 11:58:18 --> Language Class Initialized
INFO - 2017-02-17 11:58:18 --> Language Class Initialized
INFO - 2017-02-17 11:58:18 --> Config Class Initialized
INFO - 2017-02-17 11:58:18 --> Loader Class Initialized
INFO - 2017-02-17 11:58:18 --> Helper loaded: form_helper
INFO - 2017-02-17 11:58:18 --> Helper loaded: url_helper
INFO - 2017-02-17 11:58:18 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:58:18 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:58:18 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:58:18 --> Template Class Initialized
INFO - 2017-02-17 11:58:18 --> Controller Class Initialized
DEBUG - 2017-02-17 11:58:18 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:58:18 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:58:18 --> Model Class Initialized
INFO - 2017-02-17 11:58:18 --> Form Validation Class Initialized
INFO - 2017-02-17 11:58:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:58:18 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:58:18 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:58:18 --> Final output sent to browser
DEBUG - 2017-02-17 11:58:18 --> Total execution time: 0.0402
INFO - 2017-02-17 11:58:31 --> Config Class Initialized
INFO - 2017-02-17 11:58:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:58:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:58:31 --> Utf8 Class Initialized
INFO - 2017-02-17 11:58:31 --> URI Class Initialized
INFO - 2017-02-17 11:58:31 --> Router Class Initialized
INFO - 2017-02-17 11:58:31 --> Output Class Initialized
INFO - 2017-02-17 11:58:31 --> Security Class Initialized
DEBUG - 2017-02-17 11:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:58:31 --> Input Class Initialized
INFO - 2017-02-17 11:58:31 --> Language Class Initialized
INFO - 2017-02-17 11:58:31 --> Language Class Initialized
INFO - 2017-02-17 11:58:31 --> Config Class Initialized
INFO - 2017-02-17 11:58:31 --> Loader Class Initialized
INFO - 2017-02-17 11:58:31 --> Helper loaded: form_helper
INFO - 2017-02-17 11:58:31 --> Helper loaded: url_helper
INFO - 2017-02-17 11:58:31 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:58:31 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:58:31 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:58:31 --> Template Class Initialized
INFO - 2017-02-17 11:58:31 --> Controller Class Initialized
DEBUG - 2017-02-17 11:58:31 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:58:31 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:58:31 --> Model Class Initialized
INFO - 2017-02-17 11:58:31 --> Form Validation Class Initialized
INFO - 2017-02-17 11:58:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:58:31 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:58:31 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:58:31 --> Final output sent to browser
DEBUG - 2017-02-17 11:58:31 --> Total execution time: 0.0769
INFO - 2017-02-17 11:58:53 --> Config Class Initialized
INFO - 2017-02-17 11:58:53 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:58:53 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:58:53 --> Utf8 Class Initialized
INFO - 2017-02-17 11:58:53 --> URI Class Initialized
INFO - 2017-02-17 11:58:53 --> Router Class Initialized
INFO - 2017-02-17 11:58:53 --> Output Class Initialized
INFO - 2017-02-17 11:58:53 --> Security Class Initialized
DEBUG - 2017-02-17 11:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:58:53 --> Input Class Initialized
INFO - 2017-02-17 11:58:53 --> Language Class Initialized
INFO - 2017-02-17 11:58:53 --> Language Class Initialized
INFO - 2017-02-17 11:58:53 --> Config Class Initialized
INFO - 2017-02-17 11:58:53 --> Loader Class Initialized
INFO - 2017-02-17 11:58:53 --> Helper loaded: form_helper
INFO - 2017-02-17 11:58:53 --> Helper loaded: url_helper
INFO - 2017-02-17 11:58:53 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:58:53 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:58:53 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:58:53 --> Template Class Initialized
INFO - 2017-02-17 11:58:53 --> Controller Class Initialized
DEBUG - 2017-02-17 11:58:53 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:58:53 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:58:53 --> Model Class Initialized
INFO - 2017-02-17 11:58:53 --> Form Validation Class Initialized
INFO - 2017-02-17 11:58:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:58:53 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:58:53 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:58:53 --> Final output sent to browser
DEBUG - 2017-02-17 11:58:53 --> Total execution time: 0.0555
INFO - 2017-02-17 11:58:54 --> Config Class Initialized
INFO - 2017-02-17 11:58:54 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:58:54 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:58:54 --> Utf8 Class Initialized
INFO - 2017-02-17 11:58:54 --> URI Class Initialized
INFO - 2017-02-17 11:58:54 --> Router Class Initialized
INFO - 2017-02-17 11:58:54 --> Output Class Initialized
INFO - 2017-02-17 11:58:54 --> Security Class Initialized
DEBUG - 2017-02-17 11:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:58:54 --> Input Class Initialized
INFO - 2017-02-17 11:58:54 --> Language Class Initialized
INFO - 2017-02-17 11:58:54 --> Language Class Initialized
INFO - 2017-02-17 11:58:54 --> Config Class Initialized
INFO - 2017-02-17 11:58:54 --> Loader Class Initialized
INFO - 2017-02-17 11:58:54 --> Helper loaded: form_helper
INFO - 2017-02-17 11:58:54 --> Helper loaded: url_helper
INFO - 2017-02-17 11:58:54 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:58:54 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:58:54 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:58:54 --> Template Class Initialized
INFO - 2017-02-17 11:58:54 --> Controller Class Initialized
DEBUG - 2017-02-17 11:58:54 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:58:54 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:58:54 --> Model Class Initialized
INFO - 2017-02-17 11:58:54 --> Form Validation Class Initialized
INFO - 2017-02-17 11:58:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:58:54 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:58:54 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:58:54 --> Final output sent to browser
DEBUG - 2017-02-17 11:58:54 --> Total execution time: 0.0420
INFO - 2017-02-17 11:58:55 --> Config Class Initialized
INFO - 2017-02-17 11:58:55 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:58:55 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:58:55 --> Utf8 Class Initialized
INFO - 2017-02-17 11:58:55 --> URI Class Initialized
INFO - 2017-02-17 11:58:55 --> Router Class Initialized
INFO - 2017-02-17 11:58:55 --> Output Class Initialized
INFO - 2017-02-17 11:58:55 --> Security Class Initialized
DEBUG - 2017-02-17 11:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:58:55 --> Input Class Initialized
INFO - 2017-02-17 11:58:55 --> Language Class Initialized
INFO - 2017-02-17 11:58:55 --> Language Class Initialized
INFO - 2017-02-17 11:58:55 --> Config Class Initialized
INFO - 2017-02-17 11:58:55 --> Loader Class Initialized
INFO - 2017-02-17 11:58:55 --> Helper loaded: form_helper
INFO - 2017-02-17 11:58:55 --> Helper loaded: url_helper
INFO - 2017-02-17 11:58:55 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:58:55 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:58:55 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:58:55 --> Template Class Initialized
INFO - 2017-02-17 11:58:55 --> Controller Class Initialized
DEBUG - 2017-02-17 11:58:55 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:58:55 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:58:55 --> Model Class Initialized
INFO - 2017-02-17 11:58:55 --> Form Validation Class Initialized
INFO - 2017-02-17 11:58:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:58:55 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:58:55 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:58:55 --> Final output sent to browser
DEBUG - 2017-02-17 11:58:55 --> Total execution time: 0.0417
INFO - 2017-02-17 11:59:20 --> Config Class Initialized
INFO - 2017-02-17 11:59:20 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:59:20 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:59:20 --> Utf8 Class Initialized
INFO - 2017-02-17 11:59:20 --> URI Class Initialized
INFO - 2017-02-17 11:59:21 --> Router Class Initialized
INFO - 2017-02-17 11:59:21 --> Output Class Initialized
INFO - 2017-02-17 11:59:21 --> Security Class Initialized
DEBUG - 2017-02-17 11:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:59:21 --> Input Class Initialized
INFO - 2017-02-17 11:59:21 --> Language Class Initialized
INFO - 2017-02-17 11:59:21 --> Language Class Initialized
INFO - 2017-02-17 11:59:21 --> Config Class Initialized
INFO - 2017-02-17 11:59:21 --> Loader Class Initialized
INFO - 2017-02-17 11:59:21 --> Helper loaded: form_helper
INFO - 2017-02-17 11:59:21 --> Helper loaded: url_helper
INFO - 2017-02-17 11:59:21 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:59:21 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:59:21 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:59:21 --> Template Class Initialized
INFO - 2017-02-17 11:59:21 --> Controller Class Initialized
DEBUG - 2017-02-17 11:59:21 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:59:21 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:59:21 --> Model Class Initialized
INFO - 2017-02-17 11:59:21 --> Form Validation Class Initialized
INFO - 2017-02-17 11:59:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:59:21 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:59:21 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:59:21 --> Final output sent to browser
DEBUG - 2017-02-17 11:59:21 --> Total execution time: 0.0809
INFO - 2017-02-17 11:59:21 --> Config Class Initialized
INFO - 2017-02-17 11:59:21 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:59:21 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:59:21 --> Utf8 Class Initialized
INFO - 2017-02-17 11:59:21 --> URI Class Initialized
INFO - 2017-02-17 11:59:21 --> Router Class Initialized
INFO - 2017-02-17 11:59:21 --> Output Class Initialized
INFO - 2017-02-17 11:59:21 --> Security Class Initialized
DEBUG - 2017-02-17 11:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:59:21 --> Input Class Initialized
INFO - 2017-02-17 11:59:21 --> Language Class Initialized
INFO - 2017-02-17 11:59:21 --> Language Class Initialized
INFO - 2017-02-17 11:59:21 --> Config Class Initialized
INFO - 2017-02-17 11:59:21 --> Loader Class Initialized
INFO - 2017-02-17 11:59:21 --> Helper loaded: form_helper
INFO - 2017-02-17 11:59:21 --> Helper loaded: url_helper
INFO - 2017-02-17 11:59:21 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:59:21 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:59:21 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:59:21 --> Template Class Initialized
INFO - 2017-02-17 11:59:21 --> Controller Class Initialized
DEBUG - 2017-02-17 11:59:21 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:59:21 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:59:21 --> Model Class Initialized
INFO - 2017-02-17 11:59:21 --> Form Validation Class Initialized
INFO - 2017-02-17 11:59:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:59:21 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:59:21 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:59:21 --> Final output sent to browser
DEBUG - 2017-02-17 11:59:21 --> Total execution time: 0.0415
INFO - 2017-02-17 11:59:22 --> Config Class Initialized
INFO - 2017-02-17 11:59:22 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:59:22 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:59:22 --> Utf8 Class Initialized
INFO - 2017-02-17 11:59:22 --> URI Class Initialized
INFO - 2017-02-17 11:59:22 --> Router Class Initialized
INFO - 2017-02-17 11:59:22 --> Output Class Initialized
INFO - 2017-02-17 11:59:22 --> Security Class Initialized
DEBUG - 2017-02-17 11:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:59:22 --> Input Class Initialized
INFO - 2017-02-17 11:59:22 --> Language Class Initialized
INFO - 2017-02-17 11:59:22 --> Language Class Initialized
INFO - 2017-02-17 11:59:22 --> Config Class Initialized
INFO - 2017-02-17 11:59:22 --> Loader Class Initialized
INFO - 2017-02-17 11:59:22 --> Helper loaded: form_helper
INFO - 2017-02-17 11:59:22 --> Helper loaded: url_helper
INFO - 2017-02-17 11:59:22 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:59:22 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:59:22 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:59:22 --> Template Class Initialized
INFO - 2017-02-17 11:59:22 --> Controller Class Initialized
DEBUG - 2017-02-17 11:59:22 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:59:22 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:59:22 --> Model Class Initialized
INFO - 2017-02-17 11:59:22 --> Form Validation Class Initialized
INFO - 2017-02-17 11:59:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:59:22 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:59:22 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:59:22 --> Final output sent to browser
DEBUG - 2017-02-17 11:59:22 --> Total execution time: 0.0404
INFO - 2017-02-17 11:59:22 --> Config Class Initialized
INFO - 2017-02-17 11:59:22 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:59:22 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:59:22 --> Utf8 Class Initialized
INFO - 2017-02-17 11:59:22 --> URI Class Initialized
INFO - 2017-02-17 11:59:22 --> Router Class Initialized
INFO - 2017-02-17 11:59:22 --> Output Class Initialized
INFO - 2017-02-17 11:59:22 --> Security Class Initialized
DEBUG - 2017-02-17 11:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:59:22 --> Input Class Initialized
INFO - 2017-02-17 11:59:22 --> Language Class Initialized
INFO - 2017-02-17 11:59:22 --> Language Class Initialized
INFO - 2017-02-17 11:59:22 --> Config Class Initialized
INFO - 2017-02-17 11:59:22 --> Loader Class Initialized
INFO - 2017-02-17 11:59:22 --> Helper loaded: form_helper
INFO - 2017-02-17 11:59:22 --> Helper loaded: url_helper
INFO - 2017-02-17 11:59:22 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:59:22 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:59:22 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:59:22 --> Template Class Initialized
INFO - 2017-02-17 11:59:22 --> Controller Class Initialized
DEBUG - 2017-02-17 11:59:22 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:59:22 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:59:22 --> Model Class Initialized
INFO - 2017-02-17 11:59:22 --> Form Validation Class Initialized
INFO - 2017-02-17 11:59:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:59:22 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:59:22 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:59:22 --> Final output sent to browser
DEBUG - 2017-02-17 11:59:22 --> Total execution time: 0.0501
INFO - 2017-02-17 11:59:23 --> Config Class Initialized
INFO - 2017-02-17 11:59:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 11:59:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 11:59:23 --> Utf8 Class Initialized
INFO - 2017-02-17 11:59:23 --> URI Class Initialized
INFO - 2017-02-17 11:59:23 --> Router Class Initialized
INFO - 2017-02-17 11:59:23 --> Output Class Initialized
INFO - 2017-02-17 11:59:23 --> Security Class Initialized
DEBUG - 2017-02-17 11:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 11:59:23 --> Input Class Initialized
INFO - 2017-02-17 11:59:23 --> Language Class Initialized
INFO - 2017-02-17 11:59:23 --> Language Class Initialized
INFO - 2017-02-17 11:59:23 --> Config Class Initialized
INFO - 2017-02-17 11:59:23 --> Loader Class Initialized
INFO - 2017-02-17 11:59:23 --> Helper loaded: form_helper
INFO - 2017-02-17 11:59:23 --> Helper loaded: url_helper
INFO - 2017-02-17 11:59:23 --> Helper loaded: utility_helper
INFO - 2017-02-17 11:59:23 --> Database Driver Class Initialized
DEBUG - 2017-02-17 11:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 11:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 11:59:23 --> User Agent Class Initialized
DEBUG - 2017-02-17 11:59:23 --> Template Class Initialized
INFO - 2017-02-17 11:59:23 --> Controller Class Initialized
DEBUG - 2017-02-17 11:59:23 --> Login MX_Controller Initialized
INFO - 2017-02-17 11:59:23 --> Helper loaded: cookie_helper
INFO - 2017-02-17 11:59:23 --> Model Class Initialized
INFO - 2017-02-17 11:59:23 --> Form Validation Class Initialized
INFO - 2017-02-17 11:59:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 11:59:23 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 11:59:23 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 11:59:23 --> Final output sent to browser
DEBUG - 2017-02-17 11:59:23 --> Total execution time: 0.0405
INFO - 2017-02-17 12:00:16 --> Config Class Initialized
INFO - 2017-02-17 12:00:16 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:00:16 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:00:16 --> Utf8 Class Initialized
INFO - 2017-02-17 12:00:16 --> URI Class Initialized
INFO - 2017-02-17 12:00:16 --> Router Class Initialized
INFO - 2017-02-17 12:00:16 --> Output Class Initialized
INFO - 2017-02-17 12:00:16 --> Security Class Initialized
DEBUG - 2017-02-17 12:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:00:16 --> Input Class Initialized
INFO - 2017-02-17 12:00:16 --> Language Class Initialized
INFO - 2017-02-17 12:00:16 --> Language Class Initialized
INFO - 2017-02-17 12:00:16 --> Config Class Initialized
INFO - 2017-02-17 12:00:16 --> Loader Class Initialized
INFO - 2017-02-17 12:00:16 --> Helper loaded: form_helper
INFO - 2017-02-17 12:00:16 --> Helper loaded: url_helper
INFO - 2017-02-17 12:00:16 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:00:16 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:00:16 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:00:16 --> Template Class Initialized
INFO - 2017-02-17 12:00:16 --> Controller Class Initialized
DEBUG - 2017-02-17 12:00:16 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:00:16 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:00:16 --> Model Class Initialized
INFO - 2017-02-17 12:00:16 --> Form Validation Class Initialized
DEBUG - 2017-02-17 12:00:16 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:00:16 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:00:16 --> Final output sent to browser
DEBUG - 2017-02-17 12:00:16 --> Total execution time: 0.0406
INFO - 2017-02-17 12:00:17 --> Config Class Initialized
INFO - 2017-02-17 12:00:17 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:00:17 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:00:17 --> Utf8 Class Initialized
INFO - 2017-02-17 12:00:17 --> URI Class Initialized
INFO - 2017-02-17 12:00:17 --> Router Class Initialized
INFO - 2017-02-17 12:00:17 --> Output Class Initialized
INFO - 2017-02-17 12:00:17 --> Security Class Initialized
DEBUG - 2017-02-17 12:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:00:17 --> Input Class Initialized
INFO - 2017-02-17 12:00:17 --> Language Class Initialized
INFO - 2017-02-17 12:00:17 --> Language Class Initialized
INFO - 2017-02-17 12:00:17 --> Config Class Initialized
INFO - 2017-02-17 12:00:17 --> Loader Class Initialized
INFO - 2017-02-17 12:00:17 --> Helper loaded: form_helper
INFO - 2017-02-17 12:00:17 --> Helper loaded: url_helper
INFO - 2017-02-17 12:00:17 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:00:17 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:00:17 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:00:17 --> Template Class Initialized
INFO - 2017-02-17 12:00:17 --> Controller Class Initialized
DEBUG - 2017-02-17 12:00:17 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:00:17 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:00:17 --> Model Class Initialized
INFO - 2017-02-17 12:00:17 --> Form Validation Class Initialized
INFO - 2017-02-17 12:00:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 12:00:17 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:00:17 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:00:17 --> Final output sent to browser
DEBUG - 2017-02-17 12:00:17 --> Total execution time: 0.0729
INFO - 2017-02-17 12:00:56 --> Config Class Initialized
INFO - 2017-02-17 12:00:56 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:00:56 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:00:56 --> Utf8 Class Initialized
INFO - 2017-02-17 12:00:56 --> URI Class Initialized
INFO - 2017-02-17 12:00:56 --> Router Class Initialized
INFO - 2017-02-17 12:00:56 --> Output Class Initialized
INFO - 2017-02-17 12:00:56 --> Security Class Initialized
DEBUG - 2017-02-17 12:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:00:56 --> Input Class Initialized
INFO - 2017-02-17 12:00:56 --> Language Class Initialized
INFO - 2017-02-17 12:00:56 --> Language Class Initialized
INFO - 2017-02-17 12:00:56 --> Config Class Initialized
INFO - 2017-02-17 12:00:56 --> Loader Class Initialized
INFO - 2017-02-17 12:00:56 --> Helper loaded: form_helper
INFO - 2017-02-17 12:00:56 --> Helper loaded: url_helper
INFO - 2017-02-17 12:00:56 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:00:56 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:00:56 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:00:56 --> Template Class Initialized
INFO - 2017-02-17 12:00:56 --> Controller Class Initialized
DEBUG - 2017-02-17 12:00:56 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:00:56 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:00:56 --> Model Class Initialized
INFO - 2017-02-17 12:00:56 --> Form Validation Class Initialized
INFO - 2017-02-17 12:00:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 12:00:56 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:00:56 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:00:56 --> Final output sent to browser
DEBUG - 2017-02-17 12:00:56 --> Total execution time: 0.0615
INFO - 2017-02-17 12:00:57 --> Config Class Initialized
INFO - 2017-02-17 12:00:57 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:00:57 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:00:57 --> Utf8 Class Initialized
INFO - 2017-02-17 12:00:57 --> URI Class Initialized
INFO - 2017-02-17 12:00:57 --> Router Class Initialized
INFO - 2017-02-17 12:00:57 --> Output Class Initialized
INFO - 2017-02-17 12:00:57 --> Security Class Initialized
DEBUG - 2017-02-17 12:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:00:57 --> Input Class Initialized
INFO - 2017-02-17 12:00:57 --> Language Class Initialized
INFO - 2017-02-17 12:00:57 --> Language Class Initialized
INFO - 2017-02-17 12:00:57 --> Config Class Initialized
INFO - 2017-02-17 12:00:57 --> Loader Class Initialized
INFO - 2017-02-17 12:00:57 --> Helper loaded: form_helper
INFO - 2017-02-17 12:00:57 --> Helper loaded: url_helper
INFO - 2017-02-17 12:00:57 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:00:57 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:00:57 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:00:57 --> Template Class Initialized
INFO - 2017-02-17 12:00:57 --> Controller Class Initialized
DEBUG - 2017-02-17 12:00:57 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:00:57 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:00:57 --> Model Class Initialized
INFO - 2017-02-17 12:00:57 --> Form Validation Class Initialized
INFO - 2017-02-17 12:00:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 12:00:57 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:00:57 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:00:57 --> Final output sent to browser
DEBUG - 2017-02-17 12:00:57 --> Total execution time: 0.0419
INFO - 2017-02-17 12:01:09 --> Config Class Initialized
INFO - 2017-02-17 12:01:09 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:01:09 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:01:09 --> Utf8 Class Initialized
INFO - 2017-02-17 12:01:09 --> URI Class Initialized
INFO - 2017-02-17 12:01:09 --> Router Class Initialized
INFO - 2017-02-17 12:01:09 --> Output Class Initialized
INFO - 2017-02-17 12:01:09 --> Security Class Initialized
DEBUG - 2017-02-17 12:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:01:09 --> Input Class Initialized
INFO - 2017-02-17 12:01:09 --> Language Class Initialized
INFO - 2017-02-17 12:01:09 --> Language Class Initialized
INFO - 2017-02-17 12:01:09 --> Config Class Initialized
INFO - 2017-02-17 12:01:09 --> Loader Class Initialized
INFO - 2017-02-17 12:01:09 --> Helper loaded: form_helper
INFO - 2017-02-17 12:01:09 --> Helper loaded: url_helper
INFO - 2017-02-17 12:01:09 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:01:09 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:01:09 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:01:09 --> Template Class Initialized
INFO - 2017-02-17 12:01:09 --> Controller Class Initialized
DEBUG - 2017-02-17 12:01:09 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:01:09 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:01:09 --> Model Class Initialized
INFO - 2017-02-17 12:01:09 --> Form Validation Class Initialized
INFO - 2017-02-17 12:01:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 12:01:09 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:01:09 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:01:09 --> Final output sent to browser
DEBUG - 2017-02-17 12:01:09 --> Total execution time: 0.0490
INFO - 2017-02-17 12:01:45 --> Config Class Initialized
INFO - 2017-02-17 12:01:45 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:01:45 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:01:45 --> Utf8 Class Initialized
INFO - 2017-02-17 12:01:45 --> URI Class Initialized
INFO - 2017-02-17 12:01:45 --> Router Class Initialized
INFO - 2017-02-17 12:01:45 --> Output Class Initialized
INFO - 2017-02-17 12:01:45 --> Security Class Initialized
DEBUG - 2017-02-17 12:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:01:45 --> Input Class Initialized
INFO - 2017-02-17 12:01:45 --> Language Class Initialized
INFO - 2017-02-17 12:01:45 --> Language Class Initialized
INFO - 2017-02-17 12:01:45 --> Config Class Initialized
INFO - 2017-02-17 12:01:45 --> Loader Class Initialized
INFO - 2017-02-17 12:01:45 --> Helper loaded: form_helper
INFO - 2017-02-17 12:01:45 --> Helper loaded: url_helper
INFO - 2017-02-17 12:01:45 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:01:45 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:01:45 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:01:45 --> Template Class Initialized
INFO - 2017-02-17 12:01:45 --> Controller Class Initialized
DEBUG - 2017-02-17 12:01:45 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:01:45 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:01:45 --> Model Class Initialized
INFO - 2017-02-17 12:01:45 --> Form Validation Class Initialized
INFO - 2017-02-17 12:01:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 12:01:45 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:01:45 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:01:45 --> Final output sent to browser
DEBUG - 2017-02-17 12:01:45 --> Total execution time: 0.0615
INFO - 2017-02-17 12:01:46 --> Config Class Initialized
INFO - 2017-02-17 12:01:46 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:01:46 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:01:46 --> Utf8 Class Initialized
INFO - 2017-02-17 12:01:46 --> URI Class Initialized
INFO - 2017-02-17 12:01:46 --> Router Class Initialized
INFO - 2017-02-17 12:01:46 --> Output Class Initialized
INFO - 2017-02-17 12:01:46 --> Security Class Initialized
DEBUG - 2017-02-17 12:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:01:46 --> Input Class Initialized
INFO - 2017-02-17 12:01:46 --> Language Class Initialized
INFO - 2017-02-17 12:01:46 --> Language Class Initialized
INFO - 2017-02-17 12:01:46 --> Config Class Initialized
INFO - 2017-02-17 12:01:46 --> Loader Class Initialized
INFO - 2017-02-17 12:01:46 --> Helper loaded: form_helper
INFO - 2017-02-17 12:01:46 --> Helper loaded: url_helper
INFO - 2017-02-17 12:01:46 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:01:46 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:01:46 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:01:46 --> Template Class Initialized
INFO - 2017-02-17 12:01:46 --> Controller Class Initialized
DEBUG - 2017-02-17 12:01:46 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:01:46 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:01:46 --> Model Class Initialized
INFO - 2017-02-17 12:01:46 --> Form Validation Class Initialized
INFO - 2017-02-17 12:01:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 12:01:46 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:01:46 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:01:46 --> Final output sent to browser
DEBUG - 2017-02-17 12:01:46 --> Total execution time: 0.0410
INFO - 2017-02-17 12:01:47 --> Config Class Initialized
INFO - 2017-02-17 12:01:47 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:01:47 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:01:47 --> Utf8 Class Initialized
INFO - 2017-02-17 12:01:47 --> URI Class Initialized
INFO - 2017-02-17 12:01:47 --> Router Class Initialized
INFO - 2017-02-17 12:01:47 --> Output Class Initialized
INFO - 2017-02-17 12:01:47 --> Security Class Initialized
DEBUG - 2017-02-17 12:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:01:47 --> Input Class Initialized
INFO - 2017-02-17 12:01:47 --> Language Class Initialized
INFO - 2017-02-17 12:01:47 --> Language Class Initialized
INFO - 2017-02-17 12:01:47 --> Config Class Initialized
INFO - 2017-02-17 12:01:47 --> Loader Class Initialized
INFO - 2017-02-17 12:01:47 --> Helper loaded: form_helper
INFO - 2017-02-17 12:01:47 --> Helper loaded: url_helper
INFO - 2017-02-17 12:01:47 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:01:47 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:01:47 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:01:47 --> Template Class Initialized
INFO - 2017-02-17 12:01:47 --> Controller Class Initialized
DEBUG - 2017-02-17 12:01:47 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:01:47 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:01:47 --> Model Class Initialized
INFO - 2017-02-17 12:01:47 --> Form Validation Class Initialized
INFO - 2017-02-17 12:01:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 12:01:47 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:01:47 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:01:47 --> Final output sent to browser
DEBUG - 2017-02-17 12:01:47 --> Total execution time: 0.0406
INFO - 2017-02-17 12:01:48 --> Config Class Initialized
INFO - 2017-02-17 12:01:48 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:01:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:01:48 --> Utf8 Class Initialized
INFO - 2017-02-17 12:01:48 --> URI Class Initialized
INFO - 2017-02-17 12:01:48 --> Router Class Initialized
INFO - 2017-02-17 12:01:48 --> Output Class Initialized
INFO - 2017-02-17 12:01:48 --> Security Class Initialized
DEBUG - 2017-02-17 12:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:01:48 --> Input Class Initialized
INFO - 2017-02-17 12:01:48 --> Language Class Initialized
INFO - 2017-02-17 12:01:48 --> Language Class Initialized
INFO - 2017-02-17 12:01:48 --> Config Class Initialized
INFO - 2017-02-17 12:01:48 --> Loader Class Initialized
INFO - 2017-02-17 12:01:48 --> Helper loaded: form_helper
INFO - 2017-02-17 12:01:48 --> Helper loaded: url_helper
INFO - 2017-02-17 12:01:48 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:01:48 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:01:48 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:01:48 --> Template Class Initialized
INFO - 2017-02-17 12:01:48 --> Controller Class Initialized
DEBUG - 2017-02-17 12:01:48 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:01:48 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:01:48 --> Model Class Initialized
INFO - 2017-02-17 12:01:48 --> Form Validation Class Initialized
INFO - 2017-02-17 12:01:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 12:01:48 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:01:48 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:01:48 --> Final output sent to browser
DEBUG - 2017-02-17 12:01:48 --> Total execution time: 0.0411
INFO - 2017-02-17 12:01:55 --> Config Class Initialized
INFO - 2017-02-17 12:01:55 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:01:55 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:01:55 --> Utf8 Class Initialized
INFO - 2017-02-17 12:01:55 --> URI Class Initialized
INFO - 2017-02-17 12:01:55 --> Router Class Initialized
INFO - 2017-02-17 12:01:55 --> Output Class Initialized
INFO - 2017-02-17 12:01:55 --> Security Class Initialized
DEBUG - 2017-02-17 12:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:01:55 --> Input Class Initialized
INFO - 2017-02-17 12:01:55 --> Language Class Initialized
INFO - 2017-02-17 12:01:55 --> Language Class Initialized
INFO - 2017-02-17 12:01:55 --> Config Class Initialized
INFO - 2017-02-17 12:01:55 --> Loader Class Initialized
INFO - 2017-02-17 12:01:55 --> Helper loaded: form_helper
INFO - 2017-02-17 12:01:55 --> Helper loaded: url_helper
INFO - 2017-02-17 12:01:55 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:01:55 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:01:55 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:01:55 --> Template Class Initialized
INFO - 2017-02-17 12:01:55 --> Controller Class Initialized
DEBUG - 2017-02-17 12:01:55 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:01:55 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:01:55 --> Model Class Initialized
INFO - 2017-02-17 12:01:55 --> Form Validation Class Initialized
DEBUG - 2017-02-17 12:01:55 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:01:55 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:01:55 --> Final output sent to browser
DEBUG - 2017-02-17 12:01:55 --> Total execution time: 0.0426
INFO - 2017-02-17 12:01:56 --> Config Class Initialized
INFO - 2017-02-17 12:01:56 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:01:56 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:01:56 --> Utf8 Class Initialized
INFO - 2017-02-17 12:01:56 --> URI Class Initialized
INFO - 2017-02-17 12:01:56 --> Router Class Initialized
INFO - 2017-02-17 12:01:56 --> Output Class Initialized
INFO - 2017-02-17 12:01:56 --> Security Class Initialized
DEBUG - 2017-02-17 12:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:01:56 --> Input Class Initialized
INFO - 2017-02-17 12:01:56 --> Language Class Initialized
INFO - 2017-02-17 12:01:56 --> Language Class Initialized
INFO - 2017-02-17 12:01:56 --> Config Class Initialized
INFO - 2017-02-17 12:01:56 --> Loader Class Initialized
INFO - 2017-02-17 12:01:56 --> Helper loaded: form_helper
INFO - 2017-02-17 12:01:56 --> Helper loaded: url_helper
INFO - 2017-02-17 12:01:56 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:01:56 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:01:56 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:01:56 --> Template Class Initialized
INFO - 2017-02-17 12:01:56 --> Controller Class Initialized
DEBUG - 2017-02-17 12:01:56 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:01:56 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:01:56 --> Model Class Initialized
INFO - 2017-02-17 12:01:56 --> Form Validation Class Initialized
DEBUG - 2017-02-17 12:01:56 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:01:56 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:01:56 --> Final output sent to browser
DEBUG - 2017-02-17 12:01:56 --> Total execution time: 0.0399
INFO - 2017-02-17 12:02:20 --> Config Class Initialized
INFO - 2017-02-17 12:02:20 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:02:20 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:02:20 --> Utf8 Class Initialized
INFO - 2017-02-17 12:02:20 --> URI Class Initialized
INFO - 2017-02-17 12:02:20 --> Router Class Initialized
INFO - 2017-02-17 12:02:20 --> Output Class Initialized
INFO - 2017-02-17 12:02:20 --> Security Class Initialized
DEBUG - 2017-02-17 12:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:02:20 --> Input Class Initialized
INFO - 2017-02-17 12:02:20 --> Language Class Initialized
INFO - 2017-02-17 12:02:20 --> Language Class Initialized
INFO - 2017-02-17 12:02:20 --> Config Class Initialized
INFO - 2017-02-17 12:02:20 --> Loader Class Initialized
INFO - 2017-02-17 12:02:20 --> Helper loaded: form_helper
INFO - 2017-02-17 12:02:20 --> Helper loaded: url_helper
INFO - 2017-02-17 12:02:20 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:02:20 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:02:20 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:02:20 --> Template Class Initialized
INFO - 2017-02-17 12:02:20 --> Controller Class Initialized
DEBUG - 2017-02-17 12:02:20 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:02:20 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:02:20 --> Model Class Initialized
INFO - 2017-02-17 12:02:20 --> Form Validation Class Initialized
INFO - 2017-02-17 12:02:28 --> Config Class Initialized
INFO - 2017-02-17 12:02:28 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:02:28 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:02:28 --> Utf8 Class Initialized
INFO - 2017-02-17 12:02:28 --> URI Class Initialized
INFO - 2017-02-17 12:02:28 --> Router Class Initialized
INFO - 2017-02-17 12:02:28 --> Output Class Initialized
INFO - 2017-02-17 12:02:28 --> Security Class Initialized
DEBUG - 2017-02-17 12:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:02:28 --> Input Class Initialized
INFO - 2017-02-17 12:02:28 --> Language Class Initialized
INFO - 2017-02-17 12:02:28 --> Language Class Initialized
INFO - 2017-02-17 12:02:28 --> Config Class Initialized
INFO - 2017-02-17 12:02:28 --> Loader Class Initialized
INFO - 2017-02-17 12:02:28 --> Helper loaded: form_helper
INFO - 2017-02-17 12:02:28 --> Helper loaded: url_helper
INFO - 2017-02-17 12:02:28 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:02:28 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:02:28 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:02:28 --> Template Class Initialized
INFO - 2017-02-17 12:02:28 --> Controller Class Initialized
DEBUG - 2017-02-17 12:02:28 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:02:28 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:02:28 --> Model Class Initialized
INFO - 2017-02-17 12:02:28 --> Form Validation Class Initialized
DEBUG - 2017-02-17 12:02:28 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:02:28 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:02:28 --> Final output sent to browser
DEBUG - 2017-02-17 12:02:28 --> Total execution time: 0.0409
INFO - 2017-02-17 12:05:11 --> Config Class Initialized
INFO - 2017-02-17 12:05:11 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:05:11 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:05:11 --> Utf8 Class Initialized
INFO - 2017-02-17 12:05:11 --> URI Class Initialized
INFO - 2017-02-17 12:05:11 --> Router Class Initialized
INFO - 2017-02-17 12:05:11 --> Output Class Initialized
INFO - 2017-02-17 12:05:11 --> Security Class Initialized
DEBUG - 2017-02-17 12:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:05:11 --> Input Class Initialized
INFO - 2017-02-17 12:05:11 --> Language Class Initialized
INFO - 2017-02-17 12:05:11 --> Language Class Initialized
INFO - 2017-02-17 12:05:11 --> Config Class Initialized
INFO - 2017-02-17 12:05:11 --> Loader Class Initialized
INFO - 2017-02-17 12:05:11 --> Helper loaded: form_helper
INFO - 2017-02-17 12:05:11 --> Helper loaded: url_helper
INFO - 2017-02-17 12:05:11 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:05:11 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:05:11 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:05:11 --> Template Class Initialized
INFO - 2017-02-17 12:05:11 --> Controller Class Initialized
DEBUG - 2017-02-17 12:05:11 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:05:11 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:05:11 --> Model Class Initialized
INFO - 2017-02-17 12:05:11 --> Form Validation Class Initialized
DEBUG - 2017-02-17 12:05:11 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:05:11 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:05:11 --> Final output sent to browser
DEBUG - 2017-02-17 12:05:11 --> Total execution time: 0.0582
INFO - 2017-02-17 12:05:12 --> Config Class Initialized
INFO - 2017-02-17 12:05:12 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:05:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:05:12 --> Utf8 Class Initialized
INFO - 2017-02-17 12:05:12 --> URI Class Initialized
INFO - 2017-02-17 12:05:12 --> Router Class Initialized
INFO - 2017-02-17 12:05:12 --> Output Class Initialized
INFO - 2017-02-17 12:05:12 --> Security Class Initialized
DEBUG - 2017-02-17 12:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:05:12 --> Input Class Initialized
INFO - 2017-02-17 12:05:12 --> Language Class Initialized
INFO - 2017-02-17 12:05:12 --> Language Class Initialized
INFO - 2017-02-17 12:05:12 --> Config Class Initialized
INFO - 2017-02-17 12:05:12 --> Loader Class Initialized
INFO - 2017-02-17 12:05:12 --> Helper loaded: form_helper
INFO - 2017-02-17 12:05:12 --> Helper loaded: url_helper
INFO - 2017-02-17 12:05:12 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:05:12 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:05:12 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:05:12 --> Template Class Initialized
INFO - 2017-02-17 12:05:12 --> Controller Class Initialized
DEBUG - 2017-02-17 12:05:12 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:05:12 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:05:12 --> Model Class Initialized
INFO - 2017-02-17 12:05:12 --> Form Validation Class Initialized
DEBUG - 2017-02-17 12:05:12 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:05:12 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:05:12 --> Final output sent to browser
DEBUG - 2017-02-17 12:05:12 --> Total execution time: 0.0894
INFO - 2017-02-17 12:05:46 --> Config Class Initialized
INFO - 2017-02-17 12:05:46 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:05:46 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:05:46 --> Utf8 Class Initialized
INFO - 2017-02-17 12:05:46 --> URI Class Initialized
INFO - 2017-02-17 12:05:46 --> Router Class Initialized
INFO - 2017-02-17 12:05:46 --> Output Class Initialized
INFO - 2017-02-17 12:05:46 --> Security Class Initialized
DEBUG - 2017-02-17 12:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:05:46 --> Input Class Initialized
INFO - 2017-02-17 12:05:46 --> Language Class Initialized
INFO - 2017-02-17 12:05:46 --> Language Class Initialized
INFO - 2017-02-17 12:05:46 --> Config Class Initialized
INFO - 2017-02-17 12:05:46 --> Loader Class Initialized
INFO - 2017-02-17 12:05:46 --> Helper loaded: form_helper
INFO - 2017-02-17 12:05:46 --> Helper loaded: url_helper
INFO - 2017-02-17 12:05:46 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:05:46 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:05:46 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:05:46 --> Template Class Initialized
INFO - 2017-02-17 12:05:46 --> Controller Class Initialized
DEBUG - 2017-02-17 12:05:46 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:05:46 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:05:46 --> Model Class Initialized
INFO - 2017-02-17 12:05:46 --> Form Validation Class Initialized
DEBUG - 2017-02-17 12:05:46 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:05:46 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:05:46 --> Final output sent to browser
DEBUG - 2017-02-17 12:05:46 --> Total execution time: 0.0633
INFO - 2017-02-17 12:06:15 --> Config Class Initialized
INFO - 2017-02-17 12:06:15 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:06:15 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:06:15 --> Utf8 Class Initialized
INFO - 2017-02-17 12:06:15 --> URI Class Initialized
INFO - 2017-02-17 12:06:15 --> Router Class Initialized
INFO - 2017-02-17 12:06:15 --> Output Class Initialized
INFO - 2017-02-17 12:06:15 --> Security Class Initialized
DEBUG - 2017-02-17 12:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:06:15 --> Input Class Initialized
INFO - 2017-02-17 12:06:15 --> Language Class Initialized
INFO - 2017-02-17 12:06:15 --> Language Class Initialized
INFO - 2017-02-17 12:06:15 --> Config Class Initialized
INFO - 2017-02-17 12:06:15 --> Loader Class Initialized
INFO - 2017-02-17 12:06:15 --> Helper loaded: form_helper
INFO - 2017-02-17 12:06:15 --> Helper loaded: url_helper
INFO - 2017-02-17 12:06:15 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:06:15 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:06:15 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:06:15 --> Template Class Initialized
INFO - 2017-02-17 12:06:15 --> Controller Class Initialized
DEBUG - 2017-02-17 12:06:15 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:06:15 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:06:15 --> Model Class Initialized
INFO - 2017-02-17 12:06:15 --> Form Validation Class Initialized
DEBUG - 2017-02-17 12:06:15 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:06:15 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:06:15 --> Final output sent to browser
DEBUG - 2017-02-17 12:06:15 --> Total execution time: 0.0437
INFO - 2017-02-17 12:06:50 --> Config Class Initialized
INFO - 2017-02-17 12:06:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:06:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:06:50 --> Utf8 Class Initialized
INFO - 2017-02-17 12:06:50 --> URI Class Initialized
INFO - 2017-02-17 12:06:50 --> Router Class Initialized
INFO - 2017-02-17 12:06:50 --> Output Class Initialized
INFO - 2017-02-17 12:06:50 --> Security Class Initialized
DEBUG - 2017-02-17 12:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:06:50 --> Input Class Initialized
INFO - 2017-02-17 12:06:50 --> Language Class Initialized
INFO - 2017-02-17 12:06:50 --> Language Class Initialized
INFO - 2017-02-17 12:06:50 --> Config Class Initialized
INFO - 2017-02-17 12:06:50 --> Loader Class Initialized
INFO - 2017-02-17 12:06:50 --> Helper loaded: form_helper
INFO - 2017-02-17 12:06:50 --> Helper loaded: url_helper
INFO - 2017-02-17 12:06:50 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:06:50 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:06:50 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:06:50 --> Template Class Initialized
INFO - 2017-02-17 12:06:50 --> Controller Class Initialized
DEBUG - 2017-02-17 12:06:50 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:06:50 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:06:50 --> Model Class Initialized
INFO - 2017-02-17 12:06:50 --> Form Validation Class Initialized
DEBUG - 2017-02-17 12:06:50 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:06:50 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:06:50 --> Final output sent to browser
DEBUG - 2017-02-17 12:06:50 --> Total execution time: 0.0716
INFO - 2017-02-17 12:08:39 --> Config Class Initialized
INFO - 2017-02-17 12:08:39 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:08:39 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:08:39 --> Utf8 Class Initialized
INFO - 2017-02-17 12:08:39 --> URI Class Initialized
INFO - 2017-02-17 12:08:39 --> Router Class Initialized
INFO - 2017-02-17 12:08:39 --> Output Class Initialized
INFO - 2017-02-17 12:08:39 --> Security Class Initialized
DEBUG - 2017-02-17 12:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:08:39 --> Input Class Initialized
INFO - 2017-02-17 12:08:39 --> Language Class Initialized
INFO - 2017-02-17 12:08:39 --> Language Class Initialized
INFO - 2017-02-17 12:08:39 --> Config Class Initialized
INFO - 2017-02-17 12:08:39 --> Loader Class Initialized
INFO - 2017-02-17 12:08:39 --> Helper loaded: form_helper
INFO - 2017-02-17 12:08:39 --> Helper loaded: url_helper
INFO - 2017-02-17 12:08:39 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:08:39 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:08:39 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:08:39 --> Template Class Initialized
INFO - 2017-02-17 12:08:39 --> Controller Class Initialized
DEBUG - 2017-02-17 12:08:39 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:08:39 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:08:39 --> Model Class Initialized
INFO - 2017-02-17 12:08:39 --> Form Validation Class Initialized
DEBUG - 2017-02-17 12:08:39 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:08:39 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:08:39 --> Final output sent to browser
DEBUG - 2017-02-17 12:08:39 --> Total execution time: 0.0748
INFO - 2017-02-17 12:08:52 --> Config Class Initialized
INFO - 2017-02-17 12:08:52 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:08:52 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:08:52 --> Utf8 Class Initialized
INFO - 2017-02-17 12:08:52 --> URI Class Initialized
INFO - 2017-02-17 12:08:52 --> Router Class Initialized
INFO - 2017-02-17 12:08:52 --> Output Class Initialized
INFO - 2017-02-17 12:08:52 --> Security Class Initialized
DEBUG - 2017-02-17 12:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:08:52 --> Input Class Initialized
INFO - 2017-02-17 12:08:52 --> Language Class Initialized
INFO - 2017-02-17 12:08:52 --> Language Class Initialized
INFO - 2017-02-17 12:08:52 --> Config Class Initialized
INFO - 2017-02-17 12:08:52 --> Loader Class Initialized
INFO - 2017-02-17 12:08:52 --> Helper loaded: form_helper
INFO - 2017-02-17 12:08:52 --> Helper loaded: url_helper
INFO - 2017-02-17 12:08:52 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:08:52 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:08:52 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:08:52 --> Template Class Initialized
INFO - 2017-02-17 12:08:52 --> Controller Class Initialized
DEBUG - 2017-02-17 12:08:52 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:08:52 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:08:52 --> Model Class Initialized
INFO - 2017-02-17 12:08:52 --> Form Validation Class Initialized
DEBUG - 2017-02-17 12:08:52 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:08:52 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:08:52 --> Final output sent to browser
DEBUG - 2017-02-17 12:08:52 --> Total execution time: 0.0827
INFO - 2017-02-17 12:09:00 --> Config Class Initialized
INFO - 2017-02-17 12:09:00 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:09:00 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:09:00 --> Utf8 Class Initialized
INFO - 2017-02-17 12:09:00 --> URI Class Initialized
INFO - 2017-02-17 12:09:00 --> Router Class Initialized
INFO - 2017-02-17 12:09:00 --> Output Class Initialized
INFO - 2017-02-17 12:09:00 --> Security Class Initialized
DEBUG - 2017-02-17 12:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:09:00 --> Input Class Initialized
INFO - 2017-02-17 12:09:00 --> Language Class Initialized
INFO - 2017-02-17 12:09:00 --> Language Class Initialized
INFO - 2017-02-17 12:09:00 --> Config Class Initialized
INFO - 2017-02-17 12:09:00 --> Loader Class Initialized
INFO - 2017-02-17 12:09:00 --> Helper loaded: form_helper
INFO - 2017-02-17 12:09:00 --> Helper loaded: url_helper
INFO - 2017-02-17 12:09:00 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:09:00 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:09:00 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:09:00 --> Template Class Initialized
INFO - 2017-02-17 12:09:00 --> Controller Class Initialized
DEBUG - 2017-02-17 12:09:00 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:09:00 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:09:00 --> Model Class Initialized
INFO - 2017-02-17 12:09:00 --> Form Validation Class Initialized
INFO - 2017-02-17 12:09:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 12:09:01 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:09:01 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:09:01 --> Final output sent to browser
DEBUG - 2017-02-17 12:09:01 --> Total execution time: 0.7010
INFO - 2017-02-17 12:09:27 --> Config Class Initialized
INFO - 2017-02-17 12:09:27 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:09:27 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:09:27 --> Utf8 Class Initialized
INFO - 2017-02-17 12:09:27 --> URI Class Initialized
INFO - 2017-02-17 12:09:27 --> Router Class Initialized
INFO - 2017-02-17 12:09:27 --> Output Class Initialized
INFO - 2017-02-17 12:09:27 --> Security Class Initialized
DEBUG - 2017-02-17 12:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:09:27 --> Input Class Initialized
INFO - 2017-02-17 12:09:27 --> Language Class Initialized
INFO - 2017-02-17 12:09:27 --> Language Class Initialized
INFO - 2017-02-17 12:09:27 --> Config Class Initialized
INFO - 2017-02-17 12:09:27 --> Loader Class Initialized
INFO - 2017-02-17 12:09:27 --> Helper loaded: form_helper
INFO - 2017-02-17 12:09:27 --> Helper loaded: url_helper
INFO - 2017-02-17 12:09:27 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:09:27 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:09:27 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:09:27 --> Template Class Initialized
INFO - 2017-02-17 12:09:27 --> Controller Class Initialized
DEBUG - 2017-02-17 12:09:27 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:09:27 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:09:27 --> Model Class Initialized
INFO - 2017-02-17 12:09:27 --> Form Validation Class Initialized
INFO - 2017-02-17 12:09:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 12:09:27 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:09:27 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:09:27 --> Final output sent to browser
DEBUG - 2017-02-17 12:09:27 --> Total execution time: 0.0837
INFO - 2017-02-17 12:09:28 --> Config Class Initialized
INFO - 2017-02-17 12:09:28 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:09:28 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:09:28 --> Utf8 Class Initialized
INFO - 2017-02-17 12:09:28 --> URI Class Initialized
INFO - 2017-02-17 12:09:28 --> Router Class Initialized
INFO - 2017-02-17 12:09:28 --> Output Class Initialized
INFO - 2017-02-17 12:09:28 --> Security Class Initialized
DEBUG - 2017-02-17 12:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:09:28 --> Input Class Initialized
INFO - 2017-02-17 12:09:28 --> Language Class Initialized
INFO - 2017-02-17 12:09:28 --> Language Class Initialized
INFO - 2017-02-17 12:09:28 --> Config Class Initialized
INFO - 2017-02-17 12:09:28 --> Loader Class Initialized
INFO - 2017-02-17 12:09:28 --> Helper loaded: form_helper
INFO - 2017-02-17 12:09:28 --> Helper loaded: url_helper
INFO - 2017-02-17 12:09:28 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:09:28 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:09:28 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:09:28 --> Template Class Initialized
INFO - 2017-02-17 12:09:28 --> Controller Class Initialized
DEBUG - 2017-02-17 12:09:28 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:09:28 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:09:28 --> Model Class Initialized
INFO - 2017-02-17 12:09:28 --> Form Validation Class Initialized
INFO - 2017-02-17 12:09:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 12:09:28 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:09:28 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:09:28 --> Final output sent to browser
DEBUG - 2017-02-17 12:09:28 --> Total execution time: 0.0415
INFO - 2017-02-17 12:10:26 --> Config Class Initialized
INFO - 2017-02-17 12:10:26 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:10:26 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:10:26 --> Utf8 Class Initialized
INFO - 2017-02-17 12:10:26 --> URI Class Initialized
INFO - 2017-02-17 12:10:26 --> Router Class Initialized
INFO - 2017-02-17 12:10:26 --> Output Class Initialized
INFO - 2017-02-17 12:10:26 --> Security Class Initialized
DEBUG - 2017-02-17 12:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:10:26 --> Input Class Initialized
INFO - 2017-02-17 12:10:26 --> Language Class Initialized
INFO - 2017-02-17 12:10:26 --> Language Class Initialized
INFO - 2017-02-17 12:10:26 --> Config Class Initialized
INFO - 2017-02-17 12:10:26 --> Loader Class Initialized
INFO - 2017-02-17 12:10:26 --> Helper loaded: form_helper
INFO - 2017-02-17 12:10:26 --> Helper loaded: url_helper
INFO - 2017-02-17 12:10:26 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:10:26 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:10:26 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:10:26 --> Template Class Initialized
INFO - 2017-02-17 12:10:26 --> Controller Class Initialized
DEBUG - 2017-02-17 12:10:26 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:10:26 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:10:26 --> Model Class Initialized
INFO - 2017-02-17 12:10:26 --> Form Validation Class Initialized
INFO - 2017-02-17 12:10:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 12:10:26 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:10:26 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:10:26 --> Final output sent to browser
DEBUG - 2017-02-17 12:10:26 --> Total execution time: 0.0798
INFO - 2017-02-17 12:10:28 --> Config Class Initialized
INFO - 2017-02-17 12:10:28 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:10:28 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:10:28 --> Utf8 Class Initialized
INFO - 2017-02-17 12:10:28 --> URI Class Initialized
INFO - 2017-02-17 12:10:28 --> Router Class Initialized
INFO - 2017-02-17 12:10:28 --> Output Class Initialized
INFO - 2017-02-17 12:10:28 --> Security Class Initialized
DEBUG - 2017-02-17 12:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:10:28 --> Input Class Initialized
INFO - 2017-02-17 12:10:28 --> Language Class Initialized
INFO - 2017-02-17 12:10:28 --> Language Class Initialized
INFO - 2017-02-17 12:10:28 --> Config Class Initialized
INFO - 2017-02-17 12:10:28 --> Loader Class Initialized
INFO - 2017-02-17 12:10:28 --> Helper loaded: form_helper
INFO - 2017-02-17 12:10:28 --> Helper loaded: url_helper
INFO - 2017-02-17 12:10:28 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:10:28 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:10:28 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:10:28 --> Template Class Initialized
INFO - 2017-02-17 12:10:28 --> Controller Class Initialized
DEBUG - 2017-02-17 12:10:28 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:10:28 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:10:28 --> Model Class Initialized
INFO - 2017-02-17 12:10:28 --> Form Validation Class Initialized
INFO - 2017-02-17 12:10:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 12:10:28 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:10:28 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:10:28 --> Final output sent to browser
DEBUG - 2017-02-17 12:10:28 --> Total execution time: 0.0714
INFO - 2017-02-17 12:10:34 --> Config Class Initialized
INFO - 2017-02-17 12:10:34 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:10:34 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:10:34 --> Utf8 Class Initialized
INFO - 2017-02-17 12:10:34 --> URI Class Initialized
INFO - 2017-02-17 12:10:34 --> Router Class Initialized
INFO - 2017-02-17 12:10:34 --> Output Class Initialized
INFO - 2017-02-17 12:10:34 --> Security Class Initialized
DEBUG - 2017-02-17 12:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:10:34 --> Input Class Initialized
INFO - 2017-02-17 12:10:34 --> Language Class Initialized
INFO - 2017-02-17 12:10:34 --> Language Class Initialized
INFO - 2017-02-17 12:10:34 --> Config Class Initialized
INFO - 2017-02-17 12:10:34 --> Loader Class Initialized
INFO - 2017-02-17 12:10:34 --> Helper loaded: form_helper
INFO - 2017-02-17 12:10:34 --> Helper loaded: url_helper
INFO - 2017-02-17 12:10:34 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:10:34 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:10:34 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:10:34 --> Template Class Initialized
INFO - 2017-02-17 12:10:34 --> Controller Class Initialized
DEBUG - 2017-02-17 12:10:34 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:10:34 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:10:34 --> Model Class Initialized
INFO - 2017-02-17 12:10:34 --> Form Validation Class Initialized
INFO - 2017-02-17 12:10:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 12:10:34 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:10:34 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:10:34 --> Final output sent to browser
DEBUG - 2017-02-17 12:10:34 --> Total execution time: 0.0623
INFO - 2017-02-17 12:10:41 --> Config Class Initialized
INFO - 2017-02-17 12:10:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:10:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:10:41 --> Utf8 Class Initialized
INFO - 2017-02-17 12:10:41 --> URI Class Initialized
INFO - 2017-02-17 12:10:41 --> Router Class Initialized
INFO - 2017-02-17 12:10:41 --> Output Class Initialized
INFO - 2017-02-17 12:10:41 --> Security Class Initialized
DEBUG - 2017-02-17 12:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:10:41 --> Input Class Initialized
INFO - 2017-02-17 12:10:41 --> Language Class Initialized
INFO - 2017-02-17 12:10:41 --> Language Class Initialized
INFO - 2017-02-17 12:10:41 --> Config Class Initialized
INFO - 2017-02-17 12:10:41 --> Loader Class Initialized
INFO - 2017-02-17 12:10:41 --> Helper loaded: form_helper
INFO - 2017-02-17 12:10:41 --> Helper loaded: url_helper
INFO - 2017-02-17 12:10:41 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:10:41 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:10:41 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:10:41 --> Template Class Initialized
INFO - 2017-02-17 12:10:41 --> Controller Class Initialized
DEBUG - 2017-02-17 12:10:41 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:10:41 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:10:41 --> Model Class Initialized
INFO - 2017-02-17 12:10:41 --> Form Validation Class Initialized
INFO - 2017-02-17 12:10:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 12:10:41 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:10:41 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:10:41 --> Final output sent to browser
DEBUG - 2017-02-17 12:10:41 --> Total execution time: 0.0732
INFO - 2017-02-17 12:10:46 --> Config Class Initialized
INFO - 2017-02-17 12:10:46 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:10:46 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:10:46 --> Utf8 Class Initialized
INFO - 2017-02-17 12:10:46 --> URI Class Initialized
INFO - 2017-02-17 12:10:46 --> Router Class Initialized
INFO - 2017-02-17 12:10:46 --> Output Class Initialized
INFO - 2017-02-17 12:10:46 --> Security Class Initialized
DEBUG - 2017-02-17 12:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:10:46 --> Input Class Initialized
INFO - 2017-02-17 12:10:46 --> Language Class Initialized
INFO - 2017-02-17 12:10:46 --> Language Class Initialized
INFO - 2017-02-17 12:10:46 --> Config Class Initialized
INFO - 2017-02-17 12:10:46 --> Loader Class Initialized
INFO - 2017-02-17 12:10:46 --> Helper loaded: form_helper
INFO - 2017-02-17 12:10:46 --> Helper loaded: url_helper
INFO - 2017-02-17 12:10:46 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:10:46 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:10:46 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:10:46 --> Template Class Initialized
INFO - 2017-02-17 12:10:46 --> Controller Class Initialized
DEBUG - 2017-02-17 12:10:46 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:10:46 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:10:46 --> Model Class Initialized
INFO - 2017-02-17 12:10:46 --> Form Validation Class Initialized
INFO - 2017-02-17 12:10:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 12:10:46 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 12:10:46 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:10:46 --> Final output sent to browser
DEBUG - 2017-02-17 12:10:46 --> Total execution time: 0.0761
INFO - 2017-02-17 12:10:53 --> Config Class Initialized
INFO - 2017-02-17 12:10:53 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:10:53 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:10:53 --> Utf8 Class Initialized
INFO - 2017-02-17 12:10:53 --> URI Class Initialized
INFO - 2017-02-17 12:10:53 --> Router Class Initialized
INFO - 2017-02-17 12:10:53 --> Output Class Initialized
INFO - 2017-02-17 12:10:53 --> Security Class Initialized
DEBUG - 2017-02-17 12:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:10:53 --> Input Class Initialized
INFO - 2017-02-17 12:10:53 --> Language Class Initialized
INFO - 2017-02-17 12:10:53 --> Language Class Initialized
INFO - 2017-02-17 12:10:53 --> Config Class Initialized
INFO - 2017-02-17 12:10:53 --> Loader Class Initialized
INFO - 2017-02-17 12:10:53 --> Helper loaded: form_helper
INFO - 2017-02-17 12:10:53 --> Helper loaded: url_helper
INFO - 2017-02-17 12:10:53 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:10:53 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:10:53 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:10:53 --> Template Class Initialized
INFO - 2017-02-17 12:10:53 --> Controller Class Initialized
DEBUG - 2017-02-17 12:10:53 --> Login MX_Controller Initialized
INFO - 2017-02-17 12:10:53 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:10:53 --> Model Class Initialized
INFO - 2017-02-17 12:10:53 --> Form Validation Class Initialized
INFO - 2017-02-17 12:10:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 12:10:53 --> Severity: Notice --> Undefined index: first_name C:\xampp\htdocs\razor\application\modules\backend\controllers\Login.php 42
ERROR - 2017-02-17 12:10:53 --> Severity: Notice --> Undefined index: last_name C:\xampp\htdocs\razor\application\modules\backend\controllers\Login.php 43
ERROR - 2017-02-17 12:10:53 --> Severity: Notice --> Undefined index: mobile C:\xampp\htdocs\razor\application\modules\backend\controllers\Login.php 45
INFO - 2017-02-17 12:10:53 --> Config Class Initialized
INFO - 2017-02-17 12:10:53 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:10:53 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:10:53 --> Utf8 Class Initialized
INFO - 2017-02-17 12:10:53 --> URI Class Initialized
INFO - 2017-02-17 12:10:53 --> Router Class Initialized
INFO - 2017-02-17 12:10:53 --> Output Class Initialized
INFO - 2017-02-17 12:10:53 --> Security Class Initialized
DEBUG - 2017-02-17 12:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:10:53 --> Input Class Initialized
INFO - 2017-02-17 12:10:53 --> Language Class Initialized
ERROR - 2017-02-17 12:10:53 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:19:26 --> Config Class Initialized
INFO - 2017-02-17 12:19:26 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:19:26 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:19:26 --> Utf8 Class Initialized
INFO - 2017-02-17 12:19:26 --> URI Class Initialized
INFO - 2017-02-17 12:19:26 --> Router Class Initialized
INFO - 2017-02-17 12:19:26 --> Output Class Initialized
INFO - 2017-02-17 12:19:26 --> Security Class Initialized
DEBUG - 2017-02-17 12:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:19:26 --> Input Class Initialized
INFO - 2017-02-17 12:19:26 --> Language Class Initialized
INFO - 2017-02-17 12:19:26 --> Language Class Initialized
INFO - 2017-02-17 12:19:26 --> Config Class Initialized
INFO - 2017-02-17 12:19:26 --> Loader Class Initialized
INFO - 2017-02-17 12:19:26 --> Helper loaded: form_helper
INFO - 2017-02-17 12:19:26 --> Helper loaded: url_helper
INFO - 2017-02-17 12:19:26 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:19:26 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:19:26 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:19:26 --> Template Class Initialized
INFO - 2017-02-17 12:19:26 --> Controller Class Initialized
DEBUG - 2017-02-17 12:19:26 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:19:26 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:19:26 --> Model Class Initialized
DEBUG - 2017-02-17 12:19:26 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 12:19:26 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:19:26 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:19:26 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-17 12:19:26 --> Final output sent to browser
DEBUG - 2017-02-17 12:19:26 --> Total execution time: 0.0614
INFO - 2017-02-17 12:19:26 --> Config Class Initialized
INFO - 2017-02-17 12:19:26 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:19:26 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:19:26 --> Utf8 Class Initialized
INFO - 2017-02-17 12:19:26 --> URI Class Initialized
INFO - 2017-02-17 12:19:26 --> Router Class Initialized
INFO - 2017-02-17 12:19:26 --> Output Class Initialized
INFO - 2017-02-17 12:19:26 --> Security Class Initialized
DEBUG - 2017-02-17 12:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:19:26 --> Input Class Initialized
INFO - 2017-02-17 12:19:26 --> Language Class Initialized
ERROR - 2017-02-17 12:19:26 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:19:26 --> Config Class Initialized
INFO - 2017-02-17 12:19:26 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:19:26 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:19:26 --> Utf8 Class Initialized
INFO - 2017-02-17 12:19:26 --> URI Class Initialized
INFO - 2017-02-17 12:19:26 --> Router Class Initialized
INFO - 2017-02-17 12:19:26 --> Output Class Initialized
INFO - 2017-02-17 12:19:26 --> Security Class Initialized
DEBUG - 2017-02-17 12:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:19:26 --> Input Class Initialized
INFO - 2017-02-17 12:19:26 --> Language Class Initialized
ERROR - 2017-02-17 12:19:26 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:19:51 --> Config Class Initialized
INFO - 2017-02-17 12:19:51 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:19:51 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:19:51 --> Utf8 Class Initialized
INFO - 2017-02-17 12:19:51 --> URI Class Initialized
INFO - 2017-02-17 12:19:51 --> Router Class Initialized
INFO - 2017-02-17 12:19:51 --> Output Class Initialized
INFO - 2017-02-17 12:19:51 --> Security Class Initialized
DEBUG - 2017-02-17 12:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:19:51 --> Input Class Initialized
INFO - 2017-02-17 12:19:51 --> Language Class Initialized
INFO - 2017-02-17 12:19:51 --> Language Class Initialized
INFO - 2017-02-17 12:19:51 --> Config Class Initialized
INFO - 2017-02-17 12:19:51 --> Loader Class Initialized
INFO - 2017-02-17 12:19:51 --> Helper loaded: form_helper
INFO - 2017-02-17 12:19:51 --> Helper loaded: url_helper
INFO - 2017-02-17 12:19:51 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:19:51 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:19:51 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:19:51 --> Template Class Initialized
INFO - 2017-02-17 12:19:51 --> Controller Class Initialized
DEBUG - 2017-02-17 12:19:51 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:19:51 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:19:51 --> Model Class Initialized
DEBUG - 2017-02-17 12:19:51 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 12:19:51 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:19:51 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:19:51 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:19:51 --> Final output sent to browser
DEBUG - 2017-02-17 12:19:51 --> Total execution time: 0.1104
INFO - 2017-02-17 12:19:51 --> Config Class Initialized
INFO - 2017-02-17 12:19:51 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:19:51 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:19:51 --> Utf8 Class Initialized
INFO - 2017-02-17 12:19:51 --> URI Class Initialized
INFO - 2017-02-17 12:19:51 --> Router Class Initialized
INFO - 2017-02-17 12:19:51 --> Output Class Initialized
INFO - 2017-02-17 12:19:51 --> Security Class Initialized
DEBUG - 2017-02-17 12:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:19:51 --> Input Class Initialized
INFO - 2017-02-17 12:19:51 --> Language Class Initialized
ERROR - 2017-02-17 12:19:51 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:20:45 --> Config Class Initialized
INFO - 2017-02-17 12:20:45 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:20:45 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:20:45 --> Utf8 Class Initialized
INFO - 2017-02-17 12:20:45 --> URI Class Initialized
INFO - 2017-02-17 12:20:45 --> Router Class Initialized
INFO - 2017-02-17 12:20:45 --> Output Class Initialized
INFO - 2017-02-17 12:20:45 --> Security Class Initialized
DEBUG - 2017-02-17 12:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:20:45 --> Input Class Initialized
INFO - 2017-02-17 12:20:45 --> Language Class Initialized
INFO - 2017-02-17 12:20:45 --> Language Class Initialized
INFO - 2017-02-17 12:20:45 --> Config Class Initialized
INFO - 2017-02-17 12:20:45 --> Loader Class Initialized
INFO - 2017-02-17 12:20:45 --> Helper loaded: form_helper
INFO - 2017-02-17 12:20:45 --> Helper loaded: url_helper
INFO - 2017-02-17 12:20:45 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:20:45 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:20:45 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:20:45 --> Template Class Initialized
INFO - 2017-02-17 12:20:45 --> Controller Class Initialized
DEBUG - 2017-02-17 12:20:45 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:20:45 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:20:45 --> Model Class Initialized
DEBUG - 2017-02-17 12:20:45 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 12:20:45 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:20:45 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:20:45 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:20:45 --> Final output sent to browser
DEBUG - 2017-02-17 12:20:45 --> Total execution time: 0.0505
INFO - 2017-02-17 12:20:45 --> Config Class Initialized
INFO - 2017-02-17 12:20:45 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:20:45 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:20:45 --> Utf8 Class Initialized
INFO - 2017-02-17 12:20:45 --> URI Class Initialized
INFO - 2017-02-17 12:20:45 --> Router Class Initialized
INFO - 2017-02-17 12:20:45 --> Output Class Initialized
INFO - 2017-02-17 12:20:45 --> Security Class Initialized
DEBUG - 2017-02-17 12:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:20:45 --> Input Class Initialized
INFO - 2017-02-17 12:20:45 --> Language Class Initialized
ERROR - 2017-02-17 12:20:45 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:20:59 --> Config Class Initialized
INFO - 2017-02-17 12:20:59 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:20:59 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:20:59 --> Utf8 Class Initialized
INFO - 2017-02-17 12:20:59 --> URI Class Initialized
INFO - 2017-02-17 12:20:59 --> Router Class Initialized
INFO - 2017-02-17 12:20:59 --> Output Class Initialized
INFO - 2017-02-17 12:20:59 --> Security Class Initialized
DEBUG - 2017-02-17 12:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:20:59 --> Input Class Initialized
INFO - 2017-02-17 12:20:59 --> Language Class Initialized
INFO - 2017-02-17 12:20:59 --> Language Class Initialized
INFO - 2017-02-17 12:20:59 --> Config Class Initialized
INFO - 2017-02-17 12:20:59 --> Loader Class Initialized
INFO - 2017-02-17 12:20:59 --> Helper loaded: form_helper
INFO - 2017-02-17 12:20:59 --> Helper loaded: url_helper
INFO - 2017-02-17 12:20:59 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:20:59 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:20:59 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:20:59 --> Template Class Initialized
INFO - 2017-02-17 12:20:59 --> Controller Class Initialized
DEBUG - 2017-02-17 12:20:59 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:20:59 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:20:59 --> Model Class Initialized
DEBUG - 2017-02-17 12:20:59 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:20:59 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:20:59 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:20:59 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:20:59 --> Final output sent to browser
DEBUG - 2017-02-17 12:20:59 --> Total execution time: 0.0606
INFO - 2017-02-17 12:20:59 --> Config Class Initialized
INFO - 2017-02-17 12:20:59 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:20:59 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:20:59 --> Utf8 Class Initialized
INFO - 2017-02-17 12:20:59 --> URI Class Initialized
INFO - 2017-02-17 12:20:59 --> Router Class Initialized
INFO - 2017-02-17 12:20:59 --> Output Class Initialized
INFO - 2017-02-17 12:20:59 --> Security Class Initialized
DEBUG - 2017-02-17 12:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:20:59 --> Input Class Initialized
INFO - 2017-02-17 12:20:59 --> Language Class Initialized
ERROR - 2017-02-17 12:20:59 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:21:54 --> Config Class Initialized
INFO - 2017-02-17 12:21:54 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:21:54 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:21:54 --> Utf8 Class Initialized
INFO - 2017-02-17 12:21:54 --> URI Class Initialized
INFO - 2017-02-17 12:21:54 --> Router Class Initialized
INFO - 2017-02-17 12:21:54 --> Output Class Initialized
INFO - 2017-02-17 12:21:54 --> Security Class Initialized
DEBUG - 2017-02-17 12:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:21:54 --> Input Class Initialized
INFO - 2017-02-17 12:21:54 --> Language Class Initialized
INFO - 2017-02-17 12:21:54 --> Language Class Initialized
INFO - 2017-02-17 12:21:54 --> Config Class Initialized
INFO - 2017-02-17 12:21:54 --> Loader Class Initialized
INFO - 2017-02-17 12:21:54 --> Helper loaded: form_helper
INFO - 2017-02-17 12:21:54 --> Helper loaded: url_helper
INFO - 2017-02-17 12:21:54 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:21:54 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:21:54 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:21:54 --> Template Class Initialized
INFO - 2017-02-17 12:21:54 --> Controller Class Initialized
DEBUG - 2017-02-17 12:21:54 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:21:54 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:21:54 --> Model Class Initialized
DEBUG - 2017-02-17 12:21:54 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:21:54 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:21:54 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:21:54 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:21:54 --> Final output sent to browser
DEBUG - 2017-02-17 12:21:54 --> Total execution time: 0.0496
INFO - 2017-02-17 12:21:54 --> Config Class Initialized
INFO - 2017-02-17 12:21:54 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:21:54 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:21:54 --> Utf8 Class Initialized
INFO - 2017-02-17 12:21:54 --> URI Class Initialized
INFO - 2017-02-17 12:21:54 --> Router Class Initialized
INFO - 2017-02-17 12:21:54 --> Output Class Initialized
INFO - 2017-02-17 12:21:54 --> Security Class Initialized
DEBUG - 2017-02-17 12:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:21:54 --> Input Class Initialized
INFO - 2017-02-17 12:21:54 --> Language Class Initialized
ERROR - 2017-02-17 12:21:54 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:23:25 --> Config Class Initialized
INFO - 2017-02-17 12:23:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:23:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:23:25 --> Utf8 Class Initialized
INFO - 2017-02-17 12:23:25 --> URI Class Initialized
INFO - 2017-02-17 12:23:25 --> Router Class Initialized
INFO - 2017-02-17 12:23:25 --> Output Class Initialized
INFO - 2017-02-17 12:23:25 --> Security Class Initialized
DEBUG - 2017-02-17 12:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:23:25 --> Input Class Initialized
INFO - 2017-02-17 12:23:25 --> Language Class Initialized
INFO - 2017-02-17 12:23:25 --> Language Class Initialized
INFO - 2017-02-17 12:23:25 --> Config Class Initialized
INFO - 2017-02-17 12:23:25 --> Loader Class Initialized
INFO - 2017-02-17 12:23:25 --> Helper loaded: form_helper
INFO - 2017-02-17 12:23:25 --> Helper loaded: url_helper
INFO - 2017-02-17 12:23:25 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:23:25 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:23:25 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:23:25 --> Template Class Initialized
INFO - 2017-02-17 12:23:25 --> Controller Class Initialized
DEBUG - 2017-02-17 12:23:25 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:23:25 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:23:25 --> Model Class Initialized
DEBUG - 2017-02-17 12:23:25 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:23:25 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:23:25 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:23:25 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:23:25 --> Final output sent to browser
DEBUG - 2017-02-17 12:23:25 --> Total execution time: 0.0577
INFO - 2017-02-17 12:23:25 --> Config Class Initialized
INFO - 2017-02-17 12:23:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:23:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:23:25 --> Utf8 Class Initialized
INFO - 2017-02-17 12:23:25 --> URI Class Initialized
INFO - 2017-02-17 12:23:25 --> Router Class Initialized
INFO - 2017-02-17 12:23:25 --> Output Class Initialized
INFO - 2017-02-17 12:23:25 --> Security Class Initialized
DEBUG - 2017-02-17 12:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:23:25 --> Input Class Initialized
INFO - 2017-02-17 12:23:25 --> Language Class Initialized
ERROR - 2017-02-17 12:23:25 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:23:30 --> Config Class Initialized
INFO - 2017-02-17 12:23:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:23:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:23:30 --> Utf8 Class Initialized
INFO - 2017-02-17 12:23:30 --> URI Class Initialized
INFO - 2017-02-17 12:23:30 --> Router Class Initialized
INFO - 2017-02-17 12:23:30 --> Output Class Initialized
INFO - 2017-02-17 12:23:30 --> Security Class Initialized
DEBUG - 2017-02-17 12:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:23:30 --> Input Class Initialized
INFO - 2017-02-17 12:23:30 --> Language Class Initialized
INFO - 2017-02-17 12:23:30 --> Language Class Initialized
INFO - 2017-02-17 12:23:30 --> Config Class Initialized
INFO - 2017-02-17 12:23:30 --> Loader Class Initialized
INFO - 2017-02-17 12:23:30 --> Helper loaded: form_helper
INFO - 2017-02-17 12:23:30 --> Helper loaded: url_helper
INFO - 2017-02-17 12:23:30 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:23:30 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:23:30 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:23:30 --> Template Class Initialized
INFO - 2017-02-17 12:23:30 --> Controller Class Initialized
DEBUG - 2017-02-17 12:23:30 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:23:30 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:23:30 --> Model Class Initialized
DEBUG - 2017-02-17 12:23:30 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:23:30 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:23:30 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:23:30 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:23:30 --> Final output sent to browser
DEBUG - 2017-02-17 12:23:30 --> Total execution time: 0.0498
INFO - 2017-02-17 12:23:30 --> Config Class Initialized
INFO - 2017-02-17 12:23:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:23:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:23:30 --> Utf8 Class Initialized
INFO - 2017-02-17 12:23:30 --> URI Class Initialized
INFO - 2017-02-17 12:23:30 --> Router Class Initialized
INFO - 2017-02-17 12:23:30 --> Output Class Initialized
INFO - 2017-02-17 12:23:30 --> Security Class Initialized
DEBUG - 2017-02-17 12:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:23:30 --> Input Class Initialized
INFO - 2017-02-17 12:23:30 --> Language Class Initialized
ERROR - 2017-02-17 12:23:30 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:23:43 --> Config Class Initialized
INFO - 2017-02-17 12:23:43 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:23:43 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:23:43 --> Utf8 Class Initialized
INFO - 2017-02-17 12:23:43 --> URI Class Initialized
INFO - 2017-02-17 12:23:43 --> Router Class Initialized
INFO - 2017-02-17 12:23:43 --> Output Class Initialized
INFO - 2017-02-17 12:23:43 --> Security Class Initialized
DEBUG - 2017-02-17 12:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:23:43 --> Input Class Initialized
INFO - 2017-02-17 12:23:43 --> Language Class Initialized
INFO - 2017-02-17 12:23:43 --> Language Class Initialized
INFO - 2017-02-17 12:23:43 --> Config Class Initialized
INFO - 2017-02-17 12:23:43 --> Loader Class Initialized
INFO - 2017-02-17 12:23:43 --> Helper loaded: form_helper
INFO - 2017-02-17 12:23:43 --> Helper loaded: url_helper
INFO - 2017-02-17 12:23:43 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:23:43 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:23:43 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:23:43 --> Template Class Initialized
INFO - 2017-02-17 12:23:43 --> Controller Class Initialized
DEBUG - 2017-02-17 12:23:43 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:23:43 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:23:43 --> Model Class Initialized
DEBUG - 2017-02-17 12:23:43 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:23:43 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:23:43 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:23:43 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:23:43 --> Final output sent to browser
DEBUG - 2017-02-17 12:23:43 --> Total execution time: 0.0551
INFO - 2017-02-17 12:23:43 --> Config Class Initialized
INFO - 2017-02-17 12:23:43 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:23:43 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:23:43 --> Utf8 Class Initialized
INFO - 2017-02-17 12:23:43 --> URI Class Initialized
INFO - 2017-02-17 12:23:43 --> Router Class Initialized
INFO - 2017-02-17 12:23:43 --> Output Class Initialized
INFO - 2017-02-17 12:23:43 --> Security Class Initialized
DEBUG - 2017-02-17 12:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:23:43 --> Input Class Initialized
INFO - 2017-02-17 12:23:43 --> Language Class Initialized
ERROR - 2017-02-17 12:23:43 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:24:50 --> Config Class Initialized
INFO - 2017-02-17 12:24:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:24:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:24:50 --> Utf8 Class Initialized
INFO - 2017-02-17 12:24:50 --> URI Class Initialized
INFO - 2017-02-17 12:24:50 --> Router Class Initialized
INFO - 2017-02-17 12:24:50 --> Output Class Initialized
INFO - 2017-02-17 12:24:50 --> Security Class Initialized
DEBUG - 2017-02-17 12:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:24:50 --> Input Class Initialized
INFO - 2017-02-17 12:24:50 --> Language Class Initialized
INFO - 2017-02-17 12:24:50 --> Language Class Initialized
INFO - 2017-02-17 12:24:50 --> Config Class Initialized
INFO - 2017-02-17 12:24:50 --> Loader Class Initialized
INFO - 2017-02-17 12:24:50 --> Helper loaded: form_helper
INFO - 2017-02-17 12:24:50 --> Helper loaded: url_helper
INFO - 2017-02-17 12:24:50 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:24:50 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:24:50 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:24:50 --> Template Class Initialized
INFO - 2017-02-17 12:24:50 --> Controller Class Initialized
DEBUG - 2017-02-17 12:24:50 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:24:50 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:24:50 --> Model Class Initialized
DEBUG - 2017-02-17 12:24:50 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:24:50 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:24:50 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:24:50 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:24:50 --> Final output sent to browser
DEBUG - 2017-02-17 12:24:50 --> Total execution time: 0.0524
INFO - 2017-02-17 12:24:50 --> Config Class Initialized
INFO - 2017-02-17 12:24:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:24:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:24:50 --> Utf8 Class Initialized
INFO - 2017-02-17 12:24:50 --> URI Class Initialized
INFO - 2017-02-17 12:24:50 --> Router Class Initialized
INFO - 2017-02-17 12:24:50 --> Output Class Initialized
INFO - 2017-02-17 12:24:50 --> Security Class Initialized
DEBUG - 2017-02-17 12:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:24:50 --> Input Class Initialized
INFO - 2017-02-17 12:24:50 --> Language Class Initialized
ERROR - 2017-02-17 12:24:50 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:24:51 --> Config Class Initialized
INFO - 2017-02-17 12:24:51 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:24:51 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:24:51 --> Utf8 Class Initialized
INFO - 2017-02-17 12:24:51 --> URI Class Initialized
INFO - 2017-02-17 12:24:51 --> Router Class Initialized
INFO - 2017-02-17 12:24:51 --> Output Class Initialized
INFO - 2017-02-17 12:24:51 --> Security Class Initialized
DEBUG - 2017-02-17 12:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:24:51 --> Input Class Initialized
INFO - 2017-02-17 12:24:51 --> Language Class Initialized
INFO - 2017-02-17 12:24:51 --> Language Class Initialized
INFO - 2017-02-17 12:24:51 --> Config Class Initialized
INFO - 2017-02-17 12:24:51 --> Loader Class Initialized
INFO - 2017-02-17 12:24:51 --> Helper loaded: form_helper
INFO - 2017-02-17 12:24:51 --> Helper loaded: url_helper
INFO - 2017-02-17 12:24:51 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:24:51 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:24:51 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:24:51 --> Template Class Initialized
INFO - 2017-02-17 12:24:51 --> Controller Class Initialized
DEBUG - 2017-02-17 12:24:51 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:24:51 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:24:51 --> Model Class Initialized
DEBUG - 2017-02-17 12:24:51 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:24:51 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:24:51 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:24:51 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:24:51 --> Final output sent to browser
DEBUG - 2017-02-17 12:24:51 --> Total execution time: 0.0519
INFO - 2017-02-17 12:24:51 --> Config Class Initialized
INFO - 2017-02-17 12:24:51 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:24:51 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:24:51 --> Utf8 Class Initialized
INFO - 2017-02-17 12:24:51 --> URI Class Initialized
INFO - 2017-02-17 12:24:51 --> Router Class Initialized
INFO - 2017-02-17 12:24:51 --> Output Class Initialized
INFO - 2017-02-17 12:24:51 --> Security Class Initialized
DEBUG - 2017-02-17 12:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:24:51 --> Input Class Initialized
INFO - 2017-02-17 12:24:51 --> Language Class Initialized
ERROR - 2017-02-17 12:24:51 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Loader Class Initialized
INFO - 2017-02-17 12:25:08 --> Helper loaded: form_helper
INFO - 2017-02-17 12:25:08 --> Helper loaded: url_helper
INFO - 2017-02-17 12:25:08 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:25:08 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:25:08 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Template Class Initialized
INFO - 2017-02-17 12:25:08 --> Controller Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:25:08 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:25:08 --> Model Class Initialized
DEBUG - 2017-02-17 12:25:08 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:25:08 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:25:08 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:25:08 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:25:08 --> Final output sent to browser
DEBUG - 2017-02-17 12:25:08 --> Total execution time: 0.0541
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:08 --> Router Class Initialized
INFO - 2017-02-17 12:25:08 --> Output Class Initialized
INFO - 2017-02-17 12:25:08 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:08 --> Input Class Initialized
INFO - 2017-02-17 12:25:08 --> Language Class Initialized
ERROR - 2017-02-17 12:25:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:08 --> Config Class Initialized
INFO - 2017-02-17 12:25:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:08 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:08 --> URI Class Initialized
INFO - 2017-02-17 12:25:09 --> Router Class Initialized
INFO - 2017-02-17 12:25:09 --> Output Class Initialized
INFO - 2017-02-17 12:25:09 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:09 --> Input Class Initialized
INFO - 2017-02-17 12:25:09 --> Language Class Initialized
ERROR - 2017-02-17 12:25:09 --> 404 Page Not Found: /index
INFO - 2017-02-17 12:25:24 --> Config Class Initialized
INFO - 2017-02-17 12:25:24 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:24 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:24 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:24 --> URI Class Initialized
INFO - 2017-02-17 12:25:24 --> Router Class Initialized
INFO - 2017-02-17 12:25:24 --> Output Class Initialized
INFO - 2017-02-17 12:25:24 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:24 --> Input Class Initialized
INFO - 2017-02-17 12:25:24 --> Language Class Initialized
INFO - 2017-02-17 12:25:24 --> Language Class Initialized
INFO - 2017-02-17 12:25:24 --> Config Class Initialized
INFO - 2017-02-17 12:25:24 --> Loader Class Initialized
INFO - 2017-02-17 12:25:24 --> Helper loaded: form_helper
INFO - 2017-02-17 12:25:24 --> Helper loaded: url_helper
INFO - 2017-02-17 12:25:24 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:25:24 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:25:24 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:25:24 --> Template Class Initialized
INFO - 2017-02-17 12:25:24 --> Controller Class Initialized
DEBUG - 2017-02-17 12:25:24 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:25:24 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:25:24 --> Model Class Initialized
DEBUG - 2017-02-17 12:25:24 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:25:24 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:25:24 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:25:24 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:25:24 --> Final output sent to browser
DEBUG - 2017-02-17 12:25:24 --> Total execution time: 0.0489
INFO - 2017-02-17 12:25:24 --> Config Class Initialized
INFO - 2017-02-17 12:25:24 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:24 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:24 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:24 --> URI Class Initialized
INFO - 2017-02-17 12:25:24 --> Router Class Initialized
INFO - 2017-02-17 12:25:24 --> Output Class Initialized
INFO - 2017-02-17 12:25:24 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:24 --> Input Class Initialized
INFO - 2017-02-17 12:25:24 --> Language Class Initialized
ERROR - 2017-02-17 12:25:24 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:25:35 --> Config Class Initialized
INFO - 2017-02-17 12:25:35 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:35 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:35 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:35 --> URI Class Initialized
INFO - 2017-02-17 12:25:35 --> Router Class Initialized
INFO - 2017-02-17 12:25:35 --> Output Class Initialized
INFO - 2017-02-17 12:25:35 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:35 --> Input Class Initialized
INFO - 2017-02-17 12:25:35 --> Language Class Initialized
INFO - 2017-02-17 12:25:35 --> Language Class Initialized
INFO - 2017-02-17 12:25:35 --> Config Class Initialized
INFO - 2017-02-17 12:25:35 --> Loader Class Initialized
INFO - 2017-02-17 12:25:35 --> Helper loaded: form_helper
INFO - 2017-02-17 12:25:35 --> Helper loaded: url_helper
INFO - 2017-02-17 12:25:35 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:25:35 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:25:35 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:25:35 --> Template Class Initialized
INFO - 2017-02-17 12:25:35 --> Controller Class Initialized
DEBUG - 2017-02-17 12:25:35 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:25:35 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:25:35 --> Model Class Initialized
DEBUG - 2017-02-17 12:25:35 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:25:35 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:25:35 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:25:35 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:25:35 --> Final output sent to browser
DEBUG - 2017-02-17 12:25:35 --> Total execution time: 0.0409
INFO - 2017-02-17 12:25:35 --> Config Class Initialized
INFO - 2017-02-17 12:25:35 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:25:35 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:25:35 --> Utf8 Class Initialized
INFO - 2017-02-17 12:25:35 --> URI Class Initialized
INFO - 2017-02-17 12:25:35 --> Router Class Initialized
INFO - 2017-02-17 12:25:35 --> Output Class Initialized
INFO - 2017-02-17 12:25:35 --> Security Class Initialized
DEBUG - 2017-02-17 12:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:25:35 --> Input Class Initialized
INFO - 2017-02-17 12:25:35 --> Language Class Initialized
ERROR - 2017-02-17 12:25:35 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:26:20 --> Config Class Initialized
INFO - 2017-02-17 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-17 12:26:20 --> URI Class Initialized
INFO - 2017-02-17 12:26:20 --> Router Class Initialized
INFO - 2017-02-17 12:26:20 --> Output Class Initialized
INFO - 2017-02-17 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-17 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:26:20 --> Input Class Initialized
INFO - 2017-02-17 12:26:20 --> Language Class Initialized
INFO - 2017-02-17 12:26:20 --> Language Class Initialized
INFO - 2017-02-17 12:26:20 --> Config Class Initialized
INFO - 2017-02-17 12:26:20 --> Loader Class Initialized
INFO - 2017-02-17 12:26:20 --> Helper loaded: form_helper
INFO - 2017-02-17 12:26:20 --> Helper loaded: url_helper
INFO - 2017-02-17 12:26:20 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:26:20 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:26:20 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:26:20 --> Template Class Initialized
INFO - 2017-02-17 12:26:20 --> Controller Class Initialized
DEBUG - 2017-02-17 12:26:20 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:26:20 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:26:20 --> Model Class Initialized
DEBUG - 2017-02-17 12:26:20 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:26:20 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:26:20 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
ERROR - 2017-02-17 12:26:20 --> Severity: Notice --> Undefined index: sidebar C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\backend.php 35
DEBUG - 2017-02-17 12:26:20 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:26:20 --> Final output sent to browser
DEBUG - 2017-02-17 12:26:20 --> Total execution time: 0.0578
INFO - 2017-02-17 12:26:20 --> Config Class Initialized
INFO - 2017-02-17 12:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:26:20 --> Utf8 Class Initialized
INFO - 2017-02-17 12:26:20 --> URI Class Initialized
INFO - 2017-02-17 12:26:20 --> Router Class Initialized
INFO - 2017-02-17 12:26:20 --> Output Class Initialized
INFO - 2017-02-17 12:26:20 --> Security Class Initialized
DEBUG - 2017-02-17 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:26:20 --> Input Class Initialized
INFO - 2017-02-17 12:26:20 --> Language Class Initialized
ERROR - 2017-02-17 12:26:20 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:26:23 --> Config Class Initialized
INFO - 2017-02-17 12:26:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:26:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:26:23 --> Utf8 Class Initialized
INFO - 2017-02-17 12:26:23 --> URI Class Initialized
INFO - 2017-02-17 12:26:23 --> Router Class Initialized
INFO - 2017-02-17 12:26:23 --> Output Class Initialized
INFO - 2017-02-17 12:26:23 --> Security Class Initialized
DEBUG - 2017-02-17 12:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:26:23 --> Input Class Initialized
INFO - 2017-02-17 12:26:23 --> Language Class Initialized
INFO - 2017-02-17 12:26:23 --> Language Class Initialized
INFO - 2017-02-17 12:26:23 --> Config Class Initialized
INFO - 2017-02-17 12:26:23 --> Loader Class Initialized
INFO - 2017-02-17 12:26:23 --> Helper loaded: form_helper
INFO - 2017-02-17 12:26:23 --> Helper loaded: url_helper
INFO - 2017-02-17 12:26:23 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:26:23 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:26:23 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:26:23 --> Template Class Initialized
INFO - 2017-02-17 12:26:23 --> Controller Class Initialized
DEBUG - 2017-02-17 12:26:23 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:26:23 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:26:23 --> Model Class Initialized
DEBUG - 2017-02-17 12:26:23 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:26:23 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:26:23 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
ERROR - 2017-02-17 12:26:23 --> Severity: Notice --> Undefined index: sidebar C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\backend.php 35
DEBUG - 2017-02-17 12:26:23 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:26:23 --> Final output sent to browser
DEBUG - 2017-02-17 12:26:23 --> Total execution time: 0.0472
INFO - 2017-02-17 12:26:23 --> Config Class Initialized
INFO - 2017-02-17 12:26:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:26:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:26:23 --> Utf8 Class Initialized
INFO - 2017-02-17 12:26:23 --> URI Class Initialized
INFO - 2017-02-17 12:26:23 --> Router Class Initialized
INFO - 2017-02-17 12:26:23 --> Output Class Initialized
INFO - 2017-02-17 12:26:23 --> Security Class Initialized
DEBUG - 2017-02-17 12:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:26:23 --> Input Class Initialized
INFO - 2017-02-17 12:26:23 --> Language Class Initialized
ERROR - 2017-02-17 12:26:23 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:26:46 --> Config Class Initialized
INFO - 2017-02-17 12:26:46 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:26:46 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:26:46 --> Utf8 Class Initialized
INFO - 2017-02-17 12:26:46 --> URI Class Initialized
INFO - 2017-02-17 12:26:46 --> Router Class Initialized
INFO - 2017-02-17 12:26:46 --> Output Class Initialized
INFO - 2017-02-17 12:26:46 --> Security Class Initialized
DEBUG - 2017-02-17 12:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:26:46 --> Input Class Initialized
INFO - 2017-02-17 12:26:46 --> Language Class Initialized
INFO - 2017-02-17 12:26:46 --> Language Class Initialized
INFO - 2017-02-17 12:26:46 --> Config Class Initialized
INFO - 2017-02-17 12:26:46 --> Loader Class Initialized
INFO - 2017-02-17 12:26:46 --> Helper loaded: form_helper
INFO - 2017-02-17 12:26:46 --> Helper loaded: url_helper
INFO - 2017-02-17 12:26:46 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:26:46 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:26:46 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:26:46 --> Template Class Initialized
INFO - 2017-02-17 12:26:46 --> Controller Class Initialized
DEBUG - 2017-02-17 12:26:46 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:26:46 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:26:46 --> Model Class Initialized
DEBUG - 2017-02-17 12:26:47 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:26:47 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:26:47 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
ERROR - 2017-02-17 12:26:47 --> Severity: Notice --> Undefined index: partial C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\backend.php 35
DEBUG - 2017-02-17 12:26:47 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:26:47 --> Final output sent to browser
DEBUG - 2017-02-17 12:26:47 --> Total execution time: 0.0646
INFO - 2017-02-17 12:26:47 --> Config Class Initialized
INFO - 2017-02-17 12:26:47 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:26:47 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:26:47 --> Utf8 Class Initialized
INFO - 2017-02-17 12:26:47 --> URI Class Initialized
INFO - 2017-02-17 12:26:47 --> Router Class Initialized
INFO - 2017-02-17 12:26:47 --> Output Class Initialized
INFO - 2017-02-17 12:26:47 --> Security Class Initialized
DEBUG - 2017-02-17 12:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:26:47 --> Input Class Initialized
INFO - 2017-02-17 12:26:47 --> Language Class Initialized
ERROR - 2017-02-17 12:26:47 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:26:52 --> Config Class Initialized
INFO - 2017-02-17 12:26:52 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:26:52 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:26:52 --> Utf8 Class Initialized
INFO - 2017-02-17 12:26:52 --> URI Class Initialized
INFO - 2017-02-17 12:26:52 --> Router Class Initialized
INFO - 2017-02-17 12:26:52 --> Output Class Initialized
INFO - 2017-02-17 12:26:52 --> Security Class Initialized
DEBUG - 2017-02-17 12:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:26:52 --> Input Class Initialized
INFO - 2017-02-17 12:26:52 --> Language Class Initialized
INFO - 2017-02-17 12:26:52 --> Language Class Initialized
INFO - 2017-02-17 12:26:52 --> Config Class Initialized
INFO - 2017-02-17 12:26:52 --> Loader Class Initialized
INFO - 2017-02-17 12:26:52 --> Helper loaded: form_helper
INFO - 2017-02-17 12:26:52 --> Helper loaded: url_helper
INFO - 2017-02-17 12:26:52 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:26:52 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:26:52 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:26:52 --> Template Class Initialized
INFO - 2017-02-17 12:26:52 --> Controller Class Initialized
DEBUG - 2017-02-17 12:26:52 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:26:52 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:26:52 --> Model Class Initialized
DEBUG - 2017-02-17 12:26:52 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:26:52 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:26:52 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
ERROR - 2017-02-17 12:26:52 --> Severity: Notice --> Undefined index: sidebar C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\backend.php 35
DEBUG - 2017-02-17 12:26:52 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:26:52 --> Final output sent to browser
DEBUG - 2017-02-17 12:26:52 --> Total execution time: 0.0522
INFO - 2017-02-17 12:26:52 --> Config Class Initialized
INFO - 2017-02-17 12:26:52 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:26:52 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:26:52 --> Utf8 Class Initialized
INFO - 2017-02-17 12:26:52 --> URI Class Initialized
INFO - 2017-02-17 12:26:52 --> Router Class Initialized
INFO - 2017-02-17 12:26:52 --> Output Class Initialized
INFO - 2017-02-17 12:26:52 --> Security Class Initialized
DEBUG - 2017-02-17 12:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:26:52 --> Input Class Initialized
INFO - 2017-02-17 12:26:52 --> Language Class Initialized
ERROR - 2017-02-17 12:26:52 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:27:06 --> Config Class Initialized
INFO - 2017-02-17 12:27:06 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:27:06 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:27:06 --> Utf8 Class Initialized
INFO - 2017-02-17 12:27:06 --> URI Class Initialized
INFO - 2017-02-17 12:27:06 --> Router Class Initialized
INFO - 2017-02-17 12:27:06 --> Output Class Initialized
INFO - 2017-02-17 12:27:06 --> Security Class Initialized
DEBUG - 2017-02-17 12:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:27:06 --> Input Class Initialized
INFO - 2017-02-17 12:27:06 --> Language Class Initialized
INFO - 2017-02-17 12:27:06 --> Language Class Initialized
INFO - 2017-02-17 12:27:06 --> Config Class Initialized
INFO - 2017-02-17 12:27:06 --> Loader Class Initialized
INFO - 2017-02-17 12:27:06 --> Helper loaded: form_helper
INFO - 2017-02-17 12:27:06 --> Helper loaded: url_helper
INFO - 2017-02-17 12:27:06 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:27:06 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:27:06 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:27:06 --> Template Class Initialized
INFO - 2017-02-17 12:27:06 --> Controller Class Initialized
DEBUG - 2017-02-17 12:27:06 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:27:06 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:27:06 --> Model Class Initialized
DEBUG - 2017-02-17 12:27:06 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 12:27:06 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:27:06 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:27:06 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:27:06 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:27:06 --> Final output sent to browser
DEBUG - 2017-02-17 12:27:06 --> Total execution time: 0.0518
INFO - 2017-02-17 12:27:06 --> Config Class Initialized
INFO - 2017-02-17 12:27:06 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:27:06 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:27:06 --> Utf8 Class Initialized
INFO - 2017-02-17 12:27:06 --> URI Class Initialized
INFO - 2017-02-17 12:27:06 --> Router Class Initialized
INFO - 2017-02-17 12:27:06 --> Output Class Initialized
INFO - 2017-02-17 12:27:06 --> Security Class Initialized
DEBUG - 2017-02-17 12:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:27:06 --> Input Class Initialized
INFO - 2017-02-17 12:27:06 --> Language Class Initialized
ERROR - 2017-02-17 12:27:06 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:27:34 --> Config Class Initialized
INFO - 2017-02-17 12:27:34 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:27:34 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:27:34 --> Utf8 Class Initialized
INFO - 2017-02-17 12:27:34 --> URI Class Initialized
INFO - 2017-02-17 12:27:34 --> Router Class Initialized
INFO - 2017-02-17 12:27:34 --> Output Class Initialized
INFO - 2017-02-17 12:27:34 --> Security Class Initialized
DEBUG - 2017-02-17 12:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:27:34 --> Input Class Initialized
INFO - 2017-02-17 12:27:34 --> Language Class Initialized
INFO - 2017-02-17 12:27:34 --> Language Class Initialized
INFO - 2017-02-17 12:27:34 --> Config Class Initialized
INFO - 2017-02-17 12:27:34 --> Loader Class Initialized
INFO - 2017-02-17 12:27:34 --> Helper loaded: form_helper
INFO - 2017-02-17 12:27:34 --> Helper loaded: url_helper
INFO - 2017-02-17 12:27:34 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:27:34 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:27:34 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:27:34 --> Template Class Initialized
INFO - 2017-02-17 12:27:34 --> Controller Class Initialized
DEBUG - 2017-02-17 12:27:34 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:27:34 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:27:34 --> Model Class Initialized
DEBUG - 2017-02-17 12:27:34 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 12:27:34 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:27:34 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:27:34 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:27:34 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:27:34 --> Final output sent to browser
DEBUG - 2017-02-17 12:27:34 --> Total execution time: 0.0598
INFO - 2017-02-17 12:27:34 --> Config Class Initialized
INFO - 2017-02-17 12:27:34 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:27:34 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:27:34 --> Utf8 Class Initialized
INFO - 2017-02-17 12:27:34 --> URI Class Initialized
INFO - 2017-02-17 12:27:34 --> Router Class Initialized
INFO - 2017-02-17 12:27:34 --> Output Class Initialized
INFO - 2017-02-17 12:27:34 --> Security Class Initialized
DEBUG - 2017-02-17 12:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:27:34 --> Input Class Initialized
INFO - 2017-02-17 12:27:34 --> Language Class Initialized
ERROR - 2017-02-17 12:27:34 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:28:34 --> Config Class Initialized
INFO - 2017-02-17 12:28:34 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:28:34 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:28:34 --> Utf8 Class Initialized
INFO - 2017-02-17 12:28:34 --> URI Class Initialized
INFO - 2017-02-17 12:28:34 --> Router Class Initialized
INFO - 2017-02-17 12:28:34 --> Output Class Initialized
INFO - 2017-02-17 12:28:34 --> Security Class Initialized
DEBUG - 2017-02-17 12:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:28:34 --> Input Class Initialized
INFO - 2017-02-17 12:28:34 --> Language Class Initialized
INFO - 2017-02-17 12:28:34 --> Language Class Initialized
INFO - 2017-02-17 12:28:34 --> Config Class Initialized
INFO - 2017-02-17 12:28:34 --> Loader Class Initialized
INFO - 2017-02-17 12:28:34 --> Helper loaded: form_helper
INFO - 2017-02-17 12:28:34 --> Helper loaded: url_helper
INFO - 2017-02-17 12:28:34 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:28:34 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:28:34 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:28:34 --> Template Class Initialized
INFO - 2017-02-17 12:28:34 --> Controller Class Initialized
DEBUG - 2017-02-17 12:28:34 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:28:34 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:28:34 --> Model Class Initialized
DEBUG - 2017-02-17 12:28:34 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 12:28:34 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:28:34 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:28:34 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
ERROR - 2017-02-17 12:28:34 --> Severity: Notice --> Undefined index: main C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\backend.php 37
DEBUG - 2017-02-17 12:28:34 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:28:34 --> Final output sent to browser
DEBUG - 2017-02-17 12:28:34 --> Total execution time: 0.0601
INFO - 2017-02-17 12:28:34 --> Config Class Initialized
INFO - 2017-02-17 12:28:34 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:28:34 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:28:34 --> Utf8 Class Initialized
INFO - 2017-02-17 12:28:34 --> URI Class Initialized
INFO - 2017-02-17 12:28:34 --> Router Class Initialized
INFO - 2017-02-17 12:28:34 --> Output Class Initialized
INFO - 2017-02-17 12:28:34 --> Security Class Initialized
DEBUG - 2017-02-17 12:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:28:34 --> Input Class Initialized
INFO - 2017-02-17 12:28:34 --> Language Class Initialized
ERROR - 2017-02-17 12:28:34 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:28:40 --> Config Class Initialized
INFO - 2017-02-17 12:28:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:28:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:28:40 --> Utf8 Class Initialized
INFO - 2017-02-17 12:28:40 --> URI Class Initialized
INFO - 2017-02-17 12:28:40 --> Router Class Initialized
INFO - 2017-02-17 12:28:40 --> Output Class Initialized
INFO - 2017-02-17 12:28:40 --> Security Class Initialized
DEBUG - 2017-02-17 12:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:28:40 --> Input Class Initialized
INFO - 2017-02-17 12:28:40 --> Language Class Initialized
INFO - 2017-02-17 12:28:40 --> Language Class Initialized
INFO - 2017-02-17 12:28:40 --> Config Class Initialized
INFO - 2017-02-17 12:28:40 --> Loader Class Initialized
INFO - 2017-02-17 12:28:40 --> Helper loaded: form_helper
INFO - 2017-02-17 12:28:40 --> Helper loaded: url_helper
INFO - 2017-02-17 12:28:40 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:28:40 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:28:40 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:28:40 --> Template Class Initialized
INFO - 2017-02-17 12:28:40 --> Controller Class Initialized
DEBUG - 2017-02-17 12:28:40 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:28:40 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:28:40 --> Model Class Initialized
DEBUG - 2017-02-17 12:28:40 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 12:28:40 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:28:40 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:28:40 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
ERROR - 2017-02-17 12:28:40 --> Severity: Notice --> Undefined index: main C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\backend.php 37
DEBUG - 2017-02-17 12:28:40 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:28:40 --> Final output sent to browser
DEBUG - 2017-02-17 12:28:40 --> Total execution time: 0.0412
INFO - 2017-02-17 12:28:40 --> Config Class Initialized
INFO - 2017-02-17 12:28:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:28:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:28:40 --> Utf8 Class Initialized
INFO - 2017-02-17 12:28:40 --> URI Class Initialized
INFO - 2017-02-17 12:28:40 --> Router Class Initialized
INFO - 2017-02-17 12:28:40 --> Output Class Initialized
INFO - 2017-02-17 12:28:40 --> Security Class Initialized
DEBUG - 2017-02-17 12:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:28:40 --> Input Class Initialized
INFO - 2017-02-17 12:28:40 --> Language Class Initialized
ERROR - 2017-02-17 12:28:40 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:28:49 --> Config Class Initialized
INFO - 2017-02-17 12:28:49 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:28:49 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:28:49 --> Utf8 Class Initialized
INFO - 2017-02-17 12:28:49 --> URI Class Initialized
INFO - 2017-02-17 12:28:49 --> Router Class Initialized
INFO - 2017-02-17 12:28:49 --> Output Class Initialized
INFO - 2017-02-17 12:28:49 --> Security Class Initialized
DEBUG - 2017-02-17 12:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:28:49 --> Input Class Initialized
INFO - 2017-02-17 12:28:49 --> Language Class Initialized
INFO - 2017-02-17 12:28:49 --> Language Class Initialized
INFO - 2017-02-17 12:28:49 --> Config Class Initialized
INFO - 2017-02-17 12:28:49 --> Loader Class Initialized
INFO - 2017-02-17 12:28:49 --> Helper loaded: form_helper
INFO - 2017-02-17 12:28:49 --> Helper loaded: url_helper
INFO - 2017-02-17 12:28:49 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:28:49 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:28:49 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:28:49 --> Template Class Initialized
INFO - 2017-02-17 12:28:49 --> Controller Class Initialized
DEBUG - 2017-02-17 12:28:49 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:28:49 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:28:49 --> Model Class Initialized
DEBUG - 2017-02-17 12:28:49 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 12:28:49 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:28:49 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:28:49 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
ERROR - 2017-02-17 12:28:49 --> Severity: Notice --> Undefined index: main C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\backend.php 37
DEBUG - 2017-02-17 12:28:49 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:28:49 --> Final output sent to browser
DEBUG - 2017-02-17 12:28:49 --> Total execution time: 0.0581
INFO - 2017-02-17 12:28:49 --> Config Class Initialized
INFO - 2017-02-17 12:28:49 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:28:49 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:28:49 --> Utf8 Class Initialized
INFO - 2017-02-17 12:28:49 --> URI Class Initialized
INFO - 2017-02-17 12:28:49 --> Router Class Initialized
INFO - 2017-02-17 12:28:49 --> Output Class Initialized
INFO - 2017-02-17 12:28:49 --> Security Class Initialized
DEBUG - 2017-02-17 12:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:28:49 --> Input Class Initialized
INFO - 2017-02-17 12:28:49 --> Language Class Initialized
ERROR - 2017-02-17 12:28:49 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:29:30 --> Config Class Initialized
INFO - 2017-02-17 12:29:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:29:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:29:30 --> Utf8 Class Initialized
INFO - 2017-02-17 12:29:30 --> URI Class Initialized
INFO - 2017-02-17 12:29:30 --> Router Class Initialized
INFO - 2017-02-17 12:29:30 --> Output Class Initialized
INFO - 2017-02-17 12:29:30 --> Security Class Initialized
DEBUG - 2017-02-17 12:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:29:30 --> Input Class Initialized
INFO - 2017-02-17 12:29:30 --> Language Class Initialized
INFO - 2017-02-17 12:29:30 --> Language Class Initialized
INFO - 2017-02-17 12:29:30 --> Config Class Initialized
INFO - 2017-02-17 12:29:30 --> Loader Class Initialized
INFO - 2017-02-17 12:29:30 --> Helper loaded: form_helper
INFO - 2017-02-17 12:29:30 --> Helper loaded: url_helper
INFO - 2017-02-17 12:29:30 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:29:30 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:29:30 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:29:30 --> Template Class Initialized
INFO - 2017-02-17 12:29:30 --> Controller Class Initialized
DEBUG - 2017-02-17 12:29:30 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:29:30 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:29:30 --> Model Class Initialized
DEBUG - 2017-02-17 12:29:30 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 12:29:30 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:29:30 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:29:30 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:29:30 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:29:30 --> Final output sent to browser
DEBUG - 2017-02-17 12:29:30 --> Total execution time: 0.0715
INFO - 2017-02-17 12:29:31 --> Config Class Initialized
INFO - 2017-02-17 12:29:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:29:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:29:31 --> Utf8 Class Initialized
INFO - 2017-02-17 12:29:31 --> URI Class Initialized
INFO - 2017-02-17 12:29:31 --> Router Class Initialized
INFO - 2017-02-17 12:29:31 --> Output Class Initialized
INFO - 2017-02-17 12:29:31 --> Security Class Initialized
DEBUG - 2017-02-17 12:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:29:31 --> Input Class Initialized
INFO - 2017-02-17 12:29:31 --> Language Class Initialized
ERROR - 2017-02-17 12:29:31 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:29:52 --> Config Class Initialized
INFO - 2017-02-17 12:29:52 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:29:52 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:29:52 --> Utf8 Class Initialized
INFO - 2017-02-17 12:29:52 --> URI Class Initialized
INFO - 2017-02-17 12:29:52 --> Router Class Initialized
INFO - 2017-02-17 12:29:52 --> Output Class Initialized
INFO - 2017-02-17 12:29:52 --> Security Class Initialized
DEBUG - 2017-02-17 12:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:29:52 --> Input Class Initialized
INFO - 2017-02-17 12:29:52 --> Language Class Initialized
INFO - 2017-02-17 12:29:52 --> Language Class Initialized
INFO - 2017-02-17 12:29:52 --> Config Class Initialized
INFO - 2017-02-17 12:29:52 --> Loader Class Initialized
INFO - 2017-02-17 12:29:52 --> Helper loaded: form_helper
INFO - 2017-02-17 12:29:52 --> Helper loaded: url_helper
INFO - 2017-02-17 12:29:52 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:29:52 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:29:52 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:29:52 --> Template Class Initialized
INFO - 2017-02-17 12:29:52 --> Controller Class Initialized
DEBUG - 2017-02-17 12:29:52 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:29:52 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:29:52 --> Model Class Initialized
DEBUG - 2017-02-17 12:29:52 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 12:29:52 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:29:52 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:29:52 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:29:52 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:29:52 --> Final output sent to browser
DEBUG - 2017-02-17 12:29:52 --> Total execution time: 0.0712
INFO - 2017-02-17 12:29:52 --> Config Class Initialized
INFO - 2017-02-17 12:29:52 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:29:52 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:29:52 --> Utf8 Class Initialized
INFO - 2017-02-17 12:29:52 --> URI Class Initialized
INFO - 2017-02-17 12:29:52 --> Router Class Initialized
INFO - 2017-02-17 12:29:52 --> Output Class Initialized
INFO - 2017-02-17 12:29:52 --> Security Class Initialized
DEBUG - 2017-02-17 12:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:29:52 --> Input Class Initialized
INFO - 2017-02-17 12:29:52 --> Language Class Initialized
ERROR - 2017-02-17 12:29:52 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:30:12 --> Config Class Initialized
INFO - 2017-02-17 12:30:12 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:30:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:30:12 --> Utf8 Class Initialized
INFO - 2017-02-17 12:30:12 --> URI Class Initialized
INFO - 2017-02-17 12:30:12 --> Router Class Initialized
INFO - 2017-02-17 12:30:12 --> Output Class Initialized
INFO - 2017-02-17 12:30:12 --> Security Class Initialized
DEBUG - 2017-02-17 12:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:30:12 --> Input Class Initialized
INFO - 2017-02-17 12:30:12 --> Language Class Initialized
INFO - 2017-02-17 12:30:12 --> Language Class Initialized
INFO - 2017-02-17 12:30:12 --> Config Class Initialized
INFO - 2017-02-17 12:30:12 --> Loader Class Initialized
INFO - 2017-02-17 12:30:12 --> Helper loaded: form_helper
INFO - 2017-02-17 12:30:12 --> Helper loaded: url_helper
INFO - 2017-02-17 12:30:12 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:30:12 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:30:12 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:30:12 --> Template Class Initialized
INFO - 2017-02-17 12:30:12 --> Controller Class Initialized
DEBUG - 2017-02-17 12:30:12 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:30:12 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:30:12 --> Model Class Initialized
DEBUG - 2017-02-17 12:30:12 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 12:30:12 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:30:12 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:30:12 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:30:12 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:30:12 --> Final output sent to browser
DEBUG - 2017-02-17 12:30:12 --> Total execution time: 0.0600
INFO - 2017-02-17 12:30:12 --> Config Class Initialized
INFO - 2017-02-17 12:30:12 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:30:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:30:12 --> Utf8 Class Initialized
INFO - 2017-02-17 12:30:12 --> URI Class Initialized
INFO - 2017-02-17 12:30:12 --> Router Class Initialized
INFO - 2017-02-17 12:30:12 --> Output Class Initialized
INFO - 2017-02-17 12:30:12 --> Security Class Initialized
DEBUG - 2017-02-17 12:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:30:12 --> Input Class Initialized
INFO - 2017-02-17 12:30:12 --> Language Class Initialized
ERROR - 2017-02-17 12:30:12 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:30:57 --> Config Class Initialized
INFO - 2017-02-17 12:30:57 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:30:57 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:30:57 --> Utf8 Class Initialized
INFO - 2017-02-17 12:30:57 --> URI Class Initialized
INFO - 2017-02-17 12:30:57 --> Router Class Initialized
INFO - 2017-02-17 12:30:57 --> Output Class Initialized
INFO - 2017-02-17 12:30:57 --> Security Class Initialized
DEBUG - 2017-02-17 12:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:30:57 --> Input Class Initialized
INFO - 2017-02-17 12:30:57 --> Language Class Initialized
INFO - 2017-02-17 12:30:57 --> Language Class Initialized
INFO - 2017-02-17 12:30:57 --> Config Class Initialized
INFO - 2017-02-17 12:30:57 --> Loader Class Initialized
INFO - 2017-02-17 12:30:57 --> Helper loaded: form_helper
INFO - 2017-02-17 12:30:57 --> Helper loaded: url_helper
INFO - 2017-02-17 12:30:57 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:30:57 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:30:57 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:30:57 --> Template Class Initialized
INFO - 2017-02-17 12:30:57 --> Controller Class Initialized
DEBUG - 2017-02-17 12:30:57 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:30:57 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:30:57 --> Model Class Initialized
DEBUG - 2017-02-17 12:30:57 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 12:30:57 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:30:57 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:30:57 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:30:57 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:30:57 --> Final output sent to browser
DEBUG - 2017-02-17 12:30:57 --> Total execution time: 0.0551
INFO - 2017-02-17 12:30:57 --> Config Class Initialized
INFO - 2017-02-17 12:30:57 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:30:57 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:30:57 --> Utf8 Class Initialized
INFO - 2017-02-17 12:30:57 --> URI Class Initialized
INFO - 2017-02-17 12:30:57 --> Router Class Initialized
INFO - 2017-02-17 12:30:57 --> Output Class Initialized
INFO - 2017-02-17 12:30:57 --> Security Class Initialized
DEBUG - 2017-02-17 12:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:30:57 --> Input Class Initialized
INFO - 2017-02-17 12:30:57 --> Language Class Initialized
ERROR - 2017-02-17 12:30:57 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:34:09 --> Config Class Initialized
INFO - 2017-02-17 12:34:09 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:34:09 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:34:09 --> Utf8 Class Initialized
INFO - 2017-02-17 12:34:09 --> URI Class Initialized
INFO - 2017-02-17 12:34:09 --> Router Class Initialized
INFO - 2017-02-17 12:34:09 --> Output Class Initialized
INFO - 2017-02-17 12:34:09 --> Security Class Initialized
DEBUG - 2017-02-17 12:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:34:09 --> Input Class Initialized
INFO - 2017-02-17 12:34:09 --> Language Class Initialized
INFO - 2017-02-17 12:34:09 --> Language Class Initialized
INFO - 2017-02-17 12:34:09 --> Config Class Initialized
INFO - 2017-02-17 12:34:10 --> Loader Class Initialized
INFO - 2017-02-17 12:34:10 --> Helper loaded: form_helper
INFO - 2017-02-17 12:34:10 --> Helper loaded: url_helper
INFO - 2017-02-17 12:34:10 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:34:10 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:34:10 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:34:10 --> Template Class Initialized
INFO - 2017-02-17 12:34:10 --> Controller Class Initialized
DEBUG - 2017-02-17 12:34:10 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:34:10 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:34:10 --> Model Class Initialized
DEBUG - 2017-02-17 12:34:10 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 12:34:10 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:34:10 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:34:10 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:34:10 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:34:10 --> Final output sent to browser
DEBUG - 2017-02-17 12:34:10 --> Total execution time: 1.6365
INFO - 2017-02-17 12:34:11 --> Config Class Initialized
INFO - 2017-02-17 12:34:11 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:34:11 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:34:11 --> Utf8 Class Initialized
INFO - 2017-02-17 12:34:11 --> URI Class Initialized
INFO - 2017-02-17 12:34:11 --> Router Class Initialized
INFO - 2017-02-17 12:34:11 --> Output Class Initialized
INFO - 2017-02-17 12:34:11 --> Security Class Initialized
DEBUG - 2017-02-17 12:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:34:11 --> Input Class Initialized
INFO - 2017-02-17 12:34:11 --> Language Class Initialized
ERROR - 2017-02-17 12:34:11 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 12:36:56 --> Config Class Initialized
INFO - 2017-02-17 12:36:56 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:36:59 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:36:59 --> Utf8 Class Initialized
INFO - 2017-02-17 12:36:59 --> URI Class Initialized
INFO - 2017-02-17 12:37:00 --> Router Class Initialized
INFO - 2017-02-17 12:37:00 --> Output Class Initialized
INFO - 2017-02-17 12:37:01 --> Security Class Initialized
DEBUG - 2017-02-17 12:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:37:01 --> Input Class Initialized
INFO - 2017-02-17 12:37:01 --> Language Class Initialized
INFO - 2017-02-17 12:37:03 --> Language Class Initialized
INFO - 2017-02-17 12:37:03 --> Config Class Initialized
INFO - 2017-02-17 12:37:03 --> Loader Class Initialized
INFO - 2017-02-17 12:37:04 --> Helper loaded: form_helper
INFO - 2017-02-17 12:37:04 --> Helper loaded: url_helper
INFO - 2017-02-17 12:37:05 --> Helper loaded: utility_helper
INFO - 2017-02-17 12:37:06 --> Database Driver Class Initialized
DEBUG - 2017-02-17 12:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 12:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 12:37:07 --> User Agent Class Initialized
DEBUG - 2017-02-17 12:37:07 --> Template Class Initialized
INFO - 2017-02-17 12:37:07 --> Controller Class Initialized
DEBUG - 2017-02-17 12:37:07 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 12:37:07 --> Helper loaded: cookie_helper
INFO - 2017-02-17 12:37:08 --> Model Class Initialized
DEBUG - 2017-02-17 12:37:08 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 12:37:08 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 12:37:08 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 12:37:08 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 12:37:08 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 12:37:08 --> Final output sent to browser
DEBUG - 2017-02-17 12:37:08 --> Total execution time: 13.2981
INFO - 2017-02-17 12:37:09 --> Config Class Initialized
INFO - 2017-02-17 12:37:09 --> Hooks Class Initialized
DEBUG - 2017-02-17 12:37:09 --> UTF-8 Support Enabled
INFO - 2017-02-17 12:37:09 --> Utf8 Class Initialized
INFO - 2017-02-17 12:37:09 --> URI Class Initialized
INFO - 2017-02-17 12:37:09 --> Router Class Initialized
INFO - 2017-02-17 12:37:09 --> Output Class Initialized
INFO - 2017-02-17 12:37:09 --> Security Class Initialized
DEBUG - 2017-02-17 12:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 12:37:09 --> Input Class Initialized
INFO - 2017-02-17 12:37:09 --> Language Class Initialized
ERROR - 2017-02-17 12:37:09 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 13:04:00 --> Config Class Initialized
INFO - 2017-02-17 13:04:00 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:04:00 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:04:00 --> Utf8 Class Initialized
INFO - 2017-02-17 13:04:00 --> URI Class Initialized
INFO - 2017-02-17 13:04:00 --> Router Class Initialized
INFO - 2017-02-17 13:04:00 --> Output Class Initialized
INFO - 2017-02-17 13:04:00 --> Security Class Initialized
DEBUG - 2017-02-17 13:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:04:00 --> Input Class Initialized
INFO - 2017-02-17 13:04:00 --> Language Class Initialized
INFO - 2017-02-17 13:04:00 --> Language Class Initialized
INFO - 2017-02-17 13:04:00 --> Config Class Initialized
INFO - 2017-02-17 13:04:00 --> Loader Class Initialized
INFO - 2017-02-17 13:04:01 --> Helper loaded: form_helper
INFO - 2017-02-17 13:04:01 --> Helper loaded: url_helper
INFO - 2017-02-17 13:04:01 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:04:01 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:04:01 --> Config Class Initialized
INFO - 2017-02-17 13:04:01 --> Hooks Class Initialized
INFO - 2017-02-17 13:04:01 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:04:01 --> Template Class Initialized
INFO - 2017-02-17 13:04:01 --> Controller Class Initialized
DEBUG - 2017-02-17 13:04:01 --> Dashboard MX_Controller Initialized
DEBUG - 2017-02-17 13:04:01 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:04:01 --> Utf8 Class Initialized
INFO - 2017-02-17 13:04:01 --> URI Class Initialized
DEBUG - 2017-02-17 13:04:01 --> No URI present. Default controller set.
INFO - 2017-02-17 13:04:01 --> Router Class Initialized
INFO - 2017-02-17 13:04:01 --> Output Class Initialized
INFO - 2017-02-17 13:04:01 --> Security Class Initialized
DEBUG - 2017-02-17 13:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:04:01 --> Input Class Initialized
INFO - 2017-02-17 13:04:01 --> Language Class Initialized
INFO - 2017-02-17 13:04:01 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:04:01 --> Language Class Initialized
INFO - 2017-02-17 13:04:01 --> Config Class Initialized
INFO - 2017-02-17 13:04:01 --> Loader Class Initialized
INFO - 2017-02-17 13:04:01 --> Model Class Initialized
DEBUG - 2017-02-17 13:04:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
INFO - 2017-02-17 13:04:02 --> Helper loaded: form_helper
DEBUG - 2017-02-17 13:04:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 13:04:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 13:04:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
INFO - 2017-02-17 13:04:02 --> Helper loaded: url_helper
INFO - 2017-02-17 13:04:02 --> Helper loaded: utility_helper
DEBUG - 2017-02-17 13:04:02 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 13:04:02 --> Final output sent to browser
DEBUG - 2017-02-17 13:04:02 --> Total execution time: 2.0121
INFO - 2017-02-17 13:04:02 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:04:02 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:04:02 --> Template Class Initialized
INFO - 2017-02-17 13:04:02 --> Controller Class Initialized
DEBUG - 2017-02-17 13:04:02 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:04:02 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:04:02 --> Model Class Initialized
INFO - 2017-02-17 13:04:02 --> Form Validation Class Initialized
ERROR - 2017-02-17 13:04:02 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\razor\application\modules\backend\views\login.php 38
ERROR - 2017-02-17 13:04:02 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\razor\application\modules\backend\views\login.php 42
DEBUG - 2017-02-17 13:04:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
ERROR - 2017-02-17 13:04:02 --> Severity: Notice --> Undefined index: sidebar C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\backend.php 35
ERROR - 2017-02-17 13:04:02 --> Severity: Notice --> Undefined index: header C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\backend.php 36
ERROR - 2017-02-17 13:04:02 --> Severity: Notice --> Undefined index: footer C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\backend.php 38
DEBUG - 2017-02-17 13:04:02 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 13:04:02 --> Final output sent to browser
DEBUG - 2017-02-17 13:04:02 --> Total execution time: 0.7843
INFO - 2017-02-17 13:04:23 --> Config Class Initialized
INFO - 2017-02-17 13:04:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:04:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:04:23 --> Utf8 Class Initialized
INFO - 2017-02-17 13:04:23 --> URI Class Initialized
DEBUG - 2017-02-17 13:04:23 --> No URI present. Default controller set.
INFO - 2017-02-17 13:04:23 --> Router Class Initialized
INFO - 2017-02-17 13:04:23 --> Output Class Initialized
INFO - 2017-02-17 13:04:23 --> Security Class Initialized
DEBUG - 2017-02-17 13:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:04:23 --> Input Class Initialized
INFO - 2017-02-17 13:04:23 --> Language Class Initialized
INFO - 2017-02-17 13:04:23 --> Language Class Initialized
INFO - 2017-02-17 13:04:23 --> Config Class Initialized
INFO - 2017-02-17 13:04:23 --> Loader Class Initialized
INFO - 2017-02-17 13:04:23 --> Helper loaded: form_helper
INFO - 2017-02-17 13:04:23 --> Helper loaded: url_helper
INFO - 2017-02-17 13:04:23 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:04:23 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:04:23 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:04:23 --> Template Class Initialized
INFO - 2017-02-17 13:04:23 --> Controller Class Initialized
INFO - 2017-02-17 13:04:23 --> Form Validation Class Initialized
INFO - 2017-02-17 13:04:23 --> Model Class Initialized
ERROR - 2017-02-17 13:04:24 --> Severity: Error --> Access to undeclared static property: TABLES::$MST_GLOBAL_SETTING C:\xampp\htdocs\razor\application\models\Common_model.php 376
INFO - 2017-02-17 13:04:39 --> Config Class Initialized
INFO - 2017-02-17 13:04:39 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:04:39 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:04:39 --> Utf8 Class Initialized
INFO - 2017-02-17 13:04:39 --> URI Class Initialized
DEBUG - 2017-02-17 13:04:39 --> No URI present. Default controller set.
INFO - 2017-02-17 13:04:39 --> Router Class Initialized
INFO - 2017-02-17 13:04:39 --> Output Class Initialized
INFO - 2017-02-17 13:04:39 --> Security Class Initialized
DEBUG - 2017-02-17 13:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:04:39 --> Input Class Initialized
INFO - 2017-02-17 13:04:39 --> Language Class Initialized
INFO - 2017-02-17 13:04:39 --> Language Class Initialized
INFO - 2017-02-17 13:04:39 --> Config Class Initialized
INFO - 2017-02-17 13:04:39 --> Loader Class Initialized
INFO - 2017-02-17 13:04:39 --> Helper loaded: form_helper
INFO - 2017-02-17 13:04:39 --> Helper loaded: url_helper
INFO - 2017-02-17 13:04:39 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:04:39 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:04:39 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:04:39 --> Template Class Initialized
INFO - 2017-02-17 13:04:39 --> Controller Class Initialized
INFO - 2017-02-17 13:04:39 --> Form Validation Class Initialized
INFO - 2017-02-17 13:04:39 --> Model Class Initialized
ERROR - 2017-02-17 13:04:39 --> Severity: Error --> Access to undeclared static property: TABLES::$MST_GLOBAL_SETTING C:\xampp\htdocs\razor\application\models\Common_model.php 376
INFO - 2017-02-17 13:04:40 --> Config Class Initialized
INFO - 2017-02-17 13:04:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:04:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:04:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:04:40 --> URI Class Initialized
DEBUG - 2017-02-17 13:04:40 --> No URI present. Default controller set.
INFO - 2017-02-17 13:04:40 --> Router Class Initialized
INFO - 2017-02-17 13:04:40 --> Output Class Initialized
INFO - 2017-02-17 13:04:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:04:40 --> Input Class Initialized
INFO - 2017-02-17 13:04:40 --> Language Class Initialized
INFO - 2017-02-17 13:04:40 --> Language Class Initialized
INFO - 2017-02-17 13:04:40 --> Config Class Initialized
INFO - 2017-02-17 13:04:40 --> Loader Class Initialized
INFO - 2017-02-17 13:04:40 --> Helper loaded: form_helper
INFO - 2017-02-17 13:04:40 --> Helper loaded: url_helper
INFO - 2017-02-17 13:04:40 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:04:40 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:04:40 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:04:40 --> Template Class Initialized
INFO - 2017-02-17 13:04:40 --> Controller Class Initialized
INFO - 2017-02-17 13:04:40 --> Form Validation Class Initialized
INFO - 2017-02-17 13:04:40 --> Model Class Initialized
ERROR - 2017-02-17 13:04:40 --> Severity: Error --> Access to undeclared static property: TABLES::$MST_GLOBAL_SETTING C:\xampp\htdocs\razor\application\models\Common_model.php 376
INFO - 2017-02-17 13:04:41 --> Config Class Initialized
INFO - 2017-02-17 13:04:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:04:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:04:41 --> Utf8 Class Initialized
INFO - 2017-02-17 13:04:41 --> URI Class Initialized
DEBUG - 2017-02-17 13:04:41 --> No URI present. Default controller set.
INFO - 2017-02-17 13:04:41 --> Router Class Initialized
INFO - 2017-02-17 13:04:41 --> Output Class Initialized
INFO - 2017-02-17 13:04:41 --> Security Class Initialized
DEBUG - 2017-02-17 13:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:04:41 --> Input Class Initialized
INFO - 2017-02-17 13:04:41 --> Language Class Initialized
INFO - 2017-02-17 13:04:41 --> Language Class Initialized
INFO - 2017-02-17 13:04:41 --> Config Class Initialized
INFO - 2017-02-17 13:04:41 --> Loader Class Initialized
INFO - 2017-02-17 13:04:41 --> Helper loaded: form_helper
INFO - 2017-02-17 13:04:41 --> Helper loaded: url_helper
INFO - 2017-02-17 13:04:41 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:04:41 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:04:41 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:04:41 --> Template Class Initialized
INFO - 2017-02-17 13:04:41 --> Controller Class Initialized
INFO - 2017-02-17 13:04:41 --> Form Validation Class Initialized
INFO - 2017-02-17 13:04:41 --> Model Class Initialized
ERROR - 2017-02-17 13:04:41 --> Severity: Error --> Access to undeclared static property: TABLES::$MST_GLOBAL_SETTING C:\xampp\htdocs\razor\application\models\Common_model.php 376
INFO - 2017-02-17 13:05:10 --> Config Class Initialized
INFO - 2017-02-17 13:05:10 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:10 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:10 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:10 --> URI Class Initialized
DEBUG - 2017-02-17 13:05:10 --> No URI present. Default controller set.
INFO - 2017-02-17 13:05:10 --> Router Class Initialized
INFO - 2017-02-17 13:05:10 --> Output Class Initialized
INFO - 2017-02-17 13:05:10 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:10 --> Input Class Initialized
INFO - 2017-02-17 13:05:10 --> Language Class Initialized
INFO - 2017-02-17 13:05:10 --> Language Class Initialized
INFO - 2017-02-17 13:05:10 --> Config Class Initialized
INFO - 2017-02-17 13:05:10 --> Loader Class Initialized
INFO - 2017-02-17 13:05:10 --> Helper loaded: form_helper
INFO - 2017-02-17 13:05:10 --> Helper loaded: url_helper
INFO - 2017-02-17 13:05:10 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:05:10 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:05:10 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:05:10 --> Template Class Initialized
INFO - 2017-02-17 13:05:10 --> Controller Class Initialized
INFO - 2017-02-17 13:05:10 --> Form Validation Class Initialized
INFO - 2017-02-17 13:05:10 --> Model Class Initialized
ERROR - 2017-02-17 13:05:10 --> Severity: Error --> Access to undeclared static property: TABLES::$MST_GLOBAL_SETTING C:\xampp\htdocs\razor\application\models\Common_model.php 376
INFO - 2017-02-17 13:05:11 --> Config Class Initialized
INFO - 2017-02-17 13:05:11 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:11 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:11 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:11 --> URI Class Initialized
DEBUG - 2017-02-17 13:05:11 --> No URI present. Default controller set.
INFO - 2017-02-17 13:05:11 --> Router Class Initialized
INFO - 2017-02-17 13:05:11 --> Output Class Initialized
INFO - 2017-02-17 13:05:11 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:11 --> Input Class Initialized
INFO - 2017-02-17 13:05:11 --> Language Class Initialized
INFO - 2017-02-17 13:05:11 --> Language Class Initialized
INFO - 2017-02-17 13:05:11 --> Config Class Initialized
INFO - 2017-02-17 13:05:11 --> Loader Class Initialized
INFO - 2017-02-17 13:05:11 --> Helper loaded: form_helper
INFO - 2017-02-17 13:05:11 --> Helper loaded: url_helper
INFO - 2017-02-17 13:05:11 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:05:11 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:05:11 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:05:11 --> Template Class Initialized
INFO - 2017-02-17 13:05:11 --> Controller Class Initialized
INFO - 2017-02-17 13:05:11 --> Form Validation Class Initialized
INFO - 2017-02-17 13:05:11 --> Model Class Initialized
ERROR - 2017-02-17 13:05:11 --> Severity: Error --> Access to undeclared static property: TABLES::$MST_GLOBAL_SETTING C:\xampp\htdocs\razor\application\models\Common_model.php 376
INFO - 2017-02-17 13:05:11 --> Config Class Initialized
INFO - 2017-02-17 13:05:11 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:11 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:11 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:11 --> URI Class Initialized
DEBUG - 2017-02-17 13:05:11 --> No URI present. Default controller set.
INFO - 2017-02-17 13:05:11 --> Router Class Initialized
INFO - 2017-02-17 13:05:11 --> Output Class Initialized
INFO - 2017-02-17 13:05:11 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:11 --> Input Class Initialized
INFO - 2017-02-17 13:05:11 --> Language Class Initialized
INFO - 2017-02-17 13:05:11 --> Language Class Initialized
INFO - 2017-02-17 13:05:11 --> Config Class Initialized
INFO - 2017-02-17 13:05:11 --> Loader Class Initialized
INFO - 2017-02-17 13:05:12 --> Helper loaded: form_helper
INFO - 2017-02-17 13:05:12 --> Helper loaded: url_helper
INFO - 2017-02-17 13:05:12 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:05:12 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:05:12 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:05:12 --> Template Class Initialized
INFO - 2017-02-17 13:05:12 --> Controller Class Initialized
INFO - 2017-02-17 13:05:12 --> Form Validation Class Initialized
INFO - 2017-02-17 13:05:12 --> Model Class Initialized
ERROR - 2017-02-17 13:05:12 --> Severity: Error --> Access to undeclared static property: TABLES::$MST_GLOBAL_SETTING C:\xampp\htdocs\razor\application\models\Common_model.php 376
INFO - 2017-02-17 13:05:12 --> Config Class Initialized
INFO - 2017-02-17 13:05:12 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:12 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:12 --> URI Class Initialized
DEBUG - 2017-02-17 13:05:12 --> No URI present. Default controller set.
INFO - 2017-02-17 13:05:12 --> Router Class Initialized
INFO - 2017-02-17 13:05:12 --> Output Class Initialized
INFO - 2017-02-17 13:05:12 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:12 --> Input Class Initialized
INFO - 2017-02-17 13:05:12 --> Language Class Initialized
INFO - 2017-02-17 13:05:12 --> Language Class Initialized
INFO - 2017-02-17 13:05:12 --> Config Class Initialized
INFO - 2017-02-17 13:05:12 --> Loader Class Initialized
INFO - 2017-02-17 13:05:12 --> Helper loaded: form_helper
INFO - 2017-02-17 13:05:12 --> Helper loaded: url_helper
INFO - 2017-02-17 13:05:12 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:05:12 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:05:12 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:05:12 --> Template Class Initialized
INFO - 2017-02-17 13:05:12 --> Controller Class Initialized
INFO - 2017-02-17 13:05:12 --> Form Validation Class Initialized
INFO - 2017-02-17 13:05:12 --> Model Class Initialized
ERROR - 2017-02-17 13:05:12 --> Severity: Error --> Access to undeclared static property: TABLES::$MST_GLOBAL_SETTING C:\xampp\htdocs\razor\application\models\Common_model.php 376
INFO - 2017-02-17 13:05:22 --> Config Class Initialized
INFO - 2017-02-17 13:05:22 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:22 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:22 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:22 --> URI Class Initialized
DEBUG - 2017-02-17 13:05:22 --> No URI present. Default controller set.
INFO - 2017-02-17 13:05:22 --> Router Class Initialized
INFO - 2017-02-17 13:05:22 --> Output Class Initialized
INFO - 2017-02-17 13:05:22 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:22 --> Input Class Initialized
INFO - 2017-02-17 13:05:22 --> Language Class Initialized
INFO - 2017-02-17 13:05:22 --> Language Class Initialized
INFO - 2017-02-17 13:05:22 --> Config Class Initialized
INFO - 2017-02-17 13:05:22 --> Loader Class Initialized
INFO - 2017-02-17 13:05:22 --> Helper loaded: form_helper
INFO - 2017-02-17 13:05:22 --> Helper loaded: url_helper
INFO - 2017-02-17 13:05:22 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:05:22 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:05:22 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:05:22 --> Template Class Initialized
INFO - 2017-02-17 13:05:22 --> Controller Class Initialized
INFO - 2017-02-17 13:05:22 --> Form Validation Class Initialized
INFO - 2017-02-17 13:05:22 --> Model Class Initialized
DEBUG - 2017-02-17 13:05:22 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:05:22 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:05:22 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:05:22 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:05:22 --> Final output sent to browser
DEBUG - 2017-02-17 13:05:22 --> Total execution time: 0.0805
INFO - 2017-02-17 13:05:22 --> Config Class Initialized
INFO - 2017-02-17 13:05:22 --> Hooks Class Initialized
INFO - 2017-02-17 13:05:22 --> Config Class Initialized
INFO - 2017-02-17 13:05:22 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:22 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:22 --> Utf8 Class Initialized
DEBUG - 2017-02-17 13:05:22 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:22 --> URI Class Initialized
INFO - 2017-02-17 13:05:22 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:22 --> URI Class Initialized
INFO - 2017-02-17 13:05:22 --> Router Class Initialized
INFO - 2017-02-17 13:05:22 --> Output Class Initialized
INFO - 2017-02-17 13:05:22 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:22 --> Input Class Initialized
INFO - 2017-02-17 13:05:22 --> Language Class Initialized
ERROR - 2017-02-17 13:05:22 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:22 --> Config Class Initialized
INFO - 2017-02-17 13:05:22 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:22 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:22 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:22 --> Router Class Initialized
INFO - 2017-02-17 13:05:22 --> URI Class Initialized
INFO - 2017-02-17 13:05:22 --> Output Class Initialized
INFO - 2017-02-17 13:05:22 --> Router Class Initialized
INFO - 2017-02-17 13:05:22 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:22 --> Output Class Initialized
INFO - 2017-02-17 13:05:22 --> Input Class Initialized
INFO - 2017-02-17 13:05:22 --> Language Class Initialized
INFO - 2017-02-17 13:05:22 --> Security Class Initialized
ERROR - 2017-02-17 13:05:22 --> 404 Page Not Found: /index
DEBUG - 2017-02-17 13:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:22 --> Input Class Initialized
INFO - 2017-02-17 13:05:22 --> Language Class Initialized
ERROR - 2017-02-17 13:05:22 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:23 --> Config Class Initialized
INFO - 2017-02-17 13:05:23 --> Hooks Class Initialized
INFO - 2017-02-17 13:05:23 --> Config Class Initialized
INFO - 2017-02-17 13:05:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:23 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:23 --> URI Class Initialized
DEBUG - 2017-02-17 13:05:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:23 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:23 --> URI Class Initialized
INFO - 2017-02-17 13:05:23 --> Router Class Initialized
INFO - 2017-02-17 13:05:23 --> Router Class Initialized
INFO - 2017-02-17 13:05:23 --> Output Class Initialized
INFO - 2017-02-17 13:05:23 --> Security Class Initialized
INFO - 2017-02-17 13:05:23 --> Output Class Initialized
DEBUG - 2017-02-17 13:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:23 --> Input Class Initialized
INFO - 2017-02-17 13:05:23 --> Security Class Initialized
INFO - 2017-02-17 13:05:23 --> Language Class Initialized
DEBUG - 2017-02-17 13:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-17 13:05:23 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:23 --> Input Class Initialized
INFO - 2017-02-17 13:05:23 --> Language Class Initialized
ERROR - 2017-02-17 13:05:23 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:23 --> Config Class Initialized
INFO - 2017-02-17 13:05:23 --> Hooks Class Initialized
INFO - 2017-02-17 13:05:23 --> Config Class Initialized
INFO - 2017-02-17 13:05:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:23 --> UTF-8 Support Enabled
DEBUG - 2017-02-17 13:05:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:23 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:23 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:23 --> URI Class Initialized
INFO - 2017-02-17 13:05:23 --> URI Class Initialized
INFO - 2017-02-17 13:05:23 --> Router Class Initialized
INFO - 2017-02-17 13:05:23 --> Router Class Initialized
INFO - 2017-02-17 13:05:23 --> Output Class Initialized
INFO - 2017-02-17 13:05:23 --> Output Class Initialized
INFO - 2017-02-17 13:05:23 --> Security Class Initialized
INFO - 2017-02-17 13:05:23 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-17 13:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:23 --> Input Class Initialized
INFO - 2017-02-17 13:05:23 --> Input Class Initialized
INFO - 2017-02-17 13:05:23 --> Language Class Initialized
INFO - 2017-02-17 13:05:23 --> Language Class Initialized
ERROR - 2017-02-17 13:05:23 --> 404 Page Not Found: /index
ERROR - 2017-02-17 13:05:23 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:24 --> Config Class Initialized
INFO - 2017-02-17 13:05:24 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:24 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:24 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:24 --> URI Class Initialized
INFO - 2017-02-17 13:05:24 --> Router Class Initialized
INFO - 2017-02-17 13:05:24 --> Output Class Initialized
INFO - 2017-02-17 13:05:24 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:24 --> Input Class Initialized
INFO - 2017-02-17 13:05:24 --> Language Class Initialized
ERROR - 2017-02-17 13:05:24 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:24 --> Config Class Initialized
INFO - 2017-02-17 13:05:24 --> Hooks Class Initialized
INFO - 2017-02-17 13:05:24 --> Config Class Initialized
INFO - 2017-02-17 13:05:24 --> Hooks Class Initialized
INFO - 2017-02-17 13:05:24 --> Config Class Initialized
INFO - 2017-02-17 13:05:24 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:24 --> UTF-8 Support Enabled
DEBUG - 2017-02-17 13:05:24 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:24 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:24 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:24 --> URI Class Initialized
INFO - 2017-02-17 13:05:24 --> URI Class Initialized
DEBUG - 2017-02-17 13:05:24 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:24 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:24 --> URI Class Initialized
INFO - 2017-02-17 13:05:24 --> Router Class Initialized
INFO - 2017-02-17 13:05:24 --> Router Class Initialized
INFO - 2017-02-17 13:05:24 --> Output Class Initialized
INFO - 2017-02-17 13:05:24 --> Output Class Initialized
INFO - 2017-02-17 13:05:24 --> Security Class Initialized
INFO - 2017-02-17 13:05:24 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-17 13:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:24 --> Input Class Initialized
INFO - 2017-02-17 13:05:24 --> Router Class Initialized
INFO - 2017-02-17 13:05:24 --> Input Class Initialized
INFO - 2017-02-17 13:05:24 --> Language Class Initialized
ERROR - 2017-02-17 13:05:24 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:24 --> Language Class Initialized
INFO - 2017-02-17 13:05:24 --> Output Class Initialized
ERROR - 2017-02-17 13:05:24 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:24 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:24 --> Input Class Initialized
INFO - 2017-02-17 13:05:24 --> Language Class Initialized
ERROR - 2017-02-17 13:05:24 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:24 --> Config Class Initialized
INFO - 2017-02-17 13:05:24 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:24 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:24 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:24 --> URI Class Initialized
INFO - 2017-02-17 13:05:24 --> Router Class Initialized
INFO - 2017-02-17 13:05:24 --> Output Class Initialized
INFO - 2017-02-17 13:05:24 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:24 --> Input Class Initialized
INFO - 2017-02-17 13:05:24 --> Language Class Initialized
ERROR - 2017-02-17 13:05:24 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:24 --> Config Class Initialized
INFO - 2017-02-17 13:05:24 --> Hooks Class Initialized
INFO - 2017-02-17 13:05:24 --> Config Class Initialized
INFO - 2017-02-17 13:05:24 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:24 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:24 --> Utf8 Class Initialized
DEBUG - 2017-02-17 13:05:24 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:24 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:24 --> URI Class Initialized
INFO - 2017-02-17 13:05:24 --> URI Class Initialized
INFO - 2017-02-17 13:05:24 --> Router Class Initialized
INFO - 2017-02-17 13:05:24 --> Router Class Initialized
INFO - 2017-02-17 13:05:24 --> Output Class Initialized
INFO - 2017-02-17 13:05:24 --> Output Class Initialized
INFO - 2017-02-17 13:05:24 --> Security Class Initialized
INFO - 2017-02-17 13:05:24 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:24 --> Input Class Initialized
DEBUG - 2017-02-17 13:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:24 --> Language Class Initialized
INFO - 2017-02-17 13:05:24 --> Input Class Initialized
INFO - 2017-02-17 13:05:24 --> Language Class Initialized
ERROR - 2017-02-17 13:05:24 --> 404 Page Not Found: /index
ERROR - 2017-02-17 13:05:24 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:24 --> Config Class Initialized
INFO - 2017-02-17 13:05:24 --> Config Class Initialized
INFO - 2017-02-17 13:05:24 --> Hooks Class Initialized
INFO - 2017-02-17 13:05:24 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:24 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:24 --> Utf8 Class Initialized
DEBUG - 2017-02-17 13:05:24 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:24 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:24 --> URI Class Initialized
INFO - 2017-02-17 13:05:24 --> URI Class Initialized
INFO - 2017-02-17 13:05:24 --> Router Class Initialized
INFO - 2017-02-17 13:05:24 --> Router Class Initialized
INFO - 2017-02-17 13:05:24 --> Output Class Initialized
INFO - 2017-02-17 13:05:24 --> Output Class Initialized
INFO - 2017-02-17 13:05:24 --> Security Class Initialized
INFO - 2017-02-17 13:05:24 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:24 --> Input Class Initialized
INFO - 2017-02-17 13:05:24 --> Language Class Initialized
DEBUG - 2017-02-17 13:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:24 --> Input Class Initialized
ERROR - 2017-02-17 13:05:24 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:24 --> Language Class Initialized
ERROR - 2017-02-17 13:05:24 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:25 --> Config Class Initialized
INFO - 2017-02-17 13:05:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:25 --> URI Class Initialized
INFO - 2017-02-17 13:05:25 --> Router Class Initialized
INFO - 2017-02-17 13:05:25 --> Output Class Initialized
INFO - 2017-02-17 13:05:25 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:25 --> Input Class Initialized
INFO - 2017-02-17 13:05:25 --> Language Class Initialized
ERROR - 2017-02-17 13:05:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:25 --> Config Class Initialized
INFO - 2017-02-17 13:05:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:25 --> URI Class Initialized
INFO - 2017-02-17 13:05:25 --> Router Class Initialized
INFO - 2017-02-17 13:05:25 --> Output Class Initialized
INFO - 2017-02-17 13:05:25 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:25 --> Input Class Initialized
INFO - 2017-02-17 13:05:25 --> Language Class Initialized
ERROR - 2017-02-17 13:05:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:25 --> Config Class Initialized
INFO - 2017-02-17 13:05:25 --> Hooks Class Initialized
INFO - 2017-02-17 13:05:25 --> Config Class Initialized
INFO - 2017-02-17 13:05:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:25 --> Config Class Initialized
INFO - 2017-02-17 13:05:25 --> URI Class Initialized
INFO - 2017-02-17 13:05:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:25 --> Router Class Initialized
INFO - 2017-02-17 13:05:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:25 --> URI Class Initialized
INFO - 2017-02-17 13:05:25 --> Output Class Initialized
DEBUG - 2017-02-17 13:05:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:25 --> Security Class Initialized
INFO - 2017-02-17 13:05:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:25 --> Router Class Initialized
INFO - 2017-02-17 13:05:25 --> Config Class Initialized
INFO - 2017-02-17 13:05:25 --> Config Class Initialized
INFO - 2017-02-17 13:05:25 --> Hooks Class Initialized
INFO - 2017-02-17 13:05:25 --> Hooks Class Initialized
INFO - 2017-02-17 13:05:25 --> Output Class Initialized
INFO - 2017-02-17 13:05:25 --> URI Class Initialized
INFO - 2017-02-17 13:05:25 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-17 13:05:25 --> UTF-8 Support Enabled
DEBUG - 2017-02-17 13:05:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:25 --> Input Class Initialized
INFO - 2017-02-17 13:05:25 --> Utf8 Class Initialized
DEBUG - 2017-02-17 13:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:25 --> Input Class Initialized
INFO - 2017-02-17 13:05:25 --> Language Class Initialized
INFO - 2017-02-17 13:05:25 --> URI Class Initialized
INFO - 2017-02-17 13:05:25 --> Language Class Initialized
INFO - 2017-02-17 13:05:25 --> URI Class Initialized
ERROR - 2017-02-17 13:05:25 --> 404 Page Not Found: /index
ERROR - 2017-02-17 13:05:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:25 --> Router Class Initialized
INFO - 2017-02-17 13:05:25 --> Router Class Initialized
INFO - 2017-02-17 13:05:25 --> Output Class Initialized
INFO - 2017-02-17 13:05:25 --> Router Class Initialized
INFO - 2017-02-17 13:05:25 --> Output Class Initialized
INFO - 2017-02-17 13:05:25 --> Security Class Initialized
INFO - 2017-02-17 13:05:25 --> Security Class Initialized
INFO - 2017-02-17 13:05:25 --> Output Class Initialized
DEBUG - 2017-02-17 13:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:25 --> Input Class Initialized
DEBUG - 2017-02-17 13:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:25 --> Security Class Initialized
INFO - 2017-02-17 13:05:25 --> Input Class Initialized
INFO - 2017-02-17 13:05:25 --> Language Class Initialized
INFO - 2017-02-17 13:05:25 --> Language Class Initialized
DEBUG - 2017-02-17 13:05:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-17 13:05:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:25 --> Input Class Initialized
ERROR - 2017-02-17 13:05:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:25 --> Language Class Initialized
ERROR - 2017-02-17 13:05:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:25 --> Config Class Initialized
INFO - 2017-02-17 13:05:25 --> Hooks Class Initialized
INFO - 2017-02-17 13:05:25 --> Config Class Initialized
INFO - 2017-02-17 13:05:25 --> Hooks Class Initialized
INFO - 2017-02-17 13:05:25 --> Config Class Initialized
INFO - 2017-02-17 13:05:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:25 --> Utf8 Class Initialized
DEBUG - 2017-02-17 13:05:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:25 --> URI Class Initialized
INFO - 2017-02-17 13:05:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:25 --> URI Class Initialized
DEBUG - 2017-02-17 13:05:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:25 --> URI Class Initialized
INFO - 2017-02-17 13:05:25 --> Router Class Initialized
INFO - 2017-02-17 13:05:25 --> Router Class Initialized
INFO - 2017-02-17 13:05:25 --> Output Class Initialized
INFO - 2017-02-17 13:05:25 --> Router Class Initialized
INFO - 2017-02-17 13:05:25 --> Security Class Initialized
INFO - 2017-02-17 13:05:25 --> Output Class Initialized
INFO - 2017-02-17 13:05:25 --> Output Class Initialized
DEBUG - 2017-02-17 13:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:25 --> Input Class Initialized
INFO - 2017-02-17 13:05:25 --> Language Class Initialized
INFO - 2017-02-17 13:05:25 --> Security Class Initialized
INFO - 2017-02-17 13:05:25 --> Security Class Initialized
ERROR - 2017-02-17 13:05:25 --> 404 Page Not Found: /index
DEBUG - 2017-02-17 13:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:25 --> Input Class Initialized
DEBUG - 2017-02-17 13:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:25 --> Language Class Initialized
INFO - 2017-02-17 13:05:25 --> Input Class Initialized
ERROR - 2017-02-17 13:05:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:25 --> Language Class Initialized
ERROR - 2017-02-17 13:05:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:25 --> Config Class Initialized
INFO - 2017-02-17 13:05:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:25 --> URI Class Initialized
INFO - 2017-02-17 13:05:25 --> Router Class Initialized
INFO - 2017-02-17 13:05:25 --> Output Class Initialized
INFO - 2017-02-17 13:05:25 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:25 --> Input Class Initialized
INFO - 2017-02-17 13:05:25 --> Language Class Initialized
ERROR - 2017-02-17 13:05:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:25 --> Config Class Initialized
INFO - 2017-02-17 13:05:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:25 --> URI Class Initialized
INFO - 2017-02-17 13:05:25 --> Router Class Initialized
INFO - 2017-02-17 13:05:25 --> Output Class Initialized
INFO - 2017-02-17 13:05:25 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:25 --> Input Class Initialized
INFO - 2017-02-17 13:05:25 --> Language Class Initialized
ERROR - 2017-02-17 13:05:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:25 --> Config Class Initialized
INFO - 2017-02-17 13:05:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:25 --> URI Class Initialized
INFO - 2017-02-17 13:05:25 --> Router Class Initialized
INFO - 2017-02-17 13:05:25 --> Output Class Initialized
INFO - 2017-02-17 13:05:25 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:25 --> Input Class Initialized
INFO - 2017-02-17 13:05:25 --> Language Class Initialized
ERROR - 2017-02-17 13:05:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:25 --> Config Class Initialized
INFO - 2017-02-17 13:05:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:25 --> URI Class Initialized
INFO - 2017-02-17 13:05:25 --> Router Class Initialized
INFO - 2017-02-17 13:05:25 --> Output Class Initialized
INFO - 2017-02-17 13:05:25 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:25 --> Input Class Initialized
INFO - 2017-02-17 13:05:25 --> Language Class Initialized
ERROR - 2017-02-17 13:05:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:25 --> Config Class Initialized
INFO - 2017-02-17 13:05:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:25 --> URI Class Initialized
INFO - 2017-02-17 13:05:25 --> Router Class Initialized
INFO - 2017-02-17 13:05:25 --> Output Class Initialized
INFO - 2017-02-17 13:05:25 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:25 --> Input Class Initialized
INFO - 2017-02-17 13:05:25 --> Language Class Initialized
ERROR - 2017-02-17 13:05:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:25 --> Config Class Initialized
INFO - 2017-02-17 13:05:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:25 --> URI Class Initialized
INFO - 2017-02-17 13:05:25 --> Router Class Initialized
INFO - 2017-02-17 13:05:25 --> Output Class Initialized
INFO - 2017-02-17 13:05:25 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:25 --> Input Class Initialized
INFO - 2017-02-17 13:05:25 --> Language Class Initialized
ERROR - 2017-02-17 13:05:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:26 --> Config Class Initialized
INFO - 2017-02-17 13:05:26 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:26 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:26 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:26 --> URI Class Initialized
INFO - 2017-02-17 13:05:26 --> Router Class Initialized
INFO - 2017-02-17 13:05:26 --> Output Class Initialized
INFO - 2017-02-17 13:05:26 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:26 --> Input Class Initialized
INFO - 2017-02-17 13:05:26 --> Language Class Initialized
ERROR - 2017-02-17 13:05:26 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:28 --> Config Class Initialized
INFO - 2017-02-17 13:05:28 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:28 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:28 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:28 --> URI Class Initialized
INFO - 2017-02-17 13:05:28 --> Router Class Initialized
INFO - 2017-02-17 13:05:28 --> Output Class Initialized
INFO - 2017-02-17 13:05:28 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:28 --> Input Class Initialized
INFO - 2017-02-17 13:05:28 --> Language Class Initialized
ERROR - 2017-02-17 13:05:28 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:28 --> Config Class Initialized
INFO - 2017-02-17 13:05:28 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:28 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:28 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:28 --> URI Class Initialized
INFO - 2017-02-17 13:05:28 --> Router Class Initialized
INFO - 2017-02-17 13:05:28 --> Output Class Initialized
INFO - 2017-02-17 13:05:28 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:28 --> Input Class Initialized
INFO - 2017-02-17 13:05:28 --> Language Class Initialized
ERROR - 2017-02-17 13:05:28 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:28 --> Config Class Initialized
INFO - 2017-02-17 13:05:28 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:28 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:28 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:28 --> URI Class Initialized
INFO - 2017-02-17 13:05:28 --> Router Class Initialized
INFO - 2017-02-17 13:05:28 --> Output Class Initialized
INFO - 2017-02-17 13:05:28 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:28 --> Input Class Initialized
INFO - 2017-02-17 13:05:28 --> Language Class Initialized
ERROR - 2017-02-17 13:05:28 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:28 --> Config Class Initialized
INFO - 2017-02-17 13:05:28 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:28 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:28 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:28 --> URI Class Initialized
INFO - 2017-02-17 13:05:28 --> Router Class Initialized
INFO - 2017-02-17 13:05:28 --> Output Class Initialized
INFO - 2017-02-17 13:05:28 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:28 --> Input Class Initialized
INFO - 2017-02-17 13:05:28 --> Language Class Initialized
ERROR - 2017-02-17 13:05:28 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:28 --> Config Class Initialized
INFO - 2017-02-17 13:05:28 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:28 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:28 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:29 --> Config Class Initialized
INFO - 2017-02-17 13:05:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:29 --> URI Class Initialized
INFO - 2017-02-17 13:05:29 --> Router Class Initialized
INFO - 2017-02-17 13:05:29 --> Output Class Initialized
INFO - 2017-02-17 13:05:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:29 --> Input Class Initialized
INFO - 2017-02-17 13:05:29 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:30 --> Input Class Initialized
INFO - 2017-02-17 13:05:30 --> Language Class Initialized
ERROR - 2017-02-17 13:05:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:30 --> Config Class Initialized
INFO - 2017-02-17 13:05:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:30 --> URI Class Initialized
INFO - 2017-02-17 13:05:30 --> Router Class Initialized
INFO - 2017-02-17 13:05:30 --> Output Class Initialized
INFO - 2017-02-17 13:05:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:31 --> Config Class Initialized
INFO - 2017-02-17 13:05:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:05:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:31 --> URI Class Initialized
INFO - 2017-02-17 13:05:31 --> Router Class Initialized
INFO - 2017-02-17 13:05:31 --> Output Class Initialized
INFO - 2017-02-17 13:05:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:31 --> Input Class Initialized
INFO - 2017-02-17 13:05:31 --> Language Class Initialized
ERROR - 2017-02-17 13:05:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:35 --> Config Class Initialized
INFO - 2017-02-17 13:05:35 --> Hooks Class Initialized
INFO - 2017-02-17 13:05:35 --> Config Class Initialized
INFO - 2017-02-17 13:05:35 --> Hooks Class Initialized
INFO - 2017-02-17 13:05:35 --> Config Class Initialized
DEBUG - 2017-02-17 13:05:35 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:35 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:35 --> Hooks Class Initialized
INFO - 2017-02-17 13:05:35 --> URI Class Initialized
DEBUG - 2017-02-17 13:05:35 --> UTF-8 Support Enabled
DEBUG - 2017-02-17 13:05:35 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:05:35 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:35 --> Router Class Initialized
INFO - 2017-02-17 13:05:35 --> Utf8 Class Initialized
INFO - 2017-02-17 13:05:35 --> URI Class Initialized
INFO - 2017-02-17 13:05:35 --> URI Class Initialized
INFO - 2017-02-17 13:05:35 --> Output Class Initialized
INFO - 2017-02-17 13:05:35 --> Router Class Initialized
INFO - 2017-02-17 13:05:35 --> Security Class Initialized
INFO - 2017-02-17 13:05:35 --> Router Class Initialized
DEBUG - 2017-02-17 13:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:35 --> Output Class Initialized
INFO - 2017-02-17 13:05:35 --> Input Class Initialized
INFO - 2017-02-17 13:05:35 --> Language Class Initialized
INFO - 2017-02-17 13:05:35 --> Security Class Initialized
ERROR - 2017-02-17 13:05:35 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:35 --> Output Class Initialized
DEBUG - 2017-02-17 13:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:35 --> Input Class Initialized
INFO - 2017-02-17 13:05:35 --> Language Class Initialized
ERROR - 2017-02-17 13:05:35 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:05:35 --> Security Class Initialized
DEBUG - 2017-02-17 13:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:05:35 --> Input Class Initialized
INFO - 2017-02-17 13:05:35 --> Language Class Initialized
ERROR - 2017-02-17 13:05:35 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
DEBUG - 2017-02-17 13:06:48 --> No URI present. Default controller set.
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Loader Class Initialized
INFO - 2017-02-17 13:06:48 --> Helper loaded: form_helper
INFO - 2017-02-17 13:06:48 --> Helper loaded: url_helper
INFO - 2017-02-17 13:06:48 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:06:48 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:06:48 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Template Class Initialized
INFO - 2017-02-17 13:06:48 --> Controller Class Initialized
INFO - 2017-02-17 13:06:48 --> Form Validation Class Initialized
INFO - 2017-02-17 13:06:48 --> Model Class Initialized
DEBUG - 2017-02-17 13:06:48 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:06:48 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:06:48 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:06:48 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:06:48 --> Final output sent to browser
DEBUG - 2017-02-17 13:06:48 --> Total execution time: 0.0544
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
ERROR - 2017-02-17 13:06:48 --> 404 Page Not Found: /index
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
INFO - 2017-02-17 13:06:48 --> Config Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
INFO - 2017-02-17 13:06:48 --> Hooks Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
INFO - 2017-02-17 13:06:48 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:48 --> Router Class Initialized
INFO - 2017-02-17 13:06:48 --> URI Class Initialized
DEBUG - 2017-02-17 13:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:48 --> Input Class Initialized
INFO - 2017-02-17 13:06:48 --> Output Class Initialized
INFO - 2017-02-17 13:06:48 --> Language Class Initialized
INFO - 2017-02-17 13:06:49 --> Security Class Initialized
ERROR - 2017-02-17 13:06:49 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:49 --> Router Class Initialized
INFO - 2017-02-17 13:06:49 --> Security Class Initialized
INFO - 2017-02-17 13:06:49 --> Output Class Initialized
DEBUG - 2017-02-17 13:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:49 --> Input Class Initialized
DEBUG - 2017-02-17 13:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:49 --> Security Class Initialized
INFO - 2017-02-17 13:06:49 --> Input Class Initialized
INFO - 2017-02-17 13:06:49 --> Language Class Initialized
DEBUG - 2017-02-17 13:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:49 --> Language Class Initialized
INFO - 2017-02-17 13:06:49 --> Input Class Initialized
ERROR - 2017-02-17 13:06:49 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:49 --> Language Class Initialized
ERROR - 2017-02-17 13:06:49 --> 404 Page Not Found: /index
ERROR - 2017-02-17 13:06:49 --> 404 Page Not Found: /index
DEBUG - 2017-02-17 13:06:49 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:49 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:49 --> URI Class Initialized
INFO - 2017-02-17 13:06:49 --> Router Class Initialized
INFO - 2017-02-17 13:06:49 --> Output Class Initialized
INFO - 2017-02-17 13:06:49 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:49 --> Input Class Initialized
INFO - 2017-02-17 13:06:49 --> Language Class Initialized
ERROR - 2017-02-17 13:06:49 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:50 --> Config Class Initialized
INFO - 2017-02-17 13:06:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:50 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:50 --> URI Class Initialized
INFO - 2017-02-17 13:06:50 --> Router Class Initialized
INFO - 2017-02-17 13:06:50 --> Output Class Initialized
INFO - 2017-02-17 13:06:50 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:50 --> Input Class Initialized
INFO - 2017-02-17 13:06:50 --> Language Class Initialized
ERROR - 2017-02-17 13:06:50 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:50 --> Config Class Initialized
INFO - 2017-02-17 13:06:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:50 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:50 --> URI Class Initialized
INFO - 2017-02-17 13:06:50 --> Router Class Initialized
INFO - 2017-02-17 13:06:50 --> Output Class Initialized
INFO - 2017-02-17 13:06:50 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:50 --> Input Class Initialized
INFO - 2017-02-17 13:06:50 --> Language Class Initialized
ERROR - 2017-02-17 13:06:50 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:50 --> Config Class Initialized
INFO - 2017-02-17 13:06:50 --> Hooks Class Initialized
INFO - 2017-02-17 13:06:50 --> Config Class Initialized
INFO - 2017-02-17 13:06:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:50 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:50 --> URI Class Initialized
DEBUG - 2017-02-17 13:06:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:50 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:50 --> URI Class Initialized
INFO - 2017-02-17 13:06:50 --> Router Class Initialized
INFO - 2017-02-17 13:06:50 --> Output Class Initialized
INFO - 2017-02-17 13:06:50 --> Router Class Initialized
INFO - 2017-02-17 13:06:50 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:50 --> Output Class Initialized
INFO - 2017-02-17 13:06:50 --> Input Class Initialized
INFO - 2017-02-17 13:06:50 --> Language Class Initialized
ERROR - 2017-02-17 13:06:50 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:50 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:50 --> Input Class Initialized
INFO - 2017-02-17 13:06:50 --> Language Class Initialized
ERROR - 2017-02-17 13:06:50 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:50 --> Config Class Initialized
INFO - 2017-02-17 13:06:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:50 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:50 --> URI Class Initialized
INFO - 2017-02-17 13:06:50 --> Router Class Initialized
INFO - 2017-02-17 13:06:50 --> Output Class Initialized
INFO - 2017-02-17 13:06:50 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:50 --> Input Class Initialized
INFO - 2017-02-17 13:06:50 --> Language Class Initialized
ERROR - 2017-02-17 13:06:50 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:50 --> Config Class Initialized
INFO - 2017-02-17 13:06:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:50 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:50 --> URI Class Initialized
INFO - 2017-02-17 13:06:50 --> Router Class Initialized
INFO - 2017-02-17 13:06:50 --> Output Class Initialized
INFO - 2017-02-17 13:06:50 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:50 --> Input Class Initialized
INFO - 2017-02-17 13:06:50 --> Language Class Initialized
ERROR - 2017-02-17 13:06:50 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:50 --> Config Class Initialized
INFO - 2017-02-17 13:06:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:50 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:50 --> URI Class Initialized
INFO - 2017-02-17 13:06:50 --> Router Class Initialized
INFO - 2017-02-17 13:06:50 --> Output Class Initialized
INFO - 2017-02-17 13:06:50 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:50 --> Input Class Initialized
INFO - 2017-02-17 13:06:50 --> Language Class Initialized
ERROR - 2017-02-17 13:06:50 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:50 --> Config Class Initialized
INFO - 2017-02-17 13:06:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:50 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:50 --> URI Class Initialized
INFO - 2017-02-17 13:06:50 --> Router Class Initialized
INFO - 2017-02-17 13:06:50 --> Output Class Initialized
INFO - 2017-02-17 13:06:50 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:50 --> Input Class Initialized
INFO - 2017-02-17 13:06:50 --> Language Class Initialized
ERROR - 2017-02-17 13:06:50 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:50 --> Config Class Initialized
INFO - 2017-02-17 13:06:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:50 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:50 --> URI Class Initialized
INFO - 2017-02-17 13:06:50 --> Router Class Initialized
INFO - 2017-02-17 13:06:51 --> Output Class Initialized
INFO - 2017-02-17 13:06:51 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:51 --> Input Class Initialized
INFO - 2017-02-17 13:06:51 --> Language Class Initialized
ERROR - 2017-02-17 13:06:51 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:51 --> Config Class Initialized
INFO - 2017-02-17 13:06:51 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:51 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:51 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:51 --> URI Class Initialized
INFO - 2017-02-17 13:06:51 --> Router Class Initialized
INFO - 2017-02-17 13:06:51 --> Output Class Initialized
INFO - 2017-02-17 13:06:51 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:51 --> Input Class Initialized
INFO - 2017-02-17 13:06:51 --> Language Class Initialized
ERROR - 2017-02-17 13:06:51 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:51 --> Config Class Initialized
INFO - 2017-02-17 13:06:51 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:51 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:51 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:51 --> URI Class Initialized
INFO - 2017-02-17 13:06:51 --> Router Class Initialized
INFO - 2017-02-17 13:06:51 --> Output Class Initialized
INFO - 2017-02-17 13:06:51 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:51 --> Input Class Initialized
INFO - 2017-02-17 13:06:51 --> Language Class Initialized
ERROR - 2017-02-17 13:06:51 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:51 --> Config Class Initialized
INFO - 2017-02-17 13:06:51 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:51 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:51 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:51 --> URI Class Initialized
INFO - 2017-02-17 13:06:51 --> Router Class Initialized
INFO - 2017-02-17 13:06:51 --> Output Class Initialized
INFO - 2017-02-17 13:06:51 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:51 --> Input Class Initialized
INFO - 2017-02-17 13:06:51 --> Language Class Initialized
ERROR - 2017-02-17 13:06:51 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:51 --> Config Class Initialized
INFO - 2017-02-17 13:06:51 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:51 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:51 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:51 --> URI Class Initialized
INFO - 2017-02-17 13:06:51 --> Router Class Initialized
INFO - 2017-02-17 13:06:51 --> Output Class Initialized
INFO - 2017-02-17 13:06:51 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:51 --> Input Class Initialized
INFO - 2017-02-17 13:06:51 --> Language Class Initialized
ERROR - 2017-02-17 13:06:51 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:06:51 --> Config Class Initialized
INFO - 2017-02-17 13:06:51 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:06:51 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:06:51 --> Utf8 Class Initialized
INFO - 2017-02-17 13:06:51 --> URI Class Initialized
INFO - 2017-02-17 13:06:51 --> Router Class Initialized
INFO - 2017-02-17 13:06:51 --> Output Class Initialized
INFO - 2017-02-17 13:06:51 --> Security Class Initialized
DEBUG - 2017-02-17 13:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:06:51 --> Input Class Initialized
INFO - 2017-02-17 13:06:51 --> Language Class Initialized
ERROR - 2017-02-17 13:06:51 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:22 --> Config Class Initialized
INFO - 2017-02-17 13:08:22 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:22 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:22 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:22 --> URI Class Initialized
DEBUG - 2017-02-17 13:08:22 --> No URI present. Default controller set.
INFO - 2017-02-17 13:08:22 --> Router Class Initialized
INFO - 2017-02-17 13:08:22 --> Output Class Initialized
INFO - 2017-02-17 13:08:23 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:23 --> Input Class Initialized
INFO - 2017-02-17 13:08:23 --> Language Class Initialized
INFO - 2017-02-17 13:08:23 --> Language Class Initialized
INFO - 2017-02-17 13:08:23 --> Config Class Initialized
INFO - 2017-02-17 13:08:23 --> Loader Class Initialized
INFO - 2017-02-17 13:08:23 --> Helper loaded: form_helper
INFO - 2017-02-17 13:08:23 --> Helper loaded: url_helper
INFO - 2017-02-17 13:08:23 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:08:23 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:08:23 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:08:23 --> Template Class Initialized
INFO - 2017-02-17 13:08:23 --> Controller Class Initialized
INFO - 2017-02-17 13:08:23 --> Form Validation Class Initialized
INFO - 2017-02-17 13:08:23 --> Model Class Initialized
DEBUG - 2017-02-17 13:08:23 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:08:23 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:08:23 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:08:23 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:08:23 --> Final output sent to browser
DEBUG - 2017-02-17 13:08:23 --> Total execution time: 0.0711
INFO - 2017-02-17 13:08:23 --> Config Class Initialized
INFO - 2017-02-17 13:08:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:23 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:23 --> URI Class Initialized
INFO - 2017-02-17 13:08:23 --> Router Class Initialized
INFO - 2017-02-17 13:08:23 --> Output Class Initialized
INFO - 2017-02-17 13:08:23 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:23 --> Input Class Initialized
INFO - 2017-02-17 13:08:23 --> Language Class Initialized
ERROR - 2017-02-17 13:08:23 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:23 --> Config Class Initialized
INFO - 2017-02-17 13:08:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:23 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:23 --> URI Class Initialized
INFO - 2017-02-17 13:08:23 --> Router Class Initialized
INFO - 2017-02-17 13:08:23 --> Output Class Initialized
INFO - 2017-02-17 13:08:23 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:23 --> Input Class Initialized
INFO - 2017-02-17 13:08:23 --> Language Class Initialized
ERROR - 2017-02-17 13:08:23 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:23 --> Config Class Initialized
INFO - 2017-02-17 13:08:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:23 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:23 --> URI Class Initialized
INFO - 2017-02-17 13:08:23 --> Router Class Initialized
INFO - 2017-02-17 13:08:23 --> Output Class Initialized
INFO - 2017-02-17 13:08:23 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:23 --> Input Class Initialized
INFO - 2017-02-17 13:08:23 --> Language Class Initialized
ERROR - 2017-02-17 13:08:23 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:23 --> Config Class Initialized
INFO - 2017-02-17 13:08:23 --> Hooks Class Initialized
INFO - 2017-02-17 13:08:23 --> Config Class Initialized
INFO - 2017-02-17 13:08:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:23 --> Utf8 Class Initialized
DEBUG - 2017-02-17 13:08:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:23 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:23 --> URI Class Initialized
INFO - 2017-02-17 13:08:23 --> URI Class Initialized
INFO - 2017-02-17 13:08:23 --> Router Class Initialized
INFO - 2017-02-17 13:08:23 --> Output Class Initialized
INFO - 2017-02-17 13:08:23 --> Security Class Initialized
INFO - 2017-02-17 13:08:23 --> Router Class Initialized
DEBUG - 2017-02-17 13:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:23 --> Input Class Initialized
INFO - 2017-02-17 13:08:23 --> Output Class Initialized
INFO - 2017-02-17 13:08:23 --> Language Class Initialized
INFO - 2017-02-17 13:08:23 --> Security Class Initialized
ERROR - 2017-02-17 13:08:23 --> 404 Page Not Found: /index
DEBUG - 2017-02-17 13:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:23 --> Input Class Initialized
INFO - 2017-02-17 13:08:23 --> Language Class Initialized
ERROR - 2017-02-17 13:08:23 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:24 --> Config Class Initialized
INFO - 2017-02-17 13:08:24 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:24 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:24 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:24 --> URI Class Initialized
INFO - 2017-02-17 13:08:24 --> Router Class Initialized
INFO - 2017-02-17 13:08:24 --> Output Class Initialized
INFO - 2017-02-17 13:08:24 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:24 --> Input Class Initialized
INFO - 2017-02-17 13:08:24 --> Language Class Initialized
ERROR - 2017-02-17 13:08:24 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:24 --> Config Class Initialized
INFO - 2017-02-17 13:08:24 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:24 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:24 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:24 --> URI Class Initialized
INFO - 2017-02-17 13:08:24 --> Router Class Initialized
INFO - 2017-02-17 13:08:24 --> Output Class Initialized
INFO - 2017-02-17 13:08:24 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:24 --> Input Class Initialized
INFO - 2017-02-17 13:08:24 --> Language Class Initialized
ERROR - 2017-02-17 13:08:24 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:25 --> Config Class Initialized
INFO - 2017-02-17 13:08:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:25 --> URI Class Initialized
INFO - 2017-02-17 13:08:25 --> Router Class Initialized
INFO - 2017-02-17 13:08:25 --> Output Class Initialized
INFO - 2017-02-17 13:08:25 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:25 --> Input Class Initialized
INFO - 2017-02-17 13:08:25 --> Language Class Initialized
ERROR - 2017-02-17 13:08:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:25 --> Config Class Initialized
INFO - 2017-02-17 13:08:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:25 --> URI Class Initialized
INFO - 2017-02-17 13:08:25 --> Router Class Initialized
INFO - 2017-02-17 13:08:25 --> Output Class Initialized
INFO - 2017-02-17 13:08:25 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:25 --> Input Class Initialized
INFO - 2017-02-17 13:08:25 --> Language Class Initialized
ERROR - 2017-02-17 13:08:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:25 --> Config Class Initialized
INFO - 2017-02-17 13:08:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:25 --> URI Class Initialized
INFO - 2017-02-17 13:08:25 --> Router Class Initialized
INFO - 2017-02-17 13:08:25 --> Output Class Initialized
INFO - 2017-02-17 13:08:25 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:25 --> Input Class Initialized
INFO - 2017-02-17 13:08:25 --> Language Class Initialized
ERROR - 2017-02-17 13:08:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:25 --> Config Class Initialized
INFO - 2017-02-17 13:08:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:25 --> URI Class Initialized
INFO - 2017-02-17 13:08:25 --> Router Class Initialized
INFO - 2017-02-17 13:08:25 --> Output Class Initialized
INFO - 2017-02-17 13:08:25 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:25 --> Input Class Initialized
INFO - 2017-02-17 13:08:25 --> Language Class Initialized
ERROR - 2017-02-17 13:08:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:25 --> Config Class Initialized
INFO - 2017-02-17 13:08:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:25 --> URI Class Initialized
INFO - 2017-02-17 13:08:25 --> Router Class Initialized
INFO - 2017-02-17 13:08:25 --> Output Class Initialized
INFO - 2017-02-17 13:08:25 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:25 --> Input Class Initialized
INFO - 2017-02-17 13:08:25 --> Language Class Initialized
ERROR - 2017-02-17 13:08:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:25 --> Config Class Initialized
INFO - 2017-02-17 13:08:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:25 --> URI Class Initialized
INFO - 2017-02-17 13:08:25 --> Router Class Initialized
INFO - 2017-02-17 13:08:25 --> Output Class Initialized
INFO - 2017-02-17 13:08:25 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:25 --> Input Class Initialized
INFO - 2017-02-17 13:08:25 --> Language Class Initialized
ERROR - 2017-02-17 13:08:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:25 --> Config Class Initialized
INFO - 2017-02-17 13:08:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:25 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:25 --> URI Class Initialized
INFO - 2017-02-17 13:08:25 --> Router Class Initialized
INFO - 2017-02-17 13:08:25 --> Output Class Initialized
INFO - 2017-02-17 13:08:25 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:25 --> Input Class Initialized
INFO - 2017-02-17 13:08:25 --> Language Class Initialized
ERROR - 2017-02-17 13:08:25 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:26 --> Config Class Initialized
INFO - 2017-02-17 13:08:26 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:26 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:26 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:26 --> URI Class Initialized
INFO - 2017-02-17 13:08:26 --> Router Class Initialized
INFO - 2017-02-17 13:08:26 --> Output Class Initialized
INFO - 2017-02-17 13:08:26 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:26 --> Input Class Initialized
INFO - 2017-02-17 13:08:26 --> Language Class Initialized
ERROR - 2017-02-17 13:08:26 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:36 --> Config Class Initialized
INFO - 2017-02-17 13:08:36 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:36 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:36 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:36 --> URI Class Initialized
DEBUG - 2017-02-17 13:08:36 --> No URI present. Default controller set.
INFO - 2017-02-17 13:08:36 --> Router Class Initialized
INFO - 2017-02-17 13:08:36 --> Output Class Initialized
INFO - 2017-02-17 13:08:36 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:36 --> Input Class Initialized
INFO - 2017-02-17 13:08:36 --> Language Class Initialized
INFO - 2017-02-17 13:08:36 --> Language Class Initialized
INFO - 2017-02-17 13:08:36 --> Config Class Initialized
INFO - 2017-02-17 13:08:36 --> Loader Class Initialized
INFO - 2017-02-17 13:08:36 --> Helper loaded: form_helper
INFO - 2017-02-17 13:08:36 --> Helper loaded: url_helper
INFO - 2017-02-17 13:08:36 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:08:36 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:08:36 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:08:36 --> Template Class Initialized
INFO - 2017-02-17 13:08:36 --> Controller Class Initialized
INFO - 2017-02-17 13:08:36 --> Form Validation Class Initialized
INFO - 2017-02-17 13:08:36 --> Model Class Initialized
DEBUG - 2017-02-17 13:08:36 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:08:36 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:08:36 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:08:36 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:08:36 --> Final output sent to browser
DEBUG - 2017-02-17 13:08:36 --> Total execution time: 0.0660
INFO - 2017-02-17 13:08:36 --> Config Class Initialized
INFO - 2017-02-17 13:08:36 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:36 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:36 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:36 --> URI Class Initialized
INFO - 2017-02-17 13:08:36 --> Router Class Initialized
INFO - 2017-02-17 13:08:36 --> Output Class Initialized
INFO - 2017-02-17 13:08:36 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:36 --> Input Class Initialized
INFO - 2017-02-17 13:08:36 --> Language Class Initialized
ERROR - 2017-02-17 13:08:36 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:36 --> Config Class Initialized
INFO - 2017-02-17 13:08:36 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:36 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:36 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:36 --> URI Class Initialized
INFO - 2017-02-17 13:08:36 --> Router Class Initialized
INFO - 2017-02-17 13:08:36 --> Output Class Initialized
INFO - 2017-02-17 13:08:36 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:36 --> Input Class Initialized
INFO - 2017-02-17 13:08:36 --> Language Class Initialized
ERROR - 2017-02-17 13:08:36 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:36 --> Config Class Initialized
INFO - 2017-02-17 13:08:36 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:36 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:36 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:36 --> URI Class Initialized
INFO - 2017-02-17 13:08:36 --> Router Class Initialized
INFO - 2017-02-17 13:08:36 --> Output Class Initialized
INFO - 2017-02-17 13:08:36 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:36 --> Input Class Initialized
INFO - 2017-02-17 13:08:36 --> Language Class Initialized
ERROR - 2017-02-17 13:08:36 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:36 --> Config Class Initialized
INFO - 2017-02-17 13:08:36 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:36 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:36 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:36 --> URI Class Initialized
INFO - 2017-02-17 13:08:36 --> Router Class Initialized
INFO - 2017-02-17 13:08:36 --> Output Class Initialized
INFO - 2017-02-17 13:08:36 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:36 --> Input Class Initialized
INFO - 2017-02-17 13:08:36 --> Language Class Initialized
ERROR - 2017-02-17 13:08:36 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:38 --> Config Class Initialized
INFO - 2017-02-17 13:08:38 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:38 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:38 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:38 --> URI Class Initialized
INFO - 2017-02-17 13:08:38 --> Router Class Initialized
INFO - 2017-02-17 13:08:38 --> Output Class Initialized
INFO - 2017-02-17 13:08:38 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:38 --> Input Class Initialized
INFO - 2017-02-17 13:08:38 --> Language Class Initialized
ERROR - 2017-02-17 13:08:38 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:38 --> Config Class Initialized
INFO - 2017-02-17 13:08:38 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:38 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:38 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:38 --> URI Class Initialized
INFO - 2017-02-17 13:08:38 --> Router Class Initialized
INFO - 2017-02-17 13:08:38 --> Output Class Initialized
INFO - 2017-02-17 13:08:38 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:38 --> Input Class Initialized
INFO - 2017-02-17 13:08:38 --> Language Class Initialized
ERROR - 2017-02-17 13:08:38 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:38 --> Config Class Initialized
INFO - 2017-02-17 13:08:38 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:38 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:38 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:38 --> URI Class Initialized
INFO - 2017-02-17 13:08:38 --> Router Class Initialized
INFO - 2017-02-17 13:08:38 --> Output Class Initialized
INFO - 2017-02-17 13:08:38 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:38 --> Input Class Initialized
INFO - 2017-02-17 13:08:38 --> Language Class Initialized
ERROR - 2017-02-17 13:08:38 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:38 --> Config Class Initialized
INFO - 2017-02-17 13:08:38 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:38 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:38 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:38 --> URI Class Initialized
INFO - 2017-02-17 13:08:38 --> Router Class Initialized
INFO - 2017-02-17 13:08:38 --> Output Class Initialized
INFO - 2017-02-17 13:08:38 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:38 --> Input Class Initialized
INFO - 2017-02-17 13:08:38 --> Language Class Initialized
ERROR - 2017-02-17 13:08:38 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:39 --> Config Class Initialized
INFO - 2017-02-17 13:08:39 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:39 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:39 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:39 --> URI Class Initialized
INFO - 2017-02-17 13:08:39 --> Router Class Initialized
INFO - 2017-02-17 13:08:39 --> Output Class Initialized
INFO - 2017-02-17 13:08:39 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:39 --> Input Class Initialized
INFO - 2017-02-17 13:08:39 --> Language Class Initialized
ERROR - 2017-02-17 13:08:39 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:39 --> Config Class Initialized
INFO - 2017-02-17 13:08:39 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:39 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:39 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:39 --> URI Class Initialized
INFO - 2017-02-17 13:08:39 --> Router Class Initialized
INFO - 2017-02-17 13:08:39 --> Output Class Initialized
INFO - 2017-02-17 13:08:39 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:39 --> Input Class Initialized
INFO - 2017-02-17 13:08:39 --> Language Class Initialized
ERROR - 2017-02-17 13:08:39 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:39 --> Config Class Initialized
INFO - 2017-02-17 13:08:39 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:39 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:39 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:39 --> URI Class Initialized
INFO - 2017-02-17 13:08:39 --> Router Class Initialized
INFO - 2017-02-17 13:08:39 --> Output Class Initialized
INFO - 2017-02-17 13:08:39 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:39 --> Input Class Initialized
INFO - 2017-02-17 13:08:39 --> Language Class Initialized
ERROR - 2017-02-17 13:08:39 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:39 --> Config Class Initialized
INFO - 2017-02-17 13:08:39 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:39 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:39 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:39 --> URI Class Initialized
INFO - 2017-02-17 13:08:39 --> Router Class Initialized
INFO - 2017-02-17 13:08:39 --> Output Class Initialized
INFO - 2017-02-17 13:08:39 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:39 --> Input Class Initialized
INFO - 2017-02-17 13:08:39 --> Language Class Initialized
ERROR - 2017-02-17 13:08:39 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:39 --> Config Class Initialized
INFO - 2017-02-17 13:08:39 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:39 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:39 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:39 --> URI Class Initialized
INFO - 2017-02-17 13:08:39 --> Router Class Initialized
INFO - 2017-02-17 13:08:39 --> Output Class Initialized
INFO - 2017-02-17 13:08:39 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:39 --> Input Class Initialized
INFO - 2017-02-17 13:08:39 --> Language Class Initialized
ERROR - 2017-02-17 13:08:39 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:39 --> Config Class Initialized
INFO - 2017-02-17 13:08:39 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:39 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:39 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:39 --> URI Class Initialized
INFO - 2017-02-17 13:08:39 --> Router Class Initialized
INFO - 2017-02-17 13:08:39 --> Output Class Initialized
INFO - 2017-02-17 13:08:39 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:39 --> Input Class Initialized
INFO - 2017-02-17 13:08:39 --> Language Class Initialized
ERROR - 2017-02-17 13:08:39 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:39 --> Config Class Initialized
INFO - 2017-02-17 13:08:39 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:39 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:39 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:39 --> URI Class Initialized
INFO - 2017-02-17 13:08:39 --> Router Class Initialized
INFO - 2017-02-17 13:08:39 --> Output Class Initialized
INFO - 2017-02-17 13:08:39 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:39 --> Input Class Initialized
INFO - 2017-02-17 13:08:39 --> Language Class Initialized
ERROR - 2017-02-17 13:08:39 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:39 --> Config Class Initialized
INFO - 2017-02-17 13:08:39 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:39 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:39 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:39 --> URI Class Initialized
INFO - 2017-02-17 13:08:39 --> Router Class Initialized
INFO - 2017-02-17 13:08:39 --> Output Class Initialized
INFO - 2017-02-17 13:08:39 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:39 --> Input Class Initialized
INFO - 2017-02-17 13:08:39 --> Language Class Initialized
ERROR - 2017-02-17 13:08:39 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:39 --> Config Class Initialized
INFO - 2017-02-17 13:08:39 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:39 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:39 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:39 --> URI Class Initialized
INFO - 2017-02-17 13:08:39 --> Router Class Initialized
INFO - 2017-02-17 13:08:39 --> Output Class Initialized
INFO - 2017-02-17 13:08:39 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:39 --> Input Class Initialized
INFO - 2017-02-17 13:08:39 --> Language Class Initialized
ERROR - 2017-02-17 13:08:39 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:40 --> Config Class Initialized
INFO - 2017-02-17 13:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:40 --> URI Class Initialized
INFO - 2017-02-17 13:08:40 --> Router Class Initialized
INFO - 2017-02-17 13:08:40 --> Output Class Initialized
INFO - 2017-02-17 13:08:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:40 --> Input Class Initialized
INFO - 2017-02-17 13:08:40 --> Language Class Initialized
ERROR - 2017-02-17 13:08:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:40 --> Config Class Initialized
INFO - 2017-02-17 13:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:40 --> URI Class Initialized
INFO - 2017-02-17 13:08:40 --> Router Class Initialized
INFO - 2017-02-17 13:08:40 --> Output Class Initialized
INFO - 2017-02-17 13:08:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:40 --> Input Class Initialized
INFO - 2017-02-17 13:08:40 --> Language Class Initialized
ERROR - 2017-02-17 13:08:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:40 --> Config Class Initialized
INFO - 2017-02-17 13:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:40 --> URI Class Initialized
INFO - 2017-02-17 13:08:40 --> Router Class Initialized
INFO - 2017-02-17 13:08:40 --> Output Class Initialized
INFO - 2017-02-17 13:08:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:40 --> Input Class Initialized
INFO - 2017-02-17 13:08:40 --> Language Class Initialized
ERROR - 2017-02-17 13:08:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:40 --> Config Class Initialized
INFO - 2017-02-17 13:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:40 --> URI Class Initialized
INFO - 2017-02-17 13:08:40 --> Router Class Initialized
INFO - 2017-02-17 13:08:40 --> Output Class Initialized
INFO - 2017-02-17 13:08:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:40 --> Input Class Initialized
INFO - 2017-02-17 13:08:40 --> Language Class Initialized
ERROR - 2017-02-17 13:08:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:40 --> Config Class Initialized
INFO - 2017-02-17 13:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:40 --> URI Class Initialized
INFO - 2017-02-17 13:08:40 --> Router Class Initialized
INFO - 2017-02-17 13:08:40 --> Output Class Initialized
INFO - 2017-02-17 13:08:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:40 --> Input Class Initialized
INFO - 2017-02-17 13:08:40 --> Language Class Initialized
ERROR - 2017-02-17 13:08:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:40 --> Config Class Initialized
INFO - 2017-02-17 13:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:40 --> URI Class Initialized
INFO - 2017-02-17 13:08:40 --> Router Class Initialized
INFO - 2017-02-17 13:08:40 --> Output Class Initialized
INFO - 2017-02-17 13:08:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:40 --> Input Class Initialized
INFO - 2017-02-17 13:08:40 --> Language Class Initialized
ERROR - 2017-02-17 13:08:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:40 --> Config Class Initialized
INFO - 2017-02-17 13:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:40 --> URI Class Initialized
INFO - 2017-02-17 13:08:40 --> Router Class Initialized
INFO - 2017-02-17 13:08:40 --> Output Class Initialized
INFO - 2017-02-17 13:08:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:40 --> Input Class Initialized
INFO - 2017-02-17 13:08:40 --> Language Class Initialized
ERROR - 2017-02-17 13:08:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:40 --> Config Class Initialized
INFO - 2017-02-17 13:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:40 --> URI Class Initialized
INFO - 2017-02-17 13:08:40 --> Router Class Initialized
INFO - 2017-02-17 13:08:40 --> Output Class Initialized
INFO - 2017-02-17 13:08:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:40 --> Input Class Initialized
INFO - 2017-02-17 13:08:40 --> Language Class Initialized
ERROR - 2017-02-17 13:08:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:40 --> Config Class Initialized
INFO - 2017-02-17 13:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:40 --> URI Class Initialized
INFO - 2017-02-17 13:08:40 --> Router Class Initialized
INFO - 2017-02-17 13:08:40 --> Output Class Initialized
INFO - 2017-02-17 13:08:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:40 --> Input Class Initialized
INFO - 2017-02-17 13:08:40 --> Language Class Initialized
ERROR - 2017-02-17 13:08:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:40 --> Config Class Initialized
INFO - 2017-02-17 13:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:40 --> URI Class Initialized
INFO - 2017-02-17 13:08:40 --> Router Class Initialized
INFO - 2017-02-17 13:08:40 --> Output Class Initialized
INFO - 2017-02-17 13:08:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:40 --> Input Class Initialized
INFO - 2017-02-17 13:08:40 --> Language Class Initialized
ERROR - 2017-02-17 13:08:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:40 --> Config Class Initialized
INFO - 2017-02-17 13:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:40 --> URI Class Initialized
INFO - 2017-02-17 13:08:40 --> Router Class Initialized
INFO - 2017-02-17 13:08:40 --> Output Class Initialized
INFO - 2017-02-17 13:08:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:40 --> Input Class Initialized
INFO - 2017-02-17 13:08:40 --> Language Class Initialized
ERROR - 2017-02-17 13:08:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:40 --> Config Class Initialized
INFO - 2017-02-17 13:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:40 --> URI Class Initialized
INFO - 2017-02-17 13:08:40 --> Router Class Initialized
INFO - 2017-02-17 13:08:40 --> Output Class Initialized
INFO - 2017-02-17 13:08:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:40 --> Input Class Initialized
INFO - 2017-02-17 13:08:40 --> Language Class Initialized
ERROR - 2017-02-17 13:08:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:40 --> Config Class Initialized
INFO - 2017-02-17 13:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:40 --> URI Class Initialized
INFO - 2017-02-17 13:08:40 --> Router Class Initialized
INFO - 2017-02-17 13:08:40 --> Output Class Initialized
INFO - 2017-02-17 13:08:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:40 --> Input Class Initialized
INFO - 2017-02-17 13:08:40 --> Language Class Initialized
ERROR - 2017-02-17 13:08:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:40 --> Config Class Initialized
INFO - 2017-02-17 13:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:40 --> URI Class Initialized
INFO - 2017-02-17 13:08:40 --> Router Class Initialized
INFO - 2017-02-17 13:08:40 --> Output Class Initialized
INFO - 2017-02-17 13:08:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:40 --> Input Class Initialized
INFO - 2017-02-17 13:08:40 --> Language Class Initialized
ERROR - 2017-02-17 13:08:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:40 --> Config Class Initialized
INFO - 2017-02-17 13:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:40 --> URI Class Initialized
INFO - 2017-02-17 13:08:40 --> Router Class Initialized
INFO - 2017-02-17 13:08:40 --> Output Class Initialized
INFO - 2017-02-17 13:08:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:40 --> Input Class Initialized
INFO - 2017-02-17 13:08:40 --> Language Class Initialized
ERROR - 2017-02-17 13:08:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:40 --> Config Class Initialized
INFO - 2017-02-17 13:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:40 --> URI Class Initialized
INFO - 2017-02-17 13:08:40 --> Router Class Initialized
INFO - 2017-02-17 13:08:40 --> Output Class Initialized
INFO - 2017-02-17 13:08:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:40 --> Input Class Initialized
INFO - 2017-02-17 13:08:40 --> Language Class Initialized
ERROR - 2017-02-17 13:08:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:40 --> Config Class Initialized
INFO - 2017-02-17 13:08:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:40 --> URI Class Initialized
INFO - 2017-02-17 13:08:40 --> Router Class Initialized
INFO - 2017-02-17 13:08:41 --> Output Class Initialized
INFO - 2017-02-17 13:08:41 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:41 --> Input Class Initialized
INFO - 2017-02-17 13:08:41 --> Language Class Initialized
ERROR - 2017-02-17 13:08:41 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:41 --> Config Class Initialized
INFO - 2017-02-17 13:08:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:41 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:41 --> URI Class Initialized
INFO - 2017-02-17 13:08:41 --> Router Class Initialized
INFO - 2017-02-17 13:08:41 --> Output Class Initialized
INFO - 2017-02-17 13:08:41 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:41 --> Input Class Initialized
INFO - 2017-02-17 13:08:41 --> Language Class Initialized
ERROR - 2017-02-17 13:08:41 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:41 --> Config Class Initialized
INFO - 2017-02-17 13:08:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:41 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:41 --> URI Class Initialized
INFO - 2017-02-17 13:08:41 --> Router Class Initialized
INFO - 2017-02-17 13:08:41 --> Output Class Initialized
INFO - 2017-02-17 13:08:41 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:41 --> Input Class Initialized
INFO - 2017-02-17 13:08:41 --> Language Class Initialized
ERROR - 2017-02-17 13:08:41 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:41 --> Config Class Initialized
INFO - 2017-02-17 13:08:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:41 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:41 --> URI Class Initialized
INFO - 2017-02-17 13:08:41 --> Router Class Initialized
INFO - 2017-02-17 13:08:41 --> Output Class Initialized
INFO - 2017-02-17 13:08:41 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:41 --> Input Class Initialized
INFO - 2017-02-17 13:08:41 --> Language Class Initialized
ERROR - 2017-02-17 13:08:41 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:41 --> Config Class Initialized
INFO - 2017-02-17 13:08:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:41 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:41 --> URI Class Initialized
INFO - 2017-02-17 13:08:41 --> Router Class Initialized
INFO - 2017-02-17 13:08:41 --> Output Class Initialized
INFO - 2017-02-17 13:08:41 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:41 --> Input Class Initialized
INFO - 2017-02-17 13:08:41 --> Language Class Initialized
ERROR - 2017-02-17 13:08:41 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:41 --> Config Class Initialized
INFO - 2017-02-17 13:08:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:41 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:41 --> URI Class Initialized
INFO - 2017-02-17 13:08:41 --> Router Class Initialized
INFO - 2017-02-17 13:08:41 --> Output Class Initialized
INFO - 2017-02-17 13:08:41 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:41 --> Input Class Initialized
INFO - 2017-02-17 13:08:41 --> Language Class Initialized
ERROR - 2017-02-17 13:08:41 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:41 --> Config Class Initialized
INFO - 2017-02-17 13:08:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:41 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:41 --> URI Class Initialized
INFO - 2017-02-17 13:08:41 --> Router Class Initialized
INFO - 2017-02-17 13:08:41 --> Output Class Initialized
INFO - 2017-02-17 13:08:41 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:41 --> Input Class Initialized
INFO - 2017-02-17 13:08:41 --> Language Class Initialized
ERROR - 2017-02-17 13:08:41 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:41 --> Config Class Initialized
INFO - 2017-02-17 13:08:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:41 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:41 --> URI Class Initialized
INFO - 2017-02-17 13:08:41 --> Router Class Initialized
INFO - 2017-02-17 13:08:41 --> Output Class Initialized
INFO - 2017-02-17 13:08:41 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:41 --> Input Class Initialized
INFO - 2017-02-17 13:08:41 --> Language Class Initialized
ERROR - 2017-02-17 13:08:41 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:08:41 --> Config Class Initialized
INFO - 2017-02-17 13:08:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:08:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:08:41 --> Utf8 Class Initialized
INFO - 2017-02-17 13:08:41 --> URI Class Initialized
INFO - 2017-02-17 13:08:41 --> Router Class Initialized
INFO - 2017-02-17 13:08:41 --> Output Class Initialized
INFO - 2017-02-17 13:08:41 --> Security Class Initialized
DEBUG - 2017-02-17 13:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:08:41 --> Input Class Initialized
INFO - 2017-02-17 13:08:41 --> Language Class Initialized
ERROR - 2017-02-17 13:08:41 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:09:40 --> Config Class Initialized
INFO - 2017-02-17 13:09:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:09:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:09:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:09:40 --> URI Class Initialized
DEBUG - 2017-02-17 13:09:40 --> No URI present. Default controller set.
INFO - 2017-02-17 13:09:40 --> Router Class Initialized
INFO - 2017-02-17 13:09:40 --> Output Class Initialized
INFO - 2017-02-17 13:09:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:09:40 --> Input Class Initialized
INFO - 2017-02-17 13:09:40 --> Language Class Initialized
INFO - 2017-02-17 13:09:40 --> Language Class Initialized
INFO - 2017-02-17 13:09:40 --> Config Class Initialized
INFO - 2017-02-17 13:09:40 --> Loader Class Initialized
INFO - 2017-02-17 13:09:40 --> Helper loaded: form_helper
INFO - 2017-02-17 13:09:40 --> Helper loaded: url_helper
INFO - 2017-02-17 13:09:40 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:09:40 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:09:40 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:09:40 --> Template Class Initialized
INFO - 2017-02-17 13:09:40 --> Controller Class Initialized
INFO - 2017-02-17 13:09:40 --> Form Validation Class Initialized
INFO - 2017-02-17 13:09:40 --> Model Class Initialized
DEBUG - 2017-02-17 13:09:40 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:09:40 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:09:40 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:09:40 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:09:40 --> Final output sent to browser
DEBUG - 2017-02-17 13:09:40 --> Total execution time: 0.0620
INFO - 2017-02-17 13:09:40 --> Config Class Initialized
INFO - 2017-02-17 13:09:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:09:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:09:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:09:40 --> URI Class Initialized
INFO - 2017-02-17 13:09:40 --> Router Class Initialized
INFO - 2017-02-17 13:09:40 --> Output Class Initialized
INFO - 2017-02-17 13:09:40 --> Config Class Initialized
INFO - 2017-02-17 13:09:40 --> Hooks Class Initialized
INFO - 2017-02-17 13:09:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:09:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:09:40 --> Utf8 Class Initialized
DEBUG - 2017-02-17 13:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:09:40 --> Input Class Initialized
INFO - 2017-02-17 13:09:40 --> URI Class Initialized
INFO - 2017-02-17 13:09:40 --> Language Class Initialized
ERROR - 2017-02-17 13:09:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:09:40 --> Router Class Initialized
INFO - 2017-02-17 13:09:40 --> Output Class Initialized
INFO - 2017-02-17 13:09:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:09:40 --> Input Class Initialized
INFO - 2017-02-17 13:09:40 --> Language Class Initialized
ERROR - 2017-02-17 13:09:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:09:40 --> Config Class Initialized
INFO - 2017-02-17 13:09:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:09:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:09:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:09:40 --> URI Class Initialized
INFO - 2017-02-17 13:09:40 --> Router Class Initialized
INFO - 2017-02-17 13:09:40 --> Output Class Initialized
INFO - 2017-02-17 13:09:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:09:40 --> Input Class Initialized
INFO - 2017-02-17 13:09:40 --> Language Class Initialized
ERROR - 2017-02-17 13:09:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:09:40 --> Config Class Initialized
INFO - 2017-02-17 13:09:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:09:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:09:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:09:40 --> URI Class Initialized
INFO - 2017-02-17 13:09:40 --> Router Class Initialized
INFO - 2017-02-17 13:09:40 --> Config Class Initialized
INFO - 2017-02-17 13:09:40 --> Hooks Class Initialized
INFO - 2017-02-17 13:09:40 --> Output Class Initialized
INFO - 2017-02-17 13:09:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:09:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:09:40 --> Utf8 Class Initialized
DEBUG - 2017-02-17 13:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:09:40 --> Input Class Initialized
INFO - 2017-02-17 13:09:40 --> URI Class Initialized
INFO - 2017-02-17 13:09:40 --> Language Class Initialized
ERROR - 2017-02-17 13:09:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:09:40 --> Router Class Initialized
INFO - 2017-02-17 13:09:40 --> Output Class Initialized
INFO - 2017-02-17 13:09:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:09:40 --> Input Class Initialized
INFO - 2017-02-17 13:09:40 --> Language Class Initialized
ERROR - 2017-02-17 13:09:40 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:09:58 --> Config Class Initialized
INFO - 2017-02-17 13:09:58 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:09:58 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:09:58 --> Utf8 Class Initialized
INFO - 2017-02-17 13:09:58 --> URI Class Initialized
INFO - 2017-02-17 13:09:58 --> Router Class Initialized
INFO - 2017-02-17 13:09:58 --> Output Class Initialized
INFO - 2017-02-17 13:09:58 --> Security Class Initialized
DEBUG - 2017-02-17 13:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:09:58 --> Input Class Initialized
INFO - 2017-02-17 13:09:58 --> Language Class Initialized
ERROR - 2017-02-17 13:09:58 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:10:33 --> Config Class Initialized
INFO - 2017-02-17 13:10:33 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:10:33 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:10:33 --> Utf8 Class Initialized
INFO - 2017-02-17 13:10:33 --> URI Class Initialized
INFO - 2017-02-17 13:10:33 --> Router Class Initialized
INFO - 2017-02-17 13:10:33 --> Output Class Initialized
INFO - 2017-02-17 13:10:33 --> Security Class Initialized
DEBUG - 2017-02-17 13:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:10:33 --> Input Class Initialized
INFO - 2017-02-17 13:10:33 --> Language Class Initialized
ERROR - 2017-02-17 13:10:33 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:11:19 --> Config Class Initialized
INFO - 2017-02-17 13:11:19 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:11:19 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:11:19 --> Utf8 Class Initialized
INFO - 2017-02-17 13:11:19 --> URI Class Initialized
DEBUG - 2017-02-17 13:11:19 --> No URI present. Default controller set.
INFO - 2017-02-17 13:11:19 --> Router Class Initialized
INFO - 2017-02-17 13:11:19 --> Output Class Initialized
INFO - 2017-02-17 13:11:19 --> Security Class Initialized
DEBUG - 2017-02-17 13:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:11:19 --> Input Class Initialized
INFO - 2017-02-17 13:11:19 --> Language Class Initialized
INFO - 2017-02-17 13:11:19 --> Language Class Initialized
INFO - 2017-02-17 13:11:19 --> Config Class Initialized
INFO - 2017-02-17 13:11:19 --> Loader Class Initialized
INFO - 2017-02-17 13:11:19 --> Helper loaded: form_helper
INFO - 2017-02-17 13:11:19 --> Helper loaded: url_helper
INFO - 2017-02-17 13:11:19 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:11:19 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:11:19 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:11:19 --> Template Class Initialized
INFO - 2017-02-17 13:11:19 --> Controller Class Initialized
INFO - 2017-02-17 13:11:19 --> Form Validation Class Initialized
INFO - 2017-02-17 13:11:19 --> Model Class Initialized
DEBUG - 2017-02-17 13:11:19 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:11:19 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:11:19 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:11:19 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:11:19 --> Final output sent to browser
DEBUG - 2017-02-17 13:11:19 --> Total execution time: 0.0620
INFO - 2017-02-17 13:11:20 --> Config Class Initialized
INFO - 2017-02-17 13:11:20 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:11:20 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:11:20 --> Utf8 Class Initialized
INFO - 2017-02-17 13:11:20 --> URI Class Initialized
INFO - 2017-02-17 13:11:20 --> Router Class Initialized
INFO - 2017-02-17 13:11:20 --> Output Class Initialized
INFO - 2017-02-17 13:11:20 --> Security Class Initialized
DEBUG - 2017-02-17 13:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:11:20 --> Input Class Initialized
INFO - 2017-02-17 13:11:20 --> Language Class Initialized
ERROR - 2017-02-17 13:11:20 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:11:20 --> Config Class Initialized
INFO - 2017-02-17 13:11:20 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:11:20 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:11:20 --> Utf8 Class Initialized
INFO - 2017-02-17 13:11:20 --> URI Class Initialized
INFO - 2017-02-17 13:11:20 --> Router Class Initialized
INFO - 2017-02-17 13:11:20 --> Output Class Initialized
INFO - 2017-02-17 13:11:20 --> Security Class Initialized
DEBUG - 2017-02-17 13:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:11:20 --> Input Class Initialized
INFO - 2017-02-17 13:11:20 --> Language Class Initialized
ERROR - 2017-02-17 13:11:20 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:11:55 --> Config Class Initialized
INFO - 2017-02-17 13:11:55 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:11:55 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:11:55 --> Utf8 Class Initialized
INFO - 2017-02-17 13:11:55 --> URI Class Initialized
DEBUG - 2017-02-17 13:11:55 --> No URI present. Default controller set.
INFO - 2017-02-17 13:11:55 --> Router Class Initialized
INFO - 2017-02-17 13:11:55 --> Output Class Initialized
INFO - 2017-02-17 13:11:55 --> Security Class Initialized
DEBUG - 2017-02-17 13:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:11:55 --> Input Class Initialized
INFO - 2017-02-17 13:11:55 --> Language Class Initialized
INFO - 2017-02-17 13:11:55 --> Language Class Initialized
INFO - 2017-02-17 13:11:55 --> Config Class Initialized
INFO - 2017-02-17 13:11:55 --> Loader Class Initialized
INFO - 2017-02-17 13:11:55 --> Helper loaded: form_helper
INFO - 2017-02-17 13:11:55 --> Helper loaded: url_helper
INFO - 2017-02-17 13:11:55 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:11:55 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:11:55 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:11:55 --> Template Class Initialized
INFO - 2017-02-17 13:11:55 --> Controller Class Initialized
INFO - 2017-02-17 13:11:55 --> Form Validation Class Initialized
INFO - 2017-02-17 13:11:55 --> Model Class Initialized
DEBUG - 2017-02-17 13:11:55 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:11:55 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:11:55 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:11:55 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:11:55 --> Final output sent to browser
DEBUG - 2017-02-17 13:11:55 --> Total execution time: 0.0729
INFO - 2017-02-17 13:11:55 --> Config Class Initialized
INFO - 2017-02-17 13:11:55 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:11:55 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:11:55 --> Utf8 Class Initialized
INFO - 2017-02-17 13:11:55 --> URI Class Initialized
INFO - 2017-02-17 13:11:55 --> Router Class Initialized
INFO - 2017-02-17 13:11:55 --> Output Class Initialized
INFO - 2017-02-17 13:11:55 --> Security Class Initialized
DEBUG - 2017-02-17 13:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:11:55 --> Input Class Initialized
INFO - 2017-02-17 13:11:55 --> Language Class Initialized
ERROR - 2017-02-17 13:11:55 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:16:37 --> Config Class Initialized
INFO - 2017-02-17 13:16:37 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:16:37 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:16:37 --> Utf8 Class Initialized
INFO - 2017-02-17 13:16:37 --> URI Class Initialized
DEBUG - 2017-02-17 13:16:37 --> No URI present. Default controller set.
INFO - 2017-02-17 13:16:37 --> Router Class Initialized
INFO - 2017-02-17 13:16:37 --> Output Class Initialized
INFO - 2017-02-17 13:16:37 --> Security Class Initialized
DEBUG - 2017-02-17 13:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:16:37 --> Input Class Initialized
INFO - 2017-02-17 13:16:37 --> Language Class Initialized
INFO - 2017-02-17 13:16:37 --> Language Class Initialized
INFO - 2017-02-17 13:16:37 --> Config Class Initialized
INFO - 2017-02-17 13:16:37 --> Loader Class Initialized
INFO - 2017-02-17 13:16:37 --> Helper loaded: form_helper
INFO - 2017-02-17 13:16:37 --> Helper loaded: url_helper
INFO - 2017-02-17 13:16:37 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:16:37 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:16:37 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:16:37 --> Template Class Initialized
INFO - 2017-02-17 13:16:37 --> Controller Class Initialized
INFO - 2017-02-17 13:16:37 --> Form Validation Class Initialized
INFO - 2017-02-17 13:16:37 --> Model Class Initialized
DEBUG - 2017-02-17 13:16:37 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:16:37 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:16:37 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:16:37 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:16:37 --> Final output sent to browser
DEBUG - 2017-02-17 13:16:37 --> Total execution time: 0.0755
INFO - 2017-02-17 13:16:37 --> Config Class Initialized
INFO - 2017-02-17 13:16:37 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:16:37 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:16:37 --> Utf8 Class Initialized
INFO - 2017-02-17 13:16:37 --> URI Class Initialized
INFO - 2017-02-17 13:16:37 --> Router Class Initialized
INFO - 2017-02-17 13:16:37 --> Output Class Initialized
INFO - 2017-02-17 13:16:37 --> Security Class Initialized
DEBUG - 2017-02-17 13:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:16:37 --> Input Class Initialized
INFO - 2017-02-17 13:16:37 --> Language Class Initialized
ERROR - 2017-02-17 13:16:37 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:16:41 --> Config Class Initialized
INFO - 2017-02-17 13:16:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:16:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:16:41 --> Utf8 Class Initialized
INFO - 2017-02-17 13:16:41 --> URI Class Initialized
DEBUG - 2017-02-17 13:16:41 --> No URI present. Default controller set.
INFO - 2017-02-17 13:16:41 --> Router Class Initialized
INFO - 2017-02-17 13:16:41 --> Output Class Initialized
INFO - 2017-02-17 13:16:41 --> Security Class Initialized
DEBUG - 2017-02-17 13:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:16:41 --> Input Class Initialized
INFO - 2017-02-17 13:16:41 --> Language Class Initialized
INFO - 2017-02-17 13:16:41 --> Language Class Initialized
INFO - 2017-02-17 13:16:41 --> Config Class Initialized
INFO - 2017-02-17 13:16:41 --> Loader Class Initialized
INFO - 2017-02-17 13:16:41 --> Helper loaded: form_helper
INFO - 2017-02-17 13:16:41 --> Helper loaded: url_helper
INFO - 2017-02-17 13:16:41 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:16:41 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:16:41 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:16:41 --> Template Class Initialized
INFO - 2017-02-17 13:16:41 --> Controller Class Initialized
INFO - 2017-02-17 13:16:41 --> Form Validation Class Initialized
INFO - 2017-02-17 13:16:41 --> Model Class Initialized
DEBUG - 2017-02-17 13:16:41 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:16:41 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:16:41 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:16:41 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:16:41 --> Final output sent to browser
DEBUG - 2017-02-17 13:16:41 --> Total execution time: 0.0578
INFO - 2017-02-17 13:16:41 --> Config Class Initialized
INFO - 2017-02-17 13:16:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:16:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:16:41 --> Utf8 Class Initialized
INFO - 2017-02-17 13:16:41 --> URI Class Initialized
INFO - 2017-02-17 13:16:41 --> Router Class Initialized
INFO - 2017-02-17 13:16:41 --> Output Class Initialized
INFO - 2017-02-17 13:16:41 --> Security Class Initialized
DEBUG - 2017-02-17 13:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:16:41 --> Input Class Initialized
INFO - 2017-02-17 13:16:41 --> Language Class Initialized
ERROR - 2017-02-17 13:16:41 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:16:52 --> Config Class Initialized
INFO - 2017-02-17 13:16:52 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:16:52 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:16:52 --> Utf8 Class Initialized
INFO - 2017-02-17 13:16:52 --> URI Class Initialized
DEBUG - 2017-02-17 13:16:52 --> No URI present. Default controller set.
INFO - 2017-02-17 13:16:52 --> Router Class Initialized
INFO - 2017-02-17 13:16:52 --> Output Class Initialized
INFO - 2017-02-17 13:16:52 --> Security Class Initialized
DEBUG - 2017-02-17 13:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:16:52 --> Input Class Initialized
INFO - 2017-02-17 13:16:52 --> Language Class Initialized
INFO - 2017-02-17 13:16:52 --> Language Class Initialized
INFO - 2017-02-17 13:16:52 --> Config Class Initialized
INFO - 2017-02-17 13:16:52 --> Loader Class Initialized
INFO - 2017-02-17 13:16:52 --> Helper loaded: form_helper
INFO - 2017-02-17 13:16:52 --> Helper loaded: url_helper
INFO - 2017-02-17 13:16:52 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:16:52 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:16:52 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:16:52 --> Template Class Initialized
INFO - 2017-02-17 13:16:52 --> Controller Class Initialized
INFO - 2017-02-17 13:16:52 --> Form Validation Class Initialized
INFO - 2017-02-17 13:16:52 --> Model Class Initialized
DEBUG - 2017-02-17 13:16:52 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:16:52 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:16:52 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:16:52 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:16:52 --> Final output sent to browser
DEBUG - 2017-02-17 13:16:52 --> Total execution time: 0.0633
INFO - 2017-02-17 13:16:52 --> Config Class Initialized
INFO - 2017-02-17 13:16:52 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:16:52 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:16:52 --> Utf8 Class Initialized
INFO - 2017-02-17 13:16:52 --> URI Class Initialized
INFO - 2017-02-17 13:16:52 --> Router Class Initialized
INFO - 2017-02-17 13:16:52 --> Output Class Initialized
INFO - 2017-02-17 13:16:52 --> Security Class Initialized
DEBUG - 2017-02-17 13:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:16:52 --> Input Class Initialized
INFO - 2017-02-17 13:16:52 --> Language Class Initialized
ERROR - 2017-02-17 13:16:52 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:17:01 --> Config Class Initialized
INFO - 2017-02-17 13:17:01 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:17:01 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:17:01 --> Utf8 Class Initialized
INFO - 2017-02-17 13:17:01 --> URI Class Initialized
DEBUG - 2017-02-17 13:17:01 --> No URI present. Default controller set.
INFO - 2017-02-17 13:17:01 --> Router Class Initialized
INFO - 2017-02-17 13:17:01 --> Output Class Initialized
INFO - 2017-02-17 13:17:01 --> Security Class Initialized
DEBUG - 2017-02-17 13:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:17:01 --> Input Class Initialized
INFO - 2017-02-17 13:17:01 --> Language Class Initialized
INFO - 2017-02-17 13:17:01 --> Language Class Initialized
INFO - 2017-02-17 13:17:01 --> Config Class Initialized
INFO - 2017-02-17 13:17:01 --> Loader Class Initialized
INFO - 2017-02-17 13:17:01 --> Helper loaded: form_helper
INFO - 2017-02-17 13:17:01 --> Helper loaded: url_helper
INFO - 2017-02-17 13:17:01 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:17:01 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:17:01 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:17:01 --> Template Class Initialized
INFO - 2017-02-17 13:17:01 --> Controller Class Initialized
INFO - 2017-02-17 13:17:01 --> Form Validation Class Initialized
INFO - 2017-02-17 13:17:01 --> Model Class Initialized
DEBUG - 2017-02-17 13:17:01 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:17:01 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:17:01 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:17:01 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:17:01 --> Final output sent to browser
DEBUG - 2017-02-17 13:17:01 --> Total execution time: 0.0598
INFO - 2017-02-17 13:17:01 --> Config Class Initialized
INFO - 2017-02-17 13:17:01 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:17:01 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:17:01 --> Utf8 Class Initialized
INFO - 2017-02-17 13:17:01 --> URI Class Initialized
INFO - 2017-02-17 13:17:01 --> Router Class Initialized
INFO - 2017-02-17 13:17:01 --> Output Class Initialized
INFO - 2017-02-17 13:17:01 --> Security Class Initialized
DEBUG - 2017-02-17 13:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:17:01 --> Input Class Initialized
INFO - 2017-02-17 13:17:01 --> Language Class Initialized
ERROR - 2017-02-17 13:17:01 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:17:02 --> Config Class Initialized
INFO - 2017-02-17 13:17:02 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:17:02 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:17:02 --> Utf8 Class Initialized
INFO - 2017-02-17 13:17:02 --> URI Class Initialized
DEBUG - 2017-02-17 13:17:02 --> No URI present. Default controller set.
INFO - 2017-02-17 13:17:02 --> Router Class Initialized
INFO - 2017-02-17 13:17:02 --> Output Class Initialized
INFO - 2017-02-17 13:17:02 --> Security Class Initialized
DEBUG - 2017-02-17 13:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:17:02 --> Input Class Initialized
INFO - 2017-02-17 13:17:02 --> Language Class Initialized
INFO - 2017-02-17 13:17:02 --> Language Class Initialized
INFO - 2017-02-17 13:17:02 --> Config Class Initialized
INFO - 2017-02-17 13:17:02 --> Loader Class Initialized
INFO - 2017-02-17 13:17:02 --> Helper loaded: form_helper
INFO - 2017-02-17 13:17:02 --> Helper loaded: url_helper
INFO - 2017-02-17 13:17:02 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:17:02 --> Database Driver Class Initialized
INFO - 2017-02-17 13:17:02 --> Config Class Initialized
INFO - 2017-02-17 13:17:02 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:17:02 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:17:02 --> Utf8 Class Initialized
INFO - 2017-02-17 13:17:02 --> Config Class Initialized
INFO - 2017-02-17 13:17:02 --> Hooks Class Initialized
INFO - 2017-02-17 13:17:02 --> URI Class Initialized
DEBUG - 2017-02-17 13:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2017-02-17 13:17:02 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:17:02 --> Utf8 Class Initialized
INFO - 2017-02-17 13:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:17:02 --> URI Class Initialized
DEBUG - 2017-02-17 13:17:02 --> No URI present. Default controller set.
INFO - 2017-02-17 13:17:02 --> Router Class Initialized
INFO - 2017-02-17 13:17:02 --> Output Class Initialized
DEBUG - 2017-02-17 13:17:02 --> No URI present. Default controller set.
INFO - 2017-02-17 13:17:02 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:17:02 --> Template Class Initialized
INFO - 2017-02-17 13:17:02 --> Router Class Initialized
INFO - 2017-02-17 13:17:02 --> Security Class Initialized
INFO - 2017-02-17 13:17:02 --> Controller Class Initialized
INFO - 2017-02-17 13:17:02 --> Output Class Initialized
INFO - 2017-02-17 13:17:02 --> Security Class Initialized
DEBUG - 2017-02-17 13:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:17:02 --> Input Class Initialized
INFO - 2017-02-17 13:17:02 --> Form Validation Class Initialized
INFO - 2017-02-17 13:17:02 --> Language Class Initialized
DEBUG - 2017-02-17 13:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:17:02 --> Input Class Initialized
INFO - 2017-02-17 13:17:02 --> Language Class Initialized
INFO - 2017-02-17 13:17:02 --> Model Class Initialized
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
INFO - 2017-02-17 13:17:02 --> Language Class Initialized
INFO - 2017-02-17 13:17:02 --> Config Class Initialized
INFO - 2017-02-17 13:17:02 --> Loader Class Initialized
INFO - 2017-02-17 13:17:02 --> Helper loaded: form_helper
INFO - 2017-02-17 13:17:02 --> Helper loaded: url_helper
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:17:02 --> Language Class Initialized
INFO - 2017-02-17 13:17:02 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:17:02 --> Config Class Initialized
INFO - 2017-02-17 13:17:02 --> Final output sent to browser
DEBUG - 2017-02-17 13:17:02 --> Total execution time: 0.1002
INFO - 2017-02-17 13:17:02 --> Loader Class Initialized
INFO - 2017-02-17 13:17:02 --> Helper loaded: form_helper
INFO - 2017-02-17 13:17:02 --> Config Class Initialized
INFO - 2017-02-17 13:17:02 --> Hooks Class Initialized
INFO - 2017-02-17 13:17:02 --> Helper loaded: url_helper
INFO - 2017-02-17 13:17:02 --> Helper loaded: utility_helper
DEBUG - 2017-02-17 13:17:02 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:17:02 --> Utf8 Class Initialized
INFO - 2017-02-17 13:17:02 --> URI Class Initialized
DEBUG - 2017-02-17 13:17:02 --> No URI present. Default controller set.
INFO - 2017-02-17 13:17:02 --> Router Class Initialized
INFO - 2017-02-17 13:17:02 --> Database Driver Class Initialized
INFO - 2017-02-17 13:17:02 --> Database Driver Class Initialized
INFO - 2017-02-17 13:17:02 --> Output Class Initialized
INFO - 2017-02-17 13:17:02 --> Security Class Initialized
DEBUG - 2017-02-17 13:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:17:02 --> Input Class Initialized
INFO - 2017-02-17 13:17:02 --> Language Class Initialized
INFO - 2017-02-17 13:17:02 --> Language Class Initialized
INFO - 2017-02-17 13:17:02 --> Config Class Initialized
INFO - 2017-02-17 13:17:02 --> Loader Class Initialized
INFO - 2017-02-17 13:17:02 --> Helper loaded: form_helper
INFO - 2017-02-17 13:17:02 --> Helper loaded: url_helper
INFO - 2017-02-17 13:17:02 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:17:02 --> Database Driver Class Initialized
INFO - 2017-02-17 13:17:02 --> Config Class Initialized
INFO - 2017-02-17 13:17:02 --> Hooks Class Initialized
INFO - 2017-02-17 13:17:02 --> Config Class Initialized
INFO - 2017-02-17 13:17:02 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:17:02 --> UTF-8 Support Enabled
DEBUG - 2017-02-17 13:17:02 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:17:02 --> Utf8 Class Initialized
INFO - 2017-02-17 13:17:02 --> Utf8 Class Initialized
INFO - 2017-02-17 13:17:02 --> URI Class Initialized
INFO - 2017-02-17 13:17:02 --> URI Class Initialized
DEBUG - 2017-02-17 13:17:02 --> No URI present. Default controller set.
INFO - 2017-02-17 13:17:02 --> Router Class Initialized
DEBUG - 2017-02-17 13:17:02 --> No URI present. Default controller set.
INFO - 2017-02-17 13:17:02 --> Router Class Initialized
INFO - 2017-02-17 13:17:02 --> Output Class Initialized
INFO - 2017-02-17 13:17:02 --> Output Class Initialized
INFO - 2017-02-17 13:17:02 --> Security Class Initialized
DEBUG - 2017-02-17 13:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:17:02 --> Security Class Initialized
INFO - 2017-02-17 13:17:02 --> Input Class Initialized
INFO - 2017-02-17 13:17:02 --> Language Class Initialized
DEBUG - 2017-02-17 13:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:17:02 --> Input Class Initialized
INFO - 2017-02-17 13:17:02 --> Language Class Initialized
INFO - 2017-02-17 13:17:02 --> Language Class Initialized
INFO - 2017-02-17 13:17:02 --> Config Class Initialized
INFO - 2017-02-17 13:17:02 --> Loader Class Initialized
INFO - 2017-02-17 13:17:02 --> Helper loaded: form_helper
INFO - 2017-02-17 13:17:02 --> Language Class Initialized
INFO - 2017-02-17 13:17:02 --> Config Class Initialized
INFO - 2017-02-17 13:17:02 --> Loader Class Initialized
INFO - 2017-02-17 13:17:02 --> Helper loaded: form_helper
INFO - 2017-02-17 13:17:02 --> Helper loaded: url_helper
INFO - 2017-02-17 13:17:02 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:17:02 --> Database Driver Class Initialized
INFO - 2017-02-17 13:17:02 --> Helper loaded: url_helper
DEBUG - 2017-02-17 13:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:17:02 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:17:02 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:17:02 --> Template Class Initialized
INFO - 2017-02-17 13:17:02 --> Controller Class Initialized
INFO - 2017-02-17 13:17:02 --> Form Validation Class Initialized
INFO - 2017-02-17 13:17:02 --> Model Class Initialized
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
INFO - 2017-02-17 13:17:02 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:17:02 --> Final output sent to browser
DEBUG - 2017-02-17 13:17:02 --> Total execution time: 0.2206
DEBUG - 2017-02-17 13:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:17:02 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:17:02 --> Template Class Initialized
INFO - 2017-02-17 13:17:02 --> Controller Class Initialized
INFO - 2017-02-17 13:17:02 --> Form Validation Class Initialized
INFO - 2017-02-17 13:17:02 --> Config Class Initialized
INFO - 2017-02-17 13:17:02 --> Hooks Class Initialized
INFO - 2017-02-17 13:17:02 --> Model Class Initialized
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:17:02 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:17:02 --> Utf8 Class Initialized
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
INFO - 2017-02-17 13:17:02 --> URI Class Initialized
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:17:02 --> Final output sent to browser
DEBUG - 2017-02-17 13:17:02 --> Total execution time: 0.2569
DEBUG - 2017-02-17 13:17:02 --> No URI present. Default controller set.
INFO - 2017-02-17 13:17:02 --> Router Class Initialized
DEBUG - 2017-02-17 13:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:17:02 --> Output Class Initialized
INFO - 2017-02-17 13:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:17:02 --> Security Class Initialized
DEBUG - 2017-02-17 13:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:17:02 --> Input Class Initialized
INFO - 2017-02-17 13:17:02 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:17:02 --> Template Class Initialized
INFO - 2017-02-17 13:17:02 --> Controller Class Initialized
INFO - 2017-02-17 13:17:02 --> Language Class Initialized
INFO - 2017-02-17 13:17:02 --> Form Validation Class Initialized
INFO - 2017-02-17 13:17:02 --> Model Class Initialized
INFO - 2017-02-17 13:17:02 --> Language Class Initialized
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
INFO - 2017-02-17 13:17:02 --> Config Class Initialized
INFO - 2017-02-17 13:17:02 --> Loader Class Initialized
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:17:02 --> Final output sent to browser
DEBUG - 2017-02-17 13:17:02 --> Total execution time: 0.2319
DEBUG - 2017-02-17 13:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:17:02 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:17:02 --> Template Class Initialized
INFO - 2017-02-17 13:17:02 --> Controller Class Initialized
INFO - 2017-02-17 13:17:02 --> Form Validation Class Initialized
INFO - 2017-02-17 13:17:02 --> Model Class Initialized
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:17:02 --> Final output sent to browser
DEBUG - 2017-02-17 13:17:02 --> Total execution time: 0.1406
DEBUG - 2017-02-17 13:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:17:02 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:17:02 --> Template Class Initialized
INFO - 2017-02-17 13:17:02 --> Controller Class Initialized
INFO - 2017-02-17 13:17:02 --> Form Validation Class Initialized
INFO - 2017-02-17 13:17:02 --> Model Class Initialized
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:17:02 --> Final output sent to browser
DEBUG - 2017-02-17 13:17:02 --> Total execution time: 0.1627
INFO - 2017-02-17 13:17:02 --> Helper loaded: form_helper
INFO - 2017-02-17 13:17:02 --> Helper loaded: url_helper
INFO - 2017-02-17 13:17:02 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:17:02 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:17:02 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:17:02 --> Template Class Initialized
INFO - 2017-02-17 13:17:02 --> Controller Class Initialized
INFO - 2017-02-17 13:17:02 --> Form Validation Class Initialized
INFO - 2017-02-17 13:17:02 --> Model Class Initialized
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:17:02 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:17:02 --> Final output sent to browser
DEBUG - 2017-02-17 13:17:02 --> Total execution time: 0.1062
INFO - 2017-02-17 13:17:02 --> Config Class Initialized
INFO - 2017-02-17 13:17:02 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:17:02 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:17:02 --> Utf8 Class Initialized
INFO - 2017-02-17 13:17:02 --> URI Class Initialized
INFO - 2017-02-17 13:17:02 --> Router Class Initialized
INFO - 2017-02-17 13:17:02 --> Output Class Initialized
INFO - 2017-02-17 13:17:02 --> Security Class Initialized
DEBUG - 2017-02-17 13:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:17:02 --> Input Class Initialized
INFO - 2017-02-17 13:17:02 --> Language Class Initialized
ERROR - 2017-02-17 13:17:02 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:17:27 --> Config Class Initialized
INFO - 2017-02-17 13:17:27 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:17:27 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:17:27 --> Utf8 Class Initialized
INFO - 2017-02-17 13:17:27 --> URI Class Initialized
DEBUG - 2017-02-17 13:17:27 --> No URI present. Default controller set.
INFO - 2017-02-17 13:17:27 --> Router Class Initialized
INFO - 2017-02-17 13:17:27 --> Output Class Initialized
INFO - 2017-02-17 13:17:27 --> Security Class Initialized
DEBUG - 2017-02-17 13:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:17:27 --> Input Class Initialized
INFO - 2017-02-17 13:17:27 --> Language Class Initialized
INFO - 2017-02-17 13:17:27 --> Language Class Initialized
INFO - 2017-02-17 13:17:27 --> Config Class Initialized
INFO - 2017-02-17 13:17:27 --> Loader Class Initialized
INFO - 2017-02-17 13:17:27 --> Helper loaded: form_helper
INFO - 2017-02-17 13:17:27 --> Helper loaded: url_helper
INFO - 2017-02-17 13:17:27 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:17:27 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:17:27 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:17:27 --> Template Class Initialized
INFO - 2017-02-17 13:17:27 --> Controller Class Initialized
INFO - 2017-02-17 13:17:27 --> Form Validation Class Initialized
INFO - 2017-02-17 13:17:27 --> Model Class Initialized
DEBUG - 2017-02-17 13:17:27 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:17:27 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:17:27 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:17:27 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:17:27 --> Final output sent to browser
DEBUG - 2017-02-17 13:17:27 --> Total execution time: 0.1789
INFO - 2017-02-17 13:17:27 --> Config Class Initialized
INFO - 2017-02-17 13:17:27 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:17:27 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:17:27 --> Utf8 Class Initialized
INFO - 2017-02-17 13:17:27 --> URI Class Initialized
INFO - 2017-02-17 13:17:27 --> Router Class Initialized
INFO - 2017-02-17 13:17:27 --> Output Class Initialized
INFO - 2017-02-17 13:17:27 --> Security Class Initialized
DEBUG - 2017-02-17 13:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:17:27 --> Input Class Initialized
INFO - 2017-02-17 13:17:27 --> Language Class Initialized
ERROR - 2017-02-17 13:17:27 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:17:40 --> Config Class Initialized
INFO - 2017-02-17 13:17:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:17:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:17:40 --> Utf8 Class Initialized
INFO - 2017-02-17 13:17:40 --> URI Class Initialized
DEBUG - 2017-02-17 13:17:40 --> No URI present. Default controller set.
INFO - 2017-02-17 13:17:40 --> Router Class Initialized
INFO - 2017-02-17 13:17:40 --> Output Class Initialized
INFO - 2017-02-17 13:17:40 --> Security Class Initialized
DEBUG - 2017-02-17 13:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:17:40 --> Input Class Initialized
INFO - 2017-02-17 13:17:40 --> Language Class Initialized
INFO - 2017-02-17 13:17:40 --> Language Class Initialized
INFO - 2017-02-17 13:17:40 --> Config Class Initialized
INFO - 2017-02-17 13:17:40 --> Loader Class Initialized
INFO - 2017-02-17 13:17:40 --> Helper loaded: form_helper
INFO - 2017-02-17 13:17:40 --> Helper loaded: url_helper
INFO - 2017-02-17 13:17:40 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:17:40 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:17:40 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:17:40 --> Template Class Initialized
INFO - 2017-02-17 13:17:40 --> Controller Class Initialized
INFO - 2017-02-17 13:17:40 --> Form Validation Class Initialized
INFO - 2017-02-17 13:17:40 --> Model Class Initialized
DEBUG - 2017-02-17 13:17:40 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:17:40 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:17:40 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:17:40 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:17:40 --> Final output sent to browser
DEBUG - 2017-02-17 13:17:40 --> Total execution time: 0.0415
INFO - 2017-02-17 13:17:41 --> Config Class Initialized
INFO - 2017-02-17 13:17:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:17:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:17:41 --> Utf8 Class Initialized
INFO - 2017-02-17 13:17:41 --> URI Class Initialized
INFO - 2017-02-17 13:17:41 --> Router Class Initialized
INFO - 2017-02-17 13:17:41 --> Output Class Initialized
INFO - 2017-02-17 13:17:41 --> Security Class Initialized
DEBUG - 2017-02-17 13:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:17:41 --> Input Class Initialized
INFO - 2017-02-17 13:17:41 --> Language Class Initialized
ERROR - 2017-02-17 13:17:41 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:18:57 --> Config Class Initialized
INFO - 2017-02-17 13:18:57 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:18:57 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:18:57 --> Utf8 Class Initialized
INFO - 2017-02-17 13:18:57 --> URI Class Initialized
DEBUG - 2017-02-17 13:18:57 --> No URI present. Default controller set.
INFO - 2017-02-17 13:18:57 --> Router Class Initialized
INFO - 2017-02-17 13:18:57 --> Output Class Initialized
INFO - 2017-02-17 13:18:57 --> Security Class Initialized
DEBUG - 2017-02-17 13:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:18:57 --> Input Class Initialized
INFO - 2017-02-17 13:18:57 --> Language Class Initialized
INFO - 2017-02-17 13:18:57 --> Language Class Initialized
INFO - 2017-02-17 13:18:57 --> Config Class Initialized
INFO - 2017-02-17 13:18:57 --> Loader Class Initialized
INFO - 2017-02-17 13:18:57 --> Helper loaded: form_helper
INFO - 2017-02-17 13:18:57 --> Helper loaded: url_helper
INFO - 2017-02-17 13:18:57 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:18:57 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:18:57 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:18:57 --> Template Class Initialized
INFO - 2017-02-17 13:18:57 --> Controller Class Initialized
INFO - 2017-02-17 13:18:57 --> Form Validation Class Initialized
INFO - 2017-02-17 13:18:57 --> Model Class Initialized
DEBUG - 2017-02-17 13:18:57 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:18:57 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:18:57 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:18:57 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:18:57 --> Final output sent to browser
DEBUG - 2017-02-17 13:18:57 --> Total execution time: 0.0830
INFO - 2017-02-17 13:18:57 --> Config Class Initialized
INFO - 2017-02-17 13:18:57 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:18:57 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:18:57 --> Utf8 Class Initialized
INFO - 2017-02-17 13:18:57 --> URI Class Initialized
INFO - 2017-02-17 13:18:57 --> Router Class Initialized
INFO - 2017-02-17 13:18:57 --> Output Class Initialized
INFO - 2017-02-17 13:18:57 --> Security Class Initialized
DEBUG - 2017-02-17 13:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:18:57 --> Input Class Initialized
INFO - 2017-02-17 13:18:57 --> Language Class Initialized
ERROR - 2017-02-17 13:18:57 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:19:13 --> Config Class Initialized
INFO - 2017-02-17 13:19:13 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:19:13 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:19:13 --> Utf8 Class Initialized
INFO - 2017-02-17 13:19:13 --> URI Class Initialized
DEBUG - 2017-02-17 13:19:13 --> No URI present. Default controller set.
INFO - 2017-02-17 13:19:13 --> Router Class Initialized
INFO - 2017-02-17 13:19:13 --> Output Class Initialized
INFO - 2017-02-17 13:19:13 --> Security Class Initialized
DEBUG - 2017-02-17 13:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:19:13 --> Input Class Initialized
INFO - 2017-02-17 13:19:13 --> Language Class Initialized
INFO - 2017-02-17 13:19:13 --> Language Class Initialized
INFO - 2017-02-17 13:19:13 --> Config Class Initialized
INFO - 2017-02-17 13:19:13 --> Loader Class Initialized
INFO - 2017-02-17 13:19:13 --> Helper loaded: form_helper
INFO - 2017-02-17 13:19:13 --> Helper loaded: url_helper
INFO - 2017-02-17 13:19:13 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:19:14 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:19:14 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:19:14 --> Template Class Initialized
INFO - 2017-02-17 13:19:14 --> Controller Class Initialized
INFO - 2017-02-17 13:19:14 --> Form Validation Class Initialized
INFO - 2017-02-17 13:19:14 --> Model Class Initialized
DEBUG - 2017-02-17 13:19:14 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:19:14 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:19:14 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:19:14 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:19:14 --> Final output sent to browser
DEBUG - 2017-02-17 13:19:14 --> Total execution time: 0.0846
INFO - 2017-02-17 13:19:14 --> Config Class Initialized
INFO - 2017-02-17 13:19:14 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:19:14 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:19:14 --> Utf8 Class Initialized
INFO - 2017-02-17 13:19:14 --> URI Class Initialized
INFO - 2017-02-17 13:19:14 --> Router Class Initialized
INFO - 2017-02-17 13:19:14 --> Output Class Initialized
INFO - 2017-02-17 13:19:14 --> Security Class Initialized
DEBUG - 2017-02-17 13:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:19:14 --> Input Class Initialized
INFO - 2017-02-17 13:19:14 --> Language Class Initialized
ERROR - 2017-02-17 13:19:14 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:20:01 --> Config Class Initialized
INFO - 2017-02-17 13:20:01 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:20:01 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:20:01 --> Utf8 Class Initialized
INFO - 2017-02-17 13:20:01 --> URI Class Initialized
INFO - 2017-02-17 13:20:01 --> Router Class Initialized
INFO - 2017-02-17 13:20:01 --> Output Class Initialized
INFO - 2017-02-17 13:20:01 --> Security Class Initialized
DEBUG - 2017-02-17 13:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:20:01 --> Input Class Initialized
INFO - 2017-02-17 13:20:01 --> Language Class Initialized
INFO - 2017-02-17 13:20:01 --> Language Class Initialized
INFO - 2017-02-17 13:20:01 --> Config Class Initialized
INFO - 2017-02-17 13:20:01 --> Loader Class Initialized
INFO - 2017-02-17 13:20:01 --> Helper loaded: form_helper
INFO - 2017-02-17 13:20:01 --> Helper loaded: url_helper
INFO - 2017-02-17 13:20:01 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:20:01 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:20:01 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:20:01 --> Template Class Initialized
INFO - 2017-02-17 13:20:01 --> Controller Class Initialized
DEBUG - 2017-02-17 13:20:01 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:20:01 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:20:01 --> Model Class Initialized
INFO - 2017-02-17 13:20:01 --> Form Validation Class Initialized
ERROR - 2017-02-17 13:20:01 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\razor\application\modules\backend\views\login.php 38
ERROR - 2017-02-17 13:20:01 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\razor\application\modules\backend\views\login.php 42
DEBUG - 2017-02-17 13:20:01 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
ERROR - 2017-02-17 13:20:01 --> Severity: Notice --> Undefined index: sidebar C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\backend.php 35
ERROR - 2017-02-17 13:20:01 --> Severity: Notice --> Undefined index: header C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\backend.php 36
ERROR - 2017-02-17 13:20:01 --> Severity: Notice --> Undefined index: footer C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\backend.php 38
DEBUG - 2017-02-17 13:20:01 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 13:20:01 --> Final output sent to browser
DEBUG - 2017-02-17 13:20:01 --> Total execution time: 0.3046
INFO - 2017-02-17 13:20:45 --> Config Class Initialized
INFO - 2017-02-17 13:20:45 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:20:45 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:20:45 --> Utf8 Class Initialized
INFO - 2017-02-17 13:20:45 --> URI Class Initialized
INFO - 2017-02-17 13:20:45 --> Router Class Initialized
INFO - 2017-02-17 13:20:45 --> Output Class Initialized
INFO - 2017-02-17 13:20:45 --> Security Class Initialized
DEBUG - 2017-02-17 13:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:20:45 --> Input Class Initialized
INFO - 2017-02-17 13:20:45 --> Language Class Initialized
INFO - 2017-02-17 13:20:45 --> Language Class Initialized
INFO - 2017-02-17 13:20:45 --> Config Class Initialized
INFO - 2017-02-17 13:20:45 --> Loader Class Initialized
INFO - 2017-02-17 13:20:45 --> Helper loaded: form_helper
INFO - 2017-02-17 13:20:45 --> Helper loaded: url_helper
INFO - 2017-02-17 13:20:45 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:20:45 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:20:45 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:20:45 --> Template Class Initialized
INFO - 2017-02-17 13:20:45 --> Controller Class Initialized
DEBUG - 2017-02-17 13:20:45 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:20:45 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:20:45 --> Model Class Initialized
INFO - 2017-02-17 13:20:45 --> Form Validation Class Initialized
ERROR - 2017-02-17 13:20:45 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\razor\application\modules\backend\views\login.php 38
ERROR - 2017-02-17 13:20:45 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\razor\application\modules\backend\views\login.php 42
DEBUG - 2017-02-17 13:20:45 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
ERROR - 2017-02-17 13:20:45 --> Severity: Notice --> Undefined index: header C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\backend.php 36
ERROR - 2017-02-17 13:20:45 --> Severity: Notice --> Undefined index: footer C:\xampp\htdocs\razor\application\themes\default_theme\views\layouts\backend.php 38
DEBUG - 2017-02-17 13:20:45 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 13:20:45 --> Final output sent to browser
DEBUG - 2017-02-17 13:20:45 --> Total execution time: 0.0582
INFO - 2017-02-17 13:21:05 --> Config Class Initialized
INFO - 2017-02-17 13:21:05 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:21:05 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:21:05 --> Utf8 Class Initialized
INFO - 2017-02-17 13:21:05 --> URI Class Initialized
INFO - 2017-02-17 13:21:05 --> Router Class Initialized
INFO - 2017-02-17 13:21:05 --> Output Class Initialized
INFO - 2017-02-17 13:21:05 --> Security Class Initialized
DEBUG - 2017-02-17 13:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:21:05 --> Input Class Initialized
INFO - 2017-02-17 13:21:05 --> Language Class Initialized
INFO - 2017-02-17 13:21:05 --> Language Class Initialized
INFO - 2017-02-17 13:21:05 --> Config Class Initialized
INFO - 2017-02-17 13:21:05 --> Loader Class Initialized
INFO - 2017-02-17 13:21:05 --> Helper loaded: form_helper
INFO - 2017-02-17 13:21:05 --> Helper loaded: url_helper
INFO - 2017-02-17 13:21:05 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:21:05 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:21:05 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:21:05 --> Template Class Initialized
INFO - 2017-02-17 13:21:05 --> Controller Class Initialized
DEBUG - 2017-02-17 13:21:05 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:21:05 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:21:05 --> Model Class Initialized
INFO - 2017-02-17 13:21:05 --> Form Validation Class Initialized
ERROR - 2017-02-17 13:21:05 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\razor\application\modules\backend\views\login.php 38
ERROR - 2017-02-17 13:21:05 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\razor\application\modules\backend\views\login.php 42
DEBUG - 2017-02-17 13:21:05 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 13:21:05 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 13:21:05 --> Final output sent to browser
DEBUG - 2017-02-17 13:21:05 --> Total execution time: 0.0541
INFO - 2017-02-17 13:21:44 --> Config Class Initialized
INFO - 2017-02-17 13:21:44 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:21:44 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:21:44 --> Utf8 Class Initialized
INFO - 2017-02-17 13:21:44 --> URI Class Initialized
INFO - 2017-02-17 13:21:44 --> Router Class Initialized
INFO - 2017-02-17 13:21:44 --> Output Class Initialized
INFO - 2017-02-17 13:21:44 --> Security Class Initialized
DEBUG - 2017-02-17 13:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:21:44 --> Input Class Initialized
INFO - 2017-02-17 13:21:44 --> Language Class Initialized
INFO - 2017-02-17 13:21:44 --> Language Class Initialized
INFO - 2017-02-17 13:21:44 --> Config Class Initialized
INFO - 2017-02-17 13:21:44 --> Loader Class Initialized
INFO - 2017-02-17 13:21:44 --> Helper loaded: form_helper
INFO - 2017-02-17 13:21:44 --> Helper loaded: url_helper
INFO - 2017-02-17 13:21:44 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:21:44 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:21:44 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:21:44 --> Template Class Initialized
INFO - 2017-02-17 13:21:44 --> Controller Class Initialized
DEBUG - 2017-02-17 13:21:44 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:21:44 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:21:44 --> Model Class Initialized
INFO - 2017-02-17 13:21:44 --> Form Validation Class Initialized
DEBUG - 2017-02-17 13:21:44 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 13:21:44 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 13:21:44 --> Final output sent to browser
DEBUG - 2017-02-17 13:21:44 --> Total execution time: 0.0698
INFO - 2017-02-17 13:22:34 --> Config Class Initialized
INFO - 2017-02-17 13:22:34 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:22:34 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:22:34 --> Utf8 Class Initialized
INFO - 2017-02-17 13:22:34 --> URI Class Initialized
INFO - 2017-02-17 13:22:34 --> Router Class Initialized
INFO - 2017-02-17 13:22:34 --> Output Class Initialized
INFO - 2017-02-17 13:22:34 --> Security Class Initialized
DEBUG - 2017-02-17 13:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:22:34 --> Input Class Initialized
INFO - 2017-02-17 13:22:34 --> Language Class Initialized
INFO - 2017-02-17 13:22:34 --> Language Class Initialized
INFO - 2017-02-17 13:22:34 --> Config Class Initialized
INFO - 2017-02-17 13:22:34 --> Loader Class Initialized
INFO - 2017-02-17 13:22:34 --> Helper loaded: form_helper
INFO - 2017-02-17 13:22:34 --> Helper loaded: url_helper
INFO - 2017-02-17 13:22:34 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:22:34 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:22:34 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:22:34 --> Template Class Initialized
INFO - 2017-02-17 13:22:34 --> Controller Class Initialized
DEBUG - 2017-02-17 13:22:34 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:22:34 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:22:34 --> Model Class Initialized
INFO - 2017-02-17 13:22:34 --> Form Validation Class Initialized
DEBUG - 2017-02-17 13:22:34 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:22:34 --> Final output sent to browser
DEBUG - 2017-02-17 13:22:34 --> Total execution time: 0.0786
INFO - 2017-02-17 13:24:18 --> Config Class Initialized
INFO - 2017-02-17 13:24:18 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:24:18 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:24:18 --> Utf8 Class Initialized
INFO - 2017-02-17 13:24:18 --> URI Class Initialized
DEBUG - 2017-02-17 13:24:18 --> No URI present. Default controller set.
INFO - 2017-02-17 13:24:18 --> Router Class Initialized
INFO - 2017-02-17 13:24:18 --> Output Class Initialized
INFO - 2017-02-17 13:24:18 --> Security Class Initialized
DEBUG - 2017-02-17 13:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:24:18 --> Input Class Initialized
INFO - 2017-02-17 13:24:18 --> Language Class Initialized
INFO - 2017-02-17 13:24:18 --> Language Class Initialized
INFO - 2017-02-17 13:24:18 --> Config Class Initialized
INFO - 2017-02-17 13:24:18 --> Loader Class Initialized
INFO - 2017-02-17 13:24:18 --> Helper loaded: form_helper
INFO - 2017-02-17 13:24:18 --> Helper loaded: url_helper
INFO - 2017-02-17 13:24:18 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:24:18 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:24:18 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:24:18 --> Template Class Initialized
INFO - 2017-02-17 13:24:18 --> Controller Class Initialized
INFO - 2017-02-17 13:24:18 --> Form Validation Class Initialized
INFO - 2017-02-17 13:24:18 --> Model Class Initialized
DEBUG - 2017-02-17 13:24:18 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:24:18 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:24:18 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:24:18 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:24:18 --> Final output sent to browser
DEBUG - 2017-02-17 13:24:18 --> Total execution time: 0.1241
INFO - 2017-02-17 13:24:19 --> Config Class Initialized
INFO - 2017-02-17 13:24:19 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:24:19 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:24:19 --> Utf8 Class Initialized
INFO - 2017-02-17 13:24:19 --> URI Class Initialized
INFO - 2017-02-17 13:24:19 --> Router Class Initialized
INFO - 2017-02-17 13:24:19 --> Output Class Initialized
INFO - 2017-02-17 13:24:19 --> Security Class Initialized
DEBUG - 2017-02-17 13:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:24:19 --> Input Class Initialized
INFO - 2017-02-17 13:24:19 --> Language Class Initialized
ERROR - 2017-02-17 13:24:19 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:24:35 --> Config Class Initialized
INFO - 2017-02-17 13:24:35 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:24:35 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:24:35 --> Utf8 Class Initialized
INFO - 2017-02-17 13:24:35 --> URI Class Initialized
DEBUG - 2017-02-17 13:24:35 --> No URI present. Default controller set.
INFO - 2017-02-17 13:24:35 --> Router Class Initialized
INFO - 2017-02-17 13:24:35 --> Output Class Initialized
INFO - 2017-02-17 13:24:35 --> Security Class Initialized
DEBUG - 2017-02-17 13:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:24:35 --> Input Class Initialized
INFO - 2017-02-17 13:24:35 --> Language Class Initialized
INFO - 2017-02-17 13:24:35 --> Language Class Initialized
INFO - 2017-02-17 13:24:35 --> Config Class Initialized
INFO - 2017-02-17 13:24:35 --> Loader Class Initialized
INFO - 2017-02-17 13:24:35 --> Helper loaded: form_helper
INFO - 2017-02-17 13:24:35 --> Helper loaded: url_helper
INFO - 2017-02-17 13:24:35 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:24:35 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:24:35 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:24:35 --> Template Class Initialized
INFO - 2017-02-17 13:24:35 --> Controller Class Initialized
INFO - 2017-02-17 13:24:35 --> Form Validation Class Initialized
INFO - 2017-02-17 13:24:35 --> Model Class Initialized
DEBUG - 2017-02-17 13:24:35 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:24:35 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:24:35 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:24:35 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:24:35 --> Final output sent to browser
DEBUG - 2017-02-17 13:24:35 --> Total execution time: 0.0587
INFO - 2017-02-17 13:24:35 --> Config Class Initialized
INFO - 2017-02-17 13:24:35 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:24:35 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:24:35 --> Utf8 Class Initialized
INFO - 2017-02-17 13:24:35 --> URI Class Initialized
INFO - 2017-02-17 13:24:35 --> Router Class Initialized
INFO - 2017-02-17 13:24:35 --> Output Class Initialized
INFO - 2017-02-17 13:24:35 --> Security Class Initialized
DEBUG - 2017-02-17 13:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:24:35 --> Input Class Initialized
INFO - 2017-02-17 13:24:35 --> Language Class Initialized
ERROR - 2017-02-17 13:24:35 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:26:17 --> Config Class Initialized
INFO - 2017-02-17 13:26:17 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:26:17 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:26:17 --> Utf8 Class Initialized
INFO - 2017-02-17 13:26:17 --> URI Class Initialized
DEBUG - 2017-02-17 13:26:17 --> No URI present. Default controller set.
INFO - 2017-02-17 13:26:17 --> Router Class Initialized
INFO - 2017-02-17 13:26:17 --> Output Class Initialized
INFO - 2017-02-17 13:26:17 --> Security Class Initialized
DEBUG - 2017-02-17 13:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:26:17 --> Input Class Initialized
INFO - 2017-02-17 13:26:17 --> Language Class Initialized
INFO - 2017-02-17 13:26:17 --> Language Class Initialized
INFO - 2017-02-17 13:26:17 --> Config Class Initialized
INFO - 2017-02-17 13:26:17 --> Loader Class Initialized
INFO - 2017-02-17 13:26:17 --> Helper loaded: form_helper
INFO - 2017-02-17 13:26:17 --> Helper loaded: url_helper
INFO - 2017-02-17 13:26:17 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:26:17 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:26:17 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:26:17 --> Template Class Initialized
INFO - 2017-02-17 13:26:17 --> Controller Class Initialized
INFO - 2017-02-17 13:26:17 --> Form Validation Class Initialized
INFO - 2017-02-17 13:26:17 --> Model Class Initialized
DEBUG - 2017-02-17 13:26:17 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:26:17 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:26:17 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:26:17 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:26:17 --> Final output sent to browser
DEBUG - 2017-02-17 13:26:17 --> Total execution time: 0.0543
INFO - 2017-02-17 13:26:17 --> Config Class Initialized
INFO - 2017-02-17 13:26:17 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:26:17 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:26:17 --> Utf8 Class Initialized
INFO - 2017-02-17 13:26:17 --> URI Class Initialized
INFO - 2017-02-17 13:26:17 --> Router Class Initialized
INFO - 2017-02-17 13:26:17 --> Output Class Initialized
INFO - 2017-02-17 13:26:17 --> Security Class Initialized
DEBUG - 2017-02-17 13:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:26:17 --> Input Class Initialized
INFO - 2017-02-17 13:26:17 --> Language Class Initialized
ERROR - 2017-02-17 13:26:17 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:29:58 --> Config Class Initialized
INFO - 2017-02-17 13:29:58 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:29:58 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:29:58 --> Utf8 Class Initialized
INFO - 2017-02-17 13:29:58 --> URI Class Initialized
INFO - 2017-02-17 13:29:58 --> Router Class Initialized
INFO - 2017-02-17 13:29:58 --> Output Class Initialized
INFO - 2017-02-17 13:29:58 --> Security Class Initialized
DEBUG - 2017-02-17 13:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:29:58 --> Input Class Initialized
INFO - 2017-02-17 13:29:58 --> Language Class Initialized
INFO - 2017-02-17 13:29:58 --> Language Class Initialized
INFO - 2017-02-17 13:29:58 --> Config Class Initialized
INFO - 2017-02-17 13:29:58 --> Loader Class Initialized
INFO - 2017-02-17 13:29:58 --> Helper loaded: form_helper
INFO - 2017-02-17 13:29:58 --> Helper loaded: url_helper
INFO - 2017-02-17 13:29:58 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:29:58 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:29:58 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:29:58 --> Template Class Initialized
INFO - 2017-02-17 13:29:58 --> Controller Class Initialized
INFO - 2017-02-17 13:29:58 --> Form Validation Class Initialized
INFO - 2017-02-17 13:29:58 --> Model Class Initialized
ERROR - 2017-02-17 13:29:58 --> Severity: Notice --> Undefined property: Pages::$global_setting C:\xampp\htdocs\razor\application\modules\frontend\controllers\Pages.php 35
DEBUG - 2017-02-17 13:29:58 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:29:58 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:29:58 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/contact_us.php
INFO - 2017-02-17 13:30:09 --> Config Class Initialized
INFO - 2017-02-17 13:30:09 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:30:09 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:30:09 --> Utf8 Class Initialized
INFO - 2017-02-17 13:30:09 --> URI Class Initialized
INFO - 2017-02-17 13:30:09 --> Router Class Initialized
INFO - 2017-02-17 13:30:09 --> Output Class Initialized
INFO - 2017-02-17 13:30:09 --> Security Class Initialized
DEBUG - 2017-02-17 13:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:30:09 --> Input Class Initialized
INFO - 2017-02-17 13:30:09 --> Language Class Initialized
INFO - 2017-02-17 13:30:09 --> Language Class Initialized
INFO - 2017-02-17 13:30:09 --> Config Class Initialized
INFO - 2017-02-17 13:30:09 --> Loader Class Initialized
INFO - 2017-02-17 13:30:09 --> Helper loaded: form_helper
INFO - 2017-02-17 13:30:09 --> Helper loaded: url_helper
INFO - 2017-02-17 13:30:09 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:30:09 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:30:09 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:30:09 --> Template Class Initialized
INFO - 2017-02-17 13:30:09 --> Controller Class Initialized
INFO - 2017-02-17 13:30:09 --> Form Validation Class Initialized
INFO - 2017-02-17 13:30:09 --> Model Class Initialized
DEBUG - 2017-02-17 13:30:09 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:30:09 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:30:09 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/contact_us.php
INFO - 2017-02-17 13:30:18 --> Config Class Initialized
INFO - 2017-02-17 13:30:18 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:30:18 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:30:18 --> Utf8 Class Initialized
INFO - 2017-02-17 13:30:18 --> URI Class Initialized
INFO - 2017-02-17 13:30:18 --> Router Class Initialized
INFO - 2017-02-17 13:30:18 --> Output Class Initialized
INFO - 2017-02-17 13:30:18 --> Security Class Initialized
DEBUG - 2017-02-17 13:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:30:18 --> Input Class Initialized
INFO - 2017-02-17 13:30:18 --> Language Class Initialized
INFO - 2017-02-17 13:30:18 --> Language Class Initialized
INFO - 2017-02-17 13:30:18 --> Config Class Initialized
INFO - 2017-02-17 13:30:18 --> Loader Class Initialized
INFO - 2017-02-17 13:30:18 --> Helper loaded: form_helper
INFO - 2017-02-17 13:30:18 --> Helper loaded: url_helper
INFO - 2017-02-17 13:30:18 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:30:18 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:30:18 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:30:18 --> Template Class Initialized
INFO - 2017-02-17 13:30:18 --> Controller Class Initialized
INFO - 2017-02-17 13:30:18 --> Form Validation Class Initialized
INFO - 2017-02-17 13:30:18 --> Model Class Initialized
DEBUG - 2017-02-17 13:30:18 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:30:18 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:30:18 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-17 13:30:18 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:30:18 --> Final output sent to browser
DEBUG - 2017-02-17 13:30:18 --> Total execution time: 0.0868
INFO - 2017-02-17 13:30:18 --> Config Class Initialized
INFO - 2017-02-17 13:30:18 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:30:18 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:30:18 --> Utf8 Class Initialized
INFO - 2017-02-17 13:30:18 --> URI Class Initialized
INFO - 2017-02-17 13:30:18 --> Config Class Initialized
INFO - 2017-02-17 13:30:18 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:30:18 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:30:18 --> Utf8 Class Initialized
INFO - 2017-02-17 13:30:18 --> URI Class Initialized
INFO - 2017-02-17 13:30:18 --> Router Class Initialized
INFO - 2017-02-17 13:30:18 --> Output Class Initialized
INFO - 2017-02-17 13:30:18 --> Security Class Initialized
DEBUG - 2017-02-17 13:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:30:18 --> Input Class Initialized
INFO - 2017-02-17 13:30:18 --> Language Class Initialized
ERROR - 2017-02-17 13:30:18 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:30:18 --> Router Class Initialized
INFO - 2017-02-17 13:30:18 --> Output Class Initialized
INFO - 2017-02-17 13:30:18 --> Security Class Initialized
DEBUG - 2017-02-17 13:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:30:18 --> Input Class Initialized
INFO - 2017-02-17 13:30:18 --> Language Class Initialized
ERROR - 2017-02-17 13:30:18 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:30:18 --> Config Class Initialized
INFO - 2017-02-17 13:30:18 --> Config Class Initialized
INFO - 2017-02-17 13:30:18 --> Hooks Class Initialized
INFO - 2017-02-17 13:30:18 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:30:18 --> UTF-8 Support Enabled
DEBUG - 2017-02-17 13:30:18 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:30:18 --> Utf8 Class Initialized
INFO - 2017-02-17 13:30:18 --> Utf8 Class Initialized
INFO - 2017-02-17 13:30:18 --> URI Class Initialized
INFO - 2017-02-17 13:30:18 --> URI Class Initialized
INFO - 2017-02-17 13:30:18 --> Router Class Initialized
INFO - 2017-02-17 13:30:18 --> Router Class Initialized
INFO - 2017-02-17 13:30:18 --> Output Class Initialized
INFO - 2017-02-17 13:30:18 --> Output Class Initialized
INFO - 2017-02-17 13:30:18 --> Security Class Initialized
INFO - 2017-02-17 13:30:18 --> Security Class Initialized
DEBUG - 2017-02-17 13:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-17 13:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:30:18 --> Input Class Initialized
INFO - 2017-02-17 13:30:18 --> Input Class Initialized
INFO - 2017-02-17 13:30:18 --> Language Class Initialized
INFO - 2017-02-17 13:30:18 --> Language Class Initialized
ERROR - 2017-02-17 13:30:18 --> 404 Page Not Found: /index
ERROR - 2017-02-17 13:30:18 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:30:18 --> Config Class Initialized
INFO - 2017-02-17 13:30:18 --> Hooks Class Initialized
INFO - 2017-02-17 13:30:18 --> Config Class Initialized
INFO - 2017-02-17 13:30:18 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:30:18 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:30:18 --> Utf8 Class Initialized
DEBUG - 2017-02-17 13:30:18 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:30:18 --> URI Class Initialized
INFO - 2017-02-17 13:30:18 --> Utf8 Class Initialized
INFO - 2017-02-17 13:30:18 --> URI Class Initialized
INFO - 2017-02-17 13:30:18 --> Router Class Initialized
INFO - 2017-02-17 13:30:18 --> Router Class Initialized
INFO - 2017-02-17 13:30:18 --> Output Class Initialized
INFO - 2017-02-17 13:30:18 --> Output Class Initialized
INFO - 2017-02-17 13:30:18 --> Security Class Initialized
INFO - 2017-02-17 13:30:18 --> Security Class Initialized
DEBUG - 2017-02-17 13:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:30:18 --> Input Class Initialized
INFO - 2017-02-17 13:30:18 --> Language Class Initialized
DEBUG - 2017-02-17 13:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:30:18 --> Input Class Initialized
ERROR - 2017-02-17 13:30:18 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:30:18 --> Language Class Initialized
ERROR - 2017-02-17 13:30:18 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:30:18 --> Config Class Initialized
INFO - 2017-02-17 13:30:18 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:30:18 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:30:18 --> Utf8 Class Initialized
INFO - 2017-02-17 13:30:18 --> URI Class Initialized
INFO - 2017-02-17 13:30:18 --> Router Class Initialized
INFO - 2017-02-17 13:30:18 --> Output Class Initialized
INFO - 2017-02-17 13:30:18 --> Security Class Initialized
DEBUG - 2017-02-17 13:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:30:18 --> Input Class Initialized
INFO - 2017-02-17 13:30:18 --> Language Class Initialized
ERROR - 2017-02-17 13:30:18 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:30:18 --> Config Class Initialized
INFO - 2017-02-17 13:30:18 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:30:18 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:30:18 --> Utf8 Class Initialized
INFO - 2017-02-17 13:30:18 --> URI Class Initialized
INFO - 2017-02-17 13:30:18 --> Router Class Initialized
INFO - 2017-02-17 13:30:18 --> Output Class Initialized
INFO - 2017-02-17 13:30:18 --> Security Class Initialized
DEBUG - 2017-02-17 13:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:30:18 --> Input Class Initialized
INFO - 2017-02-17 13:30:18 --> Language Class Initialized
ERROR - 2017-02-17 13:30:18 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:31:16 --> Config Class Initialized
INFO - 2017-02-17 13:31:16 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:31:16 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:31:16 --> Utf8 Class Initialized
INFO - 2017-02-17 13:31:16 --> URI Class Initialized
INFO - 2017-02-17 13:31:16 --> Router Class Initialized
INFO - 2017-02-17 13:31:16 --> Output Class Initialized
INFO - 2017-02-17 13:31:16 --> Security Class Initialized
DEBUG - 2017-02-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:31:16 --> Input Class Initialized
INFO - 2017-02-17 13:31:16 --> Language Class Initialized
INFO - 2017-02-17 13:31:16 --> Language Class Initialized
INFO - 2017-02-17 13:31:16 --> Config Class Initialized
INFO - 2017-02-17 13:31:16 --> Loader Class Initialized
INFO - 2017-02-17 13:31:16 --> Helper loaded: form_helper
INFO - 2017-02-17 13:31:16 --> Helper loaded: url_helper
INFO - 2017-02-17 13:31:16 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:31:16 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:31:16 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:31:16 --> Template Class Initialized
INFO - 2017-02-17 13:31:16 --> Controller Class Initialized
INFO - 2017-02-17 13:31:16 --> Form Validation Class Initialized
INFO - 2017-02-17 13:31:16 --> Model Class Initialized
DEBUG - 2017-02-17 13:31:16 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:31:16 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:31:16 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-17 13:31:16 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:31:16 --> Final output sent to browser
DEBUG - 2017-02-17 13:31:16 --> Total execution time: 0.0700
INFO - 2017-02-17 13:31:16 --> Config Class Initialized
INFO - 2017-02-17 13:31:16 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:31:16 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:31:16 --> Utf8 Class Initialized
INFO - 2017-02-17 13:31:16 --> URI Class Initialized
INFO - 2017-02-17 13:31:16 --> Router Class Initialized
INFO - 2017-02-17 13:31:16 --> Output Class Initialized
INFO - 2017-02-17 13:31:16 --> Security Class Initialized
DEBUG - 2017-02-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:31:16 --> Input Class Initialized
INFO - 2017-02-17 13:31:16 --> Language Class Initialized
ERROR - 2017-02-17 13:31:16 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:31:16 --> Config Class Initialized
INFO - 2017-02-17 13:31:16 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:31:16 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:31:16 --> Utf8 Class Initialized
INFO - 2017-02-17 13:31:16 --> URI Class Initialized
INFO - 2017-02-17 13:31:16 --> Router Class Initialized
INFO - 2017-02-17 13:31:16 --> Output Class Initialized
INFO - 2017-02-17 13:31:16 --> Security Class Initialized
DEBUG - 2017-02-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:31:16 --> Input Class Initialized
INFO - 2017-02-17 13:31:16 --> Language Class Initialized
ERROR - 2017-02-17 13:31:16 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:31:16 --> Config Class Initialized
INFO - 2017-02-17 13:31:16 --> Hooks Class Initialized
INFO - 2017-02-17 13:31:16 --> Config Class Initialized
INFO - 2017-02-17 13:31:16 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:31:16 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:31:16 --> Utf8 Class Initialized
DEBUG - 2017-02-17 13:31:16 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:31:16 --> URI Class Initialized
INFO - 2017-02-17 13:31:16 --> Utf8 Class Initialized
INFO - 2017-02-17 13:31:16 --> URI Class Initialized
INFO - 2017-02-17 13:31:16 --> Router Class Initialized
INFO - 2017-02-17 13:31:16 --> Router Class Initialized
INFO - 2017-02-17 13:31:16 --> Config Class Initialized
INFO - 2017-02-17 13:31:16 --> Hooks Class Initialized
INFO - 2017-02-17 13:31:16 --> Output Class Initialized
INFO - 2017-02-17 13:31:16 --> Output Class Initialized
DEBUG - 2017-02-17 13:31:16 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:31:16 --> Security Class Initialized
INFO - 2017-02-17 13:31:16 --> Utf8 Class Initialized
INFO - 2017-02-17 13:31:16 --> URI Class Initialized
DEBUG - 2017-02-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:31:16 --> Security Class Initialized
INFO - 2017-02-17 13:31:16 --> Input Class Initialized
INFO - 2017-02-17 13:31:16 --> Config Class Initialized
INFO - 2017-02-17 13:31:16 --> Hooks Class Initialized
INFO - 2017-02-17 13:31:16 --> Language Class Initialized
DEBUG - 2017-02-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:31:16 --> Input Class Initialized
INFO - 2017-02-17 13:31:16 --> Router Class Initialized
INFO - 2017-02-17 13:31:16 --> Language Class Initialized
ERROR - 2017-02-17 13:31:16 --> 404 Page Not Found: /index
ERROR - 2017-02-17 13:31:16 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:31:16 --> Output Class Initialized
INFO - 2017-02-17 13:31:16 --> Security Class Initialized
DEBUG - 2017-02-17 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2017-02-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:31:16 --> Utf8 Class Initialized
INFO - 2017-02-17 13:31:16 --> Input Class Initialized
INFO - 2017-02-17 13:31:16 --> URI Class Initialized
INFO - 2017-02-17 13:31:16 --> Language Class Initialized
ERROR - 2017-02-17 13:31:16 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:31:16 --> Router Class Initialized
INFO - 2017-02-17 13:31:16 --> Output Class Initialized
INFO - 2017-02-17 13:31:16 --> Security Class Initialized
INFO - 2017-02-17 13:31:16 --> Config Class Initialized
INFO - 2017-02-17 13:31:16 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:31:16 --> Input Class Initialized
INFO - 2017-02-17 13:31:16 --> Language Class Initialized
ERROR - 2017-02-17 13:31:16 --> 404 Page Not Found: /index
DEBUG - 2017-02-17 13:31:16 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:31:16 --> Utf8 Class Initialized
INFO - 2017-02-17 13:31:16 --> URI Class Initialized
INFO - 2017-02-17 13:31:16 --> Router Class Initialized
INFO - 2017-02-17 13:31:16 --> Output Class Initialized
INFO - 2017-02-17 13:31:16 --> Security Class Initialized
DEBUG - 2017-02-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:31:16 --> Input Class Initialized
INFO - 2017-02-17 13:31:16 --> Language Class Initialized
ERROR - 2017-02-17 13:31:16 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:31:16 --> Config Class Initialized
INFO - 2017-02-17 13:31:16 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:31:16 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:31:16 --> Utf8 Class Initialized
INFO - 2017-02-17 13:31:16 --> URI Class Initialized
INFO - 2017-02-17 13:31:16 --> Router Class Initialized
INFO - 2017-02-17 13:31:16 --> Output Class Initialized
INFO - 2017-02-17 13:31:16 --> Security Class Initialized
DEBUG - 2017-02-17 13:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:31:16 --> Input Class Initialized
INFO - 2017-02-17 13:31:16 --> Language Class Initialized
ERROR - 2017-02-17 13:31:16 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:31:29 --> Config Class Initialized
INFO - 2017-02-17 13:31:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:31:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:31:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:31:29 --> URI Class Initialized
INFO - 2017-02-17 13:31:29 --> Router Class Initialized
INFO - 2017-02-17 13:31:29 --> Output Class Initialized
INFO - 2017-02-17 13:31:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:31:29 --> Input Class Initialized
INFO - 2017-02-17 13:31:29 --> Language Class Initialized
INFO - 2017-02-17 13:31:29 --> Language Class Initialized
INFO - 2017-02-17 13:31:29 --> Config Class Initialized
INFO - 2017-02-17 13:31:29 --> Loader Class Initialized
INFO - 2017-02-17 13:31:29 --> Helper loaded: form_helper
INFO - 2017-02-17 13:31:29 --> Helper loaded: url_helper
INFO - 2017-02-17 13:31:29 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:31:29 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:31:29 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:31:29 --> Template Class Initialized
INFO - 2017-02-17 13:31:29 --> Controller Class Initialized
INFO - 2017-02-17 13:31:29 --> Form Validation Class Initialized
INFO - 2017-02-17 13:31:29 --> Model Class Initialized
DEBUG - 2017-02-17 13:31:29 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:31:29 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:31:29 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-17 13:31:29 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:31:29 --> Final output sent to browser
DEBUG - 2017-02-17 13:31:29 --> Total execution time: 0.0696
INFO - 2017-02-17 13:31:29 --> Config Class Initialized
INFO - 2017-02-17 13:31:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:31:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:31:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:31:30 --> Config Class Initialized
INFO - 2017-02-17 13:31:30 --> Config Class Initialized
INFO - 2017-02-17 13:31:30 --> Hooks Class Initialized
INFO - 2017-02-17 13:31:30 --> Config Class Initialized
INFO - 2017-02-17 13:31:30 --> Hooks Class Initialized
INFO - 2017-02-17 13:31:30 --> Config Class Initialized
INFO - 2017-02-17 13:31:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:31:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:31:30 --> Utf8 Class Initialized
DEBUG - 2017-02-17 13:31:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:31:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:31:30 --> Config Class Initialized
DEBUG - 2017-02-17 13:31:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:31:30 --> URI Class Initialized
INFO - 2017-02-17 13:31:30 --> Hooks Class Initialized
INFO - 2017-02-17 13:31:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:31:30 --> URI Class Initialized
INFO - 2017-02-17 13:31:30 --> URI Class Initialized
INFO - 2017-02-17 13:31:30 --> Router Class Initialized
DEBUG - 2017-02-17 13:31:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:31:30 --> Router Class Initialized
INFO - 2017-02-17 13:31:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:31:30 --> Router Class Initialized
INFO - 2017-02-17 13:31:30 --> URI Class Initialized
INFO - 2017-02-17 13:31:30 --> Output Class Initialized
INFO - 2017-02-17 13:31:30 --> Output Class Initialized
INFO - 2017-02-17 13:31:30 --> Output Class Initialized
INFO - 2017-02-17 13:31:30 --> Security Class Initialized
INFO - 2017-02-17 13:31:30 --> Security Class Initialized
INFO - 2017-02-17 13:31:30 --> Security Class Initialized
INFO - 2017-02-17 13:31:30 --> Router Class Initialized
DEBUG - 2017-02-17 13:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-17 13:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-17 13:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:31:30 --> Input Class Initialized
INFO - 2017-02-17 13:31:30 --> Input Class Initialized
INFO - 2017-02-17 13:31:30 --> Input Class Initialized
INFO - 2017-02-17 13:31:30 --> URI Class Initialized
INFO - 2017-02-17 13:31:30 --> Output Class Initialized
INFO - 2017-02-17 13:31:30 --> Language Class Initialized
INFO - 2017-02-17 13:31:30 --> Language Class Initialized
INFO - 2017-02-17 13:31:30 --> Hooks Class Initialized
ERROR - 2017-02-17 13:31:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:31:30 --> Security Class Initialized
ERROR - 2017-02-17 13:31:30 --> 404 Page Not Found: /index
DEBUG - 2017-02-17 13:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:31:30 --> Input Class Initialized
DEBUG - 2017-02-17 13:31:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:31:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:31:30 --> Language Class Initialized
INFO - 2017-02-17 13:31:30 --> Router Class Initialized
INFO - 2017-02-17 13:31:30 --> URI Class Initialized
ERROR - 2017-02-17 13:31:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:31:30 --> Output Class Initialized
INFO - 2017-02-17 13:31:30 --> Language Class Initialized
ERROR - 2017-02-17 13:31:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:31:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:31:30 --> Router Class Initialized
INFO - 2017-02-17 13:31:30 --> Input Class Initialized
INFO - 2017-02-17 13:31:30 --> Language Class Initialized
ERROR - 2017-02-17 13:31:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:31:30 --> Output Class Initialized
INFO - 2017-02-17 13:31:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:31:30 --> Input Class Initialized
INFO - 2017-02-17 13:31:30 --> Language Class Initialized
ERROR - 2017-02-17 13:31:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:31:30 --> Config Class Initialized
INFO - 2017-02-17 13:31:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:31:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:31:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:31:30 --> URI Class Initialized
INFO - 2017-02-17 13:31:30 --> Router Class Initialized
INFO - 2017-02-17 13:31:30 --> Output Class Initialized
INFO - 2017-02-17 13:31:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:31:30 --> Input Class Initialized
INFO - 2017-02-17 13:31:30 --> Language Class Initialized
ERROR - 2017-02-17 13:31:30 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:32:02 --> Config Class Initialized
INFO - 2017-02-17 13:32:02 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:32:02 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:32:02 --> Utf8 Class Initialized
INFO - 2017-02-17 13:32:02 --> URI Class Initialized
INFO - 2017-02-17 13:32:02 --> Router Class Initialized
INFO - 2017-02-17 13:32:02 --> Output Class Initialized
INFO - 2017-02-17 13:32:02 --> Security Class Initialized
DEBUG - 2017-02-17 13:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:32:02 --> Input Class Initialized
INFO - 2017-02-17 13:32:02 --> Language Class Initialized
INFO - 2017-02-17 13:32:02 --> Language Class Initialized
INFO - 2017-02-17 13:32:02 --> Config Class Initialized
INFO - 2017-02-17 13:32:02 --> Loader Class Initialized
INFO - 2017-02-17 13:32:02 --> Helper loaded: form_helper
INFO - 2017-02-17 13:32:02 --> Helper loaded: url_helper
INFO - 2017-02-17 13:32:02 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:32:02 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:32:02 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:32:02 --> Template Class Initialized
INFO - 2017-02-17 13:32:02 --> Controller Class Initialized
INFO - 2017-02-17 13:32:02 --> Form Validation Class Initialized
INFO - 2017-02-17 13:32:02 --> Model Class Initialized
DEBUG - 2017-02-17 13:32:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:32:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:32:02 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-17 13:32:02 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:32:02 --> Final output sent to browser
DEBUG - 2017-02-17 13:32:02 --> Total execution time: 0.0516
INFO - 2017-02-17 13:32:03 --> Config Class Initialized
INFO - 2017-02-17 13:32:03 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:32:03 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:32:03 --> Utf8 Class Initialized
INFO - 2017-02-17 13:32:03 --> URI Class Initialized
INFO - 2017-02-17 13:32:03 --> Router Class Initialized
INFO - 2017-02-17 13:32:03 --> Output Class Initialized
INFO - 2017-02-17 13:32:03 --> Security Class Initialized
DEBUG - 2017-02-17 13:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:32:03 --> Input Class Initialized
INFO - 2017-02-17 13:32:03 --> Language Class Initialized
ERROR - 2017-02-17 13:32:03 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:32:03 --> Config Class Initialized
INFO - 2017-02-17 13:32:03 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:32:03 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:32:03 --> Utf8 Class Initialized
INFO - 2017-02-17 13:32:03 --> URI Class Initialized
INFO - 2017-02-17 13:32:03 --> Router Class Initialized
INFO - 2017-02-17 13:32:03 --> Output Class Initialized
INFO - 2017-02-17 13:32:03 --> Config Class Initialized
INFO - 2017-02-17 13:32:03 --> Hooks Class Initialized
INFO - 2017-02-17 13:32:03 --> Security Class Initialized
DEBUG - 2017-02-17 13:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:32:03 --> Input Class Initialized
INFO - 2017-02-17 13:32:03 --> Language Class Initialized
DEBUG - 2017-02-17 13:32:03 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:32:03 --> Utf8 Class Initialized
ERROR - 2017-02-17 13:32:03 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:32:03 --> URI Class Initialized
INFO - 2017-02-17 13:32:03 --> Router Class Initialized
INFO - 2017-02-17 13:32:03 --> Output Class Initialized
INFO - 2017-02-17 13:32:03 --> Security Class Initialized
DEBUG - 2017-02-17 13:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:32:03 --> Input Class Initialized
INFO - 2017-02-17 13:32:03 --> Language Class Initialized
ERROR - 2017-02-17 13:32:03 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:32:03 --> Config Class Initialized
INFO - 2017-02-17 13:32:03 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:32:03 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:32:03 --> Utf8 Class Initialized
INFO - 2017-02-17 13:32:03 --> URI Class Initialized
INFO - 2017-02-17 13:32:03 --> Router Class Initialized
INFO - 2017-02-17 13:32:03 --> Output Class Initialized
INFO - 2017-02-17 13:32:03 --> Security Class Initialized
DEBUG - 2017-02-17 13:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:32:03 --> Input Class Initialized
INFO - 2017-02-17 13:32:03 --> Language Class Initialized
ERROR - 2017-02-17 13:32:03 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:32:21 --> Config Class Initialized
INFO - 2017-02-17 13:32:21 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:32:21 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:32:21 --> Utf8 Class Initialized
INFO - 2017-02-17 13:32:21 --> URI Class Initialized
INFO - 2017-02-17 13:32:21 --> Router Class Initialized
INFO - 2017-02-17 13:32:21 --> Output Class Initialized
INFO - 2017-02-17 13:32:21 --> Security Class Initialized
DEBUG - 2017-02-17 13:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:32:21 --> Input Class Initialized
INFO - 2017-02-17 13:32:21 --> Language Class Initialized
INFO - 2017-02-17 13:32:21 --> Language Class Initialized
INFO - 2017-02-17 13:32:21 --> Config Class Initialized
INFO - 2017-02-17 13:32:21 --> Loader Class Initialized
INFO - 2017-02-17 13:32:21 --> Helper loaded: form_helper
INFO - 2017-02-17 13:32:21 --> Helper loaded: url_helper
INFO - 2017-02-17 13:32:21 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:32:21 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:32:21 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:32:21 --> Template Class Initialized
INFO - 2017-02-17 13:32:21 --> Controller Class Initialized
INFO - 2017-02-17 13:32:21 --> Form Validation Class Initialized
INFO - 2017-02-17 13:32:21 --> Model Class Initialized
DEBUG - 2017-02-17 13:32:21 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:32:21 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:32:21 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-17 13:32:21 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:32:21 --> Final output sent to browser
DEBUG - 2017-02-17 13:32:21 --> Total execution time: 0.0585
INFO - 2017-02-17 13:32:21 --> Config Class Initialized
INFO - 2017-02-17 13:32:21 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:32:21 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:32:21 --> Utf8 Class Initialized
INFO - 2017-02-17 13:32:21 --> URI Class Initialized
INFO - 2017-02-17 13:32:21 --> Router Class Initialized
INFO - 2017-02-17 13:32:21 --> Output Class Initialized
INFO - 2017-02-17 13:32:21 --> Security Class Initialized
DEBUG - 2017-02-17 13:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:32:21 --> Input Class Initialized
INFO - 2017-02-17 13:32:21 --> Config Class Initialized
INFO - 2017-02-17 13:32:21 --> Hooks Class Initialized
INFO - 2017-02-17 13:32:21 --> Config Class Initialized
INFO - 2017-02-17 13:32:21 --> Hooks Class Initialized
INFO - 2017-02-17 13:32:21 --> Language Class Initialized
ERROR - 2017-02-17 13:32:21 --> 404 Page Not Found: /index
DEBUG - 2017-02-17 13:32:21 --> UTF-8 Support Enabled
DEBUG - 2017-02-17 13:32:21 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:32:21 --> Utf8 Class Initialized
INFO - 2017-02-17 13:32:21 --> Utf8 Class Initialized
INFO - 2017-02-17 13:32:21 --> URI Class Initialized
INFO - 2017-02-17 13:32:21 --> URI Class Initialized
INFO - 2017-02-17 13:32:21 --> Config Class Initialized
INFO - 2017-02-17 13:32:21 --> Router Class Initialized
INFO - 2017-02-17 13:32:21 --> Hooks Class Initialized
INFO - 2017-02-17 13:32:21 --> Router Class Initialized
INFO - 2017-02-17 13:32:21 --> Output Class Initialized
INFO - 2017-02-17 13:32:21 --> Output Class Initialized
INFO - 2017-02-17 13:32:21 --> Security Class Initialized
DEBUG - 2017-02-17 13:32:21 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:32:21 --> Security Class Initialized
INFO - 2017-02-17 13:32:21 --> Utf8 Class Initialized
DEBUG - 2017-02-17 13:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:32:21 --> Input Class Initialized
DEBUG - 2017-02-17 13:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:32:21 --> Input Class Initialized
INFO - 2017-02-17 13:32:21 --> Language Class Initialized
INFO - 2017-02-17 13:32:21 --> URI Class Initialized
INFO - 2017-02-17 13:32:21 --> Language Class Initialized
ERROR - 2017-02-17 13:32:21 --> 404 Page Not Found: /index
ERROR - 2017-02-17 13:32:21 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:32:21 --> Router Class Initialized
INFO - 2017-02-17 13:32:21 --> Output Class Initialized
INFO - 2017-02-17 13:32:21 --> Security Class Initialized
DEBUG - 2017-02-17 13:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:32:21 --> Input Class Initialized
INFO - 2017-02-17 13:32:21 --> Language Class Initialized
ERROR - 2017-02-17 13:32:21 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:32:29 --> Config Class Initialized
INFO - 2017-02-17 13:32:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:32:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:32:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:32:29 --> URI Class Initialized
INFO - 2017-02-17 13:32:29 --> Router Class Initialized
INFO - 2017-02-17 13:32:29 --> Output Class Initialized
INFO - 2017-02-17 13:32:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:32:29 --> Input Class Initialized
INFO - 2017-02-17 13:32:29 --> Language Class Initialized
ERROR - 2017-02-17 13:32:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:33:12 --> Config Class Initialized
INFO - 2017-02-17 13:33:12 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:33:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:33:12 --> Utf8 Class Initialized
INFO - 2017-02-17 13:33:12 --> URI Class Initialized
INFO - 2017-02-17 13:33:12 --> Router Class Initialized
INFO - 2017-02-17 13:33:12 --> Output Class Initialized
INFO - 2017-02-17 13:33:12 --> Security Class Initialized
DEBUG - 2017-02-17 13:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:33:12 --> Input Class Initialized
INFO - 2017-02-17 13:33:12 --> Language Class Initialized
INFO - 2017-02-17 13:33:12 --> Language Class Initialized
INFO - 2017-02-17 13:33:12 --> Config Class Initialized
INFO - 2017-02-17 13:33:12 --> Loader Class Initialized
INFO - 2017-02-17 13:33:12 --> Helper loaded: form_helper
INFO - 2017-02-17 13:33:12 --> Helper loaded: url_helper
INFO - 2017-02-17 13:33:12 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:33:12 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:33:12 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:33:12 --> Template Class Initialized
INFO - 2017-02-17 13:33:12 --> Controller Class Initialized
INFO - 2017-02-17 13:33:12 --> Form Validation Class Initialized
INFO - 2017-02-17 13:33:12 --> Model Class Initialized
DEBUG - 2017-02-17 13:33:12 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:33:12 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:33:12 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-17 13:33:12 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:33:12 --> Final output sent to browser
DEBUG - 2017-02-17 13:33:12 --> Total execution time: 0.0750
INFO - 2017-02-17 13:33:12 --> Config Class Initialized
INFO - 2017-02-17 13:33:12 --> Config Class Initialized
INFO - 2017-02-17 13:33:12 --> Hooks Class Initialized
INFO - 2017-02-17 13:33:12 --> Config Class Initialized
INFO - 2017-02-17 13:33:12 --> Hooks Class Initialized
INFO - 2017-02-17 13:33:12 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:33:12 --> UTF-8 Support Enabled
DEBUG - 2017-02-17 13:33:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:33:12 --> Utf8 Class Initialized
INFO - 2017-02-17 13:33:12 --> URI Class Initialized
DEBUG - 2017-02-17 13:33:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:33:12 --> Utf8 Class Initialized
INFO - 2017-02-17 13:33:12 --> URI Class Initialized
INFO - 2017-02-17 13:33:12 --> Router Class Initialized
INFO - 2017-02-17 13:33:12 --> Output Class Initialized
INFO - 2017-02-17 13:33:12 --> Router Class Initialized
INFO - 2017-02-17 13:33:12 --> Security Class Initialized
INFO - 2017-02-17 13:33:12 --> Output Class Initialized
DEBUG - 2017-02-17 13:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:33:12 --> Input Class Initialized
INFO - 2017-02-17 13:33:12 --> Security Class Initialized
INFO - 2017-02-17 13:33:12 --> Language Class Initialized
DEBUG - 2017-02-17 13:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-17 13:33:12 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:33:12 --> Utf8 Class Initialized
INFO - 2017-02-17 13:33:12 --> Input Class Initialized
INFO - 2017-02-17 13:33:12 --> Language Class Initialized
INFO - 2017-02-17 13:33:12 --> URI Class Initialized
ERROR - 2017-02-17 13:33:12 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:33:12 --> Router Class Initialized
INFO - 2017-02-17 13:33:12 --> Output Class Initialized
INFO - 2017-02-17 13:33:12 --> Security Class Initialized
DEBUG - 2017-02-17 13:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:33:12 --> Input Class Initialized
INFO - 2017-02-17 13:33:12 --> Language Class Initialized
ERROR - 2017-02-17 13:33:12 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:33:12 --> Config Class Initialized
INFO - 2017-02-17 13:33:12 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:33:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:33:12 --> Utf8 Class Initialized
INFO - 2017-02-17 13:33:12 --> URI Class Initialized
INFO - 2017-02-17 13:33:12 --> Router Class Initialized
INFO - 2017-02-17 13:33:12 --> Output Class Initialized
INFO - 2017-02-17 13:33:12 --> Security Class Initialized
DEBUG - 2017-02-17 13:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:33:12 --> Input Class Initialized
INFO - 2017-02-17 13:33:12 --> Language Class Initialized
ERROR - 2017-02-17 13:33:12 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:33:51 --> Config Class Initialized
INFO - 2017-02-17 13:33:51 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:33:51 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:33:51 --> Utf8 Class Initialized
INFO - 2017-02-17 13:33:51 --> URI Class Initialized
INFO - 2017-02-17 13:33:51 --> Router Class Initialized
INFO - 2017-02-17 13:33:51 --> Output Class Initialized
INFO - 2017-02-17 13:33:51 --> Security Class Initialized
DEBUG - 2017-02-17 13:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:33:51 --> Input Class Initialized
INFO - 2017-02-17 13:33:51 --> Language Class Initialized
INFO - 2017-02-17 13:33:51 --> Language Class Initialized
INFO - 2017-02-17 13:33:51 --> Config Class Initialized
INFO - 2017-02-17 13:33:51 --> Loader Class Initialized
INFO - 2017-02-17 13:33:51 --> Helper loaded: form_helper
INFO - 2017-02-17 13:33:51 --> Helper loaded: url_helper
INFO - 2017-02-17 13:33:51 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:33:51 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:33:51 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:33:51 --> Template Class Initialized
INFO - 2017-02-17 13:33:51 --> Controller Class Initialized
INFO - 2017-02-17 13:33:51 --> Form Validation Class Initialized
INFO - 2017-02-17 13:33:51 --> Model Class Initialized
DEBUG - 2017-02-17 13:33:51 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:33:51 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:33:51 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-17 13:33:51 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:33:51 --> Final output sent to browser
DEBUG - 2017-02-17 13:33:51 --> Total execution time: 0.0626
INFO - 2017-02-17 13:33:51 --> Config Class Initialized
INFO - 2017-02-17 13:33:51 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:33:51 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:33:51 --> Utf8 Class Initialized
INFO - 2017-02-17 13:33:51 --> URI Class Initialized
INFO - 2017-02-17 13:33:51 --> Router Class Initialized
INFO - 2017-02-17 13:33:51 --> Output Class Initialized
INFO - 2017-02-17 13:33:51 --> Security Class Initialized
DEBUG - 2017-02-17 13:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:33:51 --> Input Class Initialized
INFO - 2017-02-17 13:33:51 --> Language Class Initialized
ERROR - 2017-02-17 13:33:51 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:36:17 --> Config Class Initialized
INFO - 2017-02-17 13:36:17 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:36:17 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:36:17 --> Utf8 Class Initialized
INFO - 2017-02-17 13:36:17 --> URI Class Initialized
INFO - 2017-02-17 13:36:17 --> Router Class Initialized
INFO - 2017-02-17 13:36:17 --> Output Class Initialized
INFO - 2017-02-17 13:36:17 --> Security Class Initialized
DEBUG - 2017-02-17 13:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:36:17 --> Input Class Initialized
INFO - 2017-02-17 13:36:17 --> Language Class Initialized
INFO - 2017-02-17 13:36:17 --> Language Class Initialized
INFO - 2017-02-17 13:36:17 --> Config Class Initialized
INFO - 2017-02-17 13:36:17 --> Loader Class Initialized
INFO - 2017-02-17 13:36:17 --> Helper loaded: form_helper
INFO - 2017-02-17 13:36:17 --> Helper loaded: url_helper
INFO - 2017-02-17 13:36:17 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:36:17 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:36:17 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:36:17 --> Template Class Initialized
INFO - 2017-02-17 13:36:17 --> Controller Class Initialized
INFO - 2017-02-17 13:36:17 --> Form Validation Class Initialized
INFO - 2017-02-17 13:36:17 --> Model Class Initialized
DEBUG - 2017-02-17 13:36:17 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:36:17 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:36:17 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-17 13:36:17 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:36:17 --> Final output sent to browser
DEBUG - 2017-02-17 13:36:17 --> Total execution time: 0.0800
INFO - 2017-02-17 13:36:17 --> Config Class Initialized
INFO - 2017-02-17 13:36:17 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:36:17 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:36:17 --> Utf8 Class Initialized
INFO - 2017-02-17 13:36:17 --> URI Class Initialized
INFO - 2017-02-17 13:36:17 --> Router Class Initialized
INFO - 2017-02-17 13:36:17 --> Output Class Initialized
INFO - 2017-02-17 13:36:17 --> Security Class Initialized
DEBUG - 2017-02-17 13:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:36:17 --> Input Class Initialized
INFO - 2017-02-17 13:36:17 --> Language Class Initialized
ERROR - 2017-02-17 13:36:17 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:36:50 --> Config Class Initialized
INFO - 2017-02-17 13:36:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:36:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:36:50 --> Utf8 Class Initialized
INFO - 2017-02-17 13:36:50 --> URI Class Initialized
INFO - 2017-02-17 13:36:50 --> Router Class Initialized
INFO - 2017-02-17 13:36:50 --> Output Class Initialized
INFO - 2017-02-17 13:36:50 --> Security Class Initialized
DEBUG - 2017-02-17 13:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:36:50 --> Input Class Initialized
INFO - 2017-02-17 13:36:50 --> Language Class Initialized
INFO - 2017-02-17 13:36:50 --> Language Class Initialized
INFO - 2017-02-17 13:36:50 --> Config Class Initialized
INFO - 2017-02-17 13:36:50 --> Loader Class Initialized
INFO - 2017-02-17 13:36:50 --> Helper loaded: form_helper
INFO - 2017-02-17 13:36:50 --> Helper loaded: url_helper
INFO - 2017-02-17 13:36:50 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:36:50 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:36:50 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:36:50 --> Template Class Initialized
INFO - 2017-02-17 13:36:50 --> Controller Class Initialized
INFO - 2017-02-17 13:36:50 --> Form Validation Class Initialized
INFO - 2017-02-17 13:36:50 --> Model Class Initialized
DEBUG - 2017-02-17 13:36:50 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:36:50 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:36:50 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-17 13:36:50 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:36:50 --> Final output sent to browser
DEBUG - 2017-02-17 13:36:50 --> Total execution time: 0.0469
INFO - 2017-02-17 13:36:50 --> Config Class Initialized
INFO - 2017-02-17 13:36:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:36:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:36:50 --> Utf8 Class Initialized
INFO - 2017-02-17 13:36:50 --> URI Class Initialized
INFO - 2017-02-17 13:36:50 --> Router Class Initialized
INFO - 2017-02-17 13:36:50 --> Output Class Initialized
INFO - 2017-02-17 13:36:50 --> Security Class Initialized
DEBUG - 2017-02-17 13:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:36:50 --> Input Class Initialized
INFO - 2017-02-17 13:36:50 --> Language Class Initialized
ERROR - 2017-02-17 13:36:50 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:36:54 --> Config Class Initialized
INFO - 2017-02-17 13:36:54 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:36:54 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:36:54 --> Utf8 Class Initialized
INFO - 2017-02-17 13:36:54 --> URI Class Initialized
INFO - 2017-02-17 13:36:54 --> Router Class Initialized
INFO - 2017-02-17 13:36:54 --> Output Class Initialized
INFO - 2017-02-17 13:36:54 --> Security Class Initialized
DEBUG - 2017-02-17 13:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:36:54 --> Input Class Initialized
INFO - 2017-02-17 13:36:54 --> Language Class Initialized
INFO - 2017-02-17 13:36:54 --> Language Class Initialized
INFO - 2017-02-17 13:36:54 --> Config Class Initialized
INFO - 2017-02-17 13:36:54 --> Loader Class Initialized
INFO - 2017-02-17 13:36:54 --> Helper loaded: form_helper
INFO - 2017-02-17 13:36:54 --> Helper loaded: url_helper
INFO - 2017-02-17 13:36:54 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:36:54 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:36:54 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:36:54 --> Template Class Initialized
INFO - 2017-02-17 13:36:54 --> Controller Class Initialized
INFO - 2017-02-17 13:36:54 --> Form Validation Class Initialized
INFO - 2017-02-17 13:36:55 --> Model Class Initialized
DEBUG - 2017-02-17 13:36:55 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:36:55 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:36:55 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-17 13:36:55 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:36:55 --> Final output sent to browser
DEBUG - 2017-02-17 13:36:55 --> Total execution time: 0.9736
INFO - 2017-02-17 13:36:55 --> Config Class Initialized
INFO - 2017-02-17 13:36:55 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:36:55 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:36:55 --> Utf8 Class Initialized
INFO - 2017-02-17 13:36:55 --> URI Class Initialized
INFO - 2017-02-17 13:36:55 --> Router Class Initialized
INFO - 2017-02-17 13:36:55 --> Output Class Initialized
INFO - 2017-02-17 13:36:55 --> Security Class Initialized
DEBUG - 2017-02-17 13:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:36:55 --> Input Class Initialized
INFO - 2017-02-17 13:36:55 --> Language Class Initialized
ERROR - 2017-02-17 13:36:55 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:37:42 --> Config Class Initialized
INFO - 2017-02-17 13:37:42 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:37:42 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:37:42 --> Utf8 Class Initialized
INFO - 2017-02-17 13:37:42 --> URI Class Initialized
INFO - 2017-02-17 13:37:42 --> Router Class Initialized
INFO - 2017-02-17 13:37:42 --> Output Class Initialized
INFO - 2017-02-17 13:37:42 --> Security Class Initialized
DEBUG - 2017-02-17 13:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:37:42 --> Input Class Initialized
INFO - 2017-02-17 13:37:42 --> Language Class Initialized
INFO - 2017-02-17 13:37:42 --> Language Class Initialized
INFO - 2017-02-17 13:37:42 --> Config Class Initialized
INFO - 2017-02-17 13:37:42 --> Loader Class Initialized
INFO - 2017-02-17 13:37:42 --> Helper loaded: form_helper
INFO - 2017-02-17 13:37:42 --> Helper loaded: url_helper
INFO - 2017-02-17 13:37:42 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:37:42 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:37:43 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:37:43 --> Template Class Initialized
INFO - 2017-02-17 13:37:43 --> Controller Class Initialized
INFO - 2017-02-17 13:37:43 --> Form Validation Class Initialized
INFO - 2017-02-17 13:37:43 --> Model Class Initialized
DEBUG - 2017-02-17 13:37:43 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:37:43 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:37:43 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-17 13:37:43 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:37:43 --> Final output sent to browser
DEBUG - 2017-02-17 13:37:43 --> Total execution time: 0.0427
INFO - 2017-02-17 13:37:43 --> Config Class Initialized
INFO - 2017-02-17 13:37:43 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:37:43 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:37:43 --> Utf8 Class Initialized
INFO - 2017-02-17 13:37:43 --> URI Class Initialized
INFO - 2017-02-17 13:37:43 --> Router Class Initialized
INFO - 2017-02-17 13:37:43 --> Output Class Initialized
INFO - 2017-02-17 13:37:43 --> Security Class Initialized
DEBUG - 2017-02-17 13:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:37:43 --> Input Class Initialized
INFO - 2017-02-17 13:37:43 --> Language Class Initialized
ERROR - 2017-02-17 13:37:43 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:39:05 --> Config Class Initialized
INFO - 2017-02-17 13:39:05 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:39:05 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:39:05 --> Utf8 Class Initialized
INFO - 2017-02-17 13:39:05 --> URI Class Initialized
INFO - 2017-02-17 13:39:05 --> Router Class Initialized
INFO - 2017-02-17 13:39:05 --> Output Class Initialized
INFO - 2017-02-17 13:39:05 --> Security Class Initialized
DEBUG - 2017-02-17 13:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:39:05 --> Input Class Initialized
INFO - 2017-02-17 13:39:05 --> Language Class Initialized
INFO - 2017-02-17 13:39:05 --> Language Class Initialized
INFO - 2017-02-17 13:39:05 --> Config Class Initialized
INFO - 2017-02-17 13:39:05 --> Loader Class Initialized
INFO - 2017-02-17 13:39:05 --> Helper loaded: form_helper
INFO - 2017-02-17 13:39:05 --> Helper loaded: url_helper
INFO - 2017-02-17 13:39:05 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:39:05 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:39:05 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:39:05 --> Template Class Initialized
INFO - 2017-02-17 13:39:05 --> Controller Class Initialized
INFO - 2017-02-17 13:39:05 --> Form Validation Class Initialized
INFO - 2017-02-17 13:39:05 --> Model Class Initialized
DEBUG - 2017-02-17 13:39:05 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:39:05 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:39:05 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-17 13:39:05 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:39:05 --> Final output sent to browser
DEBUG - 2017-02-17 13:39:05 --> Total execution time: 0.0514
INFO - 2017-02-17 13:39:15 --> Config Class Initialized
INFO - 2017-02-17 13:39:15 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:39:15 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:39:15 --> Utf8 Class Initialized
INFO - 2017-02-17 13:39:15 --> URI Class Initialized
INFO - 2017-02-17 13:39:15 --> Router Class Initialized
INFO - 2017-02-17 13:39:15 --> Output Class Initialized
INFO - 2017-02-17 13:39:15 --> Security Class Initialized
DEBUG - 2017-02-17 13:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:39:15 --> Input Class Initialized
INFO - 2017-02-17 13:39:15 --> Language Class Initialized
INFO - 2017-02-17 13:39:15 --> Language Class Initialized
INFO - 2017-02-17 13:39:15 --> Config Class Initialized
INFO - 2017-02-17 13:39:15 --> Loader Class Initialized
INFO - 2017-02-17 13:39:15 --> Helper loaded: form_helper
INFO - 2017-02-17 13:39:15 --> Helper loaded: url_helper
INFO - 2017-02-17 13:39:15 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:39:15 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:39:15 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:39:15 --> Template Class Initialized
INFO - 2017-02-17 13:39:15 --> Controller Class Initialized
INFO - 2017-02-17 13:39:15 --> Form Validation Class Initialized
INFO - 2017-02-17 13:39:15 --> Model Class Initialized
DEBUG - 2017-02-17 13:39:15 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:39:15 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:39:15 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-17 13:39:15 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:39:15 --> Final output sent to browser
DEBUG - 2017-02-17 13:39:15 --> Total execution time: 0.2745
INFO - 2017-02-17 13:39:15 --> Config Class Initialized
INFO - 2017-02-17 13:39:15 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:39:15 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:39:15 --> Utf8 Class Initialized
INFO - 2017-02-17 13:39:15 --> URI Class Initialized
INFO - 2017-02-17 13:39:15 --> Router Class Initialized
INFO - 2017-02-17 13:39:15 --> Output Class Initialized
INFO - 2017-02-17 13:39:15 --> Security Class Initialized
DEBUG - 2017-02-17 13:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:39:15 --> Input Class Initialized
INFO - 2017-02-17 13:39:15 --> Language Class Initialized
ERROR - 2017-02-17 13:39:15 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:39:44 --> Config Class Initialized
INFO - 2017-02-17 13:39:44 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:39:44 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:39:44 --> Utf8 Class Initialized
INFO - 2017-02-17 13:39:44 --> URI Class Initialized
INFO - 2017-02-17 13:39:44 --> Router Class Initialized
INFO - 2017-02-17 13:39:44 --> Output Class Initialized
INFO - 2017-02-17 13:39:44 --> Security Class Initialized
DEBUG - 2017-02-17 13:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:39:44 --> Input Class Initialized
INFO - 2017-02-17 13:39:44 --> Language Class Initialized
INFO - 2017-02-17 13:39:44 --> Language Class Initialized
INFO - 2017-02-17 13:39:44 --> Config Class Initialized
INFO - 2017-02-17 13:39:44 --> Loader Class Initialized
INFO - 2017-02-17 13:39:44 --> Helper loaded: form_helper
INFO - 2017-02-17 13:39:44 --> Helper loaded: url_helper
INFO - 2017-02-17 13:39:44 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:39:44 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:39:44 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:39:44 --> Template Class Initialized
INFO - 2017-02-17 13:39:44 --> Controller Class Initialized
INFO - 2017-02-17 13:39:44 --> Form Validation Class Initialized
INFO - 2017-02-17 13:39:44 --> Model Class Initialized
DEBUG - 2017-02-17 13:39:44 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:39:44 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:39:44 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-17 13:39:44 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:39:44 --> Final output sent to browser
DEBUG - 2017-02-17 13:39:44 --> Total execution time: 0.0502
INFO - 2017-02-17 13:39:48 --> Config Class Initialized
INFO - 2017-02-17 13:39:48 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:39:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:39:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:39:48 --> URI Class Initialized
DEBUG - 2017-02-17 13:39:48 --> No URI present. Default controller set.
INFO - 2017-02-17 13:39:48 --> Router Class Initialized
INFO - 2017-02-17 13:39:49 --> Output Class Initialized
INFO - 2017-02-17 13:39:49 --> Security Class Initialized
DEBUG - 2017-02-17 13:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:39:49 --> Input Class Initialized
INFO - 2017-02-17 13:39:49 --> Language Class Initialized
INFO - 2017-02-17 13:39:49 --> Language Class Initialized
INFO - 2017-02-17 13:39:49 --> Config Class Initialized
INFO - 2017-02-17 13:39:49 --> Loader Class Initialized
INFO - 2017-02-17 13:39:49 --> Helper loaded: form_helper
INFO - 2017-02-17 13:39:49 --> Helper loaded: url_helper
INFO - 2017-02-17 13:39:49 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:39:49 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:39:49 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:39:49 --> Template Class Initialized
INFO - 2017-02-17 13:39:49 --> Controller Class Initialized
INFO - 2017-02-17 13:39:49 --> Form Validation Class Initialized
INFO - 2017-02-17 13:39:49 --> Model Class Initialized
DEBUG - 2017-02-17 13:39:49 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:39:49 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:39:49 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:39:49 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:39:49 --> Final output sent to browser
DEBUG - 2017-02-17 13:39:49 --> Total execution time: 0.2346
INFO - 2017-02-17 13:39:54 --> Config Class Initialized
INFO - 2017-02-17 13:39:54 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:39:54 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:39:54 --> Utf8 Class Initialized
INFO - 2017-02-17 13:39:54 --> URI Class Initialized
INFO - 2017-02-17 13:39:54 --> Router Class Initialized
INFO - 2017-02-17 13:39:54 --> Output Class Initialized
INFO - 2017-02-17 13:39:54 --> Security Class Initialized
DEBUG - 2017-02-17 13:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:39:54 --> Input Class Initialized
INFO - 2017-02-17 13:39:54 --> Language Class Initialized
ERROR - 2017-02-17 13:39:54 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:41:21 --> Config Class Initialized
INFO - 2017-02-17 13:41:21 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:41:21 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:41:21 --> Utf8 Class Initialized
INFO - 2017-02-17 13:41:21 --> URI Class Initialized
DEBUG - 2017-02-17 13:41:21 --> No URI present. Default controller set.
INFO - 2017-02-17 13:41:21 --> Router Class Initialized
INFO - 2017-02-17 13:41:21 --> Output Class Initialized
INFO - 2017-02-17 13:41:21 --> Security Class Initialized
DEBUG - 2017-02-17 13:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:41:21 --> Input Class Initialized
INFO - 2017-02-17 13:41:21 --> Language Class Initialized
INFO - 2017-02-17 13:41:21 --> Language Class Initialized
INFO - 2017-02-17 13:41:21 --> Config Class Initialized
INFO - 2017-02-17 13:41:21 --> Loader Class Initialized
INFO - 2017-02-17 13:41:21 --> Helper loaded: form_helper
INFO - 2017-02-17 13:41:21 --> Helper loaded: url_helper
INFO - 2017-02-17 13:41:21 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:41:21 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:41:21 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:41:21 --> Template Class Initialized
INFO - 2017-02-17 13:41:21 --> Controller Class Initialized
INFO - 2017-02-17 13:41:21 --> Form Validation Class Initialized
INFO - 2017-02-17 13:41:21 --> Model Class Initialized
DEBUG - 2017-02-17 13:41:21 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:41:21 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:41:21 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:41:21 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:41:21 --> Final output sent to browser
DEBUG - 2017-02-17 13:41:21 --> Total execution time: 0.0884
INFO - 2017-02-17 13:43:09 --> Config Class Initialized
INFO - 2017-02-17 13:43:09 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:43:09 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:43:09 --> Utf8 Class Initialized
INFO - 2017-02-17 13:43:09 --> URI Class Initialized
DEBUG - 2017-02-17 13:43:09 --> No URI present. Default controller set.
INFO - 2017-02-17 13:43:09 --> Router Class Initialized
INFO - 2017-02-17 13:43:09 --> Output Class Initialized
INFO - 2017-02-17 13:43:09 --> Security Class Initialized
DEBUG - 2017-02-17 13:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:43:09 --> Input Class Initialized
INFO - 2017-02-17 13:43:09 --> Language Class Initialized
INFO - 2017-02-17 13:43:09 --> Language Class Initialized
INFO - 2017-02-17 13:43:09 --> Config Class Initialized
INFO - 2017-02-17 13:43:09 --> Loader Class Initialized
INFO - 2017-02-17 13:43:09 --> Helper loaded: form_helper
INFO - 2017-02-17 13:43:09 --> Helper loaded: url_helper
INFO - 2017-02-17 13:43:09 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:43:09 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:43:09 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:43:09 --> Template Class Initialized
INFO - 2017-02-17 13:43:09 --> Controller Class Initialized
INFO - 2017-02-17 13:43:09 --> Form Validation Class Initialized
INFO - 2017-02-17 13:43:09 --> Model Class Initialized
DEBUG - 2017-02-17 13:43:09 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:43:09 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:43:09 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:43:09 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:43:09 --> Final output sent to browser
DEBUG - 2017-02-17 13:43:09 --> Total execution time: 0.0515
INFO - 2017-02-17 13:43:28 --> Config Class Initialized
INFO - 2017-02-17 13:43:28 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:43:28 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:43:28 --> Utf8 Class Initialized
INFO - 2017-02-17 13:43:28 --> URI Class Initialized
INFO - 2017-02-17 13:43:28 --> Router Class Initialized
INFO - 2017-02-17 13:43:28 --> Output Class Initialized
INFO - 2017-02-17 13:43:28 --> Security Class Initialized
DEBUG - 2017-02-17 13:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:43:28 --> Input Class Initialized
INFO - 2017-02-17 13:43:28 --> Language Class Initialized
ERROR - 2017-02-17 13:43:28 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 13:43:31 --> Config Class Initialized
INFO - 2017-02-17 13:43:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:43:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:43:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:43:31 --> URI Class Initialized
INFO - 2017-02-17 13:43:31 --> Router Class Initialized
INFO - 2017-02-17 13:43:31 --> Output Class Initialized
INFO - 2017-02-17 13:43:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:43:31 --> Input Class Initialized
INFO - 2017-02-17 13:43:31 --> Language Class Initialized
INFO - 2017-02-17 13:43:31 --> Language Class Initialized
INFO - 2017-02-17 13:43:31 --> Config Class Initialized
INFO - 2017-02-17 13:43:31 --> Loader Class Initialized
INFO - 2017-02-17 13:43:31 --> Helper loaded: form_helper
INFO - 2017-02-17 13:43:31 --> Helper loaded: url_helper
INFO - 2017-02-17 13:43:31 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:43:31 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:43:31 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:43:31 --> Template Class Initialized
INFO - 2017-02-17 13:43:31 --> Controller Class Initialized
DEBUG - 2017-02-17 13:43:31 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:43:31 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:43:31 --> Model Class Initialized
INFO - 2017-02-17 13:43:31 --> Form Validation Class Initialized
DEBUG - 2017-02-17 13:43:31 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:43:31 --> Final output sent to browser
DEBUG - 2017-02-17 13:43:31 --> Total execution time: 0.2556
INFO - 2017-02-17 13:43:33 --> Config Class Initialized
INFO - 2017-02-17 13:43:33 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:43:33 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:43:33 --> Utf8 Class Initialized
INFO - 2017-02-17 13:43:33 --> URI Class Initialized
INFO - 2017-02-17 13:43:33 --> Router Class Initialized
INFO - 2017-02-17 13:43:33 --> Output Class Initialized
INFO - 2017-02-17 13:43:33 --> Security Class Initialized
DEBUG - 2017-02-17 13:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:43:33 --> Input Class Initialized
INFO - 2017-02-17 13:43:33 --> Language Class Initialized
INFO - 2017-02-17 13:43:33 --> Language Class Initialized
INFO - 2017-02-17 13:43:33 --> Config Class Initialized
INFO - 2017-02-17 13:43:33 --> Loader Class Initialized
INFO - 2017-02-17 13:43:33 --> Helper loaded: form_helper
INFO - 2017-02-17 13:43:33 --> Helper loaded: url_helper
INFO - 2017-02-17 13:43:33 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:43:34 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:43:34 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:43:34 --> Template Class Initialized
INFO - 2017-02-17 13:43:34 --> Controller Class Initialized
DEBUG - 2017-02-17 13:43:34 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:43:34 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:43:34 --> Model Class Initialized
INFO - 2017-02-17 13:43:34 --> Form Validation Class Initialized
INFO - 2017-02-17 13:43:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 13:43:34 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
DEBUG - 2017-02-17 13:43:34 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 13:43:34 --> Final output sent to browser
DEBUG - 2017-02-17 13:43:34 --> Total execution time: 0.4678
INFO - 2017-02-17 13:44:27 --> Config Class Initialized
INFO - 2017-02-17 13:44:27 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:44:27 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:44:27 --> Utf8 Class Initialized
INFO - 2017-02-17 13:44:27 --> URI Class Initialized
INFO - 2017-02-17 13:44:27 --> Router Class Initialized
INFO - 2017-02-17 13:44:27 --> Output Class Initialized
INFO - 2017-02-17 13:44:27 --> Security Class Initialized
DEBUG - 2017-02-17 13:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:44:27 --> Input Class Initialized
INFO - 2017-02-17 13:44:27 --> Language Class Initialized
INFO - 2017-02-17 13:44:27 --> Language Class Initialized
INFO - 2017-02-17 13:44:27 --> Config Class Initialized
INFO - 2017-02-17 13:44:27 --> Loader Class Initialized
INFO - 2017-02-17 13:44:27 --> Helper loaded: form_helper
INFO - 2017-02-17 13:44:27 --> Helper loaded: url_helper
INFO - 2017-02-17 13:44:27 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:44:27 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:44:27 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:44:27 --> Template Class Initialized
INFO - 2017-02-17 13:44:27 --> Controller Class Initialized
DEBUG - 2017-02-17 13:44:27 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:44:27 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:44:27 --> Model Class Initialized
INFO - 2017-02-17 13:44:27 --> Form Validation Class Initialized
INFO - 2017-02-17 13:44:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 13:44:27 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:44:27 --> Final output sent to browser
DEBUG - 2017-02-17 13:44:27 --> Total execution time: 0.1284
INFO - 2017-02-17 13:44:30 --> Config Class Initialized
INFO - 2017-02-17 13:44:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:44:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:44:30 --> Utf8 Class Initialized
INFO - 2017-02-17 13:44:30 --> URI Class Initialized
INFO - 2017-02-17 13:44:30 --> Router Class Initialized
INFO - 2017-02-17 13:44:30 --> Output Class Initialized
INFO - 2017-02-17 13:44:30 --> Security Class Initialized
DEBUG - 2017-02-17 13:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:44:30 --> Input Class Initialized
INFO - 2017-02-17 13:44:30 --> Language Class Initialized
INFO - 2017-02-17 13:44:30 --> Language Class Initialized
INFO - 2017-02-17 13:44:30 --> Config Class Initialized
INFO - 2017-02-17 13:44:30 --> Loader Class Initialized
INFO - 2017-02-17 13:44:30 --> Helper loaded: form_helper
INFO - 2017-02-17 13:44:30 --> Helper loaded: url_helper
INFO - 2017-02-17 13:44:30 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:44:30 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:44:30 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:44:30 --> Template Class Initialized
INFO - 2017-02-17 13:44:30 --> Controller Class Initialized
DEBUG - 2017-02-17 13:44:30 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:44:30 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:44:30 --> Model Class Initialized
INFO - 2017-02-17 13:44:30 --> Form Validation Class Initialized
INFO - 2017-02-17 13:44:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 13:44:30 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:44:30 --> Final output sent to browser
DEBUG - 2017-02-17 13:44:30 --> Total execution time: 0.0661
INFO - 2017-02-17 13:44:46 --> Config Class Initialized
INFO - 2017-02-17 13:44:46 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:44:46 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:44:46 --> Utf8 Class Initialized
INFO - 2017-02-17 13:44:46 --> URI Class Initialized
INFO - 2017-02-17 13:44:46 --> Router Class Initialized
INFO - 2017-02-17 13:44:46 --> Output Class Initialized
INFO - 2017-02-17 13:44:46 --> Security Class Initialized
DEBUG - 2017-02-17 13:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:44:46 --> Input Class Initialized
INFO - 2017-02-17 13:44:46 --> Language Class Initialized
INFO - 2017-02-17 13:44:46 --> Language Class Initialized
INFO - 2017-02-17 13:44:46 --> Config Class Initialized
INFO - 2017-02-17 13:44:46 --> Loader Class Initialized
INFO - 2017-02-17 13:44:46 --> Helper loaded: form_helper
INFO - 2017-02-17 13:44:46 --> Helper loaded: url_helper
INFO - 2017-02-17 13:44:46 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:44:46 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:44:46 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:44:46 --> Template Class Initialized
INFO - 2017-02-17 13:44:46 --> Controller Class Initialized
DEBUG - 2017-02-17 13:44:46 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:44:46 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:44:46 --> Model Class Initialized
INFO - 2017-02-17 13:44:46 --> Form Validation Class Initialized
INFO - 2017-02-17 13:44:46 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 13:44:46 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\razor\application\modules\backend\controllers\Login.php 62
DEBUG - 2017-02-17 13:44:46 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:44:46 --> Final output sent to browser
DEBUG - 2017-02-17 13:44:46 --> Total execution time: 0.0436
INFO - 2017-02-17 13:44:56 --> Config Class Initialized
INFO - 2017-02-17 13:44:56 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:44:56 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:44:56 --> Utf8 Class Initialized
INFO - 2017-02-17 13:44:56 --> URI Class Initialized
INFO - 2017-02-17 13:44:56 --> Router Class Initialized
INFO - 2017-02-17 13:44:56 --> Output Class Initialized
INFO - 2017-02-17 13:44:56 --> Security Class Initialized
DEBUG - 2017-02-17 13:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:44:56 --> Input Class Initialized
INFO - 2017-02-17 13:44:56 --> Language Class Initialized
INFO - 2017-02-17 13:44:56 --> Language Class Initialized
INFO - 2017-02-17 13:44:56 --> Config Class Initialized
INFO - 2017-02-17 13:44:56 --> Loader Class Initialized
INFO - 2017-02-17 13:44:56 --> Helper loaded: form_helper
INFO - 2017-02-17 13:44:56 --> Helper loaded: url_helper
INFO - 2017-02-17 13:44:56 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:44:56 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:44:56 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:44:56 --> Template Class Initialized
INFO - 2017-02-17 13:44:56 --> Controller Class Initialized
DEBUG - 2017-02-17 13:44:56 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:44:56 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:44:56 --> Model Class Initialized
INFO - 2017-02-17 13:44:56 --> Form Validation Class Initialized
INFO - 2017-02-17 13:44:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 13:44:56 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:44:56 --> Final output sent to browser
DEBUG - 2017-02-17 13:44:56 --> Total execution time: 0.0518
INFO - 2017-02-17 13:44:59 --> Config Class Initialized
INFO - 2017-02-17 13:44:59 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:44:59 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:44:59 --> Utf8 Class Initialized
INFO - 2017-02-17 13:44:59 --> URI Class Initialized
INFO - 2017-02-17 13:44:59 --> Router Class Initialized
INFO - 2017-02-17 13:44:59 --> Output Class Initialized
INFO - 2017-02-17 13:44:59 --> Security Class Initialized
DEBUG - 2017-02-17 13:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:44:59 --> Input Class Initialized
INFO - 2017-02-17 13:44:59 --> Language Class Initialized
INFO - 2017-02-17 13:44:59 --> Language Class Initialized
INFO - 2017-02-17 13:44:59 --> Config Class Initialized
INFO - 2017-02-17 13:44:59 --> Loader Class Initialized
INFO - 2017-02-17 13:44:59 --> Helper loaded: form_helper
INFO - 2017-02-17 13:44:59 --> Helper loaded: url_helper
INFO - 2017-02-17 13:44:59 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:44:59 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:44:59 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:44:59 --> Template Class Initialized
INFO - 2017-02-17 13:44:59 --> Controller Class Initialized
DEBUG - 2017-02-17 13:44:59 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:44:59 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:44:59 --> Model Class Initialized
INFO - 2017-02-17 13:44:59 --> Form Validation Class Initialized
INFO - 2017-02-17 13:44:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 13:44:59 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:44:59 --> Final output sent to browser
DEBUG - 2017-02-17 13:44:59 --> Total execution time: 0.1697
INFO - 2017-02-17 13:45:39 --> Config Class Initialized
INFO - 2017-02-17 13:45:39 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:45:39 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:45:39 --> Utf8 Class Initialized
INFO - 2017-02-17 13:45:39 --> URI Class Initialized
INFO - 2017-02-17 13:45:39 --> Router Class Initialized
INFO - 2017-02-17 13:45:39 --> Output Class Initialized
INFO - 2017-02-17 13:45:39 --> Security Class Initialized
DEBUG - 2017-02-17 13:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:45:39 --> Input Class Initialized
INFO - 2017-02-17 13:45:39 --> Language Class Initialized
INFO - 2017-02-17 13:45:39 --> Language Class Initialized
INFO - 2017-02-17 13:45:39 --> Config Class Initialized
INFO - 2017-02-17 13:45:39 --> Loader Class Initialized
INFO - 2017-02-17 13:45:39 --> Helper loaded: form_helper
INFO - 2017-02-17 13:45:39 --> Helper loaded: url_helper
INFO - 2017-02-17 13:45:39 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:45:39 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:45:39 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:45:39 --> Template Class Initialized
INFO - 2017-02-17 13:45:39 --> Controller Class Initialized
DEBUG - 2017-02-17 13:45:39 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:45:39 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:45:39 --> Model Class Initialized
INFO - 2017-02-17 13:45:39 --> Form Validation Class Initialized
INFO - 2017-02-17 13:45:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 13:45:39 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\razor\application\modules\backend\views\login.php 38
DEBUG - 2017-02-17 13:45:39 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:45:39 --> Final output sent to browser
DEBUG - 2017-02-17 13:45:39 --> Total execution time: 0.1439
INFO - 2017-02-17 13:46:41 --> Config Class Initialized
INFO - 2017-02-17 13:46:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:46:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:46:41 --> Utf8 Class Initialized
INFO - 2017-02-17 13:46:41 --> URI Class Initialized
INFO - 2017-02-17 13:46:41 --> Router Class Initialized
INFO - 2017-02-17 13:46:41 --> Output Class Initialized
INFO - 2017-02-17 13:46:41 --> Security Class Initialized
DEBUG - 2017-02-17 13:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:46:41 --> Input Class Initialized
INFO - 2017-02-17 13:46:41 --> Language Class Initialized
INFO - 2017-02-17 13:46:41 --> Language Class Initialized
INFO - 2017-02-17 13:46:41 --> Config Class Initialized
INFO - 2017-02-17 13:46:41 --> Loader Class Initialized
INFO - 2017-02-17 13:46:41 --> Helper loaded: form_helper
INFO - 2017-02-17 13:46:41 --> Helper loaded: url_helper
INFO - 2017-02-17 13:46:41 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:46:42 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:46:42 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:46:42 --> Template Class Initialized
INFO - 2017-02-17 13:46:42 --> Controller Class Initialized
DEBUG - 2017-02-17 13:46:42 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:46:42 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:46:42 --> Model Class Initialized
INFO - 2017-02-17 13:46:42 --> Form Validation Class Initialized
INFO - 2017-02-17 13:46:42 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 13:46:42 --> Severity: Notice --> Undefined variable: map C:\xampp\htdocs\razor\application\modules\backend\views\login.php 38
DEBUG - 2017-02-17 13:46:42 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:46:42 --> Final output sent to browser
DEBUG - 2017-02-17 13:46:42 --> Total execution time: 0.1344
INFO - 2017-02-17 13:46:44 --> Config Class Initialized
INFO - 2017-02-17 13:46:44 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:46:44 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:46:44 --> Utf8 Class Initialized
INFO - 2017-02-17 13:46:44 --> URI Class Initialized
INFO - 2017-02-17 13:46:44 --> Router Class Initialized
INFO - 2017-02-17 13:46:44 --> Output Class Initialized
INFO - 2017-02-17 13:46:44 --> Security Class Initialized
DEBUG - 2017-02-17 13:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:46:44 --> Input Class Initialized
INFO - 2017-02-17 13:46:44 --> Language Class Initialized
INFO - 2017-02-17 13:46:44 --> Language Class Initialized
INFO - 2017-02-17 13:46:44 --> Config Class Initialized
INFO - 2017-02-17 13:46:44 --> Loader Class Initialized
INFO - 2017-02-17 13:46:44 --> Helper loaded: form_helper
INFO - 2017-02-17 13:46:44 --> Helper loaded: url_helper
INFO - 2017-02-17 13:46:44 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:46:44 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:46:44 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:46:44 --> Template Class Initialized
INFO - 2017-02-17 13:46:44 --> Controller Class Initialized
DEBUG - 2017-02-17 13:46:44 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:46:44 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:46:44 --> Model Class Initialized
INFO - 2017-02-17 13:46:44 --> Form Validation Class Initialized
INFO - 2017-02-17 13:46:44 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 13:46:44 --> Severity: Notice --> Undefined variable: map C:\xampp\htdocs\razor\application\modules\backend\views\login.php 38
DEBUG - 2017-02-17 13:46:44 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:46:44 --> Final output sent to browser
DEBUG - 2017-02-17 13:46:44 --> Total execution time: 0.0620
INFO - 2017-02-17 13:46:57 --> Config Class Initialized
INFO - 2017-02-17 13:46:57 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:46:57 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:46:57 --> Utf8 Class Initialized
INFO - 2017-02-17 13:46:57 --> URI Class Initialized
INFO - 2017-02-17 13:46:57 --> Router Class Initialized
INFO - 2017-02-17 13:46:57 --> Output Class Initialized
INFO - 2017-02-17 13:46:57 --> Security Class Initialized
DEBUG - 2017-02-17 13:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:46:57 --> Input Class Initialized
INFO - 2017-02-17 13:46:57 --> Language Class Initialized
INFO - 2017-02-17 13:46:57 --> Language Class Initialized
INFO - 2017-02-17 13:46:57 --> Config Class Initialized
INFO - 2017-02-17 13:46:57 --> Loader Class Initialized
INFO - 2017-02-17 13:46:57 --> Helper loaded: form_helper
INFO - 2017-02-17 13:46:57 --> Helper loaded: url_helper
INFO - 2017-02-17 13:46:57 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:46:57 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:46:57 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:46:57 --> Template Class Initialized
INFO - 2017-02-17 13:46:57 --> Controller Class Initialized
DEBUG - 2017-02-17 13:46:57 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:46:57 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:46:57 --> Model Class Initialized
INFO - 2017-02-17 13:46:57 --> Form Validation Class Initialized
INFO - 2017-02-17 13:46:57 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 13:46:57 --> Severity: Notice --> Undefined variable: map C:\xampp\htdocs\razor\application\modules\backend\views\login.php 38
DEBUG - 2017-02-17 13:46:57 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:46:57 --> Final output sent to browser
DEBUG - 2017-02-17 13:46:57 --> Total execution time: 0.0868
INFO - 2017-02-17 13:47:21 --> Config Class Initialized
INFO - 2017-02-17 13:47:21 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:47:21 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:47:21 --> Utf8 Class Initialized
INFO - 2017-02-17 13:47:21 --> URI Class Initialized
INFO - 2017-02-17 13:47:21 --> Router Class Initialized
INFO - 2017-02-17 13:47:21 --> Output Class Initialized
INFO - 2017-02-17 13:47:21 --> Security Class Initialized
DEBUG - 2017-02-17 13:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:47:21 --> Input Class Initialized
INFO - 2017-02-17 13:47:21 --> Language Class Initialized
INFO - 2017-02-17 13:47:21 --> Language Class Initialized
INFO - 2017-02-17 13:47:21 --> Config Class Initialized
INFO - 2017-02-17 13:47:21 --> Loader Class Initialized
INFO - 2017-02-17 13:47:21 --> Helper loaded: form_helper
INFO - 2017-02-17 13:47:21 --> Helper loaded: url_helper
INFO - 2017-02-17 13:47:21 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:47:21 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:47:21 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:47:21 --> Template Class Initialized
INFO - 2017-02-17 13:47:21 --> Controller Class Initialized
DEBUG - 2017-02-17 13:47:21 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:47:21 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:47:21 --> Model Class Initialized
INFO - 2017-02-17 13:47:21 --> Form Validation Class Initialized
INFO - 2017-02-17 13:47:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 13:47:21 --> Severity: Notice --> Undefined variable: map C:\xampp\htdocs\razor\application\modules\backend\views\login.php 38
DEBUG - 2017-02-17 13:47:21 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:47:21 --> Final output sent to browser
DEBUG - 2017-02-17 13:47:21 --> Total execution time: 0.0512
INFO - 2017-02-17 13:47:29 --> Config Class Initialized
INFO - 2017-02-17 13:47:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:47:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:47:29 --> Utf8 Class Initialized
INFO - 2017-02-17 13:47:29 --> URI Class Initialized
INFO - 2017-02-17 13:47:29 --> Router Class Initialized
INFO - 2017-02-17 13:47:29 --> Output Class Initialized
INFO - 2017-02-17 13:47:29 --> Security Class Initialized
DEBUG - 2017-02-17 13:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:47:29 --> Input Class Initialized
INFO - 2017-02-17 13:47:29 --> Language Class Initialized
INFO - 2017-02-17 13:47:29 --> Language Class Initialized
INFO - 2017-02-17 13:47:29 --> Config Class Initialized
INFO - 2017-02-17 13:47:29 --> Loader Class Initialized
INFO - 2017-02-17 13:47:29 --> Helper loaded: form_helper
INFO - 2017-02-17 13:47:29 --> Helper loaded: url_helper
INFO - 2017-02-17 13:47:29 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:47:29 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:47:29 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:47:29 --> Template Class Initialized
INFO - 2017-02-17 13:47:29 --> Controller Class Initialized
DEBUG - 2017-02-17 13:47:29 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:47:29 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:47:29 --> Model Class Initialized
INFO - 2017-02-17 13:47:29 --> Form Validation Class Initialized
INFO - 2017-02-17 13:47:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 13:47:29 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:47:29 --> Final output sent to browser
DEBUG - 2017-02-17 13:47:29 --> Total execution time: 0.0488
INFO - 2017-02-17 13:47:31 --> Config Class Initialized
INFO - 2017-02-17 13:47:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:47:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:47:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:47:31 --> URI Class Initialized
INFO - 2017-02-17 13:47:31 --> Router Class Initialized
INFO - 2017-02-17 13:47:31 --> Output Class Initialized
INFO - 2017-02-17 13:47:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:47:31 --> Input Class Initialized
INFO - 2017-02-17 13:47:31 --> Language Class Initialized
INFO - 2017-02-17 13:47:31 --> Language Class Initialized
INFO - 2017-02-17 13:47:31 --> Config Class Initialized
INFO - 2017-02-17 13:47:31 --> Loader Class Initialized
INFO - 2017-02-17 13:47:31 --> Helper loaded: form_helper
INFO - 2017-02-17 13:47:31 --> Helper loaded: url_helper
INFO - 2017-02-17 13:47:31 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:47:31 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:47:31 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:47:31 --> Template Class Initialized
INFO - 2017-02-17 13:47:31 --> Controller Class Initialized
DEBUG - 2017-02-17 13:47:31 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:47:31 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:47:31 --> Model Class Initialized
INFO - 2017-02-17 13:47:31 --> Form Validation Class Initialized
INFO - 2017-02-17 13:47:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 13:47:31 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:47:31 --> Final output sent to browser
DEBUG - 2017-02-17 13:47:31 --> Total execution time: 0.0408
INFO - 2017-02-17 13:48:31 --> Config Class Initialized
INFO - 2017-02-17 13:48:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:48:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:48:31 --> Utf8 Class Initialized
INFO - 2017-02-17 13:48:31 --> URI Class Initialized
INFO - 2017-02-17 13:48:31 --> Router Class Initialized
INFO - 2017-02-17 13:48:31 --> Output Class Initialized
INFO - 2017-02-17 13:48:31 --> Security Class Initialized
DEBUG - 2017-02-17 13:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:48:31 --> Input Class Initialized
INFO - 2017-02-17 13:48:31 --> Language Class Initialized
INFO - 2017-02-17 13:48:31 --> Language Class Initialized
INFO - 2017-02-17 13:48:31 --> Config Class Initialized
INFO - 2017-02-17 13:48:31 --> Loader Class Initialized
INFO - 2017-02-17 13:48:31 --> Helper loaded: form_helper
INFO - 2017-02-17 13:48:31 --> Helper loaded: url_helper
INFO - 2017-02-17 13:48:31 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:48:31 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:48:31 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:48:31 --> Template Class Initialized
INFO - 2017-02-17 13:48:31 --> Controller Class Initialized
DEBUG - 2017-02-17 13:48:31 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:48:31 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:48:31 --> Model Class Initialized
INFO - 2017-02-17 13:48:31 --> Form Validation Class Initialized
INFO - 2017-02-17 13:48:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 13:48:31 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:48:31 --> Final output sent to browser
DEBUG - 2017-02-17 13:48:31 --> Total execution time: 0.0419
INFO - 2017-02-17 13:48:33 --> Config Class Initialized
INFO - 2017-02-17 13:48:33 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:48:33 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:48:33 --> Utf8 Class Initialized
INFO - 2017-02-17 13:48:33 --> URI Class Initialized
INFO - 2017-02-17 13:48:33 --> Router Class Initialized
INFO - 2017-02-17 13:48:33 --> Output Class Initialized
INFO - 2017-02-17 13:48:33 --> Security Class Initialized
DEBUG - 2017-02-17 13:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:48:33 --> Input Class Initialized
INFO - 2017-02-17 13:48:33 --> Language Class Initialized
INFO - 2017-02-17 13:48:33 --> Language Class Initialized
INFO - 2017-02-17 13:48:33 --> Config Class Initialized
INFO - 2017-02-17 13:48:33 --> Loader Class Initialized
INFO - 2017-02-17 13:48:33 --> Helper loaded: form_helper
INFO - 2017-02-17 13:48:33 --> Helper loaded: url_helper
INFO - 2017-02-17 13:48:33 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:48:33 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:48:33 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:48:33 --> Template Class Initialized
INFO - 2017-02-17 13:48:33 --> Controller Class Initialized
DEBUG - 2017-02-17 13:48:33 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:48:33 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:48:33 --> Model Class Initialized
INFO - 2017-02-17 13:48:33 --> Form Validation Class Initialized
INFO - 2017-02-17 13:48:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 13:48:33 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:48:33 --> Final output sent to browser
DEBUG - 2017-02-17 13:48:33 --> Total execution time: 0.0435
INFO - 2017-02-17 13:48:34 --> Config Class Initialized
INFO - 2017-02-17 13:48:34 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:48:34 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:48:34 --> Utf8 Class Initialized
INFO - 2017-02-17 13:48:34 --> URI Class Initialized
INFO - 2017-02-17 13:48:34 --> Router Class Initialized
INFO - 2017-02-17 13:48:34 --> Output Class Initialized
INFO - 2017-02-17 13:48:34 --> Security Class Initialized
DEBUG - 2017-02-17 13:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:48:34 --> Input Class Initialized
INFO - 2017-02-17 13:48:34 --> Language Class Initialized
INFO - 2017-02-17 13:48:34 --> Language Class Initialized
INFO - 2017-02-17 13:48:34 --> Config Class Initialized
INFO - 2017-02-17 13:48:34 --> Loader Class Initialized
INFO - 2017-02-17 13:48:34 --> Helper loaded: form_helper
INFO - 2017-02-17 13:48:34 --> Helper loaded: url_helper
INFO - 2017-02-17 13:48:34 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:48:34 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:48:34 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:48:34 --> Template Class Initialized
INFO - 2017-02-17 13:48:34 --> Controller Class Initialized
DEBUG - 2017-02-17 13:48:34 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:48:34 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:48:34 --> Model Class Initialized
INFO - 2017-02-17 13:48:34 --> Form Validation Class Initialized
DEBUG - 2017-02-17 13:48:34 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:48:34 --> Final output sent to browser
DEBUG - 2017-02-17 13:48:34 --> Total execution time: 0.0489
INFO - 2017-02-17 13:48:35 --> Config Class Initialized
INFO - 2017-02-17 13:48:35 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:48:35 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:48:35 --> Utf8 Class Initialized
INFO - 2017-02-17 13:48:35 --> URI Class Initialized
INFO - 2017-02-17 13:48:35 --> Router Class Initialized
INFO - 2017-02-17 13:48:35 --> Output Class Initialized
INFO - 2017-02-17 13:48:35 --> Security Class Initialized
DEBUG - 2017-02-17 13:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:48:35 --> Input Class Initialized
INFO - 2017-02-17 13:48:35 --> Language Class Initialized
INFO - 2017-02-17 13:48:35 --> Language Class Initialized
INFO - 2017-02-17 13:48:35 --> Config Class Initialized
INFO - 2017-02-17 13:48:35 --> Loader Class Initialized
INFO - 2017-02-17 13:48:35 --> Helper loaded: form_helper
INFO - 2017-02-17 13:48:35 --> Helper loaded: url_helper
INFO - 2017-02-17 13:48:35 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:48:35 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:48:35 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:48:35 --> Template Class Initialized
INFO - 2017-02-17 13:48:35 --> Controller Class Initialized
DEBUG - 2017-02-17 13:48:35 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:48:35 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:48:35 --> Model Class Initialized
INFO - 2017-02-17 13:48:35 --> Form Validation Class Initialized
DEBUG - 2017-02-17 13:48:35 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:48:35 --> Final output sent to browser
DEBUG - 2017-02-17 13:48:35 --> Total execution time: 0.0386
INFO - 2017-02-17 13:48:36 --> Config Class Initialized
INFO - 2017-02-17 13:48:36 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:48:36 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:48:36 --> Utf8 Class Initialized
INFO - 2017-02-17 13:48:36 --> URI Class Initialized
INFO - 2017-02-17 13:48:36 --> Router Class Initialized
INFO - 2017-02-17 13:48:36 --> Output Class Initialized
INFO - 2017-02-17 13:48:36 --> Security Class Initialized
DEBUG - 2017-02-17 13:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:48:36 --> Input Class Initialized
INFO - 2017-02-17 13:48:36 --> Language Class Initialized
INFO - 2017-02-17 13:48:36 --> Language Class Initialized
INFO - 2017-02-17 13:48:36 --> Config Class Initialized
INFO - 2017-02-17 13:48:36 --> Loader Class Initialized
INFO - 2017-02-17 13:48:36 --> Helper loaded: form_helper
INFO - 2017-02-17 13:48:36 --> Helper loaded: url_helper
INFO - 2017-02-17 13:48:36 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:48:36 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:48:36 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:48:36 --> Template Class Initialized
INFO - 2017-02-17 13:48:36 --> Controller Class Initialized
DEBUG - 2017-02-17 13:48:36 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:48:36 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:48:36 --> Model Class Initialized
INFO - 2017-02-17 13:48:36 --> Form Validation Class Initialized
DEBUG - 2017-02-17 13:48:36 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:48:36 --> Final output sent to browser
DEBUG - 2017-02-17 13:48:36 --> Total execution time: 0.0756
INFO - 2017-02-17 13:49:06 --> Config Class Initialized
INFO - 2017-02-17 13:49:06 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:49:06 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:49:06 --> Utf8 Class Initialized
INFO - 2017-02-17 13:49:06 --> URI Class Initialized
INFO - 2017-02-17 13:49:06 --> Router Class Initialized
INFO - 2017-02-17 13:49:06 --> Output Class Initialized
INFO - 2017-02-17 13:49:06 --> Security Class Initialized
DEBUG - 2017-02-17 13:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:49:06 --> Input Class Initialized
INFO - 2017-02-17 13:49:06 --> Language Class Initialized
INFO - 2017-02-17 13:49:06 --> Language Class Initialized
INFO - 2017-02-17 13:49:06 --> Config Class Initialized
INFO - 2017-02-17 13:49:06 --> Loader Class Initialized
INFO - 2017-02-17 13:49:06 --> Helper loaded: form_helper
INFO - 2017-02-17 13:49:06 --> Helper loaded: url_helper
INFO - 2017-02-17 13:49:06 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:49:06 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:49:06 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:49:06 --> Template Class Initialized
INFO - 2017-02-17 13:49:06 --> Controller Class Initialized
DEBUG - 2017-02-17 13:49:06 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:49:06 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:49:06 --> Model Class Initialized
INFO - 2017-02-17 13:49:06 --> Form Validation Class Initialized
DEBUG - 2017-02-17 13:49:06 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:49:06 --> Final output sent to browser
DEBUG - 2017-02-17 13:49:06 --> Total execution time: 0.1386
INFO - 2017-02-17 13:49:08 --> Config Class Initialized
INFO - 2017-02-17 13:49:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:49:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:49:08 --> Utf8 Class Initialized
INFO - 2017-02-17 13:49:08 --> URI Class Initialized
INFO - 2017-02-17 13:49:08 --> Router Class Initialized
INFO - 2017-02-17 13:49:08 --> Output Class Initialized
INFO - 2017-02-17 13:49:08 --> Security Class Initialized
DEBUG - 2017-02-17 13:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:49:08 --> Input Class Initialized
INFO - 2017-02-17 13:49:08 --> Language Class Initialized
INFO - 2017-02-17 13:49:08 --> Language Class Initialized
INFO - 2017-02-17 13:49:08 --> Config Class Initialized
INFO - 2017-02-17 13:49:08 --> Loader Class Initialized
INFO - 2017-02-17 13:49:08 --> Helper loaded: form_helper
INFO - 2017-02-17 13:49:08 --> Helper loaded: url_helper
INFO - 2017-02-17 13:49:08 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:49:08 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:49:08 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:49:08 --> Template Class Initialized
INFO - 2017-02-17 13:49:08 --> Controller Class Initialized
DEBUG - 2017-02-17 13:49:08 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:49:08 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:49:08 --> Model Class Initialized
INFO - 2017-02-17 13:49:08 --> Form Validation Class Initialized
DEBUG - 2017-02-17 13:49:08 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:49:08 --> Final output sent to browser
DEBUG - 2017-02-17 13:49:08 --> Total execution time: 0.0399
INFO - 2017-02-17 13:49:11 --> Config Class Initialized
INFO - 2017-02-17 13:49:11 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:49:11 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:49:11 --> Utf8 Class Initialized
INFO - 2017-02-17 13:49:11 --> URI Class Initialized
DEBUG - 2017-02-17 13:49:11 --> No URI present. Default controller set.
INFO - 2017-02-17 13:49:11 --> Router Class Initialized
INFO - 2017-02-17 13:49:11 --> Output Class Initialized
INFO - 2017-02-17 13:49:11 --> Security Class Initialized
DEBUG - 2017-02-17 13:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:49:11 --> Input Class Initialized
INFO - 2017-02-17 13:49:11 --> Language Class Initialized
INFO - 2017-02-17 13:49:11 --> Language Class Initialized
INFO - 2017-02-17 13:49:11 --> Config Class Initialized
INFO - 2017-02-17 13:49:11 --> Loader Class Initialized
INFO - 2017-02-17 13:49:11 --> Helper loaded: form_helper
INFO - 2017-02-17 13:49:11 --> Helper loaded: url_helper
INFO - 2017-02-17 13:49:11 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:49:11 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:49:11 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:49:11 --> Template Class Initialized
INFO - 2017-02-17 13:49:11 --> Controller Class Initialized
INFO - 2017-02-17 13:49:11 --> Form Validation Class Initialized
INFO - 2017-02-17 13:49:11 --> Model Class Initialized
DEBUG - 2017-02-17 13:49:11 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 13:49:11 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 13:49:11 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 13:49:11 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 13:49:11 --> Final output sent to browser
DEBUG - 2017-02-17 13:49:11 --> Total execution time: 0.0400
INFO - 2017-02-17 13:49:14 --> Config Class Initialized
INFO - 2017-02-17 13:49:14 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:49:14 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:49:14 --> Utf8 Class Initialized
INFO - 2017-02-17 13:49:14 --> URI Class Initialized
INFO - 2017-02-17 13:49:14 --> Router Class Initialized
INFO - 2017-02-17 13:49:14 --> Output Class Initialized
INFO - 2017-02-17 13:49:14 --> Security Class Initialized
DEBUG - 2017-02-17 13:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:49:14 --> Input Class Initialized
INFO - 2017-02-17 13:49:14 --> Language Class Initialized
ERROR - 2017-02-17 13:49:14 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:49:19 --> Config Class Initialized
INFO - 2017-02-17 13:49:19 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:49:19 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:49:19 --> Utf8 Class Initialized
INFO - 2017-02-17 13:49:19 --> URI Class Initialized
INFO - 2017-02-17 13:49:19 --> Router Class Initialized
INFO - 2017-02-17 13:49:19 --> Output Class Initialized
INFO - 2017-02-17 13:49:19 --> Security Class Initialized
DEBUG - 2017-02-17 13:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:49:19 --> Input Class Initialized
INFO - 2017-02-17 13:49:19 --> Language Class Initialized
ERROR - 2017-02-17 13:49:19 --> 404 Page Not Found: /index
INFO - 2017-02-17 13:49:23 --> Config Class Initialized
INFO - 2017-02-17 13:49:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:49:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:49:23 --> Utf8 Class Initialized
INFO - 2017-02-17 13:49:23 --> URI Class Initialized
INFO - 2017-02-17 13:49:23 --> Router Class Initialized
INFO - 2017-02-17 13:49:23 --> Output Class Initialized
INFO - 2017-02-17 13:49:23 --> Security Class Initialized
DEBUG - 2017-02-17 13:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:49:23 --> Input Class Initialized
INFO - 2017-02-17 13:49:23 --> Language Class Initialized
INFO - 2017-02-17 13:49:23 --> Language Class Initialized
INFO - 2017-02-17 13:49:23 --> Config Class Initialized
INFO - 2017-02-17 13:49:23 --> Loader Class Initialized
INFO - 2017-02-17 13:49:23 --> Helper loaded: form_helper
INFO - 2017-02-17 13:49:23 --> Helper loaded: url_helper
INFO - 2017-02-17 13:49:23 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:49:23 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:49:23 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:49:23 --> Template Class Initialized
INFO - 2017-02-17 13:49:23 --> Controller Class Initialized
DEBUG - 2017-02-17 13:49:23 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:49:23 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:49:23 --> Model Class Initialized
INFO - 2017-02-17 13:49:23 --> Form Validation Class Initialized
DEBUG - 2017-02-17 13:49:23 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:49:23 --> Final output sent to browser
DEBUG - 2017-02-17 13:49:23 --> Total execution time: 0.0381
INFO - 2017-02-17 13:49:24 --> Config Class Initialized
INFO - 2017-02-17 13:49:24 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:49:24 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:49:24 --> Utf8 Class Initialized
INFO - 2017-02-17 13:49:24 --> URI Class Initialized
INFO - 2017-02-17 13:49:24 --> Router Class Initialized
INFO - 2017-02-17 13:49:24 --> Output Class Initialized
INFO - 2017-02-17 13:49:24 --> Security Class Initialized
DEBUG - 2017-02-17 13:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:49:24 --> Input Class Initialized
INFO - 2017-02-17 13:49:24 --> Language Class Initialized
INFO - 2017-02-17 13:49:24 --> Language Class Initialized
INFO - 2017-02-17 13:49:24 --> Config Class Initialized
INFO - 2017-02-17 13:49:24 --> Loader Class Initialized
INFO - 2017-02-17 13:49:24 --> Helper loaded: form_helper
INFO - 2017-02-17 13:49:24 --> Helper loaded: url_helper
INFO - 2017-02-17 13:49:24 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:49:24 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:49:24 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:49:24 --> Template Class Initialized
INFO - 2017-02-17 13:49:24 --> Controller Class Initialized
DEBUG - 2017-02-17 13:49:25 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:49:25 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:49:25 --> Model Class Initialized
INFO - 2017-02-17 13:49:25 --> Form Validation Class Initialized
INFO - 2017-02-17 13:49:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 13:49:25 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:49:25 --> Final output sent to browser
DEBUG - 2017-02-17 13:49:25 --> Total execution time: 0.0558
INFO - 2017-02-17 13:49:48 --> Config Class Initialized
INFO - 2017-02-17 13:49:48 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:49:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:49:48 --> Utf8 Class Initialized
INFO - 2017-02-17 13:49:48 --> URI Class Initialized
INFO - 2017-02-17 13:49:48 --> Router Class Initialized
INFO - 2017-02-17 13:49:48 --> Output Class Initialized
INFO - 2017-02-17 13:49:48 --> Security Class Initialized
DEBUG - 2017-02-17 13:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:49:48 --> Input Class Initialized
INFO - 2017-02-17 13:49:48 --> Language Class Initialized
INFO - 2017-02-17 13:49:48 --> Language Class Initialized
INFO - 2017-02-17 13:49:48 --> Config Class Initialized
INFO - 2017-02-17 13:49:48 --> Loader Class Initialized
INFO - 2017-02-17 13:49:48 --> Helper loaded: form_helper
INFO - 2017-02-17 13:49:48 --> Helper loaded: url_helper
INFO - 2017-02-17 13:49:48 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:49:48 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:49:48 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:49:48 --> Template Class Initialized
INFO - 2017-02-17 13:49:48 --> Controller Class Initialized
DEBUG - 2017-02-17 13:49:48 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:49:48 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:49:48 --> Model Class Initialized
INFO - 2017-02-17 13:49:48 --> Form Validation Class Initialized
INFO - 2017-02-17 13:49:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 13:49:48 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:49:48 --> Final output sent to browser
DEBUG - 2017-02-17 13:49:48 --> Total execution time: 0.0471
INFO - 2017-02-17 13:49:55 --> Config Class Initialized
INFO - 2017-02-17 13:49:55 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:49:55 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:49:55 --> Utf8 Class Initialized
INFO - 2017-02-17 13:49:55 --> URI Class Initialized
INFO - 2017-02-17 13:49:55 --> Router Class Initialized
INFO - 2017-02-17 13:49:55 --> Output Class Initialized
INFO - 2017-02-17 13:49:55 --> Security Class Initialized
DEBUG - 2017-02-17 13:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:49:55 --> Input Class Initialized
INFO - 2017-02-17 13:49:55 --> Language Class Initialized
INFO - 2017-02-17 13:49:55 --> Language Class Initialized
INFO - 2017-02-17 13:49:55 --> Config Class Initialized
INFO - 2017-02-17 13:49:55 --> Loader Class Initialized
INFO - 2017-02-17 13:49:55 --> Helper loaded: form_helper
INFO - 2017-02-17 13:49:55 --> Helper loaded: url_helper
INFO - 2017-02-17 13:49:55 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:49:55 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:49:55 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:49:55 --> Template Class Initialized
INFO - 2017-02-17 13:49:55 --> Controller Class Initialized
DEBUG - 2017-02-17 13:49:55 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:49:55 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:49:55 --> Model Class Initialized
INFO - 2017-02-17 13:49:55 --> Form Validation Class Initialized
INFO - 2017-02-17 13:49:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 13:49:55 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:49:55 --> Final output sent to browser
DEBUG - 2017-02-17 13:49:55 --> Total execution time: 0.0610
INFO - 2017-02-17 13:50:36 --> Config Class Initialized
INFO - 2017-02-17 13:50:36 --> Hooks Class Initialized
DEBUG - 2017-02-17 13:50:36 --> UTF-8 Support Enabled
INFO - 2017-02-17 13:50:36 --> Utf8 Class Initialized
INFO - 2017-02-17 13:50:36 --> URI Class Initialized
INFO - 2017-02-17 13:50:36 --> Router Class Initialized
INFO - 2017-02-17 13:50:36 --> Output Class Initialized
INFO - 2017-02-17 13:50:36 --> Security Class Initialized
DEBUG - 2017-02-17 13:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 13:50:36 --> Input Class Initialized
INFO - 2017-02-17 13:50:36 --> Language Class Initialized
INFO - 2017-02-17 13:50:36 --> Language Class Initialized
INFO - 2017-02-17 13:50:36 --> Config Class Initialized
INFO - 2017-02-17 13:50:36 --> Loader Class Initialized
INFO - 2017-02-17 13:50:36 --> Helper loaded: form_helper
INFO - 2017-02-17 13:50:36 --> Helper loaded: url_helper
INFO - 2017-02-17 13:50:36 --> Helper loaded: utility_helper
INFO - 2017-02-17 13:50:36 --> Database Driver Class Initialized
DEBUG - 2017-02-17 13:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 13:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 13:50:36 --> User Agent Class Initialized
DEBUG - 2017-02-17 13:50:36 --> Template Class Initialized
INFO - 2017-02-17 13:50:36 --> Controller Class Initialized
DEBUG - 2017-02-17 13:50:36 --> Login MX_Controller Initialized
INFO - 2017-02-17 13:50:36 --> Helper loaded: cookie_helper
INFO - 2017-02-17 13:50:36 --> Model Class Initialized
INFO - 2017-02-17 13:50:36 --> Form Validation Class Initialized
INFO - 2017-02-17 13:50:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2017-02-17 13:50:36 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 13:50:36 --> Final output sent to browser
DEBUG - 2017-02-17 13:50:36 --> Total execution time: 0.0411
INFO - 2017-02-17 14:04:43 --> Config Class Initialized
INFO - 2017-02-17 14:04:43 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:04:43 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:04:43 --> Utf8 Class Initialized
INFO - 2017-02-17 14:04:43 --> URI Class Initialized
INFO - 2017-02-17 14:04:43 --> Router Class Initialized
INFO - 2017-02-17 14:04:43 --> Output Class Initialized
INFO - 2017-02-17 14:04:43 --> Security Class Initialized
DEBUG - 2017-02-17 14:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:04:43 --> Input Class Initialized
INFO - 2017-02-17 14:04:43 --> Language Class Initialized
INFO - 2017-02-17 14:04:43 --> Language Class Initialized
INFO - 2017-02-17 14:04:43 --> Config Class Initialized
INFO - 2017-02-17 14:04:43 --> Loader Class Initialized
INFO - 2017-02-17 14:04:43 --> Helper loaded: form_helper
INFO - 2017-02-17 14:04:43 --> Helper loaded: url_helper
INFO - 2017-02-17 14:04:43 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:04:44 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:04:45 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:04:45 --> Template Class Initialized
INFO - 2017-02-17 14:04:45 --> Controller Class Initialized
DEBUG - 2017-02-17 14:04:45 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:04:45 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:04:45 --> Model Class Initialized
INFO - 2017-02-17 14:04:45 --> Form Validation Class Initialized
INFO - 2017-02-17 14:04:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 14:04:45 --> Config Class Initialized
INFO - 2017-02-17 14:04:45 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:04:45 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:04:45 --> Utf8 Class Initialized
INFO - 2017-02-17 14:04:45 --> URI Class Initialized
INFO - 2017-02-17 14:04:45 --> Router Class Initialized
INFO - 2017-02-17 14:04:45 --> Output Class Initialized
INFO - 2017-02-17 14:04:45 --> Security Class Initialized
DEBUG - 2017-02-17 14:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:04:45 --> Input Class Initialized
INFO - 2017-02-17 14:04:45 --> Language Class Initialized
INFO - 2017-02-17 14:04:45 --> Language Class Initialized
INFO - 2017-02-17 14:04:45 --> Config Class Initialized
INFO - 2017-02-17 14:04:45 --> Loader Class Initialized
INFO - 2017-02-17 14:04:45 --> Helper loaded: form_helper
INFO - 2017-02-17 14:04:45 --> Helper loaded: url_helper
INFO - 2017-02-17 14:04:45 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:04:45 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:04:45 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:04:45 --> Template Class Initialized
INFO - 2017-02-17 14:04:45 --> Controller Class Initialized
DEBUG - 2017-02-17 14:04:45 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:04:45 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:04:45 --> Model Class Initialized
INFO - 2017-02-17 14:04:45 --> Form Validation Class Initialized
ERROR - 2017-02-17 14:04:45 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\xampp\htdocs\razor\application\modules\backend\views\login.php 38
INFO - 2017-02-17 14:04:54 --> Config Class Initialized
INFO - 2017-02-17 14:04:54 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:04:54 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:04:54 --> Utf8 Class Initialized
INFO - 2017-02-17 14:04:54 --> URI Class Initialized
INFO - 2017-02-17 14:04:54 --> Router Class Initialized
INFO - 2017-02-17 14:04:54 --> Output Class Initialized
INFO - 2017-02-17 14:04:54 --> Security Class Initialized
DEBUG - 2017-02-17 14:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:04:54 --> Input Class Initialized
INFO - 2017-02-17 14:04:54 --> Language Class Initialized
INFO - 2017-02-17 14:04:54 --> Language Class Initialized
INFO - 2017-02-17 14:04:54 --> Config Class Initialized
INFO - 2017-02-17 14:04:54 --> Loader Class Initialized
INFO - 2017-02-17 14:04:54 --> Helper loaded: form_helper
INFO - 2017-02-17 14:04:54 --> Helper loaded: url_helper
INFO - 2017-02-17 14:04:54 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:04:54 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:04:54 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:04:54 --> Template Class Initialized
INFO - 2017-02-17 14:04:54 --> Controller Class Initialized
DEBUG - 2017-02-17 14:04:54 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:04:54 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:04:54 --> Model Class Initialized
INFO - 2017-02-17 14:04:54 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:04:54 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:04:54 --> Final output sent to browser
DEBUG - 2017-02-17 14:04:54 --> Total execution time: 0.1593
INFO - 2017-02-17 14:05:02 --> Config Class Initialized
INFO - 2017-02-17 14:05:02 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:05:02 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:05:02 --> Utf8 Class Initialized
INFO - 2017-02-17 14:05:02 --> URI Class Initialized
INFO - 2017-02-17 14:05:02 --> Router Class Initialized
INFO - 2017-02-17 14:05:02 --> Output Class Initialized
INFO - 2017-02-17 14:05:02 --> Security Class Initialized
DEBUG - 2017-02-17 14:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:05:02 --> Input Class Initialized
INFO - 2017-02-17 14:05:02 --> Language Class Initialized
INFO - 2017-02-17 14:05:02 --> Language Class Initialized
INFO - 2017-02-17 14:05:02 --> Config Class Initialized
INFO - 2017-02-17 14:05:02 --> Loader Class Initialized
INFO - 2017-02-17 14:05:02 --> Helper loaded: form_helper
INFO - 2017-02-17 14:05:02 --> Helper loaded: url_helper
INFO - 2017-02-17 14:05:02 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:05:02 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:05:02 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:05:02 --> Template Class Initialized
INFO - 2017-02-17 14:05:02 --> Controller Class Initialized
DEBUG - 2017-02-17 14:05:02 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:05:02 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:05:02 --> Model Class Initialized
INFO - 2017-02-17 14:05:02 --> Form Validation Class Initialized
INFO - 2017-02-17 14:05:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 14:05:03 --> Config Class Initialized
INFO - 2017-02-17 14:05:03 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:05:03 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:05:03 --> Utf8 Class Initialized
INFO - 2017-02-17 14:05:03 --> URI Class Initialized
INFO - 2017-02-17 14:05:03 --> Router Class Initialized
INFO - 2017-02-17 14:05:03 --> Output Class Initialized
INFO - 2017-02-17 14:05:03 --> Security Class Initialized
DEBUG - 2017-02-17 14:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:05:03 --> Input Class Initialized
INFO - 2017-02-17 14:05:03 --> Language Class Initialized
INFO - 2017-02-17 14:05:03 --> Language Class Initialized
INFO - 2017-02-17 14:05:03 --> Config Class Initialized
INFO - 2017-02-17 14:05:03 --> Loader Class Initialized
INFO - 2017-02-17 14:05:03 --> Helper loaded: form_helper
INFO - 2017-02-17 14:05:03 --> Helper loaded: url_helper
INFO - 2017-02-17 14:05:03 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:05:03 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:05:03 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:05:03 --> Template Class Initialized
INFO - 2017-02-17 14:05:03 --> Controller Class Initialized
DEBUG - 2017-02-17 14:05:03 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:05:03 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:05:03 --> Model Class Initialized
INFO - 2017-02-17 14:05:03 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:05:03 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:05:03 --> Final output sent to browser
DEBUG - 2017-02-17 14:05:03 --> Total execution time: 0.0720
INFO - 2017-02-17 14:05:09 --> Config Class Initialized
INFO - 2017-02-17 14:05:09 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:05:09 --> Utf8 Class Initialized
INFO - 2017-02-17 14:05:09 --> URI Class Initialized
INFO - 2017-02-17 14:05:09 --> Router Class Initialized
INFO - 2017-02-17 14:05:09 --> Output Class Initialized
INFO - 2017-02-17 14:05:09 --> Security Class Initialized
DEBUG - 2017-02-17 14:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:05:09 --> Input Class Initialized
INFO - 2017-02-17 14:05:09 --> Language Class Initialized
INFO - 2017-02-17 14:05:09 --> Language Class Initialized
INFO - 2017-02-17 14:05:09 --> Config Class Initialized
INFO - 2017-02-17 14:05:09 --> Loader Class Initialized
INFO - 2017-02-17 14:05:09 --> Helper loaded: form_helper
INFO - 2017-02-17 14:05:09 --> Helper loaded: url_helper
INFO - 2017-02-17 14:05:09 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:05:09 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:05:09 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:05:09 --> Template Class Initialized
INFO - 2017-02-17 14:05:09 --> Controller Class Initialized
DEBUG - 2017-02-17 14:05:09 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:05:09 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:05:09 --> Model Class Initialized
INFO - 2017-02-17 14:05:09 --> Form Validation Class Initialized
INFO - 2017-02-17 14:05:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 14:05:09 --> Config Class Initialized
INFO - 2017-02-17 14:05:09 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:05:09 --> Utf8 Class Initialized
INFO - 2017-02-17 14:05:09 --> URI Class Initialized
INFO - 2017-02-17 14:05:09 --> Router Class Initialized
INFO - 2017-02-17 14:05:09 --> Output Class Initialized
INFO - 2017-02-17 14:05:09 --> Security Class Initialized
DEBUG - 2017-02-17 14:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:05:09 --> Input Class Initialized
INFO - 2017-02-17 14:05:09 --> Language Class Initialized
INFO - 2017-02-17 14:05:09 --> Language Class Initialized
INFO - 2017-02-17 14:05:09 --> Config Class Initialized
INFO - 2017-02-17 14:05:09 --> Loader Class Initialized
INFO - 2017-02-17 14:05:09 --> Helper loaded: form_helper
INFO - 2017-02-17 14:05:09 --> Helper loaded: url_helper
INFO - 2017-02-17 14:05:09 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:05:09 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:05:09 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:05:09 --> Template Class Initialized
INFO - 2017-02-17 14:05:09 --> Controller Class Initialized
DEBUG - 2017-02-17 14:05:09 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:05:09 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:05:09 --> Model Class Initialized
INFO - 2017-02-17 14:05:09 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:05:09 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:05:09 --> Final output sent to browser
DEBUG - 2017-02-17 14:05:09 --> Total execution time: 0.0680
INFO - 2017-02-17 14:05:17 --> Config Class Initialized
INFO - 2017-02-17 14:05:17 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:05:17 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:05:17 --> Utf8 Class Initialized
INFO - 2017-02-17 14:05:17 --> URI Class Initialized
INFO - 2017-02-17 14:05:17 --> Router Class Initialized
INFO - 2017-02-17 14:05:17 --> Output Class Initialized
INFO - 2017-02-17 14:05:17 --> Security Class Initialized
DEBUG - 2017-02-17 14:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:05:17 --> Input Class Initialized
INFO - 2017-02-17 14:05:17 --> Language Class Initialized
INFO - 2017-02-17 14:05:17 --> Language Class Initialized
INFO - 2017-02-17 14:05:17 --> Config Class Initialized
INFO - 2017-02-17 14:05:17 --> Loader Class Initialized
INFO - 2017-02-17 14:05:17 --> Helper loaded: form_helper
INFO - 2017-02-17 14:05:17 --> Helper loaded: url_helper
INFO - 2017-02-17 14:05:17 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:05:17 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:05:17 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:05:17 --> Template Class Initialized
INFO - 2017-02-17 14:05:17 --> Controller Class Initialized
DEBUG - 2017-02-17 14:05:17 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:05:17 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:05:17 --> Model Class Initialized
INFO - 2017-02-17 14:05:17 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:05:17 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:05:17 --> Final output sent to browser
DEBUG - 2017-02-17 14:05:17 --> Total execution time: 0.0879
INFO - 2017-02-17 14:05:20 --> Config Class Initialized
INFO - 2017-02-17 14:05:20 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:05:20 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:05:20 --> Utf8 Class Initialized
INFO - 2017-02-17 14:05:20 --> URI Class Initialized
INFO - 2017-02-17 14:05:20 --> Router Class Initialized
INFO - 2017-02-17 14:05:20 --> Output Class Initialized
INFO - 2017-02-17 14:05:20 --> Security Class Initialized
DEBUG - 2017-02-17 14:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:05:20 --> Input Class Initialized
INFO - 2017-02-17 14:05:20 --> Language Class Initialized
INFO - 2017-02-17 14:05:20 --> Language Class Initialized
INFO - 2017-02-17 14:05:20 --> Config Class Initialized
INFO - 2017-02-17 14:05:20 --> Loader Class Initialized
INFO - 2017-02-17 14:05:20 --> Helper loaded: form_helper
INFO - 2017-02-17 14:05:20 --> Helper loaded: url_helper
INFO - 2017-02-17 14:05:20 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:05:20 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:05:20 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:05:20 --> Template Class Initialized
INFO - 2017-02-17 14:05:20 --> Controller Class Initialized
DEBUG - 2017-02-17 14:05:20 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:05:20 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:05:20 --> Model Class Initialized
INFO - 2017-02-17 14:05:20 --> Form Validation Class Initialized
INFO - 2017-02-17 14:05:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 14:05:20 --> Config Class Initialized
INFO - 2017-02-17 14:05:20 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:05:20 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:05:20 --> Utf8 Class Initialized
INFO - 2017-02-17 14:05:20 --> URI Class Initialized
INFO - 2017-02-17 14:05:20 --> Router Class Initialized
INFO - 2017-02-17 14:05:20 --> Output Class Initialized
INFO - 2017-02-17 14:05:20 --> Security Class Initialized
DEBUG - 2017-02-17 14:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:05:20 --> Input Class Initialized
INFO - 2017-02-17 14:05:20 --> Language Class Initialized
INFO - 2017-02-17 14:05:20 --> Language Class Initialized
INFO - 2017-02-17 14:05:20 --> Config Class Initialized
INFO - 2017-02-17 14:05:20 --> Loader Class Initialized
INFO - 2017-02-17 14:05:20 --> Helper loaded: form_helper
INFO - 2017-02-17 14:05:20 --> Helper loaded: url_helper
INFO - 2017-02-17 14:05:20 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:05:20 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:05:20 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:05:20 --> Template Class Initialized
INFO - 2017-02-17 14:05:20 --> Controller Class Initialized
DEBUG - 2017-02-17 14:05:20 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:05:20 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:05:20 --> Model Class Initialized
INFO - 2017-02-17 14:05:20 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:05:20 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:05:20 --> Final output sent to browser
DEBUG - 2017-02-17 14:05:20 --> Total execution time: 0.3039
INFO - 2017-02-17 14:05:47 --> Config Class Initialized
INFO - 2017-02-17 14:05:47 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:05:47 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:05:47 --> Utf8 Class Initialized
INFO - 2017-02-17 14:05:47 --> URI Class Initialized
INFO - 2017-02-17 14:05:47 --> Router Class Initialized
INFO - 2017-02-17 14:05:47 --> Output Class Initialized
INFO - 2017-02-17 14:05:47 --> Security Class Initialized
DEBUG - 2017-02-17 14:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:05:47 --> Input Class Initialized
INFO - 2017-02-17 14:05:47 --> Language Class Initialized
INFO - 2017-02-17 14:05:47 --> Language Class Initialized
INFO - 2017-02-17 14:05:47 --> Config Class Initialized
INFO - 2017-02-17 14:05:47 --> Loader Class Initialized
INFO - 2017-02-17 14:05:47 --> Helper loaded: form_helper
INFO - 2017-02-17 14:05:47 --> Helper loaded: url_helper
INFO - 2017-02-17 14:05:47 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:05:47 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:05:47 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:05:47 --> Template Class Initialized
INFO - 2017-02-17 14:05:47 --> Controller Class Initialized
DEBUG - 2017-02-17 14:05:47 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:05:47 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:05:47 --> Model Class Initialized
INFO - 2017-02-17 14:05:47 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:05:47 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:05:47 --> Final output sent to browser
DEBUG - 2017-02-17 14:05:47 --> Total execution time: 0.6375
INFO - 2017-02-17 14:05:49 --> Config Class Initialized
INFO - 2017-02-17 14:05:49 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:05:49 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:05:49 --> Utf8 Class Initialized
INFO - 2017-02-17 14:05:49 --> URI Class Initialized
INFO - 2017-02-17 14:05:49 --> Router Class Initialized
INFO - 2017-02-17 14:05:49 --> Output Class Initialized
INFO - 2017-02-17 14:05:49 --> Security Class Initialized
DEBUG - 2017-02-17 14:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:05:49 --> Input Class Initialized
INFO - 2017-02-17 14:05:49 --> Language Class Initialized
INFO - 2017-02-17 14:05:49 --> Language Class Initialized
INFO - 2017-02-17 14:05:49 --> Config Class Initialized
INFO - 2017-02-17 14:05:49 --> Loader Class Initialized
INFO - 2017-02-17 14:05:49 --> Helper loaded: form_helper
INFO - 2017-02-17 14:05:49 --> Helper loaded: url_helper
INFO - 2017-02-17 14:05:49 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:05:49 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:05:49 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:05:49 --> Template Class Initialized
INFO - 2017-02-17 14:05:49 --> Controller Class Initialized
DEBUG - 2017-02-17 14:05:49 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:05:49 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:05:49 --> Model Class Initialized
INFO - 2017-02-17 14:05:49 --> Form Validation Class Initialized
INFO - 2017-02-17 14:05:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 14:05:49 --> Config Class Initialized
INFO - 2017-02-17 14:05:49 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:05:49 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:05:49 --> Utf8 Class Initialized
INFO - 2017-02-17 14:05:49 --> URI Class Initialized
INFO - 2017-02-17 14:05:49 --> Router Class Initialized
INFO - 2017-02-17 14:05:49 --> Output Class Initialized
INFO - 2017-02-17 14:05:49 --> Security Class Initialized
DEBUG - 2017-02-17 14:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:05:49 --> Input Class Initialized
INFO - 2017-02-17 14:05:49 --> Language Class Initialized
INFO - 2017-02-17 14:05:49 --> Language Class Initialized
INFO - 2017-02-17 14:05:49 --> Config Class Initialized
INFO - 2017-02-17 14:05:49 --> Loader Class Initialized
INFO - 2017-02-17 14:05:49 --> Helper loaded: form_helper
INFO - 2017-02-17 14:05:49 --> Helper loaded: url_helper
INFO - 2017-02-17 14:05:49 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:05:49 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:05:49 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:05:49 --> Template Class Initialized
INFO - 2017-02-17 14:05:49 --> Controller Class Initialized
DEBUG - 2017-02-17 14:05:49 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:05:49 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:05:49 --> Model Class Initialized
INFO - 2017-02-17 14:05:49 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:05:49 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:05:49 --> Final output sent to browser
DEBUG - 2017-02-17 14:05:49 --> Total execution time: 0.0611
INFO - 2017-02-17 14:05:59 --> Config Class Initialized
INFO - 2017-02-17 14:05:59 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:05:59 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:05:59 --> Utf8 Class Initialized
INFO - 2017-02-17 14:05:59 --> URI Class Initialized
INFO - 2017-02-17 14:05:59 --> Router Class Initialized
INFO - 2017-02-17 14:05:59 --> Output Class Initialized
INFO - 2017-02-17 14:05:59 --> Security Class Initialized
DEBUG - 2017-02-17 14:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:05:59 --> Input Class Initialized
INFO - 2017-02-17 14:05:59 --> Language Class Initialized
INFO - 2017-02-17 14:05:59 --> Language Class Initialized
INFO - 2017-02-17 14:05:59 --> Config Class Initialized
INFO - 2017-02-17 14:05:59 --> Loader Class Initialized
INFO - 2017-02-17 14:05:59 --> Helper loaded: form_helper
INFO - 2017-02-17 14:05:59 --> Helper loaded: url_helper
INFO - 2017-02-17 14:05:59 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:05:59 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:05:59 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:05:59 --> Template Class Initialized
INFO - 2017-02-17 14:05:59 --> Controller Class Initialized
DEBUG - 2017-02-17 14:05:59 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:05:59 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:05:59 --> Model Class Initialized
INFO - 2017-02-17 14:05:59 --> Form Validation Class Initialized
INFO - 2017-02-17 14:05:59 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 14:05:59 --> Severity: Notice --> Undefined index: first_name C:\xampp\htdocs\razor\application\modules\backend\controllers\Login.php 40
ERROR - 2017-02-17 14:05:59 --> Severity: Notice --> Undefined index: last_name C:\xampp\htdocs\razor\application\modules\backend\controllers\Login.php 41
ERROR - 2017-02-17 14:05:59 --> Severity: Notice --> Undefined index: mobile C:\xampp\htdocs\razor\application\modules\backend\controllers\Login.php 43
INFO - 2017-02-17 14:05:59 --> Config Class Initialized
INFO - 2017-02-17 14:05:59 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:05:59 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:05:59 --> Utf8 Class Initialized
INFO - 2017-02-17 14:05:59 --> URI Class Initialized
INFO - 2017-02-17 14:05:59 --> Router Class Initialized
INFO - 2017-02-17 14:05:59 --> Output Class Initialized
INFO - 2017-02-17 14:05:59 --> Security Class Initialized
DEBUG - 2017-02-17 14:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:05:59 --> Input Class Initialized
INFO - 2017-02-17 14:05:59 --> Language Class Initialized
INFO - 2017-02-17 14:05:59 --> Language Class Initialized
INFO - 2017-02-17 14:05:59 --> Config Class Initialized
INFO - 2017-02-17 14:05:59 --> Loader Class Initialized
INFO - 2017-02-17 14:06:00 --> Helper loaded: form_helper
INFO - 2017-02-17 14:06:00 --> Helper loaded: url_helper
INFO - 2017-02-17 14:06:00 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:06:00 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:06:00 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:06:00 --> Template Class Initialized
INFO - 2017-02-17 14:06:00 --> Controller Class Initialized
DEBUG - 2017-02-17 14:06:00 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 14:06:00 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:06:00 --> Model Class Initialized
DEBUG - 2017-02-17 14:06:00 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 14:06:00 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 14:06:00 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 14:06:00 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-17 14:06:00 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 14:06:00 --> Final output sent to browser
DEBUG - 2017-02-17 14:06:00 --> Total execution time: 0.5711
INFO - 2017-02-17 14:06:01 --> Config Class Initialized
INFO - 2017-02-17 14:06:01 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:06:01 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:06:01 --> Utf8 Class Initialized
INFO - 2017-02-17 14:06:01 --> URI Class Initialized
INFO - 2017-02-17 14:06:01 --> Router Class Initialized
INFO - 2017-02-17 14:06:01 --> Output Class Initialized
INFO - 2017-02-17 14:06:01 --> Security Class Initialized
DEBUG - 2017-02-17 14:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:06:01 --> Input Class Initialized
INFO - 2017-02-17 14:06:01 --> Language Class Initialized
ERROR - 2017-02-17 14:06:01 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-17 14:06:09 --> Config Class Initialized
INFO - 2017-02-17 14:06:09 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:06:09 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:06:09 --> Utf8 Class Initialized
INFO - 2017-02-17 14:06:09 --> URI Class Initialized
INFO - 2017-02-17 14:06:09 --> Router Class Initialized
INFO - 2017-02-17 14:06:09 --> Output Class Initialized
INFO - 2017-02-17 14:06:09 --> Security Class Initialized
DEBUG - 2017-02-17 14:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:06:09 --> Input Class Initialized
INFO - 2017-02-17 14:06:09 --> Language Class Initialized
INFO - 2017-02-17 14:06:09 --> Language Class Initialized
INFO - 2017-02-17 14:06:09 --> Config Class Initialized
INFO - 2017-02-17 14:06:09 --> Loader Class Initialized
INFO - 2017-02-17 14:06:09 --> Helper loaded: form_helper
INFO - 2017-02-17 14:06:09 --> Helper loaded: url_helper
INFO - 2017-02-17 14:06:10 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:06:10 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:06:10 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:06:10 --> Template Class Initialized
INFO - 2017-02-17 14:06:10 --> Controller Class Initialized
INFO - 2017-02-17 14:06:10 --> Form Validation Class Initialized
INFO - 2017-02-17 14:06:10 --> Model Class Initialized
DEBUG - 2017-02-17 14:06:10 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 14:06:10 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 14:06:10 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-17 14:06:10 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 14:06:10 --> Final output sent to browser
DEBUG - 2017-02-17 14:06:10 --> Total execution time: 0.8299
INFO - 2017-02-17 14:09:05 --> Config Class Initialized
INFO - 2017-02-17 14:09:05 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:09:05 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:09:05 --> Utf8 Class Initialized
INFO - 2017-02-17 14:09:05 --> URI Class Initialized
INFO - 2017-02-17 14:09:05 --> Router Class Initialized
INFO - 2017-02-17 14:09:05 --> Output Class Initialized
INFO - 2017-02-17 14:09:05 --> Security Class Initialized
DEBUG - 2017-02-17 14:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:09:05 --> Input Class Initialized
INFO - 2017-02-17 14:09:05 --> Language Class Initialized
INFO - 2017-02-17 14:09:05 --> Language Class Initialized
INFO - 2017-02-17 14:09:05 --> Config Class Initialized
INFO - 2017-02-17 14:09:05 --> Loader Class Initialized
INFO - 2017-02-17 14:09:05 --> Helper loaded: form_helper
INFO - 2017-02-17 14:09:05 --> Helper loaded: url_helper
INFO - 2017-02-17 14:09:05 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:09:05 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:09:05 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:09:05 --> Template Class Initialized
INFO - 2017-02-17 14:09:05 --> Controller Class Initialized
DEBUG - 2017-02-17 14:09:05 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:09:05 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:09:05 --> Model Class Initialized
INFO - 2017-02-17 14:09:05 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:09:05 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:09:05 --> Final output sent to browser
DEBUG - 2017-02-17 14:09:05 --> Total execution time: 0.1312
INFO - 2017-02-17 14:09:10 --> Config Class Initialized
INFO - 2017-02-17 14:09:10 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:09:10 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:09:10 --> Utf8 Class Initialized
INFO - 2017-02-17 14:09:10 --> URI Class Initialized
INFO - 2017-02-17 14:09:10 --> Router Class Initialized
INFO - 2017-02-17 14:09:10 --> Output Class Initialized
INFO - 2017-02-17 14:09:10 --> Security Class Initialized
DEBUG - 2017-02-17 14:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:09:10 --> Input Class Initialized
INFO - 2017-02-17 14:09:10 --> Language Class Initialized
INFO - 2017-02-17 14:09:10 --> Language Class Initialized
INFO - 2017-02-17 14:09:10 --> Config Class Initialized
INFO - 2017-02-17 14:09:10 --> Loader Class Initialized
INFO - 2017-02-17 14:09:10 --> Helper loaded: form_helper
INFO - 2017-02-17 14:09:10 --> Helper loaded: url_helper
INFO - 2017-02-17 14:09:10 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:09:10 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:09:10 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:09:10 --> Template Class Initialized
INFO - 2017-02-17 14:09:10 --> Controller Class Initialized
DEBUG - 2017-02-17 14:09:10 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:09:10 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:09:10 --> Model Class Initialized
INFO - 2017-02-17 14:09:10 --> Form Validation Class Initialized
INFO - 2017-02-17 14:09:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 14:09:10 --> Severity: Notice --> Undefined index: first_name C:\xampp\htdocs\razor\application\modules\backend\controllers\Login.php 40
ERROR - 2017-02-17 14:09:10 --> Severity: Notice --> Undefined index: last_name C:\xampp\htdocs\razor\application\modules\backend\controllers\Login.php 41
ERROR - 2017-02-17 14:09:10 --> Severity: Notice --> Undefined index: mobile C:\xampp\htdocs\razor\application\modules\backend\controllers\Login.php 43
INFO - 2017-02-17 14:09:10 --> Config Class Initialized
INFO - 2017-02-17 14:09:10 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:09:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:09:12 --> Utf8 Class Initialized
INFO - 2017-02-17 14:09:12 --> URI Class Initialized
INFO - 2017-02-17 14:09:12 --> Router Class Initialized
INFO - 2017-02-17 14:09:12 --> Output Class Initialized
INFO - 2017-02-17 14:09:12 --> Security Class Initialized
DEBUG - 2017-02-17 14:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:09:12 --> Input Class Initialized
INFO - 2017-02-17 14:09:12 --> Language Class Initialized
ERROR - 2017-02-17 14:09:12 --> 404 Page Not Found: /index
INFO - 2017-02-17 14:10:29 --> Config Class Initialized
INFO - 2017-02-17 14:10:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:10:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:10:29 --> Utf8 Class Initialized
INFO - 2017-02-17 14:10:29 --> URI Class Initialized
INFO - 2017-02-17 14:10:29 --> Router Class Initialized
INFO - 2017-02-17 14:10:29 --> Output Class Initialized
INFO - 2017-02-17 14:10:29 --> Security Class Initialized
DEBUG - 2017-02-17 14:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:10:29 --> Input Class Initialized
INFO - 2017-02-17 14:10:29 --> Language Class Initialized
INFO - 2017-02-17 14:10:29 --> Language Class Initialized
INFO - 2017-02-17 14:10:29 --> Config Class Initialized
INFO - 2017-02-17 14:10:29 --> Loader Class Initialized
INFO - 2017-02-17 14:10:29 --> Helper loaded: form_helper
INFO - 2017-02-17 14:10:29 --> Helper loaded: url_helper
INFO - 2017-02-17 14:10:29 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:10:29 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:10:29 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:10:29 --> Template Class Initialized
INFO - 2017-02-17 14:10:29 --> Controller Class Initialized
DEBUG - 2017-02-17 14:10:29 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:10:29 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:10:29 --> Model Class Initialized
INFO - 2017-02-17 14:10:29 --> Form Validation Class Initialized
INFO - 2017-02-17 14:10:29 --> Config Class Initialized
INFO - 2017-02-17 14:10:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:10:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:10:29 --> Utf8 Class Initialized
INFO - 2017-02-17 14:10:29 --> URI Class Initialized
INFO - 2017-02-17 14:10:29 --> Router Class Initialized
INFO - 2017-02-17 14:10:29 --> Output Class Initialized
INFO - 2017-02-17 14:10:29 --> Security Class Initialized
DEBUG - 2017-02-17 14:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:10:29 --> Input Class Initialized
INFO - 2017-02-17 14:10:29 --> Language Class Initialized
INFO - 2017-02-17 14:10:29 --> Language Class Initialized
INFO - 2017-02-17 14:10:29 --> Config Class Initialized
INFO - 2017-02-17 14:10:29 --> Loader Class Initialized
INFO - 2017-02-17 14:10:29 --> Helper loaded: form_helper
INFO - 2017-02-17 14:10:29 --> Helper loaded: url_helper
INFO - 2017-02-17 14:10:29 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:10:29 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:10:29 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:10:29 --> Template Class Initialized
INFO - 2017-02-17 14:10:29 --> Controller Class Initialized
DEBUG - 2017-02-17 14:10:29 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:10:29 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:10:29 --> Model Class Initialized
INFO - 2017-02-17 14:10:29 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:10:29 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:10:29 --> Final output sent to browser
DEBUG - 2017-02-17 14:10:29 --> Total execution time: 0.0812
INFO - 2017-02-17 14:10:51 --> Config Class Initialized
INFO - 2017-02-17 14:10:51 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:10:51 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:10:51 --> Utf8 Class Initialized
INFO - 2017-02-17 14:10:51 --> URI Class Initialized
INFO - 2017-02-17 14:10:51 --> Router Class Initialized
INFO - 2017-02-17 14:10:51 --> Output Class Initialized
INFO - 2017-02-17 14:10:51 --> Security Class Initialized
DEBUG - 2017-02-17 14:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:10:51 --> Input Class Initialized
INFO - 2017-02-17 14:10:51 --> Language Class Initialized
INFO - 2017-02-17 14:10:51 --> Language Class Initialized
INFO - 2017-02-17 14:10:51 --> Config Class Initialized
INFO - 2017-02-17 14:10:51 --> Loader Class Initialized
INFO - 2017-02-17 14:10:51 --> Helper loaded: form_helper
INFO - 2017-02-17 14:10:51 --> Helper loaded: url_helper
INFO - 2017-02-17 14:10:51 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:10:51 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:10:51 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:10:51 --> Template Class Initialized
INFO - 2017-02-17 14:10:51 --> Controller Class Initialized
DEBUG - 2017-02-17 14:10:51 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:10:51 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:10:51 --> Model Class Initialized
INFO - 2017-02-17 14:10:51 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:10:51 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:10:51 --> Final output sent to browser
DEBUG - 2017-02-17 14:10:51 --> Total execution time: 0.0643
INFO - 2017-02-17 14:10:54 --> Config Class Initialized
INFO - 2017-02-17 14:10:54 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:10:54 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:10:54 --> Utf8 Class Initialized
INFO - 2017-02-17 14:10:54 --> URI Class Initialized
INFO - 2017-02-17 14:10:54 --> Router Class Initialized
INFO - 2017-02-17 14:10:54 --> Output Class Initialized
INFO - 2017-02-17 14:10:54 --> Security Class Initialized
DEBUG - 2017-02-17 14:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:10:54 --> Input Class Initialized
INFO - 2017-02-17 14:10:54 --> Language Class Initialized
INFO - 2017-02-17 14:10:54 --> Language Class Initialized
INFO - 2017-02-17 14:10:54 --> Config Class Initialized
INFO - 2017-02-17 14:10:54 --> Loader Class Initialized
INFO - 2017-02-17 14:10:54 --> Helper loaded: form_helper
INFO - 2017-02-17 14:10:54 --> Helper loaded: url_helper
INFO - 2017-02-17 14:10:54 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:10:54 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:10:54 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:10:54 --> Template Class Initialized
INFO - 2017-02-17 14:10:54 --> Controller Class Initialized
DEBUG - 2017-02-17 14:10:54 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:10:54 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:10:54 --> Model Class Initialized
INFO - 2017-02-17 14:10:54 --> Form Validation Class Initialized
INFO - 2017-02-17 14:10:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 14:10:54 --> Severity: Notice --> Undefined index: first_name C:\xampp\htdocs\razor\application\modules\backend\controllers\Login.php 40
ERROR - 2017-02-17 14:10:54 --> Severity: Notice --> Undefined index: last_name C:\xampp\htdocs\razor\application\modules\backend\controllers\Login.php 41
ERROR - 2017-02-17 14:10:54 --> Severity: Notice --> Undefined index: mobile C:\xampp\htdocs\razor\application\modules\backend\controllers\Login.php 43
INFO - 2017-02-17 14:10:55 --> Config Class Initialized
INFO - 2017-02-17 14:10:55 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:10:55 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:10:55 --> Utf8 Class Initialized
INFO - 2017-02-17 14:10:55 --> URI Class Initialized
INFO - 2017-02-17 14:10:55 --> Router Class Initialized
INFO - 2017-02-17 14:10:55 --> Output Class Initialized
INFO - 2017-02-17 14:10:55 --> Security Class Initialized
DEBUG - 2017-02-17 14:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:10:55 --> Input Class Initialized
INFO - 2017-02-17 14:10:55 --> Language Class Initialized
INFO - 2017-02-17 14:10:55 --> Language Class Initialized
INFO - 2017-02-17 14:10:55 --> Config Class Initialized
INFO - 2017-02-17 14:10:55 --> Loader Class Initialized
INFO - 2017-02-17 14:10:55 --> Helper loaded: form_helper
INFO - 2017-02-17 14:10:55 --> Helper loaded: url_helper
INFO - 2017-02-17 14:10:55 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:10:55 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:10:55 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:10:55 --> Template Class Initialized
INFO - 2017-02-17 14:10:55 --> Controller Class Initialized
DEBUG - 2017-02-17 14:10:55 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 14:10:55 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:10:55 --> Model Class Initialized
DEBUG - 2017-02-17 14:10:55 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 14:10:55 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 14:10:55 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
INFO - 2017-02-17 14:12:41 --> Config Class Initialized
INFO - 2017-02-17 14:12:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:12:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:12:41 --> Utf8 Class Initialized
INFO - 2017-02-17 14:12:41 --> URI Class Initialized
INFO - 2017-02-17 14:12:41 --> Router Class Initialized
INFO - 2017-02-17 14:12:41 --> Output Class Initialized
INFO - 2017-02-17 14:12:41 --> Security Class Initialized
DEBUG - 2017-02-17 14:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:12:41 --> Input Class Initialized
INFO - 2017-02-17 14:12:41 --> Language Class Initialized
INFO - 2017-02-17 14:12:41 --> Language Class Initialized
INFO - 2017-02-17 14:12:41 --> Config Class Initialized
INFO - 2017-02-17 14:12:41 --> Loader Class Initialized
INFO - 2017-02-17 14:12:41 --> Helper loaded: form_helper
INFO - 2017-02-17 14:12:41 --> Helper loaded: url_helper
INFO - 2017-02-17 14:12:41 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:12:41 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:12:41 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:12:41 --> Template Class Initialized
INFO - 2017-02-17 14:12:41 --> Controller Class Initialized
DEBUG - 2017-02-17 14:12:41 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 14:12:41 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:12:41 --> Model Class Initialized
DEBUG - 2017-02-17 14:12:41 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 14:12:41 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 14:12:41 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 14:12:41 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-17 14:12:41 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 14:12:41 --> Final output sent to browser
DEBUG - 2017-02-17 14:12:41 --> Total execution time: 0.5202
INFO - 2017-02-17 14:12:42 --> Config Class Initialized
INFO - 2017-02-17 14:12:42 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:12:42 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:12:42 --> Utf8 Class Initialized
INFO - 2017-02-17 14:12:42 --> URI Class Initialized
INFO - 2017-02-17 14:12:42 --> Router Class Initialized
INFO - 2017-02-17 14:12:42 --> Output Class Initialized
INFO - 2017-02-17 14:12:42 --> Security Class Initialized
DEBUG - 2017-02-17 14:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:12:42 --> Input Class Initialized
INFO - 2017-02-17 14:12:42 --> Language Class Initialized
ERROR - 2017-02-17 14:12:42 --> 404 Page Not Found: /index
INFO - 2017-02-17 14:13:08 --> Config Class Initialized
INFO - 2017-02-17 14:13:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:13:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:13:08 --> Utf8 Class Initialized
INFO - 2017-02-17 14:13:08 --> URI Class Initialized
INFO - 2017-02-17 14:13:08 --> Router Class Initialized
INFO - 2017-02-17 14:13:08 --> Output Class Initialized
INFO - 2017-02-17 14:13:08 --> Security Class Initialized
DEBUG - 2017-02-17 14:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:13:08 --> Input Class Initialized
INFO - 2017-02-17 14:13:08 --> Language Class Initialized
INFO - 2017-02-17 14:13:08 --> Language Class Initialized
INFO - 2017-02-17 14:13:08 --> Config Class Initialized
INFO - 2017-02-17 14:13:08 --> Loader Class Initialized
INFO - 2017-02-17 14:13:08 --> Helper loaded: form_helper
INFO - 2017-02-17 14:13:08 --> Helper loaded: url_helper
INFO - 2017-02-17 14:13:08 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:13:08 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:13:08 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:13:08 --> Template Class Initialized
INFO - 2017-02-17 14:13:08 --> Controller Class Initialized
DEBUG - 2017-02-17 14:13:08 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 14:13:08 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:13:08 --> Model Class Initialized
DEBUG - 2017-02-17 14:13:08 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 14:13:08 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 14:13:08 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 14:13:08 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-17 14:13:08 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 14:13:08 --> Final output sent to browser
DEBUG - 2017-02-17 14:13:08 --> Total execution time: 0.1191
INFO - 2017-02-17 14:13:08 --> Config Class Initialized
INFO - 2017-02-17 14:13:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:13:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:13:08 --> Utf8 Class Initialized
INFO - 2017-02-17 14:13:08 --> URI Class Initialized
INFO - 2017-02-17 14:13:08 --> Router Class Initialized
INFO - 2017-02-17 14:13:08 --> Output Class Initialized
INFO - 2017-02-17 14:13:08 --> Security Class Initialized
DEBUG - 2017-02-17 14:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:13:08 --> Input Class Initialized
INFO - 2017-02-17 14:13:08 --> Language Class Initialized
ERROR - 2017-02-17 14:13:08 --> 404 Page Not Found: /index
INFO - 2017-02-17 14:13:10 --> Config Class Initialized
INFO - 2017-02-17 14:13:10 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:13:10 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:13:10 --> Utf8 Class Initialized
INFO - 2017-02-17 14:13:10 --> URI Class Initialized
INFO - 2017-02-17 14:13:10 --> Router Class Initialized
INFO - 2017-02-17 14:13:10 --> Output Class Initialized
INFO - 2017-02-17 14:13:10 --> Security Class Initialized
DEBUG - 2017-02-17 14:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:13:10 --> Input Class Initialized
INFO - 2017-02-17 14:13:10 --> Language Class Initialized
INFO - 2017-02-17 14:13:10 --> Language Class Initialized
INFO - 2017-02-17 14:13:10 --> Config Class Initialized
INFO - 2017-02-17 14:13:10 --> Loader Class Initialized
INFO - 2017-02-17 14:13:10 --> Helper loaded: form_helper
INFO - 2017-02-17 14:13:10 --> Helper loaded: url_helper
INFO - 2017-02-17 14:13:10 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:13:10 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:13:10 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:13:10 --> Template Class Initialized
INFO - 2017-02-17 14:13:10 --> Controller Class Initialized
DEBUG - 2017-02-17 14:13:10 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 14:13:10 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:13:10 --> Model Class Initialized
DEBUG - 2017-02-17 14:13:10 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 14:13:10 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 14:13:10 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 14:13:10 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-17 14:13:10 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 14:13:10 --> Final output sent to browser
DEBUG - 2017-02-17 14:13:10 --> Total execution time: 0.0705
INFO - 2017-02-17 14:13:10 --> Config Class Initialized
INFO - 2017-02-17 14:13:10 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:13:10 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:13:10 --> Utf8 Class Initialized
INFO - 2017-02-17 14:13:10 --> URI Class Initialized
INFO - 2017-02-17 14:13:10 --> Router Class Initialized
INFO - 2017-02-17 14:13:10 --> Output Class Initialized
INFO - 2017-02-17 14:13:10 --> Security Class Initialized
DEBUG - 2017-02-17 14:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:13:10 --> Input Class Initialized
INFO - 2017-02-17 14:13:10 --> Language Class Initialized
ERROR - 2017-02-17 14:13:10 --> 404 Page Not Found: /index
INFO - 2017-02-17 14:13:31 --> Config Class Initialized
INFO - 2017-02-17 14:13:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:13:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:13:31 --> Utf8 Class Initialized
INFO - 2017-02-17 14:13:31 --> URI Class Initialized
INFO - 2017-02-17 14:13:31 --> Router Class Initialized
INFO - 2017-02-17 14:13:31 --> Output Class Initialized
INFO - 2017-02-17 14:13:31 --> Security Class Initialized
DEBUG - 2017-02-17 14:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:13:31 --> Input Class Initialized
INFO - 2017-02-17 14:13:31 --> Language Class Initialized
INFO - 2017-02-17 14:13:31 --> Language Class Initialized
INFO - 2017-02-17 14:13:31 --> Config Class Initialized
INFO - 2017-02-17 14:13:31 --> Loader Class Initialized
INFO - 2017-02-17 14:13:31 --> Helper loaded: form_helper
INFO - 2017-02-17 14:13:31 --> Helper loaded: url_helper
INFO - 2017-02-17 14:13:31 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:13:31 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:13:31 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:13:31 --> Template Class Initialized
INFO - 2017-02-17 14:13:31 --> Controller Class Initialized
DEBUG - 2017-02-17 14:13:31 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 14:13:31 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:13:31 --> Model Class Initialized
DEBUG - 2017-02-17 14:13:31 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 14:13:31 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 14:13:31 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 14:13:31 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-17 14:13:31 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 14:13:31 --> Final output sent to browser
DEBUG - 2017-02-17 14:13:31 --> Total execution time: 0.0521
INFO - 2017-02-17 14:13:31 --> Config Class Initialized
INFO - 2017-02-17 14:13:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:13:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:13:31 --> Utf8 Class Initialized
INFO - 2017-02-17 14:13:31 --> URI Class Initialized
INFO - 2017-02-17 14:13:31 --> Router Class Initialized
INFO - 2017-02-17 14:13:31 --> Output Class Initialized
INFO - 2017-02-17 14:13:31 --> Security Class Initialized
DEBUG - 2017-02-17 14:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:13:31 --> Input Class Initialized
INFO - 2017-02-17 14:13:31 --> Language Class Initialized
ERROR - 2017-02-17 14:13:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 14:13:41 --> Config Class Initialized
INFO - 2017-02-17 14:13:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:13:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:13:41 --> Utf8 Class Initialized
INFO - 2017-02-17 14:13:41 --> URI Class Initialized
INFO - 2017-02-17 14:13:41 --> Router Class Initialized
INFO - 2017-02-17 14:13:41 --> Output Class Initialized
INFO - 2017-02-17 14:13:41 --> Security Class Initialized
DEBUG - 2017-02-17 14:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:13:41 --> Input Class Initialized
INFO - 2017-02-17 14:13:41 --> Language Class Initialized
INFO - 2017-02-17 14:13:41 --> Language Class Initialized
INFO - 2017-02-17 14:13:41 --> Config Class Initialized
INFO - 2017-02-17 14:13:41 --> Loader Class Initialized
INFO - 2017-02-17 14:13:41 --> Helper loaded: form_helper
INFO - 2017-02-17 14:13:41 --> Helper loaded: url_helper
INFO - 2017-02-17 14:13:41 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:13:41 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:13:41 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:13:41 --> Template Class Initialized
INFO - 2017-02-17 14:13:41 --> Controller Class Initialized
DEBUG - 2017-02-17 14:13:41 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 14:13:41 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:13:41 --> Model Class Initialized
DEBUG - 2017-02-17 14:13:41 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 14:13:41 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 14:13:41 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 14:13:41 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-17 14:13:41 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 14:13:41 --> Final output sent to browser
DEBUG - 2017-02-17 14:13:41 --> Total execution time: 0.0544
INFO - 2017-02-17 14:13:41 --> Config Class Initialized
INFO - 2017-02-17 14:13:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:13:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:13:41 --> Utf8 Class Initialized
INFO - 2017-02-17 14:13:41 --> URI Class Initialized
INFO - 2017-02-17 14:13:41 --> Router Class Initialized
INFO - 2017-02-17 14:13:41 --> Output Class Initialized
INFO - 2017-02-17 14:13:41 --> Security Class Initialized
DEBUG - 2017-02-17 14:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:13:41 --> Input Class Initialized
INFO - 2017-02-17 14:13:41 --> Language Class Initialized
ERROR - 2017-02-17 14:13:41 --> 404 Page Not Found: /index
INFO - 2017-02-17 14:13:42 --> Config Class Initialized
INFO - 2017-02-17 14:13:42 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:13:42 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:13:42 --> Utf8 Class Initialized
INFO - 2017-02-17 14:13:42 --> URI Class Initialized
INFO - 2017-02-17 14:13:42 --> Router Class Initialized
INFO - 2017-02-17 14:13:42 --> Output Class Initialized
INFO - 2017-02-17 14:13:42 --> Security Class Initialized
DEBUG - 2017-02-17 14:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:13:42 --> Input Class Initialized
INFO - 2017-02-17 14:13:42 --> Language Class Initialized
INFO - 2017-02-17 14:13:42 --> Language Class Initialized
INFO - 2017-02-17 14:13:42 --> Config Class Initialized
INFO - 2017-02-17 14:13:42 --> Loader Class Initialized
INFO - 2017-02-17 14:13:42 --> Helper loaded: form_helper
INFO - 2017-02-17 14:13:42 --> Helper loaded: url_helper
INFO - 2017-02-17 14:13:42 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:13:42 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:13:42 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:13:42 --> Template Class Initialized
INFO - 2017-02-17 14:13:42 --> Controller Class Initialized
DEBUG - 2017-02-17 14:13:42 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 14:13:42 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:13:42 --> Model Class Initialized
DEBUG - 2017-02-17 14:13:42 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 14:13:42 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 14:13:42 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 14:13:42 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-17 14:13:42 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 14:13:42 --> Final output sent to browser
DEBUG - 2017-02-17 14:13:42 --> Total execution time: 0.0474
INFO - 2017-02-17 14:13:42 --> Config Class Initialized
INFO - 2017-02-17 14:13:42 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:13:42 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:13:42 --> Utf8 Class Initialized
INFO - 2017-02-17 14:13:42 --> URI Class Initialized
INFO - 2017-02-17 14:13:42 --> Router Class Initialized
INFO - 2017-02-17 14:13:42 --> Output Class Initialized
INFO - 2017-02-17 14:13:42 --> Security Class Initialized
DEBUG - 2017-02-17 14:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:13:42 --> Input Class Initialized
INFO - 2017-02-17 14:13:42 --> Language Class Initialized
ERROR - 2017-02-17 14:13:42 --> 404 Page Not Found: /index
INFO - 2017-02-17 14:13:56 --> Config Class Initialized
INFO - 2017-02-17 14:13:56 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:13:56 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:13:56 --> Utf8 Class Initialized
INFO - 2017-02-17 14:13:56 --> URI Class Initialized
DEBUG - 2017-02-17 14:13:56 --> No URI present. Default controller set.
INFO - 2017-02-17 14:13:56 --> Router Class Initialized
INFO - 2017-02-17 14:13:56 --> Output Class Initialized
INFO - 2017-02-17 14:13:56 --> Security Class Initialized
DEBUG - 2017-02-17 14:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:13:56 --> Input Class Initialized
INFO - 2017-02-17 14:13:56 --> Language Class Initialized
INFO - 2017-02-17 14:13:56 --> Language Class Initialized
INFO - 2017-02-17 14:13:56 --> Config Class Initialized
INFO - 2017-02-17 14:13:56 --> Loader Class Initialized
INFO - 2017-02-17 14:13:56 --> Helper loaded: form_helper
INFO - 2017-02-17 14:13:56 --> Helper loaded: url_helper
INFO - 2017-02-17 14:13:56 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:13:56 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:13:56 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:13:56 --> Template Class Initialized
INFO - 2017-02-17 14:13:56 --> Controller Class Initialized
INFO - 2017-02-17 14:13:56 --> Form Validation Class Initialized
INFO - 2017-02-17 14:13:56 --> Model Class Initialized
DEBUG - 2017-02-17 14:13:56 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 14:13:56 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 14:13:56 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 14:13:56 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 14:13:56 --> Final output sent to browser
DEBUG - 2017-02-17 14:13:56 --> Total execution time: 0.3249
INFO - 2017-02-17 14:14:05 --> Config Class Initialized
INFO - 2017-02-17 14:14:05 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:14:05 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:14:05 --> Utf8 Class Initialized
INFO - 2017-02-17 14:14:05 --> URI Class Initialized
INFO - 2017-02-17 14:14:05 --> Router Class Initialized
INFO - 2017-02-17 14:14:05 --> Output Class Initialized
INFO - 2017-02-17 14:14:05 --> Security Class Initialized
DEBUG - 2017-02-17 14:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:14:05 --> Input Class Initialized
INFO - 2017-02-17 14:14:05 --> Language Class Initialized
ERROR - 2017-02-17 14:14:05 --> 404 Page Not Found: /index
INFO - 2017-02-17 14:14:08 --> Config Class Initialized
INFO - 2017-02-17 14:14:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:14:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:14:08 --> Utf8 Class Initialized
INFO - 2017-02-17 14:14:08 --> URI Class Initialized
INFO - 2017-02-17 14:14:08 --> Router Class Initialized
INFO - 2017-02-17 14:14:08 --> Output Class Initialized
INFO - 2017-02-17 14:14:08 --> Security Class Initialized
DEBUG - 2017-02-17 14:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:14:08 --> Input Class Initialized
INFO - 2017-02-17 14:14:08 --> Language Class Initialized
INFO - 2017-02-17 14:14:08 --> Language Class Initialized
INFO - 2017-02-17 14:14:08 --> Config Class Initialized
INFO - 2017-02-17 14:14:08 --> Loader Class Initialized
INFO - 2017-02-17 14:14:08 --> Helper loaded: form_helper
INFO - 2017-02-17 14:14:08 --> Helper loaded: url_helper
INFO - 2017-02-17 14:14:08 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:14:08 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:14:08 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:14:08 --> Template Class Initialized
INFO - 2017-02-17 14:14:08 --> Controller Class Initialized
DEBUG - 2017-02-17 14:14:08 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:14:08 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:14:08 --> Model Class Initialized
INFO - 2017-02-17 14:14:08 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:14:08 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:14:08 --> Final output sent to browser
DEBUG - 2017-02-17 14:14:08 --> Total execution time: 0.0441
INFO - 2017-02-17 14:14:14 --> Config Class Initialized
INFO - 2017-02-17 14:14:14 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:14:14 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:14:14 --> Utf8 Class Initialized
INFO - 2017-02-17 14:14:14 --> URI Class Initialized
INFO - 2017-02-17 14:14:14 --> Router Class Initialized
INFO - 2017-02-17 14:14:14 --> Output Class Initialized
INFO - 2017-02-17 14:14:14 --> Security Class Initialized
DEBUG - 2017-02-17 14:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:14:14 --> Input Class Initialized
INFO - 2017-02-17 14:14:14 --> Language Class Initialized
INFO - 2017-02-17 14:14:14 --> Language Class Initialized
INFO - 2017-02-17 14:14:14 --> Config Class Initialized
INFO - 2017-02-17 14:14:14 --> Loader Class Initialized
INFO - 2017-02-17 14:14:14 --> Helper loaded: form_helper
INFO - 2017-02-17 14:14:14 --> Helper loaded: url_helper
INFO - 2017-02-17 14:14:14 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:14:14 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:14:14 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:14:14 --> Template Class Initialized
INFO - 2017-02-17 14:14:14 --> Controller Class Initialized
DEBUG - 2017-02-17 14:14:14 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:14:14 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:14:14 --> Model Class Initialized
INFO - 2017-02-17 14:14:14 --> Form Validation Class Initialized
INFO - 2017-02-17 14:14:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 14:14:14 --> Config Class Initialized
INFO - 2017-02-17 14:14:14 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:14:14 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:14:14 --> Utf8 Class Initialized
INFO - 2017-02-17 14:14:14 --> URI Class Initialized
INFO - 2017-02-17 14:14:14 --> Router Class Initialized
INFO - 2017-02-17 14:14:14 --> Output Class Initialized
INFO - 2017-02-17 14:14:14 --> Security Class Initialized
DEBUG - 2017-02-17 14:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:14:14 --> Input Class Initialized
INFO - 2017-02-17 14:14:14 --> Language Class Initialized
INFO - 2017-02-17 14:14:14 --> Language Class Initialized
INFO - 2017-02-17 14:14:14 --> Config Class Initialized
INFO - 2017-02-17 14:14:14 --> Loader Class Initialized
INFO - 2017-02-17 14:14:14 --> Helper loaded: form_helper
INFO - 2017-02-17 14:14:14 --> Helper loaded: url_helper
INFO - 2017-02-17 14:14:14 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:14:14 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:14:14 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:14:14 --> Template Class Initialized
INFO - 2017-02-17 14:14:14 --> Controller Class Initialized
DEBUG - 2017-02-17 14:14:14 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:14:14 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:14:14 --> Model Class Initialized
INFO - 2017-02-17 14:14:14 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:14:14 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:14:14 --> Final output sent to browser
DEBUG - 2017-02-17 14:14:14 --> Total execution time: 0.0453
INFO - 2017-02-17 14:14:19 --> Config Class Initialized
INFO - 2017-02-17 14:14:19 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:14:19 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:14:19 --> Utf8 Class Initialized
INFO - 2017-02-17 14:14:19 --> URI Class Initialized
INFO - 2017-02-17 14:14:19 --> Router Class Initialized
INFO - 2017-02-17 14:14:19 --> Output Class Initialized
INFO - 2017-02-17 14:14:19 --> Security Class Initialized
DEBUG - 2017-02-17 14:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:14:19 --> Input Class Initialized
INFO - 2017-02-17 14:14:19 --> Language Class Initialized
INFO - 2017-02-17 14:14:19 --> Language Class Initialized
INFO - 2017-02-17 14:14:19 --> Config Class Initialized
INFO - 2017-02-17 14:14:19 --> Loader Class Initialized
INFO - 2017-02-17 14:14:19 --> Helper loaded: form_helper
INFO - 2017-02-17 14:14:19 --> Helper loaded: url_helper
INFO - 2017-02-17 14:14:19 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:14:19 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:14:19 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:14:19 --> Template Class Initialized
INFO - 2017-02-17 14:14:19 --> Controller Class Initialized
DEBUG - 2017-02-17 14:14:19 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:14:19 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:14:19 --> Model Class Initialized
INFO - 2017-02-17 14:14:19 --> Form Validation Class Initialized
INFO - 2017-02-17 14:14:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 14:14:19 --> Config Class Initialized
INFO - 2017-02-17 14:14:19 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:14:19 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:14:19 --> Utf8 Class Initialized
INFO - 2017-02-17 14:14:19 --> URI Class Initialized
INFO - 2017-02-17 14:14:19 --> Router Class Initialized
INFO - 2017-02-17 14:14:19 --> Output Class Initialized
INFO - 2017-02-17 14:14:19 --> Security Class Initialized
DEBUG - 2017-02-17 14:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:14:19 --> Input Class Initialized
INFO - 2017-02-17 14:14:19 --> Language Class Initialized
INFO - 2017-02-17 14:14:19 --> Language Class Initialized
INFO - 2017-02-17 14:14:19 --> Config Class Initialized
INFO - 2017-02-17 14:14:19 --> Loader Class Initialized
INFO - 2017-02-17 14:14:20 --> Helper loaded: form_helper
INFO - 2017-02-17 14:14:20 --> Helper loaded: url_helper
INFO - 2017-02-17 14:14:20 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:14:20 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:14:20 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:14:20 --> Template Class Initialized
INFO - 2017-02-17 14:14:20 --> Controller Class Initialized
DEBUG - 2017-02-17 14:14:20 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:14:20 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:14:20 --> Model Class Initialized
INFO - 2017-02-17 14:14:20 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:14:20 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:14:20 --> Final output sent to browser
DEBUG - 2017-02-17 14:14:20 --> Total execution time: 0.0488
INFO - 2017-02-17 14:14:45 --> Config Class Initialized
INFO - 2017-02-17 14:14:45 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:14:45 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:14:45 --> Utf8 Class Initialized
INFO - 2017-02-17 14:14:45 --> URI Class Initialized
INFO - 2017-02-17 14:14:45 --> Router Class Initialized
INFO - 2017-02-17 14:14:45 --> Output Class Initialized
INFO - 2017-02-17 14:14:45 --> Security Class Initialized
DEBUG - 2017-02-17 14:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:14:45 --> Input Class Initialized
INFO - 2017-02-17 14:14:45 --> Language Class Initialized
INFO - 2017-02-17 14:14:45 --> Language Class Initialized
INFO - 2017-02-17 14:14:45 --> Config Class Initialized
INFO - 2017-02-17 14:14:45 --> Loader Class Initialized
INFO - 2017-02-17 14:14:45 --> Helper loaded: form_helper
INFO - 2017-02-17 14:14:45 --> Helper loaded: url_helper
INFO - 2017-02-17 14:14:45 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:14:45 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:14:45 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:14:45 --> Template Class Initialized
INFO - 2017-02-17 14:14:45 --> Controller Class Initialized
DEBUG - 2017-02-17 14:14:45 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:14:45 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:14:45 --> Model Class Initialized
INFO - 2017-02-17 14:14:45 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:14:45 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:14:45 --> Final output sent to browser
DEBUG - 2017-02-17 14:14:45 --> Total execution time: 0.0546
INFO - 2017-02-17 14:14:50 --> Config Class Initialized
INFO - 2017-02-17 14:14:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:14:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:14:50 --> Utf8 Class Initialized
INFO - 2017-02-17 14:14:50 --> URI Class Initialized
INFO - 2017-02-17 14:14:50 --> Router Class Initialized
INFO - 2017-02-17 14:14:50 --> Output Class Initialized
INFO - 2017-02-17 14:14:50 --> Security Class Initialized
DEBUG - 2017-02-17 14:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:14:50 --> Input Class Initialized
INFO - 2017-02-17 14:14:50 --> Language Class Initialized
INFO - 2017-02-17 14:14:50 --> Language Class Initialized
INFO - 2017-02-17 14:14:50 --> Config Class Initialized
INFO - 2017-02-17 14:14:50 --> Loader Class Initialized
INFO - 2017-02-17 14:14:50 --> Helper loaded: form_helper
INFO - 2017-02-17 14:14:50 --> Helper loaded: url_helper
INFO - 2017-02-17 14:14:50 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:14:50 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:14:50 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:14:50 --> Template Class Initialized
INFO - 2017-02-17 14:14:50 --> Controller Class Initialized
DEBUG - 2017-02-17 14:14:50 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:14:50 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:14:50 --> Model Class Initialized
INFO - 2017-02-17 14:14:50 --> Form Validation Class Initialized
INFO - 2017-02-17 14:14:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 14:14:50 --> Severity: Notice --> Undefined index: first_name C:\xampp\htdocs\razor\application\modules\backend\controllers\Login.php 40
ERROR - 2017-02-17 14:14:50 --> Severity: Notice --> Undefined index: last_name C:\xampp\htdocs\razor\application\modules\backend\controllers\Login.php 41
ERROR - 2017-02-17 14:14:50 --> Severity: Notice --> Undefined index: mobile C:\xampp\htdocs\razor\application\modules\backend\controllers\Login.php 43
INFO - 2017-02-17 14:14:50 --> Config Class Initialized
INFO - 2017-02-17 14:14:50 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:14:50 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:14:50 --> Utf8 Class Initialized
INFO - 2017-02-17 14:14:50 --> URI Class Initialized
INFO - 2017-02-17 14:14:50 --> Router Class Initialized
INFO - 2017-02-17 14:14:50 --> Output Class Initialized
INFO - 2017-02-17 14:14:50 --> Security Class Initialized
DEBUG - 2017-02-17 14:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:14:50 --> Input Class Initialized
INFO - 2017-02-17 14:14:50 --> Language Class Initialized
ERROR - 2017-02-17 14:14:50 --> 404 Page Not Found: /index
INFO - 2017-02-17 14:15:06 --> Config Class Initialized
INFO - 2017-02-17 14:15:06 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:15:06 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:15:06 --> Utf8 Class Initialized
INFO - 2017-02-17 14:15:06 --> URI Class Initialized
INFO - 2017-02-17 14:15:06 --> Router Class Initialized
INFO - 2017-02-17 14:15:06 --> Output Class Initialized
INFO - 2017-02-17 14:15:06 --> Security Class Initialized
DEBUG - 2017-02-17 14:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:15:06 --> Input Class Initialized
INFO - 2017-02-17 14:15:06 --> Language Class Initialized
INFO - 2017-02-17 14:15:06 --> Language Class Initialized
INFO - 2017-02-17 14:15:06 --> Config Class Initialized
INFO - 2017-02-17 14:15:06 --> Loader Class Initialized
INFO - 2017-02-17 14:15:06 --> Helper loaded: form_helper
INFO - 2017-02-17 14:15:06 --> Helper loaded: url_helper
INFO - 2017-02-17 14:15:06 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:15:06 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:15:06 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:15:06 --> Template Class Initialized
INFO - 2017-02-17 14:15:06 --> Controller Class Initialized
DEBUG - 2017-02-17 14:15:06 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 14:15:06 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:15:06 --> Model Class Initialized
DEBUG - 2017-02-17 14:15:06 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 14:15:06 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 14:15:06 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 14:15:06 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/employee/dashboard.php
DEBUG - 2017-02-17 14:15:06 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 14:15:06 --> Final output sent to browser
DEBUG - 2017-02-17 14:15:06 --> Total execution time: 0.1249
INFO - 2017-02-17 14:15:06 --> Config Class Initialized
INFO - 2017-02-17 14:15:06 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:15:07 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:15:07 --> Utf8 Class Initialized
INFO - 2017-02-17 14:15:07 --> URI Class Initialized
INFO - 2017-02-17 14:15:07 --> Router Class Initialized
INFO - 2017-02-17 14:15:07 --> Output Class Initialized
INFO - 2017-02-17 14:15:07 --> Security Class Initialized
DEBUG - 2017-02-17 14:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:15:07 --> Input Class Initialized
INFO - 2017-02-17 14:15:07 --> Language Class Initialized
ERROR - 2017-02-17 14:15:07 --> 404 Page Not Found: /index
INFO - 2017-02-17 14:16:19 --> Config Class Initialized
INFO - 2017-02-17 14:16:19 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:16:19 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:16:19 --> Utf8 Class Initialized
INFO - 2017-02-17 14:16:19 --> URI Class Initialized
INFO - 2017-02-17 14:16:19 --> Router Class Initialized
INFO - 2017-02-17 14:16:19 --> Output Class Initialized
INFO - 2017-02-17 14:16:19 --> Security Class Initialized
DEBUG - 2017-02-17 14:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:16:19 --> Input Class Initialized
INFO - 2017-02-17 14:16:19 --> Language Class Initialized
INFO - 2017-02-17 14:16:19 --> Language Class Initialized
INFO - 2017-02-17 14:16:19 --> Config Class Initialized
INFO - 2017-02-17 14:16:19 --> Loader Class Initialized
INFO - 2017-02-17 14:16:19 --> Helper loaded: form_helper
INFO - 2017-02-17 14:16:19 --> Helper loaded: url_helper
INFO - 2017-02-17 14:16:19 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:16:19 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:16:19 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:16:19 --> Template Class Initialized
INFO - 2017-02-17 14:16:19 --> Controller Class Initialized
DEBUG - 2017-02-17 14:16:19 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 14:16:19 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:16:19 --> Model Class Initialized
DEBUG - 2017-02-17 14:16:19 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 14:16:19 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 14:16:19 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 14:16:19 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-17 14:16:19 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 14:16:19 --> Final output sent to browser
DEBUG - 2017-02-17 14:16:19 --> Total execution time: 0.0857
INFO - 2017-02-17 14:16:19 --> Config Class Initialized
INFO - 2017-02-17 14:16:19 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:16:19 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:16:19 --> Utf8 Class Initialized
INFO - 2017-02-17 14:16:19 --> URI Class Initialized
INFO - 2017-02-17 14:16:19 --> Router Class Initialized
INFO - 2017-02-17 14:16:19 --> Output Class Initialized
INFO - 2017-02-17 14:16:19 --> Security Class Initialized
DEBUG - 2017-02-17 14:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:16:19 --> Input Class Initialized
INFO - 2017-02-17 14:16:19 --> Language Class Initialized
ERROR - 2017-02-17 14:16:19 --> 404 Page Not Found: /index
INFO - 2017-02-17 14:16:37 --> Config Class Initialized
INFO - 2017-02-17 14:16:37 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:16:37 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:16:37 --> Utf8 Class Initialized
INFO - 2017-02-17 14:16:37 --> URI Class Initialized
INFO - 2017-02-17 14:16:37 --> Router Class Initialized
INFO - 2017-02-17 14:16:37 --> Output Class Initialized
INFO - 2017-02-17 14:16:37 --> Security Class Initialized
DEBUG - 2017-02-17 14:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:16:37 --> Input Class Initialized
INFO - 2017-02-17 14:16:37 --> Language Class Initialized
INFO - 2017-02-17 14:16:37 --> Language Class Initialized
INFO - 2017-02-17 14:16:37 --> Config Class Initialized
INFO - 2017-02-17 14:16:37 --> Loader Class Initialized
INFO - 2017-02-17 14:16:37 --> Helper loaded: form_helper
INFO - 2017-02-17 14:16:37 --> Helper loaded: url_helper
INFO - 2017-02-17 14:16:37 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:16:37 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:16:37 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:16:37 --> Template Class Initialized
INFO - 2017-02-17 14:16:37 --> Controller Class Initialized
DEBUG - 2017-02-17 14:16:37 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 14:16:37 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:16:37 --> Model Class Initialized
DEBUG - 2017-02-17 14:16:37 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 14:16:37 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 14:16:37 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 14:16:37 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-17 14:16:37 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 14:16:37 --> Final output sent to browser
DEBUG - 2017-02-17 14:16:37 --> Total execution time: 0.0675
INFO - 2017-02-17 14:16:37 --> Config Class Initialized
INFO - 2017-02-17 14:16:37 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:16:37 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:16:37 --> Utf8 Class Initialized
INFO - 2017-02-17 14:16:37 --> URI Class Initialized
INFO - 2017-02-17 14:16:37 --> Router Class Initialized
INFO - 2017-02-17 14:16:37 --> Output Class Initialized
INFO - 2017-02-17 14:16:37 --> Security Class Initialized
DEBUG - 2017-02-17 14:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:16:37 --> Input Class Initialized
INFO - 2017-02-17 14:16:37 --> Language Class Initialized
ERROR - 2017-02-17 14:16:37 --> 404 Page Not Found: /index
INFO - 2017-02-17 14:18:26 --> Config Class Initialized
INFO - 2017-02-17 14:18:26 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:18:26 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:18:26 --> Utf8 Class Initialized
INFO - 2017-02-17 14:18:26 --> URI Class Initialized
INFO - 2017-02-17 14:18:26 --> Router Class Initialized
INFO - 2017-02-17 14:18:26 --> Output Class Initialized
INFO - 2017-02-17 14:18:26 --> Security Class Initialized
DEBUG - 2017-02-17 14:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:18:26 --> Input Class Initialized
INFO - 2017-02-17 14:18:26 --> Language Class Initialized
INFO - 2017-02-17 14:18:26 --> Language Class Initialized
INFO - 2017-02-17 14:18:26 --> Config Class Initialized
INFO - 2017-02-17 14:18:26 --> Loader Class Initialized
INFO - 2017-02-17 14:18:26 --> Helper loaded: form_helper
INFO - 2017-02-17 14:18:26 --> Helper loaded: url_helper
INFO - 2017-02-17 14:18:26 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:18:26 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:18:26 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:18:26 --> Template Class Initialized
INFO - 2017-02-17 14:18:26 --> Controller Class Initialized
DEBUG - 2017-02-17 14:18:26 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 14:18:26 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:18:26 --> Model Class Initialized
ERROR - 2017-02-17 14:18:27 --> Severity: Notice --> Undefined index: username C:\xampp\htdocs\razor\application\modules\backend\views\partials\header.php 13
DEBUG - 2017-02-17 14:18:27 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 14:18:27 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 14:18:27 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 14:18:27 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-17 14:18:27 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 14:18:27 --> Final output sent to browser
DEBUG - 2017-02-17 14:18:27 --> Total execution time: 0.0774
INFO - 2017-02-17 14:18:27 --> Config Class Initialized
INFO - 2017-02-17 14:18:27 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:18:27 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:18:27 --> Utf8 Class Initialized
INFO - 2017-02-17 14:18:27 --> URI Class Initialized
INFO - 2017-02-17 14:18:27 --> Router Class Initialized
INFO - 2017-02-17 14:18:27 --> Output Class Initialized
INFO - 2017-02-17 14:18:27 --> Security Class Initialized
DEBUG - 2017-02-17 14:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:18:27 --> Input Class Initialized
INFO - 2017-02-17 14:18:27 --> Language Class Initialized
ERROR - 2017-02-17 14:18:27 --> 404 Page Not Found: /index
INFO - 2017-02-17 14:18:51 --> Config Class Initialized
INFO - 2017-02-17 14:18:51 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:18:51 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:18:51 --> Utf8 Class Initialized
INFO - 2017-02-17 14:18:51 --> URI Class Initialized
DEBUG - 2017-02-17 14:18:51 --> No URI present. Default controller set.
INFO - 2017-02-17 14:18:51 --> Router Class Initialized
INFO - 2017-02-17 14:18:51 --> Output Class Initialized
INFO - 2017-02-17 14:18:51 --> Security Class Initialized
DEBUG - 2017-02-17 14:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:18:51 --> Input Class Initialized
INFO - 2017-02-17 14:18:51 --> Language Class Initialized
INFO - 2017-02-17 14:18:51 --> Language Class Initialized
INFO - 2017-02-17 14:18:51 --> Config Class Initialized
INFO - 2017-02-17 14:18:51 --> Loader Class Initialized
INFO - 2017-02-17 14:18:51 --> Helper loaded: form_helper
INFO - 2017-02-17 14:18:51 --> Helper loaded: url_helper
INFO - 2017-02-17 14:18:51 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:18:51 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:18:51 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:18:51 --> Template Class Initialized
INFO - 2017-02-17 14:18:51 --> Controller Class Initialized
INFO - 2017-02-17 14:18:51 --> Form Validation Class Initialized
INFO - 2017-02-17 14:18:51 --> Model Class Initialized
DEBUG - 2017-02-17 14:18:51 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 14:18:51 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 14:18:51 --> File loaded: C:\xampp\htdocs\razor\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 14:18:51 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 14:18:51 --> Final output sent to browser
DEBUG - 2017-02-17 14:18:51 --> Total execution time: 0.0560
INFO - 2017-02-17 14:18:54 --> Config Class Initialized
INFO - 2017-02-17 14:18:54 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:18:54 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:18:54 --> Utf8 Class Initialized
INFO - 2017-02-17 14:18:54 --> URI Class Initialized
INFO - 2017-02-17 14:18:54 --> Router Class Initialized
INFO - 2017-02-17 14:18:54 --> Output Class Initialized
INFO - 2017-02-17 14:18:54 --> Security Class Initialized
DEBUG - 2017-02-17 14:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:18:54 --> Input Class Initialized
INFO - 2017-02-17 14:18:54 --> Language Class Initialized
INFO - 2017-02-17 14:18:54 --> Language Class Initialized
INFO - 2017-02-17 14:18:54 --> Config Class Initialized
INFO - 2017-02-17 14:18:54 --> Loader Class Initialized
INFO - 2017-02-17 14:18:54 --> Helper loaded: form_helper
INFO - 2017-02-17 14:18:54 --> Helper loaded: url_helper
INFO - 2017-02-17 14:18:54 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:18:54 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:18:54 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:18:54 --> Template Class Initialized
INFO - 2017-02-17 14:18:54 --> Controller Class Initialized
DEBUG - 2017-02-17 14:18:54 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:18:54 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:18:54 --> Model Class Initialized
INFO - 2017-02-17 14:18:54 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:18:54 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:18:54 --> Final output sent to browser
DEBUG - 2017-02-17 14:18:54 --> Total execution time: 0.0984
INFO - 2017-02-17 14:18:58 --> Config Class Initialized
INFO - 2017-02-17 14:18:58 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:18:58 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:18:58 --> Utf8 Class Initialized
INFO - 2017-02-17 14:18:58 --> URI Class Initialized
INFO - 2017-02-17 14:18:58 --> Router Class Initialized
INFO - 2017-02-17 14:18:58 --> Output Class Initialized
INFO - 2017-02-17 14:18:58 --> Security Class Initialized
DEBUG - 2017-02-17 14:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:18:58 --> Input Class Initialized
INFO - 2017-02-17 14:18:58 --> Language Class Initialized
INFO - 2017-02-17 14:18:58 --> Language Class Initialized
INFO - 2017-02-17 14:18:58 --> Config Class Initialized
INFO - 2017-02-17 14:18:58 --> Loader Class Initialized
INFO - 2017-02-17 14:18:58 --> Helper loaded: form_helper
INFO - 2017-02-17 14:18:58 --> Helper loaded: url_helper
INFO - 2017-02-17 14:18:58 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:18:58 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:18:58 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:18:58 --> Template Class Initialized
INFO - 2017-02-17 14:18:58 --> Controller Class Initialized
DEBUG - 2017-02-17 14:18:58 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:18:58 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:18:58 --> Model Class Initialized
INFO - 2017-02-17 14:18:58 --> Form Validation Class Initialized
INFO - 2017-02-17 14:18:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 14:18:58 --> Config Class Initialized
INFO - 2017-02-17 14:18:58 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:18:58 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:18:58 --> Utf8 Class Initialized
INFO - 2017-02-17 14:18:58 --> URI Class Initialized
INFO - 2017-02-17 14:18:58 --> Router Class Initialized
INFO - 2017-02-17 14:18:58 --> Output Class Initialized
INFO - 2017-02-17 14:18:58 --> Security Class Initialized
DEBUG - 2017-02-17 14:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:18:58 --> Input Class Initialized
INFO - 2017-02-17 14:18:58 --> Language Class Initialized
INFO - 2017-02-17 14:18:58 --> Language Class Initialized
INFO - 2017-02-17 14:18:58 --> Config Class Initialized
INFO - 2017-02-17 14:18:58 --> Loader Class Initialized
INFO - 2017-02-17 14:18:58 --> Helper loaded: form_helper
INFO - 2017-02-17 14:18:58 --> Helper loaded: url_helper
INFO - 2017-02-17 14:18:58 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:18:58 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:18:58 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:18:58 --> Template Class Initialized
INFO - 2017-02-17 14:18:58 --> Controller Class Initialized
DEBUG - 2017-02-17 14:18:58 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:18:58 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:18:58 --> Model Class Initialized
INFO - 2017-02-17 14:18:58 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:18:58 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:18:58 --> Final output sent to browser
DEBUG - 2017-02-17 14:18:58 --> Total execution time: 0.0478
INFO - 2017-02-17 14:19:03 --> Config Class Initialized
INFO - 2017-02-17 14:19:03 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:19:03 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:19:03 --> Utf8 Class Initialized
INFO - 2017-02-17 14:19:03 --> URI Class Initialized
INFO - 2017-02-17 14:19:03 --> Router Class Initialized
INFO - 2017-02-17 14:19:03 --> Output Class Initialized
INFO - 2017-02-17 14:19:03 --> Security Class Initialized
DEBUG - 2017-02-17 14:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:19:03 --> Input Class Initialized
INFO - 2017-02-17 14:19:03 --> Language Class Initialized
INFO - 2017-02-17 14:19:03 --> Language Class Initialized
INFO - 2017-02-17 14:19:03 --> Config Class Initialized
INFO - 2017-02-17 14:19:03 --> Loader Class Initialized
INFO - 2017-02-17 14:19:03 --> Helper loaded: form_helper
INFO - 2017-02-17 14:19:03 --> Helper loaded: url_helper
INFO - 2017-02-17 14:19:03 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:19:03 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:19:03 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:19:03 --> Template Class Initialized
INFO - 2017-02-17 14:19:03 --> Controller Class Initialized
DEBUG - 2017-02-17 14:19:03 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:19:03 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:19:03 --> Model Class Initialized
INFO - 2017-02-17 14:19:03 --> Form Validation Class Initialized
INFO - 2017-02-17 14:19:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 14:19:03 --> Config Class Initialized
INFO - 2017-02-17 14:19:03 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:19:03 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:19:03 --> Utf8 Class Initialized
INFO - 2017-02-17 14:19:03 --> URI Class Initialized
INFO - 2017-02-17 14:19:03 --> Router Class Initialized
INFO - 2017-02-17 14:19:03 --> Output Class Initialized
INFO - 2017-02-17 14:19:03 --> Security Class Initialized
DEBUG - 2017-02-17 14:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:19:03 --> Input Class Initialized
INFO - 2017-02-17 14:19:03 --> Language Class Initialized
INFO - 2017-02-17 14:19:03 --> Language Class Initialized
INFO - 2017-02-17 14:19:03 --> Config Class Initialized
INFO - 2017-02-17 14:19:03 --> Loader Class Initialized
INFO - 2017-02-17 14:19:03 --> Helper loaded: form_helper
INFO - 2017-02-17 14:19:03 --> Helper loaded: url_helper
INFO - 2017-02-17 14:19:03 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:19:03 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:19:03 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:19:03 --> Template Class Initialized
INFO - 2017-02-17 14:19:03 --> Controller Class Initialized
DEBUG - 2017-02-17 14:19:03 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:19:03 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:19:03 --> Model Class Initialized
INFO - 2017-02-17 14:19:03 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:19:03 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:19:03 --> Final output sent to browser
DEBUG - 2017-02-17 14:19:03 --> Total execution time: 0.0450
INFO - 2017-02-17 14:19:25 --> Config Class Initialized
INFO - 2017-02-17 14:19:25 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:19:25 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:19:25 --> Utf8 Class Initialized
INFO - 2017-02-17 14:19:25 --> URI Class Initialized
INFO - 2017-02-17 14:19:25 --> Router Class Initialized
INFO - 2017-02-17 14:19:25 --> Output Class Initialized
INFO - 2017-02-17 14:19:25 --> Security Class Initialized
DEBUG - 2017-02-17 14:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:19:25 --> Input Class Initialized
INFO - 2017-02-17 14:19:25 --> Language Class Initialized
INFO - 2017-02-17 14:19:25 --> Language Class Initialized
INFO - 2017-02-17 14:19:25 --> Config Class Initialized
INFO - 2017-02-17 14:19:25 --> Loader Class Initialized
INFO - 2017-02-17 14:19:25 --> Helper loaded: form_helper
INFO - 2017-02-17 14:19:25 --> Helper loaded: url_helper
INFO - 2017-02-17 14:19:25 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:19:25 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:19:25 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:19:25 --> Template Class Initialized
INFO - 2017-02-17 14:19:25 --> Controller Class Initialized
DEBUG - 2017-02-17 14:19:25 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:19:25 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:19:25 --> Model Class Initialized
INFO - 2017-02-17 14:19:25 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:19:25 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:19:25 --> Final output sent to browser
DEBUG - 2017-02-17 14:19:25 --> Total execution time: 0.0592
INFO - 2017-02-17 14:19:31 --> Config Class Initialized
INFO - 2017-02-17 14:19:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:19:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:19:31 --> Utf8 Class Initialized
INFO - 2017-02-17 14:19:31 --> URI Class Initialized
INFO - 2017-02-17 14:19:31 --> Router Class Initialized
INFO - 2017-02-17 14:19:31 --> Output Class Initialized
INFO - 2017-02-17 14:19:31 --> Security Class Initialized
DEBUG - 2017-02-17 14:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:19:31 --> Input Class Initialized
INFO - 2017-02-17 14:19:31 --> Language Class Initialized
INFO - 2017-02-17 14:19:31 --> Language Class Initialized
INFO - 2017-02-17 14:19:31 --> Config Class Initialized
INFO - 2017-02-17 14:19:31 --> Loader Class Initialized
INFO - 2017-02-17 14:19:31 --> Helper loaded: form_helper
INFO - 2017-02-17 14:19:31 --> Helper loaded: url_helper
INFO - 2017-02-17 14:19:31 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:19:31 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:19:31 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:19:31 --> Template Class Initialized
INFO - 2017-02-17 14:19:31 --> Controller Class Initialized
DEBUG - 2017-02-17 14:19:31 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:19:31 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:19:31 --> Model Class Initialized
INFO - 2017-02-17 14:19:31 --> Form Validation Class Initialized
INFO - 2017-02-17 14:19:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 14:19:31 --> Config Class Initialized
INFO - 2017-02-17 14:19:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:19:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:19:31 --> Utf8 Class Initialized
INFO - 2017-02-17 14:19:31 --> URI Class Initialized
INFO - 2017-02-17 14:19:31 --> Router Class Initialized
INFO - 2017-02-17 14:19:31 --> Output Class Initialized
INFO - 2017-02-17 14:19:31 --> Security Class Initialized
DEBUG - 2017-02-17 14:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:19:31 --> Input Class Initialized
INFO - 2017-02-17 14:19:31 --> Language Class Initialized
INFO - 2017-02-17 14:19:31 --> Language Class Initialized
INFO - 2017-02-17 14:19:31 --> Config Class Initialized
INFO - 2017-02-17 14:19:31 --> Loader Class Initialized
INFO - 2017-02-17 14:19:31 --> Helper loaded: form_helper
INFO - 2017-02-17 14:19:31 --> Helper loaded: url_helper
INFO - 2017-02-17 14:19:31 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:19:31 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:19:31 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:19:31 --> Template Class Initialized
INFO - 2017-02-17 14:19:31 --> Controller Class Initialized
DEBUG - 2017-02-17 14:19:31 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 14:19:31 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:19:31 --> Model Class Initialized
DEBUG - 2017-02-17 14:19:31 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 14:19:31 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 14:19:31 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 14:19:31 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/employee/dashboard.php
DEBUG - 2017-02-17 14:19:31 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 14:19:31 --> Final output sent to browser
DEBUG - 2017-02-17 14:19:31 --> Total execution time: 0.0594
INFO - 2017-02-17 14:19:31 --> Config Class Initialized
INFO - 2017-02-17 14:19:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:19:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:19:31 --> Utf8 Class Initialized
INFO - 2017-02-17 14:19:31 --> URI Class Initialized
INFO - 2017-02-17 14:19:31 --> Router Class Initialized
INFO - 2017-02-17 14:19:31 --> Output Class Initialized
INFO - 2017-02-17 14:19:31 --> Security Class Initialized
DEBUG - 2017-02-17 14:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:19:31 --> Input Class Initialized
INFO - 2017-02-17 14:19:31 --> Language Class Initialized
ERROR - 2017-02-17 14:19:31 --> 404 Page Not Found: /index
INFO - 2017-02-17 14:19:59 --> Config Class Initialized
INFO - 2017-02-17 14:19:59 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:19:59 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:19:59 --> Utf8 Class Initialized
INFO - 2017-02-17 14:19:59 --> URI Class Initialized
INFO - 2017-02-17 14:19:59 --> Router Class Initialized
INFO - 2017-02-17 14:19:59 --> Output Class Initialized
INFO - 2017-02-17 14:19:59 --> Security Class Initialized
DEBUG - 2017-02-17 14:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:19:59 --> Input Class Initialized
INFO - 2017-02-17 14:19:59 --> Language Class Initialized
INFO - 2017-02-17 14:19:59 --> Language Class Initialized
INFO - 2017-02-17 14:19:59 --> Config Class Initialized
INFO - 2017-02-17 14:19:59 --> Loader Class Initialized
INFO - 2017-02-17 14:19:59 --> Helper loaded: form_helper
INFO - 2017-02-17 14:19:59 --> Helper loaded: url_helper
INFO - 2017-02-17 14:19:59 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:19:59 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:19:59 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:19:59 --> Template Class Initialized
INFO - 2017-02-17 14:19:59 --> Controller Class Initialized
DEBUG - 2017-02-17 14:19:59 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 14:19:59 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:19:59 --> Model Class Initialized
DEBUG - 2017-02-17 14:19:59 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 14:19:59 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 14:19:59 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 14:19:59 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/employee/dashboard.php
DEBUG - 2017-02-17 14:19:59 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 14:19:59 --> Final output sent to browser
DEBUG - 2017-02-17 14:19:59 --> Total execution time: 0.0547
INFO - 2017-02-17 14:21:39 --> Config Class Initialized
INFO - 2017-02-17 14:21:39 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:21:39 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:21:39 --> Utf8 Class Initialized
INFO - 2017-02-17 14:21:39 --> URI Class Initialized
INFO - 2017-02-17 14:21:39 --> Router Class Initialized
INFO - 2017-02-17 14:21:39 --> Output Class Initialized
INFO - 2017-02-17 14:21:39 --> Security Class Initialized
DEBUG - 2017-02-17 14:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:21:39 --> Input Class Initialized
INFO - 2017-02-17 14:21:39 --> Language Class Initialized
INFO - 2017-02-17 14:21:39 --> Language Class Initialized
INFO - 2017-02-17 14:21:39 --> Config Class Initialized
INFO - 2017-02-17 14:21:39 --> Loader Class Initialized
INFO - 2017-02-17 14:21:39 --> Helper loaded: form_helper
INFO - 2017-02-17 14:21:39 --> Helper loaded: url_helper
INFO - 2017-02-17 14:21:39 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:21:39 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:21:39 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:21:39 --> Template Class Initialized
INFO - 2017-02-17 14:21:39 --> Controller Class Initialized
DEBUG - 2017-02-17 14:21:39 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 14:21:39 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:21:39 --> Model Class Initialized
DEBUG - 2017-02-17 14:21:39 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 14:21:39 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 14:21:39 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 14:21:39 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/employee/dashboard.php
DEBUG - 2017-02-17 14:21:39 --> File loaded: C:\xampp\htdocs\razor\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 14:21:39 --> Final output sent to browser
DEBUG - 2017-02-17 14:21:39 --> Total execution time: 0.0479
INFO - 2017-02-17 14:22:20 --> Config Class Initialized
INFO - 2017-02-17 14:22:20 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:22:20 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:22:20 --> Utf8 Class Initialized
INFO - 2017-02-17 14:22:20 --> URI Class Initialized
INFO - 2017-02-17 14:22:20 --> Router Class Initialized
INFO - 2017-02-17 14:22:20 --> Output Class Initialized
INFO - 2017-02-17 14:22:20 --> Security Class Initialized
DEBUG - 2017-02-17 14:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:22:20 --> Input Class Initialized
INFO - 2017-02-17 14:22:20 --> Language Class Initialized
INFO - 2017-02-17 14:22:20 --> Language Class Initialized
INFO - 2017-02-17 14:22:20 --> Config Class Initialized
INFO - 2017-02-17 14:22:20 --> Loader Class Initialized
INFO - 2017-02-17 14:22:20 --> Helper loaded: form_helper
INFO - 2017-02-17 14:22:20 --> Helper loaded: url_helper
INFO - 2017-02-17 14:22:20 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:22:20 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:22:20 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:22:20 --> Template Class Initialized
INFO - 2017-02-17 14:22:20 --> Controller Class Initialized
DEBUG - 2017-02-17 14:22:20 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:22:20 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:22:20 --> Model Class Initialized
INFO - 2017-02-17 14:22:20 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:22:20 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:22:20 --> Final output sent to browser
DEBUG - 2017-02-17 14:22:20 --> Total execution time: 0.1332
INFO - 2017-02-17 14:22:30 --> Config Class Initialized
INFO - 2017-02-17 14:22:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:22:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:22:31 --> Utf8 Class Initialized
INFO - 2017-02-17 14:22:31 --> URI Class Initialized
INFO - 2017-02-17 14:22:31 --> Router Class Initialized
INFO - 2017-02-17 14:22:31 --> Output Class Initialized
INFO - 2017-02-17 14:22:31 --> Security Class Initialized
DEBUG - 2017-02-17 14:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:22:31 --> Input Class Initialized
INFO - 2017-02-17 14:22:31 --> Language Class Initialized
INFO - 2017-02-17 14:22:31 --> Language Class Initialized
INFO - 2017-02-17 14:22:31 --> Config Class Initialized
INFO - 2017-02-17 14:22:31 --> Loader Class Initialized
INFO - 2017-02-17 14:22:31 --> Helper loaded: form_helper
INFO - 2017-02-17 14:22:31 --> Helper loaded: url_helper
INFO - 2017-02-17 14:22:31 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:22:31 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:22:31 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:22:31 --> Template Class Initialized
INFO - 2017-02-17 14:22:31 --> Controller Class Initialized
DEBUG - 2017-02-17 14:22:31 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:22:31 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:22:31 --> Model Class Initialized
INFO - 2017-02-17 14:22:31 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:22:31 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:22:31 --> Final output sent to browser
DEBUG - 2017-02-17 14:22:31 --> Total execution time: 0.0511
INFO - 2017-02-17 14:22:53 --> Config Class Initialized
INFO - 2017-02-17 14:22:53 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:22:53 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:22:53 --> Utf8 Class Initialized
INFO - 2017-02-17 14:22:53 --> URI Class Initialized
INFO - 2017-02-17 14:22:53 --> Router Class Initialized
INFO - 2017-02-17 14:22:53 --> Output Class Initialized
INFO - 2017-02-17 14:22:53 --> Security Class Initialized
DEBUG - 2017-02-17 14:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:22:53 --> Input Class Initialized
INFO - 2017-02-17 14:22:53 --> Language Class Initialized
INFO - 2017-02-17 14:22:53 --> Language Class Initialized
INFO - 2017-02-17 14:22:53 --> Config Class Initialized
INFO - 2017-02-17 14:22:53 --> Loader Class Initialized
INFO - 2017-02-17 14:22:53 --> Helper loaded: form_helper
INFO - 2017-02-17 14:22:53 --> Helper loaded: url_helper
INFO - 2017-02-17 14:22:53 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:22:53 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:22:53 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:22:53 --> Template Class Initialized
INFO - 2017-02-17 14:22:53 --> Controller Class Initialized
DEBUG - 2017-02-17 14:22:53 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:22:53 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:22:53 --> Model Class Initialized
INFO - 2017-02-17 14:22:53 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:22:53 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:22:53 --> Final output sent to browser
DEBUG - 2017-02-17 14:22:53 --> Total execution time: 0.0467
INFO - 2017-02-17 14:23:23 --> Config Class Initialized
INFO - 2017-02-17 14:23:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:23:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:23:23 --> Utf8 Class Initialized
INFO - 2017-02-17 14:23:23 --> URI Class Initialized
INFO - 2017-02-17 14:23:23 --> Router Class Initialized
INFO - 2017-02-17 14:23:23 --> Output Class Initialized
INFO - 2017-02-17 14:23:23 --> Security Class Initialized
DEBUG - 2017-02-17 14:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:23:23 --> Input Class Initialized
INFO - 2017-02-17 14:23:23 --> Language Class Initialized
INFO - 2017-02-17 14:23:23 --> Language Class Initialized
INFO - 2017-02-17 14:23:23 --> Config Class Initialized
INFO - 2017-02-17 14:23:23 --> Loader Class Initialized
INFO - 2017-02-17 14:23:23 --> Helper loaded: form_helper
INFO - 2017-02-17 14:23:23 --> Helper loaded: url_helper
INFO - 2017-02-17 14:23:23 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:23:23 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:23:23 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:23:23 --> Template Class Initialized
INFO - 2017-02-17 14:23:23 --> Controller Class Initialized
DEBUG - 2017-02-17 14:23:23 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:23:23 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:23:23 --> Model Class Initialized
INFO - 2017-02-17 14:23:23 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:23:23 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:23:23 --> Final output sent to browser
DEBUG - 2017-02-17 14:23:23 --> Total execution time: 0.0559
INFO - 2017-02-17 14:23:33 --> Config Class Initialized
INFO - 2017-02-17 14:23:33 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:23:33 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:23:33 --> Utf8 Class Initialized
INFO - 2017-02-17 14:23:33 --> URI Class Initialized
INFO - 2017-02-17 14:23:33 --> Router Class Initialized
INFO - 2017-02-17 14:23:33 --> Output Class Initialized
INFO - 2017-02-17 14:23:33 --> Security Class Initialized
DEBUG - 2017-02-17 14:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:23:33 --> Input Class Initialized
INFO - 2017-02-17 14:23:33 --> Language Class Initialized
ERROR - 2017-02-17 14:23:33 --> 404 Page Not Found: /index
INFO - 2017-02-17 14:23:36 --> Config Class Initialized
INFO - 2017-02-17 14:23:36 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:23:36 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:23:36 --> Utf8 Class Initialized
INFO - 2017-02-17 14:23:36 --> URI Class Initialized
INFO - 2017-02-17 14:23:36 --> Router Class Initialized
INFO - 2017-02-17 14:23:36 --> Output Class Initialized
INFO - 2017-02-17 14:23:36 --> Security Class Initialized
DEBUG - 2017-02-17 14:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:23:36 --> Input Class Initialized
INFO - 2017-02-17 14:23:36 --> Language Class Initialized
INFO - 2017-02-17 14:23:36 --> Language Class Initialized
INFO - 2017-02-17 14:23:36 --> Config Class Initialized
INFO - 2017-02-17 14:23:36 --> Loader Class Initialized
INFO - 2017-02-17 14:23:36 --> Helper loaded: form_helper
INFO - 2017-02-17 14:23:36 --> Helper loaded: url_helper
INFO - 2017-02-17 14:23:36 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:23:36 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:23:36 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:23:36 --> Template Class Initialized
INFO - 2017-02-17 14:23:36 --> Controller Class Initialized
DEBUG - 2017-02-17 14:23:36 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:23:36 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:23:36 --> Model Class Initialized
INFO - 2017-02-17 14:23:36 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:23:36 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:23:36 --> Final output sent to browser
DEBUG - 2017-02-17 14:23:36 --> Total execution time: 0.0547
INFO - 2017-02-17 14:32:57 --> Config Class Initialized
INFO - 2017-02-17 14:32:57 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:32:57 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:32:57 --> Utf8 Class Initialized
INFO - 2017-02-17 14:32:57 --> URI Class Initialized
INFO - 2017-02-17 14:32:57 --> Router Class Initialized
INFO - 2017-02-17 14:32:57 --> Output Class Initialized
INFO - 2017-02-17 14:32:57 --> Security Class Initialized
DEBUG - 2017-02-17 14:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:32:57 --> Input Class Initialized
INFO - 2017-02-17 14:32:57 --> Language Class Initialized
INFO - 2017-02-17 14:32:57 --> Language Class Initialized
INFO - 2017-02-17 14:32:57 --> Config Class Initialized
INFO - 2017-02-17 14:32:57 --> Loader Class Initialized
INFO - 2017-02-17 14:32:57 --> Helper loaded: form_helper
INFO - 2017-02-17 14:32:57 --> Helper loaded: url_helper
INFO - 2017-02-17 14:32:57 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:32:57 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:32:57 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:32:57 --> Template Class Initialized
INFO - 2017-02-17 14:32:57 --> Controller Class Initialized
DEBUG - 2017-02-17 14:32:57 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:32:57 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:32:57 --> Model Class Initialized
INFO - 2017-02-17 14:32:57 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:32:57 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:32:57 --> Final output sent to browser
DEBUG - 2017-02-17 14:32:57 --> Total execution time: 0.3368
INFO - 2017-02-17 14:33:08 --> Config Class Initialized
INFO - 2017-02-17 14:33:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:33:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:33:08 --> Utf8 Class Initialized
INFO - 2017-02-17 14:33:08 --> URI Class Initialized
INFO - 2017-02-17 14:33:08 --> Router Class Initialized
INFO - 2017-02-17 14:33:08 --> Output Class Initialized
INFO - 2017-02-17 14:33:08 --> Security Class Initialized
DEBUG - 2017-02-17 14:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:33:08 --> Input Class Initialized
INFO - 2017-02-17 14:33:08 --> Language Class Initialized
INFO - 2017-02-17 14:33:08 --> Language Class Initialized
INFO - 2017-02-17 14:33:08 --> Config Class Initialized
INFO - 2017-02-17 14:33:08 --> Loader Class Initialized
INFO - 2017-02-17 14:33:08 --> Helper loaded: form_helper
INFO - 2017-02-17 14:33:08 --> Helper loaded: url_helper
INFO - 2017-02-17 14:33:08 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:33:08 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:33:08 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:33:08 --> Template Class Initialized
INFO - 2017-02-17 14:33:08 --> Controller Class Initialized
DEBUG - 2017-02-17 14:33:08 --> Register MX_Controller Initialized
INFO - 2017-02-17 14:33:08 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:33:08 --> Model Class Initialized
INFO - 2017-02-17 14:33:08 --> Form Validation Class Initialized
ERROR - 2017-02-17 14:33:08 --> Severity: Notice --> Undefined variable: map C:\xampp\htdocs\razor\application\modules\backend\controllers\Register.php 42
INFO - 2017-02-17 14:33:08 --> Config Class Initialized
INFO - 2017-02-17 14:33:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:33:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:33:08 --> Utf8 Class Initialized
INFO - 2017-02-17 14:33:08 --> URI Class Initialized
INFO - 2017-02-17 14:33:08 --> Router Class Initialized
INFO - 2017-02-17 14:33:08 --> Output Class Initialized
INFO - 2017-02-17 14:33:08 --> Security Class Initialized
DEBUG - 2017-02-17 14:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:33:08 --> Input Class Initialized
INFO - 2017-02-17 14:33:08 --> Language Class Initialized
INFO - 2017-02-17 14:33:08 --> Language Class Initialized
INFO - 2017-02-17 14:33:08 --> Config Class Initialized
INFO - 2017-02-17 14:33:08 --> Loader Class Initialized
INFO - 2017-02-17 14:33:08 --> Helper loaded: form_helper
INFO - 2017-02-17 14:33:08 --> Helper loaded: url_helper
INFO - 2017-02-17 14:33:08 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:33:08 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:33:08 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:33:08 --> Template Class Initialized
INFO - 2017-02-17 14:33:08 --> Controller Class Initialized
DEBUG - 2017-02-17 14:33:08 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:33:08 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:33:08 --> Model Class Initialized
INFO - 2017-02-17 14:33:08 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:33:08 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:33:08 --> Final output sent to browser
DEBUG - 2017-02-17 14:33:08 --> Total execution time: 0.0772
INFO - 2017-02-17 14:33:49 --> Config Class Initialized
INFO - 2017-02-17 14:33:49 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:33:49 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:33:49 --> Utf8 Class Initialized
INFO - 2017-02-17 14:33:49 --> URI Class Initialized
INFO - 2017-02-17 14:33:49 --> Router Class Initialized
INFO - 2017-02-17 14:33:49 --> Output Class Initialized
INFO - 2017-02-17 14:33:49 --> Security Class Initialized
DEBUG - 2017-02-17 14:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:33:49 --> Input Class Initialized
INFO - 2017-02-17 14:33:49 --> Language Class Initialized
INFO - 2017-02-17 14:33:49 --> Language Class Initialized
INFO - 2017-02-17 14:33:49 --> Config Class Initialized
INFO - 2017-02-17 14:33:49 --> Loader Class Initialized
INFO - 2017-02-17 14:33:49 --> Helper loaded: form_helper
INFO - 2017-02-17 14:33:49 --> Helper loaded: url_helper
INFO - 2017-02-17 14:33:49 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:33:49 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:33:49 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:33:49 --> Template Class Initialized
INFO - 2017-02-17 14:33:49 --> Controller Class Initialized
DEBUG - 2017-02-17 14:33:49 --> Register MX_Controller Initialized
INFO - 2017-02-17 14:33:49 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:33:49 --> Model Class Initialized
INFO - 2017-02-17 14:33:49 --> Form Validation Class Initialized
INFO - 2017-02-17 14:33:49 --> Config Class Initialized
INFO - 2017-02-17 14:33:49 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:33:49 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:33:49 --> Utf8 Class Initialized
INFO - 2017-02-17 14:33:49 --> URI Class Initialized
INFO - 2017-02-17 14:33:49 --> Router Class Initialized
INFO - 2017-02-17 14:33:49 --> Output Class Initialized
INFO - 2017-02-17 14:33:49 --> Security Class Initialized
DEBUG - 2017-02-17 14:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:33:49 --> Input Class Initialized
INFO - 2017-02-17 14:33:49 --> Language Class Initialized
INFO - 2017-02-17 14:33:49 --> Language Class Initialized
INFO - 2017-02-17 14:33:49 --> Config Class Initialized
INFO - 2017-02-17 14:33:49 --> Loader Class Initialized
INFO - 2017-02-17 14:33:49 --> Helper loaded: form_helper
INFO - 2017-02-17 14:33:49 --> Helper loaded: url_helper
INFO - 2017-02-17 14:33:49 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:33:49 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:33:49 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:33:49 --> Template Class Initialized
INFO - 2017-02-17 14:33:49 --> Controller Class Initialized
DEBUG - 2017-02-17 14:33:49 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:33:49 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:33:49 --> Model Class Initialized
INFO - 2017-02-17 14:33:49 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:33:49 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:33:49 --> Final output sent to browser
DEBUG - 2017-02-17 14:33:49 --> Total execution time: 0.0399
INFO - 2017-02-17 14:34:13 --> Config Class Initialized
INFO - 2017-02-17 14:34:13 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:34:13 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:34:13 --> Utf8 Class Initialized
INFO - 2017-02-17 14:34:13 --> URI Class Initialized
INFO - 2017-02-17 14:34:13 --> Router Class Initialized
INFO - 2017-02-17 14:34:13 --> Output Class Initialized
INFO - 2017-02-17 14:34:13 --> Security Class Initialized
DEBUG - 2017-02-17 14:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:34:13 --> Input Class Initialized
INFO - 2017-02-17 14:34:13 --> Language Class Initialized
INFO - 2017-02-17 14:34:13 --> Language Class Initialized
INFO - 2017-02-17 14:34:13 --> Config Class Initialized
INFO - 2017-02-17 14:34:13 --> Loader Class Initialized
INFO - 2017-02-17 14:34:13 --> Helper loaded: form_helper
INFO - 2017-02-17 14:34:13 --> Helper loaded: url_helper
INFO - 2017-02-17 14:34:13 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:34:13 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:34:13 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:34:13 --> Template Class Initialized
INFO - 2017-02-17 14:34:13 --> Controller Class Initialized
DEBUG - 2017-02-17 14:34:13 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:34:13 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:34:13 --> Model Class Initialized
INFO - 2017-02-17 14:34:13 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:34:13 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:34:13 --> Final output sent to browser
DEBUG - 2017-02-17 14:34:13 --> Total execution time: 0.0556
INFO - 2017-02-17 14:34:23 --> Config Class Initialized
INFO - 2017-02-17 14:34:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:34:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:34:23 --> Utf8 Class Initialized
INFO - 2017-02-17 14:34:23 --> URI Class Initialized
INFO - 2017-02-17 14:34:23 --> Router Class Initialized
INFO - 2017-02-17 14:34:23 --> Output Class Initialized
INFO - 2017-02-17 14:34:23 --> Security Class Initialized
DEBUG - 2017-02-17 14:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:34:23 --> Input Class Initialized
INFO - 2017-02-17 14:34:23 --> Language Class Initialized
INFO - 2017-02-17 14:34:23 --> Language Class Initialized
INFO - 2017-02-17 14:34:23 --> Config Class Initialized
INFO - 2017-02-17 14:34:23 --> Loader Class Initialized
INFO - 2017-02-17 14:34:23 --> Helper loaded: form_helper
INFO - 2017-02-17 14:34:23 --> Helper loaded: url_helper
INFO - 2017-02-17 14:34:23 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:34:23 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:34:23 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:34:23 --> Template Class Initialized
INFO - 2017-02-17 14:34:23 --> Controller Class Initialized
DEBUG - 2017-02-17 14:34:23 --> Register MX_Controller Initialized
INFO - 2017-02-17 14:34:23 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:34:23 --> Model Class Initialized
INFO - 2017-02-17 14:34:23 --> Form Validation Class Initialized
INFO - 2017-02-17 14:34:23 --> Config Class Initialized
INFO - 2017-02-17 14:34:23 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:34:23 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:34:23 --> Utf8 Class Initialized
INFO - 2017-02-17 14:34:23 --> URI Class Initialized
INFO - 2017-02-17 14:34:23 --> Router Class Initialized
INFO - 2017-02-17 14:34:23 --> Output Class Initialized
INFO - 2017-02-17 14:34:23 --> Security Class Initialized
DEBUG - 2017-02-17 14:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:34:23 --> Input Class Initialized
INFO - 2017-02-17 14:34:23 --> Language Class Initialized
INFO - 2017-02-17 14:34:23 --> Language Class Initialized
INFO - 2017-02-17 14:34:23 --> Config Class Initialized
INFO - 2017-02-17 14:34:23 --> Loader Class Initialized
INFO - 2017-02-17 14:34:23 --> Helper loaded: form_helper
INFO - 2017-02-17 14:34:23 --> Helper loaded: url_helper
INFO - 2017-02-17 14:34:23 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:34:23 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:34:23 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:34:23 --> Template Class Initialized
INFO - 2017-02-17 14:34:23 --> Controller Class Initialized
DEBUG - 2017-02-17 14:34:23 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:34:23 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:34:23 --> Model Class Initialized
INFO - 2017-02-17 14:34:23 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:34:23 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:34:23 --> Final output sent to browser
DEBUG - 2017-02-17 14:34:23 --> Total execution time: 0.0389
INFO - 2017-02-17 14:34:59 --> Config Class Initialized
INFO - 2017-02-17 14:34:59 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:34:59 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:34:59 --> Utf8 Class Initialized
INFO - 2017-02-17 14:34:59 --> URI Class Initialized
INFO - 2017-02-17 14:34:59 --> Router Class Initialized
INFO - 2017-02-17 14:34:59 --> Output Class Initialized
INFO - 2017-02-17 14:34:59 --> Security Class Initialized
DEBUG - 2017-02-17 14:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:34:59 --> Input Class Initialized
INFO - 2017-02-17 14:34:59 --> Language Class Initialized
INFO - 2017-02-17 14:34:59 --> Language Class Initialized
INFO - 2017-02-17 14:34:59 --> Config Class Initialized
INFO - 2017-02-17 14:34:59 --> Loader Class Initialized
INFO - 2017-02-17 14:34:59 --> Helper loaded: form_helper
INFO - 2017-02-17 14:34:59 --> Helper loaded: url_helper
INFO - 2017-02-17 14:34:59 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:34:59 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:34:59 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:34:59 --> Template Class Initialized
INFO - 2017-02-17 14:34:59 --> Controller Class Initialized
DEBUG - 2017-02-17 14:34:59 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:34:59 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:34:59 --> Model Class Initialized
INFO - 2017-02-17 14:34:59 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:34:59 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:34:59 --> Final output sent to browser
DEBUG - 2017-02-17 14:34:59 --> Total execution time: 0.0755
INFO - 2017-02-17 14:35:11 --> Config Class Initialized
INFO - 2017-02-17 14:35:11 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:35:11 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:35:11 --> Utf8 Class Initialized
INFO - 2017-02-17 14:35:11 --> URI Class Initialized
INFO - 2017-02-17 14:35:11 --> Router Class Initialized
INFO - 2017-02-17 14:35:11 --> Output Class Initialized
INFO - 2017-02-17 14:35:11 --> Security Class Initialized
DEBUG - 2017-02-17 14:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:35:11 --> Input Class Initialized
INFO - 2017-02-17 14:35:11 --> Language Class Initialized
INFO - 2017-02-17 14:35:11 --> Language Class Initialized
INFO - 2017-02-17 14:35:11 --> Config Class Initialized
INFO - 2017-02-17 14:35:11 --> Loader Class Initialized
INFO - 2017-02-17 14:35:11 --> Helper loaded: form_helper
INFO - 2017-02-17 14:35:11 --> Helper loaded: url_helper
INFO - 2017-02-17 14:35:11 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:35:11 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:35:11 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:35:11 --> Template Class Initialized
INFO - 2017-02-17 14:35:11 --> Controller Class Initialized
DEBUG - 2017-02-17 14:35:11 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:35:11 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:35:11 --> Model Class Initialized
INFO - 2017-02-17 14:35:11 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:35:11 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:35:11 --> Final output sent to browser
DEBUG - 2017-02-17 14:35:11 --> Total execution time: 0.0749
INFO - 2017-02-17 14:35:19 --> Config Class Initialized
INFO - 2017-02-17 14:35:19 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:35:19 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:35:19 --> Utf8 Class Initialized
INFO - 2017-02-17 14:35:19 --> URI Class Initialized
INFO - 2017-02-17 14:35:19 --> Router Class Initialized
INFO - 2017-02-17 14:35:19 --> Output Class Initialized
INFO - 2017-02-17 14:35:19 --> Security Class Initialized
DEBUG - 2017-02-17 14:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:35:19 --> Input Class Initialized
INFO - 2017-02-17 14:35:19 --> Language Class Initialized
INFO - 2017-02-17 14:35:19 --> Language Class Initialized
INFO - 2017-02-17 14:35:19 --> Config Class Initialized
INFO - 2017-02-17 14:35:19 --> Loader Class Initialized
INFO - 2017-02-17 14:35:19 --> Helper loaded: form_helper
INFO - 2017-02-17 14:35:19 --> Helper loaded: url_helper
INFO - 2017-02-17 14:35:19 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:35:19 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:35:19 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:35:19 --> Template Class Initialized
INFO - 2017-02-17 14:35:19 --> Controller Class Initialized
DEBUG - 2017-02-17 14:35:19 --> Register MX_Controller Initialized
INFO - 2017-02-17 14:35:19 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:35:19 --> Model Class Initialized
INFO - 2017-02-17 14:35:19 --> Form Validation Class Initialized
INFO - 2017-02-17 14:35:19 --> Config Class Initialized
INFO - 2017-02-17 14:35:19 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:35:19 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:35:19 --> Utf8 Class Initialized
INFO - 2017-02-17 14:35:19 --> URI Class Initialized
INFO - 2017-02-17 14:35:19 --> Router Class Initialized
INFO - 2017-02-17 14:35:19 --> Output Class Initialized
INFO - 2017-02-17 14:35:19 --> Security Class Initialized
DEBUG - 2017-02-17 14:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:35:19 --> Input Class Initialized
INFO - 2017-02-17 14:35:19 --> Language Class Initialized
INFO - 2017-02-17 14:35:19 --> Language Class Initialized
INFO - 2017-02-17 14:35:19 --> Config Class Initialized
INFO - 2017-02-17 14:35:19 --> Loader Class Initialized
INFO - 2017-02-17 14:35:19 --> Helper loaded: form_helper
INFO - 2017-02-17 14:35:19 --> Helper loaded: url_helper
INFO - 2017-02-17 14:35:19 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:35:19 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:35:19 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:35:19 --> Template Class Initialized
INFO - 2017-02-17 14:35:19 --> Controller Class Initialized
DEBUG - 2017-02-17 14:35:19 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:35:19 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:35:19 --> Model Class Initialized
INFO - 2017-02-17 14:35:19 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:35:19 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:35:19 --> Final output sent to browser
DEBUG - 2017-02-17 14:35:19 --> Total execution time: 0.0418
INFO - 2017-02-17 14:35:41 --> Config Class Initialized
INFO - 2017-02-17 14:35:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:35:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:35:41 --> Utf8 Class Initialized
INFO - 2017-02-17 14:35:41 --> URI Class Initialized
INFO - 2017-02-17 14:35:41 --> Router Class Initialized
INFO - 2017-02-17 14:35:41 --> Output Class Initialized
INFO - 2017-02-17 14:35:41 --> Security Class Initialized
DEBUG - 2017-02-17 14:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:35:41 --> Input Class Initialized
INFO - 2017-02-17 14:35:41 --> Language Class Initialized
INFO - 2017-02-17 14:35:41 --> Language Class Initialized
INFO - 2017-02-17 14:35:41 --> Config Class Initialized
INFO - 2017-02-17 14:35:41 --> Loader Class Initialized
INFO - 2017-02-17 14:35:41 --> Helper loaded: form_helper
INFO - 2017-02-17 14:35:41 --> Helper loaded: url_helper
INFO - 2017-02-17 14:35:41 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:35:41 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:35:41 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:35:41 --> Template Class Initialized
INFO - 2017-02-17 14:35:41 --> Controller Class Initialized
DEBUG - 2017-02-17 14:35:41 --> Register MX_Controller Initialized
INFO - 2017-02-17 14:35:41 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:35:41 --> Model Class Initialized
INFO - 2017-02-17 14:35:41 --> Form Validation Class Initialized
INFO - 2017-02-17 14:36:07 --> Config Class Initialized
INFO - 2017-02-17 14:36:07 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:36:07 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:36:07 --> Utf8 Class Initialized
INFO - 2017-02-17 14:36:07 --> URI Class Initialized
INFO - 2017-02-17 14:36:07 --> Router Class Initialized
INFO - 2017-02-17 14:36:07 --> Output Class Initialized
INFO - 2017-02-17 14:36:07 --> Security Class Initialized
DEBUG - 2017-02-17 14:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:36:07 --> Input Class Initialized
INFO - 2017-02-17 14:36:07 --> Language Class Initialized
INFO - 2017-02-17 14:36:07 --> Language Class Initialized
INFO - 2017-02-17 14:36:07 --> Config Class Initialized
INFO - 2017-02-17 14:36:07 --> Loader Class Initialized
INFO - 2017-02-17 14:36:07 --> Helper loaded: form_helper
INFO - 2017-02-17 14:36:07 --> Helper loaded: url_helper
INFO - 2017-02-17 14:36:07 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:36:07 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:36:07 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:36:07 --> Template Class Initialized
INFO - 2017-02-17 14:36:07 --> Controller Class Initialized
DEBUG - 2017-02-17 14:36:07 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:36:07 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:36:07 --> Model Class Initialized
INFO - 2017-02-17 14:36:07 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:36:07 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:36:07 --> Final output sent to browser
DEBUG - 2017-02-17 14:36:07 --> Total execution time: 0.0439
INFO - 2017-02-17 14:36:08 --> Config Class Initialized
INFO - 2017-02-17 14:36:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:36:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:36:08 --> Utf8 Class Initialized
INFO - 2017-02-17 14:36:08 --> URI Class Initialized
INFO - 2017-02-17 14:36:08 --> Router Class Initialized
INFO - 2017-02-17 14:36:08 --> Output Class Initialized
INFO - 2017-02-17 14:36:08 --> Security Class Initialized
DEBUG - 2017-02-17 14:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:36:08 --> Input Class Initialized
INFO - 2017-02-17 14:36:08 --> Language Class Initialized
INFO - 2017-02-17 14:36:08 --> Language Class Initialized
INFO - 2017-02-17 14:36:08 --> Config Class Initialized
INFO - 2017-02-17 14:36:08 --> Loader Class Initialized
INFO - 2017-02-17 14:36:08 --> Helper loaded: form_helper
INFO - 2017-02-17 14:36:08 --> Helper loaded: url_helper
INFO - 2017-02-17 14:36:08 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:36:08 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:36:08 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:36:08 --> Template Class Initialized
INFO - 2017-02-17 14:36:08 --> Controller Class Initialized
DEBUG - 2017-02-17 14:36:08 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:36:08 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:36:08 --> Model Class Initialized
INFO - 2017-02-17 14:36:08 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:36:08 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:36:08 --> Final output sent to browser
DEBUG - 2017-02-17 14:36:08 --> Total execution time: 0.0620
INFO - 2017-02-17 14:36:15 --> Config Class Initialized
INFO - 2017-02-17 14:36:15 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:36:15 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:36:15 --> Utf8 Class Initialized
INFO - 2017-02-17 14:36:15 --> URI Class Initialized
INFO - 2017-02-17 14:36:15 --> Router Class Initialized
INFO - 2017-02-17 14:36:15 --> Output Class Initialized
INFO - 2017-02-17 14:36:15 --> Security Class Initialized
DEBUG - 2017-02-17 14:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:36:15 --> Input Class Initialized
INFO - 2017-02-17 14:36:15 --> Language Class Initialized
INFO - 2017-02-17 14:36:15 --> Language Class Initialized
INFO - 2017-02-17 14:36:15 --> Config Class Initialized
INFO - 2017-02-17 14:36:15 --> Loader Class Initialized
INFO - 2017-02-17 14:36:15 --> Helper loaded: form_helper
INFO - 2017-02-17 14:36:15 --> Helper loaded: url_helper
INFO - 2017-02-17 14:36:15 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:36:15 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:36:15 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:36:15 --> Template Class Initialized
INFO - 2017-02-17 14:36:15 --> Controller Class Initialized
DEBUG - 2017-02-17 14:36:15 --> Register MX_Controller Initialized
INFO - 2017-02-17 14:36:15 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:36:15 --> Model Class Initialized
INFO - 2017-02-17 14:36:15 --> Form Validation Class Initialized
INFO - 2017-02-17 14:36:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 14:36:15 --> Config Class Initialized
INFO - 2017-02-17 14:36:15 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:36:15 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:36:15 --> Utf8 Class Initialized
INFO - 2017-02-17 14:36:15 --> URI Class Initialized
INFO - 2017-02-17 14:36:15 --> Router Class Initialized
INFO - 2017-02-17 14:36:15 --> Output Class Initialized
INFO - 2017-02-17 14:36:15 --> Security Class Initialized
DEBUG - 2017-02-17 14:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:36:15 --> Input Class Initialized
INFO - 2017-02-17 14:36:15 --> Language Class Initialized
INFO - 2017-02-17 14:36:15 --> Language Class Initialized
INFO - 2017-02-17 14:36:15 --> Config Class Initialized
INFO - 2017-02-17 14:36:15 --> Loader Class Initialized
INFO - 2017-02-17 14:36:15 --> Helper loaded: form_helper
INFO - 2017-02-17 14:36:15 --> Helper loaded: url_helper
INFO - 2017-02-17 14:36:15 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:36:15 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:36:15 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:36:15 --> Template Class Initialized
INFO - 2017-02-17 14:36:15 --> Controller Class Initialized
DEBUG - 2017-02-17 14:36:15 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:36:15 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:36:15 --> Model Class Initialized
INFO - 2017-02-17 14:36:15 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:36:15 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:36:15 --> Final output sent to browser
DEBUG - 2017-02-17 14:36:15 --> Total execution time: 0.0598
INFO - 2017-02-17 14:36:40 --> Config Class Initialized
INFO - 2017-02-17 14:36:40 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:36:40 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:36:40 --> Utf8 Class Initialized
INFO - 2017-02-17 14:36:40 --> URI Class Initialized
INFO - 2017-02-17 14:36:40 --> Router Class Initialized
INFO - 2017-02-17 14:36:40 --> Output Class Initialized
INFO - 2017-02-17 14:36:40 --> Security Class Initialized
DEBUG - 2017-02-17 14:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:36:40 --> Input Class Initialized
INFO - 2017-02-17 14:36:40 --> Language Class Initialized
INFO - 2017-02-17 14:36:40 --> Language Class Initialized
INFO - 2017-02-17 14:36:40 --> Config Class Initialized
INFO - 2017-02-17 14:36:40 --> Loader Class Initialized
INFO - 2017-02-17 14:36:40 --> Helper loaded: form_helper
INFO - 2017-02-17 14:36:40 --> Helper loaded: url_helper
INFO - 2017-02-17 14:36:40 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:36:40 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:36:40 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:36:40 --> Template Class Initialized
INFO - 2017-02-17 14:36:40 --> Controller Class Initialized
DEBUG - 2017-02-17 14:36:40 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:36:40 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:36:40 --> Model Class Initialized
INFO - 2017-02-17 14:36:40 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:36:40 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:36:40 --> Final output sent to browser
DEBUG - 2017-02-17 14:36:40 --> Total execution time: 0.0572
INFO - 2017-02-17 14:36:43 --> Config Class Initialized
INFO - 2017-02-17 14:36:43 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:36:43 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:36:43 --> Utf8 Class Initialized
INFO - 2017-02-17 14:36:43 --> URI Class Initialized
INFO - 2017-02-17 14:36:43 --> Router Class Initialized
INFO - 2017-02-17 14:36:43 --> Output Class Initialized
INFO - 2017-02-17 14:36:43 --> Security Class Initialized
DEBUG - 2017-02-17 14:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:36:43 --> Input Class Initialized
INFO - 2017-02-17 14:36:43 --> Language Class Initialized
INFO - 2017-02-17 14:36:43 --> Language Class Initialized
INFO - 2017-02-17 14:36:43 --> Config Class Initialized
INFO - 2017-02-17 14:36:43 --> Loader Class Initialized
INFO - 2017-02-17 14:36:43 --> Helper loaded: form_helper
INFO - 2017-02-17 14:36:43 --> Helper loaded: url_helper
INFO - 2017-02-17 14:36:43 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:36:43 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:36:43 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:36:43 --> Template Class Initialized
INFO - 2017-02-17 14:36:43 --> Controller Class Initialized
DEBUG - 2017-02-17 14:36:43 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:36:43 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:36:43 --> Model Class Initialized
INFO - 2017-02-17 14:36:43 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:36:43 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:36:43 --> Final output sent to browser
DEBUG - 2017-02-17 14:36:43 --> Total execution time: 0.0765
INFO - 2017-02-17 14:36:51 --> Config Class Initialized
INFO - 2017-02-17 14:36:51 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:36:51 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:36:51 --> Utf8 Class Initialized
INFO - 2017-02-17 14:36:51 --> URI Class Initialized
INFO - 2017-02-17 14:36:51 --> Router Class Initialized
INFO - 2017-02-17 14:36:51 --> Output Class Initialized
INFO - 2017-02-17 14:36:51 --> Security Class Initialized
DEBUG - 2017-02-17 14:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:36:51 --> Input Class Initialized
INFO - 2017-02-17 14:36:51 --> Language Class Initialized
INFO - 2017-02-17 14:36:51 --> Language Class Initialized
INFO - 2017-02-17 14:36:51 --> Config Class Initialized
INFO - 2017-02-17 14:36:51 --> Loader Class Initialized
INFO - 2017-02-17 14:36:51 --> Helper loaded: form_helper
INFO - 2017-02-17 14:36:51 --> Helper loaded: url_helper
INFO - 2017-02-17 14:36:51 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:36:51 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:36:51 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:36:51 --> Template Class Initialized
INFO - 2017-02-17 14:36:51 --> Controller Class Initialized
DEBUG - 2017-02-17 14:36:51 --> Register MX_Controller Initialized
INFO - 2017-02-17 14:36:51 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:36:51 --> Model Class Initialized
INFO - 2017-02-17 14:36:51 --> Form Validation Class Initialized
INFO - 2017-02-17 14:36:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 14:36:51 --> Config Class Initialized
INFO - 2017-02-17 14:36:51 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:36:51 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:36:51 --> Utf8 Class Initialized
INFO - 2017-02-17 14:36:51 --> URI Class Initialized
INFO - 2017-02-17 14:36:51 --> Router Class Initialized
INFO - 2017-02-17 14:36:51 --> Output Class Initialized
INFO - 2017-02-17 14:36:51 --> Security Class Initialized
DEBUG - 2017-02-17 14:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:36:51 --> Input Class Initialized
INFO - 2017-02-17 14:36:51 --> Language Class Initialized
INFO - 2017-02-17 14:36:51 --> Language Class Initialized
INFO - 2017-02-17 14:36:51 --> Config Class Initialized
INFO - 2017-02-17 14:36:51 --> Loader Class Initialized
INFO - 2017-02-17 14:36:51 --> Helper loaded: form_helper
INFO - 2017-02-17 14:36:51 --> Helper loaded: url_helper
INFO - 2017-02-17 14:36:51 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:36:51 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:36:51 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:36:51 --> Template Class Initialized
INFO - 2017-02-17 14:36:51 --> Controller Class Initialized
DEBUG - 2017-02-17 14:36:51 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:36:51 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:36:51 --> Model Class Initialized
INFO - 2017-02-17 14:36:51 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:36:51 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:36:51 --> Final output sent to browser
DEBUG - 2017-02-17 14:36:51 --> Total execution time: 0.0606
INFO - 2017-02-17 14:37:08 --> Config Class Initialized
INFO - 2017-02-17 14:37:08 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:37:08 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:37:08 --> Utf8 Class Initialized
INFO - 2017-02-17 14:37:08 --> URI Class Initialized
INFO - 2017-02-17 14:37:08 --> Router Class Initialized
INFO - 2017-02-17 14:37:08 --> Output Class Initialized
INFO - 2017-02-17 14:37:08 --> Security Class Initialized
DEBUG - 2017-02-17 14:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:37:08 --> Input Class Initialized
INFO - 2017-02-17 14:37:08 --> Language Class Initialized
INFO - 2017-02-17 14:37:08 --> Language Class Initialized
INFO - 2017-02-17 14:37:08 --> Config Class Initialized
INFO - 2017-02-17 14:37:08 --> Loader Class Initialized
INFO - 2017-02-17 14:37:08 --> Helper loaded: form_helper
INFO - 2017-02-17 14:37:08 --> Helper loaded: url_helper
INFO - 2017-02-17 14:37:08 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:37:08 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:37:08 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:37:08 --> Template Class Initialized
INFO - 2017-02-17 14:37:08 --> Controller Class Initialized
DEBUG - 2017-02-17 14:37:08 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:37:08 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:37:08 --> Model Class Initialized
INFO - 2017-02-17 14:37:08 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:37:08 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:37:08 --> Final output sent to browser
DEBUG - 2017-02-17 14:37:08 --> Total execution time: 0.0574
INFO - 2017-02-17 14:37:16 --> Config Class Initialized
INFO - 2017-02-17 14:37:16 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:37:16 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:37:16 --> Utf8 Class Initialized
INFO - 2017-02-17 14:37:16 --> URI Class Initialized
INFO - 2017-02-17 14:37:16 --> Router Class Initialized
INFO - 2017-02-17 14:37:16 --> Output Class Initialized
INFO - 2017-02-17 14:37:16 --> Security Class Initialized
DEBUG - 2017-02-17 14:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:37:16 --> Input Class Initialized
INFO - 2017-02-17 14:37:16 --> Language Class Initialized
INFO - 2017-02-17 14:37:16 --> Language Class Initialized
INFO - 2017-02-17 14:37:16 --> Config Class Initialized
INFO - 2017-02-17 14:37:16 --> Loader Class Initialized
INFO - 2017-02-17 14:37:16 --> Helper loaded: form_helper
INFO - 2017-02-17 14:37:16 --> Helper loaded: url_helper
INFO - 2017-02-17 14:37:16 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:37:16 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:37:16 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:37:16 --> Template Class Initialized
INFO - 2017-02-17 14:37:16 --> Controller Class Initialized
DEBUG - 2017-02-17 14:37:16 --> Register MX_Controller Initialized
INFO - 2017-02-17 14:37:16 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:37:16 --> Model Class Initialized
INFO - 2017-02-17 14:37:16 --> Form Validation Class Initialized
INFO - 2017-02-17 14:37:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 14:37:16 --> Config Class Initialized
INFO - 2017-02-17 14:37:16 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:37:16 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:37:16 --> Utf8 Class Initialized
INFO - 2017-02-17 14:37:16 --> URI Class Initialized
INFO - 2017-02-17 14:37:16 --> Router Class Initialized
INFO - 2017-02-17 14:37:16 --> Output Class Initialized
INFO - 2017-02-17 14:37:16 --> Security Class Initialized
DEBUG - 2017-02-17 14:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:37:16 --> Input Class Initialized
INFO - 2017-02-17 14:37:16 --> Language Class Initialized
INFO - 2017-02-17 14:37:16 --> Language Class Initialized
INFO - 2017-02-17 14:37:16 --> Config Class Initialized
INFO - 2017-02-17 14:37:16 --> Loader Class Initialized
INFO - 2017-02-17 14:37:16 --> Helper loaded: form_helper
INFO - 2017-02-17 14:37:16 --> Helper loaded: url_helper
INFO - 2017-02-17 14:37:16 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:37:16 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:37:16 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:37:16 --> Template Class Initialized
INFO - 2017-02-17 14:37:16 --> Controller Class Initialized
DEBUG - 2017-02-17 14:37:16 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:37:16 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:37:16 --> Model Class Initialized
INFO - 2017-02-17 14:37:16 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:37:16 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:37:16 --> Final output sent to browser
DEBUG - 2017-02-17 14:37:16 --> Total execution time: 0.0440
INFO - 2017-02-17 14:40:43 --> Config Class Initialized
INFO - 2017-02-17 14:40:43 --> Hooks Class Initialized
DEBUG - 2017-02-17 14:40:43 --> UTF-8 Support Enabled
INFO - 2017-02-17 14:40:43 --> Utf8 Class Initialized
INFO - 2017-02-17 14:40:43 --> URI Class Initialized
INFO - 2017-02-17 14:40:43 --> Router Class Initialized
INFO - 2017-02-17 14:40:43 --> Output Class Initialized
INFO - 2017-02-17 14:40:43 --> Security Class Initialized
DEBUG - 2017-02-17 14:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 14:40:43 --> Input Class Initialized
INFO - 2017-02-17 14:40:44 --> Language Class Initialized
INFO - 2017-02-17 14:40:44 --> Language Class Initialized
INFO - 2017-02-17 14:40:44 --> Config Class Initialized
INFO - 2017-02-17 14:40:44 --> Loader Class Initialized
INFO - 2017-02-17 14:40:44 --> Helper loaded: form_helper
INFO - 2017-02-17 14:40:44 --> Helper loaded: url_helper
INFO - 2017-02-17 14:40:44 --> Helper loaded: utility_helper
INFO - 2017-02-17 14:40:44 --> Database Driver Class Initialized
DEBUG - 2017-02-17 14:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 14:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 14:40:44 --> User Agent Class Initialized
DEBUG - 2017-02-17 14:40:44 --> Template Class Initialized
INFO - 2017-02-17 14:40:44 --> Controller Class Initialized
DEBUG - 2017-02-17 14:40:44 --> Login MX_Controller Initialized
INFO - 2017-02-17 14:40:44 --> Helper loaded: cookie_helper
INFO - 2017-02-17 14:40:44 --> Model Class Initialized
INFO - 2017-02-17 14:40:44 --> Form Validation Class Initialized
DEBUG - 2017-02-17 14:40:44 --> File loaded: C:\xampp\htdocs\razor\application\modules/backend/views/login.php
INFO - 2017-02-17 14:40:44 --> Final output sent to browser
DEBUG - 2017-02-17 14:40:44 --> Total execution time: 1.1044
INFO - 2017-02-17 15:40:09 --> Config Class Initialized
INFO - 2017-02-17 15:40:09 --> Hooks Class Initialized
DEBUG - 2017-02-17 15:40:10 --> UTF-8 Support Enabled
INFO - 2017-02-17 15:40:10 --> Utf8 Class Initialized
INFO - 2017-02-17 15:40:10 --> URI Class Initialized
INFO - 2017-02-17 15:40:10 --> Router Class Initialized
INFO - 2017-02-17 15:40:10 --> Output Class Initialized
INFO - 2017-02-17 15:40:10 --> Security Class Initialized
DEBUG - 2017-02-17 15:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 15:40:10 --> Input Class Initialized
INFO - 2017-02-17 15:40:10 --> Language Class Initialized
INFO - 2017-02-17 15:40:10 --> Language Class Initialized
INFO - 2017-02-17 15:40:10 --> Config Class Initialized
INFO - 2017-02-17 15:40:10 --> Loader Class Initialized
INFO - 2017-02-17 15:40:11 --> Helper loaded: form_helper
INFO - 2017-02-17 15:40:11 --> Helper loaded: url_helper
INFO - 2017-02-17 15:40:11 --> Helper loaded: utility_helper
INFO - 2017-02-17 15:40:11 --> Database Driver Class Initialized
DEBUG - 2017-02-17 15:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 15:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 15:40:15 --> User Agent Class Initialized
DEBUG - 2017-02-17 15:40:15 --> Template Class Initialized
INFO - 2017-02-17 15:40:15 --> Controller Class Initialized
DEBUG - 2017-02-17 15:40:15 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 15:40:15 --> Helper loaded: cookie_helper
INFO - 2017-02-17 15:40:15 --> Model Class Initialized
ERROR - 2017-02-17 15:40:15 --> Severity: Notice --> Undefined index: username C:\xampp\htdocs\RazorClean\application\modules\backend\views\partials\header.php 13
DEBUG - 2017-02-17 15:40:15 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 15:40:15 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 15:40:15 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 15:40:15 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/backend/views/admin/dashboard.php
DEBUG - 2017-02-17 15:40:15 --> File loaded: C:\xampp\htdocs\RazorClean\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 15:40:15 --> Final output sent to browser
DEBUG - 2017-02-17 15:40:15 --> Total execution time: 6.2688
INFO - 2017-02-17 15:40:34 --> Config Class Initialized
INFO - 2017-02-17 15:40:34 --> Hooks Class Initialized
DEBUG - 2017-02-17 15:40:34 --> UTF-8 Support Enabled
INFO - 2017-02-17 15:40:34 --> Utf8 Class Initialized
INFO - 2017-02-17 15:40:34 --> URI Class Initialized
INFO - 2017-02-17 15:40:34 --> Router Class Initialized
INFO - 2017-02-17 15:40:34 --> Output Class Initialized
INFO - 2017-02-17 15:40:34 --> Security Class Initialized
DEBUG - 2017-02-17 15:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 15:40:34 --> Input Class Initialized
INFO - 2017-02-17 15:40:34 --> Language Class Initialized
INFO - 2017-02-17 15:40:35 --> Language Class Initialized
INFO - 2017-02-17 15:40:35 --> Config Class Initialized
INFO - 2017-02-17 15:40:35 --> Loader Class Initialized
INFO - 2017-02-17 15:40:35 --> Helper loaded: form_helper
INFO - 2017-02-17 15:40:35 --> Helper loaded: url_helper
INFO - 2017-02-17 15:40:35 --> Helper loaded: utility_helper
INFO - 2017-02-17 15:40:35 --> Database Driver Class Initialized
DEBUG - 2017-02-17 15:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 15:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 15:40:35 --> User Agent Class Initialized
DEBUG - 2017-02-17 15:40:35 --> Template Class Initialized
INFO - 2017-02-17 15:40:35 --> Controller Class Initialized
DEBUG - 2017-02-17 15:40:35 --> Login MX_Controller Initialized
INFO - 2017-02-17 15:40:35 --> Helper loaded: cookie_helper
INFO - 2017-02-17 15:40:35 --> Model Class Initialized
INFO - 2017-02-17 15:40:35 --> Form Validation Class Initialized
DEBUG - 2017-02-17 15:40:35 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/backend/views/login.php
INFO - 2017-02-17 15:40:35 --> Final output sent to browser
DEBUG - 2017-02-17 15:40:35 --> Total execution time: 0.4939
INFO - 2017-02-17 16:37:19 --> Config Class Initialized
INFO - 2017-02-17 16:37:19 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:37:19 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:37:19 --> Utf8 Class Initialized
INFO - 2017-02-17 16:37:19 --> URI Class Initialized
INFO - 2017-02-17 16:37:19 --> Router Class Initialized
INFO - 2017-02-17 16:37:19 --> Output Class Initialized
INFO - 2017-02-17 16:37:19 --> Security Class Initialized
DEBUG - 2017-02-17 16:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:37:19 --> Input Class Initialized
INFO - 2017-02-17 16:37:19 --> Language Class Initialized
INFO - 2017-02-17 16:37:19 --> Language Class Initialized
INFO - 2017-02-17 16:37:19 --> Config Class Initialized
INFO - 2017-02-17 16:37:19 --> Loader Class Initialized
INFO - 2017-02-17 16:37:19 --> Helper loaded: form_helper
INFO - 2017-02-17 16:37:19 --> Helper loaded: url_helper
INFO - 2017-02-17 16:37:19 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:37:19 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:37:19 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:37:19 --> Template Class Initialized
INFO - 2017-02-17 16:37:19 --> Controller Class Initialized
DEBUG - 2017-02-17 16:37:19 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:37:19 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:37:19 --> Model Class Initialized
INFO - 2017-02-17 16:37:19 --> Form Validation Class Initialized
ERROR - 2017-02-17 16:37:19 --> Severity: Error --> Call to undefined function fronend_asset_url() C:\xampp\htdocs\RazorClean\application\modules\frontend\views\login.php 56
INFO - 2017-02-17 16:37:20 --> Config Class Initialized
INFO - 2017-02-17 16:37:20 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:37:20 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:37:20 --> Utf8 Class Initialized
INFO - 2017-02-17 16:37:20 --> URI Class Initialized
INFO - 2017-02-17 16:37:20 --> Router Class Initialized
INFO - 2017-02-17 16:37:20 --> Output Class Initialized
INFO - 2017-02-17 16:37:20 --> Security Class Initialized
DEBUG - 2017-02-17 16:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:37:20 --> Input Class Initialized
INFO - 2017-02-17 16:37:20 --> Language Class Initialized
ERROR - 2017-02-17 16:37:20 --> 404 Page Not Found: /index
INFO - 2017-02-17 16:37:41 --> Config Class Initialized
INFO - 2017-02-17 16:37:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:37:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:37:41 --> Utf8 Class Initialized
INFO - 2017-02-17 16:37:41 --> URI Class Initialized
INFO - 2017-02-17 16:37:41 --> Router Class Initialized
INFO - 2017-02-17 16:37:41 --> Output Class Initialized
INFO - 2017-02-17 16:37:41 --> Security Class Initialized
DEBUG - 2017-02-17 16:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:37:41 --> Input Class Initialized
INFO - 2017-02-17 16:37:41 --> Language Class Initialized
INFO - 2017-02-17 16:37:41 --> Language Class Initialized
INFO - 2017-02-17 16:37:41 --> Config Class Initialized
INFO - 2017-02-17 16:37:41 --> Loader Class Initialized
INFO - 2017-02-17 16:37:41 --> Helper loaded: form_helper
INFO - 2017-02-17 16:37:41 --> Helper loaded: url_helper
INFO - 2017-02-17 16:37:41 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:37:41 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:37:41 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:37:41 --> Template Class Initialized
INFO - 2017-02-17 16:37:41 --> Controller Class Initialized
DEBUG - 2017-02-17 16:37:41 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:37:41 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:37:41 --> Model Class Initialized
INFO - 2017-02-17 16:37:41 --> Form Validation Class Initialized
ERROR - 2017-02-17 16:37:41 --> Severity: Error --> Call to undefined function fronttend_asset_url() C:\xampp\htdocs\RazorClean\application\modules\frontend\views\login.php 57
INFO - 2017-02-17 16:37:42 --> Config Class Initialized
INFO - 2017-02-17 16:37:42 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:37:42 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:37:42 --> Utf8 Class Initialized
INFO - 2017-02-17 16:37:42 --> URI Class Initialized
INFO - 2017-02-17 16:37:42 --> Router Class Initialized
INFO - 2017-02-17 16:37:42 --> Output Class Initialized
INFO - 2017-02-17 16:37:42 --> Security Class Initialized
DEBUG - 2017-02-17 16:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:37:42 --> Input Class Initialized
INFO - 2017-02-17 16:37:42 --> Language Class Initialized
ERROR - 2017-02-17 16:37:42 --> 404 Page Not Found: /index
INFO - 2017-02-17 16:38:00 --> Config Class Initialized
INFO - 2017-02-17 16:38:00 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:38:00 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:38:00 --> Utf8 Class Initialized
INFO - 2017-02-17 16:38:00 --> URI Class Initialized
INFO - 2017-02-17 16:38:00 --> Router Class Initialized
INFO - 2017-02-17 16:38:00 --> Output Class Initialized
INFO - 2017-02-17 16:38:00 --> Security Class Initialized
DEBUG - 2017-02-17 16:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:38:00 --> Input Class Initialized
INFO - 2017-02-17 16:38:00 --> Language Class Initialized
INFO - 2017-02-17 16:38:00 --> Language Class Initialized
INFO - 2017-02-17 16:38:00 --> Config Class Initialized
INFO - 2017-02-17 16:38:00 --> Loader Class Initialized
INFO - 2017-02-17 16:38:00 --> Helper loaded: form_helper
INFO - 2017-02-17 16:38:00 --> Helper loaded: url_helper
INFO - 2017-02-17 16:38:00 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:38:00 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:38:00 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:38:00 --> Template Class Initialized
INFO - 2017-02-17 16:38:00 --> Controller Class Initialized
DEBUG - 2017-02-17 16:38:00 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:38:00 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:38:00 --> Model Class Initialized
INFO - 2017-02-17 16:38:00 --> Form Validation Class Initialized
ERROR - 2017-02-17 16:38:00 --> Severity: Error --> Call to undefined function fronttend_asset_url() C:\xampp\htdocs\RazorClean\application\modules\frontend\views\login.php 57
INFO - 2017-02-17 16:38:00 --> Config Class Initialized
INFO - 2017-02-17 16:38:00 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:38:00 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:38:00 --> Utf8 Class Initialized
INFO - 2017-02-17 16:38:00 --> URI Class Initialized
INFO - 2017-02-17 16:38:00 --> Router Class Initialized
INFO - 2017-02-17 16:38:00 --> Output Class Initialized
INFO - 2017-02-17 16:38:00 --> Security Class Initialized
DEBUG - 2017-02-17 16:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:38:00 --> Input Class Initialized
INFO - 2017-02-17 16:38:00 --> Language Class Initialized
ERROR - 2017-02-17 16:38:00 --> 404 Page Not Found: /index
INFO - 2017-02-17 16:38:02 --> Config Class Initialized
INFO - 2017-02-17 16:38:02 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:38:02 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:38:02 --> Utf8 Class Initialized
INFO - 2017-02-17 16:38:02 --> URI Class Initialized
INFO - 2017-02-17 16:38:02 --> Router Class Initialized
INFO - 2017-02-17 16:38:02 --> Output Class Initialized
INFO - 2017-02-17 16:38:02 --> Security Class Initialized
DEBUG - 2017-02-17 16:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:38:02 --> Input Class Initialized
INFO - 2017-02-17 16:38:02 --> Language Class Initialized
INFO - 2017-02-17 16:38:02 --> Language Class Initialized
INFO - 2017-02-17 16:38:02 --> Config Class Initialized
INFO - 2017-02-17 16:38:02 --> Loader Class Initialized
INFO - 2017-02-17 16:38:02 --> Helper loaded: form_helper
INFO - 2017-02-17 16:38:02 --> Helper loaded: url_helper
INFO - 2017-02-17 16:38:02 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:38:02 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:38:02 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:38:02 --> Template Class Initialized
INFO - 2017-02-17 16:38:02 --> Controller Class Initialized
DEBUG - 2017-02-17 16:38:02 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:38:02 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:38:02 --> Model Class Initialized
INFO - 2017-02-17 16:38:02 --> Form Validation Class Initialized
ERROR - 2017-02-17 16:38:02 --> Severity: Error --> Call to undefined function fronttend_asset_url() C:\xampp\htdocs\RazorClean\application\modules\frontend\views\login.php 57
INFO - 2017-02-17 16:38:02 --> Config Class Initialized
INFO - 2017-02-17 16:38:02 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:38:02 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:38:02 --> Utf8 Class Initialized
INFO - 2017-02-17 16:38:02 --> URI Class Initialized
INFO - 2017-02-17 16:38:02 --> Router Class Initialized
INFO - 2017-02-17 16:38:02 --> Output Class Initialized
INFO - 2017-02-17 16:38:02 --> Security Class Initialized
DEBUG - 2017-02-17 16:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:38:02 --> Input Class Initialized
INFO - 2017-02-17 16:38:02 --> Language Class Initialized
ERROR - 2017-02-17 16:38:02 --> 404 Page Not Found: /index
INFO - 2017-02-17 16:38:11 --> Config Class Initialized
INFO - 2017-02-17 16:38:11 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:38:11 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:38:11 --> Utf8 Class Initialized
INFO - 2017-02-17 16:38:11 --> URI Class Initialized
INFO - 2017-02-17 16:38:11 --> Router Class Initialized
INFO - 2017-02-17 16:38:11 --> Output Class Initialized
INFO - 2017-02-17 16:38:11 --> Security Class Initialized
DEBUG - 2017-02-17 16:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:38:11 --> Input Class Initialized
INFO - 2017-02-17 16:38:11 --> Language Class Initialized
INFO - 2017-02-17 16:38:11 --> Language Class Initialized
INFO - 2017-02-17 16:38:11 --> Config Class Initialized
INFO - 2017-02-17 16:38:11 --> Loader Class Initialized
INFO - 2017-02-17 16:38:11 --> Helper loaded: form_helper
INFO - 2017-02-17 16:38:11 --> Helper loaded: url_helper
INFO - 2017-02-17 16:38:11 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:38:11 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:38:11 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:38:11 --> Template Class Initialized
INFO - 2017-02-17 16:38:11 --> Controller Class Initialized
DEBUG - 2017-02-17 16:38:11 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:38:11 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:38:11 --> Model Class Initialized
INFO - 2017-02-17 16:38:11 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:38:11 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:38:11 --> Final output sent to browser
DEBUG - 2017-02-17 16:38:11 --> Total execution time: 0.0751
INFO - 2017-02-17 16:38:11 --> Config Class Initialized
INFO - 2017-02-17 16:38:11 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:38:11 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:38:11 --> Utf8 Class Initialized
INFO - 2017-02-17 16:38:11 --> URI Class Initialized
INFO - 2017-02-17 16:38:11 --> Router Class Initialized
INFO - 2017-02-17 16:38:11 --> Output Class Initialized
INFO - 2017-02-17 16:38:11 --> Security Class Initialized
DEBUG - 2017-02-17 16:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:38:11 --> Input Class Initialized
INFO - 2017-02-17 16:38:11 --> Language Class Initialized
ERROR - 2017-02-17 16:38:11 --> 404 Page Not Found: /index
INFO - 2017-02-17 16:38:41 --> Config Class Initialized
INFO - 2017-02-17 16:38:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:38:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:38:41 --> Utf8 Class Initialized
INFO - 2017-02-17 16:38:41 --> URI Class Initialized
INFO - 2017-02-17 16:38:41 --> Router Class Initialized
INFO - 2017-02-17 16:38:41 --> Output Class Initialized
INFO - 2017-02-17 16:38:41 --> Security Class Initialized
DEBUG - 2017-02-17 16:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:38:41 --> Input Class Initialized
INFO - 2017-02-17 16:38:41 --> Language Class Initialized
INFO - 2017-02-17 16:38:41 --> Language Class Initialized
INFO - 2017-02-17 16:38:41 --> Config Class Initialized
INFO - 2017-02-17 16:38:41 --> Loader Class Initialized
INFO - 2017-02-17 16:38:41 --> Helper loaded: form_helper
INFO - 2017-02-17 16:38:41 --> Helper loaded: url_helper
INFO - 2017-02-17 16:38:41 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:38:41 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:38:41 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:38:41 --> Template Class Initialized
INFO - 2017-02-17 16:38:41 --> Controller Class Initialized
DEBUG - 2017-02-17 16:38:41 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:38:41 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:38:41 --> Model Class Initialized
INFO - 2017-02-17 16:38:41 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:38:41 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:38:41 --> Final output sent to browser
DEBUG - 2017-02-17 16:38:41 --> Total execution time: 0.1353
INFO - 2017-02-17 16:38:41 --> Config Class Initialized
INFO - 2017-02-17 16:38:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:38:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:38:41 --> Utf8 Class Initialized
INFO - 2017-02-17 16:38:41 --> URI Class Initialized
INFO - 2017-02-17 16:38:41 --> Router Class Initialized
INFO - 2017-02-17 16:38:41 --> Output Class Initialized
INFO - 2017-02-17 16:38:41 --> Security Class Initialized
DEBUG - 2017-02-17 16:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:38:41 --> Input Class Initialized
INFO - 2017-02-17 16:38:41 --> Language Class Initialized
ERROR - 2017-02-17 16:38:41 --> 404 Page Not Found: /index
INFO - 2017-02-17 16:38:41 --> Config Class Initialized
INFO - 2017-02-17 16:38:41 --> Hooks Class Initialized
INFO - 2017-02-17 16:38:41 --> Config Class Initialized
INFO - 2017-02-17 16:38:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:38:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:38:41 --> Utf8 Class Initialized
INFO - 2017-02-17 16:38:41 --> URI Class Initialized
DEBUG - 2017-02-17 16:38:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:38:41 --> Utf8 Class Initialized
INFO - 2017-02-17 16:38:41 --> Router Class Initialized
INFO - 2017-02-17 16:38:41 --> URI Class Initialized
INFO - 2017-02-17 16:38:41 --> Output Class Initialized
INFO - 2017-02-17 16:38:41 --> Security Class Initialized
INFO - 2017-02-17 16:38:41 --> Router Class Initialized
DEBUG - 2017-02-17 16:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:38:41 --> Input Class Initialized
INFO - 2017-02-17 16:38:41 --> Language Class Initialized
INFO - 2017-02-17 16:38:41 --> Output Class Initialized
ERROR - 2017-02-17 16:38:41 --> 404 Page Not Found: /index
INFO - 2017-02-17 16:38:41 --> Security Class Initialized
DEBUG - 2017-02-17 16:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:38:41 --> Input Class Initialized
INFO - 2017-02-17 16:38:41 --> Language Class Initialized
ERROR - 2017-02-17 16:38:41 --> 404 Page Not Found: /index
INFO - 2017-02-17 16:38:42 --> Config Class Initialized
INFO - 2017-02-17 16:38:42 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:38:42 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:38:42 --> Utf8 Class Initialized
INFO - 2017-02-17 16:38:42 --> URI Class Initialized
INFO - 2017-02-17 16:38:42 --> Router Class Initialized
INFO - 2017-02-17 16:38:42 --> Output Class Initialized
INFO - 2017-02-17 16:38:42 --> Security Class Initialized
DEBUG - 2017-02-17 16:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:38:42 --> Input Class Initialized
INFO - 2017-02-17 16:38:42 --> Language Class Initialized
ERROR - 2017-02-17 16:38:42 --> 404 Page Not Found: /index
INFO - 2017-02-17 16:39:12 --> Config Class Initialized
INFO - 2017-02-17 16:39:12 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:39:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:39:12 --> Utf8 Class Initialized
INFO - 2017-02-17 16:39:12 --> URI Class Initialized
INFO - 2017-02-17 16:39:12 --> Router Class Initialized
INFO - 2017-02-17 16:39:12 --> Output Class Initialized
INFO - 2017-02-17 16:39:12 --> Security Class Initialized
DEBUG - 2017-02-17 16:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:39:12 --> Input Class Initialized
INFO - 2017-02-17 16:39:12 --> Language Class Initialized
INFO - 2017-02-17 16:39:12 --> Language Class Initialized
INFO - 2017-02-17 16:39:12 --> Config Class Initialized
INFO - 2017-02-17 16:39:12 --> Loader Class Initialized
INFO - 2017-02-17 16:39:12 --> Helper loaded: form_helper
INFO - 2017-02-17 16:39:12 --> Helper loaded: url_helper
INFO - 2017-02-17 16:39:12 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:39:12 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:39:12 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:39:12 --> Template Class Initialized
INFO - 2017-02-17 16:39:12 --> Controller Class Initialized
DEBUG - 2017-02-17 16:39:12 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:39:12 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:39:12 --> Model Class Initialized
INFO - 2017-02-17 16:39:12 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:39:12 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:39:12 --> Final output sent to browser
DEBUG - 2017-02-17 16:39:12 --> Total execution time: 0.1681
INFO - 2017-02-17 16:39:12 --> Config Class Initialized
INFO - 2017-02-17 16:39:12 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:39:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:39:12 --> Utf8 Class Initialized
INFO - 2017-02-17 16:39:12 --> Config Class Initialized
INFO - 2017-02-17 16:39:12 --> Hooks Class Initialized
INFO - 2017-02-17 16:39:12 --> URI Class Initialized
DEBUG - 2017-02-17 16:39:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:39:12 --> Utf8 Class Initialized
INFO - 2017-02-17 16:39:12 --> Router Class Initialized
INFO - 2017-02-17 16:39:12 --> URI Class Initialized
INFO - 2017-02-17 16:39:12 --> Output Class Initialized
INFO - 2017-02-17 16:39:12 --> Security Class Initialized
INFO - 2017-02-17 16:39:12 --> Router Class Initialized
DEBUG - 2017-02-17 16:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:39:12 --> Input Class Initialized
INFO - 2017-02-17 16:39:12 --> Output Class Initialized
INFO - 2017-02-17 16:39:12 --> Language Class Initialized
INFO - 2017-02-17 16:39:12 --> Security Class Initialized
ERROR - 2017-02-17 16:39:12 --> 404 Page Not Found: /index
DEBUG - 2017-02-17 16:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:39:12 --> Input Class Initialized
INFO - 2017-02-17 16:39:12 --> Language Class Initialized
ERROR - 2017-02-17 16:39:12 --> 404 Page Not Found: /index
INFO - 2017-02-17 16:39:12 --> Config Class Initialized
INFO - 2017-02-17 16:39:12 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:39:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:39:12 --> Utf8 Class Initialized
INFO - 2017-02-17 16:39:12 --> URI Class Initialized
INFO - 2017-02-17 16:39:12 --> Router Class Initialized
INFO - 2017-02-17 16:39:12 --> Output Class Initialized
INFO - 2017-02-17 16:39:12 --> Security Class Initialized
DEBUG - 2017-02-17 16:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:39:12 --> Input Class Initialized
INFO - 2017-02-17 16:39:12 --> Language Class Initialized
ERROR - 2017-02-17 16:39:12 --> 404 Page Not Found: /index
INFO - 2017-02-17 16:39:14 --> Config Class Initialized
INFO - 2017-02-17 16:39:14 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:39:14 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:39:14 --> Utf8 Class Initialized
INFO - 2017-02-17 16:39:14 --> URI Class Initialized
INFO - 2017-02-17 16:39:14 --> Router Class Initialized
INFO - 2017-02-17 16:39:14 --> Output Class Initialized
INFO - 2017-02-17 16:39:14 --> Security Class Initialized
DEBUG - 2017-02-17 16:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:39:14 --> Input Class Initialized
INFO - 2017-02-17 16:39:14 --> Language Class Initialized
INFO - 2017-02-17 16:39:14 --> Language Class Initialized
INFO - 2017-02-17 16:39:14 --> Config Class Initialized
INFO - 2017-02-17 16:39:14 --> Loader Class Initialized
INFO - 2017-02-17 16:39:14 --> Helper loaded: form_helper
INFO - 2017-02-17 16:39:14 --> Helper loaded: url_helper
INFO - 2017-02-17 16:39:14 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:39:14 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:39:14 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:39:14 --> Template Class Initialized
INFO - 2017-02-17 16:39:14 --> Controller Class Initialized
DEBUG - 2017-02-17 16:39:14 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:39:14 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:39:14 --> Model Class Initialized
INFO - 2017-02-17 16:39:14 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:39:14 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:39:14 --> Final output sent to browser
DEBUG - 2017-02-17 16:39:14 --> Total execution time: 0.1057
INFO - 2017-02-17 16:39:14 --> Config Class Initialized
INFO - 2017-02-17 16:39:14 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:39:14 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:39:14 --> Config Class Initialized
INFO - 2017-02-17 16:39:14 --> Hooks Class Initialized
INFO - 2017-02-17 16:39:14 --> Utf8 Class Initialized
INFO - 2017-02-17 16:39:14 --> URI Class Initialized
DEBUG - 2017-02-17 16:39:14 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:39:14 --> Utf8 Class Initialized
INFO - 2017-02-17 16:39:14 --> URI Class Initialized
INFO - 2017-02-17 16:39:14 --> Router Class Initialized
INFO - 2017-02-17 16:39:14 --> Output Class Initialized
INFO - 2017-02-17 16:39:14 --> Router Class Initialized
INFO - 2017-02-17 16:39:14 --> Security Class Initialized
DEBUG - 2017-02-17 16:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:39:14 --> Input Class Initialized
INFO - 2017-02-17 16:39:14 --> Language Class Initialized
INFO - 2017-02-17 16:39:14 --> Config Class Initialized
INFO - 2017-02-17 16:39:14 --> Hooks Class Initialized
ERROR - 2017-02-17 16:39:14 --> 404 Page Not Found: /index
INFO - 2017-02-17 16:39:14 --> Output Class Initialized
DEBUG - 2017-02-17 16:39:14 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:39:14 --> Utf8 Class Initialized
INFO - 2017-02-17 16:39:14 --> Security Class Initialized
INFO - 2017-02-17 16:39:14 --> URI Class Initialized
DEBUG - 2017-02-17 16:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:39:14 --> Input Class Initialized
INFO - 2017-02-17 16:39:14 --> Router Class Initialized
INFO - 2017-02-17 16:39:14 --> Language Class Initialized
INFO - 2017-02-17 16:39:14 --> Output Class Initialized
ERROR - 2017-02-17 16:39:14 --> 404 Page Not Found: /index
INFO - 2017-02-17 16:39:14 --> Security Class Initialized
DEBUG - 2017-02-17 16:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:39:14 --> Input Class Initialized
INFO - 2017-02-17 16:39:14 --> Language Class Initialized
ERROR - 2017-02-17 16:39:14 --> 404 Page Not Found: /index
INFO - 2017-02-17 16:40:06 --> Config Class Initialized
INFO - 2017-02-17 16:40:06 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:40:06 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:40:06 --> Utf8 Class Initialized
INFO - 2017-02-17 16:40:06 --> URI Class Initialized
INFO - 2017-02-17 16:40:06 --> Router Class Initialized
INFO - 2017-02-17 16:40:06 --> Output Class Initialized
INFO - 2017-02-17 16:40:06 --> Security Class Initialized
DEBUG - 2017-02-17 16:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:40:06 --> Input Class Initialized
INFO - 2017-02-17 16:40:06 --> Language Class Initialized
INFO - 2017-02-17 16:40:06 --> Language Class Initialized
INFO - 2017-02-17 16:40:06 --> Config Class Initialized
INFO - 2017-02-17 16:40:06 --> Loader Class Initialized
INFO - 2017-02-17 16:40:06 --> Helper loaded: form_helper
INFO - 2017-02-17 16:40:06 --> Helper loaded: url_helper
INFO - 2017-02-17 16:40:06 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:40:06 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:40:06 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:40:06 --> Template Class Initialized
INFO - 2017-02-17 16:40:06 --> Controller Class Initialized
DEBUG - 2017-02-17 16:40:06 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:40:06 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:40:06 --> Model Class Initialized
INFO - 2017-02-17 16:40:06 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:40:06 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:40:06 --> Final output sent to browser
DEBUG - 2017-02-17 16:40:06 --> Total execution time: 0.0580
INFO - 2017-02-17 16:40:36 --> Config Class Initialized
INFO - 2017-02-17 16:40:36 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:40:36 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:40:36 --> Utf8 Class Initialized
INFO - 2017-02-17 16:40:36 --> URI Class Initialized
INFO - 2017-02-17 16:40:36 --> Router Class Initialized
INFO - 2017-02-17 16:40:36 --> Output Class Initialized
INFO - 2017-02-17 16:40:36 --> Security Class Initialized
DEBUG - 2017-02-17 16:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:40:36 --> Input Class Initialized
INFO - 2017-02-17 16:40:36 --> Language Class Initialized
INFO - 2017-02-17 16:40:36 --> Language Class Initialized
INFO - 2017-02-17 16:40:36 --> Config Class Initialized
INFO - 2017-02-17 16:40:36 --> Loader Class Initialized
INFO - 2017-02-17 16:40:36 --> Helper loaded: form_helper
INFO - 2017-02-17 16:40:36 --> Helper loaded: url_helper
INFO - 2017-02-17 16:40:36 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:40:36 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:40:36 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:40:36 --> Template Class Initialized
INFO - 2017-02-17 16:40:36 --> Controller Class Initialized
DEBUG - 2017-02-17 16:40:36 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:40:36 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:40:36 --> Model Class Initialized
INFO - 2017-02-17 16:40:36 --> Form Validation Class Initialized
INFO - 2017-02-17 16:40:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 16:40:36 --> Config Class Initialized
INFO - 2017-02-17 16:40:36 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:40:36 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:40:36 --> Utf8 Class Initialized
INFO - 2017-02-17 16:40:36 --> URI Class Initialized
INFO - 2017-02-17 16:40:36 --> Router Class Initialized
INFO - 2017-02-17 16:40:36 --> Output Class Initialized
INFO - 2017-02-17 16:40:36 --> Security Class Initialized
DEBUG - 2017-02-17 16:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:40:37 --> Input Class Initialized
INFO - 2017-02-17 16:40:37 --> Language Class Initialized
INFO - 2017-02-17 16:40:37 --> Language Class Initialized
INFO - 2017-02-17 16:40:37 --> Config Class Initialized
INFO - 2017-02-17 16:40:37 --> Loader Class Initialized
INFO - 2017-02-17 16:40:37 --> Helper loaded: form_helper
INFO - 2017-02-17 16:40:37 --> Helper loaded: url_helper
INFO - 2017-02-17 16:40:37 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:40:37 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:40:37 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:40:37 --> Template Class Initialized
INFO - 2017-02-17 16:40:37 --> Controller Class Initialized
DEBUG - 2017-02-17 16:40:37 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 16:40:37 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:40:37 --> Model Class Initialized
DEBUG - 2017-02-17 16:40:37 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 16:40:37 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 16:40:37 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 16:40:37 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/backend/views/employee/dashboard.php
DEBUG - 2017-02-17 16:40:37 --> File loaded: C:\xampp\htdocs\RazorClean\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 16:40:37 --> Final output sent to browser
DEBUG - 2017-02-17 16:40:37 --> Total execution time: 0.2003
INFO - 2017-02-17 16:40:45 --> Config Class Initialized
INFO - 2017-02-17 16:40:45 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:40:45 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:40:45 --> Utf8 Class Initialized
INFO - 2017-02-17 16:40:45 --> URI Class Initialized
INFO - 2017-02-17 16:40:45 --> Router Class Initialized
INFO - 2017-02-17 16:40:45 --> Output Class Initialized
INFO - 2017-02-17 16:40:45 --> Security Class Initialized
DEBUG - 2017-02-17 16:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:40:45 --> Input Class Initialized
INFO - 2017-02-17 16:40:45 --> Language Class Initialized
INFO - 2017-02-17 16:40:45 --> Language Class Initialized
INFO - 2017-02-17 16:40:45 --> Config Class Initialized
INFO - 2017-02-17 16:40:45 --> Loader Class Initialized
INFO - 2017-02-17 16:40:45 --> Helper loaded: form_helper
INFO - 2017-02-17 16:40:45 --> Helper loaded: url_helper
INFO - 2017-02-17 16:40:45 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:40:45 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:40:45 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:40:45 --> Template Class Initialized
INFO - 2017-02-17 16:40:45 --> Controller Class Initialized
DEBUG - 2017-02-17 16:40:45 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:40:45 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:40:45 --> Model Class Initialized
INFO - 2017-02-17 16:40:45 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:40:45 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:40:45 --> Final output sent to browser
DEBUG - 2017-02-17 16:40:45 --> Total execution time: 0.0638
INFO - 2017-02-17 16:40:53 --> Config Class Initialized
INFO - 2017-02-17 16:40:53 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:40:53 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:40:53 --> Utf8 Class Initialized
INFO - 2017-02-17 16:40:53 --> URI Class Initialized
INFO - 2017-02-17 16:40:53 --> Router Class Initialized
INFO - 2017-02-17 16:40:53 --> Output Class Initialized
INFO - 2017-02-17 16:40:53 --> Security Class Initialized
DEBUG - 2017-02-17 16:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:40:53 --> Input Class Initialized
INFO - 2017-02-17 16:40:53 --> Language Class Initialized
INFO - 2017-02-17 16:40:53 --> Language Class Initialized
INFO - 2017-02-17 16:40:53 --> Config Class Initialized
INFO - 2017-02-17 16:40:53 --> Loader Class Initialized
INFO - 2017-02-17 16:40:54 --> Helper loaded: form_helper
INFO - 2017-02-17 16:40:54 --> Helper loaded: url_helper
INFO - 2017-02-17 16:40:54 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:40:54 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:40:54 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:40:54 --> Template Class Initialized
INFO - 2017-02-17 16:40:54 --> Controller Class Initialized
DEBUG - 2017-02-17 16:40:54 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:40:54 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:40:54 --> Model Class Initialized
INFO - 2017-02-17 16:40:54 --> Form Validation Class Initialized
INFO - 2017-02-17 16:40:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 16:40:54 --> Config Class Initialized
INFO - 2017-02-17 16:40:54 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:40:54 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:40:54 --> Utf8 Class Initialized
INFO - 2017-02-17 16:40:54 --> URI Class Initialized
INFO - 2017-02-17 16:40:54 --> Router Class Initialized
INFO - 2017-02-17 16:40:54 --> Output Class Initialized
INFO - 2017-02-17 16:40:54 --> Security Class Initialized
DEBUG - 2017-02-17 16:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:40:54 --> Input Class Initialized
INFO - 2017-02-17 16:40:54 --> Language Class Initialized
INFO - 2017-02-17 16:40:54 --> Language Class Initialized
INFO - 2017-02-17 16:40:54 --> Config Class Initialized
INFO - 2017-02-17 16:40:54 --> Loader Class Initialized
INFO - 2017-02-17 16:40:54 --> Helper loaded: form_helper
INFO - 2017-02-17 16:40:54 --> Helper loaded: url_helper
INFO - 2017-02-17 16:40:54 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:40:55 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:40:55 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:40:55 --> Template Class Initialized
INFO - 2017-02-17 16:40:55 --> Controller Class Initialized
DEBUG - 2017-02-17 16:40:55 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:40:55 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:40:55 --> Model Class Initialized
INFO - 2017-02-17 16:40:55 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:40:55 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:40:55 --> Final output sent to browser
DEBUG - 2017-02-17 16:40:55 --> Total execution time: 0.1298
INFO - 2017-02-17 16:42:12 --> Config Class Initialized
INFO - 2017-02-17 16:42:12 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:42:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:42:12 --> Utf8 Class Initialized
INFO - 2017-02-17 16:42:12 --> URI Class Initialized
INFO - 2017-02-17 16:42:12 --> Router Class Initialized
INFO - 2017-02-17 16:42:12 --> Output Class Initialized
INFO - 2017-02-17 16:42:12 --> Security Class Initialized
DEBUG - 2017-02-17 16:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:42:12 --> Input Class Initialized
INFO - 2017-02-17 16:42:12 --> Language Class Initialized
INFO - 2017-02-17 16:42:12 --> Language Class Initialized
INFO - 2017-02-17 16:42:12 --> Config Class Initialized
INFO - 2017-02-17 16:42:12 --> Loader Class Initialized
INFO - 2017-02-17 16:42:12 --> Helper loaded: form_helper
INFO - 2017-02-17 16:42:13 --> Helper loaded: url_helper
INFO - 2017-02-17 16:42:13 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:42:13 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:42:13 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:42:13 --> Template Class Initialized
INFO - 2017-02-17 16:42:13 --> Controller Class Initialized
DEBUG - 2017-02-17 16:42:13 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:42:13 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:42:13 --> Model Class Initialized
INFO - 2017-02-17 16:42:13 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:42:13 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:42:13 --> Final output sent to browser
DEBUG - 2017-02-17 16:42:13 --> Total execution time: 0.8492
INFO - 2017-02-17 16:42:28 --> Config Class Initialized
INFO - 2017-02-17 16:42:28 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:42:28 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:42:28 --> Utf8 Class Initialized
INFO - 2017-02-17 16:42:28 --> URI Class Initialized
INFO - 2017-02-17 16:42:28 --> Router Class Initialized
INFO - 2017-02-17 16:42:28 --> Output Class Initialized
INFO - 2017-02-17 16:42:28 --> Security Class Initialized
DEBUG - 2017-02-17 16:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:42:28 --> Input Class Initialized
INFO - 2017-02-17 16:42:28 --> Language Class Initialized
INFO - 2017-02-17 16:42:28 --> Language Class Initialized
INFO - 2017-02-17 16:42:28 --> Config Class Initialized
INFO - 2017-02-17 16:42:28 --> Loader Class Initialized
INFO - 2017-02-17 16:42:28 --> Helper loaded: form_helper
INFO - 2017-02-17 16:42:28 --> Helper loaded: url_helper
INFO - 2017-02-17 16:42:28 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:42:28 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:42:28 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:42:28 --> Template Class Initialized
INFO - 2017-02-17 16:42:28 --> Controller Class Initialized
DEBUG - 2017-02-17 16:42:28 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:42:28 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:42:28 --> Model Class Initialized
INFO - 2017-02-17 16:42:28 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:42:28 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:42:28 --> Final output sent to browser
DEBUG - 2017-02-17 16:42:28 --> Total execution time: 0.1604
INFO - 2017-02-17 16:42:38 --> Config Class Initialized
INFO - 2017-02-17 16:42:38 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:42:38 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:42:38 --> Utf8 Class Initialized
INFO - 2017-02-17 16:42:38 --> URI Class Initialized
INFO - 2017-02-17 16:42:38 --> Router Class Initialized
INFO - 2017-02-17 16:42:38 --> Output Class Initialized
INFO - 2017-02-17 16:42:38 --> Security Class Initialized
DEBUG - 2017-02-17 16:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:42:38 --> Input Class Initialized
INFO - 2017-02-17 16:42:38 --> Language Class Initialized
INFO - 2017-02-17 16:42:38 --> Language Class Initialized
INFO - 2017-02-17 16:42:38 --> Config Class Initialized
INFO - 2017-02-17 16:42:38 --> Loader Class Initialized
INFO - 2017-02-17 16:42:38 --> Helper loaded: form_helper
INFO - 2017-02-17 16:42:38 --> Helper loaded: url_helper
INFO - 2017-02-17 16:42:38 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:42:38 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:42:38 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:42:38 --> Template Class Initialized
INFO - 2017-02-17 16:42:38 --> Controller Class Initialized
DEBUG - 2017-02-17 16:42:38 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:42:38 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:42:38 --> Model Class Initialized
INFO - 2017-02-17 16:42:38 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:42:38 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:42:38 --> Final output sent to browser
DEBUG - 2017-02-17 16:42:38 --> Total execution time: 0.0814
INFO - 2017-02-17 16:42:46 --> Config Class Initialized
INFO - 2017-02-17 16:42:46 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:42:46 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:42:46 --> Utf8 Class Initialized
INFO - 2017-02-17 16:42:46 --> URI Class Initialized
INFO - 2017-02-17 16:42:46 --> Router Class Initialized
INFO - 2017-02-17 16:42:46 --> Output Class Initialized
INFO - 2017-02-17 16:42:46 --> Security Class Initialized
DEBUG - 2017-02-17 16:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:42:46 --> Input Class Initialized
INFO - 2017-02-17 16:42:46 --> Language Class Initialized
INFO - 2017-02-17 16:42:46 --> Language Class Initialized
INFO - 2017-02-17 16:42:46 --> Config Class Initialized
INFO - 2017-02-17 16:42:46 --> Loader Class Initialized
INFO - 2017-02-17 16:42:46 --> Helper loaded: form_helper
INFO - 2017-02-17 16:42:46 --> Helper loaded: url_helper
INFO - 2017-02-17 16:42:46 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:42:46 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:42:46 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:42:46 --> Template Class Initialized
INFO - 2017-02-17 16:42:46 --> Controller Class Initialized
DEBUG - 2017-02-17 16:42:46 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:42:46 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:42:46 --> Model Class Initialized
INFO - 2017-02-17 16:42:46 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:42:46 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:42:46 --> Final output sent to browser
DEBUG - 2017-02-17 16:42:46 --> Total execution time: 0.0986
INFO - 2017-02-17 16:42:48 --> Config Class Initialized
INFO - 2017-02-17 16:42:48 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:42:48 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:42:48 --> Utf8 Class Initialized
INFO - 2017-02-17 16:42:48 --> URI Class Initialized
INFO - 2017-02-17 16:42:48 --> Router Class Initialized
INFO - 2017-02-17 16:42:48 --> Output Class Initialized
INFO - 2017-02-17 16:42:48 --> Security Class Initialized
DEBUG - 2017-02-17 16:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:42:48 --> Input Class Initialized
INFO - 2017-02-17 16:42:48 --> Language Class Initialized
INFO - 2017-02-17 16:42:48 --> Language Class Initialized
INFO - 2017-02-17 16:42:48 --> Config Class Initialized
INFO - 2017-02-17 16:42:48 --> Loader Class Initialized
INFO - 2017-02-17 16:42:48 --> Helper loaded: form_helper
INFO - 2017-02-17 16:42:48 --> Helper loaded: url_helper
INFO - 2017-02-17 16:42:48 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:42:48 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:42:48 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:42:48 --> Template Class Initialized
INFO - 2017-02-17 16:42:48 --> Controller Class Initialized
DEBUG - 2017-02-17 16:42:48 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:42:48 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:42:48 --> Model Class Initialized
INFO - 2017-02-17 16:42:48 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:42:48 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:42:48 --> Final output sent to browser
DEBUG - 2017-02-17 16:42:48 --> Total execution time: 0.0757
INFO - 2017-02-17 16:45:20 --> Config Class Initialized
INFO - 2017-02-17 16:45:20 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:45:20 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:45:20 --> Utf8 Class Initialized
INFO - 2017-02-17 16:45:20 --> URI Class Initialized
INFO - 2017-02-17 16:45:20 --> Router Class Initialized
INFO - 2017-02-17 16:45:20 --> Output Class Initialized
INFO - 2017-02-17 16:45:20 --> Security Class Initialized
DEBUG - 2017-02-17 16:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:45:20 --> Input Class Initialized
INFO - 2017-02-17 16:45:20 --> Language Class Initialized
INFO - 2017-02-17 16:45:20 --> Language Class Initialized
INFO - 2017-02-17 16:45:20 --> Config Class Initialized
INFO - 2017-02-17 16:45:20 --> Loader Class Initialized
INFO - 2017-02-17 16:45:20 --> Helper loaded: form_helper
INFO - 2017-02-17 16:45:20 --> Helper loaded: url_helper
INFO - 2017-02-17 16:45:20 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:45:20 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:45:20 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:45:20 --> Template Class Initialized
INFO - 2017-02-17 16:45:20 --> Controller Class Initialized
DEBUG - 2017-02-17 16:45:20 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:45:20 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:45:20 --> Model Class Initialized
INFO - 2017-02-17 16:45:20 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:45:20 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:45:20 --> Final output sent to browser
DEBUG - 2017-02-17 16:45:20 --> Total execution time: 0.1146
INFO - 2017-02-17 16:45:24 --> Config Class Initialized
INFO - 2017-02-17 16:45:24 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:45:24 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:45:24 --> Utf8 Class Initialized
INFO - 2017-02-17 16:45:24 --> URI Class Initialized
INFO - 2017-02-17 16:45:24 --> Router Class Initialized
INFO - 2017-02-17 16:45:24 --> Output Class Initialized
INFO - 2017-02-17 16:45:24 --> Security Class Initialized
DEBUG - 2017-02-17 16:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:45:24 --> Input Class Initialized
INFO - 2017-02-17 16:45:24 --> Language Class Initialized
ERROR - 2017-02-17 16:45:24 --> 404 Page Not Found: /index
INFO - 2017-02-17 16:45:37 --> Config Class Initialized
INFO - 2017-02-17 16:45:37 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:45:37 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:45:37 --> Utf8 Class Initialized
INFO - 2017-02-17 16:45:37 --> URI Class Initialized
INFO - 2017-02-17 16:45:37 --> Router Class Initialized
INFO - 2017-02-17 16:45:37 --> Output Class Initialized
INFO - 2017-02-17 16:45:37 --> Security Class Initialized
DEBUG - 2017-02-17 16:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:45:37 --> Input Class Initialized
INFO - 2017-02-17 16:45:37 --> Language Class Initialized
INFO - 2017-02-17 16:45:37 --> Language Class Initialized
INFO - 2017-02-17 16:45:37 --> Config Class Initialized
INFO - 2017-02-17 16:45:37 --> Loader Class Initialized
INFO - 2017-02-17 16:45:37 --> Helper loaded: form_helper
INFO - 2017-02-17 16:45:37 --> Helper loaded: url_helper
INFO - 2017-02-17 16:45:37 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:45:37 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:45:37 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:45:37 --> Template Class Initialized
INFO - 2017-02-17 16:45:37 --> Controller Class Initialized
DEBUG - 2017-02-17 16:45:37 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:45:37 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:45:37 --> Model Class Initialized
INFO - 2017-02-17 16:45:37 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:45:37 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:45:37 --> Final output sent to browser
DEBUG - 2017-02-17 16:45:37 --> Total execution time: 0.2404
INFO - 2017-02-17 16:45:38 --> Config Class Initialized
INFO - 2017-02-17 16:45:38 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:45:38 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:45:38 --> Utf8 Class Initialized
INFO - 2017-02-17 16:45:38 --> URI Class Initialized
INFO - 2017-02-17 16:45:38 --> Router Class Initialized
INFO - 2017-02-17 16:45:38 --> Output Class Initialized
INFO - 2017-02-17 16:45:38 --> Security Class Initialized
DEBUG - 2017-02-17 16:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:45:38 --> Input Class Initialized
INFO - 2017-02-17 16:45:38 --> Language Class Initialized
INFO - 2017-02-17 16:45:38 --> Language Class Initialized
INFO - 2017-02-17 16:45:38 --> Config Class Initialized
INFO - 2017-02-17 16:45:38 --> Loader Class Initialized
INFO - 2017-02-17 16:45:38 --> Helper loaded: form_helper
INFO - 2017-02-17 16:45:39 --> Helper loaded: url_helper
INFO - 2017-02-17 16:45:39 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:45:39 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:45:39 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:45:39 --> Template Class Initialized
INFO - 2017-02-17 16:45:39 --> Controller Class Initialized
DEBUG - 2017-02-17 16:45:39 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:45:39 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:45:39 --> Model Class Initialized
INFO - 2017-02-17 16:45:39 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:45:39 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:45:39 --> Final output sent to browser
DEBUG - 2017-02-17 16:45:39 --> Total execution time: 0.9708
INFO - 2017-02-17 16:45:52 --> Config Class Initialized
INFO - 2017-02-17 16:45:52 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:45:53 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:45:53 --> Utf8 Class Initialized
INFO - 2017-02-17 16:45:53 --> URI Class Initialized
INFO - 2017-02-17 16:45:53 --> Router Class Initialized
INFO - 2017-02-17 16:45:53 --> Output Class Initialized
INFO - 2017-02-17 16:45:53 --> Security Class Initialized
DEBUG - 2017-02-17 16:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:45:53 --> Input Class Initialized
INFO - 2017-02-17 16:45:53 --> Language Class Initialized
INFO - 2017-02-17 16:45:53 --> Language Class Initialized
INFO - 2017-02-17 16:45:53 --> Config Class Initialized
INFO - 2017-02-17 16:45:53 --> Loader Class Initialized
INFO - 2017-02-17 16:45:53 --> Helper loaded: form_helper
INFO - 2017-02-17 16:45:54 --> Helper loaded: url_helper
INFO - 2017-02-17 16:45:54 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:45:54 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:45:54 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:45:54 --> Template Class Initialized
INFO - 2017-02-17 16:45:54 --> Controller Class Initialized
DEBUG - 2017-02-17 16:45:54 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:45:54 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:45:54 --> Model Class Initialized
INFO - 2017-02-17 16:45:54 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:45:54 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:45:54 --> Final output sent to browser
DEBUG - 2017-02-17 16:45:54 --> Total execution time: 1.6643
INFO - 2017-02-17 16:45:57 --> Config Class Initialized
INFO - 2017-02-17 16:45:57 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:45:57 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:45:57 --> Utf8 Class Initialized
INFO - 2017-02-17 16:45:57 --> URI Class Initialized
INFO - 2017-02-17 16:45:57 --> Router Class Initialized
INFO - 2017-02-17 16:45:57 --> Output Class Initialized
INFO - 2017-02-17 16:45:57 --> Security Class Initialized
DEBUG - 2017-02-17 16:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:45:57 --> Input Class Initialized
INFO - 2017-02-17 16:45:57 --> Language Class Initialized
ERROR - 2017-02-17 16:45:57 --> 404 Page Not Found: /index
INFO - 2017-02-17 16:48:04 --> Config Class Initialized
INFO - 2017-02-17 16:48:04 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:48:04 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:48:04 --> Utf8 Class Initialized
INFO - 2017-02-17 16:48:04 --> URI Class Initialized
INFO - 2017-02-17 16:48:04 --> Router Class Initialized
INFO - 2017-02-17 16:48:04 --> Output Class Initialized
INFO - 2017-02-17 16:48:04 --> Security Class Initialized
DEBUG - 2017-02-17 16:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:48:04 --> Input Class Initialized
INFO - 2017-02-17 16:48:04 --> Language Class Initialized
INFO - 2017-02-17 16:48:04 --> Language Class Initialized
INFO - 2017-02-17 16:48:04 --> Config Class Initialized
INFO - 2017-02-17 16:48:04 --> Loader Class Initialized
INFO - 2017-02-17 16:48:04 --> Helper loaded: form_helper
INFO - 2017-02-17 16:48:04 --> Helper loaded: url_helper
INFO - 2017-02-17 16:48:04 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:48:04 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:48:04 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:48:04 --> Template Class Initialized
INFO - 2017-02-17 16:48:04 --> Controller Class Initialized
DEBUG - 2017-02-17 16:48:04 --> Signup MX_Controller Initialized
INFO - 2017-02-17 16:48:04 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:48:04 --> Model Class Initialized
INFO - 2017-02-17 16:48:04 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:48:04 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/signup.php
INFO - 2017-02-17 16:48:04 --> Final output sent to browser
DEBUG - 2017-02-17 16:48:04 --> Total execution time: 0.2532
INFO - 2017-02-17 16:49:34 --> Config Class Initialized
INFO - 2017-02-17 16:49:34 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:49:34 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:49:34 --> Utf8 Class Initialized
INFO - 2017-02-17 16:49:34 --> URI Class Initialized
INFO - 2017-02-17 16:49:34 --> Router Class Initialized
INFO - 2017-02-17 16:49:34 --> Output Class Initialized
INFO - 2017-02-17 16:49:34 --> Security Class Initialized
DEBUG - 2017-02-17 16:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:49:34 --> Input Class Initialized
INFO - 2017-02-17 16:49:34 --> Language Class Initialized
INFO - 2017-02-17 16:49:34 --> Language Class Initialized
INFO - 2017-02-17 16:49:34 --> Config Class Initialized
INFO - 2017-02-17 16:49:34 --> Loader Class Initialized
INFO - 2017-02-17 16:49:34 --> Helper loaded: form_helper
INFO - 2017-02-17 16:49:34 --> Helper loaded: url_helper
INFO - 2017-02-17 16:49:34 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:49:34 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:49:34 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:49:34 --> Template Class Initialized
INFO - 2017-02-17 16:49:34 --> Controller Class Initialized
DEBUG - 2017-02-17 16:49:34 --> Signup MX_Controller Initialized
INFO - 2017-02-17 16:49:34 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:49:34 --> Model Class Initialized
INFO - 2017-02-17 16:49:34 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:49:34 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/signup.php
INFO - 2017-02-17 16:49:34 --> Final output sent to browser
DEBUG - 2017-02-17 16:49:34 --> Total execution time: 0.1379
INFO - 2017-02-17 16:49:36 --> Config Class Initialized
INFO - 2017-02-17 16:49:36 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:49:36 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:49:36 --> Utf8 Class Initialized
INFO - 2017-02-17 16:49:36 --> URI Class Initialized
INFO - 2017-02-17 16:49:36 --> Router Class Initialized
INFO - 2017-02-17 16:49:36 --> Output Class Initialized
INFO - 2017-02-17 16:49:36 --> Security Class Initialized
DEBUG - 2017-02-17 16:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:49:36 --> Input Class Initialized
INFO - 2017-02-17 16:49:36 --> Language Class Initialized
INFO - 2017-02-17 16:49:36 --> Language Class Initialized
INFO - 2017-02-17 16:49:36 --> Config Class Initialized
INFO - 2017-02-17 16:49:36 --> Loader Class Initialized
INFO - 2017-02-17 16:49:36 --> Helper loaded: form_helper
INFO - 2017-02-17 16:49:36 --> Helper loaded: url_helper
INFO - 2017-02-17 16:49:36 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:49:36 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:49:36 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:49:36 --> Template Class Initialized
INFO - 2017-02-17 16:49:36 --> Controller Class Initialized
DEBUG - 2017-02-17 16:49:36 --> Signup MX_Controller Initialized
INFO - 2017-02-17 16:49:36 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:49:36 --> Model Class Initialized
INFO - 2017-02-17 16:49:36 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:49:36 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/signup.php
INFO - 2017-02-17 16:49:36 --> Final output sent to browser
DEBUG - 2017-02-17 16:49:36 --> Total execution time: 0.1676
INFO - 2017-02-17 16:49:45 --> Config Class Initialized
INFO - 2017-02-17 16:49:45 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:49:45 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:49:45 --> Utf8 Class Initialized
INFO - 2017-02-17 16:49:45 --> URI Class Initialized
INFO - 2017-02-17 16:49:45 --> Router Class Initialized
INFO - 2017-02-17 16:49:45 --> Output Class Initialized
INFO - 2017-02-17 16:49:45 --> Security Class Initialized
DEBUG - 2017-02-17 16:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:49:45 --> Input Class Initialized
INFO - 2017-02-17 16:49:45 --> Language Class Initialized
INFO - 2017-02-17 16:49:45 --> Language Class Initialized
INFO - 2017-02-17 16:49:45 --> Config Class Initialized
INFO - 2017-02-17 16:49:45 --> Loader Class Initialized
INFO - 2017-02-17 16:49:45 --> Helper loaded: form_helper
INFO - 2017-02-17 16:49:45 --> Helper loaded: url_helper
INFO - 2017-02-17 16:49:45 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:49:45 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:49:45 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:49:45 --> Template Class Initialized
INFO - 2017-02-17 16:49:45 --> Controller Class Initialized
DEBUG - 2017-02-17 16:49:45 --> Signup MX_Controller Initialized
INFO - 2017-02-17 16:49:45 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:49:45 --> Model Class Initialized
INFO - 2017-02-17 16:49:45 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:49:45 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/signup.php
INFO - 2017-02-17 16:49:45 --> Final output sent to browser
DEBUG - 2017-02-17 16:49:45 --> Total execution time: 0.2170
INFO - 2017-02-17 16:50:51 --> Config Class Initialized
INFO - 2017-02-17 16:50:51 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:50:51 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:50:51 --> Utf8 Class Initialized
INFO - 2017-02-17 16:50:51 --> URI Class Initialized
INFO - 2017-02-17 16:50:51 --> Router Class Initialized
INFO - 2017-02-17 16:50:51 --> Output Class Initialized
INFO - 2017-02-17 16:50:51 --> Security Class Initialized
DEBUG - 2017-02-17 16:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:50:51 --> Input Class Initialized
INFO - 2017-02-17 16:50:51 --> Language Class Initialized
INFO - 2017-02-17 16:50:51 --> Language Class Initialized
INFO - 2017-02-17 16:50:51 --> Config Class Initialized
INFO - 2017-02-17 16:50:51 --> Loader Class Initialized
INFO - 2017-02-17 16:50:51 --> Helper loaded: form_helper
INFO - 2017-02-17 16:50:51 --> Helper loaded: url_helper
INFO - 2017-02-17 16:50:51 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:50:51 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:50:51 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:50:51 --> Template Class Initialized
INFO - 2017-02-17 16:50:51 --> Controller Class Initialized
DEBUG - 2017-02-17 16:50:51 --> Signup MX_Controller Initialized
INFO - 2017-02-17 16:50:51 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:50:51 --> Model Class Initialized
INFO - 2017-02-17 16:50:51 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:50:51 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/signup.php
INFO - 2017-02-17 16:50:51 --> Final output sent to browser
DEBUG - 2017-02-17 16:50:51 --> Total execution time: 0.1414
INFO - 2017-02-17 16:50:54 --> Config Class Initialized
INFO - 2017-02-17 16:50:54 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:50:54 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:50:54 --> Utf8 Class Initialized
INFO - 2017-02-17 16:50:54 --> URI Class Initialized
DEBUG - 2017-02-17 16:50:54 --> No URI present. Default controller set.
INFO - 2017-02-17 16:50:54 --> Router Class Initialized
INFO - 2017-02-17 16:50:54 --> Output Class Initialized
INFO - 2017-02-17 16:50:54 --> Security Class Initialized
DEBUG - 2017-02-17 16:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:50:54 --> Input Class Initialized
INFO - 2017-02-17 16:50:54 --> Language Class Initialized
INFO - 2017-02-17 16:50:54 --> Language Class Initialized
INFO - 2017-02-17 16:50:54 --> Config Class Initialized
INFO - 2017-02-17 16:50:54 --> Loader Class Initialized
INFO - 2017-02-17 16:50:54 --> Helper loaded: form_helper
INFO - 2017-02-17 16:50:54 --> Helper loaded: url_helper
INFO - 2017-02-17 16:50:54 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:50:54 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:50:54 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:50:54 --> Template Class Initialized
INFO - 2017-02-17 16:50:54 --> Controller Class Initialized
INFO - 2017-02-17 16:50:54 --> Form Validation Class Initialized
INFO - 2017-02-17 16:50:54 --> Model Class Initialized
DEBUG - 2017-02-17 16:50:54 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 16:50:54 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 16:50:54 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 16:50:54 --> File loaded: C:\xampp\htdocs\RazorClean\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 16:50:54 --> Final output sent to browser
DEBUG - 2017-02-17 16:50:54 --> Total execution time: 0.5506
INFO - 2017-02-17 16:51:13 --> Config Class Initialized
INFO - 2017-02-17 16:51:13 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:51:13 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:51:13 --> Utf8 Class Initialized
INFO - 2017-02-17 16:51:13 --> URI Class Initialized
INFO - 2017-02-17 16:51:13 --> Router Class Initialized
INFO - 2017-02-17 16:51:13 --> Output Class Initialized
INFO - 2017-02-17 16:51:13 --> Security Class Initialized
DEBUG - 2017-02-17 16:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:51:13 --> Input Class Initialized
INFO - 2017-02-17 16:51:13 --> Language Class Initialized
INFO - 2017-02-17 16:51:13 --> Language Class Initialized
INFO - 2017-02-17 16:51:13 --> Config Class Initialized
INFO - 2017-02-17 16:51:13 --> Loader Class Initialized
INFO - 2017-02-17 16:51:13 --> Helper loaded: form_helper
INFO - 2017-02-17 16:51:13 --> Helper loaded: url_helper
INFO - 2017-02-17 16:51:13 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:51:13 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:51:13 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:51:13 --> Template Class Initialized
INFO - 2017-02-17 16:51:13 --> Controller Class Initialized
DEBUG - 2017-02-17 16:51:13 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:51:13 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:51:13 --> Model Class Initialized
INFO - 2017-02-17 16:51:13 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:51:13 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:51:13 --> Final output sent to browser
DEBUG - 2017-02-17 16:51:13 --> Total execution time: 0.1630
INFO - 2017-02-17 16:51:15 --> Config Class Initialized
INFO - 2017-02-17 16:51:15 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:51:15 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:51:15 --> Utf8 Class Initialized
INFO - 2017-02-17 16:51:15 --> URI Class Initialized
DEBUG - 2017-02-17 16:51:15 --> No URI present. Default controller set.
INFO - 2017-02-17 16:51:15 --> Router Class Initialized
INFO - 2017-02-17 16:51:15 --> Output Class Initialized
INFO - 2017-02-17 16:51:15 --> Security Class Initialized
DEBUG - 2017-02-17 16:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:51:15 --> Input Class Initialized
INFO - 2017-02-17 16:51:15 --> Language Class Initialized
INFO - 2017-02-17 16:51:15 --> Language Class Initialized
INFO - 2017-02-17 16:51:15 --> Config Class Initialized
INFO - 2017-02-17 16:51:15 --> Loader Class Initialized
INFO - 2017-02-17 16:51:15 --> Helper loaded: form_helper
INFO - 2017-02-17 16:51:15 --> Helper loaded: url_helper
INFO - 2017-02-17 16:51:15 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:51:15 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:51:15 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:51:15 --> Template Class Initialized
INFO - 2017-02-17 16:51:15 --> Controller Class Initialized
INFO - 2017-02-17 16:51:15 --> Form Validation Class Initialized
INFO - 2017-02-17 16:51:15 --> Model Class Initialized
DEBUG - 2017-02-17 16:51:15 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 16:51:15 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 16:51:15 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 16:51:15 --> File loaded: C:\xampp\htdocs\RazorClean\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 16:51:15 --> Final output sent to browser
DEBUG - 2017-02-17 16:51:15 --> Total execution time: 0.0631
INFO - 2017-02-17 16:52:16 --> Config Class Initialized
INFO - 2017-02-17 16:52:16 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:52:16 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:52:16 --> Utf8 Class Initialized
INFO - 2017-02-17 16:52:16 --> URI Class Initialized
DEBUG - 2017-02-17 16:52:16 --> No URI present. Default controller set.
INFO - 2017-02-17 16:52:16 --> Router Class Initialized
INFO - 2017-02-17 16:52:16 --> Output Class Initialized
INFO - 2017-02-17 16:52:16 --> Security Class Initialized
DEBUG - 2017-02-17 16:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:52:16 --> Input Class Initialized
INFO - 2017-02-17 16:52:16 --> Language Class Initialized
INFO - 2017-02-17 16:52:16 --> Language Class Initialized
INFO - 2017-02-17 16:52:16 --> Config Class Initialized
INFO - 2017-02-17 16:52:16 --> Loader Class Initialized
INFO - 2017-02-17 16:52:16 --> Helper loaded: form_helper
INFO - 2017-02-17 16:52:16 --> Helper loaded: url_helper
INFO - 2017-02-17 16:52:16 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:52:16 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:52:16 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:52:16 --> Template Class Initialized
INFO - 2017-02-17 16:52:16 --> Controller Class Initialized
INFO - 2017-02-17 16:52:16 --> Form Validation Class Initialized
INFO - 2017-02-17 16:52:16 --> Model Class Initialized
DEBUG - 2017-02-17 16:52:16 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 16:52:16 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 16:52:16 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 16:52:16 --> File loaded: C:\xampp\htdocs\RazorClean\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 16:52:16 --> Final output sent to browser
DEBUG - 2017-02-17 16:52:16 --> Total execution time: 0.0804
INFO - 2017-02-17 16:52:31 --> Config Class Initialized
INFO - 2017-02-17 16:52:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:52:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:52:31 --> Utf8 Class Initialized
INFO - 2017-02-17 16:52:31 --> URI Class Initialized
DEBUG - 2017-02-17 16:52:31 --> No URI present. Default controller set.
INFO - 2017-02-17 16:52:31 --> Router Class Initialized
INFO - 2017-02-17 16:52:31 --> Output Class Initialized
INFO - 2017-02-17 16:52:31 --> Security Class Initialized
DEBUG - 2017-02-17 16:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:52:31 --> Input Class Initialized
INFO - 2017-02-17 16:52:31 --> Language Class Initialized
INFO - 2017-02-17 16:52:31 --> Language Class Initialized
INFO - 2017-02-17 16:52:31 --> Config Class Initialized
INFO - 2017-02-17 16:52:31 --> Loader Class Initialized
INFO - 2017-02-17 16:52:31 --> Helper loaded: form_helper
INFO - 2017-02-17 16:52:31 --> Helper loaded: url_helper
INFO - 2017-02-17 16:52:31 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:52:31 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:52:31 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:52:31 --> Template Class Initialized
INFO - 2017-02-17 16:52:31 --> Controller Class Initialized
INFO - 2017-02-17 16:52:31 --> Form Validation Class Initialized
INFO - 2017-02-17 16:52:31 --> Model Class Initialized
DEBUG - 2017-02-17 16:52:31 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 16:52:31 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 16:52:31 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 16:52:31 --> File loaded: C:\xampp\htdocs\RazorClean\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 16:52:31 --> Final output sent to browser
DEBUG - 2017-02-17 16:52:31 --> Total execution time: 0.0948
INFO - 2017-02-17 16:53:18 --> Config Class Initialized
INFO - 2017-02-17 16:53:18 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:53:18 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:53:18 --> Utf8 Class Initialized
INFO - 2017-02-17 16:53:18 --> URI Class Initialized
DEBUG - 2017-02-17 16:53:18 --> No URI present. Default controller set.
INFO - 2017-02-17 16:53:18 --> Router Class Initialized
INFO - 2017-02-17 16:53:18 --> Output Class Initialized
INFO - 2017-02-17 16:53:18 --> Security Class Initialized
DEBUG - 2017-02-17 16:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:53:18 --> Input Class Initialized
INFO - 2017-02-17 16:53:18 --> Language Class Initialized
INFO - 2017-02-17 16:53:18 --> Language Class Initialized
INFO - 2017-02-17 16:53:18 --> Config Class Initialized
INFO - 2017-02-17 16:53:18 --> Loader Class Initialized
INFO - 2017-02-17 16:53:18 --> Helper loaded: form_helper
INFO - 2017-02-17 16:53:18 --> Helper loaded: url_helper
INFO - 2017-02-17 16:53:18 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:53:18 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:53:18 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:53:18 --> Template Class Initialized
INFO - 2017-02-17 16:53:18 --> Controller Class Initialized
INFO - 2017-02-17 16:53:18 --> Form Validation Class Initialized
INFO - 2017-02-17 16:53:18 --> Model Class Initialized
DEBUG - 2017-02-17 16:53:18 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 16:53:18 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 16:53:18 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 16:53:18 --> File loaded: C:\xampp\htdocs\RazorClean\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 16:53:18 --> Final output sent to browser
DEBUG - 2017-02-17 16:53:18 --> Total execution time: 0.0951
INFO - 2017-02-17 16:53:30 --> Config Class Initialized
INFO - 2017-02-17 16:53:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:53:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:53:30 --> Utf8 Class Initialized
INFO - 2017-02-17 16:53:30 --> URI Class Initialized
DEBUG - 2017-02-17 16:53:30 --> No URI present. Default controller set.
INFO - 2017-02-17 16:53:30 --> Router Class Initialized
INFO - 2017-02-17 16:53:30 --> Output Class Initialized
INFO - 2017-02-17 16:53:30 --> Security Class Initialized
DEBUG - 2017-02-17 16:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:53:30 --> Input Class Initialized
INFO - 2017-02-17 16:53:30 --> Language Class Initialized
INFO - 2017-02-17 16:53:30 --> Language Class Initialized
INFO - 2017-02-17 16:53:30 --> Config Class Initialized
INFO - 2017-02-17 16:53:30 --> Loader Class Initialized
INFO - 2017-02-17 16:53:30 --> Helper loaded: form_helper
INFO - 2017-02-17 16:53:30 --> Helper loaded: url_helper
INFO - 2017-02-17 16:53:30 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:53:30 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:53:30 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:53:30 --> Template Class Initialized
INFO - 2017-02-17 16:53:30 --> Controller Class Initialized
INFO - 2017-02-17 16:53:30 --> Form Validation Class Initialized
INFO - 2017-02-17 16:53:30 --> Model Class Initialized
DEBUG - 2017-02-17 16:53:30 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 16:53:30 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 16:53:30 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 16:53:30 --> File loaded: C:\xampp\htdocs\RazorClean\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 16:53:30 --> Final output sent to browser
DEBUG - 2017-02-17 16:53:30 --> Total execution time: 0.1439
INFO - 2017-02-17 16:54:03 --> Config Class Initialized
INFO - 2017-02-17 16:54:03 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:54:03 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:54:03 --> Utf8 Class Initialized
INFO - 2017-02-17 16:54:03 --> URI Class Initialized
DEBUG - 2017-02-17 16:54:03 --> No URI present. Default controller set.
INFO - 2017-02-17 16:54:03 --> Router Class Initialized
INFO - 2017-02-17 16:54:03 --> Output Class Initialized
INFO - 2017-02-17 16:54:03 --> Security Class Initialized
DEBUG - 2017-02-17 16:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:54:03 --> Input Class Initialized
INFO - 2017-02-17 16:54:03 --> Language Class Initialized
INFO - 2017-02-17 16:54:03 --> Language Class Initialized
INFO - 2017-02-17 16:54:03 --> Config Class Initialized
INFO - 2017-02-17 16:54:03 --> Loader Class Initialized
INFO - 2017-02-17 16:54:03 --> Helper loaded: form_helper
INFO - 2017-02-17 16:54:03 --> Helper loaded: url_helper
INFO - 2017-02-17 16:54:03 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:54:03 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:54:03 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:54:03 --> Template Class Initialized
INFO - 2017-02-17 16:54:03 --> Controller Class Initialized
INFO - 2017-02-17 16:54:03 --> Form Validation Class Initialized
INFO - 2017-02-17 16:54:03 --> Model Class Initialized
DEBUG - 2017-02-17 16:54:03 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 16:54:03 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 16:54:03 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 16:54:03 --> File loaded: C:\xampp\htdocs\RazorClean\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 16:54:03 --> Final output sent to browser
DEBUG - 2017-02-17 16:54:03 --> Total execution time: 0.2218
INFO - 2017-02-17 16:54:19 --> Config Class Initialized
INFO - 2017-02-17 16:54:19 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:54:19 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:54:19 --> Utf8 Class Initialized
INFO - 2017-02-17 16:54:19 --> URI Class Initialized
DEBUG - 2017-02-17 16:54:19 --> No URI present. Default controller set.
INFO - 2017-02-17 16:54:19 --> Router Class Initialized
INFO - 2017-02-17 16:54:19 --> Output Class Initialized
INFO - 2017-02-17 16:54:19 --> Security Class Initialized
DEBUG - 2017-02-17 16:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:54:19 --> Input Class Initialized
INFO - 2017-02-17 16:54:19 --> Language Class Initialized
INFO - 2017-02-17 16:54:19 --> Language Class Initialized
INFO - 2017-02-17 16:54:19 --> Config Class Initialized
INFO - 2017-02-17 16:54:19 --> Loader Class Initialized
INFO - 2017-02-17 16:54:19 --> Helper loaded: form_helper
INFO - 2017-02-17 16:54:19 --> Helper loaded: url_helper
INFO - 2017-02-17 16:54:19 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:54:19 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:54:19 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:54:19 --> Template Class Initialized
INFO - 2017-02-17 16:54:19 --> Controller Class Initialized
INFO - 2017-02-17 16:54:19 --> Form Validation Class Initialized
INFO - 2017-02-17 16:54:19 --> Model Class Initialized
DEBUG - 2017-02-17 16:54:19 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-17 16:54:19 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-17 16:54:19 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-17 16:54:19 --> File loaded: C:\xampp\htdocs\RazorClean\application\themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-17 16:54:19 --> Final output sent to browser
DEBUG - 2017-02-17 16:54:19 --> Total execution time: 0.0973
INFO - 2017-02-17 16:54:27 --> Config Class Initialized
INFO - 2017-02-17 16:54:27 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:54:27 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:54:27 --> Utf8 Class Initialized
INFO - 2017-02-17 16:54:27 --> URI Class Initialized
INFO - 2017-02-17 16:54:27 --> Router Class Initialized
INFO - 2017-02-17 16:54:27 --> Output Class Initialized
INFO - 2017-02-17 16:54:27 --> Security Class Initialized
DEBUG - 2017-02-17 16:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:54:27 --> Input Class Initialized
INFO - 2017-02-17 16:54:27 --> Language Class Initialized
INFO - 2017-02-17 16:54:27 --> Language Class Initialized
INFO - 2017-02-17 16:54:27 --> Config Class Initialized
INFO - 2017-02-17 16:54:27 --> Loader Class Initialized
INFO - 2017-02-17 16:54:27 --> Helper loaded: form_helper
INFO - 2017-02-17 16:54:27 --> Helper loaded: url_helper
INFO - 2017-02-17 16:54:27 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:54:27 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:54:27 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:54:27 --> Template Class Initialized
INFO - 2017-02-17 16:54:27 --> Controller Class Initialized
DEBUG - 2017-02-17 16:54:27 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:54:27 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:54:27 --> Model Class Initialized
INFO - 2017-02-17 16:54:27 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:54:27 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:54:27 --> Final output sent to browser
DEBUG - 2017-02-17 16:54:27 --> Total execution time: 0.0660
INFO - 2017-02-17 16:54:31 --> Config Class Initialized
INFO - 2017-02-17 16:54:31 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:54:31 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:54:31 --> Utf8 Class Initialized
INFO - 2017-02-17 16:54:31 --> URI Class Initialized
INFO - 2017-02-17 16:54:31 --> Router Class Initialized
INFO - 2017-02-17 16:54:31 --> Output Class Initialized
INFO - 2017-02-17 16:54:31 --> Security Class Initialized
DEBUG - 2017-02-17 16:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:54:31 --> Input Class Initialized
INFO - 2017-02-17 16:54:31 --> Language Class Initialized
INFO - 2017-02-17 16:54:31 --> Language Class Initialized
INFO - 2017-02-17 16:54:31 --> Config Class Initialized
INFO - 2017-02-17 16:54:31 --> Loader Class Initialized
INFO - 2017-02-17 16:54:31 --> Helper loaded: form_helper
INFO - 2017-02-17 16:54:31 --> Helper loaded: url_helper
INFO - 2017-02-17 16:54:31 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:54:32 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:54:32 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:54:32 --> Template Class Initialized
INFO - 2017-02-17 16:54:32 --> Controller Class Initialized
DEBUG - 2017-02-17 16:54:32 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:54:32 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:54:32 --> Model Class Initialized
INFO - 2017-02-17 16:54:32 --> Form Validation Class Initialized
INFO - 2017-02-17 16:54:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 16:54:32 --> Config Class Initialized
INFO - 2017-02-17 16:54:32 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:54:32 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:54:32 --> Utf8 Class Initialized
INFO - 2017-02-17 16:54:32 --> URI Class Initialized
INFO - 2017-02-17 16:54:32 --> Router Class Initialized
INFO - 2017-02-17 16:54:32 --> Output Class Initialized
INFO - 2017-02-17 16:54:32 --> Security Class Initialized
DEBUG - 2017-02-17 16:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:54:32 --> Input Class Initialized
INFO - 2017-02-17 16:54:32 --> Language Class Initialized
INFO - 2017-02-17 16:54:32 --> Language Class Initialized
INFO - 2017-02-17 16:54:32 --> Config Class Initialized
INFO - 2017-02-17 16:54:32 --> Loader Class Initialized
INFO - 2017-02-17 16:54:32 --> Helper loaded: form_helper
INFO - 2017-02-17 16:54:32 --> Helper loaded: url_helper
INFO - 2017-02-17 16:54:32 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:54:32 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:54:32 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:54:32 --> Template Class Initialized
INFO - 2017-02-17 16:54:32 --> Controller Class Initialized
DEBUG - 2017-02-17 16:54:32 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 16:54:32 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:54:32 --> Model Class Initialized
DEBUG - 2017-02-17 16:54:32 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 16:54:32 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 16:54:32 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 16:54:32 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/backend/views/employee/dashboard.php
DEBUG - 2017-02-17 16:54:32 --> File loaded: C:\xampp\htdocs\RazorClean\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 16:54:32 --> Final output sent to browser
DEBUG - 2017-02-17 16:54:32 --> Total execution time: 0.2707
INFO - 2017-02-17 16:56:26 --> Config Class Initialized
INFO - 2017-02-17 16:56:26 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:56:26 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:56:26 --> Utf8 Class Initialized
INFO - 2017-02-17 16:56:26 --> URI Class Initialized
INFO - 2017-02-17 16:56:26 --> Router Class Initialized
INFO - 2017-02-17 16:56:26 --> Output Class Initialized
INFO - 2017-02-17 16:56:26 --> Security Class Initialized
DEBUG - 2017-02-17 16:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:56:26 --> Input Class Initialized
INFO - 2017-02-17 16:56:26 --> Language Class Initialized
INFO - 2017-02-17 16:56:26 --> Language Class Initialized
INFO - 2017-02-17 16:56:26 --> Config Class Initialized
INFO - 2017-02-17 16:56:26 --> Loader Class Initialized
INFO - 2017-02-17 16:56:26 --> Helper loaded: form_helper
INFO - 2017-02-17 16:56:26 --> Helper loaded: url_helper
INFO - 2017-02-17 16:56:26 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:56:26 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:56:26 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:56:26 --> Template Class Initialized
INFO - 2017-02-17 16:56:26 --> Controller Class Initialized
DEBUG - 2017-02-17 16:56:26 --> Dashboard MX_Controller Initialized
INFO - 2017-02-17 16:56:26 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:56:26 --> Model Class Initialized
DEBUG - 2017-02-17 16:56:26 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-17 16:56:26 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/backend/views/partials/sidebar.php
DEBUG - 2017-02-17 16:56:26 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-17 16:56:26 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/backend/views/employee/dashboard.php
DEBUG - 2017-02-17 16:56:26 --> File loaded: C:\xampp\htdocs\RazorClean\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-17 16:56:26 --> Final output sent to browser
DEBUG - 2017-02-17 16:56:26 --> Total execution time: 0.2335
INFO - 2017-02-17 16:56:29 --> Config Class Initialized
INFO - 2017-02-17 16:56:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:56:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:56:29 --> Utf8 Class Initialized
INFO - 2017-02-17 16:56:29 --> URI Class Initialized
INFO - 2017-02-17 16:56:29 --> Router Class Initialized
INFO - 2017-02-17 16:56:29 --> Output Class Initialized
INFO - 2017-02-17 16:56:29 --> Security Class Initialized
DEBUG - 2017-02-17 16:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:56:29 --> Input Class Initialized
INFO - 2017-02-17 16:56:29 --> Language Class Initialized
INFO - 2017-02-17 16:56:29 --> Language Class Initialized
INFO - 2017-02-17 16:56:29 --> Config Class Initialized
INFO - 2017-02-17 16:56:29 --> Loader Class Initialized
INFO - 2017-02-17 16:56:29 --> Helper loaded: form_helper
INFO - 2017-02-17 16:56:29 --> Helper loaded: url_helper
INFO - 2017-02-17 16:56:29 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:56:29 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:56:29 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:56:29 --> Template Class Initialized
INFO - 2017-02-17 16:56:29 --> Controller Class Initialized
DEBUG - 2017-02-17 16:56:29 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:56:29 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:56:29 --> Model Class Initialized
INFO - 2017-02-17 16:56:29 --> Form Validation Class Initialized
INFO - 2017-02-17 16:56:29 --> Config Class Initialized
INFO - 2017-02-17 16:56:29 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:56:29 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:56:29 --> Utf8 Class Initialized
INFO - 2017-02-17 16:56:29 --> URI Class Initialized
INFO - 2017-02-17 16:56:29 --> Router Class Initialized
INFO - 2017-02-17 16:56:29 --> Output Class Initialized
INFO - 2017-02-17 16:56:29 --> Security Class Initialized
DEBUG - 2017-02-17 16:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:56:29 --> Input Class Initialized
INFO - 2017-02-17 16:56:29 --> Language Class Initialized
ERROR - 2017-02-17 16:56:29 --> 404 Page Not Found: /index
INFO - 2017-02-17 16:56:52 --> Config Class Initialized
INFO - 2017-02-17 16:56:52 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:56:52 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:56:52 --> Utf8 Class Initialized
INFO - 2017-02-17 16:56:52 --> URI Class Initialized
INFO - 2017-02-17 16:56:52 --> Router Class Initialized
INFO - 2017-02-17 16:56:52 --> Output Class Initialized
INFO - 2017-02-17 16:56:52 --> Security Class Initialized
DEBUG - 2017-02-17 16:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:56:52 --> Input Class Initialized
INFO - 2017-02-17 16:56:52 --> Language Class Initialized
ERROR - 2017-02-17 16:56:52 --> 404 Page Not Found: /index
INFO - 2017-02-17 16:57:12 --> Config Class Initialized
INFO - 2017-02-17 16:57:12 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:57:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:57:12 --> Utf8 Class Initialized
INFO - 2017-02-17 16:57:12 --> URI Class Initialized
INFO - 2017-02-17 16:57:12 --> Router Class Initialized
INFO - 2017-02-17 16:57:12 --> Output Class Initialized
INFO - 2017-02-17 16:57:12 --> Security Class Initialized
DEBUG - 2017-02-17 16:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:57:12 --> Input Class Initialized
INFO - 2017-02-17 16:57:12 --> Language Class Initialized
INFO - 2017-02-17 16:57:12 --> Language Class Initialized
INFO - 2017-02-17 16:57:12 --> Config Class Initialized
INFO - 2017-02-17 16:57:12 --> Loader Class Initialized
INFO - 2017-02-17 16:57:12 --> Helper loaded: form_helper
INFO - 2017-02-17 16:57:12 --> Helper loaded: url_helper
INFO - 2017-02-17 16:57:12 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:57:12 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:57:12 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:57:12 --> Template Class Initialized
INFO - 2017-02-17 16:57:12 --> Controller Class Initialized
DEBUG - 2017-02-17 16:57:12 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:57:12 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:57:12 --> Model Class Initialized
INFO - 2017-02-17 16:57:12 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:57:12 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:57:12 --> Final output sent to browser
DEBUG - 2017-02-17 16:57:12 --> Total execution time: 0.0531
INFO - 2017-02-17 16:57:18 --> Config Class Initialized
INFO - 2017-02-17 16:57:18 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:57:18 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:57:18 --> Utf8 Class Initialized
INFO - 2017-02-17 16:57:18 --> URI Class Initialized
INFO - 2017-02-17 16:57:18 --> Router Class Initialized
INFO - 2017-02-17 16:57:18 --> Output Class Initialized
INFO - 2017-02-17 16:57:18 --> Security Class Initialized
DEBUG - 2017-02-17 16:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:57:18 --> Input Class Initialized
INFO - 2017-02-17 16:57:18 --> Language Class Initialized
INFO - 2017-02-17 16:57:18 --> Language Class Initialized
INFO - 2017-02-17 16:57:18 --> Config Class Initialized
INFO - 2017-02-17 16:57:18 --> Loader Class Initialized
INFO - 2017-02-17 16:57:18 --> Helper loaded: form_helper
INFO - 2017-02-17 16:57:18 --> Helper loaded: url_helper
INFO - 2017-02-17 16:57:18 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:57:18 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:57:18 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:57:18 --> Template Class Initialized
INFO - 2017-02-17 16:57:18 --> Controller Class Initialized
DEBUG - 2017-02-17 16:57:18 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:57:18 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:57:18 --> Model Class Initialized
INFO - 2017-02-17 16:57:18 --> Form Validation Class Initialized
INFO - 2017-02-17 16:57:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 16:57:18 --> Config Class Initialized
INFO - 2017-02-17 16:57:18 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:57:18 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:57:18 --> Utf8 Class Initialized
INFO - 2017-02-17 16:57:18 --> URI Class Initialized
INFO - 2017-02-17 16:57:18 --> Router Class Initialized
INFO - 2017-02-17 16:57:18 --> Output Class Initialized
INFO - 2017-02-17 16:57:18 --> Security Class Initialized
DEBUG - 2017-02-17 16:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:57:18 --> Input Class Initialized
INFO - 2017-02-17 16:57:18 --> Language Class Initialized
INFO - 2017-02-17 16:57:18 --> Language Class Initialized
INFO - 2017-02-17 16:57:18 --> Config Class Initialized
INFO - 2017-02-17 16:57:18 --> Loader Class Initialized
INFO - 2017-02-17 16:57:18 --> Helper loaded: form_helper
INFO - 2017-02-17 16:57:18 --> Helper loaded: url_helper
INFO - 2017-02-17 16:57:18 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:57:18 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:57:18 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:57:18 --> Template Class Initialized
INFO - 2017-02-17 16:57:18 --> Controller Class Initialized
DEBUG - 2017-02-17 16:57:18 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:57:18 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:57:18 --> Model Class Initialized
INFO - 2017-02-17 16:57:18 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:57:18 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:57:18 --> Final output sent to browser
DEBUG - 2017-02-17 16:57:18 --> Total execution time: 0.0542
INFO - 2017-02-17 16:57:53 --> Config Class Initialized
INFO - 2017-02-17 16:57:53 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:57:53 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:57:53 --> Utf8 Class Initialized
INFO - 2017-02-17 16:57:53 --> URI Class Initialized
INFO - 2017-02-17 16:57:53 --> Router Class Initialized
INFO - 2017-02-17 16:57:53 --> Output Class Initialized
INFO - 2017-02-17 16:57:53 --> Security Class Initialized
DEBUG - 2017-02-17 16:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:57:53 --> Input Class Initialized
INFO - 2017-02-17 16:57:53 --> Language Class Initialized
INFO - 2017-02-17 16:57:53 --> Language Class Initialized
INFO - 2017-02-17 16:57:53 --> Config Class Initialized
INFO - 2017-02-17 16:57:53 --> Loader Class Initialized
INFO - 2017-02-17 16:57:53 --> Helper loaded: form_helper
INFO - 2017-02-17 16:57:53 --> Helper loaded: url_helper
INFO - 2017-02-17 16:57:53 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:57:53 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:57:53 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:57:53 --> Template Class Initialized
INFO - 2017-02-17 16:57:53 --> Controller Class Initialized
DEBUG - 2017-02-17 16:57:53 --> Signup MX_Controller Initialized
INFO - 2017-02-17 16:57:53 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:57:53 --> Model Class Initialized
INFO - 2017-02-17 16:57:53 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:57:53 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/signup.php
INFO - 2017-02-17 16:57:53 --> Final output sent to browser
DEBUG - 2017-02-17 16:57:53 --> Total execution time: 0.1896
INFO - 2017-02-17 16:58:05 --> Config Class Initialized
INFO - 2017-02-17 16:58:05 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:58:05 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:58:05 --> Utf8 Class Initialized
INFO - 2017-02-17 16:58:05 --> URI Class Initialized
INFO - 2017-02-17 16:58:06 --> Router Class Initialized
INFO - 2017-02-17 16:58:06 --> Output Class Initialized
INFO - 2017-02-17 16:58:06 --> Security Class Initialized
DEBUG - 2017-02-17 16:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:58:06 --> Input Class Initialized
INFO - 2017-02-17 16:58:06 --> Language Class Initialized
INFO - 2017-02-17 16:58:06 --> Language Class Initialized
INFO - 2017-02-17 16:58:06 --> Config Class Initialized
INFO - 2017-02-17 16:58:06 --> Loader Class Initialized
INFO - 2017-02-17 16:58:06 --> Helper loaded: form_helper
INFO - 2017-02-17 16:58:06 --> Helper loaded: url_helper
INFO - 2017-02-17 16:58:06 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:58:06 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:58:06 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:58:06 --> Template Class Initialized
INFO - 2017-02-17 16:58:06 --> Controller Class Initialized
DEBUG - 2017-02-17 16:58:06 --> Register MX_Controller Initialized
INFO - 2017-02-17 16:58:06 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:58:06 --> Model Class Initialized
INFO - 2017-02-17 16:58:06 --> Form Validation Class Initialized
INFO - 2017-02-17 16:58:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 16:58:06 --> Config Class Initialized
INFO - 2017-02-17 16:58:06 --> Hooks Class Initialized
DEBUG - 2017-02-17 16:58:06 --> UTF-8 Support Enabled
INFO - 2017-02-17 16:58:06 --> Utf8 Class Initialized
INFO - 2017-02-17 16:58:06 --> URI Class Initialized
INFO - 2017-02-17 16:58:06 --> Router Class Initialized
INFO - 2017-02-17 16:58:06 --> Output Class Initialized
INFO - 2017-02-17 16:58:06 --> Security Class Initialized
DEBUG - 2017-02-17 16:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 16:58:06 --> Input Class Initialized
INFO - 2017-02-17 16:58:06 --> Language Class Initialized
INFO - 2017-02-17 16:58:06 --> Language Class Initialized
INFO - 2017-02-17 16:58:06 --> Config Class Initialized
INFO - 2017-02-17 16:58:06 --> Loader Class Initialized
INFO - 2017-02-17 16:58:06 --> Helper loaded: form_helper
INFO - 2017-02-17 16:58:06 --> Helper loaded: url_helper
INFO - 2017-02-17 16:58:06 --> Helper loaded: utility_helper
INFO - 2017-02-17 16:58:06 --> Database Driver Class Initialized
DEBUG - 2017-02-17 16:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 16:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 16:58:06 --> User Agent Class Initialized
DEBUG - 2017-02-17 16:58:06 --> Template Class Initialized
INFO - 2017-02-17 16:58:06 --> Controller Class Initialized
DEBUG - 2017-02-17 16:58:06 --> Login MX_Controller Initialized
INFO - 2017-02-17 16:58:06 --> Helper loaded: cookie_helper
INFO - 2017-02-17 16:58:06 --> Model Class Initialized
INFO - 2017-02-17 16:58:06 --> Form Validation Class Initialized
DEBUG - 2017-02-17 16:58:06 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 16:58:06 --> Final output sent to browser
DEBUG - 2017-02-17 16:58:06 --> Total execution time: 0.0537
INFO - 2017-02-17 17:00:20 --> Config Class Initialized
INFO - 2017-02-17 17:00:20 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:00:20 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:00:20 --> Utf8 Class Initialized
INFO - 2017-02-17 17:00:20 --> URI Class Initialized
INFO - 2017-02-17 17:00:20 --> Router Class Initialized
INFO - 2017-02-17 17:00:20 --> Output Class Initialized
INFO - 2017-02-17 17:00:20 --> Security Class Initialized
DEBUG - 2017-02-17 17:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:00:20 --> Input Class Initialized
INFO - 2017-02-17 17:00:20 --> Language Class Initialized
INFO - 2017-02-17 17:00:20 --> Language Class Initialized
INFO - 2017-02-17 17:00:20 --> Config Class Initialized
INFO - 2017-02-17 17:00:20 --> Loader Class Initialized
INFO - 2017-02-17 17:00:20 --> Helper loaded: form_helper
INFO - 2017-02-17 17:00:20 --> Helper loaded: url_helper
INFO - 2017-02-17 17:00:20 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:00:20 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:00:20 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:00:20 --> Template Class Initialized
INFO - 2017-02-17 17:00:20 --> Controller Class Initialized
DEBUG - 2017-02-17 17:00:20 --> Signup MX_Controller Initialized
INFO - 2017-02-17 17:00:20 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:00:20 --> Model Class Initialized
INFO - 2017-02-17 17:00:20 --> Form Validation Class Initialized
DEBUG - 2017-02-17 17:00:20 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/signup.php
INFO - 2017-02-17 17:00:20 --> Final output sent to browser
DEBUG - 2017-02-17 17:00:20 --> Total execution time: 0.0389
INFO - 2017-02-17 17:00:27 --> Config Class Initialized
INFO - 2017-02-17 17:00:27 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:00:27 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:00:27 --> Utf8 Class Initialized
INFO - 2017-02-17 17:00:27 --> URI Class Initialized
INFO - 2017-02-17 17:00:27 --> Router Class Initialized
INFO - 2017-02-17 17:00:27 --> Output Class Initialized
INFO - 2017-02-17 17:00:27 --> Security Class Initialized
DEBUG - 2017-02-17 17:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:00:27 --> Input Class Initialized
INFO - 2017-02-17 17:00:27 --> Language Class Initialized
INFO - 2017-02-17 17:00:27 --> Language Class Initialized
INFO - 2017-02-17 17:00:27 --> Config Class Initialized
INFO - 2017-02-17 17:00:27 --> Loader Class Initialized
INFO - 2017-02-17 17:00:27 --> Helper loaded: form_helper
INFO - 2017-02-17 17:00:27 --> Helper loaded: url_helper
INFO - 2017-02-17 17:00:27 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:00:27 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:00:27 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:00:27 --> Template Class Initialized
INFO - 2017-02-17 17:00:27 --> Controller Class Initialized
DEBUG - 2017-02-17 17:00:27 --> Register MX_Controller Initialized
INFO - 2017-02-17 17:00:27 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:00:27 --> Model Class Initialized
INFO - 2017-02-17 17:00:27 --> Form Validation Class Initialized
INFO - 2017-02-17 17:00:27 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 17:00:27 --> Severity: Error --> Undefined class constant 'ADMIN_USERS' C:\xampp\htdocs\RazorClean\application\modules\frontend\controllers\Register.php 50
INFO - 2017-02-17 17:00:56 --> Config Class Initialized
INFO - 2017-02-17 17:00:56 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:00:56 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:00:56 --> Utf8 Class Initialized
INFO - 2017-02-17 17:00:56 --> URI Class Initialized
INFO - 2017-02-17 17:00:56 --> Router Class Initialized
INFO - 2017-02-17 17:00:56 --> Output Class Initialized
INFO - 2017-02-17 17:00:56 --> Security Class Initialized
DEBUG - 2017-02-17 17:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:00:56 --> Input Class Initialized
INFO - 2017-02-17 17:00:56 --> Language Class Initialized
INFO - 2017-02-17 17:00:56 --> Language Class Initialized
INFO - 2017-02-17 17:00:56 --> Config Class Initialized
INFO - 2017-02-17 17:00:56 --> Loader Class Initialized
INFO - 2017-02-17 17:00:56 --> Helper loaded: form_helper
INFO - 2017-02-17 17:00:56 --> Helper loaded: url_helper
INFO - 2017-02-17 17:00:56 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:00:56 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:00:56 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:00:56 --> Template Class Initialized
INFO - 2017-02-17 17:00:56 --> Controller Class Initialized
DEBUG - 2017-02-17 17:00:56 --> Register MX_Controller Initialized
INFO - 2017-02-17 17:00:56 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:00:56 --> Model Class Initialized
INFO - 2017-02-17 17:00:56 --> Form Validation Class Initialized
INFO - 2017-02-17 17:00:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 17:00:57 --> Severity: Error --> Access to undeclared static property: TABLES::$ADMIN_USERS C:\xampp\htdocs\RazorClean\application\modules\frontend\controllers\Register.php 50
INFO - 2017-02-17 17:01:19 --> Config Class Initialized
INFO - 2017-02-17 17:01:19 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:01:19 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:01:19 --> Utf8 Class Initialized
INFO - 2017-02-17 17:01:19 --> URI Class Initialized
INFO - 2017-02-17 17:01:19 --> Router Class Initialized
INFO - 2017-02-17 17:01:19 --> Output Class Initialized
INFO - 2017-02-17 17:01:19 --> Security Class Initialized
DEBUG - 2017-02-17 17:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:01:19 --> Input Class Initialized
INFO - 2017-02-17 17:01:19 --> Language Class Initialized
INFO - 2017-02-17 17:01:19 --> Language Class Initialized
INFO - 2017-02-17 17:01:19 --> Config Class Initialized
INFO - 2017-02-17 17:01:19 --> Loader Class Initialized
INFO - 2017-02-17 17:01:19 --> Helper loaded: form_helper
INFO - 2017-02-17 17:01:19 --> Helper loaded: url_helper
INFO - 2017-02-17 17:01:19 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:01:19 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:01:19 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:01:19 --> Template Class Initialized
INFO - 2017-02-17 17:01:19 --> Controller Class Initialized
DEBUG - 2017-02-17 17:01:19 --> Register MX_Controller Initialized
INFO - 2017-02-17 17:01:19 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:01:19 --> Model Class Initialized
INFO - 2017-02-17 17:01:19 --> Form Validation Class Initialized
INFO - 2017-02-17 17:01:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 17:01:19 --> Severity: Error --> Access to undeclared static property: TABLES::$ADMIN_USERS C:\xampp\htdocs\RazorClean\application\modules\frontend\controllers\Register.php 50
INFO - 2017-02-17 17:01:47 --> Config Class Initialized
INFO - 2017-02-17 17:01:47 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:01:47 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:01:47 --> Utf8 Class Initialized
INFO - 2017-02-17 17:01:47 --> URI Class Initialized
INFO - 2017-02-17 17:01:47 --> Router Class Initialized
INFO - 2017-02-17 17:01:47 --> Output Class Initialized
INFO - 2017-02-17 17:01:47 --> Security Class Initialized
DEBUG - 2017-02-17 17:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:01:47 --> Input Class Initialized
INFO - 2017-02-17 17:01:47 --> Language Class Initialized
INFO - 2017-02-17 17:01:47 --> Language Class Initialized
INFO - 2017-02-17 17:01:47 --> Config Class Initialized
INFO - 2017-02-17 17:01:47 --> Loader Class Initialized
INFO - 2017-02-17 17:01:47 --> Helper loaded: form_helper
INFO - 2017-02-17 17:01:47 --> Helper loaded: url_helper
INFO - 2017-02-17 17:01:47 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:01:47 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:01:47 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:01:47 --> Template Class Initialized
INFO - 2017-02-17 17:01:47 --> Controller Class Initialized
DEBUG - 2017-02-17 17:01:47 --> Register MX_Controller Initialized
INFO - 2017-02-17 17:01:47 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:01:47 --> Model Class Initialized
INFO - 2017-02-17 17:01:47 --> Form Validation Class Initialized
INFO - 2017-02-17 17:01:47 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 17:01:48 --> Severity: Error --> Access to undeclared static property: TABLES::$ADMIN_USERS C:\xampp\htdocs\RazorClean\application\modules\frontend\controllers\Register.php 50
INFO - 2017-02-17 17:03:30 --> Config Class Initialized
INFO - 2017-02-17 17:03:30 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:03:30 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:03:30 --> Utf8 Class Initialized
INFO - 2017-02-17 17:03:30 --> URI Class Initialized
INFO - 2017-02-17 17:03:30 --> Router Class Initialized
INFO - 2017-02-17 17:03:30 --> Output Class Initialized
INFO - 2017-02-17 17:03:30 --> Security Class Initialized
DEBUG - 2017-02-17 17:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:03:30 --> Input Class Initialized
INFO - 2017-02-17 17:03:30 --> Language Class Initialized
INFO - 2017-02-17 17:03:30 --> Language Class Initialized
INFO - 2017-02-17 17:03:30 --> Config Class Initialized
INFO - 2017-02-17 17:03:30 --> Loader Class Initialized
INFO - 2017-02-17 17:03:30 --> Helper loaded: form_helper
INFO - 2017-02-17 17:03:30 --> Helper loaded: url_helper
INFO - 2017-02-17 17:03:30 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:03:30 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:03:30 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:03:30 --> Template Class Initialized
INFO - 2017-02-17 17:03:30 --> Controller Class Initialized
DEBUG - 2017-02-17 17:03:30 --> Register MX_Controller Initialized
INFO - 2017-02-17 17:03:30 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:03:30 --> Model Class Initialized
INFO - 2017-02-17 17:03:30 --> Form Validation Class Initialized
INFO - 2017-02-17 17:03:30 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 17:03:30 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `tbl_users` (`username`, `email`, `password`, `created_time`) VALUES (NULL, NULL, '202cb962ac59075b964b07152d234b70', '2017-02-17 17:03:30')
INFO - 2017-02-17 17:03:30 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-17 17:03:53 --> Config Class Initialized
INFO - 2017-02-17 17:03:53 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:03:53 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:03:53 --> Utf8 Class Initialized
INFO - 2017-02-17 17:03:53 --> URI Class Initialized
INFO - 2017-02-17 17:03:53 --> Router Class Initialized
INFO - 2017-02-17 17:03:53 --> Output Class Initialized
INFO - 2017-02-17 17:03:53 --> Security Class Initialized
DEBUG - 2017-02-17 17:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:03:53 --> Input Class Initialized
INFO - 2017-02-17 17:03:53 --> Language Class Initialized
INFO - 2017-02-17 17:03:53 --> Language Class Initialized
INFO - 2017-02-17 17:03:53 --> Config Class Initialized
INFO - 2017-02-17 17:03:53 --> Loader Class Initialized
INFO - 2017-02-17 17:03:53 --> Helper loaded: form_helper
INFO - 2017-02-17 17:03:53 --> Helper loaded: url_helper
INFO - 2017-02-17 17:03:53 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:03:53 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:03:53 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:03:53 --> Template Class Initialized
INFO - 2017-02-17 17:03:53 --> Controller Class Initialized
DEBUG - 2017-02-17 17:03:53 --> Register MX_Controller Initialized
INFO - 2017-02-17 17:03:53 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:03:53 --> Model Class Initialized
INFO - 2017-02-17 17:03:53 --> Form Validation Class Initialized
INFO - 2017-02-17 17:03:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 17:03:53 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `tbl_users` (`username`, `password`, `created_time`) VALUES (NULL, '202cb962ac59075b964b07152d234b70', '2017-02-17 17:03:53')
INFO - 2017-02-17 17:03:53 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-17 17:04:12 --> Config Class Initialized
INFO - 2017-02-17 17:04:12 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:04:12 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:04:12 --> Utf8 Class Initialized
INFO - 2017-02-17 17:04:12 --> URI Class Initialized
INFO - 2017-02-17 17:04:12 --> Router Class Initialized
INFO - 2017-02-17 17:04:12 --> Output Class Initialized
INFO - 2017-02-17 17:04:12 --> Security Class Initialized
DEBUG - 2017-02-17 17:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:04:12 --> Input Class Initialized
INFO - 2017-02-17 17:04:12 --> Language Class Initialized
INFO - 2017-02-17 17:04:12 --> Language Class Initialized
INFO - 2017-02-17 17:04:12 --> Config Class Initialized
INFO - 2017-02-17 17:04:12 --> Loader Class Initialized
INFO - 2017-02-17 17:04:12 --> Helper loaded: form_helper
INFO - 2017-02-17 17:04:12 --> Helper loaded: url_helper
INFO - 2017-02-17 17:04:12 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:04:12 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:04:12 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:04:12 --> Template Class Initialized
INFO - 2017-02-17 17:04:12 --> Controller Class Initialized
DEBUG - 2017-02-17 17:04:12 --> Signup MX_Controller Initialized
INFO - 2017-02-17 17:04:12 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:04:12 --> Model Class Initialized
INFO - 2017-02-17 17:04:12 --> Form Validation Class Initialized
DEBUG - 2017-02-17 17:04:12 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/signup.php
INFO - 2017-02-17 17:04:12 --> Final output sent to browser
DEBUG - 2017-02-17 17:04:12 --> Total execution time: 0.0784
INFO - 2017-02-17 17:04:18 --> Config Class Initialized
INFO - 2017-02-17 17:04:18 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:04:18 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:04:18 --> Utf8 Class Initialized
INFO - 2017-02-17 17:04:18 --> URI Class Initialized
INFO - 2017-02-17 17:04:18 --> Router Class Initialized
INFO - 2017-02-17 17:04:18 --> Output Class Initialized
INFO - 2017-02-17 17:04:18 --> Security Class Initialized
DEBUG - 2017-02-17 17:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:04:18 --> Input Class Initialized
INFO - 2017-02-17 17:04:18 --> Language Class Initialized
INFO - 2017-02-17 17:04:18 --> Language Class Initialized
INFO - 2017-02-17 17:04:18 --> Config Class Initialized
INFO - 2017-02-17 17:04:18 --> Loader Class Initialized
INFO - 2017-02-17 17:04:18 --> Helper loaded: form_helper
INFO - 2017-02-17 17:04:18 --> Helper loaded: url_helper
INFO - 2017-02-17 17:04:18 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:04:18 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:04:18 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:04:18 --> Template Class Initialized
INFO - 2017-02-17 17:04:18 --> Controller Class Initialized
DEBUG - 2017-02-17 17:04:18 --> Register MX_Controller Initialized
INFO - 2017-02-17 17:04:18 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:04:18 --> Model Class Initialized
INFO - 2017-02-17 17:04:18 --> Form Validation Class Initialized
INFO - 2017-02-17 17:04:18 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 17:04:19 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `tbl_users` (`username`, `password`, `created_time`) VALUES (NULL, '9990775155c3518a0d7917f7780b24aa', '2017-02-17 17:04:19')
INFO - 2017-02-17 17:04:19 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-17 17:04:42 --> Config Class Initialized
INFO - 2017-02-17 17:04:42 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:04:42 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:04:42 --> Utf8 Class Initialized
INFO - 2017-02-17 17:04:42 --> URI Class Initialized
INFO - 2017-02-17 17:04:42 --> Router Class Initialized
INFO - 2017-02-17 17:04:42 --> Output Class Initialized
INFO - 2017-02-17 17:04:42 --> Security Class Initialized
DEBUG - 2017-02-17 17:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:04:42 --> Input Class Initialized
INFO - 2017-02-17 17:04:42 --> Language Class Initialized
INFO - 2017-02-17 17:04:42 --> Language Class Initialized
INFO - 2017-02-17 17:04:42 --> Config Class Initialized
INFO - 2017-02-17 17:04:42 --> Loader Class Initialized
INFO - 2017-02-17 17:04:42 --> Helper loaded: form_helper
INFO - 2017-02-17 17:04:42 --> Helper loaded: url_helper
INFO - 2017-02-17 17:04:42 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:04:42 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:04:42 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:04:42 --> Template Class Initialized
INFO - 2017-02-17 17:04:42 --> Controller Class Initialized
DEBUG - 2017-02-17 17:04:42 --> Register MX_Controller Initialized
INFO - 2017-02-17 17:04:42 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:04:42 --> Model Class Initialized
INFO - 2017-02-17 17:04:42 --> Form Validation Class Initialized
INFO - 2017-02-17 17:04:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 17:04:44 --> Config Class Initialized
INFO - 2017-02-17 17:04:44 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:04:44 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:04:44 --> Utf8 Class Initialized
INFO - 2017-02-17 17:04:44 --> URI Class Initialized
INFO - 2017-02-17 17:04:44 --> Router Class Initialized
INFO - 2017-02-17 17:04:44 --> Output Class Initialized
INFO - 2017-02-17 17:04:44 --> Security Class Initialized
DEBUG - 2017-02-17 17:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:04:44 --> Input Class Initialized
INFO - 2017-02-17 17:04:44 --> Language Class Initialized
INFO - 2017-02-17 17:04:44 --> Language Class Initialized
INFO - 2017-02-17 17:04:44 --> Config Class Initialized
INFO - 2017-02-17 17:04:44 --> Loader Class Initialized
INFO - 2017-02-17 17:04:44 --> Helper loaded: form_helper
INFO - 2017-02-17 17:04:44 --> Helper loaded: url_helper
INFO - 2017-02-17 17:04:44 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:04:44 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:04:44 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:04:44 --> Template Class Initialized
INFO - 2017-02-17 17:04:44 --> Controller Class Initialized
DEBUG - 2017-02-17 17:04:44 --> Login MX_Controller Initialized
INFO - 2017-02-17 17:04:44 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:04:44 --> Model Class Initialized
INFO - 2017-02-17 17:04:44 --> Form Validation Class Initialized
DEBUG - 2017-02-17 17:04:44 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 17:04:44 --> Final output sent to browser
DEBUG - 2017-02-17 17:04:44 --> Total execution time: 0.5201
INFO - 2017-02-17 17:05:10 --> Config Class Initialized
INFO - 2017-02-17 17:05:10 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:05:10 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:05:10 --> Utf8 Class Initialized
INFO - 2017-02-17 17:05:10 --> URI Class Initialized
INFO - 2017-02-17 17:05:10 --> Router Class Initialized
INFO - 2017-02-17 17:05:10 --> Output Class Initialized
INFO - 2017-02-17 17:05:10 --> Security Class Initialized
DEBUG - 2017-02-17 17:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:05:10 --> Input Class Initialized
INFO - 2017-02-17 17:05:10 --> Language Class Initialized
INFO - 2017-02-17 17:05:10 --> Language Class Initialized
INFO - 2017-02-17 17:05:10 --> Config Class Initialized
INFO - 2017-02-17 17:05:10 --> Loader Class Initialized
INFO - 2017-02-17 17:05:10 --> Helper loaded: form_helper
INFO - 2017-02-17 17:05:10 --> Helper loaded: url_helper
INFO - 2017-02-17 17:05:10 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:05:10 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:05:10 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:05:10 --> Template Class Initialized
INFO - 2017-02-17 17:05:10 --> Controller Class Initialized
DEBUG - 2017-02-17 17:05:10 --> Signup MX_Controller Initialized
INFO - 2017-02-17 17:05:10 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:05:10 --> Model Class Initialized
INFO - 2017-02-17 17:05:10 --> Form Validation Class Initialized
DEBUG - 2017-02-17 17:05:10 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/signup.php
INFO - 2017-02-17 17:05:10 --> Final output sent to browser
DEBUG - 2017-02-17 17:05:10 --> Total execution time: 0.0635
INFO - 2017-02-17 17:05:17 --> Config Class Initialized
INFO - 2017-02-17 17:05:17 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:05:17 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:05:17 --> Utf8 Class Initialized
INFO - 2017-02-17 17:05:17 --> URI Class Initialized
INFO - 2017-02-17 17:05:17 --> Router Class Initialized
INFO - 2017-02-17 17:05:17 --> Output Class Initialized
INFO - 2017-02-17 17:05:17 --> Security Class Initialized
DEBUG - 2017-02-17 17:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:05:17 --> Input Class Initialized
INFO - 2017-02-17 17:05:17 --> Language Class Initialized
INFO - 2017-02-17 17:05:17 --> Language Class Initialized
INFO - 2017-02-17 17:05:17 --> Config Class Initialized
INFO - 2017-02-17 17:05:17 --> Loader Class Initialized
INFO - 2017-02-17 17:05:17 --> Helper loaded: form_helper
INFO - 2017-02-17 17:05:17 --> Helper loaded: url_helper
INFO - 2017-02-17 17:05:17 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:05:17 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:05:17 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:05:17 --> Template Class Initialized
INFO - 2017-02-17 17:05:17 --> Controller Class Initialized
DEBUG - 2017-02-17 17:05:17 --> Register MX_Controller Initialized
INFO - 2017-02-17 17:05:17 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:05:17 --> Model Class Initialized
INFO - 2017-02-17 17:05:17 --> Form Validation Class Initialized
INFO - 2017-02-17 17:05:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-17 17:05:17 --> Config Class Initialized
INFO - 2017-02-17 17:05:17 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:05:17 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:05:17 --> Utf8 Class Initialized
INFO - 2017-02-17 17:05:17 --> URI Class Initialized
INFO - 2017-02-17 17:05:17 --> Router Class Initialized
INFO - 2017-02-17 17:05:17 --> Output Class Initialized
INFO - 2017-02-17 17:05:17 --> Security Class Initialized
DEBUG - 2017-02-17 17:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:05:17 --> Input Class Initialized
INFO - 2017-02-17 17:05:17 --> Language Class Initialized
INFO - 2017-02-17 17:05:17 --> Language Class Initialized
INFO - 2017-02-17 17:05:17 --> Config Class Initialized
INFO - 2017-02-17 17:05:17 --> Loader Class Initialized
INFO - 2017-02-17 17:05:17 --> Helper loaded: form_helper
INFO - 2017-02-17 17:05:17 --> Helper loaded: url_helper
INFO - 2017-02-17 17:05:17 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:05:17 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:05:17 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:05:17 --> Template Class Initialized
INFO - 2017-02-17 17:05:17 --> Controller Class Initialized
DEBUG - 2017-02-17 17:05:17 --> Signup MX_Controller Initialized
INFO - 2017-02-17 17:05:17 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:05:17 --> Model Class Initialized
INFO - 2017-02-17 17:05:17 --> Form Validation Class Initialized
DEBUG - 2017-02-17 17:05:17 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/signup.php
INFO - 2017-02-17 17:05:17 --> Final output sent to browser
DEBUG - 2017-02-17 17:05:17 --> Total execution time: 0.0559
INFO - 2017-02-17 17:06:04 --> Config Class Initialized
INFO - 2017-02-17 17:06:04 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:06:04 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:06:04 --> Utf8 Class Initialized
INFO - 2017-02-17 17:06:04 --> URI Class Initialized
INFO - 2017-02-17 17:06:04 --> Router Class Initialized
INFO - 2017-02-17 17:06:04 --> Output Class Initialized
INFO - 2017-02-17 17:06:04 --> Security Class Initialized
DEBUG - 2017-02-17 17:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:06:04 --> Input Class Initialized
INFO - 2017-02-17 17:06:04 --> Language Class Initialized
INFO - 2017-02-17 17:06:04 --> Language Class Initialized
INFO - 2017-02-17 17:06:04 --> Config Class Initialized
INFO - 2017-02-17 17:06:04 --> Loader Class Initialized
INFO - 2017-02-17 17:06:04 --> Helper loaded: form_helper
INFO - 2017-02-17 17:06:04 --> Helper loaded: url_helper
INFO - 2017-02-17 17:06:04 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:06:04 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:06:06 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:06:06 --> Template Class Initialized
INFO - 2017-02-17 17:06:06 --> Controller Class Initialized
DEBUG - 2017-02-17 17:06:06 --> Signup MX_Controller Initialized
INFO - 2017-02-17 17:06:06 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:06:06 --> Model Class Initialized
INFO - 2017-02-17 17:06:06 --> Form Validation Class Initialized
DEBUG - 2017-02-17 17:06:06 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/signup.php
INFO - 2017-02-17 17:06:06 --> Final output sent to browser
DEBUG - 2017-02-17 17:06:06 --> Total execution time: 2.0496
INFO - 2017-02-17 17:09:14 --> Config Class Initialized
INFO - 2017-02-17 17:09:14 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:09:14 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:09:14 --> Utf8 Class Initialized
INFO - 2017-02-17 17:09:14 --> URI Class Initialized
INFO - 2017-02-17 17:09:14 --> Router Class Initialized
INFO - 2017-02-17 17:09:14 --> Output Class Initialized
INFO - 2017-02-17 17:09:14 --> Security Class Initialized
DEBUG - 2017-02-17 17:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:09:14 --> Input Class Initialized
INFO - 2017-02-17 17:09:14 --> Language Class Initialized
INFO - 2017-02-17 17:09:14 --> Language Class Initialized
INFO - 2017-02-17 17:09:14 --> Config Class Initialized
INFO - 2017-02-17 17:09:14 --> Loader Class Initialized
INFO - 2017-02-17 17:09:14 --> Helper loaded: form_helper
INFO - 2017-02-17 17:09:14 --> Helper loaded: url_helper
INFO - 2017-02-17 17:09:14 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:09:14 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:09:14 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:09:14 --> Template Class Initialized
INFO - 2017-02-17 17:09:14 --> Controller Class Initialized
DEBUG - 2017-02-17 17:09:14 --> Signup MX_Controller Initialized
INFO - 2017-02-17 17:09:14 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:09:15 --> Model Class Initialized
INFO - 2017-02-17 17:09:15 --> Form Validation Class Initialized
DEBUG - 2017-02-17 17:09:15 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/signup.php
INFO - 2017-02-17 17:09:15 --> Final output sent to browser
DEBUG - 2017-02-17 17:09:15 --> Total execution time: 0.9011
INFO - 2017-02-17 17:09:41 --> Config Class Initialized
INFO - 2017-02-17 17:09:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:09:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:09:41 --> Utf8 Class Initialized
INFO - 2017-02-17 17:09:41 --> URI Class Initialized
INFO - 2017-02-17 17:09:41 --> Router Class Initialized
INFO - 2017-02-17 17:09:41 --> Output Class Initialized
INFO - 2017-02-17 17:09:41 --> Security Class Initialized
DEBUG - 2017-02-17 17:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:09:41 --> Input Class Initialized
INFO - 2017-02-17 17:09:41 --> Language Class Initialized
INFO - 2017-02-17 17:09:41 --> Language Class Initialized
INFO - 2017-02-17 17:09:41 --> Config Class Initialized
INFO - 2017-02-17 17:09:41 --> Loader Class Initialized
INFO - 2017-02-17 17:09:41 --> Helper loaded: form_helper
INFO - 2017-02-17 17:09:41 --> Helper loaded: url_helper
INFO - 2017-02-17 17:09:41 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:09:41 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:09:41 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:09:41 --> Template Class Initialized
INFO - 2017-02-17 17:09:41 --> Controller Class Initialized
DEBUG - 2017-02-17 17:09:41 --> Signup MX_Controller Initialized
INFO - 2017-02-17 17:09:41 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:09:41 --> Model Class Initialized
INFO - 2017-02-17 17:09:41 --> Form Validation Class Initialized
DEBUG - 2017-02-17 17:09:41 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/signup.php
INFO - 2017-02-17 17:09:41 --> Final output sent to browser
DEBUG - 2017-02-17 17:09:41 --> Total execution time: 0.0591
INFO - 2017-02-17 17:16:28 --> Config Class Initialized
INFO - 2017-02-17 17:16:28 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:16:28 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:16:28 --> Utf8 Class Initialized
INFO - 2017-02-17 17:16:28 --> URI Class Initialized
INFO - 2017-02-17 17:16:28 --> Router Class Initialized
INFO - 2017-02-17 17:16:28 --> Output Class Initialized
INFO - 2017-02-17 17:16:28 --> Security Class Initialized
DEBUG - 2017-02-17 17:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:16:28 --> Input Class Initialized
INFO - 2017-02-17 17:16:28 --> Language Class Initialized
INFO - 2017-02-17 17:16:28 --> Language Class Initialized
INFO - 2017-02-17 17:16:28 --> Config Class Initialized
INFO - 2017-02-17 17:16:28 --> Loader Class Initialized
INFO - 2017-02-17 17:16:28 --> Helper loaded: form_helper
INFO - 2017-02-17 17:16:28 --> Helper loaded: url_helper
INFO - 2017-02-17 17:16:28 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:16:28 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:16:29 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:16:29 --> Template Class Initialized
INFO - 2017-02-17 17:16:29 --> Controller Class Initialized
DEBUG - 2017-02-17 17:16:29 --> Signup MX_Controller Initialized
INFO - 2017-02-17 17:16:29 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:16:29 --> Model Class Initialized
INFO - 2017-02-17 17:16:29 --> Form Validation Class Initialized
DEBUG - 2017-02-17 17:16:29 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/signup.php
INFO - 2017-02-17 17:16:29 --> Final output sent to browser
DEBUG - 2017-02-17 17:16:29 --> Total execution time: 1.5047
INFO - 2017-02-17 17:21:41 --> Config Class Initialized
INFO - 2017-02-17 17:21:41 --> Hooks Class Initialized
DEBUG - 2017-02-17 17:21:41 --> UTF-8 Support Enabled
INFO - 2017-02-17 17:21:41 --> Utf8 Class Initialized
INFO - 2017-02-17 17:21:41 --> URI Class Initialized
INFO - 2017-02-17 17:21:42 --> Router Class Initialized
INFO - 2017-02-17 17:21:42 --> Output Class Initialized
INFO - 2017-02-17 17:21:42 --> Security Class Initialized
DEBUG - 2017-02-17 17:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 17:21:42 --> Input Class Initialized
INFO - 2017-02-17 17:21:42 --> Language Class Initialized
INFO - 2017-02-17 17:21:42 --> Language Class Initialized
INFO - 2017-02-17 17:21:42 --> Config Class Initialized
INFO - 2017-02-17 17:21:42 --> Loader Class Initialized
INFO - 2017-02-17 17:21:42 --> Helper loaded: form_helper
INFO - 2017-02-17 17:21:42 --> Helper loaded: url_helper
INFO - 2017-02-17 17:21:42 --> Helper loaded: utility_helper
INFO - 2017-02-17 17:21:42 --> Database Driver Class Initialized
DEBUG - 2017-02-17 17:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-17 17:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 17:21:42 --> User Agent Class Initialized
DEBUG - 2017-02-17 17:21:42 --> Template Class Initialized
INFO - 2017-02-17 17:21:42 --> Controller Class Initialized
DEBUG - 2017-02-17 17:21:42 --> Login MX_Controller Initialized
INFO - 2017-02-17 17:21:42 --> Helper loaded: cookie_helper
INFO - 2017-02-17 17:21:42 --> Model Class Initialized
INFO - 2017-02-17 17:21:43 --> Form Validation Class Initialized
DEBUG - 2017-02-17 17:21:43 --> File loaded: C:\xampp\htdocs\RazorClean\application\modules/frontend/views/login.php
INFO - 2017-02-17 17:21:43 --> Final output sent to browser
DEBUG - 2017-02-17 17:21:43 --> Total execution time: 1.4606
