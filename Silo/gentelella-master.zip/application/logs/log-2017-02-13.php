<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-13 12:27:40 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-13 12:27:40 --> Config Class Initialized
INFO - 2017-02-13 12:27:40 --> Hooks Class Initialized
INFO - 2017-02-13 12:27:40 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:27:41 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:27:41 --> Utf8 Class Initialized
DEBUG - 2017-02-13 12:27:42 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:27:42 --> Utf8 Class Initialized
INFO - 2017-02-13 12:27:42 --> URI Class Initialized
INFO - 2017-02-13 12:27:42 --> URI Class Initialized
INFO - 2017-02-13 12:27:43 --> Router Class Initialized
INFO - 2017-02-13 12:27:44 --> Router Class Initialized
INFO - 2017-02-13 12:27:45 --> Output Class Initialized
INFO - 2017-02-13 12:27:45 --> Output Class Initialized
INFO - 2017-02-13 12:27:46 --> Config Class Initialized
INFO - 2017-02-13 12:27:46 --> Hooks Class Initialized
INFO - 2017-02-13 12:27:46 --> Config Class Initialized
INFO - 2017-02-13 12:27:46 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:27:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:27:46 --> Utf8 Class Initialized
INFO - 2017-02-13 12:27:46 --> URI Class Initialized
DEBUG - 2017-02-13 12:27:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:27:47 --> Utf8 Class Initialized
INFO - 2017-02-13 12:27:47 --> Security Class Initialized
INFO - 2017-02-13 12:27:47 --> Security Class Initialized
INFO - 2017-02-13 12:27:47 --> Router Class Initialized
INFO - 2017-02-13 12:27:47 --> Output Class Initialized
INFO - 2017-02-13 12:27:47 --> Security Class Initialized
INFO - 2017-02-13 12:27:48 --> URI Class Initialized
INFO - 2017-02-13 12:27:48 --> Config Class Initialized
INFO - 2017-02-13 12:27:48 --> Hooks Class Initialized
INFO - 2017-02-13 12:27:48 --> Config Class Initialized
INFO - 2017-02-13 12:27:48 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:27:48 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:27:48 --> Utf8 Class Initialized
INFO - 2017-02-13 12:27:48 --> URI Class Initialized
DEBUG - 2017-02-13 12:27:48 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:27:48 --> Utf8 Class Initialized
INFO - 2017-02-13 12:27:48 --> URI Class Initialized
INFO - 2017-02-13 12:27:48 --> Router Class Initialized
INFO - 2017-02-13 12:27:48 --> Output Class Initialized
INFO - 2017-02-13 12:27:48 --> Router Class Initialized
INFO - 2017-02-13 12:27:48 --> Security Class Initialized
INFO - 2017-02-13 12:27:48 --> Output Class Initialized
INFO - 2017-02-13 12:27:48 --> Security Class Initialized
INFO - 2017-02-13 12:27:48 --> Router Class Initialized
INFO - 2017-02-13 12:27:48 --> Output Class Initialized
INFO - 2017-02-13 12:27:48 --> Security Class Initialized
DEBUG - 2017-02-13 12:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-13 12:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:27:49 --> Input Class Initialized
INFO - 2017-02-13 12:27:49 --> Input Class Initialized
INFO - 2017-02-13 12:27:49 --> Language Class Initialized
INFO - 2017-02-13 12:27:49 --> Language Class Initialized
DEBUG - 2017-02-13 12:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:27:49 --> Input Class Initialized
INFO - 2017-02-13 12:27:49 --> Language Class Initialized
DEBUG - 2017-02-13 12:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:27:49 --> Input Class Initialized
INFO - 2017-02-13 12:27:49 --> Language Class Initialized
DEBUG - 2017-02-13 12:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:27:49 --> Input Class Initialized
INFO - 2017-02-13 12:27:49 --> Language Class Initialized
ERROR - 2017-02-13 12:27:49 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:27:49 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:27:49 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:27:49 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:27:49 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:27:49 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\mobile\system\core\Input.php 564
INFO - 2017-02-13 12:27:49 --> Config Class Initialized
INFO - 2017-02-13 12:27:49 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:27:50 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:27:50 --> Utf8 Class Initialized
INFO - 2017-02-13 12:27:50 --> URI Class Initialized
INFO - 2017-02-13 12:27:50 --> Config Class Initialized
INFO - 2017-02-13 12:27:50 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:27:50 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:27:50 --> Utf8 Class Initialized
INFO - 2017-02-13 12:27:50 --> URI Class Initialized
INFO - 2017-02-13 12:27:50 --> Router Class Initialized
INFO - 2017-02-13 12:27:50 --> Output Class Initialized
INFO - 2017-02-13 12:27:50 --> Security Class Initialized
DEBUG - 2017-02-13 12:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:27:50 --> Input Class Initialized
INFO - 2017-02-13 12:27:50 --> Language Class Initialized
INFO - 2017-02-13 12:27:50 --> Config Class Initialized
ERROR - 2017-02-13 12:27:50 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:27:50 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:27:50 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:27:50 --> Utf8 Class Initialized
INFO - 2017-02-13 12:27:50 --> URI Class Initialized
INFO - 2017-02-13 12:27:50 --> Router Class Initialized
INFO - 2017-02-13 12:27:50 --> Output Class Initialized
INFO - 2017-02-13 12:27:50 --> Security Class Initialized
DEBUG - 2017-02-13 12:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:27:50 --> Input Class Initialized
INFO - 2017-02-13 12:27:50 --> Language Class Initialized
ERROR - 2017-02-13 12:27:50 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:27:51 --> Router Class Initialized
INFO - 2017-02-13 12:27:51 --> Output Class Initialized
INFO - 2017-02-13 12:27:51 --> Security Class Initialized
DEBUG - 2017-02-13 12:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:27:51 --> Input Class Initialized
INFO - 2017-02-13 12:27:51 --> Language Class Initialized
ERROR - 2017-02-13 12:27:51 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:27:51 --> Config Class Initialized
INFO - 2017-02-13 12:27:51 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:27:52 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:27:52 --> Utf8 Class Initialized
INFO - 2017-02-13 12:27:52 --> URI Class Initialized
INFO - 2017-02-13 12:27:52 --> Router Class Initialized
INFO - 2017-02-13 12:27:52 --> Output Class Initialized
INFO - 2017-02-13 12:27:52 --> Security Class Initialized
DEBUG - 2017-02-13 12:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:27:52 --> Input Class Initialized
INFO - 2017-02-13 12:27:52 --> Language Class Initialized
ERROR - 2017-02-13 12:27:52 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:27:52 --> Config Class Initialized
INFO - 2017-02-13 12:27:52 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:27:52 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:27:52 --> Utf8 Class Initialized
INFO - 2017-02-13 12:27:52 --> URI Class Initialized
INFO - 2017-02-13 12:27:52 --> Router Class Initialized
INFO - 2017-02-13 12:27:52 --> Output Class Initialized
INFO - 2017-02-13 12:27:52 --> Security Class Initialized
DEBUG - 2017-02-13 12:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:27:52 --> Input Class Initialized
INFO - 2017-02-13 12:27:52 --> Language Class Initialized
ERROR - 2017-02-13 12:27:52 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:27:52 --> Config Class Initialized
INFO - 2017-02-13 12:27:52 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:27:52 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:27:52 --> Utf8 Class Initialized
INFO - 2017-02-13 12:27:52 --> URI Class Initialized
INFO - 2017-02-13 12:27:52 --> Router Class Initialized
INFO - 2017-02-13 12:27:52 --> Output Class Initialized
INFO - 2017-02-13 12:27:52 --> Security Class Initialized
DEBUG - 2017-02-13 12:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:27:52 --> Input Class Initialized
INFO - 2017-02-13 12:27:52 --> Language Class Initialized
ERROR - 2017-02-13 12:27:52 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:27:52 --> Config Class Initialized
INFO - 2017-02-13 12:27:52 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:27:52 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:27:52 --> Utf8 Class Initialized
INFO - 2017-02-13 12:27:52 --> URI Class Initialized
INFO - 2017-02-13 12:27:52 --> Router Class Initialized
INFO - 2017-02-13 12:27:52 --> Output Class Initialized
INFO - 2017-02-13 12:27:52 --> Security Class Initialized
DEBUG - 2017-02-13 12:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:27:52 --> Input Class Initialized
INFO - 2017-02-13 12:27:52 --> Language Class Initialized
ERROR - 2017-02-13 12:27:52 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:07 --> Config Class Initialized
INFO - 2017-02-13 12:28:07 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:07 --> Config Class Initialized
INFO - 2017-02-13 12:28:07 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:07 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:07 --> URI Class Initialized
DEBUG - 2017-02-13 12:28:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:07 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:07 --> URI Class Initialized
INFO - 2017-02-13 12:28:07 --> Router Class Initialized
INFO - 2017-02-13 12:28:07 --> Router Class Initialized
INFO - 2017-02-13 12:28:07 --> Output Class Initialized
INFO - 2017-02-13 12:28:07 --> Output Class Initialized
INFO - 2017-02-13 12:28:07 --> Security Class Initialized
INFO - 2017-02-13 12:28:07 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:07 --> Input Class Initialized
INFO - 2017-02-13 12:28:07 --> Language Class Initialized
DEBUG - 2017-02-13 12:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:07 --> Input Class Initialized
INFO - 2017-02-13 12:28:07 --> Language Class Initialized
ERROR - 2017-02-13 12:28:07 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:28:07 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:07 --> Config Class Initialized
INFO - 2017-02-13 12:28:07 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:07 --> Config Class Initialized
INFO - 2017-02-13 12:28:07 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:07 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:07 --> URI Class Initialized
INFO - 2017-02-13 12:28:07 --> Router Class Initialized
INFO - 2017-02-13 12:28:07 --> Output Class Initialized
INFO - 2017-02-13 12:28:07 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:07 --> Input Class Initialized
INFO - 2017-02-13 12:28:07 --> Language Class Initialized
ERROR - 2017-02-13 12:28:07 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:07 --> Config Class Initialized
INFO - 2017-02-13 12:28:07 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:07 --> Config Class Initialized
INFO - 2017-02-13 12:28:07 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:07 --> Config Class Initialized
INFO - 2017-02-13 12:28:07 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:07 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:07 --> URI Class Initialized
DEBUG - 2017-02-13 12:28:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:07 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:07 --> URI Class Initialized
INFO - 2017-02-13 12:28:07 --> Router Class Initialized
INFO - 2017-02-13 12:28:07 --> Output Class Initialized
INFO - 2017-02-13 12:28:07 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:07 --> Input Class Initialized
INFO - 2017-02-13 12:28:07 --> Language Class Initialized
ERROR - 2017-02-13 12:28:07 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:28:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:07 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:07 --> URI Class Initialized
INFO - 2017-02-13 12:28:07 --> Router Class Initialized
INFO - 2017-02-13 12:28:07 --> Router Class Initialized
INFO - 2017-02-13 12:28:07 --> Output Class Initialized
INFO - 2017-02-13 12:28:07 --> Output Class Initialized
INFO - 2017-02-13 12:28:07 --> Security Class Initialized
INFO - 2017-02-13 12:28:07 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:07 --> Input Class Initialized
DEBUG - 2017-02-13 12:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:07 --> Input Class Initialized
INFO - 2017-02-13 12:28:07 --> Language Class Initialized
INFO - 2017-02-13 12:28:07 --> Language Class Initialized
ERROR - 2017-02-13 12:28:07 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:28:07 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:07 --> Config Class Initialized
INFO - 2017-02-13 12:28:07 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:07 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:07 --> URI Class Initialized
DEBUG - 2017-02-13 12:28:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:07 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:07 --> URI Class Initialized
INFO - 2017-02-13 12:28:07 --> Router Class Initialized
INFO - 2017-02-13 12:28:07 --> Output Class Initialized
INFO - 2017-02-13 12:28:07 --> Router Class Initialized
INFO - 2017-02-13 12:28:07 --> Security Class Initialized
INFO - 2017-02-13 12:28:07 --> Output Class Initialized
DEBUG - 2017-02-13 12:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:07 --> Input Class Initialized
INFO - 2017-02-13 12:28:07 --> Security Class Initialized
INFO - 2017-02-13 12:28:07 --> Language Class Initialized
DEBUG - 2017-02-13 12:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-13 12:28:07 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:07 --> Input Class Initialized
INFO - 2017-02-13 12:28:07 --> Language Class Initialized
ERROR - 2017-02-13 12:28:07 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:07 --> Config Class Initialized
INFO - 2017-02-13 12:28:07 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:07 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:07 --> URI Class Initialized
INFO - 2017-02-13 12:28:07 --> Router Class Initialized
INFO - 2017-02-13 12:28:07 --> Output Class Initialized
INFO - 2017-02-13 12:28:07 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:07 --> Input Class Initialized
INFO - 2017-02-13 12:28:07 --> Language Class Initialized
ERROR - 2017-02-13 12:28:07 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:07 --> Config Class Initialized
INFO - 2017-02-13 12:28:07 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:07 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:07 --> URI Class Initialized
INFO - 2017-02-13 12:28:07 --> Router Class Initialized
INFO - 2017-02-13 12:28:07 --> Output Class Initialized
INFO - 2017-02-13 12:28:07 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:07 --> Input Class Initialized
INFO - 2017-02-13 12:28:07 --> Language Class Initialized
ERROR - 2017-02-13 12:28:07 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:07 --> Config Class Initialized
INFO - 2017-02-13 12:28:07 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:07 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:07 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:07 --> URI Class Initialized
INFO - 2017-02-13 12:28:07 --> Router Class Initialized
INFO - 2017-02-13 12:28:07 --> Output Class Initialized
INFO - 2017-02-13 12:28:07 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:07 --> Input Class Initialized
INFO - 2017-02-13 12:28:07 --> Language Class Initialized
ERROR - 2017-02-13 12:28:07 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:28 --> Config Class Initialized
INFO - 2017-02-13 12:28:28 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:28 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:28 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:28 --> URI Class Initialized
INFO - 2017-02-13 12:28:28 --> Router Class Initialized
INFO - 2017-02-13 12:28:28 --> Output Class Initialized
INFO - 2017-02-13 12:28:28 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:28 --> Input Class Initialized
INFO - 2017-02-13 12:28:28 --> Language Class Initialized
ERROR - 2017-02-13 12:28:28 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:28 --> Config Class Initialized
INFO - 2017-02-13 12:28:28 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:28 --> Config Class Initialized
INFO - 2017-02-13 12:28:28 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:28 --> Config Class Initialized
DEBUG - 2017-02-13 12:28:28 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:28 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:28 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:28 --> URI Class Initialized
INFO - 2017-02-13 12:28:28 --> Config Class Initialized
DEBUG - 2017-02-13 12:28:28 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:28 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:28 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:28 --> URI Class Initialized
INFO - 2017-02-13 12:28:28 --> Router Class Initialized
INFO - 2017-02-13 12:28:28 --> Output Class Initialized
INFO - 2017-02-13 12:28:28 --> Router Class Initialized
INFO - 2017-02-13 12:28:28 --> Security Class Initialized
INFO - 2017-02-13 12:28:28 --> Output Class Initialized
DEBUG - 2017-02-13 12:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:28 --> Config Class Initialized
INFO - 2017-02-13 12:28:28 --> Input Class Initialized
INFO - 2017-02-13 12:28:28 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:28 --> Security Class Initialized
INFO - 2017-02-13 12:28:28 --> Language Class Initialized
DEBUG - 2017-02-13 12:28:28 --> UTF-8 Support Enabled
ERROR - 2017-02-13 12:28:28 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:28 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:28 --> URI Class Initialized
DEBUG - 2017-02-13 12:28:28 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:28 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:28 --> URI Class Initialized
INFO - 2017-02-13 12:28:28 --> Router Class Initialized
INFO - 2017-02-13 12:28:28 --> Output Class Initialized
INFO - 2017-02-13 12:28:28 --> Router Class Initialized
INFO - 2017-02-13 12:28:28 --> Security Class Initialized
INFO - 2017-02-13 12:28:28 --> Output Class Initialized
DEBUG - 2017-02-13 12:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:28 --> Input Class Initialized
INFO - 2017-02-13 12:28:28 --> Language Class Initialized
INFO - 2017-02-13 12:28:28 --> Security Class Initialized
ERROR - 2017-02-13 12:28:28 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:28 --> Input Class Initialized
INFO - 2017-02-13 12:28:28 --> Language Class Initialized
ERROR - 2017-02-13 12:28:28 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:28 --> Config Class Initialized
INFO - 2017-02-13 12:28:28 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:28 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:28 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:28 --> URI Class Initialized
INFO - 2017-02-13 12:28:28 --> Router Class Initialized
INFO - 2017-02-13 12:28:28 --> Output Class Initialized
INFO - 2017-02-13 12:28:28 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:28 --> Input Class Initialized
INFO - 2017-02-13 12:28:28 --> Language Class Initialized
DEBUG - 2017-02-13 12:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-13 12:28:28 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:28 --> Input Class Initialized
INFO - 2017-02-13 12:28:28 --> Utf8 Class Initialized
ERROR - 2017-02-13 12:28:28 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:28 --> Language Class Initialized
INFO - 2017-02-13 12:28:28 --> URI Class Initialized
ERROR - 2017-02-13 12:28:28 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:28 --> Router Class Initialized
INFO - 2017-02-13 12:28:28 --> Output Class Initialized
INFO - 2017-02-13 12:28:28 --> Config Class Initialized
INFO - 2017-02-13 12:28:28 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:28 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:28 --> Input Class Initialized
DEBUG - 2017-02-13 12:28:28 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:28 --> Language Class Initialized
INFO - 2017-02-13 12:28:28 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:28 --> URI Class Initialized
ERROR - 2017-02-13 12:28:28 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:28 --> Router Class Initialized
INFO - 2017-02-13 12:28:28 --> Output Class Initialized
INFO - 2017-02-13 12:28:28 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:28 --> Input Class Initialized
INFO - 2017-02-13 12:28:28 --> Language Class Initialized
ERROR - 2017-02-13 12:28:28 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:29 --> Config Class Initialized
INFO - 2017-02-13 12:28:29 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:29 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:29 --> URI Class Initialized
INFO - 2017-02-13 12:28:29 --> Router Class Initialized
INFO - 2017-02-13 12:28:29 --> Output Class Initialized
INFO - 2017-02-13 12:28:29 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:29 --> Input Class Initialized
INFO - 2017-02-13 12:28:29 --> Language Class Initialized
ERROR - 2017-02-13 12:28:29 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:29 --> Config Class Initialized
INFO - 2017-02-13 12:28:29 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:29 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:29 --> URI Class Initialized
INFO - 2017-02-13 12:28:29 --> Router Class Initialized
INFO - 2017-02-13 12:28:29 --> Output Class Initialized
INFO - 2017-02-13 12:28:29 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:29 --> Input Class Initialized
INFO - 2017-02-13 12:28:29 --> Language Class Initialized
ERROR - 2017-02-13 12:28:29 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:29 --> Config Class Initialized
INFO - 2017-02-13 12:28:29 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:29 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:29 --> URI Class Initialized
INFO - 2017-02-13 12:28:29 --> Router Class Initialized
INFO - 2017-02-13 12:28:29 --> Output Class Initialized
INFO - 2017-02-13 12:28:29 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:29 --> Input Class Initialized
INFO - 2017-02-13 12:28:29 --> Language Class Initialized
ERROR - 2017-02-13 12:28:29 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:29 --> Config Class Initialized
INFO - 2017-02-13 12:28:29 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:29 --> Config Class Initialized
INFO - 2017-02-13 12:28:29 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:29 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:29 --> URI Class Initialized
INFO - 2017-02-13 12:28:29 --> Config Class Initialized
INFO - 2017-02-13 12:28:29 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:29 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:29 --> URI Class Initialized
DEBUG - 2017-02-13 12:28:29 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:29 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:29 --> URI Class Initialized
INFO - 2017-02-13 12:28:29 --> Router Class Initialized
INFO - 2017-02-13 12:28:29 --> Output Class Initialized
INFO - 2017-02-13 12:28:30 --> Router Class Initialized
INFO - 2017-02-13 12:28:30 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:30 --> Output Class Initialized
INFO - 2017-02-13 12:28:30 --> Input Class Initialized
INFO - 2017-02-13 12:28:30 --> Language Class Initialized
INFO - 2017-02-13 12:28:30 --> Security Class Initialized
ERROR - 2017-02-13 12:28:30 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:30 --> Input Class Initialized
INFO - 2017-02-13 12:28:30 --> Language Class Initialized
INFO - 2017-02-13 12:28:30 --> Router Class Initialized
ERROR - 2017-02-13 12:28:30 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:30 --> Output Class Initialized
INFO - 2017-02-13 12:28:30 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:30 --> Input Class Initialized
INFO - 2017-02-13 12:28:30 --> Config Class Initialized
INFO - 2017-02-13 12:28:30 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:30 --> Language Class Initialized
ERROR - 2017-02-13 12:28:30 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:28:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:30 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:30 --> URI Class Initialized
INFO - 2017-02-13 12:28:30 --> Config Class Initialized
INFO - 2017-02-13 12:28:30 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:30 --> Router Class Initialized
INFO - 2017-02-13 12:28:30 --> Config Class Initialized
INFO - 2017-02-13 12:28:30 --> Output Class Initialized
INFO - 2017-02-13 12:28:30 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:30 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:30 --> Input Class Initialized
DEBUG - 2017-02-13 12:28:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:30 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:30 --> Language Class Initialized
INFO - 2017-02-13 12:28:30 --> URI Class Initialized
ERROR - 2017-02-13 12:28:30 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:30 --> Router Class Initialized
DEBUG - 2017-02-13 12:28:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:30 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:30 --> URI Class Initialized
INFO - 2017-02-13 12:28:30 --> Output Class Initialized
INFO - 2017-02-13 12:28:30 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:30 --> Router Class Initialized
INFO - 2017-02-13 12:28:30 --> Input Class Initialized
INFO - 2017-02-13 12:28:30 --> Language Class Initialized
INFO - 2017-02-13 12:28:30 --> Output Class Initialized
ERROR - 2017-02-13 12:28:30 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:30 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:30 --> Input Class Initialized
INFO - 2017-02-13 12:28:30 --> Language Class Initialized
ERROR - 2017-02-13 12:28:30 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:30 --> Config Class Initialized
INFO - 2017-02-13 12:28:30 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:30 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:30 --> URI Class Initialized
INFO - 2017-02-13 12:28:30 --> Config Class Initialized
INFO - 2017-02-13 12:28:30 --> Config Class Initialized
INFO - 2017-02-13 12:28:30 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:30 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:30 --> Router Class Initialized
DEBUG - 2017-02-13 12:28:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:30 --> Utf8 Class Initialized
DEBUG - 2017-02-13 12:28:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:30 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:30 --> Output Class Initialized
INFO - 2017-02-13 12:28:30 --> URI Class Initialized
INFO - 2017-02-13 12:28:30 --> URI Class Initialized
INFO - 2017-02-13 12:28:30 --> Security Class Initialized
INFO - 2017-02-13 12:28:30 --> Router Class Initialized
DEBUG - 2017-02-13 12:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:30 --> Input Class Initialized
INFO - 2017-02-13 12:28:30 --> Router Class Initialized
INFO - 2017-02-13 12:28:30 --> Language Class Initialized
INFO - 2017-02-13 12:28:30 --> Output Class Initialized
ERROR - 2017-02-13 12:28:30 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:30 --> Output Class Initialized
INFO - 2017-02-13 12:28:30 --> Security Class Initialized
INFO - 2017-02-13 12:28:30 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:30 --> Input Class Initialized
INFO - 2017-02-13 12:28:30 --> Language Class Initialized
DEBUG - 2017-02-13 12:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:30 --> Input Class Initialized
ERROR - 2017-02-13 12:28:30 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:30 --> Language Class Initialized
ERROR - 2017-02-13 12:28:30 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:30 --> Config Class Initialized
INFO - 2017-02-13 12:28:30 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:30 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:30 --> URI Class Initialized
INFO - 2017-02-13 12:28:30 --> Router Class Initialized
INFO - 2017-02-13 12:28:30 --> Output Class Initialized
INFO - 2017-02-13 12:28:30 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:30 --> Input Class Initialized
INFO - 2017-02-13 12:28:30 --> Language Class Initialized
ERROR - 2017-02-13 12:28:30 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:30 --> Config Class Initialized
INFO - 2017-02-13 12:28:30 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:30 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:30 --> URI Class Initialized
INFO - 2017-02-13 12:28:30 --> Router Class Initialized
INFO - 2017-02-13 12:28:30 --> Output Class Initialized
INFO - 2017-02-13 12:28:30 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:30 --> Input Class Initialized
INFO - 2017-02-13 12:28:30 --> Language Class Initialized
ERROR - 2017-02-13 12:28:30 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:30 --> Config Class Initialized
INFO - 2017-02-13 12:28:30 --> Config Class Initialized
INFO - 2017-02-13 12:28:30 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:30 --> Config Class Initialized
INFO - 2017-02-13 12:28:30 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:30 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:30 --> Utf8 Class Initialized
DEBUG - 2017-02-13 12:28:30 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 12:28:30 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:30 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:30 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:30 --> URI Class Initialized
INFO - 2017-02-13 12:28:30 --> URI Class Initialized
INFO - 2017-02-13 12:28:30 --> URI Class Initialized
INFO - 2017-02-13 12:28:30 --> Router Class Initialized
INFO - 2017-02-13 12:28:30 --> Router Class Initialized
INFO - 2017-02-13 12:28:30 --> Output Class Initialized
INFO - 2017-02-13 12:28:30 --> Router Class Initialized
INFO - 2017-02-13 12:28:30 --> Output Class Initialized
INFO - 2017-02-13 12:28:30 --> Security Class Initialized
INFO - 2017-02-13 12:28:30 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:30 --> Input Class Initialized
INFO - 2017-02-13 12:28:30 --> Output Class Initialized
DEBUG - 2017-02-13 12:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:30 --> Language Class Initialized
INFO - 2017-02-13 12:28:30 --> Input Class Initialized
INFO - 2017-02-13 12:28:31 --> Language Class Initialized
ERROR - 2017-02-13 12:28:31 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:28:31 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:31 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:31 --> Input Class Initialized
INFO - 2017-02-13 12:28:31 --> Language Class Initialized
ERROR - 2017-02-13 12:28:31 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:31 --> Config Class Initialized
INFO - 2017-02-13 12:28:31 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:31 --> Config Class Initialized
INFO - 2017-02-13 12:28:31 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:31 --> Utf8 Class Initialized
DEBUG - 2017-02-13 12:28:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:31 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:31 --> Config Class Initialized
INFO - 2017-02-13 12:28:31 --> URI Class Initialized
INFO - 2017-02-13 12:28:31 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:31 --> URI Class Initialized
DEBUG - 2017-02-13 12:28:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:31 --> Config Class Initialized
INFO - 2017-02-13 12:28:31 --> Router Class Initialized
INFO - 2017-02-13 12:28:31 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:31 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:31 --> URI Class Initialized
INFO - 2017-02-13 12:28:31 --> Output Class Initialized
INFO - 2017-02-13 12:28:31 --> Security Class Initialized
INFO - 2017-02-13 12:28:31 --> Router Class Initialized
DEBUG - 2017-02-13 12:28:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:31 --> Router Class Initialized
INFO - 2017-02-13 12:28:31 --> Utf8 Class Initialized
DEBUG - 2017-02-13 12:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:31 --> Input Class Initialized
INFO - 2017-02-13 12:28:31 --> Output Class Initialized
INFO - 2017-02-13 12:28:31 --> Language Class Initialized
INFO - 2017-02-13 12:28:31 --> URI Class Initialized
INFO - 2017-02-13 12:28:31 --> Security Class Initialized
INFO - 2017-02-13 12:28:31 --> Output Class Initialized
ERROR - 2017-02-13 12:28:31 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:31 --> Input Class Initialized
INFO - 2017-02-13 12:28:31 --> Security Class Initialized
INFO - 2017-02-13 12:28:31 --> Language Class Initialized
DEBUG - 2017-02-13 12:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:31 --> Router Class Initialized
ERROR - 2017-02-13 12:28:31 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:31 --> Input Class Initialized
INFO - 2017-02-13 12:28:31 --> Output Class Initialized
INFO - 2017-02-13 12:28:31 --> Language Class Initialized
INFO - 2017-02-13 12:28:31 --> Security Class Initialized
ERROR - 2017-02-13 12:28:31 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:31 --> Input Class Initialized
INFO - 2017-02-13 12:28:31 --> Language Class Initialized
INFO - 2017-02-13 12:28:31 --> Config Class Initialized
INFO - 2017-02-13 12:28:31 --> Hooks Class Initialized
ERROR - 2017-02-13 12:28:31 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:28:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:31 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:31 --> URI Class Initialized
INFO - 2017-02-13 12:28:31 --> Router Class Initialized
INFO - 2017-02-13 12:28:31 --> Output Class Initialized
INFO - 2017-02-13 12:28:31 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:31 --> Input Class Initialized
INFO - 2017-02-13 12:28:31 --> Language Class Initialized
ERROR - 2017-02-13 12:28:31 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:31 --> Config Class Initialized
INFO - 2017-02-13 12:28:31 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:31 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:31 --> URI Class Initialized
INFO - 2017-02-13 12:28:31 --> Router Class Initialized
INFO - 2017-02-13 12:28:31 --> Output Class Initialized
INFO - 2017-02-13 12:28:31 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:31 --> Input Class Initialized
INFO - 2017-02-13 12:28:31 --> Language Class Initialized
ERROR - 2017-02-13 12:28:31 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:31 --> Config Class Initialized
INFO - 2017-02-13 12:28:31 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:31 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:31 --> URI Class Initialized
INFO - 2017-02-13 12:28:31 --> Router Class Initialized
INFO - 2017-02-13 12:28:31 --> Output Class Initialized
INFO - 2017-02-13 12:28:31 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:31 --> Input Class Initialized
INFO - 2017-02-13 12:28:31 --> Language Class Initialized
ERROR - 2017-02-13 12:28:31 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:31 --> Config Class Initialized
INFO - 2017-02-13 12:28:31 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:31 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:31 --> URI Class Initialized
INFO - 2017-02-13 12:28:31 --> Router Class Initialized
INFO - 2017-02-13 12:28:31 --> Output Class Initialized
INFO - 2017-02-13 12:28:31 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:31 --> Input Class Initialized
INFO - 2017-02-13 12:28:31 --> Language Class Initialized
ERROR - 2017-02-13 12:28:31 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:31 --> Config Class Initialized
INFO - 2017-02-13 12:28:31 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:31 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:31 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:31 --> URI Class Initialized
INFO - 2017-02-13 12:28:31 --> Router Class Initialized
INFO - 2017-02-13 12:28:31 --> Output Class Initialized
INFO - 2017-02-13 12:28:31 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:31 --> Input Class Initialized
INFO - 2017-02-13 12:28:31 --> Language Class Initialized
ERROR - 2017-02-13 12:28:31 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:45 --> Config Class Initialized
INFO - 2017-02-13 12:28:45 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:45 --> Config Class Initialized
INFO - 2017-02-13 12:28:45 --> Config Class Initialized
INFO - 2017-02-13 12:28:45 --> Config Class Initialized
INFO - 2017-02-13 12:28:45 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:45 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:45 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:45 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 12:28:45 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:45 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:45 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:45 --> URI Class Initialized
INFO - 2017-02-13 12:28:45 --> URI Class Initialized
INFO - 2017-02-13 12:28:45 --> Router Class Initialized
INFO - 2017-02-13 12:28:45 --> Router Class Initialized
DEBUG - 2017-02-13 12:28:45 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:45 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:45 --> Output Class Initialized
INFO - 2017-02-13 12:28:45 --> URI Class Initialized
INFO - 2017-02-13 12:28:45 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:45 --> Input Class Initialized
INFO - 2017-02-13 12:28:45 --> Language Class Initialized
INFO - 2017-02-13 12:28:45 --> Router Class Initialized
INFO - 2017-02-13 12:28:45 --> Config Class Initialized
INFO - 2017-02-13 12:28:45 --> Hooks Class Initialized
ERROR - 2017-02-13 12:28:45 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:45 --> Output Class Initialized
INFO - 2017-02-13 12:28:45 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:45 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 12:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:45 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:45 --> Input Class Initialized
INFO - 2017-02-13 12:28:45 --> Language Class Initialized
INFO - 2017-02-13 12:28:45 --> URI Class Initialized
ERROR - 2017-02-13 12:28:45 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:45 --> Router Class Initialized
INFO - 2017-02-13 12:28:45 --> Config Class Initialized
INFO - 2017-02-13 12:28:45 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:45 --> Output Class Initialized
DEBUG - 2017-02-13 12:28:45 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:45 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:45 --> Security Class Initialized
INFO - 2017-02-13 12:28:45 --> URI Class Initialized
INFO - 2017-02-13 12:28:45 --> Output Class Initialized
INFO - 2017-02-13 12:28:45 --> Config Class Initialized
INFO - 2017-02-13 12:28:45 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:45 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:45 --> Input Class Initialized
INFO - 2017-02-13 12:28:45 --> Router Class Initialized
DEBUG - 2017-02-13 12:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:45 --> Input Class Initialized
DEBUG - 2017-02-13 12:28:45 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:45 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:45 --> Language Class Initialized
INFO - 2017-02-13 12:28:45 --> Language Class Initialized
INFO - 2017-02-13 12:28:45 --> Output Class Initialized
INFO - 2017-02-13 12:28:45 --> URI Class Initialized
ERROR - 2017-02-13 12:28:45 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:45 --> Security Class Initialized
ERROR - 2017-02-13 12:28:45 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:45 --> Input Class Initialized
INFO - 2017-02-13 12:28:45 --> Language Class Initialized
INFO - 2017-02-13 12:28:45 --> Router Class Initialized
ERROR - 2017-02-13 12:28:45 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:45 --> Output Class Initialized
DEBUG - 2017-02-13 12:28:45 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:45 --> Security Class Initialized
INFO - 2017-02-13 12:28:45 --> Utf8 Class Initialized
DEBUG - 2017-02-13 12:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:45 --> URI Class Initialized
INFO - 2017-02-13 12:28:45 --> Input Class Initialized
INFO - 2017-02-13 12:28:45 --> Config Class Initialized
INFO - 2017-02-13 12:28:45 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:45 --> Language Class Initialized
ERROR - 2017-02-13 12:28:45 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:45 --> Router Class Initialized
DEBUG - 2017-02-13 12:28:45 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:45 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:45 --> URI Class Initialized
INFO - 2017-02-13 12:28:45 --> Output Class Initialized
INFO - 2017-02-13 12:28:45 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:45 --> Router Class Initialized
INFO - 2017-02-13 12:28:45 --> Input Class Initialized
INFO - 2017-02-13 12:28:45 --> Language Class Initialized
INFO - 2017-02-13 12:28:45 --> Output Class Initialized
ERROR - 2017-02-13 12:28:45 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:45 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:45 --> Input Class Initialized
INFO - 2017-02-13 12:28:45 --> Language Class Initialized
ERROR - 2017-02-13 12:28:45 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:45 --> Config Class Initialized
INFO - 2017-02-13 12:28:45 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:45 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:45 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:45 --> URI Class Initialized
INFO - 2017-02-13 12:28:45 --> Router Class Initialized
INFO - 2017-02-13 12:28:45 --> Output Class Initialized
INFO - 2017-02-13 12:28:45 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:45 --> Input Class Initialized
INFO - 2017-02-13 12:28:45 --> Language Class Initialized
ERROR - 2017-02-13 12:28:45 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:45 --> Config Class Initialized
INFO - 2017-02-13 12:28:45 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:45 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:45 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:45 --> URI Class Initialized
INFO - 2017-02-13 12:28:45 --> Router Class Initialized
INFO - 2017-02-13 12:28:45 --> Output Class Initialized
INFO - 2017-02-13 12:28:45 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:45 --> Input Class Initialized
INFO - 2017-02-13 12:28:45 --> Language Class Initialized
ERROR - 2017-02-13 12:28:45 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:45 --> Config Class Initialized
INFO - 2017-02-13 12:28:45 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:45 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:45 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:45 --> URI Class Initialized
INFO - 2017-02-13 12:28:45 --> Router Class Initialized
INFO - 2017-02-13 12:28:45 --> Output Class Initialized
INFO - 2017-02-13 12:28:45 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:45 --> Input Class Initialized
INFO - 2017-02-13 12:28:45 --> Language Class Initialized
ERROR - 2017-02-13 12:28:45 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:45 --> Config Class Initialized
INFO - 2017-02-13 12:28:45 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:45 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:45 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:45 --> URI Class Initialized
INFO - 2017-02-13 12:28:45 --> Router Class Initialized
INFO - 2017-02-13 12:28:45 --> Output Class Initialized
INFO - 2017-02-13 12:28:45 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:45 --> Input Class Initialized
INFO - 2017-02-13 12:28:45 --> Language Class Initialized
ERROR - 2017-02-13 12:28:45 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:46 --> Config Class Initialized
INFO - 2017-02-13 12:28:46 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:46 --> Config Class Initialized
INFO - 2017-02-13 12:28:46 --> Config Class Initialized
INFO - 2017-02-13 12:28:46 --> Config Class Initialized
INFO - 2017-02-13 12:28:46 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:46 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:46 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:46 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 12:28:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:46 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:46 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:46 --> URI Class Initialized
INFO - 2017-02-13 12:28:46 --> URI Class Initialized
INFO - 2017-02-13 12:28:46 --> Router Class Initialized
INFO - 2017-02-13 12:28:46 --> Router Class Initialized
INFO - 2017-02-13 12:28:46 --> Output Class Initialized
INFO - 2017-02-13 12:28:46 --> Output Class Initialized
DEBUG - 2017-02-13 12:28:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:46 --> Security Class Initialized
INFO - 2017-02-13 12:28:46 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:46 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:46 --> URI Class Initialized
INFO - 2017-02-13 12:28:46 --> Input Class Initialized
DEBUG - 2017-02-13 12:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:46 --> Input Class Initialized
INFO - 2017-02-13 12:28:46 --> Language Class Initialized
INFO - 2017-02-13 12:28:46 --> Language Class Initialized
ERROR - 2017-02-13 12:28:46 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:28:46 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:28:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:46 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:46 --> URI Class Initialized
INFO - 2017-02-13 12:28:46 --> Config Class Initialized
INFO - 2017-02-13 12:28:46 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:46 --> Router Class Initialized
DEBUG - 2017-02-13 12:28:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:46 --> Output Class Initialized
INFO - 2017-02-13 12:28:46 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:46 --> Security Class Initialized
INFO - 2017-02-13 12:28:46 --> URI Class Initialized
INFO - 2017-02-13 12:28:46 --> Config Class Initialized
INFO - 2017-02-13 12:28:46 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:46 --> Config Class Initialized
INFO - 2017-02-13 12:28:46 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:46 --> Router Class Initialized
DEBUG - 2017-02-13 12:28:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:46 --> Config Class Initialized
INFO - 2017-02-13 12:28:46 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:46 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:46 --> Output Class Initialized
DEBUG - 2017-02-13 12:28:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:46 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:46 --> Security Class Initialized
INFO - 2017-02-13 12:28:46 --> Router Class Initialized
DEBUG - 2017-02-13 12:28:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:46 --> Utf8 Class Initialized
DEBUG - 2017-02-13 12:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:46 --> Input Class Initialized
INFO - 2017-02-13 12:28:46 --> Output Class Initialized
INFO - 2017-02-13 12:28:46 --> Language Class Initialized
INFO - 2017-02-13 12:28:46 --> URI Class Initialized
INFO - 2017-02-13 12:28:46 --> Security Class Initialized
ERROR - 2017-02-13 12:28:46 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:46 --> Input Class Initialized
INFO - 2017-02-13 12:28:46 --> Language Class Initialized
INFO - 2017-02-13 12:28:46 --> Router Class Initialized
ERROR - 2017-02-13 12:28:46 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:46 --> Output Class Initialized
INFO - 2017-02-13 12:28:46 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:46 --> Input Class Initialized
INFO - 2017-02-13 12:28:46 --> Language Class Initialized
ERROR - 2017-02-13 12:28:46 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:46 --> URI Class Initialized
INFO - 2017-02-13 12:28:46 --> URI Class Initialized
INFO - 2017-02-13 12:28:46 --> Router Class Initialized
INFO - 2017-02-13 12:28:46 --> Output Class Initialized
INFO - 2017-02-13 12:28:46 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:46 --> Input Class Initialized
INFO - 2017-02-13 12:28:46 --> Language Class Initialized
DEBUG - 2017-02-13 12:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:46 --> Input Class Initialized
INFO - 2017-02-13 12:28:46 --> Language Class Initialized
INFO - 2017-02-13 12:28:46 --> Router Class Initialized
ERROR - 2017-02-13 12:28:46 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:28:46 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:46 --> Output Class Initialized
INFO - 2017-02-13 12:28:46 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:46 --> Input Class Initialized
INFO - 2017-02-13 12:28:46 --> Language Class Initialized
ERROR - 2017-02-13 12:28:46 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:46 --> Config Class Initialized
INFO - 2017-02-13 12:28:46 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:46 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:46 --> URI Class Initialized
INFO - 2017-02-13 12:28:46 --> Router Class Initialized
INFO - 2017-02-13 12:28:46 --> Output Class Initialized
INFO - 2017-02-13 12:28:46 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:46 --> Input Class Initialized
INFO - 2017-02-13 12:28:46 --> Language Class Initialized
ERROR - 2017-02-13 12:28:46 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:46 --> Config Class Initialized
INFO - 2017-02-13 12:28:46 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:46 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:46 --> URI Class Initialized
INFO - 2017-02-13 12:28:46 --> Router Class Initialized
INFO - 2017-02-13 12:28:46 --> Output Class Initialized
INFO - 2017-02-13 12:28:46 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:46 --> Input Class Initialized
INFO - 2017-02-13 12:28:46 --> Language Class Initialized
ERROR - 2017-02-13 12:28:46 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:46 --> Config Class Initialized
INFO - 2017-02-13 12:28:46 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:46 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:46 --> URI Class Initialized
INFO - 2017-02-13 12:28:46 --> Router Class Initialized
INFO - 2017-02-13 12:28:46 --> Output Class Initialized
INFO - 2017-02-13 12:28:46 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:46 --> Input Class Initialized
INFO - 2017-02-13 12:28:46 --> Language Class Initialized
ERROR - 2017-02-13 12:28:46 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:46 --> Config Class Initialized
INFO - 2017-02-13 12:28:46 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:46 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:46 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:46 --> URI Class Initialized
INFO - 2017-02-13 12:28:46 --> Router Class Initialized
INFO - 2017-02-13 12:28:46 --> Output Class Initialized
INFO - 2017-02-13 12:28:46 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:46 --> Input Class Initialized
INFO - 2017-02-13 12:28:46 --> Language Class Initialized
ERROR - 2017-02-13 12:28:46 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:47 --> Config Class Initialized
INFO - 2017-02-13 12:28:47 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:47 --> Config Class Initialized
INFO - 2017-02-13 12:28:47 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:47 --> Utf8 Class Initialized
DEBUG - 2017-02-13 12:28:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:47 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:47 --> URI Class Initialized
INFO - 2017-02-13 12:28:47 --> URI Class Initialized
INFO - 2017-02-13 12:28:47 --> Router Class Initialized
INFO - 2017-02-13 12:28:47 --> Router Class Initialized
INFO - 2017-02-13 12:28:47 --> Output Class Initialized
INFO - 2017-02-13 12:28:47 --> Output Class Initialized
INFO - 2017-02-13 12:28:47 --> Config Class Initialized
INFO - 2017-02-13 12:28:47 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:47 --> Security Class Initialized
INFO - 2017-02-13 12:28:47 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:47 --> Input Class Initialized
DEBUG - 2017-02-13 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:47 --> Input Class Initialized
INFO - 2017-02-13 12:28:47 --> Language Class Initialized
INFO - 2017-02-13 12:28:47 --> Language Class Initialized
DEBUG - 2017-02-13 12:28:47 --> UTF-8 Support Enabled
ERROR - 2017-02-13 12:28:47 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:28:47 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:47 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:47 --> URI Class Initialized
INFO - 2017-02-13 12:28:47 --> Router Class Initialized
INFO - 2017-02-13 12:28:47 --> Config Class Initialized
INFO - 2017-02-13 12:28:47 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:47 --> Output Class Initialized
DEBUG - 2017-02-13 12:28:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:47 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:47 --> Config Class Initialized
INFO - 2017-02-13 12:28:47 --> URI Class Initialized
INFO - 2017-02-13 12:28:47 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:47 --> Security Class Initialized
INFO - 2017-02-13 12:28:47 --> Config Class Initialized
INFO - 2017-02-13 12:28:47 --> Hooks Class Initialized
INFO - 2017-02-13 12:28:47 --> Router Class Initialized
DEBUG - 2017-02-13 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:47 --> Input Class Initialized
INFO - 2017-02-13 12:28:47 --> Language Class Initialized
INFO - 2017-02-13 12:28:47 --> Output Class Initialized
INFO - 2017-02-13 12:28:47 --> Config Class Initialized
INFO - 2017-02-13 12:28:47 --> Hooks Class Initialized
ERROR - 2017-02-13 12:28:47 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:47 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:47 --> Input Class Initialized
INFO - 2017-02-13 12:28:47 --> Language Class Initialized
DEBUG - 2017-02-13 12:28:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:47 --> Utf8 Class Initialized
DEBUG - 2017-02-13 12:28:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:47 --> Utf8 Class Initialized
ERROR - 2017-02-13 12:28:47 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:47 --> URI Class Initialized
INFO - 2017-02-13 12:28:47 --> URI Class Initialized
INFO - 2017-02-13 12:28:47 --> Router Class Initialized
INFO - 2017-02-13 12:28:47 --> Router Class Initialized
INFO - 2017-02-13 12:28:47 --> Output Class Initialized
INFO - 2017-02-13 12:28:47 --> Output Class Initialized
INFO - 2017-02-13 12:28:47 --> Security Class Initialized
INFO - 2017-02-13 12:28:47 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:47 --> Input Class Initialized
INFO - 2017-02-13 12:28:47 --> Language Class Initialized
DEBUG - 2017-02-13 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:47 --> Input Class Initialized
ERROR - 2017-02-13 12:28:47 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:47 --> Language Class Initialized
ERROR - 2017-02-13 12:28:47 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:47 --> Config Class Initialized
INFO - 2017-02-13 12:28:47 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:47 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:47 --> URI Class Initialized
INFO - 2017-02-13 12:28:47 --> Router Class Initialized
DEBUG - 2017-02-13 12:28:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:47 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:47 --> Output Class Initialized
INFO - 2017-02-13 12:28:47 --> URI Class Initialized
INFO - 2017-02-13 12:28:47 --> Security Class Initialized
INFO - 2017-02-13 12:28:47 --> Config Class Initialized
INFO - 2017-02-13 12:28:47 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:47 --> Input Class Initialized
INFO - 2017-02-13 12:28:47 --> Router Class Initialized
DEBUG - 2017-02-13 12:28:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:47 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:47 --> Output Class Initialized
INFO - 2017-02-13 12:28:47 --> Language Class Initialized
INFO - 2017-02-13 12:28:47 --> URI Class Initialized
INFO - 2017-02-13 12:28:47 --> Security Class Initialized
ERROR - 2017-02-13 12:28:47 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:47 --> Input Class Initialized
INFO - 2017-02-13 12:28:47 --> Language Class Initialized
INFO - 2017-02-13 12:28:47 --> Router Class Initialized
ERROR - 2017-02-13 12:28:47 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:47 --> Output Class Initialized
INFO - 2017-02-13 12:28:47 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:47 --> Input Class Initialized
INFO - 2017-02-13 12:28:47 --> Language Class Initialized
ERROR - 2017-02-13 12:28:47 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:47 --> Config Class Initialized
INFO - 2017-02-13 12:28:47 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:47 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:47 --> URI Class Initialized
INFO - 2017-02-13 12:28:47 --> Router Class Initialized
INFO - 2017-02-13 12:28:47 --> Output Class Initialized
INFO - 2017-02-13 12:28:47 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:47 --> Input Class Initialized
INFO - 2017-02-13 12:28:47 --> Language Class Initialized
ERROR - 2017-02-13 12:28:47 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:47 --> Config Class Initialized
INFO - 2017-02-13 12:28:47 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:47 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:47 --> URI Class Initialized
INFO - 2017-02-13 12:28:47 --> Router Class Initialized
INFO - 2017-02-13 12:28:47 --> Output Class Initialized
INFO - 2017-02-13 12:28:47 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:47 --> Input Class Initialized
INFO - 2017-02-13 12:28:47 --> Language Class Initialized
ERROR - 2017-02-13 12:28:47 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:28:47 --> Config Class Initialized
INFO - 2017-02-13 12:28:47 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:28:47 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:28:47 --> Utf8 Class Initialized
INFO - 2017-02-13 12:28:47 --> URI Class Initialized
INFO - 2017-02-13 12:28:47 --> Router Class Initialized
INFO - 2017-02-13 12:28:47 --> Output Class Initialized
INFO - 2017-02-13 12:28:47 --> Security Class Initialized
DEBUG - 2017-02-13 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:28:47 --> Input Class Initialized
INFO - 2017-02-13 12:28:47 --> Language Class Initialized
ERROR - 2017-02-13 12:28:47 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:15 --> Config Class Initialized
INFO - 2017-02-13 12:29:15 --> Config Class Initialized
INFO - 2017-02-13 12:29:15 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:15 --> Config Class Initialized
INFO - 2017-02-13 12:29:15 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:15 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:15 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 12:29:15 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:15 --> Utf8 Class Initialized
DEBUG - 2017-02-13 12:29:15 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:15 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:15 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:15 --> URI Class Initialized
INFO - 2017-02-13 12:29:15 --> URI Class Initialized
INFO - 2017-02-13 12:29:15 --> URI Class Initialized
INFO - 2017-02-13 12:29:15 --> Router Class Initialized
INFO - 2017-02-13 12:29:15 --> Router Class Initialized
INFO - 2017-02-13 12:29:15 --> Router Class Initialized
INFO - 2017-02-13 12:29:15 --> Config Class Initialized
INFO - 2017-02-13 12:29:15 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:15 --> Output Class Initialized
INFO - 2017-02-13 12:29:15 --> Output Class Initialized
INFO - 2017-02-13 12:29:15 --> Security Class Initialized
INFO - 2017-02-13 12:29:15 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:15 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 12:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-13 12:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:15 --> Input Class Initialized
INFO - 2017-02-13 12:29:15 --> Output Class Initialized
INFO - 2017-02-13 12:29:15 --> Language Class Initialized
INFO - 2017-02-13 12:29:15 --> Security Class Initialized
ERROR - 2017-02-13 12:29:15 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:15 --> Input Class Initialized
INFO - 2017-02-13 12:29:15 --> Language Class Initialized
ERROR - 2017-02-13 12:29:15 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:15 --> Config Class Initialized
INFO - 2017-02-13 12:29:15 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:15 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:15 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:15 --> URI Class Initialized
INFO - 2017-02-13 12:29:15 --> Config Class Initialized
INFO - 2017-02-13 12:29:15 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:15 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:15 --> Input Class Initialized
DEBUG - 2017-02-13 12:29:15 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:15 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:15 --> Language Class Initialized
INFO - 2017-02-13 12:29:15 --> URI Class Initialized
ERROR - 2017-02-13 12:29:15 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:15 --> Config Class Initialized
INFO - 2017-02-13 12:29:15 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:15 --> Config Class Initialized
INFO - 2017-02-13 12:29:15 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:15 --> Router Class Initialized
DEBUG - 2017-02-13 12:29:15 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:15 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:15 --> URI Class Initialized
INFO - 2017-02-13 12:29:15 --> Output Class Initialized
DEBUG - 2017-02-13 12:29:15 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:15 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:15 --> Security Class Initialized
INFO - 2017-02-13 12:29:15 --> URI Class Initialized
INFO - 2017-02-13 12:29:15 --> Router Class Initialized
DEBUG - 2017-02-13 12:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:15 --> Input Class Initialized
INFO - 2017-02-13 12:29:15 --> Language Class Initialized
INFO - 2017-02-13 12:29:15 --> Output Class Initialized
ERROR - 2017-02-13 12:29:15 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:15 --> Router Class Initialized
INFO - 2017-02-13 12:29:15 --> Security Class Initialized
INFO - 2017-02-13 12:29:15 --> Output Class Initialized
DEBUG - 2017-02-13 12:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:15 --> Input Class Initialized
INFO - 2017-02-13 12:29:15 --> URI Class Initialized
INFO - 2017-02-13 12:29:15 --> Language Class Initialized
INFO - 2017-02-13 12:29:15 --> Security Class Initialized
ERROR - 2017-02-13 12:29:15 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:15 --> Input Class Initialized
INFO - 2017-02-13 12:29:15 --> Language Class Initialized
INFO - 2017-02-13 12:29:15 --> Router Class Initialized
ERROR - 2017-02-13 12:29:15 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:15 --> Router Class Initialized
INFO - 2017-02-13 12:29:15 --> Output Class Initialized
INFO - 2017-02-13 12:29:15 --> Output Class Initialized
INFO - 2017-02-13 12:29:15 --> Security Class Initialized
INFO - 2017-02-13 12:29:15 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:15 --> Input Class Initialized
DEBUG - 2017-02-13 12:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:15 --> Language Class Initialized
INFO - 2017-02-13 12:29:15 --> Input Class Initialized
INFO - 2017-02-13 12:29:15 --> Language Class Initialized
ERROR - 2017-02-13 12:29:15 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:29:15 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:15 --> Config Class Initialized
INFO - 2017-02-13 12:29:15 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:15 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:15 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:15 --> URI Class Initialized
INFO - 2017-02-13 12:29:15 --> Router Class Initialized
INFO - 2017-02-13 12:29:15 --> Output Class Initialized
INFO - 2017-02-13 12:29:15 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:15 --> Input Class Initialized
INFO - 2017-02-13 12:29:15 --> Language Class Initialized
ERROR - 2017-02-13 12:29:15 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:15 --> Config Class Initialized
INFO - 2017-02-13 12:29:15 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:15 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:15 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:15 --> URI Class Initialized
INFO - 2017-02-13 12:29:15 --> Router Class Initialized
INFO - 2017-02-13 12:29:15 --> Output Class Initialized
INFO - 2017-02-13 12:29:15 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:15 --> Input Class Initialized
INFO - 2017-02-13 12:29:15 --> Language Class Initialized
ERROR - 2017-02-13 12:29:15 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:15 --> Config Class Initialized
INFO - 2017-02-13 12:29:15 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:15 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:15 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:15 --> URI Class Initialized
INFO - 2017-02-13 12:29:15 --> Router Class Initialized
INFO - 2017-02-13 12:29:15 --> Output Class Initialized
INFO - 2017-02-13 12:29:15 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:15 --> Input Class Initialized
INFO - 2017-02-13 12:29:15 --> Language Class Initialized
ERROR - 2017-02-13 12:29:15 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:15 --> Config Class Initialized
INFO - 2017-02-13 12:29:15 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:15 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:15 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:15 --> URI Class Initialized
INFO - 2017-02-13 12:29:15 --> Router Class Initialized
INFO - 2017-02-13 12:29:15 --> Output Class Initialized
INFO - 2017-02-13 12:29:15 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:15 --> Input Class Initialized
INFO - 2017-02-13 12:29:15 --> Language Class Initialized
ERROR - 2017-02-13 12:29:15 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:16 --> Config Class Initialized
INFO - 2017-02-13 12:29:16 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:16 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:16 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:16 --> URI Class Initialized
INFO - 2017-02-13 12:29:16 --> Router Class Initialized
INFO - 2017-02-13 12:29:16 --> Output Class Initialized
INFO - 2017-02-13 12:29:16 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:16 --> Input Class Initialized
INFO - 2017-02-13 12:29:16 --> Language Class Initialized
ERROR - 2017-02-13 12:29:16 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:17 --> Config Class Initialized
INFO - 2017-02-13 12:29:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:17 --> URI Class Initialized
INFO - 2017-02-13 12:29:17 --> Router Class Initialized
INFO - 2017-02-13 12:29:17 --> Output Class Initialized
INFO - 2017-02-13 12:29:17 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:17 --> Input Class Initialized
INFO - 2017-02-13 12:29:17 --> Language Class Initialized
ERROR - 2017-02-13 12:29:17 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:18 --> Config Class Initialized
INFO - 2017-02-13 12:29:18 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:18 --> Config Class Initialized
INFO - 2017-02-13 12:29:18 --> Config Class Initialized
INFO - 2017-02-13 12:29:18 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:18 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:18 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 12:29:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:18 --> Utf8 Class Initialized
DEBUG - 2017-02-13 12:29:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:18 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:18 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:18 --> URI Class Initialized
INFO - 2017-02-13 12:29:18 --> URI Class Initialized
INFO - 2017-02-13 12:29:18 --> URI Class Initialized
INFO - 2017-02-13 12:29:18 --> Router Class Initialized
INFO - 2017-02-13 12:29:18 --> Router Class Initialized
INFO - 2017-02-13 12:29:18 --> Output Class Initialized
INFO - 2017-02-13 12:29:18 --> Output Class Initialized
INFO - 2017-02-13 12:29:18 --> Security Class Initialized
INFO - 2017-02-13 12:29:18 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:18 --> Input Class Initialized
DEBUG - 2017-02-13 12:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:18 --> Input Class Initialized
INFO - 2017-02-13 12:29:18 --> Language Class Initialized
INFO - 2017-02-13 12:29:18 --> Language Class Initialized
ERROR - 2017-02-13 12:29:18 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:29:18 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:18 --> Config Class Initialized
INFO - 2017-02-13 12:29:18 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:18 --> Router Class Initialized
INFO - 2017-02-13 12:29:18 --> Config Class Initialized
INFO - 2017-02-13 12:29:18 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:18 --> Output Class Initialized
DEBUG - 2017-02-13 12:29:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:18 --> Config Class Initialized
INFO - 2017-02-13 12:29:18 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:18 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:18 --> Security Class Initialized
INFO - 2017-02-13 12:29:18 --> URI Class Initialized
DEBUG - 2017-02-13 12:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:18 --> Input Class Initialized
INFO - 2017-02-13 12:29:18 --> Language Class Initialized
DEBUG - 2017-02-13 12:29:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:18 --> Utf8 Class Initialized
DEBUG - 2017-02-13 12:29:18 --> UTF-8 Support Enabled
ERROR - 2017-02-13 12:29:18 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:18 --> Router Class Initialized
INFO - 2017-02-13 12:29:18 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:18 --> URI Class Initialized
INFO - 2017-02-13 12:29:18 --> Output Class Initialized
INFO - 2017-02-13 12:29:18 --> URI Class Initialized
INFO - 2017-02-13 12:29:18 --> Security Class Initialized
INFO - 2017-02-13 12:29:18 --> Router Class Initialized
DEBUG - 2017-02-13 12:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:18 --> Input Class Initialized
INFO - 2017-02-13 12:29:18 --> Language Class Initialized
INFO - 2017-02-13 12:29:18 --> Router Class Initialized
INFO - 2017-02-13 12:29:18 --> Output Class Initialized
ERROR - 2017-02-13 12:29:18 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:18 --> Security Class Initialized
INFO - 2017-02-13 12:29:18 --> Output Class Initialized
DEBUG - 2017-02-13 12:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:18 --> Input Class Initialized
INFO - 2017-02-13 12:29:18 --> Language Class Initialized
INFO - 2017-02-13 12:29:18 --> Security Class Initialized
ERROR - 2017-02-13 12:29:18 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:18 --> Input Class Initialized
INFO - 2017-02-13 12:29:18 --> Language Class Initialized
INFO - 2017-02-13 12:29:18 --> Config Class Initialized
INFO - 2017-02-13 12:29:18 --> Hooks Class Initialized
ERROR - 2017-02-13 12:29:18 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:29:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:18 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:18 --> URI Class Initialized
INFO - 2017-02-13 12:29:18 --> Router Class Initialized
INFO - 2017-02-13 12:29:18 --> Output Class Initialized
INFO - 2017-02-13 12:29:18 --> Config Class Initialized
INFO - 2017-02-13 12:29:18 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:18 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:18 --> Input Class Initialized
INFO - 2017-02-13 12:29:18 --> Language Class Initialized
DEBUG - 2017-02-13 12:29:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:18 --> Utf8 Class Initialized
ERROR - 2017-02-13 12:29:18 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:18 --> URI Class Initialized
INFO - 2017-02-13 12:29:18 --> Router Class Initialized
INFO - 2017-02-13 12:29:18 --> Config Class Initialized
INFO - 2017-02-13 12:29:18 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:18 --> Output Class Initialized
INFO - 2017-02-13 12:29:18 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:18 --> Input Class Initialized
DEBUG - 2017-02-13 12:29:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:18 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:18 --> Language Class Initialized
INFO - 2017-02-13 12:29:18 --> URI Class Initialized
ERROR - 2017-02-13 12:29:18 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:18 --> Router Class Initialized
INFO - 2017-02-13 12:29:18 --> Output Class Initialized
INFO - 2017-02-13 12:29:18 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:18 --> Input Class Initialized
INFO - 2017-02-13 12:29:18 --> Language Class Initialized
ERROR - 2017-02-13 12:29:18 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:18 --> Config Class Initialized
INFO - 2017-02-13 12:29:18 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:18 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:18 --> URI Class Initialized
INFO - 2017-02-13 12:29:18 --> Router Class Initialized
INFO - 2017-02-13 12:29:18 --> Output Class Initialized
INFO - 2017-02-13 12:29:18 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:18 --> Input Class Initialized
INFO - 2017-02-13 12:29:18 --> Language Class Initialized
ERROR - 2017-02-13 12:29:18 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:18 --> Config Class Initialized
INFO - 2017-02-13 12:29:18 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:18 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:18 --> URI Class Initialized
INFO - 2017-02-13 12:29:18 --> Router Class Initialized
INFO - 2017-02-13 12:29:18 --> Output Class Initialized
INFO - 2017-02-13 12:29:18 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:18 --> Input Class Initialized
INFO - 2017-02-13 12:29:18 --> Language Class Initialized
ERROR - 2017-02-13 12:29:18 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:18 --> Config Class Initialized
INFO - 2017-02-13 12:29:18 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:18 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:18 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:18 --> URI Class Initialized
INFO - 2017-02-13 12:29:18 --> Router Class Initialized
INFO - 2017-02-13 12:29:18 --> Output Class Initialized
INFO - 2017-02-13 12:29:18 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:18 --> Input Class Initialized
INFO - 2017-02-13 12:29:18 --> Language Class Initialized
ERROR - 2017-02-13 12:29:18 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:29:21 --> Config Class Initialized
INFO - 2017-02-13 12:29:21 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:21 --> Config Class Initialized
INFO - 2017-02-13 12:29:21 --> Config Class Initialized
INFO - 2017-02-13 12:29:21 --> Hooks Class Initialized
INFO - 2017-02-13 12:29:21 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:29:21 --> UTF-8 Support Enabled
DEBUG - 2017-02-13 12:29:21 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:21 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:21 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:21 --> URI Class Initialized
INFO - 2017-02-13 12:29:21 --> URI Class Initialized
INFO - 2017-02-13 12:29:21 --> Router Class Initialized
INFO - 2017-02-13 12:29:21 --> Router Class Initialized
INFO - 2017-02-13 12:29:21 --> Output Class Initialized
INFO - 2017-02-13 12:29:21 --> Output Class Initialized
INFO - 2017-02-13 12:29:21 --> Security Class Initialized
INFO - 2017-02-13 12:29:21 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-13 12:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:21 --> Input Class Initialized
INFO - 2017-02-13 12:29:21 --> Input Class Initialized
INFO - 2017-02-13 12:29:21 --> Language Class Initialized
INFO - 2017-02-13 12:29:21 --> Language Class Initialized
ERROR - 2017-02-13 12:29:21 --> 404 Page Not Found: /index
ERROR - 2017-02-13 12:29:21 --> 404 Page Not Found: /index
DEBUG - 2017-02-13 12:29:21 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:29:21 --> Utf8 Class Initialized
INFO - 2017-02-13 12:29:21 --> URI Class Initialized
INFO - 2017-02-13 12:29:21 --> Router Class Initialized
INFO - 2017-02-13 12:29:21 --> Output Class Initialized
INFO - 2017-02-13 12:29:21 --> Security Class Initialized
DEBUG - 2017-02-13 12:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:29:21 --> Input Class Initialized
INFO - 2017-02-13 12:29:21 --> Language Class Initialized
ERROR - 2017-02-13 12:29:21 --> 404 Page Not Found: /index
INFO - 2017-02-13 12:30:17 --> Config Class Initialized
INFO - 2017-02-13 12:30:17 --> Hooks Class Initialized
DEBUG - 2017-02-13 12:30:17 --> UTF-8 Support Enabled
INFO - 2017-02-13 12:30:17 --> Utf8 Class Initialized
INFO - 2017-02-13 12:30:17 --> URI Class Initialized
INFO - 2017-02-13 12:30:17 --> Router Class Initialized
INFO - 2017-02-13 12:30:17 --> Output Class Initialized
INFO - 2017-02-13 12:30:17 --> Security Class Initialized
DEBUG - 2017-02-13 12:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-13 12:30:17 --> Input Class Initialized
INFO - 2017-02-13 12:30:17 --> Language Class Initialized
ERROR - 2017-02-13 12:30:17 --> 404 Page Not Found: /index
