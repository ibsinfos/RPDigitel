<?php

class TABLES
{

    public static $ADMIN_USER = 'tbl_users';
    public static $MST_GLOBAL_SETTING = 'tbl_mst_global_settings';
    public static $TRANS_GLOBAL_SETTING = 'tbl_trans_global_settings';
    public static $TRANS_BLOG_COMMENTS = 'tbl_trans_blog_comments';
    public static $MST_BLOG_POSTS = 'tbl_mst_blog_posts';
    public static $TRANS_BLOG_POSTS = 'tbl_trans_blog_posts';
    public static $MST_CATEGORIES = 'tbl_mst_categories';
    public static $TRANS_SUB_CATEGORIES = 'tbl_trans_sub_categories';
    
}
