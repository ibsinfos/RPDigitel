<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-10 06:53:39 --> Config Class Initialized
INFO - 2017-02-10 06:53:39 --> Hooks Class Initialized
DEBUG - 2017-02-10 06:53:40 --> UTF-8 Support Enabled
INFO - 2017-02-10 06:53:40 --> Utf8 Class Initialized
INFO - 2017-02-10 06:53:40 --> URI Class Initialized
INFO - 2017-02-10 06:53:40 --> Router Class Initialized
INFO - 2017-02-10 06:53:40 --> Output Class Initialized
INFO - 2017-02-10 06:53:40 --> Security Class Initialized
DEBUG - 2017-02-10 06:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 06:53:40 --> Input Class Initialized
INFO - 2017-02-10 06:53:40 --> Language Class Initialized
INFO - 2017-02-10 06:53:40 --> Language Class Initialized
INFO - 2017-02-10 06:53:40 --> Config Class Initialized
INFO - 2017-02-10 06:53:40 --> Loader Class Initialized
INFO - 2017-02-10 06:53:40 --> Helper loaded: form_helper
INFO - 2017-02-10 06:53:40 --> Helper loaded: url_helper
INFO - 2017-02-10 06:53:40 --> Helper loaded: utility_helper
INFO - 2017-02-10 06:53:40 --> Database Driver Class Initialized
INFO - 2017-02-10 06:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 06:53:40 --> User Agent Class Initialized
DEBUG - 2017-02-10 06:53:40 --> Template Class Initialized
INFO - 2017-02-10 06:53:40 --> Controller Class Initialized
DEBUG - 2017-02-10 06:53:40 --> Login MX_Controller Initialized
INFO - 2017-02-10 06:53:40 --> Helper loaded: cookie_helper
INFO - 2017-02-10 06:53:40 --> Model Class Initialized
INFO - 2017-02-10 06:53:40 --> Model Class Initialized
DEBUG - 2017-02-10 06:53:40 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/login.php
DEBUG - 2017-02-10 06:53:41 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 06:53:41 --> Final output sent to browser
DEBUG - 2017-02-10 06:53:41 --> Total execution time: 1.1176
INFO - 2017-02-10 06:53:41 --> Config Class Initialized
INFO - 2017-02-10 06:53:41 --> Hooks Class Initialized
DEBUG - 2017-02-10 06:53:41 --> UTF-8 Support Enabled
INFO - 2017-02-10 06:53:41 --> Utf8 Class Initialized
INFO - 2017-02-10 06:53:41 --> URI Class Initialized
INFO - 2017-02-10 06:53:41 --> Router Class Initialized
INFO - 2017-02-10 06:53:41 --> Output Class Initialized
INFO - 2017-02-10 06:53:41 --> Security Class Initialized
DEBUG - 2017-02-10 06:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 06:53:41 --> Input Class Initialized
INFO - 2017-02-10 06:53:41 --> Language Class Initialized
ERROR - 2017-02-10 06:53:41 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-10 06:53:46 --> Config Class Initialized
INFO - 2017-02-10 06:53:46 --> Hooks Class Initialized
DEBUG - 2017-02-10 06:53:46 --> UTF-8 Support Enabled
INFO - 2017-02-10 06:53:46 --> Utf8 Class Initialized
INFO - 2017-02-10 06:53:47 --> URI Class Initialized
INFO - 2017-02-10 06:53:47 --> Router Class Initialized
INFO - 2017-02-10 06:53:47 --> Output Class Initialized
INFO - 2017-02-10 06:53:47 --> Security Class Initialized
DEBUG - 2017-02-10 06:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 06:53:47 --> Input Class Initialized
INFO - 2017-02-10 06:53:47 --> Language Class Initialized
INFO - 2017-02-10 06:53:47 --> Language Class Initialized
INFO - 2017-02-10 06:53:47 --> Config Class Initialized
INFO - 2017-02-10 06:53:47 --> Loader Class Initialized
INFO - 2017-02-10 06:53:47 --> Helper loaded: form_helper
INFO - 2017-02-10 06:53:47 --> Helper loaded: url_helper
INFO - 2017-02-10 06:53:47 --> Helper loaded: utility_helper
INFO - 2017-02-10 06:53:47 --> Database Driver Class Initialized
INFO - 2017-02-10 06:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 06:53:47 --> User Agent Class Initialized
DEBUG - 2017-02-10 06:53:47 --> Template Class Initialized
INFO - 2017-02-10 06:53:47 --> Controller Class Initialized
DEBUG - 2017-02-10 06:53:47 --> Login MX_Controller Initialized
INFO - 2017-02-10 06:53:47 --> Helper loaded: cookie_helper
INFO - 2017-02-10 06:53:47 --> Model Class Initialized
INFO - 2017-02-10 06:53:47 --> Model Class Initialized
ERROR - 2017-02-10 06:53:47 --> Severity: Notice --> Undefined index: mobile C:\xampp\htdocs\mobile\application\modules\backend\controllers\Login.php 31
INFO - 2017-02-10 06:53:47 --> Config Class Initialized
INFO - 2017-02-10 06:53:47 --> Hooks Class Initialized
DEBUG - 2017-02-10 06:53:47 --> UTF-8 Support Enabled
INFO - 2017-02-10 06:53:47 --> Utf8 Class Initialized
INFO - 2017-02-10 06:53:47 --> URI Class Initialized
INFO - 2017-02-10 06:53:47 --> Router Class Initialized
INFO - 2017-02-10 06:53:47 --> Output Class Initialized
INFO - 2017-02-10 06:53:47 --> Security Class Initialized
DEBUG - 2017-02-10 06:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 06:53:47 --> Input Class Initialized
INFO - 2017-02-10 06:53:47 --> Language Class Initialized
INFO - 2017-02-10 06:53:47 --> Language Class Initialized
INFO - 2017-02-10 06:53:47 --> Config Class Initialized
INFO - 2017-02-10 06:53:47 --> Loader Class Initialized
INFO - 2017-02-10 06:53:47 --> Helper loaded: form_helper
INFO - 2017-02-10 06:53:47 --> Helper loaded: url_helper
INFO - 2017-02-10 06:53:47 --> Helper loaded: utility_helper
INFO - 2017-02-10 06:53:47 --> Database Driver Class Initialized
INFO - 2017-02-10 06:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 06:53:47 --> User Agent Class Initialized
DEBUG - 2017-02-10 06:53:47 --> Template Class Initialized
INFO - 2017-02-10 06:53:47 --> Controller Class Initialized
DEBUG - 2017-02-10 06:53:47 --> Dashboard MX_Controller Initialized
INFO - 2017-02-10 06:53:47 --> Helper loaded: cookie_helper
INFO - 2017-02-10 06:53:47 --> Model Class Initialized
INFO - 2017-02-10 06:53:47 --> Model Class Initialized
DEBUG - 2017-02-10 06:53:47 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 06:53:47 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 06:53:47 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-10 06:53:47 --> Severity: Notice --> Undefined variable: total_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 14
ERROR - 2017-02-10 06:53:47 --> Severity: Notice --> Undefined variable: todays_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 27
ERROR - 2017-02-10 06:53:47 --> Severity: Notice --> Undefined variable: pending_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 40
ERROR - 2017-02-10 06:53:47 --> Severity: Notice --> Undefined variable: delivered_bookings C:\xampp\htdocs\mobile\application\modules\backend\views\dashboard.php 53
DEBUG - 2017-02-10 06:53:47 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/dashboard.php
DEBUG - 2017-02-10 06:53:47 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 06:53:47 --> Final output sent to browser
DEBUG - 2017-02-10 06:53:47 --> Total execution time: 0.2450
INFO - 2017-02-10 06:53:47 --> Config Class Initialized
INFO - 2017-02-10 06:53:47 --> Hooks Class Initialized
DEBUG - 2017-02-10 06:53:47 --> UTF-8 Support Enabled
INFO - 2017-02-10 06:53:47 --> Utf8 Class Initialized
INFO - 2017-02-10 06:53:47 --> URI Class Initialized
INFO - 2017-02-10 06:53:47 --> Router Class Initialized
INFO - 2017-02-10 06:53:47 --> Output Class Initialized
INFO - 2017-02-10 06:53:47 --> Security Class Initialized
DEBUG - 2017-02-10 06:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 06:53:47 --> Input Class Initialized
INFO - 2017-02-10 06:53:47 --> Language Class Initialized
ERROR - 2017-02-10 06:53:47 --> 404 Page Not Found: /index
INFO - 2017-02-10 06:53:47 --> Config Class Initialized
INFO - 2017-02-10 06:53:47 --> Hooks Class Initialized
DEBUG - 2017-02-10 06:53:47 --> UTF-8 Support Enabled
INFO - 2017-02-10 06:53:47 --> Utf8 Class Initialized
INFO - 2017-02-10 06:53:47 --> URI Class Initialized
INFO - 2017-02-10 06:53:47 --> Router Class Initialized
INFO - 2017-02-10 06:53:47 --> Output Class Initialized
INFO - 2017-02-10 06:53:47 --> Security Class Initialized
DEBUG - 2017-02-10 06:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 06:53:47 --> Input Class Initialized
INFO - 2017-02-10 06:53:47 --> Language Class Initialized
ERROR - 2017-02-10 06:53:47 --> 404 Page Not Found: /index
INFO - 2017-02-10 06:53:52 --> Config Class Initialized
INFO - 2017-02-10 06:53:52 --> Hooks Class Initialized
DEBUG - 2017-02-10 06:53:52 --> UTF-8 Support Enabled
INFO - 2017-02-10 06:53:52 --> Utf8 Class Initialized
INFO - 2017-02-10 06:53:52 --> URI Class Initialized
INFO - 2017-02-10 06:53:52 --> Router Class Initialized
INFO - 2017-02-10 06:53:52 --> Output Class Initialized
INFO - 2017-02-10 06:53:52 --> Security Class Initialized
DEBUG - 2017-02-10 06:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 06:53:52 --> Input Class Initialized
INFO - 2017-02-10 06:53:52 --> Language Class Initialized
ERROR - 2017-02-10 06:53:52 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-10 06:53:55 --> Config Class Initialized
INFO - 2017-02-10 06:53:55 --> Hooks Class Initialized
DEBUG - 2017-02-10 06:53:55 --> UTF-8 Support Enabled
INFO - 2017-02-10 06:53:55 --> Utf8 Class Initialized
INFO - 2017-02-10 06:53:55 --> URI Class Initialized
INFO - 2017-02-10 06:53:55 --> Router Class Initialized
INFO - 2017-02-10 06:53:55 --> Output Class Initialized
INFO - 2017-02-10 06:53:55 --> Security Class Initialized
DEBUG - 2017-02-10 06:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 06:53:55 --> Input Class Initialized
INFO - 2017-02-10 06:53:55 --> Language Class Initialized
INFO - 2017-02-10 06:53:55 --> Language Class Initialized
INFO - 2017-02-10 06:53:55 --> Config Class Initialized
INFO - 2017-02-10 06:53:55 --> Loader Class Initialized
INFO - 2017-02-10 06:53:55 --> Helper loaded: form_helper
INFO - 2017-02-10 06:53:55 --> Helper loaded: url_helper
INFO - 2017-02-10 06:53:55 --> Helper loaded: utility_helper
INFO - 2017-02-10 06:53:55 --> Database Driver Class Initialized
INFO - 2017-02-10 06:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 06:53:55 --> User Agent Class Initialized
DEBUG - 2017-02-10 06:53:55 --> Template Class Initialized
INFO - 2017-02-10 06:53:55 --> Controller Class Initialized
INFO - 2017-02-10 06:53:55 --> Model Class Initialized
INFO - 2017-02-10 06:53:55 --> Model Class Initialized
INFO - 2017-02-10 06:53:55 --> Model Class Initialized
ERROR - 2017-02-10 06:53:55 --> Query error: Table 'mobile.mst_newsletter' doesn't exist - Invalid query: SELECT *
FROM `mst_newsletter`
ORDER BY `newsletter_id` DESC
INFO - 2017-02-10 06:53:55 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-10 07:00:22 --> Config Class Initialized
INFO - 2017-02-10 07:00:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:00:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:00:22 --> Utf8 Class Initialized
INFO - 2017-02-10 07:00:22 --> URI Class Initialized
INFO - 2017-02-10 07:00:22 --> Router Class Initialized
INFO - 2017-02-10 07:00:22 --> Output Class Initialized
INFO - 2017-02-10 07:00:22 --> Security Class Initialized
DEBUG - 2017-02-10 07:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:00:22 --> Input Class Initialized
INFO - 2017-02-10 07:00:22 --> Language Class Initialized
INFO - 2017-02-10 07:00:22 --> Language Class Initialized
INFO - 2017-02-10 07:00:22 --> Config Class Initialized
INFO - 2017-02-10 07:00:22 --> Loader Class Initialized
INFO - 2017-02-10 07:00:22 --> Helper loaded: form_helper
INFO - 2017-02-10 07:00:22 --> Helper loaded: url_helper
INFO - 2017-02-10 07:00:22 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:00:22 --> Database Driver Class Initialized
INFO - 2017-02-10 07:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:00:22 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:00:22 --> Template Class Initialized
INFO - 2017-02-10 07:00:22 --> Controller Class Initialized
INFO - 2017-02-10 07:00:22 --> Model Class Initialized
INFO - 2017-02-10 07:00:22 --> Model Class Initialized
INFO - 2017-02-10 07:00:22 --> Model Class Initialized
ERROR - 2017-02-10 07:00:22 --> Severity: Notice --> Undefined variable: TABLES C:\xampp\htdocs\mobile\application\models\Newsletter_model.php 12
ERROR - 2017-02-10 07:00:22 --> Severity: Error --> Class name must be a valid object or a string C:\xampp\htdocs\mobile\application\models\Newsletter_model.php 12
INFO - 2017-02-10 07:01:08 --> Config Class Initialized
INFO - 2017-02-10 07:01:08 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:01:08 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:01:08 --> Utf8 Class Initialized
INFO - 2017-02-10 07:01:08 --> URI Class Initialized
INFO - 2017-02-10 07:01:08 --> Router Class Initialized
INFO - 2017-02-10 07:01:08 --> Output Class Initialized
INFO - 2017-02-10 07:01:08 --> Security Class Initialized
DEBUG - 2017-02-10 07:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:01:08 --> Input Class Initialized
INFO - 2017-02-10 07:01:08 --> Language Class Initialized
INFO - 2017-02-10 07:01:08 --> Language Class Initialized
INFO - 2017-02-10 07:01:08 --> Config Class Initialized
INFO - 2017-02-10 07:01:08 --> Loader Class Initialized
INFO - 2017-02-10 07:01:08 --> Helper loaded: form_helper
INFO - 2017-02-10 07:01:08 --> Helper loaded: url_helper
INFO - 2017-02-10 07:01:08 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:01:08 --> Database Driver Class Initialized
INFO - 2017-02-10 07:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:01:08 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:01:08 --> Template Class Initialized
INFO - 2017-02-10 07:01:08 --> Controller Class Initialized
INFO - 2017-02-10 07:01:08 --> Model Class Initialized
INFO - 2017-02-10 07:01:08 --> Model Class Initialized
INFO - 2017-02-10 07:01:08 --> Model Class Initialized
ERROR - 2017-02-10 07:01:08 --> Query error: Table 'mobile.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `id` = '1'
INFO - 2017-02-10 07:01:08 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-10 07:02:52 --> Config Class Initialized
INFO - 2017-02-10 07:02:52 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:02:52 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:02:52 --> Utf8 Class Initialized
INFO - 2017-02-10 07:02:52 --> URI Class Initialized
INFO - 2017-02-10 07:02:52 --> Router Class Initialized
INFO - 2017-02-10 07:02:52 --> Output Class Initialized
INFO - 2017-02-10 07:02:52 --> Security Class Initialized
DEBUG - 2017-02-10 07:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:02:52 --> Input Class Initialized
INFO - 2017-02-10 07:02:52 --> Language Class Initialized
INFO - 2017-02-10 07:02:52 --> Language Class Initialized
INFO - 2017-02-10 07:02:52 --> Config Class Initialized
INFO - 2017-02-10 07:02:52 --> Loader Class Initialized
INFO - 2017-02-10 07:02:52 --> Helper loaded: form_helper
INFO - 2017-02-10 07:02:52 --> Helper loaded: url_helper
INFO - 2017-02-10 07:02:52 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:02:52 --> Database Driver Class Initialized
INFO - 2017-02-10 07:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:02:52 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:02:52 --> Template Class Initialized
INFO - 2017-02-10 07:02:52 --> Controller Class Initialized
INFO - 2017-02-10 07:02:52 --> Model Class Initialized
INFO - 2017-02-10 07:02:52 --> Model Class Initialized
INFO - 2017-02-10 07:02:52 --> Model Class Initialized
ERROR - 2017-02-10 07:02:52 --> Severity: Notice --> Undefined index: arr_global_settings C:\xampp\htdocs\mobile\application\modules\backend\controllers\Newsletter.php 39
ERROR - 2017-02-10 07:02:52 --> Severity: Notice --> Undefined index: arr_active_admin_details C:\xampp\htdocs\mobile\application\modules\backend\controllers\Newsletter.php 40
ERROR - 2017-02-10 07:02:52 --> Severity: Notice --> Undefined index: arr_newsletter_list C:\xampp\htdocs\mobile\application\modules\backend\controllers\Newsletter.php 41
DEBUG - 2017-02-10 07:02:52 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:02:52 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:02:52 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-10 07:02:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_list.php 81
DEBUG - 2017-02-10 07:02:52 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:02:52 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:02:52 --> Final output sent to browser
DEBUG - 2017-02-10 07:02:52 --> Total execution time: 0.0620
INFO - 2017-02-10 07:02:52 --> Config Class Initialized
INFO - 2017-02-10 07:02:52 --> Hooks Class Initialized
INFO - 2017-02-10 07:02:52 --> Config Class Initialized
INFO - 2017-02-10 07:02:52 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:02:52 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:02:52 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:02:52 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:02:52 --> Utf8 Class Initialized
INFO - 2017-02-10 07:02:52 --> URI Class Initialized
INFO - 2017-02-10 07:02:52 --> URI Class Initialized
INFO - 2017-02-10 07:02:52 --> Router Class Initialized
INFO - 2017-02-10 07:02:52 --> Router Class Initialized
INFO - 2017-02-10 07:02:52 --> Output Class Initialized
INFO - 2017-02-10 07:02:52 --> Output Class Initialized
INFO - 2017-02-10 07:02:52 --> Security Class Initialized
INFO - 2017-02-10 07:02:52 --> Security Class Initialized
DEBUG - 2017-02-10 07:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:02:52 --> Input Class Initialized
INFO - 2017-02-10 07:02:52 --> Language Class Initialized
DEBUG - 2017-02-10 07:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:02:52 --> Input Class Initialized
ERROR - 2017-02-10 07:02:52 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:02:52 --> Language Class Initialized
ERROR - 2017-02-10 07:02:52 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:02:53 --> Config Class Initialized
INFO - 2017-02-10 07:02:53 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:02:53 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:02:53 --> Utf8 Class Initialized
INFO - 2017-02-10 07:02:53 --> URI Class Initialized
INFO - 2017-02-10 07:02:53 --> Router Class Initialized
INFO - 2017-02-10 07:02:53 --> Output Class Initialized
INFO - 2017-02-10 07:02:53 --> Security Class Initialized
DEBUG - 2017-02-10 07:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:02:53 --> Input Class Initialized
INFO - 2017-02-10 07:02:53 --> Language Class Initialized
ERROR - 2017-02-10 07:02:53 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:03:12 --> Config Class Initialized
INFO - 2017-02-10 07:03:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:03:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:03:12 --> Utf8 Class Initialized
INFO - 2017-02-10 07:03:12 --> URI Class Initialized
INFO - 2017-02-10 07:03:12 --> Router Class Initialized
INFO - 2017-02-10 07:03:12 --> Output Class Initialized
INFO - 2017-02-10 07:03:12 --> Security Class Initialized
DEBUG - 2017-02-10 07:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:03:12 --> Input Class Initialized
INFO - 2017-02-10 07:03:12 --> Language Class Initialized
INFO - 2017-02-10 07:03:12 --> Language Class Initialized
INFO - 2017-02-10 07:03:12 --> Config Class Initialized
INFO - 2017-02-10 07:03:12 --> Loader Class Initialized
INFO - 2017-02-10 07:03:12 --> Helper loaded: form_helper
INFO - 2017-02-10 07:03:12 --> Helper loaded: url_helper
INFO - 2017-02-10 07:03:12 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:03:12 --> Database Driver Class Initialized
INFO - 2017-02-10 07:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:03:12 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:03:12 --> Template Class Initialized
INFO - 2017-02-10 07:03:12 --> Controller Class Initialized
INFO - 2017-02-10 07:03:12 --> Model Class Initialized
INFO - 2017-02-10 07:03:12 --> Model Class Initialized
INFO - 2017-02-10 07:03:12 --> Model Class Initialized
ERROR - 2017-02-10 07:03:12 --> Severity: Notice --> Undefined index: arr_active_admin_details C:\xampp\htdocs\mobile\application\modules\backend\controllers\Newsletter.php 40
ERROR - 2017-02-10 07:03:12 --> Severity: Notice --> Undefined index: arr_newsletter_list C:\xampp\htdocs\mobile\application\modules\backend\controllers\Newsletter.php 41
DEBUG - 2017-02-10 07:03:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:03:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:03:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-10 07:03:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_list.php 81
DEBUG - 2017-02-10 07:03:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:03:12 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:03:12 --> Final output sent to browser
DEBUG - 2017-02-10 07:03:12 --> Total execution time: 0.0898
INFO - 2017-02-10 07:03:12 --> Config Class Initialized
INFO - 2017-02-10 07:03:12 --> Config Class Initialized
INFO - 2017-02-10 07:03:12 --> Hooks Class Initialized
INFO - 2017-02-10 07:03:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:03:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:03:12 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:03:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:03:12 --> Utf8 Class Initialized
INFO - 2017-02-10 07:03:12 --> URI Class Initialized
INFO - 2017-02-10 07:03:12 --> URI Class Initialized
INFO - 2017-02-10 07:03:12 --> Router Class Initialized
INFO - 2017-02-10 07:03:12 --> Output Class Initialized
INFO - 2017-02-10 07:03:12 --> Router Class Initialized
INFO - 2017-02-10 07:03:12 --> Security Class Initialized
INFO - 2017-02-10 07:03:12 --> Output Class Initialized
DEBUG - 2017-02-10 07:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:03:12 --> Input Class Initialized
INFO - 2017-02-10 07:03:12 --> Language Class Initialized
INFO - 2017-02-10 07:03:12 --> Security Class Initialized
ERROR - 2017-02-10 07:03:12 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:03:12 --> Input Class Initialized
INFO - 2017-02-10 07:03:12 --> Language Class Initialized
ERROR - 2017-02-10 07:03:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:03:12 --> Config Class Initialized
INFO - 2017-02-10 07:03:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:03:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:03:12 --> Utf8 Class Initialized
INFO - 2017-02-10 07:03:12 --> URI Class Initialized
INFO - 2017-02-10 07:03:12 --> Router Class Initialized
INFO - 2017-02-10 07:03:12 --> Output Class Initialized
INFO - 2017-02-10 07:03:12 --> Security Class Initialized
DEBUG - 2017-02-10 07:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:03:12 --> Input Class Initialized
INFO - 2017-02-10 07:03:12 --> Language Class Initialized
ERROR - 2017-02-10 07:03:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:03:27 --> Config Class Initialized
INFO - 2017-02-10 07:03:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:03:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:03:27 --> Utf8 Class Initialized
INFO - 2017-02-10 07:03:27 --> URI Class Initialized
INFO - 2017-02-10 07:03:27 --> Router Class Initialized
INFO - 2017-02-10 07:03:27 --> Output Class Initialized
INFO - 2017-02-10 07:03:27 --> Security Class Initialized
DEBUG - 2017-02-10 07:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:03:27 --> Input Class Initialized
INFO - 2017-02-10 07:03:27 --> Language Class Initialized
INFO - 2017-02-10 07:03:27 --> Language Class Initialized
INFO - 2017-02-10 07:03:27 --> Config Class Initialized
INFO - 2017-02-10 07:03:27 --> Loader Class Initialized
INFO - 2017-02-10 07:03:27 --> Helper loaded: form_helper
INFO - 2017-02-10 07:03:27 --> Helper loaded: url_helper
INFO - 2017-02-10 07:03:27 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:03:27 --> Database Driver Class Initialized
INFO - 2017-02-10 07:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:03:27 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:03:27 --> Template Class Initialized
INFO - 2017-02-10 07:03:27 --> Controller Class Initialized
INFO - 2017-02-10 07:03:27 --> Model Class Initialized
INFO - 2017-02-10 07:03:27 --> Model Class Initialized
INFO - 2017-02-10 07:03:27 --> Model Class Initialized
ERROR - 2017-02-10 07:03:27 --> Severity: Notice --> Undefined index: arr_newsletter_list C:\xampp\htdocs\mobile\application\modules\backend\controllers\Newsletter.php 40
DEBUG - 2017-02-10 07:03:27 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:03:27 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:03:27 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-10 07:03:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_list.php 81
DEBUG - 2017-02-10 07:03:27 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:03:27 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:03:27 --> Final output sent to browser
DEBUG - 2017-02-10 07:03:27 --> Total execution time: 0.0830
INFO - 2017-02-10 07:03:27 --> Config Class Initialized
INFO - 2017-02-10 07:03:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:03:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:03:27 --> Utf8 Class Initialized
INFO - 2017-02-10 07:03:27 --> URI Class Initialized
INFO - 2017-02-10 07:03:27 --> Config Class Initialized
INFO - 2017-02-10 07:03:27 --> Hooks Class Initialized
INFO - 2017-02-10 07:03:27 --> Router Class Initialized
DEBUG - 2017-02-10 07:03:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:03:27 --> Output Class Initialized
INFO - 2017-02-10 07:03:27 --> Utf8 Class Initialized
INFO - 2017-02-10 07:03:27 --> Security Class Initialized
INFO - 2017-02-10 07:03:27 --> URI Class Initialized
DEBUG - 2017-02-10 07:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:03:27 --> Input Class Initialized
INFO - 2017-02-10 07:03:27 --> Language Class Initialized
INFO - 2017-02-10 07:03:27 --> Router Class Initialized
ERROR - 2017-02-10 07:03:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:03:27 --> Output Class Initialized
INFO - 2017-02-10 07:03:27 --> Security Class Initialized
DEBUG - 2017-02-10 07:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:03:27 --> Input Class Initialized
INFO - 2017-02-10 07:03:27 --> Language Class Initialized
ERROR - 2017-02-10 07:03:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:03:27 --> Config Class Initialized
INFO - 2017-02-10 07:03:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:03:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:03:27 --> Utf8 Class Initialized
INFO - 2017-02-10 07:03:27 --> URI Class Initialized
INFO - 2017-02-10 07:03:27 --> Router Class Initialized
INFO - 2017-02-10 07:03:27 --> Output Class Initialized
INFO - 2017-02-10 07:03:27 --> Security Class Initialized
DEBUG - 2017-02-10 07:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:03:27 --> Input Class Initialized
INFO - 2017-02-10 07:03:27 --> Language Class Initialized
ERROR - 2017-02-10 07:03:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:03:59 --> Config Class Initialized
INFO - 2017-02-10 07:03:59 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:03:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:03:59 --> Utf8 Class Initialized
INFO - 2017-02-10 07:03:59 --> URI Class Initialized
INFO - 2017-02-10 07:03:59 --> Router Class Initialized
INFO - 2017-02-10 07:03:59 --> Output Class Initialized
INFO - 2017-02-10 07:03:59 --> Security Class Initialized
DEBUG - 2017-02-10 07:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:03:59 --> Input Class Initialized
INFO - 2017-02-10 07:03:59 --> Language Class Initialized
INFO - 2017-02-10 07:03:59 --> Language Class Initialized
INFO - 2017-02-10 07:03:59 --> Config Class Initialized
INFO - 2017-02-10 07:03:59 --> Loader Class Initialized
INFO - 2017-02-10 07:03:59 --> Helper loaded: form_helper
INFO - 2017-02-10 07:03:59 --> Helper loaded: url_helper
INFO - 2017-02-10 07:03:59 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:03:59 --> Database Driver Class Initialized
INFO - 2017-02-10 07:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:03:59 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:03:59 --> Template Class Initialized
INFO - 2017-02-10 07:03:59 --> Controller Class Initialized
INFO - 2017-02-10 07:03:59 --> Model Class Initialized
INFO - 2017-02-10 07:03:59 --> Model Class Initialized
INFO - 2017-02-10 07:03:59 --> Model Class Initialized
ERROR - 2017-02-10 07:03:59 --> Severity: Notice --> Undefined index: arr_global_settings C:\xampp\htdocs\mobile\application\modules\backend\controllers\Newsletter.php 39
DEBUG - 2017-02-10 07:03:59 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:03:59 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:03:59 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:03:59 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:03:59 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:03:59 --> Final output sent to browser
DEBUG - 2017-02-10 07:03:59 --> Total execution time: 0.0707
INFO - 2017-02-10 07:03:59 --> Config Class Initialized
INFO - 2017-02-10 07:03:59 --> Hooks Class Initialized
INFO - 2017-02-10 07:03:59 --> Config Class Initialized
INFO - 2017-02-10 07:03:59 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:03:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:03:59 --> Utf8 Class Initialized
INFO - 2017-02-10 07:03:59 --> URI Class Initialized
DEBUG - 2017-02-10 07:03:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:03:59 --> Utf8 Class Initialized
INFO - 2017-02-10 07:03:59 --> Router Class Initialized
INFO - 2017-02-10 07:03:59 --> URI Class Initialized
INFO - 2017-02-10 07:03:59 --> Output Class Initialized
INFO - 2017-02-10 07:03:59 --> Security Class Initialized
DEBUG - 2017-02-10 07:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:03:59 --> Input Class Initialized
INFO - 2017-02-10 07:03:59 --> Router Class Initialized
INFO - 2017-02-10 07:03:59 --> Language Class Initialized
INFO - 2017-02-10 07:03:59 --> Output Class Initialized
ERROR - 2017-02-10 07:03:59 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:03:59 --> Security Class Initialized
DEBUG - 2017-02-10 07:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:03:59 --> Input Class Initialized
INFO - 2017-02-10 07:03:59 --> Language Class Initialized
ERROR - 2017-02-10 07:03:59 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:03:59 --> Config Class Initialized
INFO - 2017-02-10 07:03:59 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:03:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:03:59 --> Utf8 Class Initialized
INFO - 2017-02-10 07:03:59 --> URI Class Initialized
INFO - 2017-02-10 07:03:59 --> Router Class Initialized
INFO - 2017-02-10 07:03:59 --> Output Class Initialized
INFO - 2017-02-10 07:03:59 --> Security Class Initialized
DEBUG - 2017-02-10 07:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:03:59 --> Input Class Initialized
INFO - 2017-02-10 07:03:59 --> Language Class Initialized
ERROR - 2017-02-10 07:03:59 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:04:11 --> Config Class Initialized
INFO - 2017-02-10 07:04:11 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:04:11 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:04:11 --> Utf8 Class Initialized
INFO - 2017-02-10 07:04:11 --> URI Class Initialized
INFO - 2017-02-10 07:04:11 --> Router Class Initialized
INFO - 2017-02-10 07:04:11 --> Output Class Initialized
INFO - 2017-02-10 07:04:11 --> Security Class Initialized
DEBUG - 2017-02-10 07:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:04:11 --> Input Class Initialized
INFO - 2017-02-10 07:04:11 --> Language Class Initialized
INFO - 2017-02-10 07:04:11 --> Language Class Initialized
INFO - 2017-02-10 07:04:11 --> Config Class Initialized
INFO - 2017-02-10 07:04:11 --> Loader Class Initialized
INFO - 2017-02-10 07:04:11 --> Helper loaded: form_helper
INFO - 2017-02-10 07:04:11 --> Helper loaded: url_helper
INFO - 2017-02-10 07:04:11 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:04:11 --> Database Driver Class Initialized
INFO - 2017-02-10 07:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:04:11 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:04:11 --> Template Class Initialized
INFO - 2017-02-10 07:04:11 --> Controller Class Initialized
INFO - 2017-02-10 07:04:11 --> Model Class Initialized
INFO - 2017-02-10 07:04:11 --> Model Class Initialized
INFO - 2017-02-10 07:04:11 --> Model Class Initialized
DEBUG - 2017-02-10 07:04:11 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:04:11 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:04:11 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:04:11 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:04:11 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:04:11 --> Final output sent to browser
DEBUG - 2017-02-10 07:04:11 --> Total execution time: 0.0669
INFO - 2017-02-10 07:04:11 --> Config Class Initialized
INFO - 2017-02-10 07:04:11 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:04:11 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:04:11 --> Utf8 Class Initialized
INFO - 2017-02-10 07:04:11 --> URI Class Initialized
INFO - 2017-02-10 07:04:11 --> Config Class Initialized
INFO - 2017-02-10 07:04:11 --> Hooks Class Initialized
INFO - 2017-02-10 07:04:11 --> Router Class Initialized
INFO - 2017-02-10 07:04:11 --> Output Class Initialized
DEBUG - 2017-02-10 07:04:11 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:04:11 --> Utf8 Class Initialized
INFO - 2017-02-10 07:04:11 --> Security Class Initialized
INFO - 2017-02-10 07:04:11 --> URI Class Initialized
DEBUG - 2017-02-10 07:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:04:11 --> Input Class Initialized
INFO - 2017-02-10 07:04:11 --> Language Class Initialized
INFO - 2017-02-10 07:04:11 --> Router Class Initialized
ERROR - 2017-02-10 07:04:11 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:04:11 --> Output Class Initialized
INFO - 2017-02-10 07:04:11 --> Security Class Initialized
DEBUG - 2017-02-10 07:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:04:11 --> Input Class Initialized
INFO - 2017-02-10 07:04:11 --> Language Class Initialized
ERROR - 2017-02-10 07:04:11 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:04:11 --> Config Class Initialized
INFO - 2017-02-10 07:04:11 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:04:11 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:04:11 --> Utf8 Class Initialized
INFO - 2017-02-10 07:04:11 --> URI Class Initialized
INFO - 2017-02-10 07:04:11 --> Router Class Initialized
INFO - 2017-02-10 07:04:11 --> Output Class Initialized
INFO - 2017-02-10 07:04:11 --> Security Class Initialized
DEBUG - 2017-02-10 07:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:04:11 --> Input Class Initialized
INFO - 2017-02-10 07:04:11 --> Language Class Initialized
ERROR - 2017-02-10 07:04:11 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:04:12 --> Config Class Initialized
INFO - 2017-02-10 07:04:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:04:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:04:12 --> Utf8 Class Initialized
INFO - 2017-02-10 07:04:12 --> URI Class Initialized
INFO - 2017-02-10 07:04:12 --> Router Class Initialized
INFO - 2017-02-10 07:04:12 --> Output Class Initialized
INFO - 2017-02-10 07:04:12 --> Security Class Initialized
DEBUG - 2017-02-10 07:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:04:12 --> Input Class Initialized
INFO - 2017-02-10 07:04:12 --> Language Class Initialized
ERROR - 2017-02-10 07:04:12 --> 404 Page Not Found: ../modules/backend/controllers/Newsletter/img
INFO - 2017-02-10 07:05:56 --> Config Class Initialized
INFO - 2017-02-10 07:05:56 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:05:56 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:05:56 --> Utf8 Class Initialized
INFO - 2017-02-10 07:05:56 --> URI Class Initialized
INFO - 2017-02-10 07:05:56 --> Router Class Initialized
INFO - 2017-02-10 07:05:56 --> Output Class Initialized
INFO - 2017-02-10 07:05:56 --> Security Class Initialized
DEBUG - 2017-02-10 07:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:05:56 --> Input Class Initialized
INFO - 2017-02-10 07:05:56 --> Language Class Initialized
INFO - 2017-02-10 07:05:56 --> Language Class Initialized
INFO - 2017-02-10 07:05:56 --> Config Class Initialized
INFO - 2017-02-10 07:05:56 --> Loader Class Initialized
INFO - 2017-02-10 07:05:56 --> Helper loaded: form_helper
INFO - 2017-02-10 07:05:56 --> Helper loaded: url_helper
INFO - 2017-02-10 07:05:56 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:05:56 --> Database Driver Class Initialized
INFO - 2017-02-10 07:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:05:56 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:05:56 --> Template Class Initialized
INFO - 2017-02-10 07:05:56 --> Controller Class Initialized
INFO - 2017-02-10 07:05:56 --> Model Class Initialized
INFO - 2017-02-10 07:05:56 --> Model Class Initialized
INFO - 2017-02-10 07:05:56 --> Model Class Initialized
ERROR - 2017-02-10 07:05:56 --> Severity: Error --> Access to undeclared static property: TABLES::$MST_TEMPLATE C:\xampp\htdocs\mobile\application\models\Newsletter_model.php 12
INFO - 2017-02-10 07:06:37 --> Config Class Initialized
INFO - 2017-02-10 07:06:37 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:06:37 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:06:37 --> Utf8 Class Initialized
INFO - 2017-02-10 07:06:37 --> URI Class Initialized
INFO - 2017-02-10 07:06:37 --> Router Class Initialized
INFO - 2017-02-10 07:06:37 --> Output Class Initialized
INFO - 2017-02-10 07:06:37 --> Security Class Initialized
DEBUG - 2017-02-10 07:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:06:37 --> Input Class Initialized
INFO - 2017-02-10 07:06:37 --> Language Class Initialized
INFO - 2017-02-10 07:06:37 --> Language Class Initialized
INFO - 2017-02-10 07:06:37 --> Config Class Initialized
INFO - 2017-02-10 07:06:37 --> Loader Class Initialized
INFO - 2017-02-10 07:06:37 --> Helper loaded: form_helper
INFO - 2017-02-10 07:06:37 --> Helper loaded: url_helper
INFO - 2017-02-10 07:06:37 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:06:37 --> Database Driver Class Initialized
INFO - 2017-02-10 07:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:06:37 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:06:37 --> Template Class Initialized
INFO - 2017-02-10 07:06:37 --> Controller Class Initialized
INFO - 2017-02-10 07:06:37 --> Model Class Initialized
INFO - 2017-02-10 07:06:37 --> Model Class Initialized
INFO - 2017-02-10 07:06:37 --> Model Class Initialized
ERROR - 2017-02-10 07:06:37 --> Severity: Error --> Access to undeclared static property: TABLES::$MST_TEMPLATE C:\xampp\htdocs\mobile\application\models\Newsletter_model.php 12
INFO - 2017-02-10 07:07:11 --> Config Class Initialized
INFO - 2017-02-10 07:07:11 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:07:11 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:07:11 --> Utf8 Class Initialized
INFO - 2017-02-10 07:07:11 --> URI Class Initialized
INFO - 2017-02-10 07:07:11 --> Router Class Initialized
INFO - 2017-02-10 07:07:11 --> Output Class Initialized
INFO - 2017-02-10 07:07:11 --> Security Class Initialized
DEBUG - 2017-02-10 07:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:07:11 --> Input Class Initialized
INFO - 2017-02-10 07:07:11 --> Language Class Initialized
INFO - 2017-02-10 07:07:11 --> Language Class Initialized
INFO - 2017-02-10 07:07:11 --> Config Class Initialized
INFO - 2017-02-10 07:07:11 --> Loader Class Initialized
INFO - 2017-02-10 07:07:11 --> Helper loaded: form_helper
INFO - 2017-02-10 07:07:11 --> Helper loaded: url_helper
INFO - 2017-02-10 07:07:11 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:07:11 --> Database Driver Class Initialized
INFO - 2017-02-10 07:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:07:11 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:07:11 --> Template Class Initialized
INFO - 2017-02-10 07:07:11 --> Controller Class Initialized
INFO - 2017-02-10 07:07:11 --> Model Class Initialized
INFO - 2017-02-10 07:07:11 --> Model Class Initialized
INFO - 2017-02-10 07:07:11 --> Model Class Initialized
DEBUG - 2017-02-10 07:07:11 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:07:11 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:07:11 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:07:11 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:07:11 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:07:11 --> Final output sent to browser
DEBUG - 2017-02-10 07:07:11 --> Total execution time: 0.0715
INFO - 2017-02-10 07:07:11 --> Config Class Initialized
INFO - 2017-02-10 07:07:11 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:07:11 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:07:11 --> Utf8 Class Initialized
INFO - 2017-02-10 07:07:11 --> Config Class Initialized
INFO - 2017-02-10 07:07:11 --> Hooks Class Initialized
INFO - 2017-02-10 07:07:11 --> URI Class Initialized
DEBUG - 2017-02-10 07:07:11 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:07:11 --> Utf8 Class Initialized
INFO - 2017-02-10 07:07:11 --> Router Class Initialized
INFO - 2017-02-10 07:07:11 --> URI Class Initialized
INFO - 2017-02-10 07:07:11 --> Output Class Initialized
INFO - 2017-02-10 07:07:11 --> Security Class Initialized
DEBUG - 2017-02-10 07:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:07:11 --> Input Class Initialized
INFO - 2017-02-10 07:07:11 --> Language Class Initialized
INFO - 2017-02-10 07:07:11 --> Router Class Initialized
ERROR - 2017-02-10 07:07:11 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:07:11 --> Output Class Initialized
INFO - 2017-02-10 07:07:11 --> Security Class Initialized
DEBUG - 2017-02-10 07:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:07:11 --> Input Class Initialized
INFO - 2017-02-10 07:07:11 --> Language Class Initialized
ERROR - 2017-02-10 07:07:11 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:07:11 --> Config Class Initialized
INFO - 2017-02-10 07:07:11 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:07:11 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:07:11 --> Utf8 Class Initialized
INFO - 2017-02-10 07:07:11 --> URI Class Initialized
INFO - 2017-02-10 07:07:11 --> Router Class Initialized
INFO - 2017-02-10 07:07:11 --> Output Class Initialized
INFO - 2017-02-10 07:07:11 --> Security Class Initialized
DEBUG - 2017-02-10 07:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:07:11 --> Input Class Initialized
INFO - 2017-02-10 07:07:11 --> Language Class Initialized
ERROR - 2017-02-10 07:07:11 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:10:41 --> Config Class Initialized
INFO - 2017-02-10 07:10:41 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:10:41 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:10:41 --> Utf8 Class Initialized
INFO - 2017-02-10 07:10:41 --> URI Class Initialized
INFO - 2017-02-10 07:10:41 --> Router Class Initialized
INFO - 2017-02-10 07:10:41 --> Output Class Initialized
INFO - 2017-02-10 07:10:41 --> Security Class Initialized
DEBUG - 2017-02-10 07:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:10:41 --> Input Class Initialized
INFO - 2017-02-10 07:10:41 --> Language Class Initialized
INFO - 2017-02-10 07:10:41 --> Language Class Initialized
INFO - 2017-02-10 07:10:41 --> Config Class Initialized
INFO - 2017-02-10 07:10:41 --> Loader Class Initialized
INFO - 2017-02-10 07:10:41 --> Helper loaded: form_helper
INFO - 2017-02-10 07:10:41 --> Helper loaded: url_helper
INFO - 2017-02-10 07:10:41 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:10:41 --> Database Driver Class Initialized
INFO - 2017-02-10 07:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:10:41 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:10:41 --> Template Class Initialized
INFO - 2017-02-10 07:10:41 --> Controller Class Initialized
INFO - 2017-02-10 07:10:41 --> Model Class Initialized
INFO - 2017-02-10 07:10:41 --> Model Class Initialized
INFO - 2017-02-10 07:10:41 --> Model Class Initialized
DEBUG - 2017-02-10 07:10:41 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:10:41 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:10:41 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:10:41 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:10:41 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:10:41 --> Final output sent to browser
DEBUG - 2017-02-10 07:10:41 --> Total execution time: 0.0747
INFO - 2017-02-10 07:10:41 --> Config Class Initialized
INFO - 2017-02-10 07:10:41 --> Hooks Class Initialized
INFO - 2017-02-10 07:10:41 --> Config Class Initialized
INFO - 2017-02-10 07:10:41 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:10:41 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:10:41 --> Utf8 Class Initialized
INFO - 2017-02-10 07:10:41 --> URI Class Initialized
DEBUG - 2017-02-10 07:10:41 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:10:41 --> Utf8 Class Initialized
INFO - 2017-02-10 07:10:41 --> Router Class Initialized
INFO - 2017-02-10 07:10:41 --> URI Class Initialized
INFO - 2017-02-10 07:10:41 --> Output Class Initialized
INFO - 2017-02-10 07:10:41 --> Security Class Initialized
DEBUG - 2017-02-10 07:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:10:41 --> Input Class Initialized
INFO - 2017-02-10 07:10:41 --> Router Class Initialized
INFO - 2017-02-10 07:10:41 --> Language Class Initialized
ERROR - 2017-02-10 07:10:41 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:10:41 --> Output Class Initialized
INFO - 2017-02-10 07:10:41 --> Security Class Initialized
DEBUG - 2017-02-10 07:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:10:41 --> Input Class Initialized
INFO - 2017-02-10 07:10:41 --> Language Class Initialized
ERROR - 2017-02-10 07:10:41 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:10:41 --> Config Class Initialized
INFO - 2017-02-10 07:10:41 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:10:41 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:10:41 --> Utf8 Class Initialized
INFO - 2017-02-10 07:10:41 --> URI Class Initialized
INFO - 2017-02-10 07:10:41 --> Router Class Initialized
INFO - 2017-02-10 07:10:41 --> Output Class Initialized
INFO - 2017-02-10 07:10:41 --> Security Class Initialized
DEBUG - 2017-02-10 07:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:10:41 --> Input Class Initialized
INFO - 2017-02-10 07:10:41 --> Language Class Initialized
ERROR - 2017-02-10 07:10:41 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:10:42 --> Config Class Initialized
INFO - 2017-02-10 07:10:42 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:10:42 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:10:42 --> Utf8 Class Initialized
INFO - 2017-02-10 07:10:42 --> URI Class Initialized
INFO - 2017-02-10 07:10:42 --> Router Class Initialized
INFO - 2017-02-10 07:10:42 --> Output Class Initialized
INFO - 2017-02-10 07:10:42 --> Security Class Initialized
DEBUG - 2017-02-10 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:10:42 --> Input Class Initialized
INFO - 2017-02-10 07:10:42 --> Language Class Initialized
INFO - 2017-02-10 07:10:42 --> Language Class Initialized
INFO - 2017-02-10 07:10:42 --> Config Class Initialized
INFO - 2017-02-10 07:10:42 --> Loader Class Initialized
INFO - 2017-02-10 07:10:42 --> Helper loaded: form_helper
INFO - 2017-02-10 07:10:42 --> Helper loaded: url_helper
INFO - 2017-02-10 07:10:42 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:10:42 --> Database Driver Class Initialized
INFO - 2017-02-10 07:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:10:42 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:10:42 --> Template Class Initialized
INFO - 2017-02-10 07:10:42 --> Controller Class Initialized
INFO - 2017-02-10 07:10:42 --> Model Class Initialized
INFO - 2017-02-10 07:10:42 --> Model Class Initialized
INFO - 2017-02-10 07:10:42 --> Model Class Initialized
DEBUG - 2017-02-10 07:10:42 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:10:42 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:10:42 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:10:42 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:10:42 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:10:42 --> Final output sent to browser
DEBUG - 2017-02-10 07:10:42 --> Total execution time: 0.0645
INFO - 2017-02-10 07:10:42 --> Config Class Initialized
INFO - 2017-02-10 07:10:42 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:10:42 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:10:42 --> Utf8 Class Initialized
INFO - 2017-02-10 07:10:42 --> Config Class Initialized
INFO - 2017-02-10 07:10:42 --> Hooks Class Initialized
INFO - 2017-02-10 07:10:42 --> URI Class Initialized
INFO - 2017-02-10 07:10:42 --> Router Class Initialized
DEBUG - 2017-02-10 07:10:42 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:10:42 --> Utf8 Class Initialized
INFO - 2017-02-10 07:10:42 --> URI Class Initialized
INFO - 2017-02-10 07:10:42 --> Output Class Initialized
INFO - 2017-02-10 07:10:42 --> Security Class Initialized
INFO - 2017-02-10 07:10:42 --> Router Class Initialized
DEBUG - 2017-02-10 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:10:42 --> Input Class Initialized
INFO - 2017-02-10 07:10:42 --> Language Class Initialized
INFO - 2017-02-10 07:10:42 --> Output Class Initialized
ERROR - 2017-02-10 07:10:42 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:10:42 --> Security Class Initialized
DEBUG - 2017-02-10 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:10:42 --> Input Class Initialized
INFO - 2017-02-10 07:10:42 --> Language Class Initialized
ERROR - 2017-02-10 07:10:42 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:10:42 --> Config Class Initialized
INFO - 2017-02-10 07:10:42 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:10:42 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:10:42 --> Utf8 Class Initialized
INFO - 2017-02-10 07:10:42 --> URI Class Initialized
INFO - 2017-02-10 07:10:42 --> Router Class Initialized
INFO - 2017-02-10 07:10:42 --> Output Class Initialized
INFO - 2017-02-10 07:10:42 --> Security Class Initialized
DEBUG - 2017-02-10 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:10:42 --> Input Class Initialized
INFO - 2017-02-10 07:10:42 --> Language Class Initialized
ERROR - 2017-02-10 07:10:42 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:10:43 --> Config Class Initialized
INFO - 2017-02-10 07:10:43 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:10:43 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:10:43 --> Utf8 Class Initialized
INFO - 2017-02-10 07:10:43 --> URI Class Initialized
INFO - 2017-02-10 07:10:43 --> Router Class Initialized
INFO - 2017-02-10 07:10:43 --> Output Class Initialized
INFO - 2017-02-10 07:10:43 --> Security Class Initialized
DEBUG - 2017-02-10 07:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:10:43 --> Input Class Initialized
INFO - 2017-02-10 07:10:43 --> Language Class Initialized
INFO - 2017-02-10 07:10:43 --> Language Class Initialized
INFO - 2017-02-10 07:10:43 --> Config Class Initialized
INFO - 2017-02-10 07:10:43 --> Loader Class Initialized
INFO - 2017-02-10 07:10:43 --> Helper loaded: form_helper
INFO - 2017-02-10 07:10:43 --> Helper loaded: url_helper
INFO - 2017-02-10 07:10:43 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:10:43 --> Database Driver Class Initialized
INFO - 2017-02-10 07:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:10:43 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:10:43 --> Template Class Initialized
INFO - 2017-02-10 07:10:43 --> Controller Class Initialized
INFO - 2017-02-10 07:10:43 --> Model Class Initialized
INFO - 2017-02-10 07:10:43 --> Model Class Initialized
INFO - 2017-02-10 07:10:43 --> Model Class Initialized
DEBUG - 2017-02-10 07:10:43 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:10:43 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:10:43 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:10:43 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:10:43 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:10:43 --> Final output sent to browser
DEBUG - 2017-02-10 07:10:43 --> Total execution time: 0.0412
INFO - 2017-02-10 07:10:43 --> Config Class Initialized
INFO - 2017-02-10 07:10:43 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:10:43 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:10:43 --> Utf8 Class Initialized
INFO - 2017-02-10 07:10:43 --> Config Class Initialized
INFO - 2017-02-10 07:10:43 --> Hooks Class Initialized
INFO - 2017-02-10 07:10:43 --> URI Class Initialized
DEBUG - 2017-02-10 07:10:43 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:10:43 --> Utf8 Class Initialized
INFO - 2017-02-10 07:10:43 --> Router Class Initialized
INFO - 2017-02-10 07:10:43 --> URI Class Initialized
INFO - 2017-02-10 07:10:43 --> Output Class Initialized
INFO - 2017-02-10 07:10:43 --> Security Class Initialized
DEBUG - 2017-02-10 07:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:10:43 --> Router Class Initialized
INFO - 2017-02-10 07:10:43 --> Input Class Initialized
INFO - 2017-02-10 07:10:43 --> Language Class Initialized
ERROR - 2017-02-10 07:10:43 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:10:43 --> Output Class Initialized
INFO - 2017-02-10 07:10:43 --> Security Class Initialized
DEBUG - 2017-02-10 07:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:10:43 --> Input Class Initialized
INFO - 2017-02-10 07:10:43 --> Language Class Initialized
ERROR - 2017-02-10 07:10:43 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:10:43 --> Config Class Initialized
INFO - 2017-02-10 07:10:43 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:10:44 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:10:44 --> Utf8 Class Initialized
INFO - 2017-02-10 07:10:44 --> URI Class Initialized
INFO - 2017-02-10 07:10:44 --> Router Class Initialized
INFO - 2017-02-10 07:10:44 --> Output Class Initialized
INFO - 2017-02-10 07:10:44 --> Security Class Initialized
DEBUG - 2017-02-10 07:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:10:44 --> Input Class Initialized
INFO - 2017-02-10 07:10:44 --> Language Class Initialized
ERROR - 2017-02-10 07:10:44 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:11:05 --> Config Class Initialized
INFO - 2017-02-10 07:11:05 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:11:05 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:11:05 --> Utf8 Class Initialized
INFO - 2017-02-10 07:11:05 --> URI Class Initialized
INFO - 2017-02-10 07:11:05 --> Router Class Initialized
INFO - 2017-02-10 07:11:05 --> Output Class Initialized
INFO - 2017-02-10 07:11:05 --> Security Class Initialized
DEBUG - 2017-02-10 07:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:11:05 --> Input Class Initialized
INFO - 2017-02-10 07:11:05 --> Language Class Initialized
INFO - 2017-02-10 07:11:05 --> Language Class Initialized
INFO - 2017-02-10 07:11:05 --> Config Class Initialized
INFO - 2017-02-10 07:11:05 --> Loader Class Initialized
INFO - 2017-02-10 07:11:05 --> Helper loaded: form_helper
INFO - 2017-02-10 07:11:05 --> Helper loaded: url_helper
INFO - 2017-02-10 07:11:05 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:11:05 --> Database Driver Class Initialized
INFO - 2017-02-10 07:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:11:05 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:11:05 --> Template Class Initialized
INFO - 2017-02-10 07:11:05 --> Controller Class Initialized
INFO - 2017-02-10 07:11:05 --> Model Class Initialized
INFO - 2017-02-10 07:11:05 --> Model Class Initialized
INFO - 2017-02-10 07:11:05 --> Model Class Initialized
DEBUG - 2017-02-10 07:11:05 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:11:05 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:11:05 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:11:05 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:11:05 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:11:05 --> Final output sent to browser
DEBUG - 2017-02-10 07:11:05 --> Total execution time: 0.0656
INFO - 2017-02-10 07:11:05 --> Config Class Initialized
INFO - 2017-02-10 07:11:05 --> Hooks Class Initialized
INFO - 2017-02-10 07:11:05 --> Config Class Initialized
INFO - 2017-02-10 07:11:05 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:11:05 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:11:05 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:11:05 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:11:05 --> Utf8 Class Initialized
INFO - 2017-02-10 07:11:05 --> URI Class Initialized
INFO - 2017-02-10 07:11:05 --> URI Class Initialized
INFO - 2017-02-10 07:11:05 --> Router Class Initialized
INFO - 2017-02-10 07:11:05 --> Router Class Initialized
INFO - 2017-02-10 07:11:05 --> Output Class Initialized
INFO - 2017-02-10 07:11:05 --> Security Class Initialized
INFO - 2017-02-10 07:11:05 --> Output Class Initialized
DEBUG - 2017-02-10 07:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:11:05 --> Security Class Initialized
INFO - 2017-02-10 07:11:05 --> Input Class Initialized
INFO - 2017-02-10 07:11:05 --> Language Class Initialized
DEBUG - 2017-02-10 07:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:11:05 --> Input Class Initialized
ERROR - 2017-02-10 07:11:05 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:11:05 --> Language Class Initialized
ERROR - 2017-02-10 07:11:05 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:11:05 --> Config Class Initialized
INFO - 2017-02-10 07:11:05 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:11:05 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:11:05 --> Utf8 Class Initialized
INFO - 2017-02-10 07:11:05 --> URI Class Initialized
INFO - 2017-02-10 07:11:05 --> Router Class Initialized
INFO - 2017-02-10 07:11:05 --> Output Class Initialized
INFO - 2017-02-10 07:11:05 --> Security Class Initialized
DEBUG - 2017-02-10 07:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:11:05 --> Input Class Initialized
INFO - 2017-02-10 07:11:05 --> Language Class Initialized
ERROR - 2017-02-10 07:11:05 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:11:06 --> Config Class Initialized
INFO - 2017-02-10 07:11:06 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:11:06 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:11:06 --> Utf8 Class Initialized
INFO - 2017-02-10 07:11:06 --> URI Class Initialized
INFO - 2017-02-10 07:11:06 --> Router Class Initialized
INFO - 2017-02-10 07:11:06 --> Output Class Initialized
INFO - 2017-02-10 07:11:06 --> Security Class Initialized
DEBUG - 2017-02-10 07:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:11:06 --> Input Class Initialized
INFO - 2017-02-10 07:11:06 --> Language Class Initialized
INFO - 2017-02-10 07:11:06 --> Language Class Initialized
INFO - 2017-02-10 07:11:06 --> Config Class Initialized
INFO - 2017-02-10 07:11:06 --> Loader Class Initialized
INFO - 2017-02-10 07:11:06 --> Helper loaded: form_helper
INFO - 2017-02-10 07:11:06 --> Helper loaded: url_helper
INFO - 2017-02-10 07:11:06 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:11:06 --> Database Driver Class Initialized
INFO - 2017-02-10 07:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:11:06 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:11:06 --> Template Class Initialized
INFO - 2017-02-10 07:11:06 --> Controller Class Initialized
INFO - 2017-02-10 07:11:06 --> Model Class Initialized
INFO - 2017-02-10 07:11:06 --> Model Class Initialized
INFO - 2017-02-10 07:11:06 --> Model Class Initialized
DEBUG - 2017-02-10 07:11:06 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:11:06 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:11:06 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:11:06 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:11:06 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:11:06 --> Final output sent to browser
DEBUG - 2017-02-10 07:11:06 --> Total execution time: 0.0823
INFO - 2017-02-10 07:11:06 --> Config Class Initialized
INFO - 2017-02-10 07:11:06 --> Hooks Class Initialized
INFO - 2017-02-10 07:11:06 --> Config Class Initialized
INFO - 2017-02-10 07:11:06 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:11:06 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:11:06 --> Utf8 Class Initialized
INFO - 2017-02-10 07:11:06 --> URI Class Initialized
DEBUG - 2017-02-10 07:11:06 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:11:06 --> Utf8 Class Initialized
INFO - 2017-02-10 07:11:06 --> Router Class Initialized
INFO - 2017-02-10 07:11:06 --> URI Class Initialized
INFO - 2017-02-10 07:11:06 --> Output Class Initialized
INFO - 2017-02-10 07:11:06 --> Security Class Initialized
DEBUG - 2017-02-10 07:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:11:06 --> Input Class Initialized
INFO - 2017-02-10 07:11:06 --> Language Class Initialized
INFO - 2017-02-10 07:11:06 --> Router Class Initialized
ERROR - 2017-02-10 07:11:06 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:11:06 --> Output Class Initialized
INFO - 2017-02-10 07:11:06 --> Security Class Initialized
DEBUG - 2017-02-10 07:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:11:06 --> Input Class Initialized
INFO - 2017-02-10 07:11:06 --> Language Class Initialized
ERROR - 2017-02-10 07:11:06 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:11:06 --> Config Class Initialized
INFO - 2017-02-10 07:11:06 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:11:06 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:11:06 --> Utf8 Class Initialized
INFO - 2017-02-10 07:11:06 --> URI Class Initialized
INFO - 2017-02-10 07:11:06 --> Router Class Initialized
INFO - 2017-02-10 07:11:06 --> Output Class Initialized
INFO - 2017-02-10 07:11:06 --> Security Class Initialized
DEBUG - 2017-02-10 07:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:11:06 --> Input Class Initialized
INFO - 2017-02-10 07:11:06 --> Language Class Initialized
ERROR - 2017-02-10 07:11:06 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:12:54 --> Config Class Initialized
INFO - 2017-02-10 07:12:54 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:12:54 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:54 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:54 --> URI Class Initialized
INFO - 2017-02-10 07:12:54 --> Router Class Initialized
INFO - 2017-02-10 07:12:54 --> Output Class Initialized
INFO - 2017-02-10 07:12:54 --> Security Class Initialized
DEBUG - 2017-02-10 07:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:54 --> Input Class Initialized
INFO - 2017-02-10 07:12:54 --> Language Class Initialized
INFO - 2017-02-10 07:12:54 --> Language Class Initialized
INFO - 2017-02-10 07:12:54 --> Config Class Initialized
INFO - 2017-02-10 07:12:54 --> Loader Class Initialized
INFO - 2017-02-10 07:12:54 --> Helper loaded: form_helper
INFO - 2017-02-10 07:12:54 --> Helper loaded: url_helper
INFO - 2017-02-10 07:12:54 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:12:54 --> Database Driver Class Initialized
INFO - 2017-02-10 07:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:12:54 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:12:54 --> Template Class Initialized
INFO - 2017-02-10 07:12:54 --> Controller Class Initialized
INFO - 2017-02-10 07:12:54 --> Model Class Initialized
INFO - 2017-02-10 07:12:54 --> Model Class Initialized
INFO - 2017-02-10 07:12:54 --> Model Class Initialized
DEBUG - 2017-02-10 07:12:54 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:12:54 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:12:54 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:12:54 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:12:54 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:12:54 --> Final output sent to browser
DEBUG - 2017-02-10 07:12:54 --> Total execution time: 0.0634
INFO - 2017-02-10 07:12:54 --> Config Class Initialized
INFO - 2017-02-10 07:12:54 --> Hooks Class Initialized
INFO - 2017-02-10 07:12:54 --> Config Class Initialized
DEBUG - 2017-02-10 07:12:54 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:54 --> Hooks Class Initialized
INFO - 2017-02-10 07:12:54 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:54 --> URI Class Initialized
DEBUG - 2017-02-10 07:12:54 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:54 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:54 --> URI Class Initialized
INFO - 2017-02-10 07:12:54 --> Router Class Initialized
INFO - 2017-02-10 07:12:54 --> Router Class Initialized
INFO - 2017-02-10 07:12:54 --> Output Class Initialized
INFO - 2017-02-10 07:12:54 --> Output Class Initialized
INFO - 2017-02-10 07:12:54 --> Security Class Initialized
INFO - 2017-02-10 07:12:54 --> Security Class Initialized
DEBUG - 2017-02-10 07:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-10 07:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:54 --> Input Class Initialized
INFO - 2017-02-10 07:12:54 --> Input Class Initialized
INFO - 2017-02-10 07:12:54 --> Language Class Initialized
INFO - 2017-02-10 07:12:54 --> Language Class Initialized
ERROR - 2017-02-10 07:12:54 --> 404 Page Not Found: /index
ERROR - 2017-02-10 07:12:54 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:12:54 --> Config Class Initialized
INFO - 2017-02-10 07:12:54 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:12:54 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:54 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:54 --> URI Class Initialized
INFO - 2017-02-10 07:12:54 --> Router Class Initialized
INFO - 2017-02-10 07:12:54 --> Output Class Initialized
INFO - 2017-02-10 07:12:54 --> Security Class Initialized
DEBUG - 2017-02-10 07:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:54 --> Input Class Initialized
INFO - 2017-02-10 07:12:54 --> Language Class Initialized
ERROR - 2017-02-10 07:12:54 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:12:55 --> Config Class Initialized
INFO - 2017-02-10 07:12:55 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:12:55 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:55 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:55 --> URI Class Initialized
INFO - 2017-02-10 07:12:55 --> Router Class Initialized
INFO - 2017-02-10 07:12:55 --> Output Class Initialized
INFO - 2017-02-10 07:12:55 --> Security Class Initialized
DEBUG - 2017-02-10 07:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:55 --> Input Class Initialized
INFO - 2017-02-10 07:12:55 --> Language Class Initialized
INFO - 2017-02-10 07:12:55 --> Language Class Initialized
INFO - 2017-02-10 07:12:55 --> Config Class Initialized
INFO - 2017-02-10 07:12:55 --> Loader Class Initialized
INFO - 2017-02-10 07:12:56 --> Helper loaded: form_helper
INFO - 2017-02-10 07:12:56 --> Helper loaded: url_helper
INFO - 2017-02-10 07:12:56 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:12:56 --> Database Driver Class Initialized
INFO - 2017-02-10 07:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:12:56 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:12:56 --> Template Class Initialized
INFO - 2017-02-10 07:12:56 --> Controller Class Initialized
INFO - 2017-02-10 07:12:56 --> Model Class Initialized
INFO - 2017-02-10 07:12:56 --> Model Class Initialized
INFO - 2017-02-10 07:12:56 --> Model Class Initialized
DEBUG - 2017-02-10 07:12:56 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:12:56 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:12:56 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:12:56 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:12:56 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:12:56 --> Final output sent to browser
DEBUG - 2017-02-10 07:12:56 --> Total execution time: 0.0950
INFO - 2017-02-10 07:12:56 --> Config Class Initialized
INFO - 2017-02-10 07:12:56 --> Hooks Class Initialized
INFO - 2017-02-10 07:12:56 --> Config Class Initialized
DEBUG - 2017-02-10 07:12:56 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:56 --> Hooks Class Initialized
INFO - 2017-02-10 07:12:56 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:56 --> URI Class Initialized
DEBUG - 2017-02-10 07:12:56 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:56 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:56 --> URI Class Initialized
INFO - 2017-02-10 07:12:56 --> Router Class Initialized
INFO - 2017-02-10 07:12:56 --> Output Class Initialized
INFO - 2017-02-10 07:12:56 --> Security Class Initialized
INFO - 2017-02-10 07:12:56 --> Router Class Initialized
DEBUG - 2017-02-10 07:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:56 --> Input Class Initialized
INFO - 2017-02-10 07:12:56 --> Language Class Initialized
INFO - 2017-02-10 07:12:56 --> Output Class Initialized
ERROR - 2017-02-10 07:12:56 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:12:56 --> Security Class Initialized
DEBUG - 2017-02-10 07:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:56 --> Input Class Initialized
INFO - 2017-02-10 07:12:56 --> Language Class Initialized
ERROR - 2017-02-10 07:12:56 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:12:56 --> Config Class Initialized
INFO - 2017-02-10 07:12:56 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:12:56 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:56 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:56 --> URI Class Initialized
INFO - 2017-02-10 07:12:56 --> Router Class Initialized
INFO - 2017-02-10 07:12:56 --> Output Class Initialized
INFO - 2017-02-10 07:12:56 --> Security Class Initialized
DEBUG - 2017-02-10 07:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:56 --> Input Class Initialized
INFO - 2017-02-10 07:12:56 --> Language Class Initialized
ERROR - 2017-02-10 07:12:56 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:12:57 --> Config Class Initialized
INFO - 2017-02-10 07:12:57 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:57 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:57 --> URI Class Initialized
INFO - 2017-02-10 07:12:57 --> Router Class Initialized
INFO - 2017-02-10 07:12:57 --> Output Class Initialized
INFO - 2017-02-10 07:12:57 --> Security Class Initialized
DEBUG - 2017-02-10 07:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:57 --> Input Class Initialized
INFO - 2017-02-10 07:12:57 --> Language Class Initialized
INFO - 2017-02-10 07:12:57 --> Language Class Initialized
INFO - 2017-02-10 07:12:57 --> Config Class Initialized
INFO - 2017-02-10 07:12:57 --> Loader Class Initialized
INFO - 2017-02-10 07:12:57 --> Helper loaded: form_helper
INFO - 2017-02-10 07:12:57 --> Helper loaded: url_helper
INFO - 2017-02-10 07:12:57 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:12:57 --> Database Driver Class Initialized
INFO - 2017-02-10 07:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:12:57 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:12:57 --> Template Class Initialized
INFO - 2017-02-10 07:12:57 --> Controller Class Initialized
INFO - 2017-02-10 07:12:57 --> Model Class Initialized
INFO - 2017-02-10 07:12:57 --> Model Class Initialized
INFO - 2017-02-10 07:12:57 --> Model Class Initialized
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:12:57 --> Final output sent to browser
DEBUG - 2017-02-10 07:12:57 --> Total execution time: 0.0822
INFO - 2017-02-10 07:12:57 --> Config Class Initialized
INFO - 2017-02-10 07:12:57 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:57 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:57 --> URI Class Initialized
INFO - 2017-02-10 07:12:57 --> Config Class Initialized
INFO - 2017-02-10 07:12:57 --> Hooks Class Initialized
INFO - 2017-02-10 07:12:57 --> Router Class Initialized
DEBUG - 2017-02-10 07:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:57 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:57 --> Output Class Initialized
INFO - 2017-02-10 07:12:57 --> URI Class Initialized
INFO - 2017-02-10 07:12:57 --> Security Class Initialized
DEBUG - 2017-02-10 07:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:57 --> Input Class Initialized
INFO - 2017-02-10 07:12:57 --> Router Class Initialized
INFO - 2017-02-10 07:12:57 --> Language Class Initialized
ERROR - 2017-02-10 07:12:57 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:12:57 --> Output Class Initialized
INFO - 2017-02-10 07:12:57 --> Security Class Initialized
DEBUG - 2017-02-10 07:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:57 --> Input Class Initialized
INFO - 2017-02-10 07:12:57 --> Language Class Initialized
ERROR - 2017-02-10 07:12:57 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:12:57 --> Config Class Initialized
INFO - 2017-02-10 07:12:57 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:57 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:57 --> URI Class Initialized
INFO - 2017-02-10 07:12:57 --> Router Class Initialized
INFO - 2017-02-10 07:12:57 --> Output Class Initialized
INFO - 2017-02-10 07:12:57 --> Security Class Initialized
DEBUG - 2017-02-10 07:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:57 --> Input Class Initialized
INFO - 2017-02-10 07:12:57 --> Language Class Initialized
ERROR - 2017-02-10 07:12:57 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:12:57 --> Config Class Initialized
INFO - 2017-02-10 07:12:57 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:57 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:57 --> URI Class Initialized
INFO - 2017-02-10 07:12:57 --> Router Class Initialized
INFO - 2017-02-10 07:12:57 --> Output Class Initialized
INFO - 2017-02-10 07:12:57 --> Security Class Initialized
DEBUG - 2017-02-10 07:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:57 --> Input Class Initialized
INFO - 2017-02-10 07:12:57 --> Language Class Initialized
INFO - 2017-02-10 07:12:57 --> Language Class Initialized
INFO - 2017-02-10 07:12:57 --> Config Class Initialized
INFO - 2017-02-10 07:12:57 --> Loader Class Initialized
INFO - 2017-02-10 07:12:57 --> Helper loaded: form_helper
INFO - 2017-02-10 07:12:57 --> Helper loaded: url_helper
INFO - 2017-02-10 07:12:57 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:12:57 --> Database Driver Class Initialized
INFO - 2017-02-10 07:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:12:57 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:12:57 --> Template Class Initialized
INFO - 2017-02-10 07:12:57 --> Controller Class Initialized
INFO - 2017-02-10 07:12:57 --> Model Class Initialized
INFO - 2017-02-10 07:12:57 --> Model Class Initialized
INFO - 2017-02-10 07:12:57 --> Model Class Initialized
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:12:57 --> Final output sent to browser
DEBUG - 2017-02-10 07:12:57 --> Total execution time: 0.0470
INFO - 2017-02-10 07:12:57 --> Config Class Initialized
INFO - 2017-02-10 07:12:57 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:57 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:57 --> Config Class Initialized
INFO - 2017-02-10 07:12:57 --> Hooks Class Initialized
INFO - 2017-02-10 07:12:57 --> URI Class Initialized
DEBUG - 2017-02-10 07:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:57 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:57 --> Router Class Initialized
INFO - 2017-02-10 07:12:57 --> URI Class Initialized
INFO - 2017-02-10 07:12:57 --> Output Class Initialized
INFO - 2017-02-10 07:12:57 --> Security Class Initialized
INFO - 2017-02-10 07:12:57 --> Router Class Initialized
DEBUG - 2017-02-10 07:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:57 --> Input Class Initialized
INFO - 2017-02-10 07:12:57 --> Language Class Initialized
INFO - 2017-02-10 07:12:57 --> Output Class Initialized
ERROR - 2017-02-10 07:12:57 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:12:57 --> Security Class Initialized
DEBUG - 2017-02-10 07:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:57 --> Input Class Initialized
INFO - 2017-02-10 07:12:57 --> Language Class Initialized
ERROR - 2017-02-10 07:12:57 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:12:57 --> Config Class Initialized
INFO - 2017-02-10 07:12:57 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:57 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:57 --> URI Class Initialized
INFO - 2017-02-10 07:12:57 --> Router Class Initialized
INFO - 2017-02-10 07:12:57 --> Output Class Initialized
INFO - 2017-02-10 07:12:57 --> Security Class Initialized
DEBUG - 2017-02-10 07:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:57 --> Input Class Initialized
INFO - 2017-02-10 07:12:57 --> Language Class Initialized
ERROR - 2017-02-10 07:12:57 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:12:57 --> Config Class Initialized
INFO - 2017-02-10 07:12:57 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:57 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:57 --> URI Class Initialized
INFO - 2017-02-10 07:12:57 --> Router Class Initialized
INFO - 2017-02-10 07:12:57 --> Output Class Initialized
INFO - 2017-02-10 07:12:57 --> Security Class Initialized
DEBUG - 2017-02-10 07:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:57 --> Input Class Initialized
INFO - 2017-02-10 07:12:57 --> Language Class Initialized
INFO - 2017-02-10 07:12:57 --> Language Class Initialized
INFO - 2017-02-10 07:12:57 --> Config Class Initialized
INFO - 2017-02-10 07:12:57 --> Loader Class Initialized
INFO - 2017-02-10 07:12:57 --> Helper loaded: form_helper
INFO - 2017-02-10 07:12:57 --> Helper loaded: url_helper
INFO - 2017-02-10 07:12:57 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:12:57 --> Database Driver Class Initialized
INFO - 2017-02-10 07:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:12:57 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:12:57 --> Template Class Initialized
INFO - 2017-02-10 07:12:57 --> Controller Class Initialized
INFO - 2017-02-10 07:12:57 --> Model Class Initialized
INFO - 2017-02-10 07:12:57 --> Model Class Initialized
INFO - 2017-02-10 07:12:57 --> Model Class Initialized
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:12:57 --> Final output sent to browser
DEBUG - 2017-02-10 07:12:57 --> Total execution time: 0.0950
INFO - 2017-02-10 07:12:57 --> Config Class Initialized
INFO - 2017-02-10 07:12:57 --> Hooks Class Initialized
INFO - 2017-02-10 07:12:57 --> Config Class Initialized
INFO - 2017-02-10 07:12:57 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:57 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:57 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:57 --> URI Class Initialized
INFO - 2017-02-10 07:12:57 --> URI Class Initialized
INFO - 2017-02-10 07:12:57 --> Router Class Initialized
INFO - 2017-02-10 07:12:57 --> Router Class Initialized
INFO - 2017-02-10 07:12:57 --> Output Class Initialized
INFO - 2017-02-10 07:12:57 --> Output Class Initialized
INFO - 2017-02-10 07:12:57 --> Security Class Initialized
INFO - 2017-02-10 07:12:57 --> Security Class Initialized
DEBUG - 2017-02-10 07:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:57 --> Input Class Initialized
DEBUG - 2017-02-10 07:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:57 --> Language Class Initialized
INFO - 2017-02-10 07:12:57 --> Input Class Initialized
INFO - 2017-02-10 07:12:57 --> Language Class Initialized
ERROR - 2017-02-10 07:12:57 --> 404 Page Not Found: /index
ERROR - 2017-02-10 07:12:57 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:12:57 --> Config Class Initialized
INFO - 2017-02-10 07:12:57 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:57 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:57 --> URI Class Initialized
INFO - 2017-02-10 07:12:57 --> Router Class Initialized
INFO - 2017-02-10 07:12:57 --> Output Class Initialized
INFO - 2017-02-10 07:12:57 --> Security Class Initialized
DEBUG - 2017-02-10 07:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:57 --> Input Class Initialized
INFO - 2017-02-10 07:12:57 --> Language Class Initialized
ERROR - 2017-02-10 07:12:57 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:12:57 --> Config Class Initialized
INFO - 2017-02-10 07:12:57 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:12:57 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:57 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:57 --> URI Class Initialized
INFO - 2017-02-10 07:12:57 --> Router Class Initialized
INFO - 2017-02-10 07:12:57 --> Output Class Initialized
INFO - 2017-02-10 07:12:57 --> Security Class Initialized
DEBUG - 2017-02-10 07:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:57 --> Input Class Initialized
INFO - 2017-02-10 07:12:57 --> Language Class Initialized
INFO - 2017-02-10 07:12:57 --> Language Class Initialized
INFO - 2017-02-10 07:12:57 --> Config Class Initialized
INFO - 2017-02-10 07:12:57 --> Loader Class Initialized
INFO - 2017-02-10 07:12:57 --> Helper loaded: form_helper
INFO - 2017-02-10 07:12:57 --> Helper loaded: url_helper
INFO - 2017-02-10 07:12:57 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:12:57 --> Database Driver Class Initialized
INFO - 2017-02-10 07:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:12:57 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:12:57 --> Template Class Initialized
INFO - 2017-02-10 07:12:57 --> Controller Class Initialized
INFO - 2017-02-10 07:12:57 --> Model Class Initialized
INFO - 2017-02-10 07:12:57 --> Model Class Initialized
INFO - 2017-02-10 07:12:57 --> Model Class Initialized
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:12:57 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:12:57 --> Final output sent to browser
DEBUG - 2017-02-10 07:12:57 --> Total execution time: 0.0499
INFO - 2017-02-10 07:12:58 --> Config Class Initialized
INFO - 2017-02-10 07:12:58 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:12:58 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:58 --> Config Class Initialized
INFO - 2017-02-10 07:12:58 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:58 --> URI Class Initialized
INFO - 2017-02-10 07:12:58 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:12:58 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:58 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:58 --> Router Class Initialized
INFO - 2017-02-10 07:12:58 --> URI Class Initialized
INFO - 2017-02-10 07:12:58 --> Output Class Initialized
INFO - 2017-02-10 07:12:58 --> Security Class Initialized
INFO - 2017-02-10 07:12:58 --> Router Class Initialized
DEBUG - 2017-02-10 07:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:58 --> Output Class Initialized
INFO - 2017-02-10 07:12:58 --> Input Class Initialized
INFO - 2017-02-10 07:12:58 --> Language Class Initialized
INFO - 2017-02-10 07:12:58 --> Security Class Initialized
ERROR - 2017-02-10 07:12:58 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:58 --> Input Class Initialized
INFO - 2017-02-10 07:12:58 --> Language Class Initialized
ERROR - 2017-02-10 07:12:58 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:12:58 --> Config Class Initialized
INFO - 2017-02-10 07:12:58 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:12:58 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:12:58 --> Utf8 Class Initialized
INFO - 2017-02-10 07:12:58 --> URI Class Initialized
INFO - 2017-02-10 07:12:58 --> Router Class Initialized
INFO - 2017-02-10 07:12:58 --> Output Class Initialized
INFO - 2017-02-10 07:12:58 --> Security Class Initialized
DEBUG - 2017-02-10 07:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:12:58 --> Input Class Initialized
INFO - 2017-02-10 07:12:58 --> Language Class Initialized
ERROR - 2017-02-10 07:12:58 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:13:20 --> Config Class Initialized
INFO - 2017-02-10 07:13:20 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:13:20 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:13:20 --> Utf8 Class Initialized
INFO - 2017-02-10 07:13:20 --> URI Class Initialized
INFO - 2017-02-10 07:13:20 --> Router Class Initialized
INFO - 2017-02-10 07:13:20 --> Output Class Initialized
INFO - 2017-02-10 07:13:20 --> Security Class Initialized
DEBUG - 2017-02-10 07:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:13:20 --> Input Class Initialized
INFO - 2017-02-10 07:13:20 --> Language Class Initialized
ERROR - 2017-02-10 07:13:20 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-10 07:13:23 --> Config Class Initialized
INFO - 2017-02-10 07:13:23 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:13:23 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:13:23 --> Utf8 Class Initialized
INFO - 2017-02-10 07:13:23 --> URI Class Initialized
INFO - 2017-02-10 07:13:23 --> Router Class Initialized
INFO - 2017-02-10 07:13:23 --> Output Class Initialized
INFO - 2017-02-10 07:13:23 --> Security Class Initialized
DEBUG - 2017-02-10 07:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:13:23 --> Input Class Initialized
INFO - 2017-02-10 07:13:23 --> Language Class Initialized
INFO - 2017-02-10 07:13:23 --> Language Class Initialized
INFO - 2017-02-10 07:13:23 --> Config Class Initialized
INFO - 2017-02-10 07:13:23 --> Loader Class Initialized
INFO - 2017-02-10 07:13:23 --> Helper loaded: form_helper
INFO - 2017-02-10 07:13:23 --> Helper loaded: url_helper
INFO - 2017-02-10 07:13:23 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:13:23 --> Database Driver Class Initialized
INFO - 2017-02-10 07:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:13:23 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:13:23 --> Template Class Initialized
INFO - 2017-02-10 07:13:23 --> Controller Class Initialized
INFO - 2017-02-10 07:13:23 --> Model Class Initialized
INFO - 2017-02-10 07:13:23 --> Model Class Initialized
INFO - 2017-02-10 07:13:23 --> Model Class Initialized
INFO - 2017-02-10 07:13:23 --> Model Class Initialized
ERROR - 2017-02-10 07:13:23 --> Severity: Error --> Access to undeclared static property: TABLES::$EMAIL_TEMPLATE C:\xampp\htdocs\mobile\application\models\Email_template_model.php 11
INFO - 2017-02-10 07:13:29 --> Config Class Initialized
INFO - 2017-02-10 07:13:29 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:13:29 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:13:29 --> Utf8 Class Initialized
INFO - 2017-02-10 07:13:29 --> URI Class Initialized
INFO - 2017-02-10 07:13:29 --> Router Class Initialized
INFO - 2017-02-10 07:13:29 --> Output Class Initialized
INFO - 2017-02-10 07:13:29 --> Security Class Initialized
DEBUG - 2017-02-10 07:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:13:29 --> Input Class Initialized
INFO - 2017-02-10 07:13:29 --> Language Class Initialized
INFO - 2017-02-10 07:13:29 --> Language Class Initialized
INFO - 2017-02-10 07:13:29 --> Config Class Initialized
INFO - 2017-02-10 07:13:29 --> Loader Class Initialized
INFO - 2017-02-10 07:13:29 --> Helper loaded: form_helper
INFO - 2017-02-10 07:13:29 --> Helper loaded: url_helper
INFO - 2017-02-10 07:13:29 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:13:29 --> Database Driver Class Initialized
INFO - 2017-02-10 07:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:13:29 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:13:29 --> Template Class Initialized
INFO - 2017-02-10 07:13:29 --> Controller Class Initialized
INFO - 2017-02-10 07:13:29 --> Model Class Initialized
INFO - 2017-02-10 07:13:29 --> Model Class Initialized
INFO - 2017-02-10 07:13:29 --> Model Class Initialized
INFO - 2017-02-10 07:13:29 --> Model Class Initialized
ERROR - 2017-02-10 07:13:29 --> Severity: Error --> Access to undeclared static property: TABLES::$EMAIL_TEMPLATE C:\xampp\htdocs\mobile\application\models\Email_template_model.php 11
INFO - 2017-02-10 07:13:32 --> Config Class Initialized
INFO - 2017-02-10 07:13:32 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:13:32 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:13:32 --> Utf8 Class Initialized
INFO - 2017-02-10 07:13:32 --> URI Class Initialized
INFO - 2017-02-10 07:13:32 --> Router Class Initialized
INFO - 2017-02-10 07:13:32 --> Output Class Initialized
INFO - 2017-02-10 07:13:32 --> Security Class Initialized
DEBUG - 2017-02-10 07:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:13:32 --> Input Class Initialized
INFO - 2017-02-10 07:13:32 --> Language Class Initialized
INFO - 2017-02-10 07:13:32 --> Language Class Initialized
INFO - 2017-02-10 07:13:32 --> Config Class Initialized
INFO - 2017-02-10 07:13:32 --> Loader Class Initialized
INFO - 2017-02-10 07:13:32 --> Helper loaded: form_helper
INFO - 2017-02-10 07:13:32 --> Helper loaded: url_helper
INFO - 2017-02-10 07:13:32 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:13:32 --> Database Driver Class Initialized
INFO - 2017-02-10 07:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:13:32 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:13:32 --> Template Class Initialized
INFO - 2017-02-10 07:13:32 --> Controller Class Initialized
INFO - 2017-02-10 07:13:32 --> Model Class Initialized
INFO - 2017-02-10 07:13:32 --> Model Class Initialized
INFO - 2017-02-10 07:13:32 --> Model Class Initialized
INFO - 2017-02-10 07:13:32 --> Model Class Initialized
ERROR - 2017-02-10 07:13:32 --> Severity: Error --> Access to undeclared static property: TABLES::$EMAIL_TEMPLATE C:\xampp\htdocs\mobile\application\models\Email_template_model.php 11
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Loader Class Initialized
INFO - 2017-02-10 07:14:07 --> Helper loaded: form_helper
INFO - 2017-02-10 07:14:07 --> Helper loaded: url_helper
INFO - 2017-02-10 07:14:07 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:14:07 --> Database Driver Class Initialized
INFO - 2017-02-10 07:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:14:07 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Template Class Initialized
INFO - 2017-02-10 07:14:07 --> Controller Class Initialized
INFO - 2017-02-10 07:14:07 --> Model Class Initialized
INFO - 2017-02-10 07:14:07 --> Model Class Initialized
INFO - 2017-02-10 07:14:07 --> Model Class Initialized
INFO - 2017-02-10 07:14:07 --> Model Class Initialized
DEBUG - 2017-02-10 07:14:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:14:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:14:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:14:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/email/email_templates_list.php
DEBUG - 2017-02-10 07:14:07 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:14:07 --> Final output sent to browser
DEBUG - 2017-02-10 07:14:07 --> Total execution time: 0.0549
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:14:07 --> Config Class Initialized
INFO - 2017-02-10 07:14:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:14:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:14:07 --> URI Class Initialized
INFO - 2017-02-10 07:14:07 --> Router Class Initialized
INFO - 2017-02-10 07:14:07 --> Output Class Initialized
INFO - 2017-02-10 07:14:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:14:07 --> Input Class Initialized
INFO - 2017-02-10 07:14:07 --> Language Class Initialized
ERROR - 2017-02-10 07:14:07 --> 404 Page Not Found: ../modules/backend/controllers//index
INFO - 2017-02-10 07:15:24 --> Config Class Initialized
INFO - 2017-02-10 07:15:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:15:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:15:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:15:24 --> URI Class Initialized
INFO - 2017-02-10 07:15:24 --> Router Class Initialized
INFO - 2017-02-10 07:15:24 --> Output Class Initialized
INFO - 2017-02-10 07:15:24 --> Security Class Initialized
DEBUG - 2017-02-10 07:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:15:24 --> Input Class Initialized
INFO - 2017-02-10 07:15:24 --> Language Class Initialized
INFO - 2017-02-10 07:15:24 --> Language Class Initialized
INFO - 2017-02-10 07:15:24 --> Config Class Initialized
INFO - 2017-02-10 07:15:24 --> Loader Class Initialized
INFO - 2017-02-10 07:15:24 --> Helper loaded: form_helper
INFO - 2017-02-10 07:15:24 --> Helper loaded: url_helper
INFO - 2017-02-10 07:15:24 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:15:24 --> Database Driver Class Initialized
INFO - 2017-02-10 07:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:15:24 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:15:24 --> Template Class Initialized
INFO - 2017-02-10 07:15:24 --> Controller Class Initialized
INFO - 2017-02-10 07:15:24 --> Model Class Initialized
INFO - 2017-02-10 07:15:24 --> Model Class Initialized
INFO - 2017-02-10 07:15:24 --> Model Class Initialized
DEBUG - 2017-02-10 07:15:24 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:15:24 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:15:24 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:15:24 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:15:24 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:15:24 --> Final output sent to browser
DEBUG - 2017-02-10 07:15:24 --> Total execution time: 0.0411
INFO - 2017-02-10 07:15:24 --> Config Class Initialized
INFO - 2017-02-10 07:15:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:15:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:15:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:15:24 --> Config Class Initialized
INFO - 2017-02-10 07:15:24 --> Hooks Class Initialized
INFO - 2017-02-10 07:15:24 --> URI Class Initialized
DEBUG - 2017-02-10 07:15:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:15:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:15:24 --> URI Class Initialized
INFO - 2017-02-10 07:15:24 --> Router Class Initialized
INFO - 2017-02-10 07:15:24 --> Output Class Initialized
INFO - 2017-02-10 07:15:24 --> Router Class Initialized
INFO - 2017-02-10 07:15:24 --> Security Class Initialized
INFO - 2017-02-10 07:15:24 --> Output Class Initialized
DEBUG - 2017-02-10 07:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:15:24 --> Input Class Initialized
INFO - 2017-02-10 07:15:24 --> Language Class Initialized
INFO - 2017-02-10 07:15:24 --> Security Class Initialized
ERROR - 2017-02-10 07:15:24 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:15:24 --> Input Class Initialized
INFO - 2017-02-10 07:15:24 --> Language Class Initialized
ERROR - 2017-02-10 07:15:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:15:24 --> Config Class Initialized
INFO - 2017-02-10 07:15:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:15:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:15:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:15:24 --> URI Class Initialized
INFO - 2017-02-10 07:15:24 --> Router Class Initialized
INFO - 2017-02-10 07:15:24 --> Output Class Initialized
INFO - 2017-02-10 07:15:24 --> Security Class Initialized
DEBUG - 2017-02-10 07:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:15:24 --> Input Class Initialized
INFO - 2017-02-10 07:15:24 --> Language Class Initialized
ERROR - 2017-02-10 07:15:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:15:26 --> Config Class Initialized
INFO - 2017-02-10 07:15:26 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:15:26 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:15:26 --> Utf8 Class Initialized
INFO - 2017-02-10 07:15:26 --> URI Class Initialized
INFO - 2017-02-10 07:15:26 --> Router Class Initialized
INFO - 2017-02-10 07:15:26 --> Output Class Initialized
INFO - 2017-02-10 07:15:26 --> Security Class Initialized
DEBUG - 2017-02-10 07:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:15:26 --> Input Class Initialized
INFO - 2017-02-10 07:15:26 --> Language Class Initialized
INFO - 2017-02-10 07:15:26 --> Language Class Initialized
INFO - 2017-02-10 07:15:26 --> Config Class Initialized
INFO - 2017-02-10 07:15:26 --> Loader Class Initialized
INFO - 2017-02-10 07:15:26 --> Helper loaded: form_helper
INFO - 2017-02-10 07:15:26 --> Helper loaded: url_helper
INFO - 2017-02-10 07:15:26 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:15:26 --> Database Driver Class Initialized
INFO - 2017-02-10 07:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:15:26 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:15:26 --> Template Class Initialized
INFO - 2017-02-10 07:15:26 --> Controller Class Initialized
INFO - 2017-02-10 07:15:26 --> Model Class Initialized
INFO - 2017-02-10 07:15:26 --> Model Class Initialized
INFO - 2017-02-10 07:15:26 --> Model Class Initialized
DEBUG - 2017-02-10 07:15:26 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:15:26 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:15:26 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:15:26 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:15:26 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:15:26 --> Final output sent to browser
DEBUG - 2017-02-10 07:15:26 --> Total execution time: 0.0708
INFO - 2017-02-10 07:15:26 --> Config Class Initialized
INFO - 2017-02-10 07:15:26 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:15:26 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:15:26 --> Utf8 Class Initialized
INFO - 2017-02-10 07:15:26 --> URI Class Initialized
INFO - 2017-02-10 07:15:26 --> Config Class Initialized
INFO - 2017-02-10 07:15:26 --> Hooks Class Initialized
INFO - 2017-02-10 07:15:26 --> Router Class Initialized
INFO - 2017-02-10 07:15:26 --> Output Class Initialized
DEBUG - 2017-02-10 07:15:26 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:15:26 --> Utf8 Class Initialized
INFO - 2017-02-10 07:15:26 --> Security Class Initialized
INFO - 2017-02-10 07:15:26 --> URI Class Initialized
DEBUG - 2017-02-10 07:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:15:26 --> Input Class Initialized
INFO - 2017-02-10 07:15:26 --> Language Class Initialized
ERROR - 2017-02-10 07:15:26 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:15:26 --> Router Class Initialized
INFO - 2017-02-10 07:15:26 --> Output Class Initialized
INFO - 2017-02-10 07:15:26 --> Security Class Initialized
DEBUG - 2017-02-10 07:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:15:26 --> Input Class Initialized
INFO - 2017-02-10 07:15:26 --> Language Class Initialized
ERROR - 2017-02-10 07:15:26 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:15:26 --> Config Class Initialized
INFO - 2017-02-10 07:15:26 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:15:26 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:15:26 --> Utf8 Class Initialized
INFO - 2017-02-10 07:15:26 --> URI Class Initialized
INFO - 2017-02-10 07:15:26 --> Router Class Initialized
INFO - 2017-02-10 07:15:26 --> Output Class Initialized
INFO - 2017-02-10 07:15:26 --> Security Class Initialized
DEBUG - 2017-02-10 07:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:15:26 --> Input Class Initialized
INFO - 2017-02-10 07:15:26 --> Language Class Initialized
ERROR - 2017-02-10 07:15:26 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Loader Class Initialized
INFO - 2017-02-10 07:16:02 --> Helper loaded: form_helper
INFO - 2017-02-10 07:16:02 --> Helper loaded: url_helper
INFO - 2017-02-10 07:16:02 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:16:02 --> Database Driver Class Initialized
INFO - 2017-02-10 07:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:16:02 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Template Class Initialized
INFO - 2017-02-10 07:16:02 --> Controller Class Initialized
INFO - 2017-02-10 07:16:02 --> Model Class Initialized
INFO - 2017-02-10 07:16:02 --> Model Class Initialized
INFO - 2017-02-10 07:16:02 --> Model Class Initialized
DEBUG - 2017-02-10 07:16:02 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:16:02 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:16:02 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:16:02 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:16:02 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:16:02 --> Final output sent to browser
DEBUG - 2017-02-10 07:16:02 --> Total execution time: 0.0497
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:02 --> Config Class Initialized
INFO - 2017-02-10 07:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:02 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:02 --> URI Class Initialized
INFO - 2017-02-10 07:16:02 --> Router Class Initialized
INFO - 2017-02-10 07:16:02 --> Output Class Initialized
INFO - 2017-02-10 07:16:02 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:02 --> Input Class Initialized
INFO - 2017-02-10 07:16:02 --> Language Class Initialized
ERROR - 2017-02-10 07:16:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Loader Class Initialized
INFO - 2017-02-10 07:16:24 --> Helper loaded: form_helper
INFO - 2017-02-10 07:16:24 --> Helper loaded: url_helper
INFO - 2017-02-10 07:16:24 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:16:24 --> Database Driver Class Initialized
INFO - 2017-02-10 07:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:16:24 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:16:24 --> Template Class Initialized
INFO - 2017-02-10 07:16:24 --> Controller Class Initialized
INFO - 2017-02-10 07:16:24 --> Model Class Initialized
INFO - 2017-02-10 07:16:24 --> Model Class Initialized
INFO - 2017-02-10 07:16:24 --> Model Class Initialized
DEBUG - 2017-02-10 07:16:24 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:16:24 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:16:24 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:16:24 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:16:24 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:16:24 --> Final output sent to browser
DEBUG - 2017-02-10 07:16:24 --> Total execution time: 0.0551
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
ERROR - 2017-02-10 07:16:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
ERROR - 2017-02-10 07:16:24 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
ERROR - 2017-02-10 07:16:24 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
ERROR - 2017-02-10 07:16:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
ERROR - 2017-02-10 07:16:24 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
ERROR - 2017-02-10 07:16:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
ERROR - 2017-02-10 07:16:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
ERROR - 2017-02-10 07:16:24 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
ERROR - 2017-02-10 07:16:24 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
ERROR - 2017-02-10 07:16:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
ERROR - 2017-02-10 07:16:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-10 07:16:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
ERROR - 2017-02-10 07:16:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
ERROR - 2017-02-10 07:16:24 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
ERROR - 2017-02-10 07:16:24 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
ERROR - 2017-02-10 07:16:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
ERROR - 2017-02-10 07:16:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
INFO - 2017-02-10 07:16:24 --> Router Class Initialized
INFO - 2017-02-10 07:16:24 --> Output Class Initialized
INFO - 2017-02-10 07:16:24 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:24 --> Input Class Initialized
INFO - 2017-02-10 07:16:24 --> Language Class Initialized
ERROR - 2017-02-10 07:16:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:24 --> Config Class Initialized
INFO - 2017-02-10 07:16:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:24 --> URI Class Initialized
INFO - 2017-02-10 07:16:25 --> Router Class Initialized
INFO - 2017-02-10 07:16:25 --> Output Class Initialized
INFO - 2017-02-10 07:16:25 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:25 --> Input Class Initialized
INFO - 2017-02-10 07:16:25 --> Language Class Initialized
ERROR - 2017-02-10 07:16:25 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:25 --> Config Class Initialized
INFO - 2017-02-10 07:16:25 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:25 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:25 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:25 --> URI Class Initialized
INFO - 2017-02-10 07:16:25 --> Router Class Initialized
INFO - 2017-02-10 07:16:25 --> Output Class Initialized
INFO - 2017-02-10 07:16:25 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:25 --> Input Class Initialized
INFO - 2017-02-10 07:16:25 --> Language Class Initialized
ERROR - 2017-02-10 07:16:25 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:25 --> Config Class Initialized
INFO - 2017-02-10 07:16:25 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:25 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:25 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:25 --> URI Class Initialized
INFO - 2017-02-10 07:16:25 --> Router Class Initialized
INFO - 2017-02-10 07:16:25 --> Output Class Initialized
INFO - 2017-02-10 07:16:25 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:25 --> Input Class Initialized
INFO - 2017-02-10 07:16:25 --> Language Class Initialized
ERROR - 2017-02-10 07:16:25 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:25 --> Config Class Initialized
INFO - 2017-02-10 07:16:25 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:25 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:25 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:25 --> URI Class Initialized
INFO - 2017-02-10 07:16:25 --> Router Class Initialized
INFO - 2017-02-10 07:16:25 --> Output Class Initialized
INFO - 2017-02-10 07:16:25 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:25 --> Input Class Initialized
INFO - 2017-02-10 07:16:25 --> Language Class Initialized
ERROR - 2017-02-10 07:16:25 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:25 --> Config Class Initialized
INFO - 2017-02-10 07:16:25 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:25 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:25 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:25 --> URI Class Initialized
INFO - 2017-02-10 07:16:25 --> Router Class Initialized
INFO - 2017-02-10 07:16:25 --> Output Class Initialized
INFO - 2017-02-10 07:16:25 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:25 --> Input Class Initialized
INFO - 2017-02-10 07:16:25 --> Language Class Initialized
ERROR - 2017-02-10 07:16:25 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:25 --> Config Class Initialized
INFO - 2017-02-10 07:16:25 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:25 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:25 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:25 --> URI Class Initialized
INFO - 2017-02-10 07:16:25 --> Router Class Initialized
INFO - 2017-02-10 07:16:25 --> Output Class Initialized
INFO - 2017-02-10 07:16:25 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:25 --> Input Class Initialized
INFO - 2017-02-10 07:16:25 --> Language Class Initialized
ERROR - 2017-02-10 07:16:25 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:25 --> Config Class Initialized
INFO - 2017-02-10 07:16:25 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:25 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:25 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:25 --> URI Class Initialized
INFO - 2017-02-10 07:16:25 --> Router Class Initialized
INFO - 2017-02-10 07:16:25 --> Output Class Initialized
INFO - 2017-02-10 07:16:25 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:25 --> Input Class Initialized
INFO - 2017-02-10 07:16:25 --> Language Class Initialized
ERROR - 2017-02-10 07:16:25 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:25 --> Config Class Initialized
INFO - 2017-02-10 07:16:25 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:25 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:25 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:25 --> URI Class Initialized
INFO - 2017-02-10 07:16:25 --> Router Class Initialized
INFO - 2017-02-10 07:16:25 --> Output Class Initialized
INFO - 2017-02-10 07:16:25 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:25 --> Input Class Initialized
INFO - 2017-02-10 07:16:25 --> Language Class Initialized
ERROR - 2017-02-10 07:16:25 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:25 --> Config Class Initialized
INFO - 2017-02-10 07:16:25 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:25 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:25 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:25 --> URI Class Initialized
INFO - 2017-02-10 07:16:25 --> Router Class Initialized
INFO - 2017-02-10 07:16:25 --> Output Class Initialized
INFO - 2017-02-10 07:16:25 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:25 --> Input Class Initialized
INFO - 2017-02-10 07:16:25 --> Language Class Initialized
ERROR - 2017-02-10 07:16:25 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:29 --> Config Class Initialized
INFO - 2017-02-10 07:16:29 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:29 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:29 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:29 --> URI Class Initialized
INFO - 2017-02-10 07:16:29 --> Router Class Initialized
INFO - 2017-02-10 07:16:29 --> Output Class Initialized
INFO - 2017-02-10 07:16:29 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:29 --> Input Class Initialized
INFO - 2017-02-10 07:16:29 --> Language Class Initialized
INFO - 2017-02-10 07:16:29 --> Language Class Initialized
INFO - 2017-02-10 07:16:29 --> Config Class Initialized
INFO - 2017-02-10 07:16:29 --> Loader Class Initialized
INFO - 2017-02-10 07:16:29 --> Helper loaded: form_helper
INFO - 2017-02-10 07:16:29 --> Helper loaded: url_helper
INFO - 2017-02-10 07:16:29 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:16:29 --> Database Driver Class Initialized
INFO - 2017-02-10 07:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:16:29 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:16:29 --> Template Class Initialized
INFO - 2017-02-10 07:16:29 --> Controller Class Initialized
INFO - 2017-02-10 07:16:29 --> Model Class Initialized
INFO - 2017-02-10 07:16:29 --> Model Class Initialized
INFO - 2017-02-10 07:16:29 --> Model Class Initialized
ERROR - 2017-02-10 07:16:29 --> Query error: Table 'mobile.mst_newsletter' doesn't exist - Invalid query: UPDATE `mst_newsletter` SET `newsletter_status` = '0'
WHERE `newsletter_id` = 20
INFO - 2017-02-10 07:16:29 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-10 07:16:32 --> Config Class Initialized
INFO - 2017-02-10 07:16:32 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:32 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:32 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:32 --> URI Class Initialized
INFO - 2017-02-10 07:16:32 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Loader Class Initialized
INFO - 2017-02-10 07:16:33 --> Helper loaded: form_helper
INFO - 2017-02-10 07:16:33 --> Helper loaded: url_helper
INFO - 2017-02-10 07:16:33 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:16:33 --> Database Driver Class Initialized
INFO - 2017-02-10 07:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:16:33 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Template Class Initialized
INFO - 2017-02-10 07:16:33 --> Controller Class Initialized
INFO - 2017-02-10 07:16:33 --> Model Class Initialized
INFO - 2017-02-10 07:16:33 --> Model Class Initialized
INFO - 2017-02-10 07:16:33 --> Model Class Initialized
DEBUG - 2017-02-10 07:16:33 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:16:33 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:16:33 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:16:33 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:16:33 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:16:33 --> Final output sent to browser
DEBUG - 2017-02-10 07:16:33 --> Total execution time: 0.0594
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:33 --> Config Class Initialized
INFO - 2017-02-10 07:16:33 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:33 --> URI Class Initialized
INFO - 2017-02-10 07:16:33 --> Router Class Initialized
INFO - 2017-02-10 07:16:33 --> Output Class Initialized
INFO - 2017-02-10 07:16:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:33 --> Input Class Initialized
INFO - 2017-02-10 07:16:33 --> Language Class Initialized
ERROR - 2017-02-10 07:16:33 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:16:35 --> Config Class Initialized
INFO - 2017-02-10 07:16:35 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:16:35 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:16:35 --> Utf8 Class Initialized
INFO - 2017-02-10 07:16:35 --> URI Class Initialized
INFO - 2017-02-10 07:16:35 --> Router Class Initialized
INFO - 2017-02-10 07:16:35 --> Output Class Initialized
INFO - 2017-02-10 07:16:35 --> Security Class Initialized
DEBUG - 2017-02-10 07:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:16:35 --> Input Class Initialized
INFO - 2017-02-10 07:16:35 --> Language Class Initialized
INFO - 2017-02-10 07:16:35 --> Language Class Initialized
INFO - 2017-02-10 07:16:35 --> Config Class Initialized
INFO - 2017-02-10 07:16:35 --> Loader Class Initialized
INFO - 2017-02-10 07:16:35 --> Helper loaded: form_helper
INFO - 2017-02-10 07:16:35 --> Helper loaded: url_helper
INFO - 2017-02-10 07:16:35 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:16:35 --> Database Driver Class Initialized
INFO - 2017-02-10 07:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:16:35 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:16:35 --> Template Class Initialized
INFO - 2017-02-10 07:16:35 --> Controller Class Initialized
INFO - 2017-02-10 07:16:35 --> Model Class Initialized
INFO - 2017-02-10 07:16:35 --> Model Class Initialized
INFO - 2017-02-10 07:16:35 --> Model Class Initialized
ERROR - 2017-02-10 07:16:35 --> Query error: Table 'mobile.mst_newsletter' doesn't exist - Invalid query: UPDATE `mst_newsletter` SET `newsletter_status` = '0'
WHERE `newsletter_id` = 19
INFO - 2017-02-10 07:16:35 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-10 07:17:07 --> Config Class Initialized
INFO - 2017-02-10 07:17:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:17:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:17:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:17:07 --> URI Class Initialized
INFO - 2017-02-10 07:17:07 --> Router Class Initialized
INFO - 2017-02-10 07:17:07 --> Output Class Initialized
INFO - 2017-02-10 07:17:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:17:07 --> Input Class Initialized
INFO - 2017-02-10 07:17:07 --> Language Class Initialized
INFO - 2017-02-10 07:17:07 --> Language Class Initialized
INFO - 2017-02-10 07:17:07 --> Config Class Initialized
INFO - 2017-02-10 07:17:07 --> Loader Class Initialized
INFO - 2017-02-10 07:17:07 --> Helper loaded: form_helper
INFO - 2017-02-10 07:17:07 --> Helper loaded: url_helper
INFO - 2017-02-10 07:17:07 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:17:07 --> Database Driver Class Initialized
INFO - 2017-02-10 07:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:17:07 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:17:07 --> Template Class Initialized
INFO - 2017-02-10 07:17:07 --> Controller Class Initialized
INFO - 2017-02-10 07:17:07 --> Model Class Initialized
INFO - 2017-02-10 07:17:07 --> Model Class Initialized
INFO - 2017-02-10 07:17:07 --> Model Class Initialized
DEBUG - 2017-02-10 07:17:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:17:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:17:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:17:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:17:07 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:17:07 --> Final output sent to browser
DEBUG - 2017-02-10 07:17:07 --> Total execution time: 0.0743
INFO - 2017-02-10 07:17:07 --> Config Class Initialized
INFO - 2017-02-10 07:17:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:17:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:17:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:17:07 --> URI Class Initialized
INFO - 2017-02-10 07:17:07 --> Router Class Initialized
INFO - 2017-02-10 07:17:07 --> Output Class Initialized
INFO - 2017-02-10 07:17:07 --> Config Class Initialized
INFO - 2017-02-10 07:17:07 --> Hooks Class Initialized
INFO - 2017-02-10 07:17:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:17:07 --> Input Class Initialized
DEBUG - 2017-02-10 07:17:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:17:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:17:07 --> Language Class Initialized
INFO - 2017-02-10 07:17:07 --> URI Class Initialized
ERROR - 2017-02-10 07:17:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:17:07 --> Router Class Initialized
INFO - 2017-02-10 07:17:07 --> Output Class Initialized
INFO - 2017-02-10 07:17:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:17:07 --> Input Class Initialized
INFO - 2017-02-10 07:17:07 --> Language Class Initialized
ERROR - 2017-02-10 07:17:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:17:07 --> Config Class Initialized
INFO - 2017-02-10 07:17:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:17:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:17:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:17:07 --> URI Class Initialized
INFO - 2017-02-10 07:17:07 --> Router Class Initialized
INFO - 2017-02-10 07:17:07 --> Output Class Initialized
INFO - 2017-02-10 07:17:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:17:07 --> Input Class Initialized
INFO - 2017-02-10 07:17:07 --> Language Class Initialized
ERROR - 2017-02-10 07:17:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:17:11 --> Config Class Initialized
INFO - 2017-02-10 07:17:11 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:17:11 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:17:11 --> Utf8 Class Initialized
INFO - 2017-02-10 07:17:11 --> URI Class Initialized
INFO - 2017-02-10 07:17:11 --> Router Class Initialized
INFO - 2017-02-10 07:17:11 --> Output Class Initialized
INFO - 2017-02-10 07:17:11 --> Security Class Initialized
DEBUG - 2017-02-10 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:17:11 --> Input Class Initialized
INFO - 2017-02-10 07:17:11 --> Language Class Initialized
INFO - 2017-02-10 07:17:11 --> Language Class Initialized
INFO - 2017-02-10 07:17:11 --> Config Class Initialized
INFO - 2017-02-10 07:17:11 --> Loader Class Initialized
INFO - 2017-02-10 07:17:11 --> Helper loaded: form_helper
INFO - 2017-02-10 07:17:11 --> Helper loaded: url_helper
INFO - 2017-02-10 07:17:11 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:17:11 --> Database Driver Class Initialized
INFO - 2017-02-10 07:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:17:11 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:17:11 --> Template Class Initialized
INFO - 2017-02-10 07:17:11 --> Controller Class Initialized
INFO - 2017-02-10 07:17:11 --> Model Class Initialized
INFO - 2017-02-10 07:17:11 --> Model Class Initialized
INFO - 2017-02-10 07:17:11 --> Model Class Initialized
ERROR - 2017-02-10 07:17:11 --> Query error: Table 'mobile.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `id` = '1'
INFO - 2017-02-10 07:17:11 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-10 07:17:34 --> Config Class Initialized
INFO - 2017-02-10 07:17:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:17:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:17:34 --> Utf8 Class Initialized
INFO - 2017-02-10 07:17:34 --> URI Class Initialized
INFO - 2017-02-10 07:17:34 --> Router Class Initialized
INFO - 2017-02-10 07:17:34 --> Output Class Initialized
INFO - 2017-02-10 07:17:34 --> Security Class Initialized
DEBUG - 2017-02-10 07:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:17:34 --> Input Class Initialized
INFO - 2017-02-10 07:17:34 --> Language Class Initialized
INFO - 2017-02-10 07:17:34 --> Language Class Initialized
INFO - 2017-02-10 07:17:34 --> Config Class Initialized
INFO - 2017-02-10 07:17:34 --> Loader Class Initialized
INFO - 2017-02-10 07:17:34 --> Helper loaded: form_helper
INFO - 2017-02-10 07:17:34 --> Helper loaded: url_helper
INFO - 2017-02-10 07:17:34 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:17:34 --> Database Driver Class Initialized
INFO - 2017-02-10 07:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:17:34 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:17:34 --> Template Class Initialized
INFO - 2017-02-10 07:17:34 --> Controller Class Initialized
INFO - 2017-02-10 07:17:34 --> Model Class Initialized
INFO - 2017-02-10 07:17:34 --> Model Class Initialized
INFO - 2017-02-10 07:17:34 --> Model Class Initialized
DEBUG - 2017-02-10 07:17:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:17:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:17:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:17:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:17:34 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:17:34 --> Final output sent to browser
DEBUG - 2017-02-10 07:17:34 --> Total execution time: 0.0418
INFO - 2017-02-10 07:18:06 --> Config Class Initialized
INFO - 2017-02-10 07:18:06 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:18:06 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:18:06 --> Utf8 Class Initialized
INFO - 2017-02-10 07:18:06 --> URI Class Initialized
INFO - 2017-02-10 07:18:06 --> Router Class Initialized
INFO - 2017-02-10 07:18:06 --> Output Class Initialized
INFO - 2017-02-10 07:18:06 --> Security Class Initialized
DEBUG - 2017-02-10 07:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:18:06 --> Input Class Initialized
INFO - 2017-02-10 07:18:06 --> Language Class Initialized
INFO - 2017-02-10 07:18:06 --> Language Class Initialized
INFO - 2017-02-10 07:18:06 --> Config Class Initialized
INFO - 2017-02-10 07:18:06 --> Loader Class Initialized
INFO - 2017-02-10 07:18:06 --> Helper loaded: form_helper
INFO - 2017-02-10 07:18:06 --> Helper loaded: url_helper
INFO - 2017-02-10 07:18:06 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:18:06 --> Database Driver Class Initialized
INFO - 2017-02-10 07:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:18:06 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:18:06 --> Template Class Initialized
INFO - 2017-02-10 07:18:06 --> Controller Class Initialized
INFO - 2017-02-10 07:18:06 --> Model Class Initialized
INFO - 2017-02-10 07:18:06 --> Model Class Initialized
INFO - 2017-02-10 07:18:06 --> Model Class Initialized
DEBUG - 2017-02-10 07:18:06 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:18:06 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:18:06 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:18:06 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:18:06 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:18:06 --> Final output sent to browser
DEBUG - 2017-02-10 07:18:06 --> Total execution time: 0.0820
INFO - 2017-02-10 07:18:06 --> Config Class Initialized
INFO - 2017-02-10 07:18:06 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:18:06 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:18:06 --> Utf8 Class Initialized
INFO - 2017-02-10 07:18:06 --> Config Class Initialized
INFO - 2017-02-10 07:18:06 --> Hooks Class Initialized
INFO - 2017-02-10 07:18:06 --> URI Class Initialized
DEBUG - 2017-02-10 07:18:06 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:18:06 --> Router Class Initialized
INFO - 2017-02-10 07:18:06 --> Utf8 Class Initialized
INFO - 2017-02-10 07:18:06 --> URI Class Initialized
INFO - 2017-02-10 07:18:06 --> Output Class Initialized
INFO - 2017-02-10 07:18:06 --> Security Class Initialized
DEBUG - 2017-02-10 07:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:18:06 --> Router Class Initialized
INFO - 2017-02-10 07:18:06 --> Input Class Initialized
INFO - 2017-02-10 07:18:06 --> Language Class Initialized
ERROR - 2017-02-10 07:18:06 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:18:06 --> Output Class Initialized
INFO - 2017-02-10 07:18:06 --> Security Class Initialized
DEBUG - 2017-02-10 07:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:18:06 --> Input Class Initialized
INFO - 2017-02-10 07:18:06 --> Language Class Initialized
ERROR - 2017-02-10 07:18:06 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:18:06 --> Config Class Initialized
INFO - 2017-02-10 07:18:06 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:18:06 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:18:06 --> Utf8 Class Initialized
INFO - 2017-02-10 07:18:06 --> URI Class Initialized
INFO - 2017-02-10 07:18:06 --> Router Class Initialized
INFO - 2017-02-10 07:18:06 --> Output Class Initialized
INFO - 2017-02-10 07:18:06 --> Security Class Initialized
DEBUG - 2017-02-10 07:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:18:06 --> Input Class Initialized
INFO - 2017-02-10 07:18:06 --> Language Class Initialized
ERROR - 2017-02-10 07:18:06 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:18:17 --> Config Class Initialized
INFO - 2017-02-10 07:18:17 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:18:17 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:18:17 --> Utf8 Class Initialized
INFO - 2017-02-10 07:18:17 --> URI Class Initialized
INFO - 2017-02-10 07:18:17 --> Router Class Initialized
INFO - 2017-02-10 07:18:17 --> Output Class Initialized
INFO - 2017-02-10 07:18:17 --> Security Class Initialized
DEBUG - 2017-02-10 07:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:18:17 --> Input Class Initialized
INFO - 2017-02-10 07:18:17 --> Language Class Initialized
INFO - 2017-02-10 07:18:17 --> Language Class Initialized
INFO - 2017-02-10 07:18:17 --> Config Class Initialized
INFO - 2017-02-10 07:18:17 --> Loader Class Initialized
INFO - 2017-02-10 07:18:17 --> Helper loaded: form_helper
INFO - 2017-02-10 07:18:17 --> Helper loaded: url_helper
INFO - 2017-02-10 07:18:17 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:18:17 --> Database Driver Class Initialized
INFO - 2017-02-10 07:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:18:17 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:18:17 --> Template Class Initialized
INFO - 2017-02-10 07:18:17 --> Controller Class Initialized
INFO - 2017-02-10 07:18:17 --> Model Class Initialized
INFO - 2017-02-10 07:18:17 --> Model Class Initialized
INFO - 2017-02-10 07:18:17 --> Model Class Initialized
DEBUG - 2017-02-10 07:18:17 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:18:17 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:18:17 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:18:17 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:18:17 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:18:17 --> Final output sent to browser
DEBUG - 2017-02-10 07:18:17 --> Total execution time: 0.0627
INFO - 2017-02-10 07:18:17 --> Config Class Initialized
INFO - 2017-02-10 07:18:17 --> Hooks Class Initialized
INFO - 2017-02-10 07:18:17 --> Config Class Initialized
INFO - 2017-02-10 07:18:17 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:18:17 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:18:17 --> Utf8 Class Initialized
INFO - 2017-02-10 07:18:17 --> URI Class Initialized
DEBUG - 2017-02-10 07:18:17 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:18:17 --> Utf8 Class Initialized
INFO - 2017-02-10 07:18:17 --> URI Class Initialized
INFO - 2017-02-10 07:18:17 --> Router Class Initialized
INFO - 2017-02-10 07:18:17 --> Output Class Initialized
INFO - 2017-02-10 07:18:17 --> Router Class Initialized
INFO - 2017-02-10 07:18:17 --> Security Class Initialized
INFO - 2017-02-10 07:18:17 --> Output Class Initialized
INFO - 2017-02-10 07:18:17 --> Security Class Initialized
DEBUG - 2017-02-10 07:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:18:17 --> Input Class Initialized
INFO - 2017-02-10 07:18:17 --> Language Class Initialized
DEBUG - 2017-02-10 07:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:18:17 --> Input Class Initialized
ERROR - 2017-02-10 07:18:17 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:18:17 --> Language Class Initialized
ERROR - 2017-02-10 07:18:17 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:18:17 --> Config Class Initialized
INFO - 2017-02-10 07:18:17 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:18:17 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:18:17 --> Utf8 Class Initialized
INFO - 2017-02-10 07:18:17 --> URI Class Initialized
INFO - 2017-02-10 07:18:17 --> Router Class Initialized
INFO - 2017-02-10 07:18:17 --> Output Class Initialized
INFO - 2017-02-10 07:18:17 --> Security Class Initialized
DEBUG - 2017-02-10 07:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:18:17 --> Input Class Initialized
INFO - 2017-02-10 07:18:17 --> Language Class Initialized
ERROR - 2017-02-10 07:18:17 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:18:20 --> Config Class Initialized
INFO - 2017-02-10 07:18:20 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:18:20 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:18:20 --> Utf8 Class Initialized
INFO - 2017-02-10 07:18:20 --> URI Class Initialized
INFO - 2017-02-10 07:18:20 --> Router Class Initialized
INFO - 2017-02-10 07:18:20 --> Output Class Initialized
INFO - 2017-02-10 07:18:20 --> Security Class Initialized
DEBUG - 2017-02-10 07:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:18:20 --> Input Class Initialized
INFO - 2017-02-10 07:18:20 --> Language Class Initialized
INFO - 2017-02-10 07:18:20 --> Language Class Initialized
INFO - 2017-02-10 07:18:20 --> Config Class Initialized
INFO - 2017-02-10 07:18:20 --> Loader Class Initialized
INFO - 2017-02-10 07:18:20 --> Helper loaded: form_helper
INFO - 2017-02-10 07:18:20 --> Helper loaded: url_helper
INFO - 2017-02-10 07:18:20 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:18:20 --> Database Driver Class Initialized
INFO - 2017-02-10 07:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:18:20 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:18:20 --> Template Class Initialized
INFO - 2017-02-10 07:18:20 --> Controller Class Initialized
INFO - 2017-02-10 07:18:20 --> Model Class Initialized
INFO - 2017-02-10 07:18:20 --> Model Class Initialized
INFO - 2017-02-10 07:18:20 --> Model Class Initialized
ERROR - 2017-02-10 07:18:20 --> Query error: Table 'mobile.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `id` = '1'
INFO - 2017-02-10 07:18:20 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-10 07:19:24 --> Config Class Initialized
INFO - 2017-02-10 07:19:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:19:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:19:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:19:24 --> URI Class Initialized
INFO - 2017-02-10 07:19:24 --> Router Class Initialized
INFO - 2017-02-10 07:19:24 --> Output Class Initialized
INFO - 2017-02-10 07:19:24 --> Security Class Initialized
DEBUG - 2017-02-10 07:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:19:24 --> Input Class Initialized
INFO - 2017-02-10 07:19:24 --> Language Class Initialized
INFO - 2017-02-10 07:19:24 --> Language Class Initialized
INFO - 2017-02-10 07:19:24 --> Config Class Initialized
INFO - 2017-02-10 07:19:24 --> Loader Class Initialized
INFO - 2017-02-10 07:19:24 --> Helper loaded: form_helper
INFO - 2017-02-10 07:19:24 --> Helper loaded: url_helper
INFO - 2017-02-10 07:19:24 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:19:24 --> Database Driver Class Initialized
INFO - 2017-02-10 07:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:19:24 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:19:24 --> Template Class Initialized
INFO - 2017-02-10 07:19:24 --> Controller Class Initialized
INFO - 2017-02-10 07:19:24 --> Model Class Initialized
INFO - 2017-02-10 07:19:24 --> Model Class Initialized
INFO - 2017-02-10 07:19:24 --> Model Class Initialized
DEBUG - 2017-02-10 07:19:24 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:19:24 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:19:24 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:19:24 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_add.php
DEBUG - 2017-02-10 07:19:24 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:19:24 --> Final output sent to browser
DEBUG - 2017-02-10 07:19:24 --> Total execution time: 0.1151
INFO - 2017-02-10 07:19:24 --> Config Class Initialized
INFO - 2017-02-10 07:19:24 --> Hooks Class Initialized
INFO - 2017-02-10 07:19:24 --> Config Class Initialized
INFO - 2017-02-10 07:19:24 --> Hooks Class Initialized
INFO - 2017-02-10 07:19:24 --> Config Class Initialized
INFO - 2017-02-10 07:19:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:19:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:19:24 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:19:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:19:24 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:19:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:19:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:19:24 --> URI Class Initialized
INFO - 2017-02-10 07:19:24 --> URI Class Initialized
INFO - 2017-02-10 07:19:24 --> URI Class Initialized
INFO - 2017-02-10 07:19:24 --> Router Class Initialized
INFO - 2017-02-10 07:19:24 --> Router Class Initialized
INFO - 2017-02-10 07:19:24 --> Router Class Initialized
INFO - 2017-02-10 07:19:24 --> Output Class Initialized
INFO - 2017-02-10 07:19:24 --> Output Class Initialized
INFO - 2017-02-10 07:19:24 --> Security Class Initialized
INFO - 2017-02-10 07:19:24 --> Output Class Initialized
INFO - 2017-02-10 07:19:24 --> Security Class Initialized
DEBUG - 2017-02-10 07:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:19:24 --> Input Class Initialized
INFO - 2017-02-10 07:19:24 --> Security Class Initialized
DEBUG - 2017-02-10 07:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:19:24 --> Input Class Initialized
INFO - 2017-02-10 07:19:24 --> Language Class Initialized
INFO - 2017-02-10 07:19:24 --> Language Class Initialized
ERROR - 2017-02-10 07:19:24 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:19:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-10 07:19:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:19:24 --> Input Class Initialized
INFO - 2017-02-10 07:19:24 --> Language Class Initialized
ERROR - 2017-02-10 07:19:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:19:24 --> Config Class Initialized
INFO - 2017-02-10 07:19:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:19:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:19:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:19:24 --> URI Class Initialized
INFO - 2017-02-10 07:19:24 --> Config Class Initialized
INFO - 2017-02-10 07:19:24 --> Hooks Class Initialized
INFO - 2017-02-10 07:19:24 --> Router Class Initialized
DEBUG - 2017-02-10 07:19:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:19:24 --> Utf8 Class Initialized
INFO - 2017-02-10 07:19:24 --> Output Class Initialized
INFO - 2017-02-10 07:19:24 --> URI Class Initialized
INFO - 2017-02-10 07:19:24 --> Security Class Initialized
DEBUG - 2017-02-10 07:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:19:24 --> Input Class Initialized
INFO - 2017-02-10 07:19:24 --> Router Class Initialized
INFO - 2017-02-10 07:19:24 --> Language Class Initialized
INFO - 2017-02-10 07:19:24 --> Output Class Initialized
ERROR - 2017-02-10 07:19:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:19:24 --> Security Class Initialized
DEBUG - 2017-02-10 07:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:19:24 --> Input Class Initialized
INFO - 2017-02-10 07:19:24 --> Language Class Initialized
ERROR - 2017-02-10 07:19:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:23:17 --> Config Class Initialized
INFO - 2017-02-10 07:23:17 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:23:17 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:23:17 --> Utf8 Class Initialized
INFO - 2017-02-10 07:23:17 --> URI Class Initialized
INFO - 2017-02-10 07:23:17 --> Router Class Initialized
INFO - 2017-02-10 07:23:17 --> Output Class Initialized
INFO - 2017-02-10 07:23:17 --> Security Class Initialized
DEBUG - 2017-02-10 07:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:23:17 --> Input Class Initialized
INFO - 2017-02-10 07:23:17 --> Language Class Initialized
INFO - 2017-02-10 07:23:17 --> Language Class Initialized
INFO - 2017-02-10 07:23:17 --> Config Class Initialized
INFO - 2017-02-10 07:23:17 --> Loader Class Initialized
INFO - 2017-02-10 07:23:17 --> Helper loaded: form_helper
INFO - 2017-02-10 07:23:17 --> Helper loaded: url_helper
INFO - 2017-02-10 07:23:17 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:23:17 --> Database Driver Class Initialized
INFO - 2017-02-10 07:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:23:18 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:23:18 --> Template Class Initialized
INFO - 2017-02-10 07:23:18 --> Controller Class Initialized
INFO - 2017-02-10 07:23:18 --> Model Class Initialized
INFO - 2017-02-10 07:23:18 --> Model Class Initialized
INFO - 2017-02-10 07:23:18 --> Model Class Initialized
DEBUG - 2017-02-10 07:23:18 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:23:18 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:23:18 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:23:18 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_add.php
DEBUG - 2017-02-10 07:23:18 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:23:18 --> Final output sent to browser
DEBUG - 2017-02-10 07:23:18 --> Total execution time: 0.1077
INFO - 2017-02-10 07:23:18 --> Config Class Initialized
INFO - 2017-02-10 07:23:18 --> Hooks Class Initialized
INFO - 2017-02-10 07:23:18 --> Config Class Initialized
INFO - 2017-02-10 07:23:18 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:23:18 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:23:18 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:23:18 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:23:18 --> Utf8 Class Initialized
INFO - 2017-02-10 07:23:18 --> URI Class Initialized
INFO - 2017-02-10 07:23:18 --> URI Class Initialized
INFO - 2017-02-10 07:23:18 --> Router Class Initialized
INFO - 2017-02-10 07:23:18 --> Router Class Initialized
INFO - 2017-02-10 07:23:18 --> Output Class Initialized
INFO - 2017-02-10 07:23:18 --> Security Class Initialized
INFO - 2017-02-10 07:23:18 --> Output Class Initialized
INFO - 2017-02-10 07:23:18 --> Config Class Initialized
DEBUG - 2017-02-10 07:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:23:18 --> Input Class Initialized
INFO - 2017-02-10 07:23:18 --> Security Class Initialized
INFO - 2017-02-10 07:23:18 --> Language Class Initialized
INFO - 2017-02-10 07:23:18 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:23:18 --> Input Class Initialized
ERROR - 2017-02-10 07:23:18 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:23:18 --> Language Class Initialized
ERROR - 2017-02-10 07:23:18 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:23:18 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:23:18 --> Utf8 Class Initialized
INFO - 2017-02-10 07:23:18 --> URI Class Initialized
INFO - 2017-02-10 07:23:18 --> Router Class Initialized
INFO - 2017-02-10 07:23:18 --> Output Class Initialized
INFO - 2017-02-10 07:23:18 --> Security Class Initialized
DEBUG - 2017-02-10 07:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:23:18 --> Input Class Initialized
INFO - 2017-02-10 07:23:18 --> Language Class Initialized
ERROR - 2017-02-10 07:23:18 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:23:18 --> Config Class Initialized
INFO - 2017-02-10 07:23:18 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:23:18 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:23:18 --> Utf8 Class Initialized
INFO - 2017-02-10 07:23:18 --> URI Class Initialized
INFO - 2017-02-10 07:23:18 --> Router Class Initialized
INFO - 2017-02-10 07:23:18 --> Output Class Initialized
INFO - 2017-02-10 07:23:18 --> Security Class Initialized
DEBUG - 2017-02-10 07:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:23:18 --> Input Class Initialized
INFO - 2017-02-10 07:23:18 --> Language Class Initialized
ERROR - 2017-02-10 07:23:18 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:23:37 --> Config Class Initialized
INFO - 2017-02-10 07:23:37 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:23:37 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:23:37 --> Utf8 Class Initialized
INFO - 2017-02-10 07:23:37 --> URI Class Initialized
INFO - 2017-02-10 07:23:37 --> Router Class Initialized
INFO - 2017-02-10 07:23:37 --> Output Class Initialized
INFO - 2017-02-10 07:23:37 --> Security Class Initialized
DEBUG - 2017-02-10 07:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:23:37 --> Input Class Initialized
INFO - 2017-02-10 07:23:37 --> Language Class Initialized
INFO - 2017-02-10 07:23:37 --> Language Class Initialized
INFO - 2017-02-10 07:23:37 --> Config Class Initialized
INFO - 2017-02-10 07:23:37 --> Loader Class Initialized
INFO - 2017-02-10 07:23:37 --> Helper loaded: form_helper
INFO - 2017-02-10 07:23:37 --> Helper loaded: url_helper
INFO - 2017-02-10 07:23:37 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:23:37 --> Database Driver Class Initialized
INFO - 2017-02-10 07:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:23:37 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:23:37 --> Template Class Initialized
INFO - 2017-02-10 07:23:37 --> Controller Class Initialized
INFO - 2017-02-10 07:23:37 --> Model Class Initialized
INFO - 2017-02-10 07:23:37 --> Model Class Initialized
INFO - 2017-02-10 07:23:37 --> Model Class Initialized
DEBUG - 2017-02-10 07:23:37 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:23:37 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:23:37 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:23:37 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_add.php
DEBUG - 2017-02-10 07:23:37 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:23:37 --> Final output sent to browser
DEBUG - 2017-02-10 07:23:37 --> Total execution time: 0.0549
INFO - 2017-02-10 07:23:37 --> Config Class Initialized
INFO - 2017-02-10 07:23:37 --> Hooks Class Initialized
INFO - 2017-02-10 07:23:37 --> Config Class Initialized
INFO - 2017-02-10 07:23:37 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:23:37 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:23:37 --> Utf8 Class Initialized
INFO - 2017-02-10 07:23:37 --> URI Class Initialized
DEBUG - 2017-02-10 07:23:37 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:23:37 --> Utf8 Class Initialized
INFO - 2017-02-10 07:23:37 --> URI Class Initialized
INFO - 2017-02-10 07:23:37 --> Router Class Initialized
INFO - 2017-02-10 07:23:37 --> Output Class Initialized
INFO - 2017-02-10 07:23:37 --> Router Class Initialized
INFO - 2017-02-10 07:23:37 --> Security Class Initialized
INFO - 2017-02-10 07:23:37 --> Output Class Initialized
DEBUG - 2017-02-10 07:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:23:37 --> Input Class Initialized
INFO - 2017-02-10 07:23:37 --> Security Class Initialized
INFO - 2017-02-10 07:23:37 --> Language Class Initialized
DEBUG - 2017-02-10 07:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:23:37 --> Input Class Initialized
ERROR - 2017-02-10 07:23:37 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:23:37 --> Language Class Initialized
ERROR - 2017-02-10 07:23:37 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:23:37 --> Config Class Initialized
INFO - 2017-02-10 07:23:37 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:23:37 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:23:37 --> Utf8 Class Initialized
INFO - 2017-02-10 07:23:37 --> URI Class Initialized
INFO - 2017-02-10 07:23:37 --> Router Class Initialized
INFO - 2017-02-10 07:23:37 --> Output Class Initialized
INFO - 2017-02-10 07:23:37 --> Security Class Initialized
DEBUG - 2017-02-10 07:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:23:37 --> Input Class Initialized
INFO - 2017-02-10 07:23:37 --> Language Class Initialized
ERROR - 2017-02-10 07:23:37 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:23:58 --> Config Class Initialized
INFO - 2017-02-10 07:23:58 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:23:58 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:23:58 --> Utf8 Class Initialized
INFO - 2017-02-10 07:23:58 --> URI Class Initialized
INFO - 2017-02-10 07:23:58 --> Router Class Initialized
INFO - 2017-02-10 07:23:58 --> Output Class Initialized
INFO - 2017-02-10 07:23:58 --> Security Class Initialized
DEBUG - 2017-02-10 07:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:23:58 --> Input Class Initialized
INFO - 2017-02-10 07:23:58 --> Language Class Initialized
INFO - 2017-02-10 07:23:58 --> Language Class Initialized
INFO - 2017-02-10 07:23:58 --> Config Class Initialized
INFO - 2017-02-10 07:23:58 --> Loader Class Initialized
INFO - 2017-02-10 07:23:58 --> Helper loaded: form_helper
INFO - 2017-02-10 07:23:58 --> Helper loaded: url_helper
INFO - 2017-02-10 07:23:58 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:23:58 --> Database Driver Class Initialized
INFO - 2017-02-10 07:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:23:58 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:23:58 --> Template Class Initialized
INFO - 2017-02-10 07:23:58 --> Controller Class Initialized
INFO - 2017-02-10 07:23:58 --> Model Class Initialized
INFO - 2017-02-10 07:23:58 --> Model Class Initialized
INFO - 2017-02-10 07:23:58 --> Model Class Initialized
INFO - 2017-02-10 07:23:58 --> Config Class Initialized
INFO - 2017-02-10 07:23:58 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:23:58 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:23:58 --> Utf8 Class Initialized
INFO - 2017-02-10 07:23:58 --> URI Class Initialized
INFO - 2017-02-10 07:23:58 --> Router Class Initialized
INFO - 2017-02-10 07:23:58 --> Output Class Initialized
INFO - 2017-02-10 07:23:58 --> Security Class Initialized
DEBUG - 2017-02-10 07:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:23:58 --> Input Class Initialized
INFO - 2017-02-10 07:23:58 --> Language Class Initialized
INFO - 2017-02-10 07:23:58 --> Language Class Initialized
INFO - 2017-02-10 07:23:58 --> Config Class Initialized
INFO - 2017-02-10 07:23:58 --> Loader Class Initialized
INFO - 2017-02-10 07:23:58 --> Helper loaded: form_helper
INFO - 2017-02-10 07:23:58 --> Helper loaded: url_helper
INFO - 2017-02-10 07:23:58 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:23:58 --> Database Driver Class Initialized
INFO - 2017-02-10 07:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:23:58 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:23:58 --> Template Class Initialized
INFO - 2017-02-10 07:23:58 --> Controller Class Initialized
INFO - 2017-02-10 07:23:58 --> Model Class Initialized
INFO - 2017-02-10 07:23:58 --> Model Class Initialized
INFO - 2017-02-10 07:23:58 --> Model Class Initialized
DEBUG - 2017-02-10 07:23:58 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:23:58 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:23:58 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:23:58 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:23:58 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:23:58 --> Final output sent to browser
DEBUG - 2017-02-10 07:23:58 --> Total execution time: 0.1052
INFO - 2017-02-10 07:23:58 --> Config Class Initialized
INFO - 2017-02-10 07:23:58 --> Config Class Initialized
INFO - 2017-02-10 07:23:58 --> Hooks Class Initialized
INFO - 2017-02-10 07:23:58 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:23:58 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 07:23:58 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:23:58 --> Utf8 Class Initialized
INFO - 2017-02-10 07:23:58 --> Utf8 Class Initialized
INFO - 2017-02-10 07:23:58 --> URI Class Initialized
INFO - 2017-02-10 07:23:58 --> URI Class Initialized
INFO - 2017-02-10 07:23:58 --> Router Class Initialized
INFO - 2017-02-10 07:23:58 --> Router Class Initialized
INFO - 2017-02-10 07:23:58 --> Output Class Initialized
INFO - 2017-02-10 07:23:58 --> Output Class Initialized
INFO - 2017-02-10 07:23:58 --> Security Class Initialized
INFO - 2017-02-10 07:23:58 --> Security Class Initialized
DEBUG - 2017-02-10 07:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-10 07:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:23:58 --> Input Class Initialized
INFO - 2017-02-10 07:23:58 --> Input Class Initialized
INFO - 2017-02-10 07:23:58 --> Language Class Initialized
INFO - 2017-02-10 07:23:58 --> Language Class Initialized
ERROR - 2017-02-10 07:23:58 --> 404 Page Not Found: /index
ERROR - 2017-02-10 07:23:58 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:23:58 --> Config Class Initialized
INFO - 2017-02-10 07:23:58 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:23:58 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:23:58 --> Utf8 Class Initialized
INFO - 2017-02-10 07:23:58 --> URI Class Initialized
INFO - 2017-02-10 07:23:58 --> Router Class Initialized
INFO - 2017-02-10 07:23:58 --> Output Class Initialized
INFO - 2017-02-10 07:23:58 --> Security Class Initialized
DEBUG - 2017-02-10 07:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:23:58 --> Input Class Initialized
INFO - 2017-02-10 07:23:58 --> Language Class Initialized
ERROR - 2017-02-10 07:23:58 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:24:04 --> Config Class Initialized
INFO - 2017-02-10 07:24:04 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:24:04 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:24:04 --> Utf8 Class Initialized
INFO - 2017-02-10 07:24:04 --> URI Class Initialized
INFO - 2017-02-10 07:24:04 --> Router Class Initialized
INFO - 2017-02-10 07:24:04 --> Output Class Initialized
INFO - 2017-02-10 07:24:04 --> Security Class Initialized
DEBUG - 2017-02-10 07:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:24:04 --> Input Class Initialized
INFO - 2017-02-10 07:24:04 --> Language Class Initialized
INFO - 2017-02-10 07:24:04 --> Language Class Initialized
INFO - 2017-02-10 07:24:04 --> Config Class Initialized
INFO - 2017-02-10 07:24:04 --> Loader Class Initialized
INFO - 2017-02-10 07:24:04 --> Helper loaded: form_helper
INFO - 2017-02-10 07:24:04 --> Helper loaded: url_helper
INFO - 2017-02-10 07:24:04 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:24:04 --> Database Driver Class Initialized
INFO - 2017-02-10 07:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:24:04 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:24:04 --> Template Class Initialized
INFO - 2017-02-10 07:24:04 --> Controller Class Initialized
INFO - 2017-02-10 07:24:04 --> Model Class Initialized
INFO - 2017-02-10 07:24:04 --> Model Class Initialized
INFO - 2017-02-10 07:24:04 --> Model Class Initialized
ERROR - 2017-02-10 07:24:04 --> Query error: Table 'mobile.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `id` = '1'
INFO - 2017-02-10 07:24:04 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-10 07:24:06 --> Config Class Initialized
INFO - 2017-02-10 07:24:06 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:24:06 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:24:06 --> Utf8 Class Initialized
INFO - 2017-02-10 07:24:06 --> URI Class Initialized
INFO - 2017-02-10 07:24:06 --> Router Class Initialized
INFO - 2017-02-10 07:24:06 --> Output Class Initialized
INFO - 2017-02-10 07:24:06 --> Security Class Initialized
DEBUG - 2017-02-10 07:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:24:06 --> Input Class Initialized
INFO - 2017-02-10 07:24:06 --> Language Class Initialized
INFO - 2017-02-10 07:24:06 --> Language Class Initialized
INFO - 2017-02-10 07:24:06 --> Config Class Initialized
INFO - 2017-02-10 07:24:06 --> Loader Class Initialized
INFO - 2017-02-10 07:24:06 --> Helper loaded: form_helper
INFO - 2017-02-10 07:24:06 --> Helper loaded: url_helper
INFO - 2017-02-10 07:24:06 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:24:06 --> Database Driver Class Initialized
INFO - 2017-02-10 07:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:24:06 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:24:06 --> Template Class Initialized
INFO - 2017-02-10 07:24:06 --> Controller Class Initialized
INFO - 2017-02-10 07:24:06 --> Model Class Initialized
INFO - 2017-02-10 07:24:06 --> Model Class Initialized
INFO - 2017-02-10 07:24:06 --> Model Class Initialized
DEBUG - 2017-02-10 07:24:06 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:24:06 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:24:06 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:24:06 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:24:06 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:24:06 --> Final output sent to browser
DEBUG - 2017-02-10 07:24:06 --> Total execution time: 0.0425
INFO - 2017-02-10 07:26:17 --> Config Class Initialized
INFO - 2017-02-10 07:26:17 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:26:17 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:26:17 --> Utf8 Class Initialized
INFO - 2017-02-10 07:26:17 --> URI Class Initialized
INFO - 2017-02-10 07:26:17 --> Router Class Initialized
INFO - 2017-02-10 07:26:17 --> Output Class Initialized
INFO - 2017-02-10 07:26:17 --> Security Class Initialized
DEBUG - 2017-02-10 07:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:26:17 --> Input Class Initialized
INFO - 2017-02-10 07:26:17 --> Language Class Initialized
INFO - 2017-02-10 07:26:17 --> Language Class Initialized
INFO - 2017-02-10 07:26:17 --> Config Class Initialized
INFO - 2017-02-10 07:26:17 --> Loader Class Initialized
INFO - 2017-02-10 07:26:17 --> Helper loaded: form_helper
INFO - 2017-02-10 07:26:17 --> Helper loaded: url_helper
INFO - 2017-02-10 07:26:17 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:26:17 --> Database Driver Class Initialized
INFO - 2017-02-10 07:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:26:17 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:26:17 --> Template Class Initialized
INFO - 2017-02-10 07:26:17 --> Controller Class Initialized
INFO - 2017-02-10 07:26:17 --> Model Class Initialized
INFO - 2017-02-10 07:26:17 --> Model Class Initialized
INFO - 2017-02-10 07:26:17 --> Model Class Initialized
DEBUG - 2017-02-10 07:26:17 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:26:17 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:26:17 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:26:17 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:26:17 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:26:17 --> Final output sent to browser
DEBUG - 2017-02-10 07:26:17 --> Total execution time: 0.0911
INFO - 2017-02-10 07:26:17 --> Config Class Initialized
INFO - 2017-02-10 07:26:17 --> Config Class Initialized
INFO - 2017-02-10 07:26:17 --> Hooks Class Initialized
INFO - 2017-02-10 07:26:17 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:26:17 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 07:26:17 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:26:17 --> Utf8 Class Initialized
INFO - 2017-02-10 07:26:17 --> Utf8 Class Initialized
INFO - 2017-02-10 07:26:17 --> URI Class Initialized
INFO - 2017-02-10 07:26:17 --> URI Class Initialized
INFO - 2017-02-10 07:26:17 --> Router Class Initialized
INFO - 2017-02-10 07:26:17 --> Router Class Initialized
INFO - 2017-02-10 07:26:17 --> Output Class Initialized
INFO - 2017-02-10 07:26:17 --> Output Class Initialized
INFO - 2017-02-10 07:26:17 --> Security Class Initialized
INFO - 2017-02-10 07:26:17 --> Security Class Initialized
DEBUG - 2017-02-10 07:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-10 07:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:26:17 --> Input Class Initialized
INFO - 2017-02-10 07:26:17 --> Input Class Initialized
INFO - 2017-02-10 07:26:17 --> Language Class Initialized
INFO - 2017-02-10 07:26:17 --> Language Class Initialized
ERROR - 2017-02-10 07:26:17 --> 404 Page Not Found: /index
ERROR - 2017-02-10 07:26:17 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:26:17 --> Config Class Initialized
INFO - 2017-02-10 07:26:17 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:26:17 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:26:17 --> Utf8 Class Initialized
INFO - 2017-02-10 07:26:17 --> URI Class Initialized
INFO - 2017-02-10 07:26:17 --> Router Class Initialized
INFO - 2017-02-10 07:26:17 --> Output Class Initialized
INFO - 2017-02-10 07:26:17 --> Security Class Initialized
DEBUG - 2017-02-10 07:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:26:17 --> Input Class Initialized
INFO - 2017-02-10 07:26:17 --> Language Class Initialized
ERROR - 2017-02-10 07:26:17 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:26:20 --> Config Class Initialized
INFO - 2017-02-10 07:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:26:20 --> Utf8 Class Initialized
INFO - 2017-02-10 07:26:20 --> URI Class Initialized
INFO - 2017-02-10 07:26:20 --> Router Class Initialized
INFO - 2017-02-10 07:26:20 --> Output Class Initialized
INFO - 2017-02-10 07:26:20 --> Security Class Initialized
DEBUG - 2017-02-10 07:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:26:20 --> Input Class Initialized
INFO - 2017-02-10 07:26:20 --> Language Class Initialized
INFO - 2017-02-10 07:26:20 --> Language Class Initialized
INFO - 2017-02-10 07:26:20 --> Config Class Initialized
INFO - 2017-02-10 07:26:20 --> Loader Class Initialized
INFO - 2017-02-10 07:26:20 --> Helper loaded: form_helper
INFO - 2017-02-10 07:26:20 --> Helper loaded: url_helper
INFO - 2017-02-10 07:26:20 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:26:20 --> Database Driver Class Initialized
INFO - 2017-02-10 07:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:26:20 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:26:20 --> Template Class Initialized
INFO - 2017-02-10 07:26:20 --> Controller Class Initialized
INFO - 2017-02-10 07:26:20 --> Model Class Initialized
INFO - 2017-02-10 07:26:20 --> Model Class Initialized
INFO - 2017-02-10 07:26:20 --> Model Class Initialized
DEBUG - 2017-02-10 07:26:20 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:26:20 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:26:20 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:26:20 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_edit.php
DEBUG - 2017-02-10 07:26:20 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:26:20 --> Final output sent to browser
DEBUG - 2017-02-10 07:26:20 --> Total execution time: 0.0545
INFO - 2017-02-10 07:26:20 --> Config Class Initialized
INFO - 2017-02-10 07:26:20 --> Hooks Class Initialized
INFO - 2017-02-10 07:26:20 --> Config Class Initialized
INFO - 2017-02-10 07:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:26:20 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 07:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:26:20 --> Utf8 Class Initialized
INFO - 2017-02-10 07:26:20 --> Utf8 Class Initialized
INFO - 2017-02-10 07:26:20 --> Config Class Initialized
INFO - 2017-02-10 07:26:20 --> URI Class Initialized
INFO - 2017-02-10 07:26:20 --> Hooks Class Initialized
INFO - 2017-02-10 07:26:20 --> URI Class Initialized
INFO - 2017-02-10 07:26:20 --> Router Class Initialized
INFO - 2017-02-10 07:26:20 --> Router Class Initialized
DEBUG - 2017-02-10 07:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:26:20 --> Utf8 Class Initialized
INFO - 2017-02-10 07:26:20 --> Output Class Initialized
INFO - 2017-02-10 07:26:20 --> Output Class Initialized
INFO - 2017-02-10 07:26:20 --> URI Class Initialized
INFO - 2017-02-10 07:26:20 --> Security Class Initialized
INFO - 2017-02-10 07:26:20 --> Security Class Initialized
DEBUG - 2017-02-10 07:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-10 07:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:26:20 --> Input Class Initialized
INFO - 2017-02-10 07:26:20 --> Input Class Initialized
INFO - 2017-02-10 07:26:20 --> Language Class Initialized
INFO - 2017-02-10 07:26:20 --> Language Class Initialized
ERROR - 2017-02-10 07:26:20 --> 404 Page Not Found: /index
ERROR - 2017-02-10 07:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:26:20 --> Router Class Initialized
INFO - 2017-02-10 07:26:20 --> Output Class Initialized
INFO - 2017-02-10 07:26:20 --> Security Class Initialized
DEBUG - 2017-02-10 07:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:26:20 --> Input Class Initialized
INFO - 2017-02-10 07:26:20 --> Language Class Initialized
ERROR - 2017-02-10 07:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:26:20 --> Config Class Initialized
INFO - 2017-02-10 07:26:20 --> Hooks Class Initialized
INFO - 2017-02-10 07:26:20 --> Config Class Initialized
INFO - 2017-02-10 07:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:26:20 --> Utf8 Class Initialized
INFO - 2017-02-10 07:26:20 --> URI Class Initialized
DEBUG - 2017-02-10 07:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:26:20 --> Utf8 Class Initialized
INFO - 2017-02-10 07:26:20 --> URI Class Initialized
INFO - 2017-02-10 07:26:20 --> Router Class Initialized
INFO - 2017-02-10 07:26:20 --> Output Class Initialized
INFO - 2017-02-10 07:26:20 --> Router Class Initialized
INFO - 2017-02-10 07:26:20 --> Security Class Initialized
INFO - 2017-02-10 07:26:20 --> Output Class Initialized
DEBUG - 2017-02-10 07:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:26:20 --> Input Class Initialized
INFO - 2017-02-10 07:26:20 --> Language Class Initialized
INFO - 2017-02-10 07:26:20 --> Security Class Initialized
ERROR - 2017-02-10 07:26:20 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:26:20 --> Input Class Initialized
INFO - 2017-02-10 07:26:20 --> Language Class Initialized
ERROR - 2017-02-10 07:26:20 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:26:20 --> Config Class Initialized
INFO - 2017-02-10 07:26:20 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:26:20 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:26:20 --> Utf8 Class Initialized
INFO - 2017-02-10 07:26:20 --> URI Class Initialized
INFO - 2017-02-10 07:26:20 --> Router Class Initialized
INFO - 2017-02-10 07:26:20 --> Output Class Initialized
INFO - 2017-02-10 07:26:20 --> Security Class Initialized
DEBUG - 2017-02-10 07:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:26:20 --> Input Class Initialized
INFO - 2017-02-10 07:26:20 --> Language Class Initialized
ERROR - 2017-02-10 07:26:20 --> 404 Page Not Found: ../modules/backend/controllers/Newsletter/edit
INFO - 2017-02-10 07:32:45 --> Config Class Initialized
INFO - 2017-02-10 07:32:45 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:32:45 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:32:45 --> Utf8 Class Initialized
INFO - 2017-02-10 07:32:45 --> URI Class Initialized
INFO - 2017-02-10 07:32:45 --> Router Class Initialized
INFO - 2017-02-10 07:32:45 --> Output Class Initialized
INFO - 2017-02-10 07:32:45 --> Security Class Initialized
DEBUG - 2017-02-10 07:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:32:45 --> Input Class Initialized
INFO - 2017-02-10 07:32:45 --> Language Class Initialized
INFO - 2017-02-10 07:32:45 --> Language Class Initialized
INFO - 2017-02-10 07:32:45 --> Config Class Initialized
INFO - 2017-02-10 07:32:45 --> Loader Class Initialized
INFO - 2017-02-10 07:32:45 --> Helper loaded: form_helper
INFO - 2017-02-10 07:32:45 --> Helper loaded: url_helper
INFO - 2017-02-10 07:32:45 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:32:45 --> Database Driver Class Initialized
INFO - 2017-02-10 07:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:32:45 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:32:45 --> Template Class Initialized
INFO - 2017-02-10 07:32:45 --> Controller Class Initialized
INFO - 2017-02-10 07:32:45 --> Model Class Initialized
INFO - 2017-02-10 07:32:45 --> Model Class Initialized
INFO - 2017-02-10 07:32:45 --> Model Class Initialized
DEBUG - 2017-02-10 07:32:45 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:32:45 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:32:45 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:32:45 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:32:45 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:32:45 --> Final output sent to browser
DEBUG - 2017-02-10 07:32:45 --> Total execution time: 0.1376
INFO - 2017-02-10 07:32:45 --> Config Class Initialized
INFO - 2017-02-10 07:32:45 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:32:45 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:32:45 --> Utf8 Class Initialized
INFO - 2017-02-10 07:32:45 --> URI Class Initialized
INFO - 2017-02-10 07:32:45 --> Router Class Initialized
INFO - 2017-02-10 07:32:45 --> Output Class Initialized
INFO - 2017-02-10 07:32:45 --> Security Class Initialized
DEBUG - 2017-02-10 07:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:32:45 --> Input Class Initialized
INFO - 2017-02-10 07:32:45 --> Language Class Initialized
ERROR - 2017-02-10 07:32:45 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:32:45 --> Config Class Initialized
INFO - 2017-02-10 07:32:45 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:32:45 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:32:45 --> Utf8 Class Initialized
INFO - 2017-02-10 07:32:45 --> Config Class Initialized
INFO - 2017-02-10 07:32:45 --> Hooks Class Initialized
INFO - 2017-02-10 07:32:45 --> URI Class Initialized
DEBUG - 2017-02-10 07:32:45 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:32:45 --> Utf8 Class Initialized
INFO - 2017-02-10 07:32:45 --> Router Class Initialized
INFO - 2017-02-10 07:32:45 --> URI Class Initialized
INFO - 2017-02-10 07:32:45 --> Output Class Initialized
INFO - 2017-02-10 07:32:45 --> Security Class Initialized
DEBUG - 2017-02-10 07:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:32:45 --> Input Class Initialized
INFO - 2017-02-10 07:32:45 --> Language Class Initialized
INFO - 2017-02-10 07:32:45 --> Router Class Initialized
ERROR - 2017-02-10 07:32:45 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:32:45 --> Output Class Initialized
INFO - 2017-02-10 07:32:45 --> Security Class Initialized
DEBUG - 2017-02-10 07:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:32:45 --> Input Class Initialized
INFO - 2017-02-10 07:32:45 --> Language Class Initialized
ERROR - 2017-02-10 07:32:45 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:32:47 --> Config Class Initialized
INFO - 2017-02-10 07:32:47 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:32:47 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:32:47 --> Utf8 Class Initialized
INFO - 2017-02-10 07:32:47 --> URI Class Initialized
INFO - 2017-02-10 07:32:47 --> Router Class Initialized
INFO - 2017-02-10 07:32:47 --> Output Class Initialized
INFO - 2017-02-10 07:32:47 --> Security Class Initialized
DEBUG - 2017-02-10 07:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:32:47 --> Input Class Initialized
INFO - 2017-02-10 07:32:47 --> Language Class Initialized
INFO - 2017-02-10 07:32:47 --> Language Class Initialized
INFO - 2017-02-10 07:32:47 --> Config Class Initialized
INFO - 2017-02-10 07:32:47 --> Loader Class Initialized
INFO - 2017-02-10 07:32:47 --> Helper loaded: form_helper
INFO - 2017-02-10 07:32:47 --> Helper loaded: url_helper
INFO - 2017-02-10 07:32:47 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:32:47 --> Database Driver Class Initialized
INFO - 2017-02-10 07:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:32:47 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:32:47 --> Template Class Initialized
INFO - 2017-02-10 07:32:47 --> Controller Class Initialized
INFO - 2017-02-10 07:32:47 --> Model Class Initialized
INFO - 2017-02-10 07:32:47 --> Model Class Initialized
INFO - 2017-02-10 07:32:47 --> Model Class Initialized
DEBUG - 2017-02-10 07:32:47 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:32:47 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:32:47 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:32:47 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_edit.php
DEBUG - 2017-02-10 07:32:47 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:32:47 --> Final output sent to browser
DEBUG - 2017-02-10 07:32:47 --> Total execution time: 0.0416
INFO - 2017-02-10 07:32:47 --> Config Class Initialized
INFO - 2017-02-10 07:32:47 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:32:47 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:32:47 --> Utf8 Class Initialized
INFO - 2017-02-10 07:32:47 --> Config Class Initialized
INFO - 2017-02-10 07:32:47 --> Hooks Class Initialized
INFO - 2017-02-10 07:32:47 --> URI Class Initialized
DEBUG - 2017-02-10 07:32:47 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:32:47 --> Utf8 Class Initialized
INFO - 2017-02-10 07:32:47 --> Router Class Initialized
INFO - 2017-02-10 07:32:47 --> URI Class Initialized
INFO - 2017-02-10 07:32:47 --> Output Class Initialized
INFO - 2017-02-10 07:32:47 --> Security Class Initialized
INFO - 2017-02-10 07:32:47 --> Router Class Initialized
DEBUG - 2017-02-10 07:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:32:47 --> Input Class Initialized
INFO - 2017-02-10 07:32:47 --> Language Class Initialized
INFO - 2017-02-10 07:32:47 --> Output Class Initialized
ERROR - 2017-02-10 07:32:47 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:32:47 --> Security Class Initialized
DEBUG - 2017-02-10 07:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:32:47 --> Input Class Initialized
INFO - 2017-02-10 07:32:47 --> Language Class Initialized
INFO - 2017-02-10 07:32:47 --> Config Class Initialized
INFO - 2017-02-10 07:32:47 --> Hooks Class Initialized
ERROR - 2017-02-10 07:32:47 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:32:47 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:32:47 --> Utf8 Class Initialized
INFO - 2017-02-10 07:32:47 --> URI Class Initialized
INFO - 2017-02-10 07:32:47 --> Router Class Initialized
INFO - 2017-02-10 07:32:47 --> Output Class Initialized
INFO - 2017-02-10 07:32:47 --> Security Class Initialized
DEBUG - 2017-02-10 07:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:32:47 --> Input Class Initialized
INFO - 2017-02-10 07:32:47 --> Language Class Initialized
ERROR - 2017-02-10 07:32:47 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:32:47 --> Config Class Initialized
INFO - 2017-02-10 07:32:47 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:32:47 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:32:47 --> Utf8 Class Initialized
INFO - 2017-02-10 07:32:47 --> URI Class Initialized
INFO - 2017-02-10 07:32:47 --> Router Class Initialized
INFO - 2017-02-10 07:32:47 --> Output Class Initialized
INFO - 2017-02-10 07:32:47 --> Security Class Initialized
DEBUG - 2017-02-10 07:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:32:47 --> Input Class Initialized
INFO - 2017-02-10 07:32:47 --> Language Class Initialized
ERROR - 2017-02-10 07:32:47 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:34:07 --> Config Class Initialized
INFO - 2017-02-10 07:34:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:34:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:34:07 --> URI Class Initialized
INFO - 2017-02-10 07:34:07 --> Router Class Initialized
INFO - 2017-02-10 07:34:07 --> Output Class Initialized
INFO - 2017-02-10 07:34:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:07 --> Input Class Initialized
INFO - 2017-02-10 07:34:07 --> Language Class Initialized
INFO - 2017-02-10 07:34:07 --> Language Class Initialized
INFO - 2017-02-10 07:34:07 --> Config Class Initialized
INFO - 2017-02-10 07:34:07 --> Loader Class Initialized
INFO - 2017-02-10 07:34:07 --> Helper loaded: form_helper
INFO - 2017-02-10 07:34:07 --> Helper loaded: url_helper
INFO - 2017-02-10 07:34:07 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:34:07 --> Database Driver Class Initialized
INFO - 2017-02-10 07:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:34:07 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:34:07 --> Template Class Initialized
INFO - 2017-02-10 07:34:07 --> Controller Class Initialized
INFO - 2017-02-10 07:34:07 --> Model Class Initialized
INFO - 2017-02-10 07:34:07 --> Model Class Initialized
INFO - 2017-02-10 07:34:07 --> Model Class Initialized
DEBUG - 2017-02-10 07:34:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:34:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:34:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:34:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_edit.php
DEBUG - 2017-02-10 07:34:07 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:34:07 --> Final output sent to browser
DEBUG - 2017-02-10 07:34:07 --> Total execution time: 0.0785
INFO - 2017-02-10 07:34:07 --> Config Class Initialized
INFO - 2017-02-10 07:34:07 --> Hooks Class Initialized
INFO - 2017-02-10 07:34:07 --> Config Class Initialized
INFO - 2017-02-10 07:34:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:34:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:07 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:34:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:07 --> URI Class Initialized
INFO - 2017-02-10 07:34:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:34:07 --> URI Class Initialized
INFO - 2017-02-10 07:34:07 --> Router Class Initialized
INFO - 2017-02-10 07:34:07 --> Router Class Initialized
INFO - 2017-02-10 07:34:07 --> Output Class Initialized
INFO - 2017-02-10 07:34:07 --> Output Class Initialized
INFO - 2017-02-10 07:34:07 --> Security Class Initialized
INFO - 2017-02-10 07:34:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:07 --> Input Class Initialized
DEBUG - 2017-02-10 07:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:07 --> Input Class Initialized
INFO - 2017-02-10 07:34:07 --> Language Class Initialized
INFO - 2017-02-10 07:34:07 --> Language Class Initialized
ERROR - 2017-02-10 07:34:07 --> 404 Page Not Found: /index
ERROR - 2017-02-10 07:34:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:34:07 --> Config Class Initialized
INFO - 2017-02-10 07:34:07 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:34:07 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:07 --> Utf8 Class Initialized
INFO - 2017-02-10 07:34:07 --> URI Class Initialized
INFO - 2017-02-10 07:34:07 --> Router Class Initialized
INFO - 2017-02-10 07:34:07 --> Output Class Initialized
INFO - 2017-02-10 07:34:07 --> Security Class Initialized
DEBUG - 2017-02-10 07:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:07 --> Input Class Initialized
INFO - 2017-02-10 07:34:07 --> Language Class Initialized
ERROR - 2017-02-10 07:34:07 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:34:12 --> Config Class Initialized
INFO - 2017-02-10 07:34:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:34:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:12 --> Utf8 Class Initialized
INFO - 2017-02-10 07:34:12 --> URI Class Initialized
INFO - 2017-02-10 07:34:12 --> Router Class Initialized
INFO - 2017-02-10 07:34:12 --> Output Class Initialized
INFO - 2017-02-10 07:34:12 --> Security Class Initialized
DEBUG - 2017-02-10 07:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:12 --> Input Class Initialized
INFO - 2017-02-10 07:34:12 --> Language Class Initialized
INFO - 2017-02-10 07:34:12 --> Language Class Initialized
INFO - 2017-02-10 07:34:12 --> Config Class Initialized
INFO - 2017-02-10 07:34:12 --> Loader Class Initialized
INFO - 2017-02-10 07:34:12 --> Helper loaded: form_helper
INFO - 2017-02-10 07:34:12 --> Helper loaded: url_helper
INFO - 2017-02-10 07:34:12 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:34:12 --> Database Driver Class Initialized
INFO - 2017-02-10 07:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:34:12 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:34:12 --> Template Class Initialized
INFO - 2017-02-10 07:34:12 --> Controller Class Initialized
INFO - 2017-02-10 07:34:12 --> Model Class Initialized
INFO - 2017-02-10 07:34:12 --> Model Class Initialized
INFO - 2017-02-10 07:34:12 --> Model Class Initialized
INFO - 2017-02-10 07:34:12 --> Config Class Initialized
INFO - 2017-02-10 07:34:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:34:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:12 --> Utf8 Class Initialized
INFO - 2017-02-10 07:34:12 --> URI Class Initialized
INFO - 2017-02-10 07:34:12 --> Router Class Initialized
INFO - 2017-02-10 07:34:12 --> Output Class Initialized
INFO - 2017-02-10 07:34:12 --> Security Class Initialized
DEBUG - 2017-02-10 07:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:12 --> Input Class Initialized
INFO - 2017-02-10 07:34:12 --> Language Class Initialized
INFO - 2017-02-10 07:34:12 --> Language Class Initialized
INFO - 2017-02-10 07:34:12 --> Config Class Initialized
INFO - 2017-02-10 07:34:12 --> Loader Class Initialized
INFO - 2017-02-10 07:34:12 --> Helper loaded: form_helper
INFO - 2017-02-10 07:34:12 --> Helper loaded: url_helper
INFO - 2017-02-10 07:34:12 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:34:12 --> Database Driver Class Initialized
INFO - 2017-02-10 07:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:34:12 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:34:12 --> Template Class Initialized
INFO - 2017-02-10 07:34:12 --> Controller Class Initialized
INFO - 2017-02-10 07:34:12 --> Model Class Initialized
INFO - 2017-02-10 07:34:12 --> Model Class Initialized
INFO - 2017-02-10 07:34:12 --> Model Class Initialized
DEBUG - 2017-02-10 07:34:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:34:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:34:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:34:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:34:12 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:34:12 --> Final output sent to browser
DEBUG - 2017-02-10 07:34:12 --> Total execution time: 0.0730
INFO - 2017-02-10 07:34:12 --> Config Class Initialized
INFO - 2017-02-10 07:34:12 --> Hooks Class Initialized
INFO - 2017-02-10 07:34:12 --> Config Class Initialized
INFO - 2017-02-10 07:34:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:34:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:12 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:34:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:12 --> Utf8 Class Initialized
INFO - 2017-02-10 07:34:12 --> URI Class Initialized
INFO - 2017-02-10 07:34:12 --> URI Class Initialized
INFO - 2017-02-10 07:34:12 --> Router Class Initialized
INFO - 2017-02-10 07:34:12 --> Router Class Initialized
INFO - 2017-02-10 07:34:12 --> Output Class Initialized
INFO - 2017-02-10 07:34:12 --> Output Class Initialized
INFO - 2017-02-10 07:34:12 --> Security Class Initialized
INFO - 2017-02-10 07:34:12 --> Security Class Initialized
DEBUG - 2017-02-10 07:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:12 --> Input Class Initialized
INFO - 2017-02-10 07:34:12 --> Language Class Initialized
DEBUG - 2017-02-10 07:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-10 07:34:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:34:12 --> Input Class Initialized
INFO - 2017-02-10 07:34:12 --> Language Class Initialized
ERROR - 2017-02-10 07:34:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:34:13 --> Config Class Initialized
INFO - 2017-02-10 07:34:13 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:34:13 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:13 --> Utf8 Class Initialized
INFO - 2017-02-10 07:34:13 --> URI Class Initialized
INFO - 2017-02-10 07:34:13 --> Router Class Initialized
INFO - 2017-02-10 07:34:13 --> Output Class Initialized
INFO - 2017-02-10 07:34:13 --> Security Class Initialized
DEBUG - 2017-02-10 07:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:13 --> Input Class Initialized
INFO - 2017-02-10 07:34:13 --> Language Class Initialized
ERROR - 2017-02-10 07:34:13 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:34:15 --> Config Class Initialized
INFO - 2017-02-10 07:34:15 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:34:15 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:15 --> Utf8 Class Initialized
INFO - 2017-02-10 07:34:15 --> URI Class Initialized
INFO - 2017-02-10 07:34:15 --> Router Class Initialized
INFO - 2017-02-10 07:34:15 --> Output Class Initialized
INFO - 2017-02-10 07:34:15 --> Security Class Initialized
DEBUG - 2017-02-10 07:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:15 --> Input Class Initialized
INFO - 2017-02-10 07:34:15 --> Language Class Initialized
INFO - 2017-02-10 07:34:15 --> Language Class Initialized
INFO - 2017-02-10 07:34:15 --> Config Class Initialized
INFO - 2017-02-10 07:34:15 --> Loader Class Initialized
INFO - 2017-02-10 07:34:15 --> Helper loaded: form_helper
INFO - 2017-02-10 07:34:15 --> Helper loaded: url_helper
INFO - 2017-02-10 07:34:15 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:34:15 --> Database Driver Class Initialized
INFO - 2017-02-10 07:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:34:15 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:34:15 --> Template Class Initialized
INFO - 2017-02-10 07:34:15 --> Controller Class Initialized
INFO - 2017-02-10 07:34:15 --> Model Class Initialized
INFO - 2017-02-10 07:34:15 --> Model Class Initialized
INFO - 2017-02-10 07:34:15 --> Model Class Initialized
DEBUG - 2017-02-10 07:34:15 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:34:15 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:34:15 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:34:15 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_edit.php
DEBUG - 2017-02-10 07:34:15 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:34:15 --> Final output sent to browser
DEBUG - 2017-02-10 07:34:15 --> Total execution time: 0.0459
INFO - 2017-02-10 07:34:15 --> Config Class Initialized
INFO - 2017-02-10 07:34:15 --> Hooks Class Initialized
INFO - 2017-02-10 07:34:15 --> Config Class Initialized
INFO - 2017-02-10 07:34:15 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:34:15 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:15 --> Utf8 Class Initialized
INFO - 2017-02-10 07:34:15 --> URI Class Initialized
DEBUG - 2017-02-10 07:34:15 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:15 --> Utf8 Class Initialized
INFO - 2017-02-10 07:34:15 --> Router Class Initialized
INFO - 2017-02-10 07:34:15 --> URI Class Initialized
INFO - 2017-02-10 07:34:15 --> Output Class Initialized
INFO - 2017-02-10 07:34:15 --> Security Class Initialized
DEBUG - 2017-02-10 07:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:15 --> Input Class Initialized
INFO - 2017-02-10 07:34:15 --> Language Class Initialized
INFO - 2017-02-10 07:34:15 --> Router Class Initialized
ERROR - 2017-02-10 07:34:15 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:34:15 --> Output Class Initialized
INFO - 2017-02-10 07:34:15 --> Security Class Initialized
DEBUG - 2017-02-10 07:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:15 --> Input Class Initialized
INFO - 2017-02-10 07:34:15 --> Language Class Initialized
ERROR - 2017-02-10 07:34:15 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:34:15 --> Config Class Initialized
INFO - 2017-02-10 07:34:15 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:34:15 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:15 --> Utf8 Class Initialized
INFO - 2017-02-10 07:34:15 --> URI Class Initialized
INFO - 2017-02-10 07:34:15 --> Router Class Initialized
INFO - 2017-02-10 07:34:15 --> Output Class Initialized
INFO - 2017-02-10 07:34:15 --> Security Class Initialized
DEBUG - 2017-02-10 07:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:15 --> Input Class Initialized
INFO - 2017-02-10 07:34:15 --> Language Class Initialized
ERROR - 2017-02-10 07:34:15 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:34:18 --> Config Class Initialized
INFO - 2017-02-10 07:34:18 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:34:18 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:18 --> Utf8 Class Initialized
INFO - 2017-02-10 07:34:18 --> URI Class Initialized
INFO - 2017-02-10 07:34:18 --> Router Class Initialized
INFO - 2017-02-10 07:34:18 --> Output Class Initialized
INFO - 2017-02-10 07:34:18 --> Security Class Initialized
DEBUG - 2017-02-10 07:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:18 --> Input Class Initialized
INFO - 2017-02-10 07:34:18 --> Language Class Initialized
INFO - 2017-02-10 07:34:18 --> Language Class Initialized
INFO - 2017-02-10 07:34:18 --> Config Class Initialized
INFO - 2017-02-10 07:34:18 --> Loader Class Initialized
INFO - 2017-02-10 07:34:18 --> Helper loaded: form_helper
INFO - 2017-02-10 07:34:18 --> Helper loaded: url_helper
INFO - 2017-02-10 07:34:18 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:34:18 --> Database Driver Class Initialized
INFO - 2017-02-10 07:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:34:18 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:34:18 --> Template Class Initialized
INFO - 2017-02-10 07:34:18 --> Controller Class Initialized
INFO - 2017-02-10 07:34:18 --> Model Class Initialized
INFO - 2017-02-10 07:34:18 --> Model Class Initialized
INFO - 2017-02-10 07:34:18 --> Model Class Initialized
INFO - 2017-02-10 07:34:18 --> Config Class Initialized
INFO - 2017-02-10 07:34:18 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:34:18 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:18 --> Utf8 Class Initialized
INFO - 2017-02-10 07:34:18 --> URI Class Initialized
INFO - 2017-02-10 07:34:18 --> Router Class Initialized
INFO - 2017-02-10 07:34:18 --> Output Class Initialized
INFO - 2017-02-10 07:34:18 --> Security Class Initialized
DEBUG - 2017-02-10 07:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:18 --> Input Class Initialized
INFO - 2017-02-10 07:34:18 --> Language Class Initialized
INFO - 2017-02-10 07:34:18 --> Language Class Initialized
INFO - 2017-02-10 07:34:18 --> Config Class Initialized
INFO - 2017-02-10 07:34:18 --> Loader Class Initialized
INFO - 2017-02-10 07:34:18 --> Helper loaded: form_helper
INFO - 2017-02-10 07:34:18 --> Helper loaded: url_helper
INFO - 2017-02-10 07:34:18 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:34:18 --> Database Driver Class Initialized
INFO - 2017-02-10 07:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:34:18 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:34:18 --> Template Class Initialized
INFO - 2017-02-10 07:34:18 --> Controller Class Initialized
INFO - 2017-02-10 07:34:18 --> Model Class Initialized
INFO - 2017-02-10 07:34:18 --> Model Class Initialized
INFO - 2017-02-10 07:34:18 --> Model Class Initialized
DEBUG - 2017-02-10 07:34:18 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:34:18 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:34:18 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:34:18 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:34:18 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:34:18 --> Final output sent to browser
DEBUG - 2017-02-10 07:34:18 --> Total execution time: 0.0641
INFO - 2017-02-10 07:34:18 --> Config Class Initialized
INFO - 2017-02-10 07:34:18 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:34:18 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:18 --> Utf8 Class Initialized
INFO - 2017-02-10 07:34:18 --> URI Class Initialized
INFO - 2017-02-10 07:34:18 --> Config Class Initialized
INFO - 2017-02-10 07:34:18 --> Hooks Class Initialized
INFO - 2017-02-10 07:34:18 --> Router Class Initialized
INFO - 2017-02-10 07:34:18 --> Output Class Initialized
DEBUG - 2017-02-10 07:34:18 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:18 --> Security Class Initialized
INFO - 2017-02-10 07:34:18 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:18 --> Input Class Initialized
INFO - 2017-02-10 07:34:18 --> URI Class Initialized
INFO - 2017-02-10 07:34:18 --> Language Class Initialized
ERROR - 2017-02-10 07:34:18 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:34:18 --> Router Class Initialized
INFO - 2017-02-10 07:34:18 --> Output Class Initialized
INFO - 2017-02-10 07:34:18 --> Security Class Initialized
DEBUG - 2017-02-10 07:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:18 --> Input Class Initialized
INFO - 2017-02-10 07:34:18 --> Language Class Initialized
ERROR - 2017-02-10 07:34:18 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:34:18 --> Config Class Initialized
INFO - 2017-02-10 07:34:18 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:34:18 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:18 --> Utf8 Class Initialized
INFO - 2017-02-10 07:34:18 --> URI Class Initialized
INFO - 2017-02-10 07:34:18 --> Router Class Initialized
INFO - 2017-02-10 07:34:18 --> Output Class Initialized
INFO - 2017-02-10 07:34:18 --> Security Class Initialized
DEBUG - 2017-02-10 07:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:18 --> Input Class Initialized
INFO - 2017-02-10 07:34:18 --> Language Class Initialized
ERROR - 2017-02-10 07:34:18 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:34:25 --> Config Class Initialized
INFO - 2017-02-10 07:34:25 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:34:25 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:25 --> Utf8 Class Initialized
INFO - 2017-02-10 07:34:25 --> URI Class Initialized
INFO - 2017-02-10 07:34:25 --> Router Class Initialized
INFO - 2017-02-10 07:34:25 --> Output Class Initialized
INFO - 2017-02-10 07:34:25 --> Security Class Initialized
DEBUG - 2017-02-10 07:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:25 --> Input Class Initialized
INFO - 2017-02-10 07:34:25 --> Language Class Initialized
INFO - 2017-02-10 07:34:25 --> Language Class Initialized
INFO - 2017-02-10 07:34:25 --> Config Class Initialized
INFO - 2017-02-10 07:34:25 --> Loader Class Initialized
INFO - 2017-02-10 07:34:25 --> Helper loaded: form_helper
INFO - 2017-02-10 07:34:25 --> Helper loaded: url_helper
INFO - 2017-02-10 07:34:25 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:34:25 --> Database Driver Class Initialized
INFO - 2017-02-10 07:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:34:25 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:34:25 --> Template Class Initialized
INFO - 2017-02-10 07:34:25 --> Controller Class Initialized
INFO - 2017-02-10 07:34:25 --> Model Class Initialized
INFO - 2017-02-10 07:34:25 --> Model Class Initialized
INFO - 2017-02-10 07:34:25 --> Model Class Initialized
ERROR - 2017-02-10 07:34:25 --> Query error: Table 'mobile.mst_users' doesn't exist - Invalid query: SELECT `mu`.`user_id`, `mu`.`first_name`, `mu`.`last_name`, `mu`.`user_email`, `mu`.`user_status`, `mu`.`user_type`
FROM `mst_users` as `mu`
WHERE `mu`.`user_type` != '1'
AND `mu`.`email_verified` = '1'
INFO - 2017-02-10 07:34:25 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-10 07:34:31 --> Config Class Initialized
INFO - 2017-02-10 07:34:31 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:34:31 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:34:31 --> Utf8 Class Initialized
INFO - 2017-02-10 07:34:31 --> URI Class Initialized
INFO - 2017-02-10 07:34:31 --> Router Class Initialized
INFO - 2017-02-10 07:34:31 --> Output Class Initialized
INFO - 2017-02-10 07:34:31 --> Security Class Initialized
DEBUG - 2017-02-10 07:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:34:31 --> Input Class Initialized
INFO - 2017-02-10 07:34:31 --> Language Class Initialized
INFO - 2017-02-10 07:34:31 --> Language Class Initialized
INFO - 2017-02-10 07:34:31 --> Config Class Initialized
INFO - 2017-02-10 07:34:31 --> Loader Class Initialized
INFO - 2017-02-10 07:34:31 --> Helper loaded: form_helper
INFO - 2017-02-10 07:34:31 --> Helper loaded: url_helper
INFO - 2017-02-10 07:34:31 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:34:31 --> Database Driver Class Initialized
INFO - 2017-02-10 07:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:34:31 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:34:31 --> Template Class Initialized
INFO - 2017-02-10 07:34:31 --> Controller Class Initialized
INFO - 2017-02-10 07:34:31 --> Model Class Initialized
INFO - 2017-02-10 07:34:31 --> Model Class Initialized
INFO - 2017-02-10 07:34:31 --> Model Class Initialized
DEBUG - 2017-02-10 07:34:31 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:34:31 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:34:31 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:34:31 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:34:31 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:34:31 --> Final output sent to browser
DEBUG - 2017-02-10 07:34:31 --> Total execution time: 0.0457
INFO - 2017-02-10 07:35:14 --> Config Class Initialized
INFO - 2017-02-10 07:35:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:35:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:35:14 --> Utf8 Class Initialized
INFO - 2017-02-10 07:35:14 --> URI Class Initialized
INFO - 2017-02-10 07:35:14 --> Router Class Initialized
INFO - 2017-02-10 07:35:14 --> Output Class Initialized
INFO - 2017-02-10 07:35:14 --> Security Class Initialized
DEBUG - 2017-02-10 07:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:35:14 --> Input Class Initialized
INFO - 2017-02-10 07:35:14 --> Language Class Initialized
INFO - 2017-02-10 07:35:14 --> Language Class Initialized
INFO - 2017-02-10 07:35:14 --> Config Class Initialized
INFO - 2017-02-10 07:35:14 --> Loader Class Initialized
INFO - 2017-02-10 07:35:14 --> Helper loaded: form_helper
INFO - 2017-02-10 07:35:14 --> Helper loaded: url_helper
INFO - 2017-02-10 07:35:14 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:35:14 --> Database Driver Class Initialized
INFO - 2017-02-10 07:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:35:14 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:35:14 --> Template Class Initialized
INFO - 2017-02-10 07:35:14 --> Controller Class Initialized
INFO - 2017-02-10 07:35:14 --> Model Class Initialized
INFO - 2017-02-10 07:35:14 --> Model Class Initialized
INFO - 2017-02-10 07:35:14 --> Model Class Initialized
DEBUG - 2017-02-10 07:35:14 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:35:14 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:35:14 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:35:14 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 07:35:14 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:35:14 --> Final output sent to browser
DEBUG - 2017-02-10 07:35:14 --> Total execution time: 0.0565
INFO - 2017-02-10 07:35:14 --> Config Class Initialized
INFO - 2017-02-10 07:35:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:35:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:35:14 --> Utf8 Class Initialized
INFO - 2017-02-10 07:35:14 --> Config Class Initialized
INFO - 2017-02-10 07:35:14 --> URI Class Initialized
INFO - 2017-02-10 07:35:14 --> Hooks Class Initialized
INFO - 2017-02-10 07:35:14 --> Router Class Initialized
DEBUG - 2017-02-10 07:35:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:35:14 --> Utf8 Class Initialized
INFO - 2017-02-10 07:35:14 --> Output Class Initialized
INFO - 2017-02-10 07:35:14 --> URI Class Initialized
INFO - 2017-02-10 07:35:14 --> Security Class Initialized
DEBUG - 2017-02-10 07:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:35:14 --> Input Class Initialized
INFO - 2017-02-10 07:35:14 --> Router Class Initialized
INFO - 2017-02-10 07:35:14 --> Language Class Initialized
ERROR - 2017-02-10 07:35:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:35:14 --> Output Class Initialized
INFO - 2017-02-10 07:35:14 --> Security Class Initialized
DEBUG - 2017-02-10 07:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:35:14 --> Input Class Initialized
INFO - 2017-02-10 07:35:14 --> Language Class Initialized
ERROR - 2017-02-10 07:35:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:35:14 --> Config Class Initialized
INFO - 2017-02-10 07:35:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:35:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:35:14 --> Utf8 Class Initialized
INFO - 2017-02-10 07:35:14 --> URI Class Initialized
INFO - 2017-02-10 07:35:14 --> Router Class Initialized
INFO - 2017-02-10 07:35:14 --> Output Class Initialized
INFO - 2017-02-10 07:35:14 --> Security Class Initialized
DEBUG - 2017-02-10 07:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:35:14 --> Input Class Initialized
INFO - 2017-02-10 07:35:14 --> Language Class Initialized
ERROR - 2017-02-10 07:35:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:35:16 --> Config Class Initialized
INFO - 2017-02-10 07:35:16 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:35:16 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:35:16 --> Utf8 Class Initialized
INFO - 2017-02-10 07:35:16 --> URI Class Initialized
INFO - 2017-02-10 07:35:16 --> Router Class Initialized
INFO - 2017-02-10 07:35:16 --> Output Class Initialized
INFO - 2017-02-10 07:35:16 --> Security Class Initialized
DEBUG - 2017-02-10 07:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:35:16 --> Input Class Initialized
INFO - 2017-02-10 07:35:16 --> Language Class Initialized
INFO - 2017-02-10 07:35:16 --> Language Class Initialized
INFO - 2017-02-10 07:35:16 --> Config Class Initialized
INFO - 2017-02-10 07:35:16 --> Loader Class Initialized
INFO - 2017-02-10 07:35:16 --> Helper loaded: form_helper
INFO - 2017-02-10 07:35:16 --> Helper loaded: url_helper
INFO - 2017-02-10 07:35:16 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:35:16 --> Database Driver Class Initialized
INFO - 2017-02-10 07:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:35:16 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:35:16 --> Template Class Initialized
INFO - 2017-02-10 07:35:16 --> Controller Class Initialized
INFO - 2017-02-10 07:35:16 --> Model Class Initialized
INFO - 2017-02-10 07:35:16 --> Model Class Initialized
INFO - 2017-02-10 07:35:16 --> Model Class Initialized
ERROR - 2017-02-10 07:35:16 --> Query error: Table 'mobile.mst_users' doesn't exist - Invalid query: SELECT `mu`.`user_id`, `mu`.`first_name`, `mu`.`last_name`, `mu`.`user_email`, `mu`.`user_status`, `mu`.`user_type`
FROM `mst_users` as `mu`
WHERE `mu`.`user_type` != '1'
AND `mu`.`email_verified` = '1'
INFO - 2017-02-10 07:35:16 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-10 07:37:37 --> Config Class Initialized
INFO - 2017-02-10 07:37:37 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:37:37 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:37:37 --> Utf8 Class Initialized
INFO - 2017-02-10 07:37:37 --> URI Class Initialized
INFO - 2017-02-10 07:37:37 --> Router Class Initialized
INFO - 2017-02-10 07:37:37 --> Output Class Initialized
INFO - 2017-02-10 07:37:37 --> Security Class Initialized
DEBUG - 2017-02-10 07:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:37:37 --> Input Class Initialized
INFO - 2017-02-10 07:37:37 --> Language Class Initialized
INFO - 2017-02-10 07:37:37 --> Language Class Initialized
INFO - 2017-02-10 07:37:37 --> Config Class Initialized
INFO - 2017-02-10 07:37:37 --> Loader Class Initialized
INFO - 2017-02-10 07:37:37 --> Helper loaded: form_helper
INFO - 2017-02-10 07:37:37 --> Helper loaded: url_helper
INFO - 2017-02-10 07:37:37 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:37:37 --> Database Driver Class Initialized
INFO - 2017-02-10 07:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:37:37 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:37:37 --> Template Class Initialized
INFO - 2017-02-10 07:37:37 --> Controller Class Initialized
INFO - 2017-02-10 07:37:37 --> Model Class Initialized
INFO - 2017-02-10 07:37:37 --> Model Class Initialized
INFO - 2017-02-10 07:37:37 --> Model Class Initialized
ERROR - 2017-02-10 07:37:37 --> Query error: Table 'mobile.mst_users' doesn't exist - Invalid query: SELECT `mu`.`user_id`, `mu`.`first_name`, `mu`.`last_name`, `mu`.`user_email`, `mu`.`user_status`, `mu`.`user_type`
FROM `mst_users` as `mu`
WHERE `mu`.`user_type` != '1'
AND `mu`.`email_verified` = '1'
INFO - 2017-02-10 07:37:37 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-10 07:37:39 --> Config Class Initialized
INFO - 2017-02-10 07:37:39 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:37:39 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:37:39 --> Utf8 Class Initialized
INFO - 2017-02-10 07:37:39 --> URI Class Initialized
INFO - 2017-02-10 07:37:39 --> Router Class Initialized
INFO - 2017-02-10 07:37:39 --> Output Class Initialized
INFO - 2017-02-10 07:37:39 --> Security Class Initialized
DEBUG - 2017-02-10 07:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:37:39 --> Input Class Initialized
INFO - 2017-02-10 07:37:39 --> Language Class Initialized
INFO - 2017-02-10 07:37:39 --> Language Class Initialized
INFO - 2017-02-10 07:37:39 --> Config Class Initialized
INFO - 2017-02-10 07:37:39 --> Loader Class Initialized
INFO - 2017-02-10 07:37:39 --> Helper loaded: form_helper
INFO - 2017-02-10 07:37:39 --> Helper loaded: url_helper
INFO - 2017-02-10 07:37:39 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:37:39 --> Database Driver Class Initialized
INFO - 2017-02-10 07:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:37:39 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:37:39 --> Template Class Initialized
INFO - 2017-02-10 07:37:39 --> Controller Class Initialized
INFO - 2017-02-10 07:37:39 --> Model Class Initialized
INFO - 2017-02-10 07:37:39 --> Model Class Initialized
INFO - 2017-02-10 07:37:39 --> Model Class Initialized
ERROR - 2017-02-10 07:37:39 --> Query error: Table 'mobile.mst_users' doesn't exist - Invalid query: SELECT `mu`.`user_id`, `mu`.`first_name`, `mu`.`last_name`, `mu`.`user_email`, `mu`.`user_status`, `mu`.`user_type`
FROM `mst_users` as `mu`
WHERE `mu`.`user_type` != '1'
AND `mu`.`email_verified` = '1'
INFO - 2017-02-10 07:37:39 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-10 07:39:32 --> Config Class Initialized
INFO - 2017-02-10 07:39:32 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:39:32 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:39:32 --> Utf8 Class Initialized
INFO - 2017-02-10 07:39:32 --> URI Class Initialized
INFO - 2017-02-10 07:39:32 --> Router Class Initialized
INFO - 2017-02-10 07:39:32 --> Output Class Initialized
INFO - 2017-02-10 07:39:32 --> Security Class Initialized
DEBUG - 2017-02-10 07:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:39:32 --> Input Class Initialized
INFO - 2017-02-10 07:39:32 --> Language Class Initialized
INFO - 2017-02-10 07:39:32 --> Language Class Initialized
INFO - 2017-02-10 07:39:32 --> Config Class Initialized
INFO - 2017-02-10 07:39:32 --> Loader Class Initialized
INFO - 2017-02-10 07:39:32 --> Helper loaded: form_helper
INFO - 2017-02-10 07:39:32 --> Helper loaded: url_helper
INFO - 2017-02-10 07:39:32 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:39:32 --> Database Driver Class Initialized
INFO - 2017-02-10 07:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:39:32 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:39:32 --> Template Class Initialized
INFO - 2017-02-10 07:39:32 --> Controller Class Initialized
INFO - 2017-02-10 07:39:32 --> Model Class Initialized
INFO - 2017-02-10 07:39:32 --> Model Class Initialized
INFO - 2017-02-10 07:39:32 --> Model Class Initialized
ERROR - 2017-02-10 07:39:32 --> Severity: Error --> Access to undeclared static property: TABLES::$ADMIN_USERS C:\xampp\htdocs\mobile\application\models\Newsletter_model.php 89
INFO - 2017-02-10 07:39:38 --> Config Class Initialized
INFO - 2017-02-10 07:39:38 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:39:38 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:39:38 --> Utf8 Class Initialized
INFO - 2017-02-10 07:39:38 --> URI Class Initialized
INFO - 2017-02-10 07:39:38 --> Router Class Initialized
INFO - 2017-02-10 07:39:38 --> Output Class Initialized
INFO - 2017-02-10 07:39:38 --> Security Class Initialized
DEBUG - 2017-02-10 07:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:39:38 --> Input Class Initialized
INFO - 2017-02-10 07:39:38 --> Language Class Initialized
INFO - 2017-02-10 07:39:38 --> Language Class Initialized
INFO - 2017-02-10 07:39:38 --> Config Class Initialized
INFO - 2017-02-10 07:39:38 --> Loader Class Initialized
INFO - 2017-02-10 07:39:38 --> Helper loaded: form_helper
INFO - 2017-02-10 07:39:38 --> Helper loaded: url_helper
INFO - 2017-02-10 07:39:38 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:39:38 --> Database Driver Class Initialized
INFO - 2017-02-10 07:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:39:38 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:39:38 --> Template Class Initialized
INFO - 2017-02-10 07:39:38 --> Controller Class Initialized
INFO - 2017-02-10 07:39:38 --> Model Class Initialized
INFO - 2017-02-10 07:39:38 --> Model Class Initialized
INFO - 2017-02-10 07:39:38 --> Model Class Initialized
ERROR - 2017-02-10 07:39:38 --> Query error: Unknown column 'mu.user_type' in 'where clause' - Invalid query: SELECT *
FROM `tbl_users` as `mu`
WHERE `mu`.`user_type` != '1'
AND `mu`.`email_verified` = '1'
INFO - 2017-02-10 07:39:38 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-10 07:39:47 --> Config Class Initialized
INFO - 2017-02-10 07:39:47 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:39:47 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:39:47 --> Utf8 Class Initialized
INFO - 2017-02-10 07:39:47 --> URI Class Initialized
INFO - 2017-02-10 07:39:47 --> Router Class Initialized
INFO - 2017-02-10 07:39:47 --> Output Class Initialized
INFO - 2017-02-10 07:39:47 --> Security Class Initialized
DEBUG - 2017-02-10 07:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:39:47 --> Input Class Initialized
INFO - 2017-02-10 07:39:47 --> Language Class Initialized
INFO - 2017-02-10 07:39:47 --> Language Class Initialized
INFO - 2017-02-10 07:39:47 --> Config Class Initialized
INFO - 2017-02-10 07:39:47 --> Loader Class Initialized
INFO - 2017-02-10 07:39:47 --> Helper loaded: form_helper
INFO - 2017-02-10 07:39:47 --> Helper loaded: url_helper
INFO - 2017-02-10 07:39:47 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:39:47 --> Database Driver Class Initialized
INFO - 2017-02-10 07:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:39:47 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:39:47 --> Template Class Initialized
INFO - 2017-02-10 07:39:47 --> Controller Class Initialized
INFO - 2017-02-10 07:39:47 --> Model Class Initialized
INFO - 2017-02-10 07:39:47 --> Model Class Initialized
INFO - 2017-02-10 07:39:47 --> Model Class Initialized
ERROR - 2017-02-10 07:39:47 --> Query error: Unknown column 'mu.email_verified' in 'where clause' - Invalid query: SELECT *
FROM `tbl_users` as `mu`
WHERE `mu`.`email_verified` = '1'
INFO - 2017-02-10 07:39:47 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-10 07:39:59 --> Config Class Initialized
INFO - 2017-02-10 07:39:59 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:39:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:39:59 --> Utf8 Class Initialized
INFO - 2017-02-10 07:39:59 --> URI Class Initialized
INFO - 2017-02-10 07:39:59 --> Router Class Initialized
INFO - 2017-02-10 07:39:59 --> Output Class Initialized
INFO - 2017-02-10 07:39:59 --> Security Class Initialized
DEBUG - 2017-02-10 07:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:39:59 --> Input Class Initialized
INFO - 2017-02-10 07:39:59 --> Language Class Initialized
INFO - 2017-02-10 07:39:59 --> Language Class Initialized
INFO - 2017-02-10 07:39:59 --> Config Class Initialized
INFO - 2017-02-10 07:39:59 --> Loader Class Initialized
INFO - 2017-02-10 07:39:59 --> Helper loaded: form_helper
INFO - 2017-02-10 07:39:59 --> Helper loaded: url_helper
INFO - 2017-02-10 07:39:59 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:39:59 --> Database Driver Class Initialized
INFO - 2017-02-10 07:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:39:59 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:39:59 --> Template Class Initialized
INFO - 2017-02-10 07:39:59 --> Controller Class Initialized
INFO - 2017-02-10 07:39:59 --> Model Class Initialized
INFO - 2017-02-10 07:39:59 --> Model Class Initialized
INFO - 2017-02-10 07:39:59 --> Model Class Initialized
DEBUG - 2017-02-10 07:39:59 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:39:59 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:39:59 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-10 07:39:59 --> Severity: Notice --> Undefined index: user_id C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 101
ERROR - 2017-02-10 07:39:59 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 108
ERROR - 2017-02-10 07:39:59 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 110
ERROR - 2017-02-10 07:39:59 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 112
ERROR - 2017-02-10 07:39:59 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 119
ERROR - 2017-02-10 07:39:59 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 121
ERROR - 2017-02-10 07:39:59 --> Severity: Notice --> Undefined index: user_email C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 128
DEBUG - 2017-02-10 07:39:59 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 07:39:59 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:39:59 --> Final output sent to browser
DEBUG - 2017-02-10 07:39:59 --> Total execution time: 0.1260
INFO - 2017-02-10 07:39:59 --> Config Class Initialized
INFO - 2017-02-10 07:39:59 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:39:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:39:59 --> Config Class Initialized
INFO - 2017-02-10 07:39:59 --> Utf8 Class Initialized
INFO - 2017-02-10 07:39:59 --> Hooks Class Initialized
INFO - 2017-02-10 07:39:59 --> URI Class Initialized
DEBUG - 2017-02-10 07:39:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:39:59 --> Utf8 Class Initialized
INFO - 2017-02-10 07:39:59 --> Router Class Initialized
INFO - 2017-02-10 07:39:59 --> URI Class Initialized
INFO - 2017-02-10 07:39:59 --> Output Class Initialized
INFO - 2017-02-10 07:39:59 --> Security Class Initialized
INFO - 2017-02-10 07:39:59 --> Router Class Initialized
DEBUG - 2017-02-10 07:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:39:59 --> Input Class Initialized
INFO - 2017-02-10 07:39:59 --> Language Class Initialized
INFO - 2017-02-10 07:39:59 --> Output Class Initialized
ERROR - 2017-02-10 07:39:59 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:39:59 --> Security Class Initialized
DEBUG - 2017-02-10 07:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:39:59 --> Input Class Initialized
INFO - 2017-02-10 07:39:59 --> Language Class Initialized
ERROR - 2017-02-10 07:39:59 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:39:59 --> Config Class Initialized
INFO - 2017-02-10 07:39:59 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:39:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:39:59 --> Utf8 Class Initialized
INFO - 2017-02-10 07:39:59 --> URI Class Initialized
INFO - 2017-02-10 07:39:59 --> Router Class Initialized
INFO - 2017-02-10 07:39:59 --> Output Class Initialized
INFO - 2017-02-10 07:39:59 --> Security Class Initialized
DEBUG - 2017-02-10 07:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:39:59 --> Input Class Initialized
INFO - 2017-02-10 07:39:59 --> Language Class Initialized
ERROR - 2017-02-10 07:39:59 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:39:59 --> Config Class Initialized
INFO - 2017-02-10 07:39:59 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:39:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:39:59 --> Utf8 Class Initialized
INFO - 2017-02-10 07:39:59 --> URI Class Initialized
INFO - 2017-02-10 07:39:59 --> Router Class Initialized
INFO - 2017-02-10 07:39:59 --> Output Class Initialized
INFO - 2017-02-10 07:39:59 --> Security Class Initialized
DEBUG - 2017-02-10 07:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:39:59 --> Input Class Initialized
INFO - 2017-02-10 07:39:59 --> Language Class Initialized
ERROR - 2017-02-10 07:39:59 --> 404 Page Not Found: ../modules/backend/controllers/Newsletter/send-newsletter
INFO - 2017-02-10 07:40:09 --> Config Class Initialized
INFO - 2017-02-10 07:40:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:40:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:40:09 --> Utf8 Class Initialized
INFO - 2017-02-10 07:40:09 --> URI Class Initialized
INFO - 2017-02-10 07:40:09 --> Router Class Initialized
INFO - 2017-02-10 07:40:09 --> Output Class Initialized
INFO - 2017-02-10 07:40:09 --> Security Class Initialized
DEBUG - 2017-02-10 07:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:40:09 --> Input Class Initialized
INFO - 2017-02-10 07:40:09 --> Language Class Initialized
INFO - 2017-02-10 07:40:09 --> Language Class Initialized
INFO - 2017-02-10 07:40:09 --> Config Class Initialized
INFO - 2017-02-10 07:40:09 --> Loader Class Initialized
INFO - 2017-02-10 07:40:09 --> Helper loaded: form_helper
INFO - 2017-02-10 07:40:09 --> Helper loaded: url_helper
INFO - 2017-02-10 07:40:09 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:40:09 --> Database Driver Class Initialized
INFO - 2017-02-10 07:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:40:09 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:40:09 --> Template Class Initialized
INFO - 2017-02-10 07:40:09 --> Controller Class Initialized
INFO - 2017-02-10 07:40:09 --> Model Class Initialized
INFO - 2017-02-10 07:40:09 --> Model Class Initialized
INFO - 2017-02-10 07:40:09 --> Model Class Initialized
ERROR - 2017-02-10 07:40:09 --> Query error: Table 'mobile.trans_notification_subscription' doesn't exist - Invalid query: SELECT *
FROM `trans_notification_subscription`
INFO - 2017-02-10 07:40:09 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-10 07:40:17 --> Config Class Initialized
INFO - 2017-02-10 07:40:17 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:40:17 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:40:17 --> Utf8 Class Initialized
INFO - 2017-02-10 07:40:17 --> URI Class Initialized
INFO - 2017-02-10 07:40:17 --> Router Class Initialized
INFO - 2017-02-10 07:40:17 --> Output Class Initialized
INFO - 2017-02-10 07:40:17 --> Security Class Initialized
DEBUG - 2017-02-10 07:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:40:17 --> Input Class Initialized
INFO - 2017-02-10 07:40:17 --> Language Class Initialized
INFO - 2017-02-10 07:40:17 --> Language Class Initialized
INFO - 2017-02-10 07:40:17 --> Config Class Initialized
INFO - 2017-02-10 07:40:17 --> Loader Class Initialized
INFO - 2017-02-10 07:40:17 --> Helper loaded: form_helper
INFO - 2017-02-10 07:40:17 --> Helper loaded: url_helper
INFO - 2017-02-10 07:40:17 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:40:17 --> Database Driver Class Initialized
INFO - 2017-02-10 07:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:40:17 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:40:17 --> Template Class Initialized
INFO - 2017-02-10 07:40:17 --> Controller Class Initialized
INFO - 2017-02-10 07:40:17 --> Model Class Initialized
INFO - 2017-02-10 07:40:17 --> Model Class Initialized
INFO - 2017-02-10 07:40:17 --> Model Class Initialized
DEBUG - 2017-02-10 07:40:17 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:40:17 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:40:17 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-10 07:40:17 --> Severity: Notice --> Undefined index: user_id C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 101
ERROR - 2017-02-10 07:40:17 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 108
ERROR - 2017-02-10 07:40:17 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 110
ERROR - 2017-02-10 07:40:17 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 112
ERROR - 2017-02-10 07:40:17 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 119
ERROR - 2017-02-10 07:40:17 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 121
ERROR - 2017-02-10 07:40:17 --> Severity: Notice --> Undefined index: user_email C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 128
DEBUG - 2017-02-10 07:40:17 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 07:40:17 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:40:17 --> Final output sent to browser
DEBUG - 2017-02-10 07:40:17 --> Total execution time: 0.0486
INFO - 2017-02-10 07:41:47 --> Config Class Initialized
INFO - 2017-02-10 07:41:47 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:41:47 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:41:47 --> Utf8 Class Initialized
INFO - 2017-02-10 07:41:47 --> URI Class Initialized
INFO - 2017-02-10 07:41:47 --> Router Class Initialized
INFO - 2017-02-10 07:41:47 --> Output Class Initialized
INFO - 2017-02-10 07:41:47 --> Security Class Initialized
DEBUG - 2017-02-10 07:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:41:47 --> Input Class Initialized
INFO - 2017-02-10 07:41:47 --> Language Class Initialized
INFO - 2017-02-10 07:41:47 --> Language Class Initialized
INFO - 2017-02-10 07:41:47 --> Config Class Initialized
INFO - 2017-02-10 07:41:47 --> Loader Class Initialized
INFO - 2017-02-10 07:41:47 --> Helper loaded: form_helper
INFO - 2017-02-10 07:41:47 --> Helper loaded: url_helper
INFO - 2017-02-10 07:41:47 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:41:47 --> Database Driver Class Initialized
INFO - 2017-02-10 07:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:41:47 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:41:47 --> Template Class Initialized
INFO - 2017-02-10 07:41:47 --> Controller Class Initialized
INFO - 2017-02-10 07:41:47 --> Model Class Initialized
INFO - 2017-02-10 07:41:47 --> Model Class Initialized
INFO - 2017-02-10 07:41:47 --> Model Class Initialized
ERROR - 2017-02-10 07:41:47 --> Query error: Table 'mobile.trans_notification_subscription' doesn't exist - Invalid query: SELECT *
FROM `trans_notification_subscription`
INFO - 2017-02-10 07:41:47 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-10 07:45:09 --> Config Class Initialized
INFO - 2017-02-10 07:45:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:45:10 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:45:10 --> Utf8 Class Initialized
INFO - 2017-02-10 07:45:10 --> URI Class Initialized
INFO - 2017-02-10 07:45:10 --> Router Class Initialized
INFO - 2017-02-10 07:45:10 --> Output Class Initialized
INFO - 2017-02-10 07:45:10 --> Security Class Initialized
DEBUG - 2017-02-10 07:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:45:10 --> Input Class Initialized
INFO - 2017-02-10 07:45:10 --> Language Class Initialized
INFO - 2017-02-10 07:45:10 --> Language Class Initialized
INFO - 2017-02-10 07:45:10 --> Config Class Initialized
INFO - 2017-02-10 07:45:10 --> Loader Class Initialized
INFO - 2017-02-10 07:45:10 --> Helper loaded: form_helper
INFO - 2017-02-10 07:45:10 --> Helper loaded: url_helper
INFO - 2017-02-10 07:45:10 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:45:10 --> Database Driver Class Initialized
INFO - 2017-02-10 07:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:45:10 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:45:10 --> Template Class Initialized
INFO - 2017-02-10 07:45:10 --> Controller Class Initialized
INFO - 2017-02-10 07:45:10 --> Model Class Initialized
INFO - 2017-02-10 07:45:10 --> Model Class Initialized
INFO - 2017-02-10 07:45:10 --> Model Class Initialized
INFO - 2017-02-10 07:47:00 --> Config Class Initialized
INFO - 2017-02-10 07:47:00 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:47:00 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:47:00 --> Utf8 Class Initialized
INFO - 2017-02-10 07:47:00 --> URI Class Initialized
INFO - 2017-02-10 07:47:00 --> Router Class Initialized
INFO - 2017-02-10 07:47:00 --> Output Class Initialized
INFO - 2017-02-10 07:47:00 --> Security Class Initialized
DEBUG - 2017-02-10 07:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:47:00 --> Input Class Initialized
INFO - 2017-02-10 07:47:00 --> Language Class Initialized
INFO - 2017-02-10 07:47:00 --> Language Class Initialized
INFO - 2017-02-10 07:47:00 --> Config Class Initialized
INFO - 2017-02-10 07:47:00 --> Loader Class Initialized
INFO - 2017-02-10 07:47:00 --> Helper loaded: form_helper
INFO - 2017-02-10 07:47:00 --> Helper loaded: url_helper
INFO - 2017-02-10 07:47:00 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:47:00 --> Database Driver Class Initialized
INFO - 2017-02-10 07:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:47:00 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:47:00 --> Template Class Initialized
INFO - 2017-02-10 07:47:00 --> Controller Class Initialized
INFO - 2017-02-10 07:47:00 --> Model Class Initialized
INFO - 2017-02-10 07:47:00 --> Model Class Initialized
INFO - 2017-02-10 07:47:00 --> Model Class Initialized
DEBUG - 2017-02-10 07:47:00 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:47:00 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:47:00 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:47:00 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 07:47:00 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:47:00 --> Final output sent to browser
DEBUG - 2017-02-10 07:47:00 --> Total execution time: 0.0758
INFO - 2017-02-10 07:47:01 --> Config Class Initialized
INFO - 2017-02-10 07:47:01 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:47:01 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:47:01 --> Utf8 Class Initialized
INFO - 2017-02-10 07:47:01 --> URI Class Initialized
INFO - 2017-02-10 07:47:01 --> Router Class Initialized
INFO - 2017-02-10 07:47:01 --> Output Class Initialized
INFO - 2017-02-10 07:47:01 --> Config Class Initialized
INFO - 2017-02-10 07:47:01 --> Security Class Initialized
INFO - 2017-02-10 07:47:01 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:47:01 --> Input Class Initialized
INFO - 2017-02-10 07:47:01 --> Language Class Initialized
DEBUG - 2017-02-10 07:47:01 --> UTF-8 Support Enabled
ERROR - 2017-02-10 07:47:01 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:47:01 --> Utf8 Class Initialized
INFO - 2017-02-10 07:47:01 --> URI Class Initialized
INFO - 2017-02-10 07:47:01 --> Router Class Initialized
INFO - 2017-02-10 07:47:01 --> Output Class Initialized
INFO - 2017-02-10 07:47:01 --> Security Class Initialized
DEBUG - 2017-02-10 07:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:47:01 --> Input Class Initialized
INFO - 2017-02-10 07:47:01 --> Language Class Initialized
ERROR - 2017-02-10 07:47:01 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:47:01 --> Config Class Initialized
INFO - 2017-02-10 07:47:01 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:47:01 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:47:01 --> Utf8 Class Initialized
INFO - 2017-02-10 07:47:01 --> URI Class Initialized
INFO - 2017-02-10 07:47:01 --> Router Class Initialized
INFO - 2017-02-10 07:47:01 --> Output Class Initialized
INFO - 2017-02-10 07:47:01 --> Security Class Initialized
DEBUG - 2017-02-10 07:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:47:01 --> Input Class Initialized
INFO - 2017-02-10 07:47:01 --> Language Class Initialized
ERROR - 2017-02-10 07:47:01 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:47:01 --> Config Class Initialized
INFO - 2017-02-10 07:47:01 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:47:01 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:47:01 --> Utf8 Class Initialized
INFO - 2017-02-10 07:47:01 --> URI Class Initialized
INFO - 2017-02-10 07:47:01 --> Router Class Initialized
INFO - 2017-02-10 07:47:01 --> Output Class Initialized
INFO - 2017-02-10 07:47:01 --> Security Class Initialized
DEBUG - 2017-02-10 07:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:47:01 --> Input Class Initialized
INFO - 2017-02-10 07:47:01 --> Language Class Initialized
ERROR - 2017-02-10 07:47:01 --> 404 Page Not Found: ../modules/backend/controllers/Newsletter/send-newsletter-visitor
INFO - 2017-02-10 07:47:09 --> Config Class Initialized
INFO - 2017-02-10 07:47:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:47:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:47:09 --> Utf8 Class Initialized
INFO - 2017-02-10 07:47:09 --> URI Class Initialized
INFO - 2017-02-10 07:47:09 --> Router Class Initialized
INFO - 2017-02-10 07:47:09 --> Output Class Initialized
INFO - 2017-02-10 07:47:09 --> Security Class Initialized
DEBUG - 2017-02-10 07:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:47:09 --> Input Class Initialized
INFO - 2017-02-10 07:47:09 --> Language Class Initialized
INFO - 2017-02-10 07:47:09 --> Language Class Initialized
INFO - 2017-02-10 07:47:09 --> Config Class Initialized
INFO - 2017-02-10 07:47:09 --> Loader Class Initialized
INFO - 2017-02-10 07:47:09 --> Helper loaded: form_helper
INFO - 2017-02-10 07:47:09 --> Helper loaded: url_helper
INFO - 2017-02-10 07:47:09 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:47:09 --> Database Driver Class Initialized
INFO - 2017-02-10 07:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:47:09 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:47:09 --> Template Class Initialized
INFO - 2017-02-10 07:47:09 --> Controller Class Initialized
INFO - 2017-02-10 07:47:09 --> Model Class Initialized
INFO - 2017-02-10 07:47:09 --> Model Class Initialized
INFO - 2017-02-10 07:47:09 --> Model Class Initialized
DEBUG - 2017-02-10 07:47:09 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:47:09 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:47:09 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:47:09 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 07:47:09 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:47:09 --> Final output sent to browser
DEBUG - 2017-02-10 07:47:09 --> Total execution time: 0.0491
INFO - 2017-02-10 07:47:09 --> Config Class Initialized
INFO - 2017-02-10 07:47:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:47:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:47:09 --> Utf8 Class Initialized
INFO - 2017-02-10 07:47:09 --> Config Class Initialized
INFO - 2017-02-10 07:47:09 --> Hooks Class Initialized
INFO - 2017-02-10 07:47:09 --> URI Class Initialized
INFO - 2017-02-10 07:47:09 --> Router Class Initialized
DEBUG - 2017-02-10 07:47:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:47:09 --> Utf8 Class Initialized
INFO - 2017-02-10 07:47:09 --> Output Class Initialized
INFO - 2017-02-10 07:47:09 --> URI Class Initialized
INFO - 2017-02-10 07:47:09 --> Security Class Initialized
DEBUG - 2017-02-10 07:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:47:09 --> Input Class Initialized
INFO - 2017-02-10 07:47:09 --> Router Class Initialized
INFO - 2017-02-10 07:47:09 --> Language Class Initialized
INFO - 2017-02-10 07:47:09 --> Output Class Initialized
ERROR - 2017-02-10 07:47:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:47:09 --> Security Class Initialized
DEBUG - 2017-02-10 07:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:47:09 --> Input Class Initialized
INFO - 2017-02-10 07:47:09 --> Language Class Initialized
ERROR - 2017-02-10 07:47:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:47:09 --> Config Class Initialized
INFO - 2017-02-10 07:47:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:47:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:47:09 --> Utf8 Class Initialized
INFO - 2017-02-10 07:47:09 --> URI Class Initialized
INFO - 2017-02-10 07:47:09 --> Router Class Initialized
INFO - 2017-02-10 07:47:09 --> Output Class Initialized
INFO - 2017-02-10 07:47:09 --> Security Class Initialized
DEBUG - 2017-02-10 07:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:47:09 --> Input Class Initialized
INFO - 2017-02-10 07:47:09 --> Language Class Initialized
ERROR - 2017-02-10 07:47:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:48:00 --> Config Class Initialized
INFO - 2017-02-10 07:48:00 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:48:00 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:48:00 --> Utf8 Class Initialized
INFO - 2017-02-10 07:48:00 --> URI Class Initialized
INFO - 2017-02-10 07:48:00 --> Router Class Initialized
INFO - 2017-02-10 07:48:00 --> Output Class Initialized
INFO - 2017-02-10 07:48:00 --> Security Class Initialized
DEBUG - 2017-02-10 07:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:48:00 --> Input Class Initialized
INFO - 2017-02-10 07:48:00 --> Language Class Initialized
INFO - 2017-02-10 07:48:00 --> Language Class Initialized
INFO - 2017-02-10 07:48:00 --> Config Class Initialized
INFO - 2017-02-10 07:48:00 --> Loader Class Initialized
INFO - 2017-02-10 07:48:00 --> Helper loaded: form_helper
INFO - 2017-02-10 07:48:00 --> Helper loaded: url_helper
INFO - 2017-02-10 07:48:00 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:48:00 --> Database Driver Class Initialized
INFO - 2017-02-10 07:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:48:00 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:48:00 --> Template Class Initialized
INFO - 2017-02-10 07:48:00 --> Controller Class Initialized
INFO - 2017-02-10 07:48:00 --> Model Class Initialized
INFO - 2017-02-10 07:48:00 --> Model Class Initialized
INFO - 2017-02-10 07:48:00 --> Model Class Initialized
DEBUG - 2017-02-10 07:48:00 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:48:00 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:48:00 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-10 07:48:00 --> Severity: Notice --> Undefined index: user_id C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 101
ERROR - 2017-02-10 07:48:00 --> Severity: Notice --> Undefined index: first_name C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 104
ERROR - 2017-02-10 07:48:00 --> Severity: Notice --> Undefined index: last_name C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 105
ERROR - 2017-02-10 07:48:00 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 108
ERROR - 2017-02-10 07:48:00 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 110
ERROR - 2017-02-10 07:48:00 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 112
ERROR - 2017-02-10 07:48:00 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 119
ERROR - 2017-02-10 07:48:00 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 121
ERROR - 2017-02-10 07:48:00 --> Severity: Notice --> Undefined index: user_email C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 128
ERROR - 2017-02-10 07:48:00 --> Severity: Notice --> Undefined index: user_id C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 101
ERROR - 2017-02-10 07:48:00 --> Severity: Notice --> Undefined index: first_name C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 104
ERROR - 2017-02-10 07:48:00 --> Severity: Notice --> Undefined index: last_name C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 105
ERROR - 2017-02-10 07:48:00 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 108
ERROR - 2017-02-10 07:48:00 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 110
ERROR - 2017-02-10 07:48:00 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 112
ERROR - 2017-02-10 07:48:00 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 119
ERROR - 2017-02-10 07:48:00 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 121
ERROR - 2017-02-10 07:48:00 --> Severity: Notice --> Undefined index: user_email C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 128
DEBUG - 2017-02-10 07:48:00 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 07:48:00 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:48:00 --> Final output sent to browser
DEBUG - 2017-02-10 07:48:00 --> Total execution time: 0.0976
INFO - 2017-02-10 07:48:00 --> Config Class Initialized
INFO - 2017-02-10 07:48:00 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:48:00 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:48:00 --> Utf8 Class Initialized
INFO - 2017-02-10 07:48:00 --> Config Class Initialized
INFO - 2017-02-10 07:48:00 --> Hooks Class Initialized
INFO - 2017-02-10 07:48:00 --> URI Class Initialized
DEBUG - 2017-02-10 07:48:00 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:48:00 --> Utf8 Class Initialized
INFO - 2017-02-10 07:48:00 --> Router Class Initialized
INFO - 2017-02-10 07:48:00 --> URI Class Initialized
INFO - 2017-02-10 07:48:00 --> Output Class Initialized
INFO - 2017-02-10 07:48:00 --> Security Class Initialized
INFO - 2017-02-10 07:48:00 --> Router Class Initialized
DEBUG - 2017-02-10 07:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:48:00 --> Input Class Initialized
INFO - 2017-02-10 07:48:00 --> Language Class Initialized
INFO - 2017-02-10 07:48:00 --> Output Class Initialized
ERROR - 2017-02-10 07:48:00 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:48:00 --> Security Class Initialized
DEBUG - 2017-02-10 07:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:48:00 --> Input Class Initialized
INFO - 2017-02-10 07:48:00 --> Language Class Initialized
ERROR - 2017-02-10 07:48:00 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:48:00 --> Config Class Initialized
INFO - 2017-02-10 07:48:00 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:48:00 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:48:00 --> Utf8 Class Initialized
INFO - 2017-02-10 07:48:00 --> URI Class Initialized
INFO - 2017-02-10 07:48:00 --> Router Class Initialized
INFO - 2017-02-10 07:48:00 --> Output Class Initialized
INFO - 2017-02-10 07:48:00 --> Security Class Initialized
DEBUG - 2017-02-10 07:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:48:00 --> Input Class Initialized
INFO - 2017-02-10 07:48:00 --> Language Class Initialized
ERROR - 2017-02-10 07:48:00 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:48:23 --> Config Class Initialized
INFO - 2017-02-10 07:48:23 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:48:23 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:48:23 --> Utf8 Class Initialized
INFO - 2017-02-10 07:48:23 --> URI Class Initialized
INFO - 2017-02-10 07:48:23 --> Router Class Initialized
INFO - 2017-02-10 07:48:23 --> Output Class Initialized
INFO - 2017-02-10 07:48:23 --> Security Class Initialized
DEBUG - 2017-02-10 07:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:48:23 --> Input Class Initialized
INFO - 2017-02-10 07:48:23 --> Language Class Initialized
INFO - 2017-02-10 07:48:23 --> Language Class Initialized
INFO - 2017-02-10 07:48:23 --> Config Class Initialized
INFO - 2017-02-10 07:48:23 --> Loader Class Initialized
INFO - 2017-02-10 07:48:23 --> Helper loaded: form_helper
INFO - 2017-02-10 07:48:23 --> Helper loaded: url_helper
INFO - 2017-02-10 07:48:23 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:48:23 --> Database Driver Class Initialized
INFO - 2017-02-10 07:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:48:23 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:48:23 --> Template Class Initialized
INFO - 2017-02-10 07:48:23 --> Controller Class Initialized
INFO - 2017-02-10 07:48:23 --> Model Class Initialized
INFO - 2017-02-10 07:48:23 --> Model Class Initialized
INFO - 2017-02-10 07:48:23 --> Model Class Initialized
DEBUG - 2017-02-10 07:48:23 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:48:23 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:48:23 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-10 07:48:23 --> Severity: Notice --> Undefined index: user_id C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 101
ERROR - 2017-02-10 07:48:23 --> Severity: Notice --> Undefined index: first_name C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 104
ERROR - 2017-02-10 07:48:23 --> Severity: Notice --> Undefined index: last_name C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 105
ERROR - 2017-02-10 07:48:23 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 108
ERROR - 2017-02-10 07:48:23 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 110
ERROR - 2017-02-10 07:48:23 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 112
ERROR - 2017-02-10 07:48:23 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 119
ERROR - 2017-02-10 07:48:23 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 121
ERROR - 2017-02-10 07:48:23 --> Severity: Notice --> Undefined index: user_id C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 101
ERROR - 2017-02-10 07:48:23 --> Severity: Notice --> Undefined index: first_name C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 104
ERROR - 2017-02-10 07:48:23 --> Severity: Notice --> Undefined index: last_name C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 105
ERROR - 2017-02-10 07:48:23 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 108
ERROR - 2017-02-10 07:48:23 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 110
ERROR - 2017-02-10 07:48:23 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 112
ERROR - 2017-02-10 07:48:23 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 119
ERROR - 2017-02-10 07:48:23 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 121
DEBUG - 2017-02-10 07:48:23 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 07:48:23 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:48:23 --> Final output sent to browser
DEBUG - 2017-02-10 07:48:23 --> Total execution time: 0.0883
INFO - 2017-02-10 07:48:23 --> Config Class Initialized
INFO - 2017-02-10 07:48:23 --> Hooks Class Initialized
INFO - 2017-02-10 07:48:23 --> Config Class Initialized
INFO - 2017-02-10 07:48:23 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:48:23 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 07:48:23 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:48:23 --> Utf8 Class Initialized
INFO - 2017-02-10 07:48:23 --> Utf8 Class Initialized
INFO - 2017-02-10 07:48:23 --> URI Class Initialized
INFO - 2017-02-10 07:48:23 --> URI Class Initialized
INFO - 2017-02-10 07:48:23 --> Router Class Initialized
INFO - 2017-02-10 07:48:23 --> Router Class Initialized
INFO - 2017-02-10 07:48:23 --> Output Class Initialized
INFO - 2017-02-10 07:48:23 --> Output Class Initialized
INFO - 2017-02-10 07:48:23 --> Security Class Initialized
INFO - 2017-02-10 07:48:23 --> Security Class Initialized
DEBUG - 2017-02-10 07:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:48:23 --> Input Class Initialized
INFO - 2017-02-10 07:48:23 --> Language Class Initialized
ERROR - 2017-02-10 07:48:23 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 07:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:48:23 --> Input Class Initialized
INFO - 2017-02-10 07:48:23 --> Language Class Initialized
ERROR - 2017-02-10 07:48:23 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:48:23 --> Config Class Initialized
INFO - 2017-02-10 07:48:23 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:48:23 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:48:23 --> Utf8 Class Initialized
INFO - 2017-02-10 07:48:23 --> URI Class Initialized
INFO - 2017-02-10 07:48:23 --> Router Class Initialized
INFO - 2017-02-10 07:48:23 --> Output Class Initialized
INFO - 2017-02-10 07:48:23 --> Security Class Initialized
DEBUG - 2017-02-10 07:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:48:23 --> Input Class Initialized
INFO - 2017-02-10 07:48:23 --> Language Class Initialized
ERROR - 2017-02-10 07:48:23 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:50:55 --> Config Class Initialized
INFO - 2017-02-10 07:50:55 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:50:55 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:50:55 --> Utf8 Class Initialized
INFO - 2017-02-10 07:50:55 --> URI Class Initialized
INFO - 2017-02-10 07:50:55 --> Router Class Initialized
INFO - 2017-02-10 07:50:55 --> Output Class Initialized
INFO - 2017-02-10 07:50:55 --> Security Class Initialized
DEBUG - 2017-02-10 07:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:50:55 --> Input Class Initialized
INFO - 2017-02-10 07:50:55 --> Language Class Initialized
INFO - 2017-02-10 07:50:55 --> Language Class Initialized
INFO - 2017-02-10 07:50:55 --> Config Class Initialized
INFO - 2017-02-10 07:50:55 --> Loader Class Initialized
INFO - 2017-02-10 07:50:55 --> Helper loaded: form_helper
INFO - 2017-02-10 07:50:55 --> Helper loaded: url_helper
INFO - 2017-02-10 07:50:55 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:50:55 --> Database Driver Class Initialized
INFO - 2017-02-10 07:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:50:55 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:50:55 --> Template Class Initialized
INFO - 2017-02-10 07:50:55 --> Controller Class Initialized
INFO - 2017-02-10 07:50:55 --> Model Class Initialized
INFO - 2017-02-10 07:50:55 --> Model Class Initialized
INFO - 2017-02-10 07:50:55 --> Model Class Initialized
DEBUG - 2017-02-10 07:50:55 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:50:55 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:50:55 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-10 07:50:55 --> Severity: Notice --> Undefined index: user_id C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 101
ERROR - 2017-02-10 07:50:55 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 108
ERROR - 2017-02-10 07:50:55 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 110
ERROR - 2017-02-10 07:50:55 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 112
ERROR - 2017-02-10 07:50:55 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 119
ERROR - 2017-02-10 07:50:55 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 121
ERROR - 2017-02-10 07:50:55 --> Severity: Notice --> Undefined index: user_id C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 101
ERROR - 2017-02-10 07:50:55 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 108
ERROR - 2017-02-10 07:50:55 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 110
ERROR - 2017-02-10 07:50:55 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 112
ERROR - 2017-02-10 07:50:55 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 119
ERROR - 2017-02-10 07:50:55 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 121
DEBUG - 2017-02-10 07:50:55 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 07:50:55 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:50:55 --> Final output sent to browser
DEBUG - 2017-02-10 07:50:55 --> Total execution time: 0.0764
INFO - 2017-02-10 07:50:55 --> Config Class Initialized
INFO - 2017-02-10 07:50:55 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:50:55 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:50:55 --> Utf8 Class Initialized
INFO - 2017-02-10 07:50:55 --> URI Class Initialized
INFO - 2017-02-10 07:50:55 --> Config Class Initialized
INFO - 2017-02-10 07:50:55 --> Hooks Class Initialized
INFO - 2017-02-10 07:50:55 --> Router Class Initialized
INFO - 2017-02-10 07:50:55 --> Output Class Initialized
DEBUG - 2017-02-10 07:50:55 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:50:55 --> Utf8 Class Initialized
INFO - 2017-02-10 07:50:55 --> Security Class Initialized
INFO - 2017-02-10 07:50:55 --> URI Class Initialized
DEBUG - 2017-02-10 07:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:50:55 --> Input Class Initialized
INFO - 2017-02-10 07:50:55 --> Language Class Initialized
INFO - 2017-02-10 07:50:55 --> Router Class Initialized
ERROR - 2017-02-10 07:50:55 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:50:55 --> Output Class Initialized
INFO - 2017-02-10 07:50:55 --> Security Class Initialized
DEBUG - 2017-02-10 07:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:50:55 --> Input Class Initialized
INFO - 2017-02-10 07:50:55 --> Language Class Initialized
ERROR - 2017-02-10 07:50:55 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:50:55 --> Config Class Initialized
INFO - 2017-02-10 07:50:55 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:50:55 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:50:55 --> Utf8 Class Initialized
INFO - 2017-02-10 07:50:55 --> URI Class Initialized
INFO - 2017-02-10 07:50:55 --> Router Class Initialized
INFO - 2017-02-10 07:50:55 --> Output Class Initialized
INFO - 2017-02-10 07:50:55 --> Security Class Initialized
DEBUG - 2017-02-10 07:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:50:55 --> Input Class Initialized
INFO - 2017-02-10 07:50:55 --> Language Class Initialized
ERROR - 2017-02-10 07:50:55 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:51:23 --> Config Class Initialized
INFO - 2017-02-10 07:51:23 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:51:23 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:51:23 --> Utf8 Class Initialized
INFO - 2017-02-10 07:51:23 --> URI Class Initialized
INFO - 2017-02-10 07:51:23 --> Router Class Initialized
INFO - 2017-02-10 07:51:23 --> Output Class Initialized
INFO - 2017-02-10 07:51:23 --> Security Class Initialized
DEBUG - 2017-02-10 07:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:51:23 --> Input Class Initialized
INFO - 2017-02-10 07:51:23 --> Language Class Initialized
INFO - 2017-02-10 07:51:23 --> Language Class Initialized
INFO - 2017-02-10 07:51:23 --> Config Class Initialized
INFO - 2017-02-10 07:51:23 --> Loader Class Initialized
INFO - 2017-02-10 07:51:23 --> Helper loaded: form_helper
INFO - 2017-02-10 07:51:23 --> Helper loaded: url_helper
INFO - 2017-02-10 07:51:23 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:51:23 --> Database Driver Class Initialized
INFO - 2017-02-10 07:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:51:23 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:51:23 --> Template Class Initialized
INFO - 2017-02-10 07:51:23 --> Controller Class Initialized
INFO - 2017-02-10 07:51:23 --> Model Class Initialized
INFO - 2017-02-10 07:51:23 --> Model Class Initialized
INFO - 2017-02-10 07:51:23 --> Model Class Initialized
DEBUG - 2017-02-10 07:51:23 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:51:23 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:51:23 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-10 07:51:23 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 108
ERROR - 2017-02-10 07:51:23 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 110
ERROR - 2017-02-10 07:51:23 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 112
ERROR - 2017-02-10 07:51:23 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 119
ERROR - 2017-02-10 07:51:23 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 121
ERROR - 2017-02-10 07:51:23 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 108
ERROR - 2017-02-10 07:51:23 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 110
ERROR - 2017-02-10 07:51:23 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 112
ERROR - 2017-02-10 07:51:23 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 119
ERROR - 2017-02-10 07:51:23 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 121
DEBUG - 2017-02-10 07:51:23 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 07:51:23 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:51:23 --> Final output sent to browser
DEBUG - 2017-02-10 07:51:23 --> Total execution time: 0.0789
INFO - 2017-02-10 07:51:23 --> Config Class Initialized
INFO - 2017-02-10 07:51:23 --> Hooks Class Initialized
INFO - 2017-02-10 07:51:23 --> Config Class Initialized
DEBUG - 2017-02-10 07:51:23 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:51:23 --> Hooks Class Initialized
INFO - 2017-02-10 07:51:23 --> Utf8 Class Initialized
INFO - 2017-02-10 07:51:23 --> URI Class Initialized
DEBUG - 2017-02-10 07:51:23 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:51:23 --> Utf8 Class Initialized
INFO - 2017-02-10 07:51:23 --> URI Class Initialized
INFO - 2017-02-10 07:51:23 --> Router Class Initialized
INFO - 2017-02-10 07:51:23 --> Output Class Initialized
INFO - 2017-02-10 07:51:23 --> Router Class Initialized
INFO - 2017-02-10 07:51:23 --> Output Class Initialized
INFO - 2017-02-10 07:51:23 --> Security Class Initialized
INFO - 2017-02-10 07:51:23 --> Security Class Initialized
DEBUG - 2017-02-10 07:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:51:23 --> Input Class Initialized
DEBUG - 2017-02-10 07:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:51:23 --> Input Class Initialized
INFO - 2017-02-10 07:51:23 --> Language Class Initialized
INFO - 2017-02-10 07:51:23 --> Language Class Initialized
ERROR - 2017-02-10 07:51:23 --> 404 Page Not Found: /index
ERROR - 2017-02-10 07:51:23 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:51:23 --> Config Class Initialized
INFO - 2017-02-10 07:51:23 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:51:23 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:51:23 --> Utf8 Class Initialized
INFO - 2017-02-10 07:51:23 --> URI Class Initialized
INFO - 2017-02-10 07:51:23 --> Router Class Initialized
INFO - 2017-02-10 07:51:23 --> Output Class Initialized
INFO - 2017-02-10 07:51:23 --> Security Class Initialized
DEBUG - 2017-02-10 07:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:51:23 --> Input Class Initialized
INFO - 2017-02-10 07:51:23 --> Language Class Initialized
ERROR - 2017-02-10 07:51:23 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:51:50 --> Config Class Initialized
INFO - 2017-02-10 07:51:50 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:51:50 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:51:50 --> Utf8 Class Initialized
INFO - 2017-02-10 07:51:50 --> URI Class Initialized
INFO - 2017-02-10 07:51:50 --> Router Class Initialized
INFO - 2017-02-10 07:51:50 --> Output Class Initialized
INFO - 2017-02-10 07:51:50 --> Security Class Initialized
DEBUG - 2017-02-10 07:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:51:50 --> Input Class Initialized
INFO - 2017-02-10 07:51:50 --> Language Class Initialized
INFO - 2017-02-10 07:51:50 --> Language Class Initialized
INFO - 2017-02-10 07:51:50 --> Config Class Initialized
INFO - 2017-02-10 07:51:50 --> Loader Class Initialized
INFO - 2017-02-10 07:51:50 --> Helper loaded: form_helper
INFO - 2017-02-10 07:51:50 --> Helper loaded: url_helper
INFO - 2017-02-10 07:51:50 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:51:50 --> Database Driver Class Initialized
INFO - 2017-02-10 07:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:51:50 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:51:50 --> Template Class Initialized
INFO - 2017-02-10 07:51:50 --> Controller Class Initialized
INFO - 2017-02-10 07:51:50 --> Model Class Initialized
INFO - 2017-02-10 07:51:50 --> Model Class Initialized
INFO - 2017-02-10 07:51:50 --> Model Class Initialized
DEBUG - 2017-02-10 07:51:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:51:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:51:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-10 07:51:50 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 119
ERROR - 2017-02-10 07:51:50 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 121
ERROR - 2017-02-10 07:51:50 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 119
ERROR - 2017-02-10 07:51:50 --> Severity: Notice --> Undefined index: user_type C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 121
DEBUG - 2017-02-10 07:51:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 07:51:50 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:51:50 --> Final output sent to browser
DEBUG - 2017-02-10 07:51:50 --> Total execution time: 0.0922
INFO - 2017-02-10 07:51:50 --> Config Class Initialized
INFO - 2017-02-10 07:51:50 --> Hooks Class Initialized
INFO - 2017-02-10 07:51:50 --> Config Class Initialized
INFO - 2017-02-10 07:51:50 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:51:50 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:51:50 --> Utf8 Class Initialized
DEBUG - 2017-02-10 07:51:50 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:51:50 --> Utf8 Class Initialized
INFO - 2017-02-10 07:51:50 --> URI Class Initialized
INFO - 2017-02-10 07:51:50 --> URI Class Initialized
INFO - 2017-02-10 07:51:50 --> Router Class Initialized
INFO - 2017-02-10 07:51:50 --> Router Class Initialized
INFO - 2017-02-10 07:51:50 --> Output Class Initialized
INFO - 2017-02-10 07:51:50 --> Output Class Initialized
INFO - 2017-02-10 07:51:50 --> Security Class Initialized
INFO - 2017-02-10 07:51:50 --> Security Class Initialized
DEBUG - 2017-02-10 07:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:51:50 --> Input Class Initialized
DEBUG - 2017-02-10 07:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:51:50 --> Input Class Initialized
INFO - 2017-02-10 07:51:50 --> Language Class Initialized
INFO - 2017-02-10 07:51:50 --> Language Class Initialized
ERROR - 2017-02-10 07:51:50 --> 404 Page Not Found: /index
ERROR - 2017-02-10 07:51:50 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:51:50 --> Config Class Initialized
INFO - 2017-02-10 07:51:50 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:51:50 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:51:50 --> Utf8 Class Initialized
INFO - 2017-02-10 07:51:50 --> URI Class Initialized
INFO - 2017-02-10 07:51:50 --> Router Class Initialized
INFO - 2017-02-10 07:51:50 --> Output Class Initialized
INFO - 2017-02-10 07:51:50 --> Security Class Initialized
DEBUG - 2017-02-10 07:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:51:50 --> Input Class Initialized
INFO - 2017-02-10 07:51:50 --> Language Class Initialized
ERROR - 2017-02-10 07:51:50 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:52:11 --> Config Class Initialized
INFO - 2017-02-10 07:52:11 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:52:11 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:52:11 --> Utf8 Class Initialized
INFO - 2017-02-10 07:52:11 --> URI Class Initialized
INFO - 2017-02-10 07:52:11 --> Router Class Initialized
INFO - 2017-02-10 07:52:11 --> Output Class Initialized
INFO - 2017-02-10 07:52:11 --> Security Class Initialized
DEBUG - 2017-02-10 07:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:52:11 --> Input Class Initialized
INFO - 2017-02-10 07:52:11 --> Language Class Initialized
INFO - 2017-02-10 07:52:11 --> Language Class Initialized
INFO - 2017-02-10 07:52:11 --> Config Class Initialized
INFO - 2017-02-10 07:52:11 --> Loader Class Initialized
INFO - 2017-02-10 07:52:11 --> Helper loaded: form_helper
INFO - 2017-02-10 07:52:11 --> Helper loaded: url_helper
INFO - 2017-02-10 07:52:11 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:52:11 --> Database Driver Class Initialized
INFO - 2017-02-10 07:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:52:11 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:52:11 --> Template Class Initialized
INFO - 2017-02-10 07:52:11 --> Controller Class Initialized
INFO - 2017-02-10 07:52:11 --> Model Class Initialized
INFO - 2017-02-10 07:52:11 --> Model Class Initialized
INFO - 2017-02-10 07:52:11 --> Model Class Initialized
DEBUG - 2017-02-10 07:52:11 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:52:11 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:52:11 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:52:11 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 07:52:11 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:52:11 --> Final output sent to browser
DEBUG - 2017-02-10 07:52:11 --> Total execution time: 0.0630
INFO - 2017-02-10 07:52:11 --> Config Class Initialized
INFO - 2017-02-10 07:52:11 --> Config Class Initialized
INFO - 2017-02-10 07:52:11 --> Hooks Class Initialized
INFO - 2017-02-10 07:52:11 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:52:11 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 07:52:11 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:52:11 --> Utf8 Class Initialized
INFO - 2017-02-10 07:52:11 --> Utf8 Class Initialized
INFO - 2017-02-10 07:52:11 --> URI Class Initialized
INFO - 2017-02-10 07:52:11 --> URI Class Initialized
INFO - 2017-02-10 07:52:11 --> Router Class Initialized
INFO - 2017-02-10 07:52:11 --> Router Class Initialized
INFO - 2017-02-10 07:52:11 --> Output Class Initialized
INFO - 2017-02-10 07:52:11 --> Output Class Initialized
INFO - 2017-02-10 07:52:11 --> Security Class Initialized
INFO - 2017-02-10 07:52:11 --> Security Class Initialized
DEBUG - 2017-02-10 07:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:52:11 --> Input Class Initialized
INFO - 2017-02-10 07:52:11 --> Language Class Initialized
DEBUG - 2017-02-10 07:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:52:11 --> Input Class Initialized
ERROR - 2017-02-10 07:52:11 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:52:11 --> Language Class Initialized
ERROR - 2017-02-10 07:52:11 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:52:11 --> Config Class Initialized
INFO - 2017-02-10 07:52:11 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:52:11 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:52:11 --> Utf8 Class Initialized
INFO - 2017-02-10 07:52:11 --> URI Class Initialized
INFO - 2017-02-10 07:52:11 --> Router Class Initialized
INFO - 2017-02-10 07:52:11 --> Output Class Initialized
INFO - 2017-02-10 07:52:11 --> Security Class Initialized
DEBUG - 2017-02-10 07:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:52:11 --> Input Class Initialized
INFO - 2017-02-10 07:52:11 --> Language Class Initialized
ERROR - 2017-02-10 07:52:11 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:58:54 --> Config Class Initialized
INFO - 2017-02-10 07:58:54 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:58:54 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:58:54 --> Utf8 Class Initialized
INFO - 2017-02-10 07:58:54 --> URI Class Initialized
INFO - 2017-02-10 07:58:54 --> Router Class Initialized
INFO - 2017-02-10 07:58:54 --> Output Class Initialized
INFO - 2017-02-10 07:58:54 --> Security Class Initialized
DEBUG - 2017-02-10 07:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:58:54 --> Input Class Initialized
INFO - 2017-02-10 07:58:54 --> Language Class Initialized
INFO - 2017-02-10 07:58:54 --> Language Class Initialized
INFO - 2017-02-10 07:58:54 --> Config Class Initialized
INFO - 2017-02-10 07:58:54 --> Loader Class Initialized
INFO - 2017-02-10 07:58:54 --> Helper loaded: form_helper
INFO - 2017-02-10 07:58:54 --> Helper loaded: url_helper
INFO - 2017-02-10 07:58:54 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:58:54 --> Database Driver Class Initialized
INFO - 2017-02-10 07:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:58:54 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:58:54 --> Template Class Initialized
INFO - 2017-02-10 07:58:54 --> Controller Class Initialized
INFO - 2017-02-10 07:58:54 --> Model Class Initialized
INFO - 2017-02-10 07:58:54 --> Model Class Initialized
INFO - 2017-02-10 07:58:54 --> Model Class Initialized
DEBUG - 2017-02-10 07:58:54 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:58:54 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:58:54 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:58:54 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 07:58:54 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:58:54 --> Final output sent to browser
DEBUG - 2017-02-10 07:58:54 --> Total execution time: 1.0148
INFO - 2017-02-10 07:59:05 --> Config Class Initialized
INFO - 2017-02-10 07:59:05 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:59:05 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:59:05 --> Utf8 Class Initialized
INFO - 2017-02-10 07:59:05 --> URI Class Initialized
INFO - 2017-02-10 07:59:05 --> Router Class Initialized
INFO - 2017-02-10 07:59:05 --> Output Class Initialized
INFO - 2017-02-10 07:59:05 --> Security Class Initialized
DEBUG - 2017-02-10 07:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:59:05 --> Input Class Initialized
INFO - 2017-02-10 07:59:05 --> Language Class Initialized
INFO - 2017-02-10 07:59:05 --> Language Class Initialized
INFO - 2017-02-10 07:59:05 --> Config Class Initialized
INFO - 2017-02-10 07:59:05 --> Loader Class Initialized
INFO - 2017-02-10 07:59:05 --> Helper loaded: form_helper
INFO - 2017-02-10 07:59:05 --> Helper loaded: url_helper
INFO - 2017-02-10 07:59:05 --> Helper loaded: utility_helper
INFO - 2017-02-10 07:59:05 --> Database Driver Class Initialized
INFO - 2017-02-10 07:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:59:05 --> User Agent Class Initialized
DEBUG - 2017-02-10 07:59:05 --> Template Class Initialized
INFO - 2017-02-10 07:59:05 --> Controller Class Initialized
INFO - 2017-02-10 07:59:05 --> Model Class Initialized
INFO - 2017-02-10 07:59:05 --> Model Class Initialized
INFO - 2017-02-10 07:59:05 --> Model Class Initialized
DEBUG - 2017-02-10 07:59:05 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 07:59:05 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 07:59:05 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 07:59:05 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 07:59:05 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 07:59:05 --> Final output sent to browser
DEBUG - 2017-02-10 07:59:05 --> Total execution time: 0.0551
INFO - 2017-02-10 07:59:05 --> Config Class Initialized
INFO - 2017-02-10 07:59:05 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:59:05 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:59:05 --> Utf8 Class Initialized
INFO - 2017-02-10 07:59:05 --> URI Class Initialized
INFO - 2017-02-10 07:59:05 --> Config Class Initialized
INFO - 2017-02-10 07:59:05 --> Hooks Class Initialized
INFO - 2017-02-10 07:59:05 --> Router Class Initialized
DEBUG - 2017-02-10 07:59:05 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:59:05 --> Utf8 Class Initialized
INFO - 2017-02-10 07:59:05 --> Output Class Initialized
INFO - 2017-02-10 07:59:05 --> URI Class Initialized
INFO - 2017-02-10 07:59:05 --> Security Class Initialized
DEBUG - 2017-02-10 07:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:59:05 --> Input Class Initialized
INFO - 2017-02-10 07:59:05 --> Router Class Initialized
INFO - 2017-02-10 07:59:05 --> Language Class Initialized
INFO - 2017-02-10 07:59:05 --> Output Class Initialized
INFO - 2017-02-10 07:59:05 --> Security Class Initialized
DEBUG - 2017-02-10 07:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:59:05 --> Input Class Initialized
INFO - 2017-02-10 07:59:05 --> Language Class Initialized
ERROR - 2017-02-10 07:59:05 --> 404 Page Not Found: /index
ERROR - 2017-02-10 07:59:05 --> 404 Page Not Found: /index
INFO - 2017-02-10 07:59:05 --> Config Class Initialized
INFO - 2017-02-10 07:59:05 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:59:05 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:59:05 --> Utf8 Class Initialized
INFO - 2017-02-10 07:59:05 --> URI Class Initialized
INFO - 2017-02-10 07:59:05 --> Router Class Initialized
INFO - 2017-02-10 07:59:05 --> Output Class Initialized
INFO - 2017-02-10 07:59:05 --> Security Class Initialized
DEBUG - 2017-02-10 07:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:59:05 --> Input Class Initialized
INFO - 2017-02-10 07:59:05 --> Language Class Initialized
ERROR - 2017-02-10 07:59:05 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:01:39 --> Config Class Initialized
INFO - 2017-02-10 08:01:39 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:01:39 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:01:39 --> Utf8 Class Initialized
INFO - 2017-02-10 08:01:39 --> URI Class Initialized
INFO - 2017-02-10 08:01:39 --> Router Class Initialized
INFO - 2017-02-10 08:01:39 --> Output Class Initialized
INFO - 2017-02-10 08:01:39 --> Security Class Initialized
DEBUG - 2017-02-10 08:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:01:39 --> Input Class Initialized
INFO - 2017-02-10 08:01:39 --> Language Class Initialized
INFO - 2017-02-10 08:01:39 --> Language Class Initialized
INFO - 2017-02-10 08:01:39 --> Config Class Initialized
INFO - 2017-02-10 08:01:39 --> Loader Class Initialized
INFO - 2017-02-10 08:01:39 --> Helper loaded: form_helper
INFO - 2017-02-10 08:01:39 --> Helper loaded: url_helper
INFO - 2017-02-10 08:01:39 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:01:39 --> Database Driver Class Initialized
INFO - 2017-02-10 08:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:01:39 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:01:39 --> Template Class Initialized
INFO - 2017-02-10 08:01:39 --> Controller Class Initialized
INFO - 2017-02-10 08:01:39 --> Model Class Initialized
INFO - 2017-02-10 08:01:39 --> Model Class Initialized
INFO - 2017-02-10 08:01:39 --> Model Class Initialized
DEBUG - 2017-02-10 08:01:39 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 08:01:39 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 08:01:39 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-10 08:01:39 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 232
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Loader Class Initialized
INFO - 2017-02-10 08:02:34 --> Helper loaded: form_helper
INFO - 2017-02-10 08:02:34 --> Helper loaded: url_helper
INFO - 2017-02-10 08:02:34 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:02:34 --> Database Driver Class Initialized
INFO - 2017-02-10 08:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:02:34 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Template Class Initialized
INFO - 2017-02-10 08:02:34 --> Controller Class Initialized
INFO - 2017-02-10 08:02:34 --> Model Class Initialized
INFO - 2017-02-10 08:02:34 --> Model Class Initialized
INFO - 2017-02-10 08:02:34 --> Model Class Initialized
DEBUG - 2017-02-10 08:02:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 08:02:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 08:02:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 08:02:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 08:02:34 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 08:02:34 --> Final output sent to browser
DEBUG - 2017-02-10 08:02:34 --> Total execution time: 0.0457
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:34 --> Config Class Initialized
INFO - 2017-02-10 08:02:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:34 --> URI Class Initialized
INFO - 2017-02-10 08:02:34 --> Router Class Initialized
INFO - 2017-02-10 08:02:34 --> Output Class Initialized
INFO - 2017-02-10 08:02:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:34 --> Input Class Initialized
INFO - 2017-02-10 08:02:34 --> Language Class Initialized
ERROR - 2017-02-10 08:02:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:02:50 --> Config Class Initialized
INFO - 2017-02-10 08:02:50 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:02:50 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:02:50 --> Utf8 Class Initialized
INFO - 2017-02-10 08:02:50 --> URI Class Initialized
INFO - 2017-02-10 08:02:50 --> Router Class Initialized
INFO - 2017-02-10 08:02:50 --> Output Class Initialized
INFO - 2017-02-10 08:02:50 --> Security Class Initialized
DEBUG - 2017-02-10 08:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:02:50 --> Input Class Initialized
INFO - 2017-02-10 08:02:50 --> Language Class Initialized
INFO - 2017-02-10 08:02:50 --> Language Class Initialized
INFO - 2017-02-10 08:02:50 --> Config Class Initialized
INFO - 2017-02-10 08:02:50 --> Loader Class Initialized
INFO - 2017-02-10 08:02:50 --> Helper loaded: form_helper
INFO - 2017-02-10 08:02:50 --> Helper loaded: url_helper
INFO - 2017-02-10 08:02:50 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:02:50 --> Database Driver Class Initialized
INFO - 2017-02-10 08:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:02:50 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:02:50 --> Template Class Initialized
INFO - 2017-02-10 08:02:50 --> Controller Class Initialized
INFO - 2017-02-10 08:02:50 --> Model Class Initialized
INFO - 2017-02-10 08:02:50 --> Model Class Initialized
INFO - 2017-02-10 08:02:50 --> Model Class Initialized
DEBUG - 2017-02-10 08:02:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 08:02:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 08:02:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-10 08:02:50 --> Severity: Notice --> Undefined index: user_id C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 87
ERROR - 2017-02-10 08:02:50 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 94
ERROR - 2017-02-10 08:02:50 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 96
ERROR - 2017-02-10 08:02:50 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 98
ERROR - 2017-02-10 08:02:50 --> Severity: Notice --> Undefined index: user_email C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 103
DEBUG - 2017-02-10 08:02:50 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 08:02:50 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 08:02:50 --> Final output sent to browser
DEBUG - 2017-02-10 08:02:50 --> Total execution time: 0.0469
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Loader Class Initialized
INFO - 2017-02-10 08:03:22 --> Helper loaded: form_helper
INFO - 2017-02-10 08:03:22 --> Helper loaded: url_helper
INFO - 2017-02-10 08:03:22 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:03:22 --> Database Driver Class Initialized
INFO - 2017-02-10 08:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:03:22 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Template Class Initialized
INFO - 2017-02-10 08:03:22 --> Controller Class Initialized
INFO - 2017-02-10 08:03:22 --> Model Class Initialized
INFO - 2017-02-10 08:03:22 --> Model Class Initialized
INFO - 2017-02-10 08:03:22 --> Model Class Initialized
DEBUG - 2017-02-10 08:03:22 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 08:03:22 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 08:03:22 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-10 08:03:22 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 94
ERROR - 2017-02-10 08:03:22 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 96
ERROR - 2017-02-10 08:03:22 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 98
ERROR - 2017-02-10 08:03:22 --> Severity: Notice --> Undefined index: user_email C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 103
DEBUG - 2017-02-10 08:03:22 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 08:03:22 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 08:03:22 --> Final output sent to browser
DEBUG - 2017-02-10 08:03:22 --> Total execution time: 0.1060
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:03:22 --> Config Class Initialized
INFO - 2017-02-10 08:03:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:03:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:03:22 --> Utf8 Class Initialized
INFO - 2017-02-10 08:03:22 --> URI Class Initialized
INFO - 2017-02-10 08:03:22 --> Router Class Initialized
INFO - 2017-02-10 08:03:22 --> Output Class Initialized
INFO - 2017-02-10 08:03:22 --> Security Class Initialized
DEBUG - 2017-02-10 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:03:22 --> Input Class Initialized
INFO - 2017-02-10 08:03:22 --> Language Class Initialized
ERROR - 2017-02-10 08:03:22 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:08 --> Config Class Initialized
INFO - 2017-02-10 08:05:08 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:05:08 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:08 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:08 --> URI Class Initialized
INFO - 2017-02-10 08:05:08 --> Router Class Initialized
INFO - 2017-02-10 08:05:08 --> Output Class Initialized
INFO - 2017-02-10 08:05:08 --> Security Class Initialized
DEBUG - 2017-02-10 08:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:08 --> Input Class Initialized
INFO - 2017-02-10 08:05:08 --> Language Class Initialized
INFO - 2017-02-10 08:05:08 --> Language Class Initialized
INFO - 2017-02-10 08:05:08 --> Config Class Initialized
INFO - 2017-02-10 08:05:08 --> Loader Class Initialized
INFO - 2017-02-10 08:05:08 --> Helper loaded: form_helper
INFO - 2017-02-10 08:05:08 --> Helper loaded: url_helper
INFO - 2017-02-10 08:05:08 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:05:08 --> Database Driver Class Initialized
INFO - 2017-02-10 08:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:05:08 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:05:08 --> Template Class Initialized
INFO - 2017-02-10 08:05:08 --> Controller Class Initialized
INFO - 2017-02-10 08:05:08 --> Model Class Initialized
INFO - 2017-02-10 08:05:08 --> Model Class Initialized
INFO - 2017-02-10 08:05:09 --> Model Class Initialized
DEBUG - 2017-02-10 08:05:09 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 08:05:09 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 08:05:09 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-10 08:05:09 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 94
ERROR - 2017-02-10 08:05:09 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 96
ERROR - 2017-02-10 08:05:09 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 98
ERROR - 2017-02-10 08:05:09 --> Severity: Notice --> Undefined index: user_email C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 103
DEBUG - 2017-02-10 08:05:09 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 08:05:09 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 08:05:09 --> Final output sent to browser
DEBUG - 2017-02-10 08:05:09 --> Total execution time: 0.0660
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:05:09 --> Config Class Initialized
INFO - 2017-02-10 08:05:09 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:05:09 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:05:09 --> Utf8 Class Initialized
INFO - 2017-02-10 08:05:09 --> URI Class Initialized
INFO - 2017-02-10 08:05:09 --> Router Class Initialized
INFO - 2017-02-10 08:05:09 --> Output Class Initialized
INFO - 2017-02-10 08:05:09 --> Security Class Initialized
DEBUG - 2017-02-10 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:05:09 --> Input Class Initialized
INFO - 2017-02-10 08:05:09 --> Language Class Initialized
ERROR - 2017-02-10 08:05:09 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Loader Class Initialized
INFO - 2017-02-10 08:06:12 --> Helper loaded: form_helper
INFO - 2017-02-10 08:06:12 --> Helper loaded: url_helper
INFO - 2017-02-10 08:06:12 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:06:12 --> Database Driver Class Initialized
INFO - 2017-02-10 08:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:06:12 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Template Class Initialized
INFO - 2017-02-10 08:06:12 --> Controller Class Initialized
INFO - 2017-02-10 08:06:12 --> Model Class Initialized
INFO - 2017-02-10 08:06:12 --> Model Class Initialized
INFO - 2017-02-10 08:06:12 --> Model Class Initialized
DEBUG - 2017-02-10 08:06:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 08:06:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 08:06:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-10 08:06:12 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 94
ERROR - 2017-02-10 08:06:12 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 96
ERROR - 2017-02-10 08:06:12 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 98
ERROR - 2017-02-10 08:06:12 --> Severity: Notice --> Undefined index: user_email C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 103
DEBUG - 2017-02-10 08:06:12 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 08:06:12 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 08:06:12 --> Final output sent to browser
DEBUG - 2017-02-10 08:06:12 --> Total execution time: 0.0741
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:12 --> Config Class Initialized
INFO - 2017-02-10 08:06:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:12 --> URI Class Initialized
INFO - 2017-02-10 08:06:12 --> Router Class Initialized
INFO - 2017-02-10 08:06:12 --> Output Class Initialized
INFO - 2017-02-10 08:06:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:12 --> Input Class Initialized
INFO - 2017-02-10 08:06:12 --> Language Class Initialized
ERROR - 2017-02-10 08:06:12 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:13 --> Config Class Initialized
INFO - 2017-02-10 08:06:13 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:13 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:13 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:13 --> URI Class Initialized
INFO - 2017-02-10 08:06:13 --> Router Class Initialized
INFO - 2017-02-10 08:06:13 --> Output Class Initialized
INFO - 2017-02-10 08:06:13 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:13 --> Input Class Initialized
INFO - 2017-02-10 08:06:13 --> Language Class Initialized
INFO - 2017-02-10 08:06:13 --> Language Class Initialized
INFO - 2017-02-10 08:06:13 --> Config Class Initialized
INFO - 2017-02-10 08:06:13 --> Loader Class Initialized
INFO - 2017-02-10 08:06:13 --> Helper loaded: form_helper
INFO - 2017-02-10 08:06:13 --> Helper loaded: url_helper
INFO - 2017-02-10 08:06:13 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:06:13 --> Database Driver Class Initialized
INFO - 2017-02-10 08:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:06:13 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:06:13 --> Template Class Initialized
INFO - 2017-02-10 08:06:13 --> Controller Class Initialized
INFO - 2017-02-10 08:06:13 --> Model Class Initialized
INFO - 2017-02-10 08:06:13 --> Model Class Initialized
INFO - 2017-02-10 08:06:13 --> Model Class Initialized
DEBUG - 2017-02-10 08:06:13 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 08:06:13 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 08:06:13 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-10 08:06:13 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 94
ERROR - 2017-02-10 08:06:13 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 96
ERROR - 2017-02-10 08:06:13 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 98
ERROR - 2017-02-10 08:06:13 --> Severity: Notice --> Undefined index: user_email C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 103
DEBUG - 2017-02-10 08:06:13 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 08:06:13 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 08:06:13 --> Final output sent to browser
DEBUG - 2017-02-10 08:06:13 --> Total execution time: 0.0769
INFO - 2017-02-10 08:06:13 --> Config Class Initialized
INFO - 2017-02-10 08:06:13 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:13 --> Config Class Initialized
DEBUG - 2017-02-10 08:06:13 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:13 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:13 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:13 --> Config Class Initialized
INFO - 2017-02-10 08:06:13 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:13 --> URI Class Initialized
DEBUG - 2017-02-10 08:06:13 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:13 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:13 --> Router Class Initialized
DEBUG - 2017-02-10 08:06:13 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:13 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:13 --> URI Class Initialized
INFO - 2017-02-10 08:06:13 --> Output Class Initialized
INFO - 2017-02-10 08:06:13 --> URI Class Initialized
INFO - 2017-02-10 08:06:13 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:13 --> Input Class Initialized
INFO - 2017-02-10 08:06:13 --> Router Class Initialized
INFO - 2017-02-10 08:06:13 --> Router Class Initialized
INFO - 2017-02-10 08:06:13 --> Language Class Initialized
INFO - 2017-02-10 08:06:13 --> Output Class Initialized
INFO - 2017-02-10 08:06:13 --> Output Class Initialized
ERROR - 2017-02-10 08:06:13 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:13 --> Security Class Initialized
INFO - 2017-02-10 08:06:13 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:13 --> Input Class Initialized
DEBUG - 2017-02-10 08:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:13 --> Config Class Initialized
INFO - 2017-02-10 08:06:13 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:13 --> Config Class Initialized
INFO - 2017-02-10 08:06:13 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:13 --> Language Class Initialized
INFO - 2017-02-10 08:06:13 --> Config Class Initialized
INFO - 2017-02-10 08:06:13 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:13 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 08:06:13 --> UTF-8 Support Enabled
ERROR - 2017-02-10 08:06:13 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:13 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:13 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:13 --> URI Class Initialized
DEBUG - 2017-02-10 08:06:13 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:13 --> URI Class Initialized
INFO - 2017-02-10 08:06:13 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:13 --> URI Class Initialized
INFO - 2017-02-10 08:06:13 --> Router Class Initialized
INFO - 2017-02-10 08:06:13 --> Router Class Initialized
INFO - 2017-02-10 08:06:13 --> Output Class Initialized
INFO - 2017-02-10 08:06:13 --> Router Class Initialized
INFO - 2017-02-10 08:06:13 --> Output Class Initialized
INFO - 2017-02-10 08:06:13 --> Security Class Initialized
INFO - 2017-02-10 08:06:13 --> Output Class Initialized
INFO - 2017-02-10 08:06:13 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:13 --> Input Class Initialized
INFO - 2017-02-10 08:06:13 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:13 --> Language Class Initialized
INFO - 2017-02-10 08:06:13 --> Input Class Initialized
INFO - 2017-02-10 08:06:13 --> Language Class Initialized
DEBUG - 2017-02-10 08:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:13 --> Input Class Initialized
ERROR - 2017-02-10 08:06:13 --> 404 Page Not Found: /index
ERROR - 2017-02-10 08:06:13 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:13 --> Language Class Initialized
ERROR - 2017-02-10 08:06:13 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:13 --> Config Class Initialized
INFO - 2017-02-10 08:06:13 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:13 --> Input Class Initialized
DEBUG - 2017-02-10 08:06:13 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:13 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:13 --> Config Class Initialized
INFO - 2017-02-10 08:06:13 --> Config Class Initialized
INFO - 2017-02-10 08:06:13 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:13 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:13 --> Language Class Initialized
INFO - 2017-02-10 08:06:13 --> URI Class Initialized
DEBUG - 2017-02-10 08:06:13 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:13 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:06:13 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:13 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:13 --> Router Class Initialized
INFO - 2017-02-10 08:06:13 --> URI Class Initialized
INFO - 2017-02-10 08:06:13 --> URI Class Initialized
INFO - 2017-02-10 08:06:13 --> Output Class Initialized
ERROR - 2017-02-10 08:06:13 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Config Class Initialized
INFO - 2017-02-10 08:06:14 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:14 --> Config Class Initialized
INFO - 2017-02-10 08:06:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:14 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:14 --> URI Class Initialized
INFO - 2017-02-10 08:06:14 --> Config Class Initialized
INFO - 2017-02-10 08:06:14 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:14 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:14 --> URI Class Initialized
INFO - 2017-02-10 08:06:14 --> Config Class Initialized
INFO - 2017-02-10 08:06:14 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
DEBUG - 2017-02-10 08:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:14 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
INFO - 2017-02-10 08:06:14 --> URI Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
DEBUG - 2017-02-10 08:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:14 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
INFO - 2017-02-10 08:06:14 --> URI Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
INFO - 2017-02-10 08:06:14 --> Config Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:14 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:14 --> URI Class Initialized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Config Class Initialized
INFO - 2017-02-10 08:06:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:14 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:14 --> URI Class Initialized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Config Class Initialized
INFO - 2017-02-10 08:06:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:14 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:14 --> URI Class Initialized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Config Class Initialized
INFO - 2017-02-10 08:06:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:14 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:14 --> URI Class Initialized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Config Class Initialized
INFO - 2017-02-10 08:06:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:14 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:14 --> URI Class Initialized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Config Class Initialized
INFO - 2017-02-10 08:06:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:14 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:14 --> URI Class Initialized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Config Class Initialized
INFO - 2017-02-10 08:06:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:14 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:14 --> URI Class Initialized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Config Class Initialized
INFO - 2017-02-10 08:06:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:14 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:14 --> URI Class Initialized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Config Class Initialized
INFO - 2017-02-10 08:06:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:14 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:14 --> URI Class Initialized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Config Class Initialized
INFO - 2017-02-10 08:06:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:14 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:14 --> URI Class Initialized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Config Class Initialized
INFO - 2017-02-10 08:06:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:14 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:14 --> URI Class Initialized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Config Class Initialized
INFO - 2017-02-10 08:06:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:14 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:14 --> URI Class Initialized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Config Class Initialized
INFO - 2017-02-10 08:06:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:14 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:14 --> URI Class Initialized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:14 --> Config Class Initialized
INFO - 2017-02-10 08:06:14 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:14 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:14 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:14 --> URI Class Initialized
INFO - 2017-02-10 08:06:14 --> Router Class Initialized
INFO - 2017-02-10 08:06:14 --> Output Class Initialized
INFO - 2017-02-10 08:06:14 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:14 --> Input Class Initialized
INFO - 2017-02-10 08:06:14 --> Language Class Initialized
ERROR - 2017-02-10 08:06:14 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Loader Class Initialized
INFO - 2017-02-10 08:06:34 --> Helper loaded: form_helper
INFO - 2017-02-10 08:06:34 --> Helper loaded: url_helper
INFO - 2017-02-10 08:06:34 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:06:34 --> Database Driver Class Initialized
INFO - 2017-02-10 08:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:06:34 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Template Class Initialized
INFO - 2017-02-10 08:06:34 --> Controller Class Initialized
INFO - 2017-02-10 08:06:34 --> Model Class Initialized
INFO - 2017-02-10 08:06:34 --> Model Class Initialized
INFO - 2017-02-10 08:06:34 --> Model Class Initialized
DEBUG - 2017-02-10 08:06:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 08:06:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 08:06:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
ERROR - 2017-02-10 08:06:34 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 94
ERROR - 2017-02-10 08:06:34 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 96
ERROR - 2017-02-10 08:06:34 --> Severity: Notice --> Undefined index: user_status C:\xampp\htdocs\mobile\application\modules\backend\views\newsletter\newsletter_send.php 98
DEBUG - 2017-02-10 08:06:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 08:06:34 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 08:06:34 --> Final output sent to browser
DEBUG - 2017-02-10 08:06:34 --> Total execution time: 0.0626
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:34 --> Config Class Initialized
INFO - 2017-02-10 08:06:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:34 --> URI Class Initialized
INFO - 2017-02-10 08:06:34 --> Router Class Initialized
INFO - 2017-02-10 08:06:34 --> Output Class Initialized
INFO - 2017-02-10 08:06:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:34 --> Input Class Initialized
INFO - 2017-02-10 08:06:34 --> Language Class Initialized
ERROR - 2017-02-10 08:06:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:59 --> Config Class Initialized
INFO - 2017-02-10 08:06:59 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:59 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:59 --> URI Class Initialized
INFO - 2017-02-10 08:06:59 --> Router Class Initialized
INFO - 2017-02-10 08:06:59 --> Output Class Initialized
INFO - 2017-02-10 08:06:59 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:59 --> Input Class Initialized
INFO - 2017-02-10 08:06:59 --> Language Class Initialized
INFO - 2017-02-10 08:06:59 --> Language Class Initialized
INFO - 2017-02-10 08:06:59 --> Config Class Initialized
INFO - 2017-02-10 08:06:59 --> Loader Class Initialized
INFO - 2017-02-10 08:06:59 --> Helper loaded: form_helper
INFO - 2017-02-10 08:06:59 --> Helper loaded: url_helper
INFO - 2017-02-10 08:06:59 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:06:59 --> Database Driver Class Initialized
INFO - 2017-02-10 08:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:06:59 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:06:59 --> Template Class Initialized
INFO - 2017-02-10 08:06:59 --> Controller Class Initialized
INFO - 2017-02-10 08:06:59 --> Model Class Initialized
INFO - 2017-02-10 08:06:59 --> Model Class Initialized
INFO - 2017-02-10 08:06:59 --> Model Class Initialized
DEBUG - 2017-02-10 08:06:59 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 08:06:59 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 08:06:59 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 08:06:59 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 08:06:59 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 08:06:59 --> Final output sent to browser
DEBUG - 2017-02-10 08:06:59 --> Total execution time: 0.0664
INFO - 2017-02-10 08:06:59 --> Config Class Initialized
INFO - 2017-02-10 08:06:59 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:59 --> Config Class Initialized
INFO - 2017-02-10 08:06:59 --> Config Class Initialized
INFO - 2017-02-10 08:06:59 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:59 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:06:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:59 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:59 --> URI Class Initialized
INFO - 2017-02-10 08:06:59 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:59 --> URI Class Initialized
INFO - 2017-02-10 08:06:59 --> Router Class Initialized
DEBUG - 2017-02-10 08:06:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:59 --> Router Class Initialized
INFO - 2017-02-10 08:06:59 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:59 --> Output Class Initialized
INFO - 2017-02-10 08:06:59 --> Security Class Initialized
INFO - 2017-02-10 08:06:59 --> Output Class Initialized
INFO - 2017-02-10 08:06:59 --> URI Class Initialized
DEBUG - 2017-02-10 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:59 --> Input Class Initialized
INFO - 2017-02-10 08:06:59 --> Security Class Initialized
INFO - 2017-02-10 08:06:59 --> Language Class Initialized
DEBUG - 2017-02-10 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:59 --> Router Class Initialized
ERROR - 2017-02-10 08:06:59 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:59 --> Input Class Initialized
INFO - 2017-02-10 08:06:59 --> Output Class Initialized
INFO - 2017-02-10 08:06:59 --> Config Class Initialized
INFO - 2017-02-10 08:06:59 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:59 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:59 --> Input Class Initialized
DEBUG - 2017-02-10 08:06:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:59 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:59 --> Language Class Initialized
INFO - 2017-02-10 08:06:59 --> URI Class Initialized
ERROR - 2017-02-10 08:06:59 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:59 --> Config Class Initialized
INFO - 2017-02-10 08:06:59 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:59 --> Router Class Initialized
INFO - 2017-02-10 08:06:59 --> Output Class Initialized
DEBUG - 2017-02-10 08:06:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:59 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:59 --> Security Class Initialized
INFO - 2017-02-10 08:06:59 --> URI Class Initialized
DEBUG - 2017-02-10 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:59 --> Input Class Initialized
INFO - 2017-02-10 08:06:59 --> Language Class Initialized
INFO - 2017-02-10 08:06:59 --> Config Class Initialized
INFO - 2017-02-10 08:06:59 --> Hooks Class Initialized
ERROR - 2017-02-10 08:06:59 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:59 --> Router Class Initialized
INFO - 2017-02-10 08:06:59 --> Output Class Initialized
DEBUG - 2017-02-10 08:06:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:59 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:59 --> Security Class Initialized
INFO - 2017-02-10 08:06:59 --> URI Class Initialized
DEBUG - 2017-02-10 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:59 --> Input Class Initialized
INFO - 2017-02-10 08:06:59 --> Language Class Initialized
ERROR - 2017-02-10 08:06:59 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:59 --> Router Class Initialized
INFO - 2017-02-10 08:06:59 --> Config Class Initialized
INFO - 2017-02-10 08:06:59 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:59 --> Output Class Initialized
INFO - 2017-02-10 08:06:59 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:59 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:59 --> Input Class Initialized
INFO - 2017-02-10 08:06:59 --> URI Class Initialized
INFO - 2017-02-10 08:06:59 --> Language Class Initialized
ERROR - 2017-02-10 08:06:59 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:59 --> Config Class Initialized
INFO - 2017-02-10 08:06:59 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:59 --> Router Class Initialized
INFO - 2017-02-10 08:06:59 --> Config Class Initialized
INFO - 2017-02-10 08:06:59 --> Output Class Initialized
INFO - 2017-02-10 08:06:59 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:59 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:59 --> URI Class Initialized
INFO - 2017-02-10 08:06:59 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:59 --> Input Class Initialized
INFO - 2017-02-10 08:06:59 --> Router Class Initialized
DEBUG - 2017-02-10 08:06:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:59 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:59 --> Config Class Initialized
INFO - 2017-02-10 08:06:59 --> Output Class Initialized
INFO - 2017-02-10 08:06:59 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:59 --> Language Class Initialized
INFO - 2017-02-10 08:06:59 --> URI Class Initialized
INFO - 2017-02-10 08:06:59 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:59 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:59 --> Utf8 Class Initialized
ERROR - 2017-02-10 08:06:59 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:59 --> Input Class Initialized
INFO - 2017-02-10 08:06:59 --> Language Class Initialized
INFO - 2017-02-10 08:06:59 --> URI Class Initialized
ERROR - 2017-02-10 08:06:59 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:59 --> Router Class Initialized
INFO - 2017-02-10 08:06:59 --> Router Class Initialized
INFO - 2017-02-10 08:06:59 --> Output Class Initialized
INFO - 2017-02-10 08:06:59 --> Output Class Initialized
INFO - 2017-02-10 08:06:59 --> Security Class Initialized
INFO - 2017-02-10 08:06:59 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-10 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:59 --> Input Class Initialized
INFO - 2017-02-10 08:06:59 --> Input Class Initialized
INFO - 2017-02-10 08:06:59 --> Config Class Initialized
INFO - 2017-02-10 08:06:59 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:59 --> Config Class Initialized
INFO - 2017-02-10 08:06:59 --> Language Class Initialized
INFO - 2017-02-10 08:06:59 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:59 --> Language Class Initialized
DEBUG - 2017-02-10 08:06:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:59 --> Utf8 Class Initialized
ERROR - 2017-02-10 08:06:59 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:06:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:59 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:59 --> Language Class Initialized
ERROR - 2017-02-10 08:06:59 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:59 --> Config Class Initialized
INFO - 2017-02-10 08:06:59 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:59 --> Config Class Initialized
INFO - 2017-02-10 08:06:59 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:06:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:59 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:06:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:59 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:59 --> URI Class Initialized
INFO - 2017-02-10 08:06:59 --> URI Class Initialized
INFO - 2017-02-10 08:06:59 --> Router Class Initialized
INFO - 2017-02-10 08:06:59 --> Config Class Initialized
INFO - 2017-02-10 08:06:59 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:59 --> Output Class Initialized
DEBUG - 2017-02-10 08:06:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:59 --> Security Class Initialized
INFO - 2017-02-10 08:06:59 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:59 --> URI Class Initialized
INFO - 2017-02-10 08:06:59 --> Router Class Initialized
DEBUG - 2017-02-10 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:59 --> Input Class Initialized
INFO - 2017-02-10 08:06:59 --> Language Class Initialized
INFO - 2017-02-10 08:06:59 --> Output Class Initialized
ERROR - 2017-02-10 08:06:59 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:59 --> Router Class Initialized
INFO - 2017-02-10 08:06:59 --> Security Class Initialized
INFO - 2017-02-10 08:06:59 --> Output Class Initialized
DEBUG - 2017-02-10 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:59 --> Input Class Initialized
INFO - 2017-02-10 08:06:59 --> Language Class Initialized
INFO - 2017-02-10 08:06:59 --> Security Class Initialized
ERROR - 2017-02-10 08:06:59 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:59 --> Input Class Initialized
INFO - 2017-02-10 08:06:59 --> Language Class Initialized
ERROR - 2017-02-10 08:06:59 --> 404 Page Not Found: /index
ERROR - 2017-02-10 08:06:59 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:59 --> Config Class Initialized
INFO - 2017-02-10 08:06:59 --> Hooks Class Initialized
INFO - 2017-02-10 08:06:59 --> URI Class Initialized
DEBUG - 2017-02-10 08:06:59 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:06:59 --> URI Class Initialized
INFO - 2017-02-10 08:06:59 --> Utf8 Class Initialized
INFO - 2017-02-10 08:06:59 --> URI Class Initialized
INFO - 2017-02-10 08:06:59 --> Router Class Initialized
INFO - 2017-02-10 08:06:59 --> Router Class Initialized
INFO - 2017-02-10 08:06:59 --> Output Class Initialized
INFO - 2017-02-10 08:06:59 --> Output Class Initialized
INFO - 2017-02-10 08:06:59 --> Security Class Initialized
INFO - 2017-02-10 08:06:59 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:59 --> Router Class Initialized
DEBUG - 2017-02-10 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:59 --> Input Class Initialized
INFO - 2017-02-10 08:06:59 --> Input Class Initialized
INFO - 2017-02-10 08:06:59 --> Language Class Initialized
INFO - 2017-02-10 08:06:59 --> Language Class Initialized
INFO - 2017-02-10 08:06:59 --> Output Class Initialized
ERROR - 2017-02-10 08:06:59 --> 404 Page Not Found: /index
ERROR - 2017-02-10 08:06:59 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:06:59 --> Security Class Initialized
DEBUG - 2017-02-10 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:06:59 --> Input Class Initialized
INFO - 2017-02-10 08:06:59 --> Language Class Initialized
ERROR - 2017-02-10 08:06:59 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:00 --> Config Class Initialized
INFO - 2017-02-10 08:07:00 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:00 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:00 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:00 --> URI Class Initialized
INFO - 2017-02-10 08:07:00 --> Router Class Initialized
INFO - 2017-02-10 08:07:00 --> Output Class Initialized
INFO - 2017-02-10 08:07:00 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:00 --> Input Class Initialized
INFO - 2017-02-10 08:07:00 --> Language Class Initialized
ERROR - 2017-02-10 08:07:00 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:00 --> Config Class Initialized
INFO - 2017-02-10 08:07:00 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:00 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:00 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:00 --> URI Class Initialized
INFO - 2017-02-10 08:07:00 --> Router Class Initialized
INFO - 2017-02-10 08:07:00 --> Output Class Initialized
INFO - 2017-02-10 08:07:00 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:00 --> Input Class Initialized
INFO - 2017-02-10 08:07:00 --> Language Class Initialized
ERROR - 2017-02-10 08:07:00 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:00 --> Config Class Initialized
INFO - 2017-02-10 08:07:00 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:00 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:00 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:00 --> URI Class Initialized
INFO - 2017-02-10 08:07:00 --> Router Class Initialized
INFO - 2017-02-10 08:07:00 --> Output Class Initialized
INFO - 2017-02-10 08:07:00 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:00 --> Input Class Initialized
INFO - 2017-02-10 08:07:00 --> Language Class Initialized
ERROR - 2017-02-10 08:07:00 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:00 --> Config Class Initialized
INFO - 2017-02-10 08:07:00 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:00 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:00 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:00 --> URI Class Initialized
INFO - 2017-02-10 08:07:00 --> Router Class Initialized
INFO - 2017-02-10 08:07:00 --> Output Class Initialized
INFO - 2017-02-10 08:07:00 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:00 --> Input Class Initialized
INFO - 2017-02-10 08:07:00 --> Language Class Initialized
ERROR - 2017-02-10 08:07:00 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:00 --> Config Class Initialized
INFO - 2017-02-10 08:07:00 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:00 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:00 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:00 --> URI Class Initialized
INFO - 2017-02-10 08:07:00 --> Router Class Initialized
INFO - 2017-02-10 08:07:00 --> Output Class Initialized
INFO - 2017-02-10 08:07:00 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:00 --> Input Class Initialized
INFO - 2017-02-10 08:07:00 --> Language Class Initialized
ERROR - 2017-02-10 08:07:00 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:00 --> Config Class Initialized
INFO - 2017-02-10 08:07:00 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:00 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:00 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:00 --> URI Class Initialized
INFO - 2017-02-10 08:07:00 --> Router Class Initialized
INFO - 2017-02-10 08:07:00 --> Output Class Initialized
INFO - 2017-02-10 08:07:00 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:00 --> Input Class Initialized
INFO - 2017-02-10 08:07:00 --> Language Class Initialized
ERROR - 2017-02-10 08:07:00 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:00 --> Config Class Initialized
INFO - 2017-02-10 08:07:00 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:00 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:00 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:00 --> URI Class Initialized
INFO - 2017-02-10 08:07:00 --> Router Class Initialized
INFO - 2017-02-10 08:07:00 --> Output Class Initialized
INFO - 2017-02-10 08:07:00 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:00 --> Input Class Initialized
INFO - 2017-02-10 08:07:00 --> Language Class Initialized
ERROR - 2017-02-10 08:07:00 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:00 --> Config Class Initialized
INFO - 2017-02-10 08:07:00 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:00 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:00 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:00 --> URI Class Initialized
INFO - 2017-02-10 08:07:00 --> Router Class Initialized
INFO - 2017-02-10 08:07:00 --> Output Class Initialized
INFO - 2017-02-10 08:07:00 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:00 --> Input Class Initialized
INFO - 2017-02-10 08:07:00 --> Language Class Initialized
ERROR - 2017-02-10 08:07:00 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:00 --> Config Class Initialized
INFO - 2017-02-10 08:07:00 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:00 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:00 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:00 --> URI Class Initialized
INFO - 2017-02-10 08:07:00 --> Router Class Initialized
INFO - 2017-02-10 08:07:00 --> Output Class Initialized
INFO - 2017-02-10 08:07:00 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:00 --> Input Class Initialized
INFO - 2017-02-10 08:07:00 --> Language Class Initialized
ERROR - 2017-02-10 08:07:00 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:00 --> Config Class Initialized
INFO - 2017-02-10 08:07:00 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:00 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:00 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:00 --> URI Class Initialized
INFO - 2017-02-10 08:07:00 --> Router Class Initialized
INFO - 2017-02-10 08:07:00 --> Output Class Initialized
INFO - 2017-02-10 08:07:00 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:00 --> Input Class Initialized
INFO - 2017-02-10 08:07:00 --> Language Class Initialized
ERROR - 2017-02-10 08:07:00 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:00 --> Config Class Initialized
INFO - 2017-02-10 08:07:00 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:00 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:00 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:00 --> URI Class Initialized
INFO - 2017-02-10 08:07:00 --> Router Class Initialized
INFO - 2017-02-10 08:07:00 --> Output Class Initialized
INFO - 2017-02-10 08:07:00 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:00 --> Input Class Initialized
INFO - 2017-02-10 08:07:00 --> Language Class Initialized
ERROR - 2017-02-10 08:07:00 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:12 --> Config Class Initialized
INFO - 2017-02-10 08:07:12 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:12 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:12 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:12 --> URI Class Initialized
INFO - 2017-02-10 08:07:12 --> Router Class Initialized
INFO - 2017-02-10 08:07:12 --> Output Class Initialized
INFO - 2017-02-10 08:07:12 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:12 --> Input Class Initialized
INFO - 2017-02-10 08:07:12 --> Language Class Initialized
INFO - 2017-02-10 08:07:12 --> Language Class Initialized
INFO - 2017-02-10 08:07:12 --> Config Class Initialized
INFO - 2017-02-10 08:07:12 --> Loader Class Initialized
INFO - 2017-02-10 08:07:12 --> Helper loaded: form_helper
INFO - 2017-02-10 08:07:12 --> Helper loaded: url_helper
INFO - 2017-02-10 08:07:12 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:07:12 --> Database Driver Class Initialized
INFO - 2017-02-10 08:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:07:12 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:07:12 --> Template Class Initialized
INFO - 2017-02-10 08:07:12 --> Controller Class Initialized
INFO - 2017-02-10 08:07:12 --> Model Class Initialized
INFO - 2017-02-10 08:07:12 --> Model Class Initialized
INFO - 2017-02-10 08:07:12 --> Model Class Initialized
ERROR - 2017-02-10 08:07:12 --> Query error: Table 'mobile.mst_users' doesn't exist - Invalid query: SELECT user_email, user_id
FROM `mst_users`
WHERE `user_id` = '39'
INFO - 2017-02-10 08:07:12 --> Language file loaded: language/english/db_lang.php
INFO - 2017-02-10 08:07:19 --> Config Class Initialized
INFO - 2017-02-10 08:07:19 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:19 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:19 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:19 --> URI Class Initialized
INFO - 2017-02-10 08:07:19 --> Router Class Initialized
INFO - 2017-02-10 08:07:19 --> Output Class Initialized
INFO - 2017-02-10 08:07:19 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:19 --> Input Class Initialized
INFO - 2017-02-10 08:07:19 --> Language Class Initialized
INFO - 2017-02-10 08:07:19 --> Language Class Initialized
INFO - 2017-02-10 08:07:19 --> Config Class Initialized
INFO - 2017-02-10 08:07:19 --> Loader Class Initialized
INFO - 2017-02-10 08:07:19 --> Helper loaded: form_helper
INFO - 2017-02-10 08:07:19 --> Helper loaded: url_helper
INFO - 2017-02-10 08:07:19 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:07:19 --> Database Driver Class Initialized
INFO - 2017-02-10 08:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:07:19 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:07:19 --> Template Class Initialized
INFO - 2017-02-10 08:07:19 --> Controller Class Initialized
INFO - 2017-02-10 08:07:19 --> Model Class Initialized
INFO - 2017-02-10 08:07:19 --> Model Class Initialized
INFO - 2017-02-10 08:07:19 --> Model Class Initialized
DEBUG - 2017-02-10 08:07:19 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 08:07:19 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 08:07:19 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 08:07:19 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 08:07:19 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 08:07:19 --> Final output sent to browser
DEBUG - 2017-02-10 08:07:19 --> Total execution time: 0.0456
INFO - 2017-02-10 08:07:20 --> Config Class Initialized
INFO - 2017-02-10 08:07:20 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:20 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:20 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:20 --> URI Class Initialized
INFO - 2017-02-10 08:07:20 --> Router Class Initialized
INFO - 2017-02-10 08:07:20 --> Output Class Initialized
INFO - 2017-02-10 08:07:20 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:20 --> Input Class Initialized
INFO - 2017-02-10 08:07:20 --> Language Class Initialized
INFO - 2017-02-10 08:07:20 --> Language Class Initialized
INFO - 2017-02-10 08:07:20 --> Config Class Initialized
INFO - 2017-02-10 08:07:20 --> Loader Class Initialized
INFO - 2017-02-10 08:07:20 --> Helper loaded: form_helper
INFO - 2017-02-10 08:07:20 --> Helper loaded: url_helper
INFO - 2017-02-10 08:07:20 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:07:20 --> Database Driver Class Initialized
INFO - 2017-02-10 08:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:07:20 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:07:20 --> Template Class Initialized
INFO - 2017-02-10 08:07:20 --> Controller Class Initialized
INFO - 2017-02-10 08:07:20 --> Model Class Initialized
INFO - 2017-02-10 08:07:20 --> Model Class Initialized
INFO - 2017-02-10 08:07:20 --> Model Class Initialized
DEBUG - 2017-02-10 08:07:20 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 08:07:20 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 08:07:20 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 08:07:20 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 08:07:20 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 08:07:20 --> Final output sent to browser
DEBUG - 2017-02-10 08:07:20 --> Total execution time: 0.0694
INFO - 2017-02-10 08:07:24 --> Config Class Initialized
INFO - 2017-02-10 08:07:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:24 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:24 --> URI Class Initialized
INFO - 2017-02-10 08:07:24 --> Router Class Initialized
INFO - 2017-02-10 08:07:24 --> Output Class Initialized
INFO - 2017-02-10 08:07:24 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:24 --> Input Class Initialized
INFO - 2017-02-10 08:07:24 --> Language Class Initialized
INFO - 2017-02-10 08:07:24 --> Language Class Initialized
INFO - 2017-02-10 08:07:24 --> Config Class Initialized
INFO - 2017-02-10 08:07:24 --> Loader Class Initialized
INFO - 2017-02-10 08:07:24 --> Helper loaded: form_helper
INFO - 2017-02-10 08:07:24 --> Helper loaded: url_helper
INFO - 2017-02-10 08:07:24 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:07:24 --> Database Driver Class Initialized
INFO - 2017-02-10 08:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:07:24 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:07:24 --> Template Class Initialized
INFO - 2017-02-10 08:07:24 --> Controller Class Initialized
INFO - 2017-02-10 08:07:24 --> Model Class Initialized
INFO - 2017-02-10 08:07:24 --> Model Class Initialized
INFO - 2017-02-10 08:07:24 --> Model Class Initialized
DEBUG - 2017-02-10 08:07:24 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 08:07:24 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 08:07:24 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 08:07:24 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_edit.php
DEBUG - 2017-02-10 08:07:24 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 08:07:24 --> Final output sent to browser
DEBUG - 2017-02-10 08:07:24 --> Total execution time: 0.0961
INFO - 2017-02-10 08:07:24 --> Config Class Initialized
INFO - 2017-02-10 08:07:24 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:24 --> Config Class Initialized
INFO - 2017-02-10 08:07:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:24 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:07:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:24 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:24 --> URI Class Initialized
INFO - 2017-02-10 08:07:24 --> URI Class Initialized
INFO - 2017-02-10 08:07:24 --> Router Class Initialized
INFO - 2017-02-10 08:07:24 --> Router Class Initialized
INFO - 2017-02-10 08:07:24 --> Output Class Initialized
INFO - 2017-02-10 08:07:24 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:24 --> Output Class Initialized
INFO - 2017-02-10 08:07:24 --> Input Class Initialized
INFO - 2017-02-10 08:07:24 --> Language Class Initialized
INFO - 2017-02-10 08:07:24 --> Security Class Initialized
ERROR - 2017-02-10 08:07:24 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:24 --> Input Class Initialized
INFO - 2017-02-10 08:07:24 --> Language Class Initialized
ERROR - 2017-02-10 08:07:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:24 --> Config Class Initialized
INFO - 2017-02-10 08:07:24 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:24 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:24 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:24 --> URI Class Initialized
INFO - 2017-02-10 08:07:24 --> Router Class Initialized
INFO - 2017-02-10 08:07:24 --> Output Class Initialized
INFO - 2017-02-10 08:07:24 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:24 --> Input Class Initialized
INFO - 2017-02-10 08:07:24 --> Language Class Initialized
ERROR - 2017-02-10 08:07:24 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:26 --> Config Class Initialized
INFO - 2017-02-10 08:07:26 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:26 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:26 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:26 --> URI Class Initialized
INFO - 2017-02-10 08:07:26 --> Router Class Initialized
INFO - 2017-02-10 08:07:26 --> Output Class Initialized
INFO - 2017-02-10 08:07:26 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:26 --> Input Class Initialized
INFO - 2017-02-10 08:07:26 --> Language Class Initialized
INFO - 2017-02-10 08:07:26 --> Language Class Initialized
INFO - 2017-02-10 08:07:26 --> Config Class Initialized
INFO - 2017-02-10 08:07:26 --> Loader Class Initialized
INFO - 2017-02-10 08:07:26 --> Helper loaded: form_helper
INFO - 2017-02-10 08:07:26 --> Helper loaded: url_helper
INFO - 2017-02-10 08:07:26 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:07:26 --> Database Driver Class Initialized
INFO - 2017-02-10 08:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:07:26 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:07:26 --> Template Class Initialized
INFO - 2017-02-10 08:07:26 --> Controller Class Initialized
INFO - 2017-02-10 08:07:26 --> Model Class Initialized
INFO - 2017-02-10 08:07:26 --> Model Class Initialized
INFO - 2017-02-10 08:07:26 --> Model Class Initialized
DEBUG - 2017-02-10 08:07:26 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 08:07:26 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 08:07:26 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 08:07:26 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 08:07:26 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 08:07:26 --> Final output sent to browser
DEBUG - 2017-02-10 08:07:26 --> Total execution time: 0.0455
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Loader Class Initialized
INFO - 2017-02-10 08:07:27 --> Helper loaded: form_helper
INFO - 2017-02-10 08:07:27 --> Helper loaded: url_helper
INFO - 2017-02-10 08:07:27 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:07:27 --> Database Driver Class Initialized
INFO - 2017-02-10 08:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:07:27 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Template Class Initialized
INFO - 2017-02-10 08:07:27 --> Controller Class Initialized
INFO - 2017-02-10 08:07:27 --> Model Class Initialized
INFO - 2017-02-10 08:07:27 --> Model Class Initialized
INFO - 2017-02-10 08:07:27 --> Model Class Initialized
DEBUG - 2017-02-10 08:07:27 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 08:07:27 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 08:07:27 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 08:07:27 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 08:07:27 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 08:07:27 --> Final output sent to browser
DEBUG - 2017-02-10 08:07:27 --> Total execution time: 0.0536
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:27 --> Config Class Initialized
INFO - 2017-02-10 08:07:27 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:27 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:27 --> URI Class Initialized
INFO - 2017-02-10 08:07:27 --> Router Class Initialized
INFO - 2017-02-10 08:07:27 --> Output Class Initialized
INFO - 2017-02-10 08:07:27 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:27 --> Input Class Initialized
INFO - 2017-02-10 08:07:27 --> Language Class Initialized
ERROR - 2017-02-10 08:07:27 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:31 --> Config Class Initialized
INFO - 2017-02-10 08:07:31 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:31 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:31 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:31 --> URI Class Initialized
INFO - 2017-02-10 08:07:31 --> Router Class Initialized
INFO - 2017-02-10 08:07:31 --> Output Class Initialized
INFO - 2017-02-10 08:07:31 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:31 --> Input Class Initialized
INFO - 2017-02-10 08:07:31 --> Language Class Initialized
INFO - 2017-02-10 08:07:31 --> Language Class Initialized
INFO - 2017-02-10 08:07:31 --> Config Class Initialized
INFO - 2017-02-10 08:07:31 --> Loader Class Initialized
INFO - 2017-02-10 08:07:31 --> Helper loaded: form_helper
INFO - 2017-02-10 08:07:31 --> Helper loaded: url_helper
INFO - 2017-02-10 08:07:31 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:07:31 --> Database Driver Class Initialized
INFO - 2017-02-10 08:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:07:31 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:07:31 --> Template Class Initialized
INFO - 2017-02-10 08:07:31 --> Controller Class Initialized
INFO - 2017-02-10 08:07:31 --> Model Class Initialized
INFO - 2017-02-10 08:07:31 --> Model Class Initialized
INFO - 2017-02-10 08:07:31 --> Model Class Initialized
DEBUG - 2017-02-10 08:07:31 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 08:07:31 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 08:07:31 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 08:07:31 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 08:07:31 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 08:07:31 --> Final output sent to browser
DEBUG - 2017-02-10 08:07:31 --> Total execution time: 0.0434
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Loader Class Initialized
INFO - 2017-02-10 08:07:34 --> Helper loaded: form_helper
INFO - 2017-02-10 08:07:34 --> Helper loaded: url_helper
INFO - 2017-02-10 08:07:34 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:07:34 --> Database Driver Class Initialized
INFO - 2017-02-10 08:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:07:34 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Template Class Initialized
INFO - 2017-02-10 08:07:34 --> Controller Class Initialized
INFO - 2017-02-10 08:07:34 --> Model Class Initialized
INFO - 2017-02-10 08:07:34 --> Model Class Initialized
INFO - 2017-02-10 08:07:34 --> Model Class Initialized
DEBUG - 2017-02-10 08:07:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 08:07:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 08:07:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 08:07:34 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_send.php
DEBUG - 2017-02-10 08:07:34 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 08:07:34 --> Final output sent to browser
DEBUG - 2017-02-10 08:07:34 --> Total execution time: 0.0523
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:34 --> Router Class Initialized
INFO - 2017-02-10 08:07:34 --> Output Class Initialized
INFO - 2017-02-10 08:07:34 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:34 --> Input Class Initialized
INFO - 2017-02-10 08:07:34 --> Language Class Initialized
ERROR - 2017-02-10 08:07:34 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:34 --> Config Class Initialized
INFO - 2017-02-10 08:07:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:34 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:34 --> URI Class Initialized
INFO - 2017-02-10 08:07:35 --> Router Class Initialized
INFO - 2017-02-10 08:07:35 --> Output Class Initialized
INFO - 2017-02-10 08:07:35 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:35 --> Input Class Initialized
INFO - 2017-02-10 08:07:35 --> Language Class Initialized
ERROR - 2017-02-10 08:07:35 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:07:36 --> Config Class Initialized
INFO - 2017-02-10 08:07:36 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:07:36 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:07:36 --> Utf8 Class Initialized
INFO - 2017-02-10 08:07:36 --> URI Class Initialized
INFO - 2017-02-10 08:07:36 --> Router Class Initialized
INFO - 2017-02-10 08:07:36 --> Output Class Initialized
INFO - 2017-02-10 08:07:36 --> Security Class Initialized
DEBUG - 2017-02-10 08:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:07:36 --> Input Class Initialized
INFO - 2017-02-10 08:07:37 --> Language Class Initialized
INFO - 2017-02-10 08:07:37 --> Language Class Initialized
INFO - 2017-02-10 08:07:37 --> Config Class Initialized
INFO - 2017-02-10 08:07:37 --> Loader Class Initialized
INFO - 2017-02-10 08:07:37 --> Helper loaded: form_helper
INFO - 2017-02-10 08:07:37 --> Helper loaded: url_helper
INFO - 2017-02-10 08:07:37 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:07:37 --> Database Driver Class Initialized
INFO - 2017-02-10 08:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:07:37 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:07:37 --> Template Class Initialized
INFO - 2017-02-10 08:07:37 --> Controller Class Initialized
INFO - 2017-02-10 08:07:37 --> Model Class Initialized
INFO - 2017-02-10 08:07:37 --> Model Class Initialized
INFO - 2017-02-10 08:07:37 --> Model Class Initialized
DEBUG - 2017-02-10 08:07:37 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 08:07:37 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 08:07:37 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 08:07:37 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 08:07:37 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 08:07:37 --> Final output sent to browser
DEBUG - 2017-02-10 08:07:37 --> Total execution time: 0.0590
INFO - 2017-02-10 08:08:48 --> Config Class Initialized
INFO - 2017-02-10 08:08:48 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:08:48 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:08:48 --> Utf8 Class Initialized
INFO - 2017-02-10 08:08:48 --> URI Class Initialized
INFO - 2017-02-10 08:08:48 --> Router Class Initialized
INFO - 2017-02-10 08:08:48 --> Output Class Initialized
INFO - 2017-02-10 08:08:48 --> Security Class Initialized
DEBUG - 2017-02-10 08:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:08:48 --> Input Class Initialized
INFO - 2017-02-10 08:08:48 --> Language Class Initialized
INFO - 2017-02-10 08:08:48 --> Language Class Initialized
INFO - 2017-02-10 08:08:48 --> Config Class Initialized
INFO - 2017-02-10 08:08:48 --> Loader Class Initialized
INFO - 2017-02-10 08:08:48 --> Helper loaded: form_helper
INFO - 2017-02-10 08:08:48 --> Helper loaded: url_helper
INFO - 2017-02-10 08:08:48 --> Helper loaded: utility_helper
INFO - 2017-02-10 08:08:48 --> Database Driver Class Initialized
INFO - 2017-02-10 08:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:08:48 --> User Agent Class Initialized
DEBUG - 2017-02-10 08:08:48 --> Template Class Initialized
INFO - 2017-02-10 08:08:48 --> Controller Class Initialized
INFO - 2017-02-10 08:08:48 --> Model Class Initialized
INFO - 2017-02-10 08:08:48 --> Model Class Initialized
INFO - 2017-02-10 08:08:48 --> Model Class Initialized
DEBUG - 2017-02-10 08:08:48 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/header.php
DEBUG - 2017-02-10 08:08:48 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/leftpanel.php
DEBUG - 2017-02-10 08:08:48 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/partials/footer.php
DEBUG - 2017-02-10 08:08:48 --> File loaded: C:\xampp\htdocs\mobile\application\modules/backend/views/newsletter/newsletter_list.php
DEBUG - 2017-02-10 08:08:48 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/backend.php
INFO - 2017-02-10 08:08:48 --> Final output sent to browser
DEBUG - 2017-02-10 08:08:48 --> Total execution time: 0.0710
INFO - 2017-02-10 08:08:48 --> Config Class Initialized
INFO - 2017-02-10 08:08:48 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:08:48 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:08:48 --> Utf8 Class Initialized
INFO - 2017-02-10 08:08:48 --> URI Class Initialized
INFO - 2017-02-10 08:08:48 --> Config Class Initialized
INFO - 2017-02-10 08:08:48 --> Hooks Class Initialized
INFO - 2017-02-10 08:08:48 --> Router Class Initialized
DEBUG - 2017-02-10 08:08:48 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:08:48 --> Output Class Initialized
INFO - 2017-02-10 08:08:48 --> Utf8 Class Initialized
INFO - 2017-02-10 08:08:48 --> Security Class Initialized
INFO - 2017-02-10 08:08:48 --> URI Class Initialized
DEBUG - 2017-02-10 08:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:08:48 --> Input Class Initialized
INFO - 2017-02-10 08:08:48 --> Language Class Initialized
ERROR - 2017-02-10 08:08:48 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:08:48 --> Router Class Initialized
INFO - 2017-02-10 08:08:48 --> Output Class Initialized
INFO - 2017-02-10 08:08:48 --> Security Class Initialized
DEBUG - 2017-02-10 08:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:08:48 --> Input Class Initialized
INFO - 2017-02-10 08:08:48 --> Language Class Initialized
ERROR - 2017-02-10 08:08:48 --> 404 Page Not Found: /index
INFO - 2017-02-10 08:08:48 --> Config Class Initialized
INFO - 2017-02-10 08:08:48 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:08:48 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:08:48 --> Utf8 Class Initialized
INFO - 2017-02-10 08:08:48 --> URI Class Initialized
INFO - 2017-02-10 08:08:48 --> Router Class Initialized
INFO - 2017-02-10 08:08:48 --> Output Class Initialized
INFO - 2017-02-10 08:08:48 --> Security Class Initialized
DEBUG - 2017-02-10 08:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:08:48 --> Input Class Initialized
INFO - 2017-02-10 08:08:48 --> Language Class Initialized
ERROR - 2017-02-10 08:08:48 --> 404 Page Not Found: /index
INFO - 2017-02-10 09:03:34 --> Config Class Initialized
INFO - 2017-02-10 09:03:34 --> Hooks Class Initialized
DEBUG - 2017-02-10 09:03:34 --> UTF-8 Support Enabled
INFO - 2017-02-10 09:03:34 --> Utf8 Class Initialized
INFO - 2017-02-10 09:03:34 --> URI Class Initialized
INFO - 2017-02-10 09:03:34 --> Router Class Initialized
INFO - 2017-02-10 09:03:34 --> Output Class Initialized
INFO - 2017-02-10 09:03:34 --> Security Class Initialized
DEBUG - 2017-02-10 09:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 09:03:34 --> Input Class Initialized
INFO - 2017-02-10 09:03:34 --> Language Class Initialized
ERROR - 2017-02-10 09:03:35 --> 404 Page Not Found: /index
INFO - 2017-02-10 09:03:35 --> Config Class Initialized
INFO - 2017-02-10 09:03:35 --> Hooks Class Initialized
DEBUG - 2017-02-10 09:03:35 --> UTF-8 Support Enabled
INFO - 2017-02-10 09:03:35 --> Utf8 Class Initialized
INFO - 2017-02-10 09:03:35 --> URI Class Initialized
INFO - 2017-02-10 09:03:35 --> Router Class Initialized
INFO - 2017-02-10 09:03:35 --> Output Class Initialized
INFO - 2017-02-10 09:03:35 --> Security Class Initialized
DEBUG - 2017-02-10 09:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 09:03:35 --> Input Class Initialized
INFO - 2017-02-10 09:03:35 --> Language Class Initialized
ERROR - 2017-02-10 09:03:35 --> 404 Page Not Found: /index
INFO - 2017-02-10 09:04:02 --> Config Class Initialized
INFO - 2017-02-10 09:04:02 --> Hooks Class Initialized
DEBUG - 2017-02-10 09:04:02 --> UTF-8 Support Enabled
INFO - 2017-02-10 09:04:02 --> Utf8 Class Initialized
INFO - 2017-02-10 09:04:02 --> URI Class Initialized
INFO - 2017-02-10 09:04:02 --> Router Class Initialized
INFO - 2017-02-10 09:04:02 --> Output Class Initialized
INFO - 2017-02-10 09:04:02 --> Security Class Initialized
DEBUG - 2017-02-10 09:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 09:04:02 --> Input Class Initialized
INFO - 2017-02-10 09:04:02 --> Language Class Initialized
ERROR - 2017-02-10 09:04:02 --> 404 Page Not Found: /index
INFO - 2017-02-10 09:04:06 --> Config Class Initialized
INFO - 2017-02-10 09:04:06 --> Hooks Class Initialized
DEBUG - 2017-02-10 09:04:06 --> UTF-8 Support Enabled
INFO - 2017-02-10 09:04:06 --> Utf8 Class Initialized
INFO - 2017-02-10 09:04:06 --> URI Class Initialized
INFO - 2017-02-10 09:04:06 --> Router Class Initialized
INFO - 2017-02-10 09:04:06 --> Output Class Initialized
INFO - 2017-02-10 09:04:06 --> Security Class Initialized
DEBUG - 2017-02-10 09:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 09:04:06 --> Input Class Initialized
INFO - 2017-02-10 09:04:06 --> Language Class Initialized
ERROR - 2017-02-10 09:04:06 --> 404 Page Not Found: /index
INFO - 2017-02-10 12:39:37 --> Config Class Initialized
INFO - 2017-02-10 12:39:37 --> Hooks Class Initialized
DEBUG - 2017-02-10 12:39:38 --> UTF-8 Support Enabled
INFO - 2017-02-10 12:39:38 --> Utf8 Class Initialized
INFO - 2017-02-10 12:39:38 --> URI Class Initialized
INFO - 2017-02-10 12:39:38 --> Router Class Initialized
INFO - 2017-02-10 12:39:38 --> Output Class Initialized
INFO - 2017-02-10 12:39:38 --> Security Class Initialized
DEBUG - 2017-02-10 12:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 12:39:38 --> Input Class Initialized
INFO - 2017-02-10 12:39:38 --> Language Class Initialized
INFO - 2017-02-10 12:39:39 --> Language Class Initialized
INFO - 2017-02-10 12:39:39 --> Config Class Initialized
INFO - 2017-02-10 12:39:39 --> Loader Class Initialized
INFO - 2017-02-10 12:39:39 --> Helper loaded: form_helper
INFO - 2017-02-10 12:39:39 --> Helper loaded: url_helper
INFO - 2017-02-10 12:39:40 --> Helper loaded: utility_helper
INFO - 2017-02-10 12:39:40 --> Database Driver Class Initialized
INFO - 2017-02-10 12:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 12:39:41 --> User Agent Class Initialized
DEBUG - 2017-02-10 12:39:41 --> Template Class Initialized
INFO - 2017-02-10 12:39:41 --> Controller Class Initialized
INFO - 2017-02-10 12:39:41 --> Model Class Initialized
INFO - 2017-02-10 12:39:41 --> Model Class Initialized
INFO - 2017-02-10 12:39:41 --> Model Class Initialized
