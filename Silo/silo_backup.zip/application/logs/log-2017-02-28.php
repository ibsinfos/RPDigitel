<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-28 04:14:01 --> Config Class Initialized
INFO - 2017-02-28 04:14:01 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:01 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:01 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:01 --> URI Class Initialized
INFO - 2017-02-28 04:14:01 --> Router Class Initialized
INFO - 2017-02-28 04:14:01 --> Output Class Initialized
INFO - 2017-02-28 04:14:01 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:01 --> Input Class Initialized
INFO - 2017-02-28 04:14:01 --> Language Class Initialized
INFO - 2017-02-28 04:14:01 --> Language Class Initialized
INFO - 2017-02-28 04:14:01 --> Config Class Initialized
INFO - 2017-02-28 04:14:01 --> Loader Class Initialized
INFO - 2017-02-28 04:14:01 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:01 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:01 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:01 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:01 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:01 --> Template Class Initialized
INFO - 2017-02-28 04:14:01 --> Model Class Initialized
INFO - 2017-02-28 04:14:01 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:01 --> Dashboard MX_Controller Initialized
INFO - 2017-02-28 04:14:01 --> Helper loaded: cookie_helper
INFO - 2017-02-28 04:14:02 --> Config Class Initialized
INFO - 2017-02-28 04:14:02 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:02 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:02 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:02 --> URI Class Initialized
DEBUG - 2017-02-28 04:14:02 --> No URI present. Default controller set.
INFO - 2017-02-28 04:14:02 --> Router Class Initialized
INFO - 2017-02-28 04:14:02 --> Output Class Initialized
INFO - 2017-02-28 04:14:02 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:02 --> Input Class Initialized
INFO - 2017-02-28 04:14:02 --> Language Class Initialized
INFO - 2017-02-28 04:14:02 --> Language Class Initialized
INFO - 2017-02-28 04:14:02 --> Config Class Initialized
INFO - 2017-02-28 04:14:02 --> Loader Class Initialized
INFO - 2017-02-28 04:14:02 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:02 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:02 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:02 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:02 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:02 --> Template Class Initialized
INFO - 2017-02-28 04:14:02 --> Model Class Initialized
INFO - 2017-02-28 04:14:02 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:02 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:02 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-28 04:14:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-28 04:14:02 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-28 04:14:02 --> Final output sent to browser
DEBUG - 2017-02-28 04:14:02 --> Total execution time: 0.0579
INFO - 2017-02-28 04:14:04 --> Config Class Initialized
INFO - 2017-02-28 04:14:04 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:04 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:04 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:04 --> URI Class Initialized
INFO - 2017-02-28 04:14:04 --> Router Class Initialized
INFO - 2017-02-28 04:14:04 --> Output Class Initialized
INFO - 2017-02-28 04:14:04 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:04 --> Input Class Initialized
INFO - 2017-02-28 04:14:04 --> Language Class Initialized
INFO - 2017-02-28 04:14:04 --> Language Class Initialized
INFO - 2017-02-28 04:14:04 --> Config Class Initialized
INFO - 2017-02-28 04:14:04 --> Loader Class Initialized
INFO - 2017-02-28 04:14:04 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:04 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:04 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:04 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:04 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:04 --> Template Class Initialized
INFO - 2017-02-28 04:14:04 --> Model Class Initialized
INFO - 2017-02-28 04:14:04 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:04 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:04 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 04:14:06 --> Config Class Initialized
INFO - 2017-02-28 04:14:06 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:06 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:06 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:06 --> URI Class Initialized
INFO - 2017-02-28 04:14:06 --> Router Class Initialized
INFO - 2017-02-28 04:14:06 --> Output Class Initialized
INFO - 2017-02-28 04:14:06 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:06 --> Input Class Initialized
INFO - 2017-02-28 04:14:06 --> Language Class Initialized
INFO - 2017-02-28 04:14:06 --> Language Class Initialized
INFO - 2017-02-28 04:14:06 --> Config Class Initialized
INFO - 2017-02-28 04:14:06 --> Loader Class Initialized
INFO - 2017-02-28 04:14:06 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:06 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:06 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:06 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:06 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:06 --> Template Class Initialized
INFO - 2017-02-28 04:14:06 --> Model Class Initialized
INFO - 2017-02-28 04:14:06 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:06 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:06 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 04:14:07 --> Config Class Initialized
INFO - 2017-02-28 04:14:07 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:07 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:07 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:07 --> URI Class Initialized
INFO - 2017-02-28 04:14:07 --> Router Class Initialized
INFO - 2017-02-28 04:14:07 --> Output Class Initialized
INFO - 2017-02-28 04:14:07 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:07 --> Input Class Initialized
INFO - 2017-02-28 04:14:07 --> Language Class Initialized
INFO - 2017-02-28 04:14:07 --> Language Class Initialized
INFO - 2017-02-28 04:14:07 --> Config Class Initialized
INFO - 2017-02-28 04:14:07 --> Loader Class Initialized
INFO - 2017-02-28 04:14:07 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:07 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:07 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:07 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:07 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:07 --> Template Class Initialized
INFO - 2017-02-28 04:14:07 --> Model Class Initialized
INFO - 2017-02-28 04:14:07 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:07 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:07 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 04:14:08 --> Config Class Initialized
INFO - 2017-02-28 04:14:08 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:08 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:08 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:08 --> URI Class Initialized
INFO - 2017-02-28 04:14:08 --> Router Class Initialized
INFO - 2017-02-28 04:14:08 --> Output Class Initialized
INFO - 2017-02-28 04:14:08 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:08 --> Input Class Initialized
INFO - 2017-02-28 04:14:08 --> Language Class Initialized
INFO - 2017-02-28 04:14:08 --> Language Class Initialized
INFO - 2017-02-28 04:14:08 --> Config Class Initialized
INFO - 2017-02-28 04:14:08 --> Loader Class Initialized
INFO - 2017-02-28 04:14:08 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:08 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:08 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:08 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:08 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:08 --> Template Class Initialized
INFO - 2017-02-28 04:14:08 --> Model Class Initialized
INFO - 2017-02-28 04:14:08 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:08 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:08 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 04:14:16 --> Config Class Initialized
INFO - 2017-02-28 04:14:16 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:16 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:16 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:16 --> URI Class Initialized
DEBUG - 2017-02-28 04:14:16 --> No URI present. Default controller set.
INFO - 2017-02-28 04:14:16 --> Router Class Initialized
INFO - 2017-02-28 04:14:16 --> Output Class Initialized
INFO - 2017-02-28 04:14:16 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:16 --> Input Class Initialized
INFO - 2017-02-28 04:14:16 --> Language Class Initialized
INFO - 2017-02-28 04:14:16 --> Language Class Initialized
INFO - 2017-02-28 04:14:16 --> Config Class Initialized
INFO - 2017-02-28 04:14:16 --> Loader Class Initialized
INFO - 2017-02-28 04:14:16 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:16 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:16 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:16 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:16 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:16 --> Template Class Initialized
INFO - 2017-02-28 04:14:16 --> Model Class Initialized
INFO - 2017-02-28 04:14:16 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:16 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:16 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-28 04:14:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-28 04:14:16 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-28 04:14:16 --> Final output sent to browser
DEBUG - 2017-02-28 04:14:16 --> Total execution time: 0.0146
INFO - 2017-02-28 04:14:17 --> Config Class Initialized
INFO - 2017-02-28 04:14:17 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:17 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:17 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:17 --> URI Class Initialized
INFO - 2017-02-28 04:14:17 --> Router Class Initialized
INFO - 2017-02-28 04:14:17 --> Output Class Initialized
INFO - 2017-02-28 04:14:17 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:17 --> Input Class Initialized
INFO - 2017-02-28 04:14:17 --> Language Class Initialized
INFO - 2017-02-28 04:14:17 --> Language Class Initialized
INFO - 2017-02-28 04:14:17 --> Config Class Initialized
INFO - 2017-02-28 04:14:17 --> Loader Class Initialized
INFO - 2017-02-28 04:14:17 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:17 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:17 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:17 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:17 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:17 --> Template Class Initialized
INFO - 2017-02-28 04:14:17 --> Model Class Initialized
INFO - 2017-02-28 04:14:17 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:17 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:17 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 04:14:17 --> Config Class Initialized
INFO - 2017-02-28 04:14:17 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:17 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:17 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:17 --> URI Class Initialized
INFO - 2017-02-28 04:14:17 --> Router Class Initialized
INFO - 2017-02-28 04:14:17 --> Output Class Initialized
INFO - 2017-02-28 04:14:17 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:17 --> Input Class Initialized
INFO - 2017-02-28 04:14:17 --> Language Class Initialized
INFO - 2017-02-28 04:14:17 --> Language Class Initialized
INFO - 2017-02-28 04:14:17 --> Config Class Initialized
INFO - 2017-02-28 04:14:17 --> Loader Class Initialized
INFO - 2017-02-28 04:14:17 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:17 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:17 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:17 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:17 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:17 --> Template Class Initialized
INFO - 2017-02-28 04:14:17 --> Model Class Initialized
INFO - 2017-02-28 04:14:17 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:17 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:17 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 04:14:17 --> Config Class Initialized
INFO - 2017-02-28 04:14:17 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:17 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:17 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:17 --> URI Class Initialized
INFO - 2017-02-28 04:14:17 --> Router Class Initialized
INFO - 2017-02-28 04:14:17 --> Output Class Initialized
INFO - 2017-02-28 04:14:17 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:17 --> Input Class Initialized
INFO - 2017-02-28 04:14:17 --> Language Class Initialized
INFO - 2017-02-28 04:14:17 --> Language Class Initialized
INFO - 2017-02-28 04:14:17 --> Config Class Initialized
INFO - 2017-02-28 04:14:17 --> Loader Class Initialized
INFO - 2017-02-28 04:14:17 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:17 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:17 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:17 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:18 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:18 --> Template Class Initialized
INFO - 2017-02-28 04:14:18 --> Model Class Initialized
INFO - 2017-02-28 04:14:18 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:18 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:18 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 04:14:23 --> Config Class Initialized
INFO - 2017-02-28 04:14:23 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:23 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:23 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:23 --> URI Class Initialized
INFO - 2017-02-28 04:14:23 --> Router Class Initialized
INFO - 2017-02-28 04:14:23 --> Output Class Initialized
INFO - 2017-02-28 04:14:23 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:23 --> Input Class Initialized
INFO - 2017-02-28 04:14:23 --> Language Class Initialized
INFO - 2017-02-28 04:14:23 --> Language Class Initialized
INFO - 2017-02-28 04:14:23 --> Config Class Initialized
INFO - 2017-02-28 04:14:23 --> Loader Class Initialized
INFO - 2017-02-28 04:14:23 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:23 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:23 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:23 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:23 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:23 --> Template Class Initialized
INFO - 2017-02-28 04:14:23 --> Model Class Initialized
INFO - 2017-02-28 04:14:23 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:23 --> Dashboard MX_Controller Initialized
INFO - 2017-02-28 04:14:23 --> Helper loaded: cookie_helper
INFO - 2017-02-28 04:14:23 --> Config Class Initialized
INFO - 2017-02-28 04:14:23 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:23 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:23 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:23 --> URI Class Initialized
DEBUG - 2017-02-28 04:14:23 --> No URI present. Default controller set.
INFO - 2017-02-28 04:14:23 --> Router Class Initialized
INFO - 2017-02-28 04:14:23 --> Output Class Initialized
INFO - 2017-02-28 04:14:23 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:23 --> Input Class Initialized
INFO - 2017-02-28 04:14:23 --> Language Class Initialized
INFO - 2017-02-28 04:14:23 --> Language Class Initialized
INFO - 2017-02-28 04:14:23 --> Config Class Initialized
INFO - 2017-02-28 04:14:23 --> Loader Class Initialized
INFO - 2017-02-28 04:14:23 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:23 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:23 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:23 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:23 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:23 --> Template Class Initialized
INFO - 2017-02-28 04:14:23 --> Model Class Initialized
INFO - 2017-02-28 04:14:23 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:23 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:23 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-28 04:14:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-28 04:14:23 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-28 04:14:23 --> Final output sent to browser
DEBUG - 2017-02-28 04:14:23 --> Total execution time: 0.0128
INFO - 2017-02-28 04:14:23 --> Config Class Initialized
INFO - 2017-02-28 04:14:23 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:23 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:23 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:23 --> URI Class Initialized
INFO - 2017-02-28 04:14:23 --> Router Class Initialized
INFO - 2017-02-28 04:14:23 --> Output Class Initialized
INFO - 2017-02-28 04:14:23 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:23 --> Input Class Initialized
INFO - 2017-02-28 04:14:23 --> Language Class Initialized
INFO - 2017-02-28 04:14:23 --> Language Class Initialized
INFO - 2017-02-28 04:14:23 --> Config Class Initialized
INFO - 2017-02-28 04:14:23 --> Loader Class Initialized
INFO - 2017-02-28 04:14:23 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:23 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:23 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:23 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:23 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:23 --> Template Class Initialized
INFO - 2017-02-28 04:14:23 --> Model Class Initialized
INFO - 2017-02-28 04:14:23 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:23 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:23 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 04:14:23 --> Config Class Initialized
INFO - 2017-02-28 04:14:23 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:23 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:23 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:23 --> URI Class Initialized
INFO - 2017-02-28 04:14:24 --> Router Class Initialized
INFO - 2017-02-28 04:14:24 --> Output Class Initialized
INFO - 2017-02-28 04:14:24 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:24 --> Input Class Initialized
INFO - 2017-02-28 04:14:24 --> Language Class Initialized
INFO - 2017-02-28 04:14:24 --> Language Class Initialized
INFO - 2017-02-28 04:14:24 --> Config Class Initialized
INFO - 2017-02-28 04:14:24 --> Loader Class Initialized
INFO - 2017-02-28 04:14:24 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:24 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:24 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:24 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:24 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:24 --> Template Class Initialized
INFO - 2017-02-28 04:14:24 --> Model Class Initialized
INFO - 2017-02-28 04:14:24 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:24 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:24 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 04:14:24 --> Config Class Initialized
INFO - 2017-02-28 04:14:24 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:24 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:24 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:24 --> URI Class Initialized
INFO - 2017-02-28 04:14:24 --> Router Class Initialized
INFO - 2017-02-28 04:14:24 --> Output Class Initialized
INFO - 2017-02-28 04:14:24 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:24 --> Input Class Initialized
INFO - 2017-02-28 04:14:24 --> Language Class Initialized
INFO - 2017-02-28 04:14:24 --> Language Class Initialized
INFO - 2017-02-28 04:14:24 --> Config Class Initialized
INFO - 2017-02-28 04:14:24 --> Loader Class Initialized
INFO - 2017-02-28 04:14:24 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:24 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:24 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:24 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:24 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:24 --> Template Class Initialized
INFO - 2017-02-28 04:14:24 --> Model Class Initialized
INFO - 2017-02-28 04:14:24 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:24 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:24 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 04:14:25 --> Config Class Initialized
INFO - 2017-02-28 04:14:25 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:25 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:25 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:25 --> URI Class Initialized
INFO - 2017-02-28 04:14:25 --> Router Class Initialized
INFO - 2017-02-28 04:14:25 --> Output Class Initialized
INFO - 2017-02-28 04:14:25 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:25 --> Input Class Initialized
INFO - 2017-02-28 04:14:25 --> Language Class Initialized
INFO - 2017-02-28 04:14:25 --> Language Class Initialized
INFO - 2017-02-28 04:14:25 --> Config Class Initialized
INFO - 2017-02-28 04:14:25 --> Loader Class Initialized
INFO - 2017-02-28 04:14:25 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:25 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:25 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:25 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:25 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:25 --> Template Class Initialized
INFO - 2017-02-28 04:14:25 --> Model Class Initialized
INFO - 2017-02-28 04:14:25 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:25 --> Dashboard MX_Controller Initialized
INFO - 2017-02-28 04:14:25 --> Helper loaded: cookie_helper
INFO - 2017-02-28 04:14:25 --> Config Class Initialized
INFO - 2017-02-28 04:14:25 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:25 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:25 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:25 --> URI Class Initialized
DEBUG - 2017-02-28 04:14:25 --> No URI present. Default controller set.
INFO - 2017-02-28 04:14:25 --> Router Class Initialized
INFO - 2017-02-28 04:14:25 --> Output Class Initialized
INFO - 2017-02-28 04:14:25 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:25 --> Input Class Initialized
INFO - 2017-02-28 04:14:25 --> Language Class Initialized
INFO - 2017-02-28 04:14:25 --> Language Class Initialized
INFO - 2017-02-28 04:14:25 --> Config Class Initialized
INFO - 2017-02-28 04:14:25 --> Loader Class Initialized
INFO - 2017-02-28 04:14:25 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:25 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:25 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:25 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:25 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:25 --> Template Class Initialized
INFO - 2017-02-28 04:14:25 --> Model Class Initialized
INFO - 2017-02-28 04:14:25 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:25 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:25 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-28 04:14:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-28 04:14:25 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-28 04:14:25 --> Final output sent to browser
DEBUG - 2017-02-28 04:14:25 --> Total execution time: 0.0138
INFO - 2017-02-28 04:14:26 --> Config Class Initialized
INFO - 2017-02-28 04:14:26 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:26 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:26 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:26 --> URI Class Initialized
INFO - 2017-02-28 04:14:26 --> Router Class Initialized
INFO - 2017-02-28 04:14:26 --> Output Class Initialized
INFO - 2017-02-28 04:14:26 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:26 --> Input Class Initialized
INFO - 2017-02-28 04:14:26 --> Language Class Initialized
INFO - 2017-02-28 04:14:26 --> Language Class Initialized
INFO - 2017-02-28 04:14:26 --> Config Class Initialized
INFO - 2017-02-28 04:14:26 --> Loader Class Initialized
INFO - 2017-02-28 04:14:26 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:26 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:26 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:26 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:26 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:26 --> Template Class Initialized
INFO - 2017-02-28 04:14:26 --> Model Class Initialized
INFO - 2017-02-28 04:14:26 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:26 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:26 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 04:14:26 --> Config Class Initialized
INFO - 2017-02-28 04:14:26 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:26 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:26 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:26 --> URI Class Initialized
INFO - 2017-02-28 04:14:26 --> Router Class Initialized
INFO - 2017-02-28 04:14:26 --> Output Class Initialized
INFO - 2017-02-28 04:14:26 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:26 --> Input Class Initialized
INFO - 2017-02-28 04:14:26 --> Language Class Initialized
INFO - 2017-02-28 04:14:26 --> Language Class Initialized
INFO - 2017-02-28 04:14:26 --> Config Class Initialized
INFO - 2017-02-28 04:14:26 --> Loader Class Initialized
INFO - 2017-02-28 04:14:26 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:26 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:26 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:26 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:26 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:26 --> Template Class Initialized
INFO - 2017-02-28 04:14:26 --> Model Class Initialized
INFO - 2017-02-28 04:14:26 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:26 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:26 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 04:14:26 --> Config Class Initialized
INFO - 2017-02-28 04:14:26 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:26 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:26 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:26 --> URI Class Initialized
INFO - 2017-02-28 04:14:26 --> Router Class Initialized
INFO - 2017-02-28 04:14:26 --> Output Class Initialized
INFO - 2017-02-28 04:14:26 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:26 --> Input Class Initialized
INFO - 2017-02-28 04:14:26 --> Language Class Initialized
INFO - 2017-02-28 04:14:26 --> Language Class Initialized
INFO - 2017-02-28 04:14:26 --> Config Class Initialized
INFO - 2017-02-28 04:14:26 --> Loader Class Initialized
INFO - 2017-02-28 04:14:26 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:26 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:26 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:26 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:26 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:26 --> Template Class Initialized
INFO - 2017-02-28 04:14:26 --> Model Class Initialized
INFO - 2017-02-28 04:14:26 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:26 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:26 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 04:14:33 --> Config Class Initialized
INFO - 2017-02-28 04:14:33 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:33 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:33 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:33 --> URI Class Initialized
INFO - 2017-02-28 04:14:33 --> Router Class Initialized
INFO - 2017-02-28 04:14:33 --> Output Class Initialized
INFO - 2017-02-28 04:14:33 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:33 --> Input Class Initialized
INFO - 2017-02-28 04:14:33 --> Language Class Initialized
INFO - 2017-02-28 04:14:33 --> Language Class Initialized
INFO - 2017-02-28 04:14:33 --> Config Class Initialized
INFO - 2017-02-28 04:14:33 --> Loader Class Initialized
INFO - 2017-02-28 04:14:33 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:33 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:33 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:33 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:33 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:33 --> Template Class Initialized
INFO - 2017-02-28 04:14:33 --> Model Class Initialized
INFO - 2017-02-28 04:14:33 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:33 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:33 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-28 04:14:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-02-28 04:14:33 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-28 04:14:33 --> Final output sent to browser
DEBUG - 2017-02-28 04:14:33 --> Total execution time: 0.0241
INFO - 2017-02-28 04:14:34 --> Config Class Initialized
INFO - 2017-02-28 04:14:34 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:14:34 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:14:34 --> Utf8 Class Initialized
INFO - 2017-02-28 04:14:34 --> URI Class Initialized
INFO - 2017-02-28 04:14:34 --> Router Class Initialized
INFO - 2017-02-28 04:14:34 --> Output Class Initialized
INFO - 2017-02-28 04:14:34 --> Security Class Initialized
DEBUG - 2017-02-28 04:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:14:34 --> Input Class Initialized
INFO - 2017-02-28 04:14:34 --> Language Class Initialized
INFO - 2017-02-28 04:14:34 --> Language Class Initialized
INFO - 2017-02-28 04:14:34 --> Config Class Initialized
INFO - 2017-02-28 04:14:34 --> Loader Class Initialized
INFO - 2017-02-28 04:14:34 --> Helper loaded: form_helper
INFO - 2017-02-28 04:14:34 --> Helper loaded: url_helper
INFO - 2017-02-28 04:14:34 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:14:34 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:14:34 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:14:34 --> Template Class Initialized
INFO - 2017-02-28 04:14:34 --> Model Class Initialized
INFO - 2017-02-28 04:14:34 --> Controller Class Initialized
DEBUG - 2017-02-28 04:14:34 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:14:34 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:14:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:14:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 04:15:45 --> Config Class Initialized
INFO - 2017-02-28 04:15:45 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:15:45 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:15:45 --> Utf8 Class Initialized
INFO - 2017-02-28 04:15:45 --> URI Class Initialized
DEBUG - 2017-02-28 04:15:45 --> No URI present. Default controller set.
INFO - 2017-02-28 04:15:45 --> Router Class Initialized
INFO - 2017-02-28 04:15:45 --> Output Class Initialized
INFO - 2017-02-28 04:15:45 --> Security Class Initialized
DEBUG - 2017-02-28 04:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:15:45 --> Input Class Initialized
INFO - 2017-02-28 04:15:45 --> Language Class Initialized
INFO - 2017-02-28 04:15:45 --> Language Class Initialized
INFO - 2017-02-28 04:15:45 --> Config Class Initialized
INFO - 2017-02-28 04:15:45 --> Loader Class Initialized
INFO - 2017-02-28 04:15:45 --> Helper loaded: form_helper
INFO - 2017-02-28 04:15:45 --> Helper loaded: url_helper
INFO - 2017-02-28 04:15:45 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:15:45 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:15:45 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:15:45 --> Template Class Initialized
INFO - 2017-02-28 04:15:45 --> Model Class Initialized
INFO - 2017-02-28 04:15:45 --> Controller Class Initialized
DEBUG - 2017-02-28 04:15:45 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:15:45 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:15:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:15:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-28 04:15:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-28 04:15:45 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-28 04:15:45 --> Final output sent to browser
DEBUG - 2017-02-28 04:15:45 --> Total execution time: 0.0603
INFO - 2017-02-28 04:15:45 --> Config Class Initialized
INFO - 2017-02-28 04:15:45 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:15:45 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:15:45 --> Utf8 Class Initialized
INFO - 2017-02-28 04:15:45 --> URI Class Initialized
INFO - 2017-02-28 04:15:45 --> Router Class Initialized
INFO - 2017-02-28 04:15:45 --> Output Class Initialized
INFO - 2017-02-28 04:15:45 --> Security Class Initialized
DEBUG - 2017-02-28 04:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:15:45 --> Input Class Initialized
INFO - 2017-02-28 04:15:45 --> Language Class Initialized
INFO - 2017-02-28 04:15:45 --> Language Class Initialized
INFO - 2017-02-28 04:15:45 --> Config Class Initialized
INFO - 2017-02-28 04:15:45 --> Loader Class Initialized
INFO - 2017-02-28 04:15:45 --> Helper loaded: form_helper
INFO - 2017-02-28 04:15:45 --> Helper loaded: url_helper
INFO - 2017-02-28 04:15:45 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:15:45 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:15:45 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:15:45 --> Template Class Initialized
INFO - 2017-02-28 04:15:45 --> Model Class Initialized
INFO - 2017-02-28 04:15:45 --> Controller Class Initialized
DEBUG - 2017-02-28 04:15:45 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:15:45 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:15:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:15:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 04:15:46 --> Config Class Initialized
INFO - 2017-02-28 04:15:46 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:15:46 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:15:46 --> Utf8 Class Initialized
INFO - 2017-02-28 04:15:46 --> URI Class Initialized
INFO - 2017-02-28 04:15:46 --> Router Class Initialized
INFO - 2017-02-28 04:15:46 --> Output Class Initialized
INFO - 2017-02-28 04:15:46 --> Security Class Initialized
DEBUG - 2017-02-28 04:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:15:46 --> Input Class Initialized
INFO - 2017-02-28 04:15:46 --> Language Class Initialized
INFO - 2017-02-28 04:15:46 --> Language Class Initialized
INFO - 2017-02-28 04:15:46 --> Config Class Initialized
INFO - 2017-02-28 04:15:46 --> Loader Class Initialized
INFO - 2017-02-28 04:15:46 --> Helper loaded: form_helper
INFO - 2017-02-28 04:15:46 --> Helper loaded: url_helper
INFO - 2017-02-28 04:15:46 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:15:46 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:15:46 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:15:46 --> Template Class Initialized
INFO - 2017-02-28 04:15:46 --> Model Class Initialized
INFO - 2017-02-28 04:15:46 --> Controller Class Initialized
DEBUG - 2017-02-28 04:15:46 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:15:46 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:15:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:15:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 04:15:54 --> Config Class Initialized
INFO - 2017-02-28 04:15:54 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:15:54 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:15:54 --> Utf8 Class Initialized
INFO - 2017-02-28 04:15:54 --> URI Class Initialized
INFO - 2017-02-28 04:15:54 --> Router Class Initialized
INFO - 2017-02-28 04:15:54 --> Output Class Initialized
INFO - 2017-02-28 04:15:54 --> Security Class Initialized
DEBUG - 2017-02-28 04:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:15:54 --> Input Class Initialized
INFO - 2017-02-28 04:15:54 --> Language Class Initialized
INFO - 2017-02-28 04:15:54 --> Language Class Initialized
INFO - 2017-02-28 04:15:54 --> Config Class Initialized
INFO - 2017-02-28 04:15:54 --> Loader Class Initialized
INFO - 2017-02-28 04:15:54 --> Helper loaded: form_helper
INFO - 2017-02-28 04:15:54 --> Helper loaded: url_helper
INFO - 2017-02-28 04:15:54 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:15:54 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:15:54 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:15:54 --> Template Class Initialized
INFO - 2017-02-28 04:15:54 --> Model Class Initialized
INFO - 2017-02-28 04:15:54 --> Controller Class Initialized
DEBUG - 2017-02-28 04:15:54 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:15:54 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:15:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:15:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-28 04:15:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-02-28 04:15:54 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-28 04:15:54 --> Final output sent to browser
DEBUG - 2017-02-28 04:15:54 --> Total execution time: 0.0279
INFO - 2017-02-28 04:15:54 --> Config Class Initialized
INFO - 2017-02-28 04:15:54 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:15:54 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:15:54 --> Utf8 Class Initialized
INFO - 2017-02-28 04:15:54 --> URI Class Initialized
INFO - 2017-02-28 04:15:54 --> Router Class Initialized
INFO - 2017-02-28 04:15:54 --> Output Class Initialized
INFO - 2017-02-28 04:15:54 --> Security Class Initialized
DEBUG - 2017-02-28 04:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:15:54 --> Input Class Initialized
INFO - 2017-02-28 04:15:54 --> Language Class Initialized
INFO - 2017-02-28 04:15:54 --> Language Class Initialized
INFO - 2017-02-28 04:15:54 --> Config Class Initialized
INFO - 2017-02-28 04:15:54 --> Loader Class Initialized
INFO - 2017-02-28 04:15:54 --> Helper loaded: form_helper
INFO - 2017-02-28 04:15:54 --> Helper loaded: url_helper
INFO - 2017-02-28 04:15:54 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:15:54 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:15:54 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:15:54 --> Template Class Initialized
INFO - 2017-02-28 04:15:54 --> Model Class Initialized
INFO - 2017-02-28 04:15:54 --> Controller Class Initialized
DEBUG - 2017-02-28 04:15:54 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:15:54 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:15:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:15:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 04:16:01 --> Config Class Initialized
INFO - 2017-02-28 04:16:01 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:16:01 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:16:01 --> Utf8 Class Initialized
INFO - 2017-02-28 04:16:01 --> URI Class Initialized
INFO - 2017-02-28 04:16:01 --> Router Class Initialized
INFO - 2017-02-28 04:16:01 --> Output Class Initialized
INFO - 2017-02-28 04:16:01 --> Security Class Initialized
DEBUG - 2017-02-28 04:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:16:01 --> Input Class Initialized
INFO - 2017-02-28 04:16:01 --> Language Class Initialized
INFO - 2017-02-28 04:16:01 --> Language Class Initialized
INFO - 2017-02-28 04:16:01 --> Config Class Initialized
INFO - 2017-02-28 04:16:01 --> Loader Class Initialized
INFO - 2017-02-28 04:16:01 --> Helper loaded: form_helper
INFO - 2017-02-28 04:16:01 --> Helper loaded: url_helper
INFO - 2017-02-28 04:16:01 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:16:01 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:16:01 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:16:01 --> Template Class Initialized
INFO - 2017-02-28 04:16:01 --> Model Class Initialized
INFO - 2017-02-28 04:16:01 --> Controller Class Initialized
DEBUG - 2017-02-28 04:16:01 --> Login MX_Controller Initialized
INFO - 2017-02-28 04:16:01 --> Helper loaded: cookie_helper
INFO - 2017-02-28 04:16:01 --> Form Validation Class Initialized
INFO - 2017-02-28 04:16:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-28 04:16:02 --> Config Class Initialized
INFO - 2017-02-28 04:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:16:02 --> Utf8 Class Initialized
INFO - 2017-02-28 04:16:02 --> URI Class Initialized
INFO - 2017-02-28 04:16:02 --> Router Class Initialized
INFO - 2017-02-28 04:16:02 --> Output Class Initialized
INFO - 2017-02-28 04:16:02 --> Security Class Initialized
DEBUG - 2017-02-28 04:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:16:02 --> Input Class Initialized
INFO - 2017-02-28 04:16:02 --> Language Class Initialized
INFO - 2017-02-28 04:16:02 --> Language Class Initialized
INFO - 2017-02-28 04:16:02 --> Config Class Initialized
INFO - 2017-02-28 04:16:02 --> Loader Class Initialized
INFO - 2017-02-28 04:16:02 --> Helper loaded: form_helper
INFO - 2017-02-28 04:16:02 --> Helper loaded: url_helper
INFO - 2017-02-28 04:16:02 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:16:02 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:16:02 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:16:02 --> Template Class Initialized
INFO - 2017-02-28 04:16:02 --> Model Class Initialized
INFO - 2017-02-28 04:16:02 --> Controller Class Initialized
DEBUG - 2017-02-28 04:16:02 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:16:02 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:16:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:16:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-28 04:16:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-02-28 04:16:02 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-28 04:16:02 --> Final output sent to browser
DEBUG - 2017-02-28 04:16:02 --> Total execution time: 0.0122
INFO - 2017-02-28 04:16:02 --> Config Class Initialized
INFO - 2017-02-28 04:16:02 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:16:02 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:16:02 --> Utf8 Class Initialized
INFO - 2017-02-28 04:16:02 --> URI Class Initialized
INFO - 2017-02-28 04:16:02 --> Router Class Initialized
INFO - 2017-02-28 04:16:02 --> Output Class Initialized
INFO - 2017-02-28 04:16:02 --> Security Class Initialized
DEBUG - 2017-02-28 04:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:16:02 --> Input Class Initialized
INFO - 2017-02-28 04:16:02 --> Language Class Initialized
INFO - 2017-02-28 04:16:02 --> Language Class Initialized
INFO - 2017-02-28 04:16:02 --> Config Class Initialized
INFO - 2017-02-28 04:16:02 --> Loader Class Initialized
INFO - 2017-02-28 04:16:02 --> Helper loaded: form_helper
INFO - 2017-02-28 04:16:02 --> Helper loaded: url_helper
INFO - 2017-02-28 04:16:02 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:16:02 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:16:02 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:16:02 --> Template Class Initialized
INFO - 2017-02-28 04:16:02 --> Model Class Initialized
INFO - 2017-02-28 04:16:02 --> Controller Class Initialized
DEBUG - 2017-02-28 04:16:02 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:16:02 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:16:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:16:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 04:16:10 --> Config Class Initialized
INFO - 2017-02-28 04:16:10 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:16:10 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:16:10 --> Utf8 Class Initialized
INFO - 2017-02-28 04:16:10 --> URI Class Initialized
INFO - 2017-02-28 04:16:10 --> Router Class Initialized
INFO - 2017-02-28 04:16:10 --> Output Class Initialized
INFO - 2017-02-28 04:16:10 --> Security Class Initialized
DEBUG - 2017-02-28 04:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:16:10 --> Input Class Initialized
INFO - 2017-02-28 04:16:10 --> Language Class Initialized
INFO - 2017-02-28 04:16:10 --> Language Class Initialized
INFO - 2017-02-28 04:16:10 --> Config Class Initialized
INFO - 2017-02-28 04:16:10 --> Loader Class Initialized
INFO - 2017-02-28 04:16:10 --> Helper loaded: form_helper
INFO - 2017-02-28 04:16:10 --> Helper loaded: url_helper
INFO - 2017-02-28 04:16:10 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:16:10 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:16:10 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:16:10 --> Template Class Initialized
INFO - 2017-02-28 04:16:10 --> Model Class Initialized
INFO - 2017-02-28 04:16:10 --> Controller Class Initialized
DEBUG - 2017-02-28 04:16:10 --> Login MX_Controller Initialized
INFO - 2017-02-28 04:16:10 --> Helper loaded: cookie_helper
INFO - 2017-02-28 04:16:10 --> Form Validation Class Initialized
INFO - 2017-02-28 04:16:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-28 04:16:11 --> Config Class Initialized
INFO - 2017-02-28 04:16:11 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:16:11 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:16:11 --> Utf8 Class Initialized
INFO - 2017-02-28 04:16:11 --> URI Class Initialized
INFO - 2017-02-28 04:16:11 --> Router Class Initialized
INFO - 2017-02-28 04:16:11 --> Output Class Initialized
INFO - 2017-02-28 04:16:11 --> Security Class Initialized
DEBUG - 2017-02-28 04:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:16:11 --> Input Class Initialized
INFO - 2017-02-28 04:16:11 --> Language Class Initialized
INFO - 2017-02-28 04:16:11 --> Language Class Initialized
INFO - 2017-02-28 04:16:11 --> Config Class Initialized
INFO - 2017-02-28 04:16:11 --> Loader Class Initialized
INFO - 2017-02-28 04:16:11 --> Helper loaded: form_helper
INFO - 2017-02-28 04:16:11 --> Helper loaded: url_helper
INFO - 2017-02-28 04:16:11 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:16:11 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:16:11 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:16:11 --> Template Class Initialized
INFO - 2017-02-28 04:16:11 --> Model Class Initialized
INFO - 2017-02-28 04:16:11 --> Controller Class Initialized
DEBUG - 2017-02-28 04:16:11 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:16:11 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:16:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:16:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-28 04:16:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-02-28 04:16:11 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-28 04:16:11 --> Final output sent to browser
DEBUG - 2017-02-28 04:16:11 --> Total execution time: 0.0214
INFO - 2017-02-28 04:16:11 --> Config Class Initialized
INFO - 2017-02-28 04:16:11 --> Hooks Class Initialized
DEBUG - 2017-02-28 04:16:11 --> UTF-8 Support Enabled
INFO - 2017-02-28 04:16:11 --> Utf8 Class Initialized
INFO - 2017-02-28 04:16:11 --> URI Class Initialized
INFO - 2017-02-28 04:16:11 --> Router Class Initialized
INFO - 2017-02-28 04:16:11 --> Output Class Initialized
INFO - 2017-02-28 04:16:11 --> Security Class Initialized
DEBUG - 2017-02-28 04:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 04:16:11 --> Input Class Initialized
INFO - 2017-02-28 04:16:11 --> Language Class Initialized
INFO - 2017-02-28 04:16:11 --> Language Class Initialized
INFO - 2017-02-28 04:16:11 --> Config Class Initialized
INFO - 2017-02-28 04:16:11 --> Loader Class Initialized
INFO - 2017-02-28 04:16:11 --> Helper loaded: form_helper
INFO - 2017-02-28 04:16:11 --> Helper loaded: url_helper
INFO - 2017-02-28 04:16:11 --> Helper loaded: utility_helper
INFO - 2017-02-28 04:16:11 --> Database Driver Class Initialized
DEBUG - 2017-02-28 04:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 04:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 04:16:11 --> User Agent Class Initialized
DEBUG - 2017-02-28 04:16:11 --> Template Class Initialized
INFO - 2017-02-28 04:16:11 --> Model Class Initialized
INFO - 2017-02-28 04:16:11 --> Controller Class Initialized
DEBUG - 2017-02-28 04:16:11 --> Pages MX_Controller Initialized
INFO - 2017-02-28 04:16:11 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 04:16:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 04:16:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 16:05:40 --> Config Class Initialized
INFO - 2017-02-28 16:05:40 --> Hooks Class Initialized
DEBUG - 2017-02-28 16:05:40 --> UTF-8 Support Enabled
INFO - 2017-02-28 16:05:40 --> Utf8 Class Initialized
INFO - 2017-02-28 16:05:40 --> URI Class Initialized
DEBUG - 2017-02-28 16:05:40 --> No URI present. Default controller set.
INFO - 2017-02-28 16:05:40 --> Router Class Initialized
INFO - 2017-02-28 16:05:40 --> Output Class Initialized
INFO - 2017-02-28 16:05:40 --> Security Class Initialized
DEBUG - 2017-02-28 16:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 16:05:40 --> Input Class Initialized
INFO - 2017-02-28 16:05:40 --> Language Class Initialized
INFO - 2017-02-28 16:05:40 --> Language Class Initialized
INFO - 2017-02-28 16:05:40 --> Config Class Initialized
INFO - 2017-02-28 16:05:40 --> Loader Class Initialized
INFO - 2017-02-28 16:05:40 --> Helper loaded: form_helper
INFO - 2017-02-28 16:05:40 --> Helper loaded: url_helper
INFO - 2017-02-28 16:05:40 --> Helper loaded: utility_helper
INFO - 2017-02-28 16:05:40 --> Database Driver Class Initialized
DEBUG - 2017-02-28 16:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 16:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 16:05:40 --> User Agent Class Initialized
DEBUG - 2017-02-28 16:05:40 --> Template Class Initialized
INFO - 2017-02-28 16:05:40 --> Model Class Initialized
INFO - 2017-02-28 16:05:40 --> Controller Class Initialized
DEBUG - 2017-02-28 16:05:40 --> Pages MX_Controller Initialized
INFO - 2017-02-28 16:05:40 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 16:05:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 16:05:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-28 16:05:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-28 16:05:40 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-28 16:05:40 --> Final output sent to browser
DEBUG - 2017-02-28 16:05:40 --> Total execution time: 0.4362
INFO - 2017-02-28 19:20:27 --> Config Class Initialized
INFO - 2017-02-28 19:20:27 --> Hooks Class Initialized
DEBUG - 2017-02-28 19:20:27 --> UTF-8 Support Enabled
INFO - 2017-02-28 19:20:27 --> Utf8 Class Initialized
INFO - 2017-02-28 19:20:27 --> URI Class Initialized
DEBUG - 2017-02-28 19:20:27 --> No URI present. Default controller set.
INFO - 2017-02-28 19:20:27 --> Router Class Initialized
INFO - 2017-02-28 19:20:27 --> Output Class Initialized
INFO - 2017-02-28 19:20:27 --> Security Class Initialized
DEBUG - 2017-02-28 19:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 19:20:27 --> Input Class Initialized
INFO - 2017-02-28 19:20:27 --> Language Class Initialized
INFO - 2017-02-28 19:20:27 --> Language Class Initialized
INFO - 2017-02-28 19:20:27 --> Config Class Initialized
INFO - 2017-02-28 19:20:27 --> Loader Class Initialized
INFO - 2017-02-28 19:20:27 --> Helper loaded: form_helper
INFO - 2017-02-28 19:20:27 --> Helper loaded: url_helper
INFO - 2017-02-28 19:20:27 --> Helper loaded: utility_helper
INFO - 2017-02-28 19:20:28 --> Database Driver Class Initialized
DEBUG - 2017-02-28 19:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 19:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 19:20:28 --> User Agent Class Initialized
DEBUG - 2017-02-28 19:20:28 --> Template Class Initialized
INFO - 2017-02-28 19:20:28 --> Model Class Initialized
INFO - 2017-02-28 19:20:28 --> Controller Class Initialized
DEBUG - 2017-02-28 19:20:28 --> Pages MX_Controller Initialized
INFO - 2017-02-28 19:20:28 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 19:20:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 19:20:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-28 19:20:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-28 19:20:28 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-28 19:20:28 --> Final output sent to browser
DEBUG - 2017-02-28 19:20:28 --> Total execution time: 0.4141
INFO - 2017-02-28 19:20:32 --> Config Class Initialized
INFO - 2017-02-28 19:20:32 --> Hooks Class Initialized
DEBUG - 2017-02-28 19:20:32 --> UTF-8 Support Enabled
INFO - 2017-02-28 19:20:32 --> Utf8 Class Initialized
INFO - 2017-02-28 19:20:32 --> URI Class Initialized
INFO - 2017-02-28 19:20:32 --> Router Class Initialized
INFO - 2017-02-28 19:20:32 --> Output Class Initialized
INFO - 2017-02-28 19:20:32 --> Security Class Initialized
DEBUG - 2017-02-28 19:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 19:20:32 --> Input Class Initialized
INFO - 2017-02-28 19:20:32 --> Language Class Initialized
INFO - 2017-02-28 19:20:32 --> Language Class Initialized
INFO - 2017-02-28 19:20:32 --> Config Class Initialized
INFO - 2017-02-28 19:20:32 --> Loader Class Initialized
INFO - 2017-02-28 19:20:32 --> Helper loaded: form_helper
INFO - 2017-02-28 19:20:32 --> Helper loaded: url_helper
INFO - 2017-02-28 19:20:32 --> Helper loaded: utility_helper
INFO - 2017-02-28 19:20:32 --> Database Driver Class Initialized
DEBUG - 2017-02-28 19:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 19:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 19:20:32 --> User Agent Class Initialized
DEBUG - 2017-02-28 19:20:32 --> Template Class Initialized
INFO - 2017-02-28 19:20:32 --> Model Class Initialized
INFO - 2017-02-28 19:20:32 --> Controller Class Initialized
DEBUG - 2017-02-28 19:20:32 --> Pages MX_Controller Initialized
INFO - 2017-02-28 19:20:32 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 19:20:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 19:20:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 19:20:32 --> Config Class Initialized
INFO - 2017-02-28 19:20:32 --> Hooks Class Initialized
DEBUG - 2017-02-28 19:20:32 --> UTF-8 Support Enabled
INFO - 2017-02-28 19:20:32 --> Utf8 Class Initialized
INFO - 2017-02-28 19:20:32 --> URI Class Initialized
INFO - 2017-02-28 19:20:32 --> Router Class Initialized
INFO - 2017-02-28 19:20:32 --> Output Class Initialized
INFO - 2017-02-28 19:20:32 --> Security Class Initialized
DEBUG - 2017-02-28 19:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 19:20:32 --> Input Class Initialized
INFO - 2017-02-28 19:20:32 --> Language Class Initialized
INFO - 2017-02-28 19:20:32 --> Language Class Initialized
INFO - 2017-02-28 19:20:32 --> Config Class Initialized
INFO - 2017-02-28 19:20:32 --> Loader Class Initialized
INFO - 2017-02-28 19:20:32 --> Helper loaded: form_helper
INFO - 2017-02-28 19:20:32 --> Helper loaded: url_helper
INFO - 2017-02-28 19:20:32 --> Helper loaded: utility_helper
INFO - 2017-02-28 19:20:32 --> Database Driver Class Initialized
DEBUG - 2017-02-28 19:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 19:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 19:20:32 --> User Agent Class Initialized
DEBUG - 2017-02-28 19:20:32 --> Template Class Initialized
INFO - 2017-02-28 19:20:32 --> Model Class Initialized
INFO - 2017-02-28 19:20:32 --> Controller Class Initialized
DEBUG - 2017-02-28 19:20:32 --> Pages MX_Controller Initialized
INFO - 2017-02-28 19:20:32 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 19:20:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 19:20:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 19:20:55 --> Config Class Initialized
INFO - 2017-02-28 19:20:55 --> Hooks Class Initialized
DEBUG - 2017-02-28 19:20:55 --> UTF-8 Support Enabled
INFO - 2017-02-28 19:20:55 --> Utf8 Class Initialized
INFO - 2017-02-28 19:20:55 --> URI Class Initialized
INFO - 2017-02-28 19:20:55 --> Router Class Initialized
INFO - 2017-02-28 19:20:55 --> Output Class Initialized
INFO - 2017-02-28 19:20:55 --> Security Class Initialized
DEBUG - 2017-02-28 19:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 19:20:55 --> Input Class Initialized
INFO - 2017-02-28 19:20:55 --> Language Class Initialized
INFO - 2017-02-28 19:20:55 --> Language Class Initialized
INFO - 2017-02-28 19:20:55 --> Config Class Initialized
INFO - 2017-02-28 19:20:55 --> Loader Class Initialized
INFO - 2017-02-28 19:20:55 --> Helper loaded: form_helper
INFO - 2017-02-28 19:20:55 --> Helper loaded: url_helper
INFO - 2017-02-28 19:20:55 --> Helper loaded: utility_helper
INFO - 2017-02-28 19:20:55 --> Database Driver Class Initialized
DEBUG - 2017-02-28 19:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 19:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 19:20:55 --> User Agent Class Initialized
DEBUG - 2017-02-28 19:20:55 --> Template Class Initialized
INFO - 2017-02-28 19:20:55 --> Model Class Initialized
INFO - 2017-02-28 19:20:55 --> Controller Class Initialized
DEBUG - 2017-02-28 19:20:55 --> Pages MX_Controller Initialized
INFO - 2017-02-28 19:20:55 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 19:20:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 19:20:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-28 19:20:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-02-28 19:20:55 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-28 19:20:55 --> Final output sent to browser
DEBUG - 2017-02-28 19:20:55 --> Total execution time: 0.0260
INFO - 2017-02-28 19:20:56 --> Config Class Initialized
INFO - 2017-02-28 19:20:56 --> Hooks Class Initialized
DEBUG - 2017-02-28 19:20:56 --> UTF-8 Support Enabled
INFO - 2017-02-28 19:20:56 --> Utf8 Class Initialized
INFO - 2017-02-28 19:20:56 --> URI Class Initialized
INFO - 2017-02-28 19:20:56 --> Router Class Initialized
INFO - 2017-02-28 19:20:56 --> Output Class Initialized
INFO - 2017-02-28 19:20:56 --> Security Class Initialized
DEBUG - 2017-02-28 19:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 19:20:56 --> Input Class Initialized
INFO - 2017-02-28 19:20:56 --> Language Class Initialized
INFO - 2017-02-28 19:20:56 --> Language Class Initialized
INFO - 2017-02-28 19:20:56 --> Config Class Initialized
INFO - 2017-02-28 19:20:56 --> Loader Class Initialized
INFO - 2017-02-28 19:20:56 --> Helper loaded: form_helper
INFO - 2017-02-28 19:20:56 --> Helper loaded: url_helper
INFO - 2017-02-28 19:20:56 --> Helper loaded: utility_helper
INFO - 2017-02-28 19:20:56 --> Database Driver Class Initialized
DEBUG - 2017-02-28 19:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 19:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 19:20:56 --> User Agent Class Initialized
DEBUG - 2017-02-28 19:20:56 --> Template Class Initialized
INFO - 2017-02-28 19:20:56 --> Model Class Initialized
INFO - 2017-02-28 19:20:56 --> Controller Class Initialized
DEBUG - 2017-02-28 19:20:56 --> Pages MX_Controller Initialized
INFO - 2017-02-28 19:20:56 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 19:20:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 19:20:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 19:20:59 --> Config Class Initialized
INFO - 2017-02-28 19:20:59 --> Hooks Class Initialized
DEBUG - 2017-02-28 19:20:59 --> UTF-8 Support Enabled
INFO - 2017-02-28 19:20:59 --> Utf8 Class Initialized
INFO - 2017-02-28 19:20:59 --> URI Class Initialized
INFO - 2017-02-28 19:20:59 --> Router Class Initialized
INFO - 2017-02-28 19:20:59 --> Output Class Initialized
INFO - 2017-02-28 19:20:59 --> Security Class Initialized
DEBUG - 2017-02-28 19:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 19:20:59 --> Input Class Initialized
INFO - 2017-02-28 19:20:59 --> Language Class Initialized
INFO - 2017-02-28 19:20:59 --> Language Class Initialized
INFO - 2017-02-28 19:20:59 --> Config Class Initialized
INFO - 2017-02-28 19:20:59 --> Loader Class Initialized
INFO - 2017-02-28 19:20:59 --> Helper loaded: form_helper
INFO - 2017-02-28 19:20:59 --> Helper loaded: url_helper
INFO - 2017-02-28 19:20:59 --> Helper loaded: utility_helper
INFO - 2017-02-28 19:20:59 --> Database Driver Class Initialized
DEBUG - 2017-02-28 19:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 19:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 19:20:59 --> User Agent Class Initialized
DEBUG - 2017-02-28 19:20:59 --> Template Class Initialized
INFO - 2017-02-28 19:20:59 --> Model Class Initialized
INFO - 2017-02-28 19:20:59 --> Controller Class Initialized
DEBUG - 2017-02-28 19:20:59 --> Login MX_Controller Initialized
INFO - 2017-02-28 19:20:59 --> Helper loaded: cookie_helper
INFO - 2017-02-28 19:20:59 --> Form Validation Class Initialized
INFO - 2017-02-28 19:20:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-28 19:21:00 --> Config Class Initialized
INFO - 2017-02-28 19:21:00 --> Hooks Class Initialized
DEBUG - 2017-02-28 19:21:00 --> UTF-8 Support Enabled
INFO - 2017-02-28 19:21:00 --> Utf8 Class Initialized
INFO - 2017-02-28 19:21:00 --> URI Class Initialized
INFO - 2017-02-28 19:21:00 --> Router Class Initialized
INFO - 2017-02-28 19:21:00 --> Output Class Initialized
INFO - 2017-02-28 19:21:00 --> Security Class Initialized
DEBUG - 2017-02-28 19:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 19:21:00 --> Input Class Initialized
INFO - 2017-02-28 19:21:00 --> Language Class Initialized
INFO - 2017-02-28 19:21:00 --> Language Class Initialized
INFO - 2017-02-28 19:21:00 --> Config Class Initialized
INFO - 2017-02-28 19:21:00 --> Loader Class Initialized
INFO - 2017-02-28 19:21:00 --> Helper loaded: form_helper
INFO - 2017-02-28 19:21:00 --> Helper loaded: url_helper
INFO - 2017-02-28 19:21:00 --> Helper loaded: utility_helper
INFO - 2017-02-28 19:21:00 --> Database Driver Class Initialized
DEBUG - 2017-02-28 19:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 19:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 19:21:00 --> User Agent Class Initialized
DEBUG - 2017-02-28 19:21:00 --> Template Class Initialized
INFO - 2017-02-28 19:21:00 --> Model Class Initialized
INFO - 2017-02-28 19:21:00 --> Controller Class Initialized
DEBUG - 2017-02-28 19:21:00 --> Pages MX_Controller Initialized
INFO - 2017-02-28 19:21:00 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 19:21:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 19:21:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-28 19:21:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-02-28 19:21:00 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-28 19:21:00 --> Final output sent to browser
DEBUG - 2017-02-28 19:21:00 --> Total execution time: 0.0136
INFO - 2017-02-28 19:21:00 --> Config Class Initialized
INFO - 2017-02-28 19:21:00 --> Hooks Class Initialized
DEBUG - 2017-02-28 19:21:00 --> UTF-8 Support Enabled
INFO - 2017-02-28 19:21:00 --> Utf8 Class Initialized
INFO - 2017-02-28 19:21:00 --> URI Class Initialized
INFO - 2017-02-28 19:21:00 --> Router Class Initialized
INFO - 2017-02-28 19:21:00 --> Output Class Initialized
INFO - 2017-02-28 19:21:00 --> Security Class Initialized
DEBUG - 2017-02-28 19:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 19:21:00 --> Input Class Initialized
INFO - 2017-02-28 19:21:00 --> Language Class Initialized
INFO - 2017-02-28 19:21:00 --> Language Class Initialized
INFO - 2017-02-28 19:21:00 --> Config Class Initialized
INFO - 2017-02-28 19:21:00 --> Loader Class Initialized
INFO - 2017-02-28 19:21:00 --> Helper loaded: form_helper
INFO - 2017-02-28 19:21:00 --> Helper loaded: url_helper
INFO - 2017-02-28 19:21:00 --> Helper loaded: utility_helper
INFO - 2017-02-28 19:21:00 --> Database Driver Class Initialized
DEBUG - 2017-02-28 19:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 19:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 19:21:00 --> User Agent Class Initialized
DEBUG - 2017-02-28 19:21:00 --> Template Class Initialized
INFO - 2017-02-28 19:21:00 --> Model Class Initialized
INFO - 2017-02-28 19:21:00 --> Controller Class Initialized
DEBUG - 2017-02-28 19:21:00 --> Pages MX_Controller Initialized
INFO - 2017-02-28 19:21:00 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 19:21:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 19:21:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 19:32:08 --> Config Class Initialized
INFO - 2017-02-28 19:32:08 --> Hooks Class Initialized
DEBUG - 2017-02-28 19:32:08 --> UTF-8 Support Enabled
INFO - 2017-02-28 19:32:08 --> Utf8 Class Initialized
INFO - 2017-02-28 19:32:08 --> URI Class Initialized
DEBUG - 2017-02-28 19:32:08 --> No URI present. Default controller set.
INFO - 2017-02-28 19:32:08 --> Router Class Initialized
INFO - 2017-02-28 19:32:08 --> Output Class Initialized
INFO - 2017-02-28 19:32:08 --> Security Class Initialized
DEBUG - 2017-02-28 19:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 19:32:08 --> Input Class Initialized
INFO - 2017-02-28 19:32:08 --> Language Class Initialized
INFO - 2017-02-28 19:32:08 --> Language Class Initialized
INFO - 2017-02-28 19:32:08 --> Config Class Initialized
INFO - 2017-02-28 19:32:08 --> Loader Class Initialized
INFO - 2017-02-28 19:32:08 --> Helper loaded: form_helper
INFO - 2017-02-28 19:32:08 --> Helper loaded: url_helper
INFO - 2017-02-28 19:32:08 --> Helper loaded: utility_helper
INFO - 2017-02-28 19:32:08 --> Database Driver Class Initialized
DEBUG - 2017-02-28 19:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 19:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 19:32:08 --> User Agent Class Initialized
DEBUG - 2017-02-28 19:32:08 --> Template Class Initialized
INFO - 2017-02-28 19:32:08 --> Model Class Initialized
INFO - 2017-02-28 19:32:08 --> Controller Class Initialized
DEBUG - 2017-02-28 19:32:08 --> Pages MX_Controller Initialized
INFO - 2017-02-28 19:32:08 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 19:32:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 19:32:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-28 19:32:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-28 19:32:08 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-28 19:32:08 --> Final output sent to browser
DEBUG - 2017-02-28 19:32:08 --> Total execution time: 0.0609
INFO - 2017-02-28 19:32:08 --> Config Class Initialized
INFO - 2017-02-28 19:32:08 --> Hooks Class Initialized
DEBUG - 2017-02-28 19:32:08 --> UTF-8 Support Enabled
INFO - 2017-02-28 19:32:08 --> Utf8 Class Initialized
INFO - 2017-02-28 19:32:08 --> URI Class Initialized
INFO - 2017-02-28 19:32:08 --> Router Class Initialized
INFO - 2017-02-28 19:32:08 --> Output Class Initialized
INFO - 2017-02-28 19:32:08 --> Security Class Initialized
DEBUG - 2017-02-28 19:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 19:32:08 --> Input Class Initialized
INFO - 2017-02-28 19:32:08 --> Language Class Initialized
INFO - 2017-02-28 19:32:08 --> Language Class Initialized
INFO - 2017-02-28 19:32:08 --> Config Class Initialized
INFO - 2017-02-28 19:32:08 --> Loader Class Initialized
INFO - 2017-02-28 19:32:08 --> Helper loaded: form_helper
INFO - 2017-02-28 19:32:08 --> Helper loaded: url_helper
INFO - 2017-02-28 19:32:08 --> Helper loaded: utility_helper
INFO - 2017-02-28 19:32:08 --> Database Driver Class Initialized
DEBUG - 2017-02-28 19:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 19:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 19:32:08 --> User Agent Class Initialized
DEBUG - 2017-02-28 19:32:08 --> Template Class Initialized
INFO - 2017-02-28 19:32:08 --> Model Class Initialized
INFO - 2017-02-28 19:32:08 --> Controller Class Initialized
DEBUG - 2017-02-28 19:32:08 --> Pages MX_Controller Initialized
INFO - 2017-02-28 19:32:08 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 19:32:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 19:32:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 19:32:09 --> Config Class Initialized
INFO - 2017-02-28 19:32:09 --> Hooks Class Initialized
DEBUG - 2017-02-28 19:32:09 --> UTF-8 Support Enabled
INFO - 2017-02-28 19:32:09 --> Utf8 Class Initialized
INFO - 2017-02-28 19:32:09 --> URI Class Initialized
INFO - 2017-02-28 19:32:09 --> Router Class Initialized
INFO - 2017-02-28 19:32:09 --> Output Class Initialized
INFO - 2017-02-28 19:32:09 --> Security Class Initialized
DEBUG - 2017-02-28 19:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 19:32:09 --> Input Class Initialized
INFO - 2017-02-28 19:32:09 --> Language Class Initialized
INFO - 2017-02-28 19:32:09 --> Language Class Initialized
INFO - 2017-02-28 19:32:09 --> Config Class Initialized
INFO - 2017-02-28 19:32:09 --> Loader Class Initialized
INFO - 2017-02-28 19:32:09 --> Helper loaded: form_helper
INFO - 2017-02-28 19:32:09 --> Helper loaded: url_helper
INFO - 2017-02-28 19:32:09 --> Helper loaded: utility_helper
INFO - 2017-02-28 19:32:09 --> Database Driver Class Initialized
DEBUG - 2017-02-28 19:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 19:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 19:32:09 --> User Agent Class Initialized
DEBUG - 2017-02-28 19:32:09 --> Template Class Initialized
INFO - 2017-02-28 19:32:09 --> Model Class Initialized
INFO - 2017-02-28 19:32:09 --> Controller Class Initialized
DEBUG - 2017-02-28 19:32:09 --> Pages MX_Controller Initialized
INFO - 2017-02-28 19:32:09 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 19:32:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 19:32:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 19:34:09 --> Config Class Initialized
INFO - 2017-02-28 19:34:09 --> Hooks Class Initialized
DEBUG - 2017-02-28 19:34:09 --> UTF-8 Support Enabled
INFO - 2017-02-28 19:34:09 --> Utf8 Class Initialized
INFO - 2017-02-28 19:34:09 --> URI Class Initialized
INFO - 2017-02-28 19:34:09 --> Router Class Initialized
INFO - 2017-02-28 19:34:09 --> Output Class Initialized
INFO - 2017-02-28 19:34:09 --> Security Class Initialized
DEBUG - 2017-02-28 19:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 19:34:09 --> Input Class Initialized
INFO - 2017-02-28 19:34:09 --> Language Class Initialized
INFO - 2017-02-28 19:34:09 --> Language Class Initialized
INFO - 2017-02-28 19:34:09 --> Config Class Initialized
INFO - 2017-02-28 19:34:09 --> Loader Class Initialized
INFO - 2017-02-28 19:34:09 --> Helper loaded: form_helper
INFO - 2017-02-28 19:34:09 --> Helper loaded: url_helper
INFO - 2017-02-28 19:34:09 --> Helper loaded: utility_helper
INFO - 2017-02-28 19:34:09 --> Database Driver Class Initialized
DEBUG - 2017-02-28 19:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 19:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 19:34:09 --> User Agent Class Initialized
DEBUG - 2017-02-28 19:34:09 --> Template Class Initialized
INFO - 2017-02-28 19:34:09 --> Model Class Initialized
INFO - 2017-02-28 19:34:09 --> Controller Class Initialized
DEBUG - 2017-02-28 19:34:09 --> Pages MX_Controller Initialized
INFO - 2017-02-28 19:34:09 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 19:34:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 19:34:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 19:41:21 --> Config Class Initialized
INFO - 2017-02-28 19:41:21 --> Hooks Class Initialized
DEBUG - 2017-02-28 19:41:21 --> UTF-8 Support Enabled
INFO - 2017-02-28 19:41:21 --> Utf8 Class Initialized
INFO - 2017-02-28 19:41:21 --> URI Class Initialized
INFO - 2017-02-28 19:41:21 --> Router Class Initialized
INFO - 2017-02-28 19:41:21 --> Output Class Initialized
INFO - 2017-02-28 19:41:21 --> Security Class Initialized
DEBUG - 2017-02-28 19:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 19:41:21 --> Input Class Initialized
INFO - 2017-02-28 19:41:21 --> Language Class Initialized
INFO - 2017-02-28 19:41:21 --> Language Class Initialized
INFO - 2017-02-28 19:41:21 --> Config Class Initialized
INFO - 2017-02-28 19:41:21 --> Loader Class Initialized
INFO - 2017-02-28 19:41:21 --> Helper loaded: form_helper
INFO - 2017-02-28 19:41:21 --> Helper loaded: url_helper
INFO - 2017-02-28 19:41:21 --> Helper loaded: utility_helper
INFO - 2017-02-28 19:41:21 --> Database Driver Class Initialized
DEBUG - 2017-02-28 19:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 19:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 19:41:22 --> User Agent Class Initialized
DEBUG - 2017-02-28 19:41:22 --> Template Class Initialized
INFO - 2017-02-28 19:41:22 --> Model Class Initialized
INFO - 2017-02-28 19:41:22 --> Controller Class Initialized
DEBUG - 2017-02-28 19:41:22 --> Pages MX_Controller Initialized
INFO - 2017-02-28 19:41:22 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 19:41:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 19:41:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-28 19:41:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-02-28 19:41:22 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-28 19:41:22 --> Final output sent to browser
DEBUG - 2017-02-28 19:41:22 --> Total execution time: 0.0430
INFO - 2017-02-28 19:41:22 --> Config Class Initialized
INFO - 2017-02-28 19:41:22 --> Hooks Class Initialized
DEBUG - 2017-02-28 19:41:22 --> UTF-8 Support Enabled
INFO - 2017-02-28 19:41:22 --> Utf8 Class Initialized
INFO - 2017-02-28 19:41:22 --> URI Class Initialized
INFO - 2017-02-28 19:41:22 --> Router Class Initialized
INFO - 2017-02-28 19:41:22 --> Output Class Initialized
INFO - 2017-02-28 19:41:22 --> Security Class Initialized
DEBUG - 2017-02-28 19:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 19:41:22 --> Input Class Initialized
INFO - 2017-02-28 19:41:22 --> Language Class Initialized
INFO - 2017-02-28 19:41:22 --> Language Class Initialized
INFO - 2017-02-28 19:41:22 --> Config Class Initialized
INFO - 2017-02-28 19:41:22 --> Loader Class Initialized
INFO - 2017-02-28 19:41:22 --> Helper loaded: form_helper
INFO - 2017-02-28 19:41:22 --> Helper loaded: url_helper
INFO - 2017-02-28 19:41:22 --> Helper loaded: utility_helper
INFO - 2017-02-28 19:41:22 --> Database Driver Class Initialized
DEBUG - 2017-02-28 19:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 19:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 19:41:22 --> User Agent Class Initialized
DEBUG - 2017-02-28 19:41:22 --> Template Class Initialized
INFO - 2017-02-28 19:41:22 --> Model Class Initialized
INFO - 2017-02-28 19:41:22 --> Controller Class Initialized
DEBUG - 2017-02-28 19:41:22 --> Pages MX_Controller Initialized
INFO - 2017-02-28 19:41:22 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 19:41:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 19:41:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 19:47:25 --> Config Class Initialized
INFO - 2017-02-28 19:47:25 --> Hooks Class Initialized
DEBUG - 2017-02-28 19:47:25 --> UTF-8 Support Enabled
INFO - 2017-02-28 19:47:25 --> Utf8 Class Initialized
INFO - 2017-02-28 19:47:25 --> URI Class Initialized
DEBUG - 2017-02-28 19:47:25 --> No URI present. Default controller set.
INFO - 2017-02-28 19:47:25 --> Router Class Initialized
INFO - 2017-02-28 19:47:25 --> Output Class Initialized
INFO - 2017-02-28 19:47:25 --> Security Class Initialized
DEBUG - 2017-02-28 19:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 19:47:25 --> Input Class Initialized
INFO - 2017-02-28 19:47:25 --> Language Class Initialized
INFO - 2017-02-28 19:47:25 --> Language Class Initialized
INFO - 2017-02-28 19:47:25 --> Config Class Initialized
INFO - 2017-02-28 19:47:25 --> Loader Class Initialized
INFO - 2017-02-28 19:47:25 --> Helper loaded: form_helper
INFO - 2017-02-28 19:47:25 --> Helper loaded: url_helper
INFO - 2017-02-28 19:47:25 --> Helper loaded: utility_helper
INFO - 2017-02-28 19:47:25 --> Database Driver Class Initialized
DEBUG - 2017-02-28 19:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 19:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 19:47:25 --> User Agent Class Initialized
DEBUG - 2017-02-28 19:47:25 --> Template Class Initialized
INFO - 2017-02-28 19:47:25 --> Model Class Initialized
INFO - 2017-02-28 19:47:25 --> Controller Class Initialized
DEBUG - 2017-02-28 19:47:25 --> Pages MX_Controller Initialized
INFO - 2017-02-28 19:47:25 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 19:47:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 19:47:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-28 19:47:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-28 19:47:25 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-28 19:47:25 --> Final output sent to browser
DEBUG - 2017-02-28 19:47:25 --> Total execution time: 0.0654
INFO - 2017-02-28 19:47:28 --> Config Class Initialized
INFO - 2017-02-28 19:47:28 --> Hooks Class Initialized
DEBUG - 2017-02-28 19:47:28 --> UTF-8 Support Enabled
INFO - 2017-02-28 19:47:28 --> Utf8 Class Initialized
INFO - 2017-02-28 19:47:28 --> URI Class Initialized
INFO - 2017-02-28 19:47:28 --> Router Class Initialized
INFO - 2017-02-28 19:47:28 --> Output Class Initialized
INFO - 2017-02-28 19:47:28 --> Security Class Initialized
DEBUG - 2017-02-28 19:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 19:47:28 --> Input Class Initialized
INFO - 2017-02-28 19:47:28 --> Language Class Initialized
INFO - 2017-02-28 19:47:28 --> Language Class Initialized
INFO - 2017-02-28 19:47:28 --> Config Class Initialized
INFO - 2017-02-28 19:47:28 --> Loader Class Initialized
INFO - 2017-02-28 19:47:28 --> Helper loaded: form_helper
INFO - 2017-02-28 19:47:28 --> Helper loaded: url_helper
INFO - 2017-02-28 19:47:28 --> Helper loaded: utility_helper
INFO - 2017-02-28 19:47:28 --> Database Driver Class Initialized
DEBUG - 2017-02-28 19:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 19:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 19:47:28 --> User Agent Class Initialized
DEBUG - 2017-02-28 19:47:28 --> Template Class Initialized
INFO - 2017-02-28 19:47:28 --> Model Class Initialized
INFO - 2017-02-28 19:47:28 --> Controller Class Initialized
DEBUG - 2017-02-28 19:47:28 --> Pages MX_Controller Initialized
INFO - 2017-02-28 19:47:28 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 19:47:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 19:47:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-28 19:47:28 --> Config Class Initialized
INFO - 2017-02-28 19:47:28 --> Hooks Class Initialized
DEBUG - 2017-02-28 19:47:28 --> UTF-8 Support Enabled
INFO - 2017-02-28 19:47:28 --> Utf8 Class Initialized
INFO - 2017-02-28 19:47:28 --> URI Class Initialized
INFO - 2017-02-28 19:47:28 --> Router Class Initialized
INFO - 2017-02-28 19:47:28 --> Output Class Initialized
INFO - 2017-02-28 19:47:28 --> Security Class Initialized
DEBUG - 2017-02-28 19:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-28 19:47:28 --> Input Class Initialized
INFO - 2017-02-28 19:47:28 --> Language Class Initialized
INFO - 2017-02-28 19:47:28 --> Language Class Initialized
INFO - 2017-02-28 19:47:28 --> Config Class Initialized
INFO - 2017-02-28 19:47:28 --> Loader Class Initialized
INFO - 2017-02-28 19:47:28 --> Helper loaded: form_helper
INFO - 2017-02-28 19:47:28 --> Helper loaded: url_helper
INFO - 2017-02-28 19:47:28 --> Helper loaded: utility_helper
INFO - 2017-02-28 19:47:28 --> Database Driver Class Initialized
DEBUG - 2017-02-28 19:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-28 19:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-28 19:47:28 --> User Agent Class Initialized
DEBUG - 2017-02-28 19:47:28 --> Template Class Initialized
INFO - 2017-02-28 19:47:28 --> Model Class Initialized
INFO - 2017-02-28 19:47:28 --> Controller Class Initialized
DEBUG - 2017-02-28 19:47:28 --> Pages MX_Controller Initialized
INFO - 2017-02-28 19:47:28 --> Helper loaded: cookie_helper
DEBUG - 2017-02-28 19:47:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-28 19:47:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
