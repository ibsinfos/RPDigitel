<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-26 00:52:11 --> Config Class Initialized
INFO - 2017-02-26 00:52:11 --> Hooks Class Initialized
DEBUG - 2017-02-26 00:52:11 --> UTF-8 Support Enabled
INFO - 2017-02-26 00:52:11 --> Utf8 Class Initialized
INFO - 2017-02-26 00:52:11 --> URI Class Initialized
INFO - 2017-02-26 00:52:11 --> Router Class Initialized
INFO - 2017-02-26 00:52:11 --> Output Class Initialized
INFO - 2017-02-26 00:52:11 --> Security Class Initialized
DEBUG - 2017-02-26 00:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-26 00:52:11 --> Input Class Initialized
INFO - 2017-02-26 00:52:11 --> Language Class Initialized
INFO - 2017-02-26 00:52:11 --> Language Class Initialized
INFO - 2017-02-26 00:52:11 --> Config Class Initialized
INFO - 2017-02-26 00:52:11 --> Loader Class Initialized
INFO - 2017-02-26 00:52:11 --> Helper loaded: form_helper
INFO - 2017-02-26 00:52:11 --> Helper loaded: url_helper
INFO - 2017-02-26 00:52:11 --> Helper loaded: utility_helper
INFO - 2017-02-26 00:52:11 --> Database Driver Class Initialized
DEBUG - 2017-02-26 00:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-26 00:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-26 00:52:11 --> User Agent Class Initialized
DEBUG - 2017-02-26 00:52:11 --> Template Class Initialized
INFO - 2017-02-26 00:52:11 --> Model Class Initialized
INFO - 2017-02-26 00:52:11 --> Controller Class Initialized
DEBUG - 2017-02-26 00:52:11 --> Pages MX_Controller Initialized
INFO - 2017-02-26 00:52:11 --> Helper loaded: cookie_helper
DEBUG - 2017-02-26 00:52:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-26 00:52:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-26 00:52:14 --> Config Class Initialized
INFO - 2017-02-26 00:52:14 --> Hooks Class Initialized
DEBUG - 2017-02-26 00:52:14 --> UTF-8 Support Enabled
INFO - 2017-02-26 00:52:14 --> Utf8 Class Initialized
INFO - 2017-02-26 00:52:14 --> URI Class Initialized
INFO - 2017-02-26 00:52:14 --> Router Class Initialized
INFO - 2017-02-26 00:52:14 --> Output Class Initialized
INFO - 2017-02-26 00:52:14 --> Security Class Initialized
DEBUG - 2017-02-26 00:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-26 00:52:14 --> Input Class Initialized
INFO - 2017-02-26 00:52:14 --> Language Class Initialized
INFO - 2017-02-26 00:52:14 --> Language Class Initialized
INFO - 2017-02-26 00:52:14 --> Config Class Initialized
INFO - 2017-02-26 00:52:14 --> Loader Class Initialized
INFO - 2017-02-26 00:52:14 --> Helper loaded: form_helper
INFO - 2017-02-26 00:52:14 --> Helper loaded: url_helper
INFO - 2017-02-26 00:52:14 --> Helper loaded: utility_helper
INFO - 2017-02-26 00:52:14 --> Database Driver Class Initialized
DEBUG - 2017-02-26 00:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-26 00:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-26 00:52:14 --> User Agent Class Initialized
DEBUG - 2017-02-26 00:52:14 --> Template Class Initialized
INFO - 2017-02-26 00:52:14 --> Model Class Initialized
INFO - 2017-02-26 00:52:14 --> Controller Class Initialized
DEBUG - 2017-02-26 00:52:14 --> Pages MX_Controller Initialized
INFO - 2017-02-26 00:52:14 --> Helper loaded: cookie_helper
DEBUG - 2017-02-26 00:52:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-26 00:52:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-26 00:52:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-02-26 00:52:14 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-26 00:52:14 --> Final output sent to browser
DEBUG - 2017-02-26 00:52:14 --> Total execution time: 0.0229
INFO - 2017-02-26 00:52:14 --> Config Class Initialized
INFO - 2017-02-26 00:52:14 --> Hooks Class Initialized
DEBUG - 2017-02-26 00:52:14 --> UTF-8 Support Enabled
INFO - 2017-02-26 00:52:14 --> Utf8 Class Initialized
INFO - 2017-02-26 00:52:14 --> URI Class Initialized
INFO - 2017-02-26 00:52:14 --> Router Class Initialized
INFO - 2017-02-26 00:52:14 --> Output Class Initialized
INFO - 2017-02-26 00:52:14 --> Security Class Initialized
DEBUG - 2017-02-26 00:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-26 00:52:14 --> Input Class Initialized
INFO - 2017-02-26 00:52:14 --> Language Class Initialized
INFO - 2017-02-26 00:52:14 --> Language Class Initialized
INFO - 2017-02-26 00:52:14 --> Config Class Initialized
INFO - 2017-02-26 00:52:14 --> Loader Class Initialized
INFO - 2017-02-26 00:52:14 --> Helper loaded: form_helper
INFO - 2017-02-26 00:52:14 --> Helper loaded: url_helper
INFO - 2017-02-26 00:52:14 --> Helper loaded: utility_helper
INFO - 2017-02-26 00:52:14 --> Database Driver Class Initialized
DEBUG - 2017-02-26 00:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-26 00:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-26 00:52:14 --> User Agent Class Initialized
DEBUG - 2017-02-26 00:52:14 --> Template Class Initialized
INFO - 2017-02-26 00:52:14 --> Model Class Initialized
INFO - 2017-02-26 00:52:14 --> Controller Class Initialized
DEBUG - 2017-02-26 00:52:14 --> Pages MX_Controller Initialized
INFO - 2017-02-26 00:52:14 --> Helper loaded: cookie_helper
DEBUG - 2017-02-26 00:52:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-26 00:52:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-26 00:55:16 --> Config Class Initialized
INFO - 2017-02-26 00:55:16 --> Hooks Class Initialized
DEBUG - 2017-02-26 00:55:16 --> UTF-8 Support Enabled
INFO - 2017-02-26 00:55:16 --> Utf8 Class Initialized
INFO - 2017-02-26 00:55:16 --> URI Class Initialized
INFO - 2017-02-26 00:55:16 --> Router Class Initialized
INFO - 2017-02-26 00:55:16 --> Output Class Initialized
INFO - 2017-02-26 00:55:16 --> Security Class Initialized
DEBUG - 2017-02-26 00:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-26 00:55:16 --> Input Class Initialized
INFO - 2017-02-26 00:55:16 --> Language Class Initialized
INFO - 2017-02-26 00:55:16 --> Language Class Initialized
INFO - 2017-02-26 00:55:16 --> Config Class Initialized
INFO - 2017-02-26 00:55:16 --> Loader Class Initialized
INFO - 2017-02-26 00:55:16 --> Helper loaded: form_helper
INFO - 2017-02-26 00:55:16 --> Helper loaded: url_helper
INFO - 2017-02-26 00:55:16 --> Helper loaded: utility_helper
INFO - 2017-02-26 00:55:16 --> Database Driver Class Initialized
DEBUG - 2017-02-26 00:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-26 00:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-26 00:55:16 --> User Agent Class Initialized
DEBUG - 2017-02-26 00:55:16 --> Template Class Initialized
INFO - 2017-02-26 00:55:16 --> Model Class Initialized
INFO - 2017-02-26 00:55:16 --> Controller Class Initialized
DEBUG - 2017-02-26 00:55:16 --> Pages MX_Controller Initialized
INFO - 2017-02-26 00:55:16 --> Helper loaded: cookie_helper
DEBUG - 2017-02-26 00:55:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-26 00:55:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-26 03:10:06 --> Config Class Initialized
INFO - 2017-02-26 03:10:06 --> Hooks Class Initialized
DEBUG - 2017-02-26 03:10:06 --> UTF-8 Support Enabled
INFO - 2017-02-26 03:10:06 --> Utf8 Class Initialized
INFO - 2017-02-26 03:10:06 --> URI Class Initialized
DEBUG - 2017-02-26 03:10:06 --> No URI present. Default controller set.
INFO - 2017-02-26 03:10:06 --> Router Class Initialized
INFO - 2017-02-26 03:10:06 --> Output Class Initialized
INFO - 2017-02-26 03:10:06 --> Security Class Initialized
DEBUG - 2017-02-26 03:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-26 03:10:06 --> Input Class Initialized
INFO - 2017-02-26 03:10:06 --> Language Class Initialized
INFO - 2017-02-26 03:10:06 --> Language Class Initialized
INFO - 2017-02-26 03:10:06 --> Config Class Initialized
INFO - 2017-02-26 03:10:06 --> Loader Class Initialized
INFO - 2017-02-26 03:10:06 --> Helper loaded: form_helper
INFO - 2017-02-26 03:10:06 --> Helper loaded: url_helper
INFO - 2017-02-26 03:10:06 --> Helper loaded: utility_helper
INFO - 2017-02-26 03:10:06 --> Database Driver Class Initialized
DEBUG - 2017-02-26 03:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-26 03:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-26 03:10:06 --> User Agent Class Initialized
DEBUG - 2017-02-26 03:10:06 --> Template Class Initialized
INFO - 2017-02-26 03:10:06 --> Model Class Initialized
INFO - 2017-02-26 03:10:06 --> Controller Class Initialized
DEBUG - 2017-02-26 03:10:06 --> Pages MX_Controller Initialized
INFO - 2017-02-26 03:10:06 --> Helper loaded: cookie_helper
DEBUG - 2017-02-26 03:10:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-26 03:10:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-26 03:10:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-26 03:10:06 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-26 03:10:06 --> Final output sent to browser
DEBUG - 2017-02-26 03:10:06 --> Total execution time: 0.3517
INFO - 2017-02-26 03:10:09 --> Config Class Initialized
INFO - 2017-02-26 03:10:09 --> Hooks Class Initialized
DEBUG - 2017-02-26 03:10:09 --> UTF-8 Support Enabled
INFO - 2017-02-26 03:10:09 --> Utf8 Class Initialized
INFO - 2017-02-26 03:10:09 --> URI Class Initialized
INFO - 2017-02-26 03:10:09 --> Router Class Initialized
INFO - 2017-02-26 03:10:09 --> Output Class Initialized
INFO - 2017-02-26 03:10:09 --> Security Class Initialized
DEBUG - 2017-02-26 03:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-26 03:10:09 --> Input Class Initialized
INFO - 2017-02-26 03:10:09 --> Language Class Initialized
INFO - 2017-02-26 03:10:09 --> Language Class Initialized
INFO - 2017-02-26 03:10:09 --> Config Class Initialized
INFO - 2017-02-26 03:10:09 --> Loader Class Initialized
INFO - 2017-02-26 03:10:09 --> Helper loaded: form_helper
INFO - 2017-02-26 03:10:09 --> Helper loaded: url_helper
INFO - 2017-02-26 03:10:09 --> Helper loaded: utility_helper
INFO - 2017-02-26 03:10:09 --> Database Driver Class Initialized
DEBUG - 2017-02-26 03:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-26 03:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-26 03:10:09 --> User Agent Class Initialized
DEBUG - 2017-02-26 03:10:09 --> Template Class Initialized
INFO - 2017-02-26 03:10:09 --> Model Class Initialized
INFO - 2017-02-26 03:10:09 --> Controller Class Initialized
DEBUG - 2017-02-26 03:10:09 --> Pages MX_Controller Initialized
INFO - 2017-02-26 03:10:09 --> Helper loaded: cookie_helper
DEBUG - 2017-02-26 03:10:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-26 03:10:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-26 03:10:09 --> Config Class Initialized
INFO - 2017-02-26 03:10:09 --> Hooks Class Initialized
DEBUG - 2017-02-26 03:10:09 --> UTF-8 Support Enabled
INFO - 2017-02-26 03:10:09 --> Utf8 Class Initialized
INFO - 2017-02-26 03:10:09 --> URI Class Initialized
INFO - 2017-02-26 03:10:09 --> Router Class Initialized
INFO - 2017-02-26 03:10:09 --> Output Class Initialized
INFO - 2017-02-26 03:10:09 --> Security Class Initialized
DEBUG - 2017-02-26 03:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-26 03:10:09 --> Input Class Initialized
INFO - 2017-02-26 03:10:09 --> Language Class Initialized
INFO - 2017-02-26 03:10:09 --> Language Class Initialized
INFO - 2017-02-26 03:10:09 --> Config Class Initialized
INFO - 2017-02-26 03:10:09 --> Loader Class Initialized
INFO - 2017-02-26 03:10:09 --> Helper loaded: form_helper
INFO - 2017-02-26 03:10:09 --> Helper loaded: url_helper
INFO - 2017-02-26 03:10:09 --> Helper loaded: utility_helper
INFO - 2017-02-26 03:10:09 --> Database Driver Class Initialized
DEBUG - 2017-02-26 03:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-26 03:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-26 03:10:09 --> User Agent Class Initialized
DEBUG - 2017-02-26 03:10:09 --> Template Class Initialized
INFO - 2017-02-26 03:10:09 --> Model Class Initialized
INFO - 2017-02-26 03:10:09 --> Controller Class Initialized
DEBUG - 2017-02-26 03:10:09 --> Pages MX_Controller Initialized
INFO - 2017-02-26 03:10:09 --> Helper loaded: cookie_helper
DEBUG - 2017-02-26 03:10:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-26 03:10:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-26 06:45:21 --> Config Class Initialized
INFO - 2017-02-26 06:45:21 --> Hooks Class Initialized
DEBUG - 2017-02-26 06:45:21 --> UTF-8 Support Enabled
INFO - 2017-02-26 06:45:21 --> Utf8 Class Initialized
INFO - 2017-02-26 06:45:21 --> URI Class Initialized
INFO - 2017-02-26 06:45:21 --> Router Class Initialized
INFO - 2017-02-26 06:45:21 --> Output Class Initialized
INFO - 2017-02-26 06:45:21 --> Security Class Initialized
DEBUG - 2017-02-26 06:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-26 06:45:21 --> Input Class Initialized
INFO - 2017-02-26 06:45:21 --> Language Class Initialized
INFO - 2017-02-26 06:45:21 --> Language Class Initialized
INFO - 2017-02-26 06:45:21 --> Config Class Initialized
INFO - 2017-02-26 06:45:21 --> Loader Class Initialized
INFO - 2017-02-26 06:45:21 --> Helper loaded: form_helper
INFO - 2017-02-26 06:45:21 --> Helper loaded: url_helper
INFO - 2017-02-26 06:45:21 --> Helper loaded: utility_helper
INFO - 2017-02-26 06:45:21 --> Database Driver Class Initialized
DEBUG - 2017-02-26 06:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-26 06:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-26 06:45:21 --> User Agent Class Initialized
DEBUG - 2017-02-26 06:45:21 --> Template Class Initialized
INFO - 2017-02-26 06:45:21 --> Model Class Initialized
INFO - 2017-02-26 06:45:21 --> Controller Class Initialized
DEBUG - 2017-02-26 06:45:21 --> Pages MX_Controller Initialized
INFO - 2017-02-26 06:45:21 --> Helper loaded: cookie_helper
DEBUG - 2017-02-26 06:45:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-26 06:45:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-26 12:47:18 --> Config Class Initialized
INFO - 2017-02-26 12:47:18 --> Hooks Class Initialized
DEBUG - 2017-02-26 12:47:18 --> UTF-8 Support Enabled
INFO - 2017-02-26 12:47:18 --> Utf8 Class Initialized
INFO - 2017-02-26 12:47:18 --> URI Class Initialized
INFO - 2017-02-26 12:47:18 --> Router Class Initialized
INFO - 2017-02-26 12:47:18 --> Output Class Initialized
INFO - 2017-02-26 12:47:18 --> Security Class Initialized
DEBUG - 2017-02-26 12:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-26 12:47:18 --> Input Class Initialized
INFO - 2017-02-26 12:47:18 --> Language Class Initialized
INFO - 2017-02-26 12:47:18 --> Language Class Initialized
INFO - 2017-02-26 12:47:18 --> Config Class Initialized
INFO - 2017-02-26 12:47:18 --> Loader Class Initialized
INFO - 2017-02-26 12:47:18 --> Helper loaded: form_helper
INFO - 2017-02-26 12:47:18 --> Helper loaded: url_helper
INFO - 2017-02-26 12:47:18 --> Helper loaded: utility_helper
INFO - 2017-02-26 12:47:18 --> Database Driver Class Initialized
DEBUG - 2017-02-26 12:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-26 12:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-26 12:47:18 --> User Agent Class Initialized
DEBUG - 2017-02-26 12:47:18 --> Template Class Initialized
INFO - 2017-02-26 12:47:18 --> Model Class Initialized
INFO - 2017-02-26 12:47:18 --> Controller Class Initialized
DEBUG - 2017-02-26 12:47:18 --> Pages MX_Controller Initialized
INFO - 2017-02-26 12:47:18 --> Helper loaded: cookie_helper
DEBUG - 2017-02-26 12:47:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-26 12:47:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-26 18:44:05 --> Config Class Initialized
INFO - 2017-02-26 18:44:05 --> Hooks Class Initialized
DEBUG - 2017-02-26 18:44:05 --> UTF-8 Support Enabled
INFO - 2017-02-26 18:44:05 --> Utf8 Class Initialized
INFO - 2017-02-26 18:44:05 --> URI Class Initialized
INFO - 2017-02-26 18:44:05 --> Router Class Initialized
INFO - 2017-02-26 18:44:05 --> Output Class Initialized
INFO - 2017-02-26 18:44:05 --> Security Class Initialized
DEBUG - 2017-02-26 18:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-26 18:44:05 --> Input Class Initialized
INFO - 2017-02-26 18:44:05 --> Language Class Initialized
INFO - 2017-02-26 18:44:05 --> Language Class Initialized
INFO - 2017-02-26 18:44:05 --> Config Class Initialized
INFO - 2017-02-26 18:44:05 --> Loader Class Initialized
INFO - 2017-02-26 18:44:05 --> Helper loaded: form_helper
INFO - 2017-02-26 18:44:05 --> Helper loaded: url_helper
INFO - 2017-02-26 18:44:05 --> Helper loaded: utility_helper
INFO - 2017-02-26 18:44:05 --> Database Driver Class Initialized
DEBUG - 2017-02-26 18:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-26 18:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-26 18:44:06 --> User Agent Class Initialized
DEBUG - 2017-02-26 18:44:06 --> Template Class Initialized
INFO - 2017-02-26 18:44:06 --> Model Class Initialized
INFO - 2017-02-26 18:44:06 --> Controller Class Initialized
DEBUG - 2017-02-26 18:44:06 --> Pages MX_Controller Initialized
INFO - 2017-02-26 18:44:06 --> Helper loaded: cookie_helper
DEBUG - 2017-02-26 18:44:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-26 18:44:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-26 19:11:23 --> Config Class Initialized
INFO - 2017-02-26 19:11:23 --> Hooks Class Initialized
DEBUG - 2017-02-26 19:11:23 --> UTF-8 Support Enabled
INFO - 2017-02-26 19:11:23 --> Utf8 Class Initialized
INFO - 2017-02-26 19:11:23 --> URI Class Initialized
INFO - 2017-02-26 19:11:23 --> Router Class Initialized
INFO - 2017-02-26 19:11:23 --> Output Class Initialized
INFO - 2017-02-26 19:11:23 --> Security Class Initialized
DEBUG - 2017-02-26 19:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-26 19:11:23 --> Input Class Initialized
INFO - 2017-02-26 19:11:23 --> Language Class Initialized
INFO - 2017-02-26 19:11:23 --> Language Class Initialized
INFO - 2017-02-26 19:11:23 --> Config Class Initialized
INFO - 2017-02-26 19:11:23 --> Loader Class Initialized
INFO - 2017-02-26 19:11:23 --> Helper loaded: form_helper
INFO - 2017-02-26 19:11:23 --> Helper loaded: url_helper
INFO - 2017-02-26 19:11:23 --> Helper loaded: utility_helper
INFO - 2017-02-26 19:11:23 --> Database Driver Class Initialized
DEBUG - 2017-02-26 19:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-26 19:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-26 19:11:23 --> User Agent Class Initialized
DEBUG - 2017-02-26 19:11:23 --> Template Class Initialized
INFO - 2017-02-26 19:11:23 --> Model Class Initialized
INFO - 2017-02-26 19:11:23 --> Controller Class Initialized
DEBUG - 2017-02-26 19:11:23 --> Pages MX_Controller Initialized
INFO - 2017-02-26 19:11:23 --> Helper loaded: cookie_helper
DEBUG - 2017-02-26 19:11:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-26 19:11:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-26 19:13:07 --> Config Class Initialized
INFO - 2017-02-26 19:13:07 --> Hooks Class Initialized
DEBUG - 2017-02-26 19:13:07 --> UTF-8 Support Enabled
INFO - 2017-02-26 19:13:07 --> Utf8 Class Initialized
INFO - 2017-02-26 19:13:07 --> URI Class Initialized
INFO - 2017-02-26 19:13:07 --> Router Class Initialized
INFO - 2017-02-26 19:13:07 --> Output Class Initialized
INFO - 2017-02-26 19:13:07 --> Security Class Initialized
DEBUG - 2017-02-26 19:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-26 19:13:07 --> Input Class Initialized
INFO - 2017-02-26 19:13:07 --> Language Class Initialized
INFO - 2017-02-26 19:13:07 --> Language Class Initialized
INFO - 2017-02-26 19:13:07 --> Config Class Initialized
INFO - 2017-02-26 19:13:07 --> Loader Class Initialized
INFO - 2017-02-26 19:13:07 --> Helper loaded: form_helper
INFO - 2017-02-26 19:13:07 --> Helper loaded: url_helper
INFO - 2017-02-26 19:13:07 --> Helper loaded: utility_helper
INFO - 2017-02-26 19:13:07 --> Database Driver Class Initialized
DEBUG - 2017-02-26 19:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-26 19:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-26 19:13:07 --> User Agent Class Initialized
DEBUG - 2017-02-26 19:13:07 --> Template Class Initialized
INFO - 2017-02-26 19:13:07 --> Model Class Initialized
INFO - 2017-02-26 19:13:07 --> Controller Class Initialized
DEBUG - 2017-02-26 19:13:07 --> Pages MX_Controller Initialized
INFO - 2017-02-26 19:13:07 --> Helper loaded: cookie_helper
DEBUG - 2017-02-26 19:13:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-26 19:13:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-26 19:15:36 --> Config Class Initialized
INFO - 2017-02-26 19:15:36 --> Hooks Class Initialized
DEBUG - 2017-02-26 19:15:36 --> UTF-8 Support Enabled
INFO - 2017-02-26 19:15:36 --> Utf8 Class Initialized
INFO - 2017-02-26 19:15:36 --> URI Class Initialized
INFO - 2017-02-26 19:15:36 --> Router Class Initialized
INFO - 2017-02-26 19:15:36 --> Output Class Initialized
INFO - 2017-02-26 19:15:36 --> Security Class Initialized
DEBUG - 2017-02-26 19:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-26 19:15:36 --> Input Class Initialized
INFO - 2017-02-26 19:15:36 --> Language Class Initialized
INFO - 2017-02-26 19:15:36 --> Language Class Initialized
INFO - 2017-02-26 19:15:36 --> Config Class Initialized
INFO - 2017-02-26 19:15:36 --> Loader Class Initialized
INFO - 2017-02-26 19:15:36 --> Helper loaded: form_helper
INFO - 2017-02-26 19:15:36 --> Helper loaded: url_helper
INFO - 2017-02-26 19:15:36 --> Helper loaded: utility_helper
INFO - 2017-02-26 19:15:36 --> Database Driver Class Initialized
DEBUG - 2017-02-26 19:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-26 19:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-26 19:15:36 --> User Agent Class Initialized
DEBUG - 2017-02-26 19:15:36 --> Template Class Initialized
INFO - 2017-02-26 19:15:36 --> Model Class Initialized
INFO - 2017-02-26 19:15:36 --> Controller Class Initialized
DEBUG - 2017-02-26 19:15:36 --> Pages MX_Controller Initialized
INFO - 2017-02-26 19:15:36 --> Helper loaded: cookie_helper
DEBUG - 2017-02-26 19:15:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-26 19:15:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-26 19:15:51 --> Config Class Initialized
INFO - 2017-02-26 19:15:51 --> Hooks Class Initialized
DEBUG - 2017-02-26 19:15:51 --> UTF-8 Support Enabled
INFO - 2017-02-26 19:15:51 --> Utf8 Class Initialized
INFO - 2017-02-26 19:15:51 --> URI Class Initialized
DEBUG - 2017-02-26 19:15:51 --> No URI present. Default controller set.
INFO - 2017-02-26 19:15:51 --> Router Class Initialized
INFO - 2017-02-26 19:15:51 --> Output Class Initialized
INFO - 2017-02-26 19:15:51 --> Security Class Initialized
DEBUG - 2017-02-26 19:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-26 19:15:51 --> Input Class Initialized
INFO - 2017-02-26 19:15:51 --> Language Class Initialized
INFO - 2017-02-26 19:15:51 --> Language Class Initialized
INFO - 2017-02-26 19:15:51 --> Config Class Initialized
INFO - 2017-02-26 19:15:51 --> Loader Class Initialized
INFO - 2017-02-26 19:15:51 --> Helper loaded: form_helper
INFO - 2017-02-26 19:15:51 --> Helper loaded: url_helper
INFO - 2017-02-26 19:15:51 --> Helper loaded: utility_helper
INFO - 2017-02-26 19:15:51 --> Database Driver Class Initialized
DEBUG - 2017-02-26 19:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-26 19:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-26 19:15:51 --> User Agent Class Initialized
DEBUG - 2017-02-26 19:15:51 --> Template Class Initialized
INFO - 2017-02-26 19:15:51 --> Model Class Initialized
INFO - 2017-02-26 19:15:51 --> Controller Class Initialized
DEBUG - 2017-02-26 19:15:51 --> Pages MX_Controller Initialized
INFO - 2017-02-26 19:15:51 --> Helper loaded: cookie_helper
DEBUG - 2017-02-26 19:15:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-26 19:15:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-26 19:15:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-26 19:15:51 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-26 19:15:51 --> Final output sent to browser
DEBUG - 2017-02-26 19:15:51 --> Total execution time: 0.1038
