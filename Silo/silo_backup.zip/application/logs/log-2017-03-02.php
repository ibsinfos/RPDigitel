<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-02 00:20:05 --> Config Class Initialized
INFO - 2017-03-02 00:20:05 --> Hooks Class Initialized
DEBUG - 2017-03-02 00:20:05 --> UTF-8 Support Enabled
INFO - 2017-03-02 00:20:05 --> Utf8 Class Initialized
INFO - 2017-03-02 00:20:05 --> URI Class Initialized
INFO - 2017-03-02 00:20:05 --> Router Class Initialized
INFO - 2017-03-02 00:20:05 --> Output Class Initialized
INFO - 2017-03-02 00:20:05 --> Security Class Initialized
DEBUG - 2017-03-02 00:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 00:20:06 --> Input Class Initialized
INFO - 2017-03-02 00:20:06 --> Language Class Initialized
INFO - 2017-03-02 00:20:06 --> Language Class Initialized
INFO - 2017-03-02 00:20:06 --> Config Class Initialized
INFO - 2017-03-02 00:20:06 --> Loader Class Initialized
INFO - 2017-03-02 00:20:06 --> Helper loaded: form_helper
INFO - 2017-03-02 00:20:06 --> Helper loaded: url_helper
INFO - 2017-03-02 00:20:06 --> Helper loaded: utility_helper
INFO - 2017-03-02 00:20:06 --> Database Driver Class Initialized
DEBUG - 2017-03-02 00:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 00:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 00:20:06 --> User Agent Class Initialized
DEBUG - 2017-03-02 00:20:06 --> Template Class Initialized
INFO - 2017-03-02 00:20:06 --> Model Class Initialized
INFO - 2017-03-02 00:20:06 --> Controller Class Initialized
DEBUG - 2017-03-02 00:20:06 --> Pages MX_Controller Initialized
INFO - 2017-03-02 00:20:06 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 00:20:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 00:20:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 00:43:33 --> Config Class Initialized
INFO - 2017-03-02 00:43:33 --> Hooks Class Initialized
DEBUG - 2017-03-02 00:43:33 --> UTF-8 Support Enabled
INFO - 2017-03-02 00:43:33 --> Utf8 Class Initialized
INFO - 2017-03-02 00:43:33 --> URI Class Initialized
DEBUG - 2017-03-02 00:43:33 --> No URI present. Default controller set.
INFO - 2017-03-02 00:43:33 --> Router Class Initialized
INFO - 2017-03-02 00:43:33 --> Output Class Initialized
INFO - 2017-03-02 00:43:33 --> Security Class Initialized
DEBUG - 2017-03-02 00:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 00:43:33 --> Input Class Initialized
INFO - 2017-03-02 00:43:33 --> Language Class Initialized
INFO - 2017-03-02 00:43:33 --> Language Class Initialized
INFO - 2017-03-02 00:43:33 --> Config Class Initialized
INFO - 2017-03-02 00:43:33 --> Loader Class Initialized
INFO - 2017-03-02 00:43:33 --> Helper loaded: form_helper
INFO - 2017-03-02 00:43:33 --> Helper loaded: url_helper
INFO - 2017-03-02 00:43:33 --> Helper loaded: utility_helper
INFO - 2017-03-02 00:43:33 --> Database Driver Class Initialized
DEBUG - 2017-03-02 00:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 00:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 00:43:33 --> User Agent Class Initialized
DEBUG - 2017-03-02 00:43:33 --> Template Class Initialized
INFO - 2017-03-02 00:43:33 --> Model Class Initialized
INFO - 2017-03-02 00:43:33 --> Controller Class Initialized
DEBUG - 2017-03-02 00:43:33 --> Pages MX_Controller Initialized
INFO - 2017-03-02 00:43:33 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 00:43:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 00:43:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 00:43:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-02 00:43:33 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 00:43:33 --> Final output sent to browser
DEBUG - 2017-03-02 00:43:33 --> Total execution time: 0.0824
INFO - 2017-03-02 00:43:35 --> Config Class Initialized
INFO - 2017-03-02 00:43:35 --> Hooks Class Initialized
DEBUG - 2017-03-02 00:43:35 --> UTF-8 Support Enabled
INFO - 2017-03-02 00:43:35 --> Utf8 Class Initialized
INFO - 2017-03-02 00:43:35 --> URI Class Initialized
INFO - 2017-03-02 00:43:35 --> Router Class Initialized
INFO - 2017-03-02 00:43:35 --> Output Class Initialized
INFO - 2017-03-02 00:43:35 --> Security Class Initialized
DEBUG - 2017-03-02 00:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 00:43:35 --> Input Class Initialized
INFO - 2017-03-02 00:43:35 --> Language Class Initialized
INFO - 2017-03-02 00:43:35 --> Language Class Initialized
INFO - 2017-03-02 00:43:35 --> Config Class Initialized
INFO - 2017-03-02 00:43:35 --> Loader Class Initialized
INFO - 2017-03-02 00:43:35 --> Helper loaded: form_helper
INFO - 2017-03-02 00:43:35 --> Helper loaded: url_helper
INFO - 2017-03-02 00:43:35 --> Helper loaded: utility_helper
INFO - 2017-03-02 00:43:35 --> Database Driver Class Initialized
DEBUG - 2017-03-02 00:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 00:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 00:43:35 --> User Agent Class Initialized
DEBUG - 2017-03-02 00:43:35 --> Template Class Initialized
INFO - 2017-03-02 00:43:35 --> Model Class Initialized
INFO - 2017-03-02 00:43:35 --> Controller Class Initialized
DEBUG - 2017-03-02 00:43:35 --> Pages MX_Controller Initialized
INFO - 2017-03-02 00:43:35 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 00:43:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 00:43:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 00:43:36 --> Config Class Initialized
INFO - 2017-03-02 00:43:36 --> Hooks Class Initialized
DEBUG - 2017-03-02 00:43:36 --> UTF-8 Support Enabled
INFO - 2017-03-02 00:43:36 --> Utf8 Class Initialized
INFO - 2017-03-02 00:43:36 --> URI Class Initialized
INFO - 2017-03-02 00:43:36 --> Router Class Initialized
INFO - 2017-03-02 00:43:36 --> Output Class Initialized
INFO - 2017-03-02 00:43:36 --> Security Class Initialized
DEBUG - 2017-03-02 00:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 00:43:36 --> Input Class Initialized
INFO - 2017-03-02 00:43:36 --> Language Class Initialized
INFO - 2017-03-02 00:43:36 --> Language Class Initialized
INFO - 2017-03-02 00:43:36 --> Config Class Initialized
INFO - 2017-03-02 00:43:36 --> Loader Class Initialized
INFO - 2017-03-02 00:43:36 --> Helper loaded: form_helper
INFO - 2017-03-02 00:43:36 --> Helper loaded: url_helper
INFO - 2017-03-02 00:43:36 --> Helper loaded: utility_helper
INFO - 2017-03-02 00:43:36 --> Database Driver Class Initialized
DEBUG - 2017-03-02 00:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 00:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 00:43:36 --> User Agent Class Initialized
DEBUG - 2017-03-02 00:43:36 --> Template Class Initialized
INFO - 2017-03-02 00:43:36 --> Model Class Initialized
INFO - 2017-03-02 00:43:36 --> Controller Class Initialized
DEBUG - 2017-03-02 00:43:36 --> Pages MX_Controller Initialized
INFO - 2017-03-02 00:43:36 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 00:43:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 00:43:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 00:43:36 --> Config Class Initialized
INFO - 2017-03-02 00:43:36 --> Hooks Class Initialized
DEBUG - 2017-03-02 00:43:36 --> UTF-8 Support Enabled
INFO - 2017-03-02 00:43:36 --> Utf8 Class Initialized
INFO - 2017-03-02 00:43:36 --> URI Class Initialized
INFO - 2017-03-02 00:43:36 --> Router Class Initialized
INFO - 2017-03-02 00:43:36 --> Output Class Initialized
INFO - 2017-03-02 00:43:36 --> Security Class Initialized
DEBUG - 2017-03-02 00:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 00:43:36 --> Input Class Initialized
INFO - 2017-03-02 00:43:36 --> Language Class Initialized
INFO - 2017-03-02 00:43:36 --> Language Class Initialized
INFO - 2017-03-02 00:43:36 --> Config Class Initialized
INFO - 2017-03-02 00:43:36 --> Loader Class Initialized
INFO - 2017-03-02 00:43:36 --> Helper loaded: form_helper
INFO - 2017-03-02 00:43:36 --> Helper loaded: url_helper
INFO - 2017-03-02 00:43:36 --> Helper loaded: utility_helper
INFO - 2017-03-02 00:43:36 --> Database Driver Class Initialized
DEBUG - 2017-03-02 00:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 00:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 00:43:36 --> User Agent Class Initialized
DEBUG - 2017-03-02 00:43:36 --> Template Class Initialized
INFO - 2017-03-02 00:43:36 --> Model Class Initialized
INFO - 2017-03-02 00:43:36 --> Controller Class Initialized
DEBUG - 2017-03-02 00:43:36 --> Pages MX_Controller Initialized
INFO - 2017-03-02 00:43:36 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 00:43:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 00:43:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 01:28:37 --> Config Class Initialized
INFO - 2017-03-02 01:28:37 --> Config Class Initialized
INFO - 2017-03-02 01:28:37 --> Hooks Class Initialized
INFO - 2017-03-02 01:28:37 --> Hooks Class Initialized
DEBUG - 2017-03-02 01:28:37 --> UTF-8 Support Enabled
DEBUG - 2017-03-02 01:28:37 --> UTF-8 Support Enabled
INFO - 2017-03-02 01:28:37 --> Utf8 Class Initialized
INFO - 2017-03-02 01:28:37 --> Utf8 Class Initialized
INFO - 2017-03-02 01:28:37 --> URI Class Initialized
INFO - 2017-03-02 01:28:37 --> URI Class Initialized
INFO - 2017-03-02 01:28:37 --> Router Class Initialized
INFO - 2017-03-02 01:28:37 --> Router Class Initialized
INFO - 2017-03-02 01:28:37 --> Output Class Initialized
INFO - 2017-03-02 01:28:37 --> Output Class Initialized
INFO - 2017-03-02 01:28:37 --> Security Class Initialized
INFO - 2017-03-02 01:28:37 --> Security Class Initialized
DEBUG - 2017-03-02 01:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-03-02 01:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 01:28:37 --> Input Class Initialized
INFO - 2017-03-02 01:28:37 --> Input Class Initialized
INFO - 2017-03-02 01:28:37 --> Language Class Initialized
INFO - 2017-03-02 01:28:37 --> Language Class Initialized
INFO - 2017-03-02 01:28:37 --> Language Class Initialized
INFO - 2017-03-02 01:28:37 --> Language Class Initialized
INFO - 2017-03-02 01:28:37 --> Config Class Initialized
INFO - 2017-03-02 01:28:37 --> Config Class Initialized
INFO - 2017-03-02 01:28:37 --> Loader Class Initialized
INFO - 2017-03-02 01:28:37 --> Loader Class Initialized
INFO - 2017-03-02 01:28:37 --> Helper loaded: form_helper
INFO - 2017-03-02 01:28:37 --> Helper loaded: form_helper
INFO - 2017-03-02 01:28:37 --> Helper loaded: url_helper
INFO - 2017-03-02 01:28:37 --> Helper loaded: url_helper
INFO - 2017-03-02 01:28:37 --> Helper loaded: utility_helper
INFO - 2017-03-02 01:28:37 --> Helper loaded: utility_helper
INFO - 2017-03-02 01:28:37 --> Database Driver Class Initialized
INFO - 2017-03-02 01:28:37 --> Database Driver Class Initialized
DEBUG - 2017-03-02 01:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 01:28:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2017-03-02 01:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 01:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 01:28:37 --> User Agent Class Initialized
DEBUG - 2017-03-02 01:28:37 --> Template Class Initialized
INFO - 2017-03-02 01:28:37 --> User Agent Class Initialized
DEBUG - 2017-03-02 01:28:37 --> Template Class Initialized
INFO - 2017-03-02 01:28:37 --> Model Class Initialized
INFO - 2017-03-02 01:28:37 --> Controller Class Initialized
DEBUG - 2017-03-02 01:28:37 --> Pages MX_Controller Initialized
INFO - 2017-03-02 01:28:37 --> Model Class Initialized
INFO - 2017-03-02 01:28:37 --> Helper loaded: cookie_helper
INFO - 2017-03-02 01:28:37 --> Controller Class Initialized
DEBUG - 2017-03-02 01:28:37 --> Pages MX_Controller Initialized
DEBUG - 2017-03-02 01:28:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
INFO - 2017-03-02 01:28:37 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 01:28:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 01:28:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 01:28:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 01:28:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-02 01:28:37 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 01:28:37 --> Final output sent to browser
DEBUG - 2017-03-02 01:28:37 --> Total execution time: 0.1052
INFO - 2017-03-02 01:28:47 --> Config Class Initialized
INFO - 2017-03-02 01:28:47 --> Hooks Class Initialized
DEBUG - 2017-03-02 01:28:47 --> UTF-8 Support Enabled
INFO - 2017-03-02 01:28:47 --> Utf8 Class Initialized
INFO - 2017-03-02 01:28:47 --> URI Class Initialized
INFO - 2017-03-02 01:28:47 --> Router Class Initialized
INFO - 2017-03-02 01:28:47 --> Output Class Initialized
INFO - 2017-03-02 01:28:47 --> Security Class Initialized
DEBUG - 2017-03-02 01:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 01:28:47 --> Input Class Initialized
INFO - 2017-03-02 01:28:47 --> Language Class Initialized
INFO - 2017-03-02 01:28:47 --> Language Class Initialized
INFO - 2017-03-02 01:28:47 --> Config Class Initialized
INFO - 2017-03-02 01:28:47 --> Loader Class Initialized
INFO - 2017-03-02 01:28:47 --> Helper loaded: form_helper
INFO - 2017-03-02 01:28:47 --> Helper loaded: url_helper
INFO - 2017-03-02 01:28:47 --> Helper loaded: utility_helper
INFO - 2017-03-02 01:28:47 --> Database Driver Class Initialized
DEBUG - 2017-03-02 01:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 01:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 01:28:47 --> User Agent Class Initialized
DEBUG - 2017-03-02 01:28:47 --> Template Class Initialized
INFO - 2017-03-02 01:28:47 --> Model Class Initialized
INFO - 2017-03-02 01:28:47 --> Controller Class Initialized
DEBUG - 2017-03-02 01:28:47 --> Pages MX_Controller Initialized
INFO - 2017-03-02 01:28:47 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 01:28:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 01:28:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:06:13 --> Config Class Initialized
INFO - 2017-03-02 02:06:13 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:06:13 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:06:13 --> Utf8 Class Initialized
INFO - 2017-03-02 02:06:13 --> URI Class Initialized
INFO - 2017-03-02 02:06:13 --> Router Class Initialized
INFO - 2017-03-02 02:06:13 --> Output Class Initialized
INFO - 2017-03-02 02:06:13 --> Security Class Initialized
DEBUG - 2017-03-02 02:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:06:13 --> Input Class Initialized
INFO - 2017-03-02 02:06:13 --> Language Class Initialized
INFO - 2017-03-02 02:06:13 --> Language Class Initialized
INFO - 2017-03-02 02:06:13 --> Config Class Initialized
INFO - 2017-03-02 02:06:13 --> Loader Class Initialized
INFO - 2017-03-02 02:06:13 --> Helper loaded: form_helper
INFO - 2017-03-02 02:06:13 --> Helper loaded: url_helper
INFO - 2017-03-02 02:06:13 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:06:13 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:06:13 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:06:13 --> Template Class Initialized
INFO - 2017-03-02 02:06:13 --> Model Class Initialized
INFO - 2017-03-02 02:06:13 --> Controller Class Initialized
DEBUG - 2017-03-02 02:06:13 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:06:13 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:06:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:06:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:06:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/support.php
DEBUG - 2017-03-02 02:06:13 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:06:13 --> Final output sent to browser
DEBUG - 2017-03-02 02:06:13 --> Total execution time: 0.0653
INFO - 2017-03-02 02:06:18 --> Config Class Initialized
INFO - 2017-03-02 02:06:18 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:06:18 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:06:18 --> Utf8 Class Initialized
INFO - 2017-03-02 02:06:18 --> URI Class Initialized
INFO - 2017-03-02 02:06:18 --> Router Class Initialized
INFO - 2017-03-02 02:06:18 --> Output Class Initialized
INFO - 2017-03-02 02:06:18 --> Security Class Initialized
DEBUG - 2017-03-02 02:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:06:18 --> Input Class Initialized
INFO - 2017-03-02 02:06:18 --> Language Class Initialized
INFO - 2017-03-02 02:06:18 --> Language Class Initialized
INFO - 2017-03-02 02:06:18 --> Config Class Initialized
INFO - 2017-03-02 02:06:18 --> Loader Class Initialized
INFO - 2017-03-02 02:06:18 --> Helper loaded: form_helper
INFO - 2017-03-02 02:06:18 --> Helper loaded: url_helper
INFO - 2017-03-02 02:06:18 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:06:18 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:06:18 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:06:18 --> Template Class Initialized
INFO - 2017-03-02 02:06:18 --> Model Class Initialized
INFO - 2017-03-02 02:06:18 --> Controller Class Initialized
DEBUG - 2017-03-02 02:06:18 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:06:18 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:06:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:06:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:23:49 --> Config Class Initialized
INFO - 2017-03-02 02:23:49 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:23:49 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:23:49 --> Utf8 Class Initialized
INFO - 2017-03-02 02:23:49 --> URI Class Initialized
INFO - 2017-03-02 02:23:49 --> Router Class Initialized
INFO - 2017-03-02 02:23:49 --> Output Class Initialized
INFO - 2017-03-02 02:23:49 --> Security Class Initialized
DEBUG - 2017-03-02 02:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:23:49 --> Input Class Initialized
INFO - 2017-03-02 02:23:49 --> Language Class Initialized
INFO - 2017-03-02 02:23:49 --> Language Class Initialized
INFO - 2017-03-02 02:23:49 --> Config Class Initialized
INFO - 2017-03-02 02:23:49 --> Loader Class Initialized
INFO - 2017-03-02 02:23:49 --> Helper loaded: form_helper
INFO - 2017-03-02 02:23:49 --> Helper loaded: url_helper
INFO - 2017-03-02 02:23:49 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:23:49 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:23:49 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:23:49 --> Template Class Initialized
INFO - 2017-03-02 02:23:49 --> Model Class Initialized
INFO - 2017-03-02 02:23:49 --> Controller Class Initialized
DEBUG - 2017-03-02 02:23:49 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:23:49 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:23:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:23:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:23:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/about_us.php
DEBUG - 2017-03-02 02:23:49 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:23:49 --> Final output sent to browser
DEBUG - 2017-03-02 02:23:49 --> Total execution time: 0.0707
INFO - 2017-03-02 02:23:54 --> Config Class Initialized
INFO - 2017-03-02 02:23:54 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:23:54 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:23:54 --> Utf8 Class Initialized
INFO - 2017-03-02 02:23:54 --> URI Class Initialized
INFO - 2017-03-02 02:23:54 --> Router Class Initialized
INFO - 2017-03-02 02:23:54 --> Output Class Initialized
INFO - 2017-03-02 02:23:54 --> Security Class Initialized
DEBUG - 2017-03-02 02:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:23:54 --> Input Class Initialized
INFO - 2017-03-02 02:23:54 --> Language Class Initialized
INFO - 2017-03-02 02:23:54 --> Language Class Initialized
INFO - 2017-03-02 02:23:54 --> Config Class Initialized
INFO - 2017-03-02 02:23:54 --> Loader Class Initialized
INFO - 2017-03-02 02:23:54 --> Helper loaded: form_helper
INFO - 2017-03-02 02:23:54 --> Helper loaded: url_helper
INFO - 2017-03-02 02:23:54 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:23:54 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:23:54 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:23:54 --> Template Class Initialized
INFO - 2017-03-02 02:23:54 --> Model Class Initialized
INFO - 2017-03-02 02:23:54 --> Controller Class Initialized
DEBUG - 2017-03-02 02:23:54 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:23:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:23:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:23:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:25:05 --> Config Class Initialized
INFO - 2017-03-02 02:25:05 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:25:05 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:25:05 --> Utf8 Class Initialized
INFO - 2017-03-02 02:25:05 --> URI Class Initialized
DEBUG - 2017-03-02 02:25:05 --> No URI present. Default controller set.
INFO - 2017-03-02 02:25:05 --> Router Class Initialized
INFO - 2017-03-02 02:25:05 --> Output Class Initialized
INFO - 2017-03-02 02:25:05 --> Security Class Initialized
DEBUG - 2017-03-02 02:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:25:05 --> Input Class Initialized
INFO - 2017-03-02 02:25:05 --> Language Class Initialized
INFO - 2017-03-02 02:25:05 --> Language Class Initialized
INFO - 2017-03-02 02:25:05 --> Config Class Initialized
INFO - 2017-03-02 02:25:05 --> Loader Class Initialized
INFO - 2017-03-02 02:25:05 --> Helper loaded: form_helper
INFO - 2017-03-02 02:25:05 --> Helper loaded: url_helper
INFO - 2017-03-02 02:25:05 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:25:05 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:25:05 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:25:05 --> Template Class Initialized
INFO - 2017-03-02 02:25:05 --> Model Class Initialized
INFO - 2017-03-02 02:25:05 --> Controller Class Initialized
DEBUG - 2017-03-02 02:25:05 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:25:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:25:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:25:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:25:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-02 02:25:05 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:25:05 --> Final output sent to browser
DEBUG - 2017-03-02 02:25:05 --> Total execution time: 0.0162
INFO - 2017-03-02 02:25:06 --> Config Class Initialized
INFO - 2017-03-02 02:25:06 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:25:06 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:25:06 --> Utf8 Class Initialized
INFO - 2017-03-02 02:25:06 --> URI Class Initialized
INFO - 2017-03-02 02:25:06 --> Router Class Initialized
INFO - 2017-03-02 02:25:06 --> Output Class Initialized
INFO - 2017-03-02 02:25:06 --> Security Class Initialized
DEBUG - 2017-03-02 02:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:25:06 --> Input Class Initialized
INFO - 2017-03-02 02:25:06 --> Language Class Initialized
INFO - 2017-03-02 02:25:06 --> Language Class Initialized
INFO - 2017-03-02 02:25:06 --> Config Class Initialized
INFO - 2017-03-02 02:25:06 --> Loader Class Initialized
INFO - 2017-03-02 02:25:06 --> Helper loaded: form_helper
INFO - 2017-03-02 02:25:06 --> Helper loaded: url_helper
INFO - 2017-03-02 02:25:06 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:25:06 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:25:06 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:25:06 --> Template Class Initialized
INFO - 2017-03-02 02:25:06 --> Model Class Initialized
INFO - 2017-03-02 02:25:06 --> Controller Class Initialized
DEBUG - 2017-03-02 02:25:06 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:25:06 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:25:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:25:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:25:06 --> Config Class Initialized
INFO - 2017-03-02 02:25:06 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:25:06 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:25:06 --> Utf8 Class Initialized
INFO - 2017-03-02 02:25:06 --> URI Class Initialized
INFO - 2017-03-02 02:25:06 --> Router Class Initialized
INFO - 2017-03-02 02:25:06 --> Output Class Initialized
INFO - 2017-03-02 02:25:06 --> Security Class Initialized
DEBUG - 2017-03-02 02:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:25:06 --> Input Class Initialized
INFO - 2017-03-02 02:25:06 --> Language Class Initialized
INFO - 2017-03-02 02:25:06 --> Language Class Initialized
INFO - 2017-03-02 02:25:06 --> Config Class Initialized
INFO - 2017-03-02 02:25:06 --> Loader Class Initialized
INFO - 2017-03-02 02:25:06 --> Helper loaded: form_helper
INFO - 2017-03-02 02:25:06 --> Helper loaded: url_helper
INFO - 2017-03-02 02:25:06 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:25:06 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:25:06 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:25:06 --> Template Class Initialized
INFO - 2017-03-02 02:25:06 --> Model Class Initialized
INFO - 2017-03-02 02:25:06 --> Controller Class Initialized
DEBUG - 2017-03-02 02:25:06 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:25:06 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:25:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:25:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:25:14 --> Config Class Initialized
INFO - 2017-03-02 02:25:14 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:25:14 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:25:14 --> Utf8 Class Initialized
INFO - 2017-03-02 02:25:14 --> URI Class Initialized
INFO - 2017-03-02 02:25:14 --> Router Class Initialized
INFO - 2017-03-02 02:25:14 --> Output Class Initialized
INFO - 2017-03-02 02:25:14 --> Security Class Initialized
DEBUG - 2017-03-02 02:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:25:14 --> Input Class Initialized
INFO - 2017-03-02 02:25:14 --> Language Class Initialized
INFO - 2017-03-02 02:25:14 --> Language Class Initialized
INFO - 2017-03-02 02:25:14 --> Config Class Initialized
INFO - 2017-03-02 02:25:14 --> Loader Class Initialized
INFO - 2017-03-02 02:25:14 --> Helper loaded: form_helper
INFO - 2017-03-02 02:25:14 --> Helper loaded: url_helper
INFO - 2017-03-02 02:25:14 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:25:14 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:25:14 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:25:14 --> Template Class Initialized
INFO - 2017-03-02 02:25:14 --> Model Class Initialized
INFO - 2017-03-02 02:25:14 --> Controller Class Initialized
DEBUG - 2017-03-02 02:25:14 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:25:14 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:25:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:25:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:25:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-02 02:25:14 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:25:14 --> Final output sent to browser
DEBUG - 2017-03-02 02:25:14 --> Total execution time: 0.0138
INFO - 2017-03-02 02:25:17 --> Config Class Initialized
INFO - 2017-03-02 02:25:17 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:25:17 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:25:17 --> Utf8 Class Initialized
INFO - 2017-03-02 02:25:17 --> URI Class Initialized
INFO - 2017-03-02 02:25:17 --> Router Class Initialized
INFO - 2017-03-02 02:25:17 --> Output Class Initialized
INFO - 2017-03-02 02:25:17 --> Security Class Initialized
DEBUG - 2017-03-02 02:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:25:17 --> Input Class Initialized
INFO - 2017-03-02 02:25:17 --> Language Class Initialized
INFO - 2017-03-02 02:25:17 --> Language Class Initialized
INFO - 2017-03-02 02:25:17 --> Config Class Initialized
INFO - 2017-03-02 02:25:17 --> Loader Class Initialized
INFO - 2017-03-02 02:25:17 --> Helper loaded: form_helper
INFO - 2017-03-02 02:25:17 --> Helper loaded: url_helper
INFO - 2017-03-02 02:25:17 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:25:17 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:25:17 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:25:17 --> Template Class Initialized
INFO - 2017-03-02 02:25:17 --> Model Class Initialized
INFO - 2017-03-02 02:25:17 --> Controller Class Initialized
DEBUG - 2017-03-02 02:25:17 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:25:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:25:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:25:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:25:21 --> Config Class Initialized
INFO - 2017-03-02 02:25:21 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:25:21 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:25:21 --> Utf8 Class Initialized
INFO - 2017-03-02 02:25:21 --> URI Class Initialized
INFO - 2017-03-02 02:25:21 --> Router Class Initialized
INFO - 2017-03-02 02:25:21 --> Output Class Initialized
INFO - 2017-03-02 02:25:21 --> Security Class Initialized
DEBUG - 2017-03-02 02:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:25:21 --> Input Class Initialized
INFO - 2017-03-02 02:25:21 --> Language Class Initialized
INFO - 2017-03-02 02:25:21 --> Language Class Initialized
INFO - 2017-03-02 02:25:21 --> Config Class Initialized
INFO - 2017-03-02 02:25:21 --> Loader Class Initialized
INFO - 2017-03-02 02:25:21 --> Helper loaded: form_helper
INFO - 2017-03-02 02:25:21 --> Helper loaded: url_helper
INFO - 2017-03-02 02:25:21 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:25:21 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:25:21 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:25:21 --> Template Class Initialized
INFO - 2017-03-02 02:25:21 --> Model Class Initialized
INFO - 2017-03-02 02:25:21 --> Controller Class Initialized
DEBUG - 2017-03-02 02:25:21 --> Login MX_Controller Initialized
INFO - 2017-03-02 02:25:21 --> Helper loaded: cookie_helper
INFO - 2017-03-02 02:25:21 --> Form Validation Class Initialized
INFO - 2017-03-02 02:25:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-02 02:25:22 --> Config Class Initialized
INFO - 2017-03-02 02:25:22 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:25:22 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:25:22 --> Utf8 Class Initialized
INFO - 2017-03-02 02:25:22 --> URI Class Initialized
INFO - 2017-03-02 02:25:22 --> Router Class Initialized
INFO - 2017-03-02 02:25:22 --> Output Class Initialized
INFO - 2017-03-02 02:25:22 --> Security Class Initialized
DEBUG - 2017-03-02 02:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:25:22 --> Input Class Initialized
INFO - 2017-03-02 02:25:22 --> Language Class Initialized
INFO - 2017-03-02 02:25:22 --> Language Class Initialized
INFO - 2017-03-02 02:25:22 --> Config Class Initialized
INFO - 2017-03-02 02:25:22 --> Loader Class Initialized
INFO - 2017-03-02 02:25:22 --> Helper loaded: form_helper
INFO - 2017-03-02 02:25:22 --> Helper loaded: url_helper
INFO - 2017-03-02 02:25:22 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:25:22 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:25:22 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:25:22 --> Template Class Initialized
INFO - 2017-03-02 02:25:22 --> Model Class Initialized
INFO - 2017-03-02 02:25:22 --> Controller Class Initialized
DEBUG - 2017-03-02 02:25:22 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:25:22 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:25:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:25:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:25:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-02 02:25:22 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:25:22 --> Final output sent to browser
DEBUG - 2017-03-02 02:25:22 --> Total execution time: 0.0157
INFO - 2017-03-02 02:25:22 --> Config Class Initialized
INFO - 2017-03-02 02:25:22 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:25:22 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:25:22 --> Utf8 Class Initialized
INFO - 2017-03-02 02:25:22 --> URI Class Initialized
INFO - 2017-03-02 02:25:22 --> Router Class Initialized
INFO - 2017-03-02 02:25:22 --> Output Class Initialized
INFO - 2017-03-02 02:25:22 --> Security Class Initialized
DEBUG - 2017-03-02 02:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:25:22 --> Input Class Initialized
INFO - 2017-03-02 02:25:22 --> Language Class Initialized
INFO - 2017-03-02 02:25:22 --> Language Class Initialized
INFO - 2017-03-02 02:25:22 --> Config Class Initialized
INFO - 2017-03-02 02:25:22 --> Loader Class Initialized
INFO - 2017-03-02 02:25:22 --> Helper loaded: form_helper
INFO - 2017-03-02 02:25:22 --> Helper loaded: url_helper
INFO - 2017-03-02 02:25:22 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:25:22 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:25:22 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:25:22 --> Template Class Initialized
INFO - 2017-03-02 02:25:22 --> Model Class Initialized
INFO - 2017-03-02 02:25:22 --> Controller Class Initialized
DEBUG - 2017-03-02 02:25:22 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:25:22 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:25:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:25:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:25:38 --> Config Class Initialized
INFO - 2017-03-02 02:25:38 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:25:38 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:25:38 --> Utf8 Class Initialized
INFO - 2017-03-02 02:25:38 --> URI Class Initialized
INFO - 2017-03-02 02:25:38 --> Router Class Initialized
INFO - 2017-03-02 02:25:38 --> Output Class Initialized
INFO - 2017-03-02 02:25:38 --> Security Class Initialized
DEBUG - 2017-03-02 02:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:25:38 --> Input Class Initialized
INFO - 2017-03-02 02:25:38 --> Language Class Initialized
INFO - 2017-03-02 02:25:38 --> Language Class Initialized
INFO - 2017-03-02 02:25:38 --> Config Class Initialized
INFO - 2017-03-02 02:25:38 --> Loader Class Initialized
INFO - 2017-03-02 02:25:38 --> Helper loaded: form_helper
INFO - 2017-03-02 02:25:38 --> Helper loaded: url_helper
INFO - 2017-03-02 02:25:38 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:25:38 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:25:38 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:25:38 --> Template Class Initialized
INFO - 2017-03-02 02:25:38 --> Model Class Initialized
INFO - 2017-03-02 02:25:38 --> Controller Class Initialized
DEBUG - 2017-03-02 02:25:38 --> Login MX_Controller Initialized
INFO - 2017-03-02 02:25:38 --> Helper loaded: cookie_helper
INFO - 2017-03-02 02:25:38 --> Form Validation Class Initialized
INFO - 2017-03-02 02:25:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-02 02:25:38 --> Config Class Initialized
INFO - 2017-03-02 02:25:38 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:25:38 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:25:38 --> Utf8 Class Initialized
INFO - 2017-03-02 02:25:38 --> URI Class Initialized
INFO - 2017-03-02 02:25:38 --> Router Class Initialized
INFO - 2017-03-02 02:25:38 --> Output Class Initialized
INFO - 2017-03-02 02:25:38 --> Security Class Initialized
DEBUG - 2017-03-02 02:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:25:38 --> Input Class Initialized
INFO - 2017-03-02 02:25:38 --> Language Class Initialized
INFO - 2017-03-02 02:25:38 --> Language Class Initialized
INFO - 2017-03-02 02:25:38 --> Config Class Initialized
INFO - 2017-03-02 02:25:38 --> Loader Class Initialized
INFO - 2017-03-02 02:25:38 --> Helper loaded: form_helper
INFO - 2017-03-02 02:25:38 --> Helper loaded: url_helper
INFO - 2017-03-02 02:25:38 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:25:38 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:25:39 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:25:39 --> Template Class Initialized
INFO - 2017-03-02 02:25:39 --> Model Class Initialized
INFO - 2017-03-02 02:25:39 --> Controller Class Initialized
DEBUG - 2017-03-02 02:25:39 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:25:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:25:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:25:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:25:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-02 02:25:39 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:25:39 --> Final output sent to browser
DEBUG - 2017-03-02 02:25:39 --> Total execution time: 0.0157
INFO - 2017-03-02 02:25:39 --> Config Class Initialized
INFO - 2017-03-02 02:25:39 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:25:39 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:25:39 --> Utf8 Class Initialized
INFO - 2017-03-02 02:25:39 --> URI Class Initialized
INFO - 2017-03-02 02:25:39 --> Router Class Initialized
INFO - 2017-03-02 02:25:39 --> Output Class Initialized
INFO - 2017-03-02 02:25:39 --> Security Class Initialized
DEBUG - 2017-03-02 02:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:25:39 --> Input Class Initialized
INFO - 2017-03-02 02:25:39 --> Language Class Initialized
INFO - 2017-03-02 02:25:39 --> Language Class Initialized
INFO - 2017-03-02 02:25:39 --> Config Class Initialized
INFO - 2017-03-02 02:25:39 --> Loader Class Initialized
INFO - 2017-03-02 02:25:39 --> Helper loaded: form_helper
INFO - 2017-03-02 02:25:39 --> Helper loaded: url_helper
INFO - 2017-03-02 02:25:39 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:25:39 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:25:39 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:25:39 --> Template Class Initialized
INFO - 2017-03-02 02:25:39 --> Model Class Initialized
INFO - 2017-03-02 02:25:39 --> Controller Class Initialized
DEBUG - 2017-03-02 02:25:39 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:25:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:25:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:25:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:25:45 --> Config Class Initialized
INFO - 2017-03-02 02:25:45 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:25:45 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:25:45 --> Utf8 Class Initialized
INFO - 2017-03-02 02:25:45 --> URI Class Initialized
INFO - 2017-03-02 02:25:45 --> Router Class Initialized
INFO - 2017-03-02 02:25:45 --> Output Class Initialized
INFO - 2017-03-02 02:25:45 --> Security Class Initialized
DEBUG - 2017-03-02 02:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:25:45 --> Input Class Initialized
INFO - 2017-03-02 02:25:45 --> Language Class Initialized
INFO - 2017-03-02 02:25:45 --> Language Class Initialized
INFO - 2017-03-02 02:25:45 --> Config Class Initialized
INFO - 2017-03-02 02:25:45 --> Loader Class Initialized
INFO - 2017-03-02 02:25:45 --> Helper loaded: form_helper
INFO - 2017-03-02 02:25:45 --> Helper loaded: url_helper
INFO - 2017-03-02 02:25:45 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:25:45 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:25:45 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:25:45 --> Template Class Initialized
INFO - 2017-03-02 02:25:45 --> Model Class Initialized
INFO - 2017-03-02 02:25:45 --> Controller Class Initialized
DEBUG - 2017-03-02 02:25:45 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:25:45 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:25:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:25:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:25:47 --> Config Class Initialized
INFO - 2017-03-02 02:25:47 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:25:47 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:25:47 --> Utf8 Class Initialized
INFO - 2017-03-02 02:25:47 --> URI Class Initialized
INFO - 2017-03-02 02:25:47 --> Router Class Initialized
INFO - 2017-03-02 02:25:47 --> Output Class Initialized
INFO - 2017-03-02 02:25:47 --> Security Class Initialized
DEBUG - 2017-03-02 02:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:25:47 --> Input Class Initialized
INFO - 2017-03-02 02:25:47 --> Language Class Initialized
INFO - 2017-03-02 02:25:47 --> Language Class Initialized
INFO - 2017-03-02 02:25:47 --> Config Class Initialized
INFO - 2017-03-02 02:25:47 --> Loader Class Initialized
INFO - 2017-03-02 02:25:47 --> Helper loaded: form_helper
INFO - 2017-03-02 02:25:47 --> Helper loaded: url_helper
INFO - 2017-03-02 02:25:47 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:25:47 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:25:47 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:25:47 --> Template Class Initialized
INFO - 2017-03-02 02:25:47 --> Model Class Initialized
INFO - 2017-03-02 02:25:47 --> Controller Class Initialized
DEBUG - 2017-03-02 02:25:47 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:25:47 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:25:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:25:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:25:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-02 02:25:47 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:25:47 --> Final output sent to browser
DEBUG - 2017-03-02 02:25:47 --> Total execution time: 0.0137
INFO - 2017-03-02 02:25:47 --> Config Class Initialized
INFO - 2017-03-02 02:25:47 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:25:47 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:25:47 --> Utf8 Class Initialized
INFO - 2017-03-02 02:25:47 --> URI Class Initialized
INFO - 2017-03-02 02:25:47 --> Router Class Initialized
INFO - 2017-03-02 02:25:47 --> Output Class Initialized
INFO - 2017-03-02 02:25:47 --> Security Class Initialized
DEBUG - 2017-03-02 02:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:25:47 --> Input Class Initialized
INFO - 2017-03-02 02:25:47 --> Language Class Initialized
INFO - 2017-03-02 02:25:47 --> Language Class Initialized
INFO - 2017-03-02 02:25:47 --> Config Class Initialized
INFO - 2017-03-02 02:25:47 --> Loader Class Initialized
INFO - 2017-03-02 02:25:47 --> Helper loaded: form_helper
INFO - 2017-03-02 02:25:47 --> Helper loaded: url_helper
INFO - 2017-03-02 02:25:47 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:25:47 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:25:47 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:25:47 --> Template Class Initialized
INFO - 2017-03-02 02:25:47 --> Model Class Initialized
INFO - 2017-03-02 02:25:47 --> Controller Class Initialized
DEBUG - 2017-03-02 02:25:47 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:25:47 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:25:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:25:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:25:49 --> Config Class Initialized
INFO - 2017-03-02 02:25:49 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:25:49 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:25:49 --> Utf8 Class Initialized
INFO - 2017-03-02 02:25:49 --> URI Class Initialized
INFO - 2017-03-02 02:25:49 --> Router Class Initialized
INFO - 2017-03-02 02:25:49 --> Output Class Initialized
INFO - 2017-03-02 02:25:49 --> Security Class Initialized
DEBUG - 2017-03-02 02:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:25:49 --> Input Class Initialized
INFO - 2017-03-02 02:25:49 --> Language Class Initialized
INFO - 2017-03-02 02:25:49 --> Language Class Initialized
INFO - 2017-03-02 02:25:49 --> Config Class Initialized
INFO - 2017-03-02 02:25:49 --> Loader Class Initialized
INFO - 2017-03-02 02:25:49 --> Helper loaded: form_helper
INFO - 2017-03-02 02:25:49 --> Helper loaded: url_helper
INFO - 2017-03-02 02:25:49 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:25:49 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:25:49 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:25:49 --> Template Class Initialized
INFO - 2017-03-02 02:25:49 --> Model Class Initialized
INFO - 2017-03-02 02:25:49 --> Controller Class Initialized
DEBUG - 2017-03-02 02:25:49 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:25:49 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:25:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:25:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:25:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-03-02 02:25:49 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:25:49 --> Final output sent to browser
DEBUG - 2017-03-02 02:25:49 --> Total execution time: 0.0219
INFO - 2017-03-02 02:25:49 --> Config Class Initialized
INFO - 2017-03-02 02:25:49 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:25:49 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:25:49 --> Utf8 Class Initialized
INFO - 2017-03-02 02:25:49 --> URI Class Initialized
INFO - 2017-03-02 02:25:49 --> Router Class Initialized
INFO - 2017-03-02 02:25:49 --> Output Class Initialized
INFO - 2017-03-02 02:25:49 --> Security Class Initialized
DEBUG - 2017-03-02 02:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:25:49 --> Input Class Initialized
INFO - 2017-03-02 02:25:49 --> Language Class Initialized
INFO - 2017-03-02 02:25:49 --> Language Class Initialized
INFO - 2017-03-02 02:25:49 --> Config Class Initialized
INFO - 2017-03-02 02:25:49 --> Loader Class Initialized
INFO - 2017-03-02 02:25:49 --> Helper loaded: form_helper
INFO - 2017-03-02 02:25:49 --> Helper loaded: url_helper
INFO - 2017-03-02 02:25:49 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:25:49 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:25:49 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:25:49 --> Template Class Initialized
INFO - 2017-03-02 02:25:49 --> Model Class Initialized
INFO - 2017-03-02 02:25:49 --> Controller Class Initialized
DEBUG - 2017-03-02 02:25:49 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:25:49 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:25:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:25:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:25:53 --> Config Class Initialized
INFO - 2017-03-02 02:25:53 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:25:53 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:25:53 --> Utf8 Class Initialized
INFO - 2017-03-02 02:25:53 --> URI Class Initialized
INFO - 2017-03-02 02:25:53 --> Router Class Initialized
INFO - 2017-03-02 02:25:53 --> Output Class Initialized
INFO - 2017-03-02 02:25:53 --> Security Class Initialized
DEBUG - 2017-03-02 02:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:25:53 --> Input Class Initialized
INFO - 2017-03-02 02:25:53 --> Language Class Initialized
INFO - 2017-03-02 02:25:53 --> Language Class Initialized
INFO - 2017-03-02 02:25:53 --> Config Class Initialized
INFO - 2017-03-02 02:25:53 --> Loader Class Initialized
INFO - 2017-03-02 02:25:53 --> Helper loaded: form_helper
INFO - 2017-03-02 02:25:53 --> Helper loaded: url_helper
INFO - 2017-03-02 02:25:53 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:25:53 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:25:53 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:25:53 --> Template Class Initialized
INFO - 2017-03-02 02:25:53 --> Model Class Initialized
INFO - 2017-03-02 02:25:53 --> Controller Class Initialized
DEBUG - 2017-03-02 02:25:53 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:25:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:25:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:25:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:25:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-03-02 02:25:53 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:25:53 --> Final output sent to browser
DEBUG - 2017-03-02 02:25:53 --> Total execution time: 0.0232
INFO - 2017-03-02 02:25:53 --> Config Class Initialized
INFO - 2017-03-02 02:25:53 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:25:53 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:25:53 --> Utf8 Class Initialized
INFO - 2017-03-02 02:25:53 --> URI Class Initialized
INFO - 2017-03-02 02:25:53 --> Router Class Initialized
INFO - 2017-03-02 02:25:53 --> Output Class Initialized
INFO - 2017-03-02 02:25:53 --> Security Class Initialized
DEBUG - 2017-03-02 02:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:25:53 --> Input Class Initialized
INFO - 2017-03-02 02:25:53 --> Language Class Initialized
INFO - 2017-03-02 02:25:53 --> Language Class Initialized
INFO - 2017-03-02 02:25:53 --> Config Class Initialized
INFO - 2017-03-02 02:25:53 --> Loader Class Initialized
INFO - 2017-03-02 02:25:53 --> Helper loaded: form_helper
INFO - 2017-03-02 02:25:53 --> Helper loaded: url_helper
INFO - 2017-03-02 02:25:53 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:25:53 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:25:53 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:25:53 --> Template Class Initialized
INFO - 2017-03-02 02:25:53 --> Model Class Initialized
INFO - 2017-03-02 02:25:53 --> Controller Class Initialized
DEBUG - 2017-03-02 02:25:53 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:25:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:25:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:25:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:36:48 --> Config Class Initialized
INFO - 2017-03-02 02:36:48 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:36:48 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:36:48 --> Utf8 Class Initialized
INFO - 2017-03-02 02:36:48 --> URI Class Initialized
DEBUG - 2017-03-02 02:36:48 --> No URI present. Default controller set.
INFO - 2017-03-02 02:36:48 --> Router Class Initialized
INFO - 2017-03-02 02:36:48 --> Output Class Initialized
INFO - 2017-03-02 02:36:48 --> Security Class Initialized
DEBUG - 2017-03-02 02:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:36:48 --> Input Class Initialized
INFO - 2017-03-02 02:36:48 --> Language Class Initialized
INFO - 2017-03-02 02:36:48 --> Language Class Initialized
INFO - 2017-03-02 02:36:48 --> Config Class Initialized
INFO - 2017-03-02 02:36:48 --> Loader Class Initialized
INFO - 2017-03-02 02:36:48 --> Helper loaded: form_helper
INFO - 2017-03-02 02:36:48 --> Helper loaded: url_helper
INFO - 2017-03-02 02:36:48 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:36:48 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:36:48 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:36:48 --> Template Class Initialized
INFO - 2017-03-02 02:36:48 --> Model Class Initialized
INFO - 2017-03-02 02:36:48 --> Controller Class Initialized
DEBUG - 2017-03-02 02:36:48 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:36:48 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:36:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:36:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:36:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-02 02:36:48 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:36:48 --> Final output sent to browser
DEBUG - 2017-03-02 02:36:48 --> Total execution time: 0.0671
INFO - 2017-03-02 02:36:48 --> Config Class Initialized
INFO - 2017-03-02 02:36:48 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:36:48 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:36:48 --> Utf8 Class Initialized
INFO - 2017-03-02 02:36:48 --> URI Class Initialized
INFO - 2017-03-02 02:36:48 --> Router Class Initialized
INFO - 2017-03-02 02:36:48 --> Output Class Initialized
INFO - 2017-03-02 02:36:48 --> Security Class Initialized
DEBUG - 2017-03-02 02:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:36:48 --> Input Class Initialized
INFO - 2017-03-02 02:36:48 --> Language Class Initialized
INFO - 2017-03-02 02:36:48 --> Language Class Initialized
INFO - 2017-03-02 02:36:48 --> Config Class Initialized
INFO - 2017-03-02 02:36:48 --> Loader Class Initialized
INFO - 2017-03-02 02:36:48 --> Helper loaded: form_helper
INFO - 2017-03-02 02:36:48 --> Helper loaded: url_helper
INFO - 2017-03-02 02:36:48 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:36:48 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:36:48 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:36:48 --> Template Class Initialized
INFO - 2017-03-02 02:36:48 --> Model Class Initialized
INFO - 2017-03-02 02:36:48 --> Controller Class Initialized
DEBUG - 2017-03-02 02:36:48 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:36:48 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:36:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:36:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:36:49 --> Config Class Initialized
INFO - 2017-03-02 02:36:49 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:36:49 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:36:49 --> Utf8 Class Initialized
INFO - 2017-03-02 02:36:49 --> URI Class Initialized
INFO - 2017-03-02 02:36:49 --> Router Class Initialized
INFO - 2017-03-02 02:36:49 --> Output Class Initialized
INFO - 2017-03-02 02:36:49 --> Security Class Initialized
DEBUG - 2017-03-02 02:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:36:49 --> Input Class Initialized
INFO - 2017-03-02 02:36:49 --> Language Class Initialized
INFO - 2017-03-02 02:36:49 --> Language Class Initialized
INFO - 2017-03-02 02:36:49 --> Config Class Initialized
INFO - 2017-03-02 02:36:49 --> Loader Class Initialized
INFO - 2017-03-02 02:36:49 --> Helper loaded: form_helper
INFO - 2017-03-02 02:36:49 --> Helper loaded: url_helper
INFO - 2017-03-02 02:36:49 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:36:49 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:36:49 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:36:49 --> Template Class Initialized
INFO - 2017-03-02 02:36:49 --> Model Class Initialized
INFO - 2017-03-02 02:36:49 --> Controller Class Initialized
DEBUG - 2017-03-02 02:36:49 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:36:49 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:36:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:36:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:41:53 --> Config Class Initialized
INFO - 2017-03-02 02:41:53 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:41:53 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:41:53 --> Utf8 Class Initialized
INFO - 2017-03-02 02:41:53 --> URI Class Initialized
DEBUG - 2017-03-02 02:41:53 --> No URI present. Default controller set.
INFO - 2017-03-02 02:41:53 --> Router Class Initialized
INFO - 2017-03-02 02:41:53 --> Output Class Initialized
INFO - 2017-03-02 02:41:53 --> Security Class Initialized
DEBUG - 2017-03-02 02:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:41:53 --> Input Class Initialized
INFO - 2017-03-02 02:41:53 --> Language Class Initialized
INFO - 2017-03-02 02:41:53 --> Language Class Initialized
INFO - 2017-03-02 02:41:53 --> Config Class Initialized
INFO - 2017-03-02 02:41:53 --> Loader Class Initialized
INFO - 2017-03-02 02:41:53 --> Helper loaded: form_helper
INFO - 2017-03-02 02:41:53 --> Helper loaded: url_helper
INFO - 2017-03-02 02:41:53 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:41:53 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:41:53 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:41:53 --> Template Class Initialized
INFO - 2017-03-02 02:41:53 --> Model Class Initialized
INFO - 2017-03-02 02:41:53 --> Controller Class Initialized
DEBUG - 2017-03-02 02:41:53 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:41:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:41:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:41:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:41:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-02 02:41:53 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:41:53 --> Final output sent to browser
DEBUG - 2017-03-02 02:41:53 --> Total execution time: 0.0630
INFO - 2017-03-02 02:41:55 --> Config Class Initialized
INFO - 2017-03-02 02:41:55 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:41:55 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:41:55 --> Utf8 Class Initialized
INFO - 2017-03-02 02:41:55 --> URI Class Initialized
INFO - 2017-03-02 02:41:55 --> Router Class Initialized
INFO - 2017-03-02 02:41:55 --> Output Class Initialized
INFO - 2017-03-02 02:41:55 --> Security Class Initialized
DEBUG - 2017-03-02 02:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:41:55 --> Input Class Initialized
INFO - 2017-03-02 02:41:55 --> Language Class Initialized
INFO - 2017-03-02 02:41:55 --> Language Class Initialized
INFO - 2017-03-02 02:41:55 --> Config Class Initialized
INFO - 2017-03-02 02:41:55 --> Loader Class Initialized
INFO - 2017-03-02 02:41:55 --> Helper loaded: form_helper
INFO - 2017-03-02 02:41:55 --> Helper loaded: url_helper
INFO - 2017-03-02 02:41:55 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:41:55 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:41:55 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:41:55 --> Template Class Initialized
INFO - 2017-03-02 02:41:55 --> Model Class Initialized
INFO - 2017-03-02 02:41:55 --> Controller Class Initialized
DEBUG - 2017-03-02 02:41:55 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:41:55 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:41:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:41:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:41:55 --> Config Class Initialized
INFO - 2017-03-02 02:41:55 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:41:55 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:41:55 --> Utf8 Class Initialized
INFO - 2017-03-02 02:41:55 --> URI Class Initialized
INFO - 2017-03-02 02:41:55 --> Router Class Initialized
INFO - 2017-03-02 02:41:55 --> Output Class Initialized
INFO - 2017-03-02 02:41:55 --> Security Class Initialized
DEBUG - 2017-03-02 02:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:41:55 --> Input Class Initialized
INFO - 2017-03-02 02:41:55 --> Language Class Initialized
INFO - 2017-03-02 02:41:55 --> Language Class Initialized
INFO - 2017-03-02 02:41:55 --> Config Class Initialized
INFO - 2017-03-02 02:41:55 --> Loader Class Initialized
INFO - 2017-03-02 02:41:55 --> Helper loaded: form_helper
INFO - 2017-03-02 02:41:55 --> Helper loaded: url_helper
INFO - 2017-03-02 02:41:55 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:41:55 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:41:55 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:41:55 --> Template Class Initialized
INFO - 2017-03-02 02:41:55 --> Model Class Initialized
INFO - 2017-03-02 02:41:55 --> Controller Class Initialized
DEBUG - 2017-03-02 02:41:55 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:41:55 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:41:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:41:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:42:53 --> Config Class Initialized
INFO - 2017-03-02 02:42:53 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:42:53 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:42:53 --> Utf8 Class Initialized
INFO - 2017-03-02 02:42:53 --> URI Class Initialized
INFO - 2017-03-02 02:42:53 --> Router Class Initialized
INFO - 2017-03-02 02:42:53 --> Output Class Initialized
INFO - 2017-03-02 02:42:53 --> Security Class Initialized
DEBUG - 2017-03-02 02:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:42:53 --> Input Class Initialized
INFO - 2017-03-02 02:42:53 --> Language Class Initialized
INFO - 2017-03-02 02:42:53 --> Language Class Initialized
INFO - 2017-03-02 02:42:53 --> Config Class Initialized
INFO - 2017-03-02 02:42:53 --> Loader Class Initialized
INFO - 2017-03-02 02:42:53 --> Helper loaded: form_helper
INFO - 2017-03-02 02:42:53 --> Helper loaded: url_helper
INFO - 2017-03-02 02:42:53 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:42:53 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:42:53 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:42:53 --> Template Class Initialized
INFO - 2017-03-02 02:42:53 --> Model Class Initialized
INFO - 2017-03-02 02:42:53 --> Controller Class Initialized
DEBUG - 2017-03-02 02:42:53 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:42:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:42:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:42:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:42:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/about_us.php
DEBUG - 2017-03-02 02:42:53 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:42:53 --> Final output sent to browser
DEBUG - 2017-03-02 02:42:53 --> Total execution time: 0.0201
INFO - 2017-03-02 02:42:54 --> Config Class Initialized
INFO - 2017-03-02 02:42:54 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:42:54 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:42:54 --> Utf8 Class Initialized
INFO - 2017-03-02 02:42:54 --> URI Class Initialized
INFO - 2017-03-02 02:42:54 --> Router Class Initialized
INFO - 2017-03-02 02:42:54 --> Output Class Initialized
INFO - 2017-03-02 02:42:54 --> Security Class Initialized
DEBUG - 2017-03-02 02:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:42:54 --> Input Class Initialized
INFO - 2017-03-02 02:42:54 --> Language Class Initialized
INFO - 2017-03-02 02:42:54 --> Language Class Initialized
INFO - 2017-03-02 02:42:54 --> Config Class Initialized
INFO - 2017-03-02 02:42:54 --> Loader Class Initialized
INFO - 2017-03-02 02:42:54 --> Helper loaded: form_helper
INFO - 2017-03-02 02:42:54 --> Helper loaded: url_helper
INFO - 2017-03-02 02:42:54 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:42:54 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:42:54 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:42:54 --> Template Class Initialized
INFO - 2017-03-02 02:42:54 --> Model Class Initialized
INFO - 2017-03-02 02:42:54 --> Controller Class Initialized
DEBUG - 2017-03-02 02:42:54 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:42:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:42:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:42:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:42:59 --> Config Class Initialized
INFO - 2017-03-02 02:42:59 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:42:59 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:42:59 --> Utf8 Class Initialized
INFO - 2017-03-02 02:42:59 --> URI Class Initialized
INFO - 2017-03-02 02:42:59 --> Router Class Initialized
INFO - 2017-03-02 02:42:59 --> Output Class Initialized
INFO - 2017-03-02 02:42:59 --> Security Class Initialized
DEBUG - 2017-03-02 02:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:42:59 --> Input Class Initialized
INFO - 2017-03-02 02:42:59 --> Language Class Initialized
INFO - 2017-03-02 02:42:59 --> Language Class Initialized
INFO - 2017-03-02 02:42:59 --> Config Class Initialized
INFO - 2017-03-02 02:42:59 --> Loader Class Initialized
INFO - 2017-03-02 02:42:59 --> Helper loaded: form_helper
INFO - 2017-03-02 02:42:59 --> Helper loaded: url_helper
INFO - 2017-03-02 02:42:59 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:42:59 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:42:59 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:42:59 --> Template Class Initialized
INFO - 2017-03-02 02:42:59 --> Model Class Initialized
INFO - 2017-03-02 02:42:59 --> Controller Class Initialized
DEBUG - 2017-03-02 02:42:59 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:42:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:42:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:42:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:42:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/support.php
DEBUG - 2017-03-02 02:42:59 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:42:59 --> Final output sent to browser
DEBUG - 2017-03-02 02:42:59 --> Total execution time: 0.0229
INFO - 2017-03-02 02:43:00 --> Config Class Initialized
INFO - 2017-03-02 02:43:00 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:43:00 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:43:00 --> Utf8 Class Initialized
INFO - 2017-03-02 02:43:00 --> URI Class Initialized
INFO - 2017-03-02 02:43:00 --> Router Class Initialized
INFO - 2017-03-02 02:43:00 --> Output Class Initialized
INFO - 2017-03-02 02:43:00 --> Security Class Initialized
DEBUG - 2017-03-02 02:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:43:00 --> Input Class Initialized
INFO - 2017-03-02 02:43:00 --> Language Class Initialized
INFO - 2017-03-02 02:43:00 --> Language Class Initialized
INFO - 2017-03-02 02:43:00 --> Config Class Initialized
INFO - 2017-03-02 02:43:00 --> Loader Class Initialized
INFO - 2017-03-02 02:43:00 --> Helper loaded: form_helper
INFO - 2017-03-02 02:43:00 --> Helper loaded: url_helper
INFO - 2017-03-02 02:43:00 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:43:00 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:43:00 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:43:00 --> Template Class Initialized
INFO - 2017-03-02 02:43:00 --> Model Class Initialized
INFO - 2017-03-02 02:43:00 --> Controller Class Initialized
DEBUG - 2017-03-02 02:43:00 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:43:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:43:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:43:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:43:16 --> Config Class Initialized
INFO - 2017-03-02 02:43:16 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:43:16 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:43:16 --> Utf8 Class Initialized
INFO - 2017-03-02 02:43:16 --> URI Class Initialized
DEBUG - 2017-03-02 02:43:16 --> No URI present. Default controller set.
INFO - 2017-03-02 02:43:16 --> Router Class Initialized
INFO - 2017-03-02 02:43:16 --> Output Class Initialized
INFO - 2017-03-02 02:43:16 --> Security Class Initialized
DEBUG - 2017-03-02 02:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:43:16 --> Input Class Initialized
INFO - 2017-03-02 02:43:16 --> Language Class Initialized
INFO - 2017-03-02 02:43:16 --> Language Class Initialized
INFO - 2017-03-02 02:43:16 --> Config Class Initialized
INFO - 2017-03-02 02:43:16 --> Loader Class Initialized
INFO - 2017-03-02 02:43:16 --> Helper loaded: form_helper
INFO - 2017-03-02 02:43:16 --> Helper loaded: url_helper
INFO - 2017-03-02 02:43:16 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:43:16 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:43:16 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:43:16 --> Template Class Initialized
INFO - 2017-03-02 02:43:16 --> Model Class Initialized
INFO - 2017-03-02 02:43:16 --> Controller Class Initialized
DEBUG - 2017-03-02 02:43:16 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:43:16 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:43:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:43:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:43:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-02 02:43:16 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:43:16 --> Final output sent to browser
DEBUG - 2017-03-02 02:43:16 --> Total execution time: 0.0106
INFO - 2017-03-02 02:43:16 --> Config Class Initialized
INFO - 2017-03-02 02:43:16 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:43:16 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:43:16 --> Utf8 Class Initialized
INFO - 2017-03-02 02:43:16 --> URI Class Initialized
INFO - 2017-03-02 02:43:16 --> Router Class Initialized
INFO - 2017-03-02 02:43:16 --> Output Class Initialized
INFO - 2017-03-02 02:43:16 --> Security Class Initialized
DEBUG - 2017-03-02 02:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:43:16 --> Input Class Initialized
INFO - 2017-03-02 02:43:16 --> Language Class Initialized
INFO - 2017-03-02 02:43:16 --> Language Class Initialized
INFO - 2017-03-02 02:43:16 --> Config Class Initialized
INFO - 2017-03-02 02:43:16 --> Loader Class Initialized
INFO - 2017-03-02 02:43:16 --> Helper loaded: form_helper
INFO - 2017-03-02 02:43:16 --> Helper loaded: url_helper
INFO - 2017-03-02 02:43:16 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:43:16 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:43:16 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:43:16 --> Template Class Initialized
INFO - 2017-03-02 02:43:16 --> Model Class Initialized
INFO - 2017-03-02 02:43:16 --> Controller Class Initialized
DEBUG - 2017-03-02 02:43:16 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:43:16 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:43:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:43:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:43:16 --> Config Class Initialized
INFO - 2017-03-02 02:43:16 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:43:16 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:43:16 --> Utf8 Class Initialized
INFO - 2017-03-02 02:43:16 --> URI Class Initialized
INFO - 2017-03-02 02:43:16 --> Router Class Initialized
INFO - 2017-03-02 02:43:16 --> Output Class Initialized
INFO - 2017-03-02 02:43:16 --> Security Class Initialized
DEBUG - 2017-03-02 02:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:43:16 --> Input Class Initialized
INFO - 2017-03-02 02:43:16 --> Language Class Initialized
INFO - 2017-03-02 02:43:16 --> Language Class Initialized
INFO - 2017-03-02 02:43:16 --> Config Class Initialized
INFO - 2017-03-02 02:43:16 --> Loader Class Initialized
INFO - 2017-03-02 02:43:16 --> Helper loaded: form_helper
INFO - 2017-03-02 02:43:16 --> Helper loaded: url_helper
INFO - 2017-03-02 02:43:16 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:43:16 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:43:16 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:43:16 --> Template Class Initialized
INFO - 2017-03-02 02:43:16 --> Model Class Initialized
INFO - 2017-03-02 02:43:16 --> Controller Class Initialized
DEBUG - 2017-03-02 02:43:16 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:43:16 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:43:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:43:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:43:18 --> Config Class Initialized
INFO - 2017-03-02 02:43:18 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:43:18 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:43:18 --> Utf8 Class Initialized
INFO - 2017-03-02 02:43:18 --> URI Class Initialized
INFO - 2017-03-02 02:43:18 --> Router Class Initialized
INFO - 2017-03-02 02:43:18 --> Output Class Initialized
INFO - 2017-03-02 02:43:18 --> Security Class Initialized
DEBUG - 2017-03-02 02:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:43:18 --> Input Class Initialized
INFO - 2017-03-02 02:43:18 --> Language Class Initialized
INFO - 2017-03-02 02:43:18 --> Language Class Initialized
INFO - 2017-03-02 02:43:18 --> Config Class Initialized
INFO - 2017-03-02 02:43:18 --> Loader Class Initialized
INFO - 2017-03-02 02:43:18 --> Helper loaded: form_helper
INFO - 2017-03-02 02:43:18 --> Helper loaded: url_helper
INFO - 2017-03-02 02:43:18 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:43:18 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:43:18 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:43:18 --> Template Class Initialized
INFO - 2017-03-02 02:43:18 --> Model Class Initialized
INFO - 2017-03-02 02:43:18 --> Controller Class Initialized
DEBUG - 2017-03-02 02:43:18 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:43:18 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:43:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:43:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:43:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-02 02:43:18 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:43:18 --> Final output sent to browser
DEBUG - 2017-03-02 02:43:18 --> Total execution time: 0.0130
INFO - 2017-03-02 02:43:18 --> Config Class Initialized
INFO - 2017-03-02 02:43:18 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:43:18 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:43:18 --> Utf8 Class Initialized
INFO - 2017-03-02 02:43:18 --> URI Class Initialized
INFO - 2017-03-02 02:43:18 --> Router Class Initialized
INFO - 2017-03-02 02:43:18 --> Output Class Initialized
INFO - 2017-03-02 02:43:18 --> Security Class Initialized
DEBUG - 2017-03-02 02:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:43:18 --> Input Class Initialized
INFO - 2017-03-02 02:43:18 --> Language Class Initialized
INFO - 2017-03-02 02:43:18 --> Language Class Initialized
INFO - 2017-03-02 02:43:18 --> Config Class Initialized
INFO - 2017-03-02 02:43:18 --> Loader Class Initialized
INFO - 2017-03-02 02:43:18 --> Helper loaded: form_helper
INFO - 2017-03-02 02:43:18 --> Helper loaded: url_helper
INFO - 2017-03-02 02:43:18 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:43:18 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:43:18 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:43:18 --> Template Class Initialized
INFO - 2017-03-02 02:43:18 --> Model Class Initialized
INFO - 2017-03-02 02:43:18 --> Controller Class Initialized
DEBUG - 2017-03-02 02:43:18 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:43:18 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:43:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:43:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:43:31 --> Config Class Initialized
INFO - 2017-03-02 02:43:31 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:43:31 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:43:31 --> Utf8 Class Initialized
INFO - 2017-03-02 02:43:31 --> URI Class Initialized
INFO - 2017-03-02 02:43:31 --> Router Class Initialized
INFO - 2017-03-02 02:43:31 --> Output Class Initialized
INFO - 2017-03-02 02:43:31 --> Security Class Initialized
DEBUG - 2017-03-02 02:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:43:31 --> Input Class Initialized
INFO - 2017-03-02 02:43:31 --> Language Class Initialized
INFO - 2017-03-02 02:43:31 --> Language Class Initialized
INFO - 2017-03-02 02:43:31 --> Config Class Initialized
INFO - 2017-03-02 02:43:31 --> Loader Class Initialized
INFO - 2017-03-02 02:43:31 --> Helper loaded: form_helper
INFO - 2017-03-02 02:43:31 --> Helper loaded: url_helper
INFO - 2017-03-02 02:43:31 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:43:31 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:43:31 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:43:31 --> Template Class Initialized
INFO - 2017-03-02 02:43:31 --> Model Class Initialized
INFO - 2017-03-02 02:43:31 --> Controller Class Initialized
DEBUG - 2017-03-02 02:43:31 --> Login MX_Controller Initialized
INFO - 2017-03-02 02:43:31 --> Helper loaded: cookie_helper
INFO - 2017-03-02 02:43:31 --> Form Validation Class Initialized
INFO - 2017-03-02 02:43:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-02 02:43:31 --> Config Class Initialized
INFO - 2017-03-02 02:43:31 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:43:31 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:43:31 --> Utf8 Class Initialized
INFO - 2017-03-02 02:43:31 --> URI Class Initialized
INFO - 2017-03-02 02:43:31 --> Router Class Initialized
INFO - 2017-03-02 02:43:31 --> Output Class Initialized
INFO - 2017-03-02 02:43:31 --> Security Class Initialized
DEBUG - 2017-03-02 02:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:43:31 --> Input Class Initialized
INFO - 2017-03-02 02:43:31 --> Language Class Initialized
INFO - 2017-03-02 02:43:31 --> Language Class Initialized
INFO - 2017-03-02 02:43:31 --> Config Class Initialized
INFO - 2017-03-02 02:43:31 --> Loader Class Initialized
INFO - 2017-03-02 02:43:31 --> Helper loaded: form_helper
INFO - 2017-03-02 02:43:31 --> Helper loaded: url_helper
INFO - 2017-03-02 02:43:31 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:43:31 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:43:31 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:43:31 --> Template Class Initialized
INFO - 2017-03-02 02:43:31 --> Model Class Initialized
INFO - 2017-03-02 02:43:31 --> Controller Class Initialized
DEBUG - 2017-03-02 02:43:31 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:43:31 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:43:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:43:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:43:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-02 02:43:31 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:43:31 --> Final output sent to browser
DEBUG - 2017-03-02 02:43:31 --> Total execution time: 0.0131
INFO - 2017-03-02 02:43:32 --> Config Class Initialized
INFO - 2017-03-02 02:43:32 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:43:32 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:43:32 --> Utf8 Class Initialized
INFO - 2017-03-02 02:43:32 --> URI Class Initialized
INFO - 2017-03-02 02:43:32 --> Router Class Initialized
INFO - 2017-03-02 02:43:32 --> Output Class Initialized
INFO - 2017-03-02 02:43:32 --> Security Class Initialized
DEBUG - 2017-03-02 02:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:43:32 --> Input Class Initialized
INFO - 2017-03-02 02:43:32 --> Language Class Initialized
INFO - 2017-03-02 02:43:32 --> Language Class Initialized
INFO - 2017-03-02 02:43:32 --> Config Class Initialized
INFO - 2017-03-02 02:43:32 --> Loader Class Initialized
INFO - 2017-03-02 02:43:32 --> Helper loaded: form_helper
INFO - 2017-03-02 02:43:32 --> Helper loaded: url_helper
INFO - 2017-03-02 02:43:32 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:43:32 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:43:32 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:43:32 --> Template Class Initialized
INFO - 2017-03-02 02:43:32 --> Model Class Initialized
INFO - 2017-03-02 02:43:32 --> Controller Class Initialized
DEBUG - 2017-03-02 02:43:32 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:43:32 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:43:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:43:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:45:49 --> Config Class Initialized
INFO - 2017-03-02 02:45:49 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:45:49 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:45:49 --> Utf8 Class Initialized
INFO - 2017-03-02 02:45:49 --> URI Class Initialized
INFO - 2017-03-02 02:45:49 --> Router Class Initialized
INFO - 2017-03-02 02:45:49 --> Output Class Initialized
INFO - 2017-03-02 02:45:49 --> Security Class Initialized
DEBUG - 2017-03-02 02:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:45:49 --> Input Class Initialized
INFO - 2017-03-02 02:45:49 --> Language Class Initialized
INFO - 2017-03-02 02:45:49 --> Language Class Initialized
INFO - 2017-03-02 02:45:49 --> Config Class Initialized
INFO - 2017-03-02 02:45:49 --> Loader Class Initialized
INFO - 2017-03-02 02:45:49 --> Helper loaded: form_helper
INFO - 2017-03-02 02:45:49 --> Helper loaded: url_helper
INFO - 2017-03-02 02:45:49 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:45:49 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:45:49 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:45:49 --> Template Class Initialized
INFO - 2017-03-02 02:45:49 --> Model Class Initialized
INFO - 2017-03-02 02:45:49 --> Controller Class Initialized
DEBUG - 2017-03-02 02:45:49 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:45:49 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:45:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:45:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:45:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-02 02:45:49 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:45:49 --> Final output sent to browser
DEBUG - 2017-03-02 02:45:49 --> Total execution time: 0.0101
INFO - 2017-03-02 02:45:49 --> Config Class Initialized
INFO - 2017-03-02 02:45:49 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:45:49 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:45:49 --> Utf8 Class Initialized
INFO - 2017-03-02 02:45:49 --> URI Class Initialized
INFO - 2017-03-02 02:45:49 --> Router Class Initialized
INFO - 2017-03-02 02:45:49 --> Output Class Initialized
INFO - 2017-03-02 02:45:49 --> Security Class Initialized
DEBUG - 2017-03-02 02:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:45:49 --> Input Class Initialized
INFO - 2017-03-02 02:45:49 --> Language Class Initialized
INFO - 2017-03-02 02:45:49 --> Language Class Initialized
INFO - 2017-03-02 02:45:49 --> Config Class Initialized
INFO - 2017-03-02 02:45:49 --> Loader Class Initialized
INFO - 2017-03-02 02:45:49 --> Helper loaded: form_helper
INFO - 2017-03-02 02:45:49 --> Helper loaded: url_helper
INFO - 2017-03-02 02:45:49 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:45:49 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:45:49 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:45:49 --> Template Class Initialized
INFO - 2017-03-02 02:45:49 --> Model Class Initialized
INFO - 2017-03-02 02:45:49 --> Controller Class Initialized
DEBUG - 2017-03-02 02:45:49 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:45:49 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:45:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:45:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:45:51 --> Config Class Initialized
INFO - 2017-03-02 02:45:51 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:45:51 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:45:51 --> Utf8 Class Initialized
INFO - 2017-03-02 02:45:51 --> URI Class Initialized
INFO - 2017-03-02 02:45:51 --> Router Class Initialized
INFO - 2017-03-02 02:45:51 --> Output Class Initialized
INFO - 2017-03-02 02:45:51 --> Security Class Initialized
DEBUG - 2017-03-02 02:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:45:51 --> Input Class Initialized
INFO - 2017-03-02 02:45:51 --> Language Class Initialized
INFO - 2017-03-02 02:45:51 --> Language Class Initialized
INFO - 2017-03-02 02:45:51 --> Config Class Initialized
INFO - 2017-03-02 02:45:51 --> Loader Class Initialized
INFO - 2017-03-02 02:45:51 --> Helper loaded: form_helper
INFO - 2017-03-02 02:45:51 --> Helper loaded: url_helper
INFO - 2017-03-02 02:45:51 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:45:51 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:45:51 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:45:51 --> Template Class Initialized
INFO - 2017-03-02 02:45:51 --> Model Class Initialized
INFO - 2017-03-02 02:45:51 --> Controller Class Initialized
DEBUG - 2017-03-02 02:45:51 --> Login MX_Controller Initialized
INFO - 2017-03-02 02:45:51 --> Helper loaded: cookie_helper
INFO - 2017-03-02 02:45:51 --> Form Validation Class Initialized
INFO - 2017-03-02 02:45:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-02 02:45:51 --> Config Class Initialized
INFO - 2017-03-02 02:45:51 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:45:51 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:45:51 --> Utf8 Class Initialized
INFO - 2017-03-02 02:45:51 --> URI Class Initialized
INFO - 2017-03-02 02:45:51 --> Router Class Initialized
INFO - 2017-03-02 02:45:51 --> Output Class Initialized
INFO - 2017-03-02 02:45:51 --> Security Class Initialized
DEBUG - 2017-03-02 02:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:45:51 --> Input Class Initialized
INFO - 2017-03-02 02:45:51 --> Language Class Initialized
INFO - 2017-03-02 02:45:51 --> Language Class Initialized
INFO - 2017-03-02 02:45:51 --> Config Class Initialized
INFO - 2017-03-02 02:45:51 --> Loader Class Initialized
INFO - 2017-03-02 02:45:51 --> Helper loaded: form_helper
INFO - 2017-03-02 02:45:51 --> Helper loaded: url_helper
INFO - 2017-03-02 02:45:51 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:45:51 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:45:51 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:45:51 --> Template Class Initialized
INFO - 2017-03-02 02:45:51 --> Model Class Initialized
INFO - 2017-03-02 02:45:51 --> Controller Class Initialized
DEBUG - 2017-03-02 02:45:51 --> Dashboard MX_Controller Initialized
INFO - 2017-03-02 02:45:51 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:45:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-02 02:45:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-03-02 02:45:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-02 02:45:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-02 02:45:51 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-02 02:45:51 --> Final output sent to browser
DEBUG - 2017-03-02 02:45:51 --> Total execution time: 0.0745
INFO - 2017-03-02 02:46:09 --> Config Class Initialized
INFO - 2017-03-02 02:46:09 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:09 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:09 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:09 --> URI Class Initialized
INFO - 2017-03-02 02:46:09 --> Router Class Initialized
INFO - 2017-03-02 02:46:09 --> Output Class Initialized
INFO - 2017-03-02 02:46:09 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:09 --> Input Class Initialized
INFO - 2017-03-02 02:46:09 --> Language Class Initialized
INFO - 2017-03-02 02:46:09 --> Language Class Initialized
INFO - 2017-03-02 02:46:09 --> Config Class Initialized
INFO - 2017-03-02 02:46:09 --> Loader Class Initialized
INFO - 2017-03-02 02:46:09 --> Helper loaded: form_helper
INFO - 2017-03-02 02:46:09 --> Helper loaded: url_helper
INFO - 2017-03-02 02:46:09 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:46:09 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:09 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:46:09 --> Template Class Initialized
INFO - 2017-03-02 02:46:09 --> Model Class Initialized
INFO - 2017-03-02 02:46:09 --> Controller Class Initialized
DEBUG - 2017-03-02 02:46:09 --> Login MX_Controller Initialized
INFO - 2017-03-02 02:46:09 --> Helper loaded: cookie_helper
INFO - 2017-03-02 02:46:09 --> Form Validation Class Initialized
INFO - 2017-03-02 02:46:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-02 02:46:10 --> Config Class Initialized
INFO - 2017-03-02 02:46:10 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:10 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:10 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:10 --> URI Class Initialized
INFO - 2017-03-02 02:46:10 --> Router Class Initialized
INFO - 2017-03-02 02:46:10 --> Output Class Initialized
INFO - 2017-03-02 02:46:10 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:10 --> Input Class Initialized
INFO - 2017-03-02 02:46:10 --> Language Class Initialized
INFO - 2017-03-02 02:46:10 --> Language Class Initialized
INFO - 2017-03-02 02:46:10 --> Config Class Initialized
INFO - 2017-03-02 02:46:10 --> Loader Class Initialized
INFO - 2017-03-02 02:46:10 --> Helper loaded: form_helper
INFO - 2017-03-02 02:46:10 --> Helper loaded: url_helper
INFO - 2017-03-02 02:46:10 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:46:10 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:10 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:46:10 --> Template Class Initialized
INFO - 2017-03-02 02:46:10 --> Model Class Initialized
INFO - 2017-03-02 02:46:10 --> Controller Class Initialized
DEBUG - 2017-03-02 02:46:10 --> Dashboard MX_Controller Initialized
INFO - 2017-03-02 02:46:10 --> Helper loaded: cookie_helper
INFO - 2017-03-02 02:46:10 --> Config Class Initialized
INFO - 2017-03-02 02:46:10 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:10 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:10 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:10 --> URI Class Initialized
DEBUG - 2017-03-02 02:46:10 --> No URI present. Default controller set.
INFO - 2017-03-02 02:46:10 --> Router Class Initialized
INFO - 2017-03-02 02:46:10 --> Output Class Initialized
INFO - 2017-03-02 02:46:10 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:10 --> Input Class Initialized
INFO - 2017-03-02 02:46:10 --> Language Class Initialized
INFO - 2017-03-02 02:46:10 --> Language Class Initialized
INFO - 2017-03-02 02:46:10 --> Config Class Initialized
INFO - 2017-03-02 02:46:10 --> Loader Class Initialized
INFO - 2017-03-02 02:46:10 --> Helper loaded: form_helper
INFO - 2017-03-02 02:46:10 --> Helper loaded: url_helper
INFO - 2017-03-02 02:46:10 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:46:10 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:10 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:46:10 --> Template Class Initialized
INFO - 2017-03-02 02:46:10 --> Model Class Initialized
INFO - 2017-03-02 02:46:10 --> Controller Class Initialized
DEBUG - 2017-03-02 02:46:10 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:46:10 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:46:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:46:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:46:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-02 02:46:10 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:46:10 --> Final output sent to browser
DEBUG - 2017-03-02 02:46:10 --> Total execution time: 0.0142
INFO - 2017-03-02 02:46:10 --> Config Class Initialized
INFO - 2017-03-02 02:46:10 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:10 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:10 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:10 --> URI Class Initialized
INFO - 2017-03-02 02:46:10 --> Router Class Initialized
INFO - 2017-03-02 02:46:10 --> Output Class Initialized
INFO - 2017-03-02 02:46:10 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:10 --> Input Class Initialized
INFO - 2017-03-02 02:46:10 --> Language Class Initialized
INFO - 2017-03-02 02:46:10 --> Language Class Initialized
INFO - 2017-03-02 02:46:10 --> Config Class Initialized
INFO - 2017-03-02 02:46:10 --> Loader Class Initialized
INFO - 2017-03-02 02:46:10 --> Helper loaded: form_helper
INFO - 2017-03-02 02:46:10 --> Helper loaded: url_helper
INFO - 2017-03-02 02:46:10 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:46:10 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:10 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:46:10 --> Template Class Initialized
INFO - 2017-03-02 02:46:10 --> Model Class Initialized
INFO - 2017-03-02 02:46:10 --> Controller Class Initialized
DEBUG - 2017-03-02 02:46:10 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:46:10 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:46:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:46:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:46:11 --> Config Class Initialized
INFO - 2017-03-02 02:46:11 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:11 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:11 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:11 --> URI Class Initialized
INFO - 2017-03-02 02:46:11 --> Router Class Initialized
INFO - 2017-03-02 02:46:11 --> Output Class Initialized
INFO - 2017-03-02 02:46:11 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:11 --> Input Class Initialized
INFO - 2017-03-02 02:46:11 --> Language Class Initialized
INFO - 2017-03-02 02:46:11 --> Language Class Initialized
INFO - 2017-03-02 02:46:11 --> Config Class Initialized
INFO - 2017-03-02 02:46:11 --> Loader Class Initialized
INFO - 2017-03-02 02:46:11 --> Helper loaded: form_helper
INFO - 2017-03-02 02:46:11 --> Helper loaded: url_helper
INFO - 2017-03-02 02:46:11 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:46:11 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:11 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:46:11 --> Template Class Initialized
INFO - 2017-03-02 02:46:11 --> Model Class Initialized
INFO - 2017-03-02 02:46:11 --> Controller Class Initialized
DEBUG - 2017-03-02 02:46:11 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:46:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:46:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:46:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:46:31 --> Config Class Initialized
INFO - 2017-03-02 02:46:31 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:31 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:31 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:31 --> URI Class Initialized
INFO - 2017-03-02 02:46:31 --> Router Class Initialized
INFO - 2017-03-02 02:46:31 --> Output Class Initialized
INFO - 2017-03-02 02:46:31 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:31 --> Input Class Initialized
INFO - 2017-03-02 02:46:31 --> Language Class Initialized
INFO - 2017-03-02 02:46:31 --> Language Class Initialized
INFO - 2017-03-02 02:46:31 --> Config Class Initialized
INFO - 2017-03-02 02:46:31 --> Loader Class Initialized
INFO - 2017-03-02 02:46:31 --> Helper loaded: form_helper
INFO - 2017-03-02 02:46:31 --> Helper loaded: url_helper
INFO - 2017-03-02 02:46:31 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:46:31 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:31 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:46:31 --> Template Class Initialized
INFO - 2017-03-02 02:46:31 --> Model Class Initialized
INFO - 2017-03-02 02:46:31 --> Controller Class Initialized
DEBUG - 2017-03-02 02:46:31 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:46:31 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:46:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:46:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:46:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-02 02:46:31 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:46:31 --> Final output sent to browser
DEBUG - 2017-03-02 02:46:31 --> Total execution time: 0.0135
INFO - 2017-03-02 02:46:32 --> Config Class Initialized
INFO - 2017-03-02 02:46:32 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:32 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:32 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:32 --> URI Class Initialized
INFO - 2017-03-02 02:46:32 --> Router Class Initialized
INFO - 2017-03-02 02:46:32 --> Output Class Initialized
INFO - 2017-03-02 02:46:32 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:32 --> Input Class Initialized
INFO - 2017-03-02 02:46:32 --> Language Class Initialized
INFO - 2017-03-02 02:46:32 --> Language Class Initialized
INFO - 2017-03-02 02:46:32 --> Config Class Initialized
INFO - 2017-03-02 02:46:32 --> Loader Class Initialized
INFO - 2017-03-02 02:46:32 --> Helper loaded: form_helper
INFO - 2017-03-02 02:46:32 --> Helper loaded: url_helper
INFO - 2017-03-02 02:46:32 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:46:32 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:32 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:46:32 --> Template Class Initialized
INFO - 2017-03-02 02:46:32 --> Model Class Initialized
INFO - 2017-03-02 02:46:32 --> Controller Class Initialized
DEBUG - 2017-03-02 02:46:32 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:46:32 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:46:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:46:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:46:38 --> Config Class Initialized
INFO - 2017-03-02 02:46:38 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:38 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:38 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:38 --> URI Class Initialized
INFO - 2017-03-02 02:46:38 --> Router Class Initialized
INFO - 2017-03-02 02:46:38 --> Output Class Initialized
INFO - 2017-03-02 02:46:38 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:38 --> Input Class Initialized
INFO - 2017-03-02 02:46:38 --> Language Class Initialized
INFO - 2017-03-02 02:46:38 --> Language Class Initialized
INFO - 2017-03-02 02:46:38 --> Config Class Initialized
INFO - 2017-03-02 02:46:38 --> Loader Class Initialized
INFO - 2017-03-02 02:46:38 --> Helper loaded: form_helper
INFO - 2017-03-02 02:46:38 --> Helper loaded: url_helper
INFO - 2017-03-02 02:46:38 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:46:38 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:38 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:46:38 --> Template Class Initialized
INFO - 2017-03-02 02:46:38 --> Model Class Initialized
INFO - 2017-03-02 02:46:38 --> Controller Class Initialized
DEBUG - 2017-03-02 02:46:38 --> Login MX_Controller Initialized
INFO - 2017-03-02 02:46:38 --> Helper loaded: cookie_helper
INFO - 2017-03-02 02:46:38 --> Form Validation Class Initialized
INFO - 2017-03-02 02:46:39 --> Config Class Initialized
INFO - 2017-03-02 02:46:39 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:39 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:39 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:39 --> URI Class Initialized
DEBUG - 2017-03-02 02:46:39 --> No URI present. Default controller set.
INFO - 2017-03-02 02:46:39 --> Router Class Initialized
INFO - 2017-03-02 02:46:39 --> Output Class Initialized
INFO - 2017-03-02 02:46:39 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:39 --> Input Class Initialized
INFO - 2017-03-02 02:46:39 --> Language Class Initialized
INFO - 2017-03-02 02:46:39 --> Language Class Initialized
INFO - 2017-03-02 02:46:39 --> Config Class Initialized
INFO - 2017-03-02 02:46:39 --> Loader Class Initialized
INFO - 2017-03-02 02:46:39 --> Helper loaded: form_helper
INFO - 2017-03-02 02:46:39 --> Helper loaded: url_helper
INFO - 2017-03-02 02:46:39 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:46:39 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:39 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:46:39 --> Template Class Initialized
INFO - 2017-03-02 02:46:39 --> Model Class Initialized
INFO - 2017-03-02 02:46:39 --> Controller Class Initialized
DEBUG - 2017-03-02 02:46:39 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:46:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:46:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:46:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:46:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-02 02:46:39 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:46:39 --> Final output sent to browser
DEBUG - 2017-03-02 02:46:39 --> Total execution time: 0.0135
INFO - 2017-03-02 02:46:39 --> Config Class Initialized
INFO - 2017-03-02 02:46:39 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:39 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:39 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:39 --> URI Class Initialized
INFO - 2017-03-02 02:46:39 --> Router Class Initialized
INFO - 2017-03-02 02:46:39 --> Output Class Initialized
INFO - 2017-03-02 02:46:39 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:39 --> Input Class Initialized
INFO - 2017-03-02 02:46:39 --> Language Class Initialized
INFO - 2017-03-02 02:46:39 --> Language Class Initialized
INFO - 2017-03-02 02:46:39 --> Config Class Initialized
INFO - 2017-03-02 02:46:39 --> Loader Class Initialized
INFO - 2017-03-02 02:46:39 --> Helper loaded: form_helper
INFO - 2017-03-02 02:46:39 --> Helper loaded: url_helper
INFO - 2017-03-02 02:46:39 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:46:39 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:39 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:46:39 --> Template Class Initialized
INFO - 2017-03-02 02:46:39 --> Model Class Initialized
INFO - 2017-03-02 02:46:39 --> Controller Class Initialized
DEBUG - 2017-03-02 02:46:39 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:46:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:46:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:46:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:46:39 --> Config Class Initialized
INFO - 2017-03-02 02:46:39 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:39 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:39 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:39 --> URI Class Initialized
INFO - 2017-03-02 02:46:39 --> Router Class Initialized
INFO - 2017-03-02 02:46:39 --> Output Class Initialized
INFO - 2017-03-02 02:46:39 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:39 --> Input Class Initialized
INFO - 2017-03-02 02:46:39 --> Language Class Initialized
INFO - 2017-03-02 02:46:39 --> Language Class Initialized
INFO - 2017-03-02 02:46:39 --> Config Class Initialized
INFO - 2017-03-02 02:46:39 --> Loader Class Initialized
INFO - 2017-03-02 02:46:39 --> Helper loaded: form_helper
INFO - 2017-03-02 02:46:39 --> Helper loaded: url_helper
INFO - 2017-03-02 02:46:39 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:46:39 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:39 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:46:39 --> Template Class Initialized
INFO - 2017-03-02 02:46:39 --> Model Class Initialized
INFO - 2017-03-02 02:46:39 --> Controller Class Initialized
DEBUG - 2017-03-02 02:46:39 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:46:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:46:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:46:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:46:43 --> Config Class Initialized
INFO - 2017-03-02 02:46:43 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:43 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:43 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:43 --> URI Class Initialized
INFO - 2017-03-02 02:46:43 --> Router Class Initialized
INFO - 2017-03-02 02:46:43 --> Output Class Initialized
INFO - 2017-03-02 02:46:43 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:43 --> Input Class Initialized
INFO - 2017-03-02 02:46:43 --> Language Class Initialized
INFO - 2017-03-02 02:46:43 --> Language Class Initialized
INFO - 2017-03-02 02:46:43 --> Config Class Initialized
INFO - 2017-03-02 02:46:43 --> Loader Class Initialized
INFO - 2017-03-02 02:46:43 --> Helper loaded: form_helper
INFO - 2017-03-02 02:46:43 --> Helper loaded: url_helper
INFO - 2017-03-02 02:46:43 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:46:43 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:43 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:46:43 --> Template Class Initialized
INFO - 2017-03-02 02:46:43 --> Model Class Initialized
INFO - 2017-03-02 02:46:43 --> Controller Class Initialized
DEBUG - 2017-03-02 02:46:43 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:46:43 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:46:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:46:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:46:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-02 02:46:43 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:46:43 --> Final output sent to browser
DEBUG - 2017-03-02 02:46:43 --> Total execution time: 0.0146
INFO - 2017-03-02 02:46:44 --> Config Class Initialized
INFO - 2017-03-02 02:46:44 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:44 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:44 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:44 --> URI Class Initialized
INFO - 2017-03-02 02:46:44 --> Router Class Initialized
INFO - 2017-03-02 02:46:44 --> Output Class Initialized
INFO - 2017-03-02 02:46:44 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:44 --> Input Class Initialized
INFO - 2017-03-02 02:46:44 --> Language Class Initialized
INFO - 2017-03-02 02:46:44 --> Language Class Initialized
INFO - 2017-03-02 02:46:44 --> Config Class Initialized
INFO - 2017-03-02 02:46:44 --> Loader Class Initialized
INFO - 2017-03-02 02:46:44 --> Helper loaded: form_helper
INFO - 2017-03-02 02:46:44 --> Helper loaded: url_helper
INFO - 2017-03-02 02:46:44 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:46:44 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:44 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:46:44 --> Template Class Initialized
INFO - 2017-03-02 02:46:44 --> Model Class Initialized
INFO - 2017-03-02 02:46:44 --> Controller Class Initialized
DEBUG - 2017-03-02 02:46:44 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:46:44 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:46:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:46:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:46:52 --> Config Class Initialized
INFO - 2017-03-02 02:46:52 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:52 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:52 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:52 --> URI Class Initialized
INFO - 2017-03-02 02:46:52 --> Router Class Initialized
INFO - 2017-03-02 02:46:52 --> Output Class Initialized
INFO - 2017-03-02 02:46:52 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:52 --> Input Class Initialized
INFO - 2017-03-02 02:46:52 --> Language Class Initialized
INFO - 2017-03-02 02:46:52 --> Language Class Initialized
INFO - 2017-03-02 02:46:52 --> Config Class Initialized
INFO - 2017-03-02 02:46:52 --> Loader Class Initialized
INFO - 2017-03-02 02:46:52 --> Helper loaded: form_helper
INFO - 2017-03-02 02:46:52 --> Helper loaded: url_helper
INFO - 2017-03-02 02:46:52 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:46:52 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:52 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:46:52 --> Template Class Initialized
INFO - 2017-03-02 02:46:52 --> Model Class Initialized
INFO - 2017-03-02 02:46:52 --> Controller Class Initialized
DEBUG - 2017-03-02 02:46:52 --> Login MX_Controller Initialized
INFO - 2017-03-02 02:46:52 --> Helper loaded: cookie_helper
INFO - 2017-03-02 02:46:52 --> Form Validation Class Initialized
INFO - 2017-03-02 02:46:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-02 02:46:52 --> Config Class Initialized
INFO - 2017-03-02 02:46:52 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:52 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:52 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:52 --> URI Class Initialized
INFO - 2017-03-02 02:46:52 --> Router Class Initialized
INFO - 2017-03-02 02:46:52 --> Output Class Initialized
INFO - 2017-03-02 02:46:52 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:52 --> Input Class Initialized
INFO - 2017-03-02 02:46:52 --> Language Class Initialized
INFO - 2017-03-02 02:46:52 --> Language Class Initialized
INFO - 2017-03-02 02:46:52 --> Config Class Initialized
INFO - 2017-03-02 02:46:52 --> Loader Class Initialized
INFO - 2017-03-02 02:46:52 --> Helper loaded: form_helper
INFO - 2017-03-02 02:46:52 --> Helper loaded: url_helper
INFO - 2017-03-02 02:46:52 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:46:52 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:52 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:46:52 --> Template Class Initialized
INFO - 2017-03-02 02:46:52 --> Model Class Initialized
INFO - 2017-03-02 02:46:52 --> Controller Class Initialized
DEBUG - 2017-03-02 02:46:52 --> Dashboard MX_Controller Initialized
INFO - 2017-03-02 02:46:52 --> Helper loaded: cookie_helper
INFO - 2017-03-02 02:46:52 --> Config Class Initialized
INFO - 2017-03-02 02:46:52 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:52 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:52 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:52 --> URI Class Initialized
DEBUG - 2017-03-02 02:46:52 --> No URI present. Default controller set.
INFO - 2017-03-02 02:46:52 --> Router Class Initialized
INFO - 2017-03-02 02:46:52 --> Output Class Initialized
INFO - 2017-03-02 02:46:52 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:52 --> Input Class Initialized
INFO - 2017-03-02 02:46:52 --> Language Class Initialized
INFO - 2017-03-02 02:46:52 --> Language Class Initialized
INFO - 2017-03-02 02:46:52 --> Config Class Initialized
INFO - 2017-03-02 02:46:52 --> Loader Class Initialized
INFO - 2017-03-02 02:46:52 --> Helper loaded: form_helper
INFO - 2017-03-02 02:46:52 --> Helper loaded: url_helper
INFO - 2017-03-02 02:46:52 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:46:52 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:52 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:46:52 --> Template Class Initialized
INFO - 2017-03-02 02:46:52 --> Model Class Initialized
INFO - 2017-03-02 02:46:52 --> Controller Class Initialized
DEBUG - 2017-03-02 02:46:52 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:46:52 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:46:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:46:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:46:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-02 02:46:52 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:46:52 --> Final output sent to browser
DEBUG - 2017-03-02 02:46:52 --> Total execution time: 0.0144
INFO - 2017-03-02 02:46:53 --> Config Class Initialized
INFO - 2017-03-02 02:46:53 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:53 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:53 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:53 --> URI Class Initialized
INFO - 2017-03-02 02:46:53 --> Router Class Initialized
INFO - 2017-03-02 02:46:53 --> Output Class Initialized
INFO - 2017-03-02 02:46:53 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:53 --> Input Class Initialized
INFO - 2017-03-02 02:46:53 --> Language Class Initialized
INFO - 2017-03-02 02:46:53 --> Language Class Initialized
INFO - 2017-03-02 02:46:53 --> Config Class Initialized
INFO - 2017-03-02 02:46:53 --> Loader Class Initialized
INFO - 2017-03-02 02:46:53 --> Helper loaded: form_helper
INFO - 2017-03-02 02:46:53 --> Helper loaded: url_helper
INFO - 2017-03-02 02:46:53 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:46:53 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:53 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:46:53 --> Template Class Initialized
INFO - 2017-03-02 02:46:53 --> Model Class Initialized
INFO - 2017-03-02 02:46:53 --> Controller Class Initialized
DEBUG - 2017-03-02 02:46:53 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:46:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:46:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:46:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:46:53 --> Config Class Initialized
INFO - 2017-03-02 02:46:53 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:46:53 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:46:53 --> Utf8 Class Initialized
INFO - 2017-03-02 02:46:53 --> URI Class Initialized
INFO - 2017-03-02 02:46:53 --> Router Class Initialized
INFO - 2017-03-02 02:46:53 --> Output Class Initialized
INFO - 2017-03-02 02:46:53 --> Security Class Initialized
DEBUG - 2017-03-02 02:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:46:53 --> Input Class Initialized
INFO - 2017-03-02 02:46:53 --> Language Class Initialized
INFO - 2017-03-02 02:46:53 --> Language Class Initialized
INFO - 2017-03-02 02:46:53 --> Config Class Initialized
INFO - 2017-03-02 02:46:53 --> Loader Class Initialized
INFO - 2017-03-02 02:46:53 --> Helper loaded: form_helper
INFO - 2017-03-02 02:46:53 --> Helper loaded: url_helper
INFO - 2017-03-02 02:46:53 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:46:53 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:46:53 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:46:53 --> Template Class Initialized
INFO - 2017-03-02 02:46:53 --> Model Class Initialized
INFO - 2017-03-02 02:46:53 --> Controller Class Initialized
DEBUG - 2017-03-02 02:46:53 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:46:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:46:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:46:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:47:13 --> Config Class Initialized
INFO - 2017-03-02 02:47:13 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:47:13 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:47:13 --> Utf8 Class Initialized
INFO - 2017-03-02 02:47:13 --> URI Class Initialized
INFO - 2017-03-02 02:47:13 --> Router Class Initialized
INFO - 2017-03-02 02:47:13 --> Output Class Initialized
INFO - 2017-03-02 02:47:13 --> Security Class Initialized
DEBUG - 2017-03-02 02:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:47:13 --> Input Class Initialized
INFO - 2017-03-02 02:47:13 --> Language Class Initialized
INFO - 2017-03-02 02:47:13 --> Language Class Initialized
INFO - 2017-03-02 02:47:13 --> Config Class Initialized
INFO - 2017-03-02 02:47:13 --> Loader Class Initialized
INFO - 2017-03-02 02:47:13 --> Helper loaded: form_helper
INFO - 2017-03-02 02:47:13 --> Helper loaded: url_helper
INFO - 2017-03-02 02:47:13 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:47:13 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:47:13 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:47:13 --> Template Class Initialized
INFO - 2017-03-02 02:47:13 --> Model Class Initialized
INFO - 2017-03-02 02:47:13 --> Controller Class Initialized
DEBUG - 2017-03-02 02:47:13 --> Login MX_Controller Initialized
INFO - 2017-03-02 02:47:13 --> Helper loaded: cookie_helper
INFO - 2017-03-02 02:47:13 --> Form Validation Class Initialized
INFO - 2017-03-02 02:47:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-02 02:47:14 --> Config Class Initialized
INFO - 2017-03-02 02:47:14 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:47:14 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:47:14 --> Utf8 Class Initialized
INFO - 2017-03-02 02:47:14 --> URI Class Initialized
INFO - 2017-03-02 02:47:14 --> Router Class Initialized
INFO - 2017-03-02 02:47:14 --> Output Class Initialized
INFO - 2017-03-02 02:47:14 --> Security Class Initialized
DEBUG - 2017-03-02 02:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:47:14 --> Input Class Initialized
INFO - 2017-03-02 02:47:14 --> Language Class Initialized
INFO - 2017-03-02 02:47:14 --> Language Class Initialized
INFO - 2017-03-02 02:47:14 --> Config Class Initialized
INFO - 2017-03-02 02:47:14 --> Loader Class Initialized
INFO - 2017-03-02 02:47:14 --> Helper loaded: form_helper
INFO - 2017-03-02 02:47:14 --> Helper loaded: url_helper
INFO - 2017-03-02 02:47:14 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:47:14 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:47:14 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:47:14 --> Template Class Initialized
INFO - 2017-03-02 02:47:14 --> Model Class Initialized
INFO - 2017-03-02 02:47:14 --> Controller Class Initialized
DEBUG - 2017-03-02 02:47:14 --> Dashboard MX_Controller Initialized
INFO - 2017-03-02 02:47:14 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:47:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-02 02:47:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-02 02:47:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-02 02:47:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-02 02:47:14 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-02 02:47:14 --> Final output sent to browser
DEBUG - 2017-03-02 02:47:14 --> Total execution time: 0.0239
INFO - 2017-03-02 02:47:21 --> Config Class Initialized
INFO - 2017-03-02 02:47:21 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:47:21 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:47:21 --> Utf8 Class Initialized
INFO - 2017-03-02 02:47:21 --> URI Class Initialized
INFO - 2017-03-02 02:47:21 --> Router Class Initialized
INFO - 2017-03-02 02:47:21 --> Output Class Initialized
INFO - 2017-03-02 02:47:21 --> Security Class Initialized
DEBUG - 2017-03-02 02:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:47:21 --> Input Class Initialized
INFO - 2017-03-02 02:47:21 --> Language Class Initialized
INFO - 2017-03-02 02:47:21 --> Language Class Initialized
INFO - 2017-03-02 02:47:21 --> Config Class Initialized
INFO - 2017-03-02 02:47:21 --> Loader Class Initialized
INFO - 2017-03-02 02:47:21 --> Helper loaded: form_helper
INFO - 2017-03-02 02:47:21 --> Helper loaded: url_helper
INFO - 2017-03-02 02:47:21 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:47:21 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:47:21 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:47:21 --> Template Class Initialized
INFO - 2017-03-02 02:47:21 --> Model Class Initialized
INFO - 2017-03-02 02:47:21 --> Controller Class Initialized
DEBUG - 2017-03-02 02:47:21 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:47:21 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:47:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:47:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:47:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-02 02:47:21 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:47:21 --> Final output sent to browser
DEBUG - 2017-03-02 02:47:21 --> Total execution time: 0.0147
INFO - 2017-03-02 02:47:22 --> Config Class Initialized
INFO - 2017-03-02 02:47:22 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:47:22 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:47:22 --> Utf8 Class Initialized
INFO - 2017-03-02 02:47:22 --> URI Class Initialized
INFO - 2017-03-02 02:47:22 --> Router Class Initialized
INFO - 2017-03-02 02:47:22 --> Output Class Initialized
INFO - 2017-03-02 02:47:22 --> Security Class Initialized
DEBUG - 2017-03-02 02:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:47:22 --> Input Class Initialized
INFO - 2017-03-02 02:47:22 --> Language Class Initialized
INFO - 2017-03-02 02:47:22 --> Language Class Initialized
INFO - 2017-03-02 02:47:22 --> Config Class Initialized
INFO - 2017-03-02 02:47:22 --> Loader Class Initialized
INFO - 2017-03-02 02:47:22 --> Helper loaded: form_helper
INFO - 2017-03-02 02:47:22 --> Helper loaded: url_helper
INFO - 2017-03-02 02:47:22 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:47:22 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:47:22 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:47:22 --> Template Class Initialized
INFO - 2017-03-02 02:47:22 --> Model Class Initialized
INFO - 2017-03-02 02:47:22 --> Controller Class Initialized
DEBUG - 2017-03-02 02:47:22 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:47:22 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:47:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:47:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:47:34 --> Config Class Initialized
INFO - 2017-03-02 02:47:34 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:47:34 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:47:34 --> Utf8 Class Initialized
INFO - 2017-03-02 02:47:34 --> URI Class Initialized
INFO - 2017-03-02 02:47:34 --> Router Class Initialized
INFO - 2017-03-02 02:47:34 --> Output Class Initialized
INFO - 2017-03-02 02:47:34 --> Security Class Initialized
DEBUG - 2017-03-02 02:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:47:34 --> Input Class Initialized
INFO - 2017-03-02 02:47:34 --> Language Class Initialized
INFO - 2017-03-02 02:47:34 --> Language Class Initialized
INFO - 2017-03-02 02:47:34 --> Config Class Initialized
INFO - 2017-03-02 02:47:34 --> Loader Class Initialized
INFO - 2017-03-02 02:47:34 --> Helper loaded: form_helper
INFO - 2017-03-02 02:47:34 --> Helper loaded: url_helper
INFO - 2017-03-02 02:47:34 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:47:34 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:47:34 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:47:34 --> Template Class Initialized
INFO - 2017-03-02 02:47:34 --> Model Class Initialized
INFO - 2017-03-02 02:47:34 --> Controller Class Initialized
DEBUG - 2017-03-02 02:47:34 --> Login MX_Controller Initialized
INFO - 2017-03-02 02:47:34 --> Helper loaded: cookie_helper
INFO - 2017-03-02 02:47:34 --> Form Validation Class Initialized
INFO - 2017-03-02 02:47:34 --> Config Class Initialized
INFO - 2017-03-02 02:47:34 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:47:34 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:47:34 --> Utf8 Class Initialized
INFO - 2017-03-02 02:47:34 --> URI Class Initialized
DEBUG - 2017-03-02 02:47:34 --> No URI present. Default controller set.
INFO - 2017-03-02 02:47:34 --> Router Class Initialized
INFO - 2017-03-02 02:47:34 --> Output Class Initialized
INFO - 2017-03-02 02:47:34 --> Security Class Initialized
DEBUG - 2017-03-02 02:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:47:34 --> Input Class Initialized
INFO - 2017-03-02 02:47:34 --> Language Class Initialized
INFO - 2017-03-02 02:47:34 --> Language Class Initialized
INFO - 2017-03-02 02:47:34 --> Config Class Initialized
INFO - 2017-03-02 02:47:34 --> Loader Class Initialized
INFO - 2017-03-02 02:47:34 --> Helper loaded: form_helper
INFO - 2017-03-02 02:47:34 --> Helper loaded: url_helper
INFO - 2017-03-02 02:47:34 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:47:34 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:47:34 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:47:34 --> Template Class Initialized
INFO - 2017-03-02 02:47:34 --> Model Class Initialized
INFO - 2017-03-02 02:47:34 --> Controller Class Initialized
DEBUG - 2017-03-02 02:47:34 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:47:34 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:47:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:47:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:47:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-02 02:47:34 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:47:34 --> Final output sent to browser
DEBUG - 2017-03-02 02:47:34 --> Total execution time: 0.0137
INFO - 2017-03-02 02:47:34 --> Config Class Initialized
INFO - 2017-03-02 02:47:34 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:47:34 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:47:34 --> Utf8 Class Initialized
INFO - 2017-03-02 02:47:34 --> URI Class Initialized
INFO - 2017-03-02 02:47:34 --> Router Class Initialized
INFO - 2017-03-02 02:47:34 --> Output Class Initialized
INFO - 2017-03-02 02:47:34 --> Security Class Initialized
DEBUG - 2017-03-02 02:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:47:34 --> Input Class Initialized
INFO - 2017-03-02 02:47:34 --> Language Class Initialized
INFO - 2017-03-02 02:47:34 --> Language Class Initialized
INFO - 2017-03-02 02:47:34 --> Config Class Initialized
INFO - 2017-03-02 02:47:34 --> Loader Class Initialized
INFO - 2017-03-02 02:47:34 --> Helper loaded: form_helper
INFO - 2017-03-02 02:47:34 --> Helper loaded: url_helper
INFO - 2017-03-02 02:47:34 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:47:34 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:47:34 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:47:34 --> Template Class Initialized
INFO - 2017-03-02 02:47:34 --> Model Class Initialized
INFO - 2017-03-02 02:47:34 --> Controller Class Initialized
DEBUG - 2017-03-02 02:47:34 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:47:34 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:47:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:47:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:47:35 --> Config Class Initialized
INFO - 2017-03-02 02:47:35 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:47:35 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:47:35 --> Utf8 Class Initialized
INFO - 2017-03-02 02:47:35 --> URI Class Initialized
INFO - 2017-03-02 02:47:35 --> Router Class Initialized
INFO - 2017-03-02 02:47:35 --> Output Class Initialized
INFO - 2017-03-02 02:47:35 --> Security Class Initialized
DEBUG - 2017-03-02 02:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:47:35 --> Input Class Initialized
INFO - 2017-03-02 02:47:35 --> Language Class Initialized
INFO - 2017-03-02 02:47:35 --> Language Class Initialized
INFO - 2017-03-02 02:47:35 --> Config Class Initialized
INFO - 2017-03-02 02:47:35 --> Loader Class Initialized
INFO - 2017-03-02 02:47:35 --> Helper loaded: form_helper
INFO - 2017-03-02 02:47:35 --> Helper loaded: url_helper
INFO - 2017-03-02 02:47:35 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:47:35 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:47:35 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:47:35 --> Template Class Initialized
INFO - 2017-03-02 02:47:35 --> Model Class Initialized
INFO - 2017-03-02 02:47:35 --> Controller Class Initialized
DEBUG - 2017-03-02 02:47:35 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:47:35 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:47:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:47:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:47:42 --> Config Class Initialized
INFO - 2017-03-02 02:47:42 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:47:42 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:47:42 --> Utf8 Class Initialized
INFO - 2017-03-02 02:47:42 --> URI Class Initialized
INFO - 2017-03-02 02:47:42 --> Router Class Initialized
INFO - 2017-03-02 02:47:42 --> Output Class Initialized
INFO - 2017-03-02 02:47:42 --> Security Class Initialized
DEBUG - 2017-03-02 02:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:47:42 --> Input Class Initialized
INFO - 2017-03-02 02:47:42 --> Language Class Initialized
INFO - 2017-03-02 02:47:42 --> Language Class Initialized
INFO - 2017-03-02 02:47:42 --> Config Class Initialized
INFO - 2017-03-02 02:47:42 --> Loader Class Initialized
INFO - 2017-03-02 02:47:42 --> Helper loaded: form_helper
INFO - 2017-03-02 02:47:42 --> Helper loaded: url_helper
INFO - 2017-03-02 02:47:42 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:47:42 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:47:42 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:47:42 --> Template Class Initialized
INFO - 2017-03-02 02:47:42 --> Model Class Initialized
INFO - 2017-03-02 02:47:42 --> Controller Class Initialized
DEBUG - 2017-03-02 02:47:42 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:47:42 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:47:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:47:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:47:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-02 02:47:42 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:47:42 --> Final output sent to browser
DEBUG - 2017-03-02 02:47:42 --> Total execution time: 0.0143
INFO - 2017-03-02 02:47:42 --> Config Class Initialized
INFO - 2017-03-02 02:47:42 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:47:42 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:47:42 --> Utf8 Class Initialized
INFO - 2017-03-02 02:47:42 --> URI Class Initialized
INFO - 2017-03-02 02:47:42 --> Router Class Initialized
INFO - 2017-03-02 02:47:42 --> Output Class Initialized
INFO - 2017-03-02 02:47:42 --> Security Class Initialized
DEBUG - 2017-03-02 02:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:47:42 --> Input Class Initialized
INFO - 2017-03-02 02:47:42 --> Language Class Initialized
INFO - 2017-03-02 02:47:42 --> Language Class Initialized
INFO - 2017-03-02 02:47:42 --> Config Class Initialized
INFO - 2017-03-02 02:47:42 --> Loader Class Initialized
INFO - 2017-03-02 02:47:42 --> Helper loaded: form_helper
INFO - 2017-03-02 02:47:42 --> Helper loaded: url_helper
INFO - 2017-03-02 02:47:42 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:47:42 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:47:42 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:47:42 --> Template Class Initialized
INFO - 2017-03-02 02:47:42 --> Model Class Initialized
INFO - 2017-03-02 02:47:42 --> Controller Class Initialized
DEBUG - 2017-03-02 02:47:42 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:47:42 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:47:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:47:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:48:17 --> Config Class Initialized
INFO - 2017-03-02 02:48:17 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:48:17 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:48:17 --> Utf8 Class Initialized
INFO - 2017-03-02 02:48:17 --> URI Class Initialized
INFO - 2017-03-02 02:48:17 --> Router Class Initialized
INFO - 2017-03-02 02:48:17 --> Output Class Initialized
INFO - 2017-03-02 02:48:17 --> Security Class Initialized
DEBUG - 2017-03-02 02:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:48:17 --> Input Class Initialized
INFO - 2017-03-02 02:48:17 --> Language Class Initialized
INFO - 2017-03-02 02:48:17 --> Language Class Initialized
INFO - 2017-03-02 02:48:17 --> Config Class Initialized
INFO - 2017-03-02 02:48:17 --> Loader Class Initialized
INFO - 2017-03-02 02:48:17 --> Helper loaded: form_helper
INFO - 2017-03-02 02:48:17 --> Helper loaded: url_helper
INFO - 2017-03-02 02:48:17 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:48:17 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:48:17 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:48:17 --> Template Class Initialized
INFO - 2017-03-02 02:48:17 --> Model Class Initialized
INFO - 2017-03-02 02:48:17 --> Controller Class Initialized
DEBUG - 2017-03-02 02:48:17 --> Login MX_Controller Initialized
INFO - 2017-03-02 02:48:17 --> Helper loaded: cookie_helper
INFO - 2017-03-02 02:48:17 --> Form Validation Class Initialized
INFO - 2017-03-02 02:48:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-02 02:48:17 --> Config Class Initialized
INFO - 2017-03-02 02:48:17 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:48:17 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:48:17 --> Utf8 Class Initialized
INFO - 2017-03-02 02:48:17 --> URI Class Initialized
INFO - 2017-03-02 02:48:17 --> Router Class Initialized
INFO - 2017-03-02 02:48:17 --> Output Class Initialized
INFO - 2017-03-02 02:48:17 --> Security Class Initialized
DEBUG - 2017-03-02 02:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:48:17 --> Input Class Initialized
INFO - 2017-03-02 02:48:17 --> Language Class Initialized
INFO - 2017-03-02 02:48:17 --> Language Class Initialized
INFO - 2017-03-02 02:48:17 --> Config Class Initialized
INFO - 2017-03-02 02:48:17 --> Loader Class Initialized
INFO - 2017-03-02 02:48:17 --> Helper loaded: form_helper
INFO - 2017-03-02 02:48:17 --> Helper loaded: url_helper
INFO - 2017-03-02 02:48:17 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:48:17 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:48:17 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:48:17 --> Template Class Initialized
INFO - 2017-03-02 02:48:17 --> Model Class Initialized
INFO - 2017-03-02 02:48:17 --> Controller Class Initialized
DEBUG - 2017-03-02 02:48:17 --> Dashboard MX_Controller Initialized
INFO - 2017-03-02 02:48:17 --> Helper loaded: cookie_helper
INFO - 2017-03-02 02:48:18 --> Config Class Initialized
INFO - 2017-03-02 02:48:18 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:48:18 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:48:18 --> Utf8 Class Initialized
INFO - 2017-03-02 02:48:18 --> URI Class Initialized
DEBUG - 2017-03-02 02:48:18 --> No URI present. Default controller set.
INFO - 2017-03-02 02:48:18 --> Router Class Initialized
INFO - 2017-03-02 02:48:18 --> Output Class Initialized
INFO - 2017-03-02 02:48:18 --> Security Class Initialized
DEBUG - 2017-03-02 02:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:48:18 --> Input Class Initialized
INFO - 2017-03-02 02:48:18 --> Language Class Initialized
INFO - 2017-03-02 02:48:18 --> Language Class Initialized
INFO - 2017-03-02 02:48:18 --> Config Class Initialized
INFO - 2017-03-02 02:48:18 --> Loader Class Initialized
INFO - 2017-03-02 02:48:18 --> Helper loaded: form_helper
INFO - 2017-03-02 02:48:18 --> Helper loaded: url_helper
INFO - 2017-03-02 02:48:18 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:48:18 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:48:18 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:48:18 --> Template Class Initialized
INFO - 2017-03-02 02:48:18 --> Model Class Initialized
INFO - 2017-03-02 02:48:18 --> Controller Class Initialized
DEBUG - 2017-03-02 02:48:18 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:48:18 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:48:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:48:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 02:48:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-02 02:48:18 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 02:48:18 --> Final output sent to browser
DEBUG - 2017-03-02 02:48:18 --> Total execution time: 0.0163
INFO - 2017-03-02 02:48:18 --> Config Class Initialized
INFO - 2017-03-02 02:48:18 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:48:18 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:48:18 --> Utf8 Class Initialized
INFO - 2017-03-02 02:48:18 --> URI Class Initialized
INFO - 2017-03-02 02:48:18 --> Router Class Initialized
INFO - 2017-03-02 02:48:18 --> Output Class Initialized
INFO - 2017-03-02 02:48:18 --> Security Class Initialized
DEBUG - 2017-03-02 02:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:48:18 --> Input Class Initialized
INFO - 2017-03-02 02:48:18 --> Language Class Initialized
INFO - 2017-03-02 02:48:18 --> Language Class Initialized
INFO - 2017-03-02 02:48:18 --> Config Class Initialized
INFO - 2017-03-02 02:48:18 --> Loader Class Initialized
INFO - 2017-03-02 02:48:18 --> Helper loaded: form_helper
INFO - 2017-03-02 02:48:18 --> Helper loaded: url_helper
INFO - 2017-03-02 02:48:18 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:48:18 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:48:18 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:48:18 --> Template Class Initialized
INFO - 2017-03-02 02:48:18 --> Model Class Initialized
INFO - 2017-03-02 02:48:18 --> Controller Class Initialized
DEBUG - 2017-03-02 02:48:18 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:48:18 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:48:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:48:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 02:48:18 --> Config Class Initialized
INFO - 2017-03-02 02:48:18 --> Hooks Class Initialized
DEBUG - 2017-03-02 02:48:18 --> UTF-8 Support Enabled
INFO - 2017-03-02 02:48:18 --> Utf8 Class Initialized
INFO - 2017-03-02 02:48:18 --> URI Class Initialized
INFO - 2017-03-02 02:48:18 --> Router Class Initialized
INFO - 2017-03-02 02:48:18 --> Output Class Initialized
INFO - 2017-03-02 02:48:18 --> Security Class Initialized
DEBUG - 2017-03-02 02:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 02:48:18 --> Input Class Initialized
INFO - 2017-03-02 02:48:18 --> Language Class Initialized
INFO - 2017-03-02 02:48:18 --> Language Class Initialized
INFO - 2017-03-02 02:48:18 --> Config Class Initialized
INFO - 2017-03-02 02:48:18 --> Loader Class Initialized
INFO - 2017-03-02 02:48:18 --> Helper loaded: form_helper
INFO - 2017-03-02 02:48:18 --> Helper loaded: url_helper
INFO - 2017-03-02 02:48:18 --> Helper loaded: utility_helper
INFO - 2017-03-02 02:48:18 --> Database Driver Class Initialized
DEBUG - 2017-03-02 02:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 02:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 02:48:18 --> User Agent Class Initialized
DEBUG - 2017-03-02 02:48:18 --> Template Class Initialized
INFO - 2017-03-02 02:48:18 --> Model Class Initialized
INFO - 2017-03-02 02:48:18 --> Controller Class Initialized
DEBUG - 2017-03-02 02:48:18 --> Pages MX_Controller Initialized
INFO - 2017-03-02 02:48:18 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 02:48:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 02:48:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 03:15:02 --> Config Class Initialized
INFO - 2017-03-02 03:15:02 --> Hooks Class Initialized
DEBUG - 2017-03-02 03:15:02 --> UTF-8 Support Enabled
INFO - 2017-03-02 03:15:02 --> Utf8 Class Initialized
INFO - 2017-03-02 03:15:02 --> URI Class Initialized
INFO - 2017-03-02 03:15:02 --> Router Class Initialized
INFO - 2017-03-02 03:15:02 --> Output Class Initialized
INFO - 2017-03-02 03:15:02 --> Security Class Initialized
DEBUG - 2017-03-02 03:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 03:15:02 --> Input Class Initialized
INFO - 2017-03-02 03:15:02 --> Language Class Initialized
INFO - 2017-03-02 03:15:02 --> Language Class Initialized
INFO - 2017-03-02 03:15:02 --> Config Class Initialized
INFO - 2017-03-02 03:15:02 --> Loader Class Initialized
INFO - 2017-03-02 03:15:02 --> Helper loaded: form_helper
INFO - 2017-03-02 03:15:02 --> Helper loaded: url_helper
INFO - 2017-03-02 03:15:02 --> Helper loaded: utility_helper
INFO - 2017-03-02 03:15:02 --> Database Driver Class Initialized
DEBUG - 2017-03-02 03:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 03:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 03:15:02 --> User Agent Class Initialized
DEBUG - 2017-03-02 03:15:02 --> Template Class Initialized
INFO - 2017-03-02 03:15:02 --> Model Class Initialized
INFO - 2017-03-02 03:15:02 --> Controller Class Initialized
DEBUG - 2017-03-02 03:15:02 --> Pages MX_Controller Initialized
INFO - 2017-03-02 03:15:02 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 03:15:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 03:15:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 03:15:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-03-02 03:15:02 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 03:15:02 --> Final output sent to browser
DEBUG - 2017-03-02 03:15:02 --> Total execution time: 0.2292
INFO - 2017-03-02 03:15:11 --> Config Class Initialized
INFO - 2017-03-02 03:15:11 --> Hooks Class Initialized
DEBUG - 2017-03-02 03:15:11 --> UTF-8 Support Enabled
INFO - 2017-03-02 03:15:11 --> Utf8 Class Initialized
INFO - 2017-03-02 03:15:11 --> URI Class Initialized
INFO - 2017-03-02 03:15:11 --> Router Class Initialized
INFO - 2017-03-02 03:15:11 --> Output Class Initialized
INFO - 2017-03-02 03:15:11 --> Security Class Initialized
DEBUG - 2017-03-02 03:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 03:15:11 --> Input Class Initialized
INFO - 2017-03-02 03:15:11 --> Language Class Initialized
INFO - 2017-03-02 03:15:11 --> Language Class Initialized
INFO - 2017-03-02 03:15:11 --> Config Class Initialized
INFO - 2017-03-02 03:15:11 --> Loader Class Initialized
INFO - 2017-03-02 03:15:11 --> Helper loaded: form_helper
INFO - 2017-03-02 03:15:11 --> Helper loaded: url_helper
INFO - 2017-03-02 03:15:11 --> Helper loaded: utility_helper
INFO - 2017-03-02 03:15:11 --> Database Driver Class Initialized
DEBUG - 2017-03-02 03:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 03:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 03:15:11 --> User Agent Class Initialized
DEBUG - 2017-03-02 03:15:11 --> Template Class Initialized
INFO - 2017-03-02 03:15:11 --> Model Class Initialized
INFO - 2017-03-02 03:15:11 --> Controller Class Initialized
DEBUG - 2017-03-02 03:15:11 --> Pages MX_Controller Initialized
INFO - 2017-03-02 03:15:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 03:15:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 03:15:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 06:19:34 --> Config Class Initialized
INFO - 2017-03-02 06:19:34 --> Hooks Class Initialized
DEBUG - 2017-03-02 06:19:34 --> UTF-8 Support Enabled
INFO - 2017-03-02 06:19:34 --> Utf8 Class Initialized
INFO - 2017-03-02 06:19:34 --> URI Class Initialized
INFO - 2017-03-02 06:19:34 --> Router Class Initialized
INFO - 2017-03-02 06:19:34 --> Output Class Initialized
INFO - 2017-03-02 06:19:34 --> Security Class Initialized
DEBUG - 2017-03-02 06:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 06:19:34 --> Input Class Initialized
INFO - 2017-03-02 06:19:34 --> Language Class Initialized
INFO - 2017-03-02 06:19:35 --> Language Class Initialized
INFO - 2017-03-02 06:19:35 --> Config Class Initialized
INFO - 2017-03-02 06:19:35 --> Loader Class Initialized
INFO - 2017-03-02 06:19:35 --> Helper loaded: form_helper
INFO - 2017-03-02 06:19:35 --> Helper loaded: url_helper
INFO - 2017-03-02 06:19:35 --> Helper loaded: utility_helper
INFO - 2017-03-02 06:19:35 --> Database Driver Class Initialized
DEBUG - 2017-03-02 06:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 06:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 06:19:35 --> User Agent Class Initialized
DEBUG - 2017-03-02 06:19:35 --> Template Class Initialized
INFO - 2017-03-02 06:19:35 --> Model Class Initialized
INFO - 2017-03-02 06:19:35 --> Controller Class Initialized
DEBUG - 2017-03-02 06:19:35 --> Pages MX_Controller Initialized
INFO - 2017-03-02 06:19:35 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 06:19:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 06:19:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 08:48:25 --> Config Class Initialized
INFO - 2017-03-02 08:48:25 --> Hooks Class Initialized
DEBUG - 2017-03-02 08:48:25 --> UTF-8 Support Enabled
INFO - 2017-03-02 08:48:25 --> Utf8 Class Initialized
INFO - 2017-03-02 08:48:25 --> URI Class Initialized
INFO - 2017-03-02 08:48:25 --> Router Class Initialized
INFO - 2017-03-02 08:48:25 --> Output Class Initialized
INFO - 2017-03-02 08:48:25 --> Security Class Initialized
DEBUG - 2017-03-02 08:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 08:48:25 --> Input Class Initialized
INFO - 2017-03-02 08:48:25 --> Language Class Initialized
INFO - 2017-03-02 08:48:25 --> Language Class Initialized
INFO - 2017-03-02 08:48:25 --> Config Class Initialized
INFO - 2017-03-02 08:48:25 --> Loader Class Initialized
INFO - 2017-03-02 08:48:25 --> Helper loaded: form_helper
INFO - 2017-03-02 08:48:25 --> Helper loaded: url_helper
INFO - 2017-03-02 08:48:25 --> Helper loaded: utility_helper
INFO - 2017-03-02 08:48:25 --> Database Driver Class Initialized
DEBUG - 2017-03-02 08:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 08:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 08:48:25 --> User Agent Class Initialized
DEBUG - 2017-03-02 08:48:25 --> Template Class Initialized
INFO - 2017-03-02 08:48:25 --> Model Class Initialized
INFO - 2017-03-02 08:48:25 --> Controller Class Initialized
DEBUG - 2017-03-02 08:48:25 --> Pages MX_Controller Initialized
INFO - 2017-03-02 08:48:25 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 08:48:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 08:48:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 08:49:15 --> Config Class Initialized
INFO - 2017-03-02 08:49:15 --> Hooks Class Initialized
DEBUG - 2017-03-02 08:49:15 --> UTF-8 Support Enabled
INFO - 2017-03-02 08:49:15 --> Utf8 Class Initialized
INFO - 2017-03-02 08:49:15 --> URI Class Initialized
INFO - 2017-03-02 08:49:15 --> Router Class Initialized
INFO - 2017-03-02 08:49:15 --> Output Class Initialized
INFO - 2017-03-02 08:49:15 --> Security Class Initialized
DEBUG - 2017-03-02 08:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 08:49:15 --> Input Class Initialized
INFO - 2017-03-02 08:49:15 --> Language Class Initialized
INFO - 2017-03-02 08:49:15 --> Language Class Initialized
INFO - 2017-03-02 08:49:15 --> Config Class Initialized
INFO - 2017-03-02 08:49:15 --> Loader Class Initialized
INFO - 2017-03-02 08:49:15 --> Helper loaded: form_helper
INFO - 2017-03-02 08:49:15 --> Helper loaded: url_helper
INFO - 2017-03-02 08:49:15 --> Helper loaded: utility_helper
INFO - 2017-03-02 08:49:15 --> Database Driver Class Initialized
DEBUG - 2017-03-02 08:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 08:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 08:49:15 --> User Agent Class Initialized
DEBUG - 2017-03-02 08:49:15 --> Template Class Initialized
INFO - 2017-03-02 08:49:15 --> Model Class Initialized
INFO - 2017-03-02 08:49:15 --> Controller Class Initialized
DEBUG - 2017-03-02 08:49:15 --> Pages MX_Controller Initialized
INFO - 2017-03-02 08:49:15 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 08:49:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 08:49:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 08:51:15 --> Config Class Initialized
INFO - 2017-03-02 08:51:15 --> Hooks Class Initialized
DEBUG - 2017-03-02 08:51:15 --> UTF-8 Support Enabled
INFO - 2017-03-02 08:51:15 --> Utf8 Class Initialized
INFO - 2017-03-02 08:51:15 --> URI Class Initialized
INFO - 2017-03-02 08:51:15 --> Router Class Initialized
INFO - 2017-03-02 08:51:15 --> Output Class Initialized
INFO - 2017-03-02 08:51:15 --> Security Class Initialized
DEBUG - 2017-03-02 08:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 08:51:15 --> Input Class Initialized
INFO - 2017-03-02 08:51:15 --> Language Class Initialized
INFO - 2017-03-02 08:51:15 --> Language Class Initialized
INFO - 2017-03-02 08:51:15 --> Config Class Initialized
INFO - 2017-03-02 08:51:15 --> Loader Class Initialized
INFO - 2017-03-02 08:51:15 --> Helper loaded: form_helper
INFO - 2017-03-02 08:51:15 --> Helper loaded: url_helper
INFO - 2017-03-02 08:51:15 --> Helper loaded: utility_helper
INFO - 2017-03-02 08:51:15 --> Database Driver Class Initialized
DEBUG - 2017-03-02 08:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 08:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 08:51:15 --> User Agent Class Initialized
DEBUG - 2017-03-02 08:51:15 --> Template Class Initialized
INFO - 2017-03-02 08:51:15 --> Model Class Initialized
INFO - 2017-03-02 08:51:15 --> Controller Class Initialized
DEBUG - 2017-03-02 08:51:15 --> Pages MX_Controller Initialized
INFO - 2017-03-02 08:51:15 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 08:51:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 08:51:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 08:53:31 --> Config Class Initialized
INFO - 2017-03-02 08:53:31 --> Hooks Class Initialized
DEBUG - 2017-03-02 08:53:31 --> UTF-8 Support Enabled
INFO - 2017-03-02 08:53:31 --> Utf8 Class Initialized
INFO - 2017-03-02 08:53:31 --> URI Class Initialized
INFO - 2017-03-02 08:53:31 --> Router Class Initialized
INFO - 2017-03-02 08:53:31 --> Output Class Initialized
INFO - 2017-03-02 08:53:31 --> Security Class Initialized
DEBUG - 2017-03-02 08:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 08:53:31 --> Input Class Initialized
INFO - 2017-03-02 08:53:31 --> Language Class Initialized
INFO - 2017-03-02 08:53:31 --> Language Class Initialized
INFO - 2017-03-02 08:53:31 --> Config Class Initialized
INFO - 2017-03-02 08:53:31 --> Loader Class Initialized
INFO - 2017-03-02 08:53:31 --> Helper loaded: form_helper
INFO - 2017-03-02 08:53:31 --> Helper loaded: url_helper
INFO - 2017-03-02 08:53:31 --> Helper loaded: utility_helper
INFO - 2017-03-02 08:53:31 --> Database Driver Class Initialized
DEBUG - 2017-03-02 08:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 08:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 08:53:31 --> User Agent Class Initialized
DEBUG - 2017-03-02 08:53:31 --> Template Class Initialized
INFO - 2017-03-02 08:53:31 --> Model Class Initialized
INFO - 2017-03-02 08:53:31 --> Controller Class Initialized
DEBUG - 2017-03-02 08:53:31 --> Pages MX_Controller Initialized
INFO - 2017-03-02 08:53:31 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 08:53:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 08:53:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 15:24:54 --> Config Class Initialized
INFO - 2017-03-02 15:24:54 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:24:54 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:24:54 --> Utf8 Class Initialized
INFO - 2017-03-02 15:24:54 --> URI Class Initialized
DEBUG - 2017-03-02 15:24:54 --> No URI present. Default controller set.
INFO - 2017-03-02 15:24:54 --> Router Class Initialized
INFO - 2017-03-02 15:24:54 --> Output Class Initialized
INFO - 2017-03-02 15:24:54 --> Security Class Initialized
DEBUG - 2017-03-02 15:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:24:54 --> Input Class Initialized
INFO - 2017-03-02 15:24:54 --> Language Class Initialized
INFO - 2017-03-02 15:24:54 --> Language Class Initialized
INFO - 2017-03-02 15:24:54 --> Config Class Initialized
INFO - 2017-03-02 15:24:54 --> Loader Class Initialized
INFO - 2017-03-02 15:24:54 --> Helper loaded: form_helper
INFO - 2017-03-02 15:24:54 --> Helper loaded: url_helper
INFO - 2017-03-02 15:24:54 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:24:54 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:24:54 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:24:54 --> Template Class Initialized
INFO - 2017-03-02 15:24:54 --> Model Class Initialized
INFO - 2017-03-02 15:24:54 --> Controller Class Initialized
DEBUG - 2017-03-02 15:24:54 --> Pages MX_Controller Initialized
INFO - 2017-03-02 15:24:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:24:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 15:24:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 15:24:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-02 15:24:54 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 15:24:54 --> Final output sent to browser
DEBUG - 2017-03-02 15:24:54 --> Total execution time: 0.4133
INFO - 2017-03-02 15:24:57 --> Config Class Initialized
INFO - 2017-03-02 15:24:57 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:24:57 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:24:57 --> Utf8 Class Initialized
INFO - 2017-03-02 15:24:57 --> URI Class Initialized
INFO - 2017-03-02 15:24:57 --> Router Class Initialized
INFO - 2017-03-02 15:24:57 --> Output Class Initialized
INFO - 2017-03-02 15:24:57 --> Security Class Initialized
DEBUG - 2017-03-02 15:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:24:57 --> Input Class Initialized
INFO - 2017-03-02 15:24:57 --> Language Class Initialized
INFO - 2017-03-02 15:24:57 --> Language Class Initialized
INFO - 2017-03-02 15:24:57 --> Config Class Initialized
INFO - 2017-03-02 15:24:57 --> Loader Class Initialized
INFO - 2017-03-02 15:24:57 --> Helper loaded: form_helper
INFO - 2017-03-02 15:24:57 --> Helper loaded: url_helper
INFO - 2017-03-02 15:24:57 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:24:57 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:24:57 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:24:57 --> Template Class Initialized
INFO - 2017-03-02 15:24:57 --> Model Class Initialized
INFO - 2017-03-02 15:24:57 --> Controller Class Initialized
DEBUG - 2017-03-02 15:24:57 --> Pages MX_Controller Initialized
INFO - 2017-03-02 15:24:57 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:24:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 15:24:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 15:25:00 --> Config Class Initialized
INFO - 2017-03-02 15:25:00 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:25:00 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:25:00 --> Utf8 Class Initialized
INFO - 2017-03-02 15:25:00 --> URI Class Initialized
INFO - 2017-03-02 15:25:00 --> Router Class Initialized
INFO - 2017-03-02 15:25:00 --> Output Class Initialized
INFO - 2017-03-02 15:25:00 --> Security Class Initialized
DEBUG - 2017-03-02 15:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:25:00 --> Input Class Initialized
INFO - 2017-03-02 15:25:00 --> Language Class Initialized
INFO - 2017-03-02 15:25:00 --> Language Class Initialized
INFO - 2017-03-02 15:25:00 --> Config Class Initialized
INFO - 2017-03-02 15:25:00 --> Loader Class Initialized
INFO - 2017-03-02 15:25:00 --> Helper loaded: form_helper
INFO - 2017-03-02 15:25:00 --> Helper loaded: url_helper
INFO - 2017-03-02 15:25:00 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:25:00 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:25:00 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:25:00 --> Template Class Initialized
INFO - 2017-03-02 15:25:00 --> Model Class Initialized
INFO - 2017-03-02 15:25:00 --> Controller Class Initialized
DEBUG - 2017-03-02 15:25:00 --> Pages MX_Controller Initialized
INFO - 2017-03-02 15:25:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:25:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 15:25:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 15:25:01 --> Config Class Initialized
INFO - 2017-03-02 15:25:01 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:25:01 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:25:01 --> Utf8 Class Initialized
INFO - 2017-03-02 15:25:01 --> URI Class Initialized
INFO - 2017-03-02 15:25:01 --> Router Class Initialized
INFO - 2017-03-02 15:25:01 --> Output Class Initialized
INFO - 2017-03-02 15:25:01 --> Security Class Initialized
DEBUG - 2017-03-02 15:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:25:01 --> Input Class Initialized
INFO - 2017-03-02 15:25:01 --> Language Class Initialized
INFO - 2017-03-02 15:25:01 --> Language Class Initialized
INFO - 2017-03-02 15:25:01 --> Config Class Initialized
INFO - 2017-03-02 15:25:01 --> Loader Class Initialized
INFO - 2017-03-02 15:25:01 --> Helper loaded: form_helper
INFO - 2017-03-02 15:25:01 --> Helper loaded: url_helper
INFO - 2017-03-02 15:25:01 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:25:01 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:25:01 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:25:01 --> Template Class Initialized
INFO - 2017-03-02 15:25:01 --> Model Class Initialized
INFO - 2017-03-02 15:25:01 --> Controller Class Initialized
DEBUG - 2017-03-02 15:25:01 --> Pages MX_Controller Initialized
INFO - 2017-03-02 15:25:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:25:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 15:25:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 15:25:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-02 15:25:01 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 15:25:01 --> Final output sent to browser
DEBUG - 2017-03-02 15:25:01 --> Total execution time: 0.0218
INFO - 2017-03-02 15:25:01 --> Config Class Initialized
INFO - 2017-03-02 15:25:01 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:25:01 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:25:01 --> Utf8 Class Initialized
INFO - 2017-03-02 15:25:01 --> URI Class Initialized
INFO - 2017-03-02 15:25:01 --> Router Class Initialized
INFO - 2017-03-02 15:25:01 --> Output Class Initialized
INFO - 2017-03-02 15:25:01 --> Security Class Initialized
DEBUG - 2017-03-02 15:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:25:01 --> Input Class Initialized
INFO - 2017-03-02 15:25:01 --> Language Class Initialized
INFO - 2017-03-02 15:25:01 --> Language Class Initialized
INFO - 2017-03-02 15:25:01 --> Config Class Initialized
INFO - 2017-03-02 15:25:01 --> Loader Class Initialized
INFO - 2017-03-02 15:25:01 --> Helper loaded: form_helper
INFO - 2017-03-02 15:25:01 --> Helper loaded: url_helper
INFO - 2017-03-02 15:25:01 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:25:01 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:25:01 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:25:01 --> Template Class Initialized
INFO - 2017-03-02 15:25:01 --> Model Class Initialized
INFO - 2017-03-02 15:25:01 --> Controller Class Initialized
DEBUG - 2017-03-02 15:25:01 --> Pages MX_Controller Initialized
INFO - 2017-03-02 15:25:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:25:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 15:25:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 15:25:02 --> Config Class Initialized
INFO - 2017-03-02 15:25:02 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:25:02 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:25:02 --> Utf8 Class Initialized
INFO - 2017-03-02 15:25:02 --> URI Class Initialized
INFO - 2017-03-02 15:25:02 --> Router Class Initialized
INFO - 2017-03-02 15:25:02 --> Output Class Initialized
INFO - 2017-03-02 15:25:02 --> Security Class Initialized
DEBUG - 2017-03-02 15:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:25:02 --> Input Class Initialized
INFO - 2017-03-02 15:25:02 --> Language Class Initialized
INFO - 2017-03-02 15:25:02 --> Language Class Initialized
INFO - 2017-03-02 15:25:02 --> Config Class Initialized
INFO - 2017-03-02 15:25:02 --> Loader Class Initialized
INFO - 2017-03-02 15:25:02 --> Helper loaded: form_helper
INFO - 2017-03-02 15:25:02 --> Helper loaded: url_helper
INFO - 2017-03-02 15:25:02 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:25:02 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:25:02 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:25:02 --> Template Class Initialized
INFO - 2017-03-02 15:25:02 --> Model Class Initialized
INFO - 2017-03-02 15:25:02 --> Controller Class Initialized
DEBUG - 2017-03-02 15:25:02 --> Pages MX_Controller Initialized
INFO - 2017-03-02 15:25:02 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:25:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 15:25:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 15:25:04 --> Config Class Initialized
INFO - 2017-03-02 15:25:04 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:25:04 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:25:04 --> Utf8 Class Initialized
INFO - 2017-03-02 15:25:04 --> URI Class Initialized
INFO - 2017-03-02 15:25:04 --> Router Class Initialized
INFO - 2017-03-02 15:25:04 --> Output Class Initialized
INFO - 2017-03-02 15:25:04 --> Security Class Initialized
DEBUG - 2017-03-02 15:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:25:04 --> Input Class Initialized
INFO - 2017-03-02 15:25:04 --> Language Class Initialized
INFO - 2017-03-02 15:25:04 --> Language Class Initialized
INFO - 2017-03-02 15:25:04 --> Config Class Initialized
INFO - 2017-03-02 15:25:04 --> Loader Class Initialized
INFO - 2017-03-02 15:25:04 --> Helper loaded: form_helper
INFO - 2017-03-02 15:25:04 --> Helper loaded: url_helper
INFO - 2017-03-02 15:25:04 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:25:04 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:25:04 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:25:04 --> Template Class Initialized
INFO - 2017-03-02 15:25:04 --> Model Class Initialized
INFO - 2017-03-02 15:25:04 --> Controller Class Initialized
DEBUG - 2017-03-02 15:25:04 --> Login MX_Controller Initialized
INFO - 2017-03-02 15:25:04 --> Helper loaded: cookie_helper
INFO - 2017-03-02 15:25:04 --> Form Validation Class Initialized
INFO - 2017-03-02 15:25:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-02 15:25:04 --> Config Class Initialized
INFO - 2017-03-02 15:25:04 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:25:04 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:25:04 --> Utf8 Class Initialized
INFO - 2017-03-02 15:25:04 --> URI Class Initialized
INFO - 2017-03-02 15:25:04 --> Router Class Initialized
INFO - 2017-03-02 15:25:04 --> Output Class Initialized
INFO - 2017-03-02 15:25:04 --> Security Class Initialized
DEBUG - 2017-03-02 15:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:25:04 --> Input Class Initialized
INFO - 2017-03-02 15:25:04 --> Language Class Initialized
INFO - 2017-03-02 15:25:04 --> Language Class Initialized
INFO - 2017-03-02 15:25:04 --> Config Class Initialized
INFO - 2017-03-02 15:25:04 --> Loader Class Initialized
INFO - 2017-03-02 15:25:04 --> Helper loaded: form_helper
INFO - 2017-03-02 15:25:04 --> Helper loaded: url_helper
INFO - 2017-03-02 15:25:04 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:25:04 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:25:04 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:25:04 --> Template Class Initialized
INFO - 2017-03-02 15:25:04 --> Model Class Initialized
INFO - 2017-03-02 15:25:04 --> Controller Class Initialized
DEBUG - 2017-03-02 15:25:04 --> Dashboard MX_Controller Initialized
INFO - 2017-03-02 15:25:04 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:25:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-02 15:25:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-02 15:25:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-02 15:25:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-02 15:25:04 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-02 15:25:04 --> Final output sent to browser
DEBUG - 2017-03-02 15:25:04 --> Total execution time: 0.0636
INFO - 2017-03-02 15:25:06 --> Config Class Initialized
INFO - 2017-03-02 15:25:06 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:25:06 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:25:06 --> Utf8 Class Initialized
INFO - 2017-03-02 15:25:06 --> URI Class Initialized
INFO - 2017-03-02 15:25:06 --> Router Class Initialized
INFO - 2017-03-02 15:25:06 --> Output Class Initialized
INFO - 2017-03-02 15:25:06 --> Security Class Initialized
DEBUG - 2017-03-02 15:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:25:06 --> Input Class Initialized
INFO - 2017-03-02 15:25:06 --> Language Class Initialized
INFO - 2017-03-02 15:25:06 --> Language Class Initialized
INFO - 2017-03-02 15:25:06 --> Config Class Initialized
INFO - 2017-03-02 15:25:06 --> Loader Class Initialized
INFO - 2017-03-02 15:25:06 --> Helper loaded: form_helper
INFO - 2017-03-02 15:25:06 --> Helper loaded: url_helper
INFO - 2017-03-02 15:25:06 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:25:06 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:25:06 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:25:06 --> Template Class Initialized
INFO - 2017-03-02 15:25:06 --> Model Class Initialized
INFO - 2017-03-02 15:25:06 --> Controller Class Initialized
DEBUG - 2017-03-02 15:25:06 --> Pages MX_Controller Initialized
INFO - 2017-03-02 15:25:06 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:25:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 15:25:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 15:26:32 --> Config Class Initialized
INFO - 2017-03-02 15:26:32 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:26:32 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:26:32 --> Utf8 Class Initialized
INFO - 2017-03-02 15:26:32 --> URI Class Initialized
INFO - 2017-03-02 15:26:32 --> Router Class Initialized
INFO - 2017-03-02 15:26:32 --> Output Class Initialized
INFO - 2017-03-02 15:26:32 --> Security Class Initialized
DEBUG - 2017-03-02 15:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:26:32 --> Input Class Initialized
INFO - 2017-03-02 15:26:32 --> Language Class Initialized
INFO - 2017-03-02 15:26:32 --> Language Class Initialized
INFO - 2017-03-02 15:26:32 --> Config Class Initialized
INFO - 2017-03-02 15:26:32 --> Loader Class Initialized
INFO - 2017-03-02 15:26:32 --> Helper loaded: form_helper
INFO - 2017-03-02 15:26:32 --> Helper loaded: url_helper
INFO - 2017-03-02 15:26:32 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:26:32 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:26:33 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:26:33 --> Template Class Initialized
INFO - 2017-03-02 15:26:33 --> Model Class Initialized
INFO - 2017-03-02 15:26:33 --> Controller Class Initialized
DEBUG - 2017-03-02 15:26:33 --> Project MX_Controller Initialized
INFO - 2017-03-02 15:26:33 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:26:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-02 15:26:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-02 15:26:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-02 15:26:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-02 15:26:33 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-02 15:26:33 --> Final output sent to browser
DEBUG - 2017-03-02 15:26:33 --> Total execution time: 1.0111
INFO - 2017-03-02 15:26:33 --> Config Class Initialized
INFO - 2017-03-02 15:26:33 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:26:33 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:26:33 --> Utf8 Class Initialized
INFO - 2017-03-02 15:26:33 --> URI Class Initialized
INFO - 2017-03-02 15:26:33 --> Router Class Initialized
INFO - 2017-03-02 15:26:33 --> Output Class Initialized
INFO - 2017-03-02 15:26:33 --> Security Class Initialized
DEBUG - 2017-03-02 15:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:26:33 --> Input Class Initialized
INFO - 2017-03-02 15:26:33 --> Language Class Initialized
INFO - 2017-03-02 15:26:33 --> Language Class Initialized
INFO - 2017-03-02 15:26:33 --> Config Class Initialized
INFO - 2017-03-02 15:26:33 --> Loader Class Initialized
INFO - 2017-03-02 15:26:33 --> Helper loaded: form_helper
INFO - 2017-03-02 15:26:33 --> Helper loaded: url_helper
INFO - 2017-03-02 15:26:33 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:26:33 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:26:33 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:26:33 --> Template Class Initialized
INFO - 2017-03-02 15:26:33 --> Model Class Initialized
INFO - 2017-03-02 15:26:33 --> Controller Class Initialized
DEBUG - 2017-03-02 15:26:33 --> Pages MX_Controller Initialized
INFO - 2017-03-02 15:26:33 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:26:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 15:26:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 15:26:59 --> Config Class Initialized
INFO - 2017-03-02 15:26:59 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:26:59 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:26:59 --> Utf8 Class Initialized
INFO - 2017-03-02 15:26:59 --> URI Class Initialized
INFO - 2017-03-02 15:26:59 --> Router Class Initialized
INFO - 2017-03-02 15:26:59 --> Output Class Initialized
INFO - 2017-03-02 15:26:59 --> Security Class Initialized
DEBUG - 2017-03-02 15:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:26:59 --> Input Class Initialized
INFO - 2017-03-02 15:26:59 --> Language Class Initialized
INFO - 2017-03-02 15:26:59 --> Language Class Initialized
INFO - 2017-03-02 15:26:59 --> Config Class Initialized
INFO - 2017-03-02 15:26:59 --> Loader Class Initialized
INFO - 2017-03-02 15:26:59 --> Helper loaded: form_helper
INFO - 2017-03-02 15:26:59 --> Helper loaded: url_helper
INFO - 2017-03-02 15:26:59 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:26:59 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:26:59 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:26:59 --> Template Class Initialized
INFO - 2017-03-02 15:26:59 --> Model Class Initialized
INFO - 2017-03-02 15:26:59 --> Controller Class Initialized
DEBUG - 2017-03-02 15:26:59 --> Project MX_Controller Initialized
INFO - 2017-03-02 15:26:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:26:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-02 15:26:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-02 15:26:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-02 15:26:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-02 15:26:59 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-02 15:26:59 --> Final output sent to browser
DEBUG - 2017-03-02 15:26:59 --> Total execution time: 0.0640
INFO - 2017-03-02 15:26:59 --> Config Class Initialized
INFO - 2017-03-02 15:26:59 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:26:59 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:26:59 --> Utf8 Class Initialized
INFO - 2017-03-02 15:26:59 --> URI Class Initialized
INFO - 2017-03-02 15:26:59 --> Router Class Initialized
INFO - 2017-03-02 15:26:59 --> Output Class Initialized
INFO - 2017-03-02 15:26:59 --> Security Class Initialized
DEBUG - 2017-03-02 15:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:26:59 --> Input Class Initialized
INFO - 2017-03-02 15:26:59 --> Language Class Initialized
INFO - 2017-03-02 15:26:59 --> Language Class Initialized
INFO - 2017-03-02 15:26:59 --> Config Class Initialized
INFO - 2017-03-02 15:26:59 --> Loader Class Initialized
INFO - 2017-03-02 15:26:59 --> Helper loaded: form_helper
INFO - 2017-03-02 15:26:59 --> Helper loaded: url_helper
INFO - 2017-03-02 15:27:01 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:27:01 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:27:01 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:27:01 --> Template Class Initialized
INFO - 2017-03-02 15:27:01 --> Model Class Initialized
INFO - 2017-03-02 15:27:01 --> Controller Class Initialized
DEBUG - 2017-03-02 15:27:01 --> Pages MX_Controller Initialized
INFO - 2017-03-02 15:27:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:27:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 15:27:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 15:31:36 --> Config Class Initialized
INFO - 2017-03-02 15:31:36 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:31:36 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:31:36 --> Utf8 Class Initialized
INFO - 2017-03-02 15:31:36 --> URI Class Initialized
DEBUG - 2017-03-02 15:31:36 --> No URI present. Default controller set.
INFO - 2017-03-02 15:31:36 --> Router Class Initialized
INFO - 2017-03-02 15:31:36 --> Output Class Initialized
INFO - 2017-03-02 15:31:36 --> Security Class Initialized
DEBUG - 2017-03-02 15:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:31:36 --> Input Class Initialized
INFO - 2017-03-02 15:31:36 --> Language Class Initialized
INFO - 2017-03-02 15:31:36 --> Language Class Initialized
INFO - 2017-03-02 15:31:36 --> Config Class Initialized
INFO - 2017-03-02 15:31:36 --> Loader Class Initialized
INFO - 2017-03-02 15:31:36 --> Helper loaded: form_helper
INFO - 2017-03-02 15:31:36 --> Helper loaded: url_helper
INFO - 2017-03-02 15:31:36 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:31:36 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:31:36 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:31:36 --> Template Class Initialized
INFO - 2017-03-02 15:31:36 --> Model Class Initialized
INFO - 2017-03-02 15:31:36 --> Controller Class Initialized
DEBUG - 2017-03-02 15:31:36 --> Pages MX_Controller Initialized
INFO - 2017-03-02 15:31:36 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:31:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 15:31:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 15:31:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-02 15:31:36 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 15:31:36 --> Final output sent to browser
DEBUG - 2017-03-02 15:31:36 --> Total execution time: 0.0579
INFO - 2017-03-02 15:31:39 --> Config Class Initialized
INFO - 2017-03-02 15:31:39 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:31:39 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:31:39 --> Utf8 Class Initialized
INFO - 2017-03-02 15:31:39 --> URI Class Initialized
INFO - 2017-03-02 15:31:39 --> Router Class Initialized
INFO - 2017-03-02 15:31:39 --> Output Class Initialized
INFO - 2017-03-02 15:31:39 --> Security Class Initialized
DEBUG - 2017-03-02 15:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:31:39 --> Input Class Initialized
INFO - 2017-03-02 15:31:39 --> Language Class Initialized
INFO - 2017-03-02 15:31:39 --> Language Class Initialized
INFO - 2017-03-02 15:31:39 --> Config Class Initialized
INFO - 2017-03-02 15:31:39 --> Loader Class Initialized
INFO - 2017-03-02 15:31:39 --> Helper loaded: form_helper
INFO - 2017-03-02 15:31:39 --> Helper loaded: url_helper
INFO - 2017-03-02 15:31:39 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:31:39 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:31:39 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:31:39 --> Template Class Initialized
INFO - 2017-03-02 15:31:39 --> Model Class Initialized
INFO - 2017-03-02 15:31:39 --> Controller Class Initialized
DEBUG - 2017-03-02 15:31:39 --> Pages MX_Controller Initialized
INFO - 2017-03-02 15:31:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:31:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 15:31:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 15:31:42 --> Config Class Initialized
INFO - 2017-03-02 15:31:42 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:31:42 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:31:42 --> Utf8 Class Initialized
INFO - 2017-03-02 15:31:42 --> URI Class Initialized
INFO - 2017-03-02 15:31:42 --> Router Class Initialized
INFO - 2017-03-02 15:31:42 --> Output Class Initialized
INFO - 2017-03-02 15:31:42 --> Security Class Initialized
DEBUG - 2017-03-02 15:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:31:42 --> Input Class Initialized
INFO - 2017-03-02 15:31:42 --> Language Class Initialized
INFO - 2017-03-02 15:31:42 --> Language Class Initialized
INFO - 2017-03-02 15:31:42 --> Config Class Initialized
INFO - 2017-03-02 15:31:42 --> Loader Class Initialized
INFO - 2017-03-02 15:31:42 --> Helper loaded: form_helper
INFO - 2017-03-02 15:31:42 --> Helper loaded: url_helper
INFO - 2017-03-02 15:31:42 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:31:42 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:31:42 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:31:42 --> Template Class Initialized
INFO - 2017-03-02 15:31:42 --> Model Class Initialized
INFO - 2017-03-02 15:31:42 --> Controller Class Initialized
DEBUG - 2017-03-02 15:31:42 --> Pages MX_Controller Initialized
INFO - 2017-03-02 15:31:42 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:31:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 15:31:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 15:31:42 --> Config Class Initialized
INFO - 2017-03-02 15:31:42 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:31:42 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:31:42 --> Utf8 Class Initialized
INFO - 2017-03-02 15:31:42 --> URI Class Initialized
INFO - 2017-03-02 15:31:42 --> Router Class Initialized
INFO - 2017-03-02 15:31:42 --> Output Class Initialized
INFO - 2017-03-02 15:31:42 --> Security Class Initialized
DEBUG - 2017-03-02 15:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:31:42 --> Input Class Initialized
INFO - 2017-03-02 15:31:42 --> Language Class Initialized
INFO - 2017-03-02 15:31:42 --> Language Class Initialized
INFO - 2017-03-02 15:31:42 --> Config Class Initialized
INFO - 2017-03-02 15:31:42 --> Loader Class Initialized
INFO - 2017-03-02 15:31:42 --> Helper loaded: form_helper
INFO - 2017-03-02 15:31:42 --> Helper loaded: url_helper
INFO - 2017-03-02 15:31:42 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:31:42 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:31:42 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:31:42 --> Template Class Initialized
INFO - 2017-03-02 15:31:42 --> Model Class Initialized
INFO - 2017-03-02 15:31:42 --> Controller Class Initialized
DEBUG - 2017-03-02 15:31:42 --> Pages MX_Controller Initialized
INFO - 2017-03-02 15:31:42 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:31:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 15:31:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 15:31:44 --> Config Class Initialized
INFO - 2017-03-02 15:31:44 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:31:44 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:31:44 --> Utf8 Class Initialized
INFO - 2017-03-02 15:31:44 --> URI Class Initialized
INFO - 2017-03-02 15:31:44 --> Router Class Initialized
INFO - 2017-03-02 15:31:44 --> Output Class Initialized
INFO - 2017-03-02 15:31:44 --> Security Class Initialized
DEBUG - 2017-03-02 15:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:31:44 --> Input Class Initialized
INFO - 2017-03-02 15:31:44 --> Language Class Initialized
INFO - 2017-03-02 15:31:44 --> Language Class Initialized
INFO - 2017-03-02 15:31:44 --> Config Class Initialized
INFO - 2017-03-02 15:31:44 --> Loader Class Initialized
INFO - 2017-03-02 15:31:44 --> Helper loaded: form_helper
INFO - 2017-03-02 15:31:44 --> Helper loaded: url_helper
INFO - 2017-03-02 15:31:44 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:31:44 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:31:44 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:31:44 --> Template Class Initialized
INFO - 2017-03-02 15:31:44 --> Model Class Initialized
INFO - 2017-03-02 15:31:44 --> Controller Class Initialized
DEBUG - 2017-03-02 15:31:44 --> Pages MX_Controller Initialized
INFO - 2017-03-02 15:31:44 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:31:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 15:31:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 15:43:14 --> Config Class Initialized
INFO - 2017-03-02 15:43:14 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:43:14 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:43:14 --> Utf8 Class Initialized
INFO - 2017-03-02 15:43:14 --> URI Class Initialized
INFO - 2017-03-02 15:43:14 --> Router Class Initialized
INFO - 2017-03-02 15:43:14 --> Output Class Initialized
INFO - 2017-03-02 15:43:14 --> Security Class Initialized
DEBUG - 2017-03-02 15:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:43:14 --> Input Class Initialized
INFO - 2017-03-02 15:43:14 --> Language Class Initialized
INFO - 2017-03-02 15:43:14 --> Language Class Initialized
INFO - 2017-03-02 15:43:14 --> Config Class Initialized
INFO - 2017-03-02 15:43:14 --> Loader Class Initialized
INFO - 2017-03-02 15:43:14 --> Helper loaded: form_helper
INFO - 2017-03-02 15:43:14 --> Helper loaded: url_helper
INFO - 2017-03-02 15:43:14 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:43:14 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:43:14 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:43:14 --> Template Class Initialized
INFO - 2017-03-02 15:43:14 --> Model Class Initialized
INFO - 2017-03-02 15:43:14 --> Controller Class Initialized
DEBUG - 2017-03-02 15:43:14 --> Pages MX_Controller Initialized
INFO - 2017-03-02 15:43:14 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:43:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 15:43:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 15:43:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-02 15:43:14 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 15:43:14 --> Final output sent to browser
DEBUG - 2017-03-02 15:43:14 --> Total execution time: 0.0379
INFO - 2017-03-02 15:43:15 --> Config Class Initialized
INFO - 2017-03-02 15:43:15 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:43:15 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:43:15 --> Utf8 Class Initialized
INFO - 2017-03-02 15:43:15 --> URI Class Initialized
INFO - 2017-03-02 15:43:15 --> Router Class Initialized
INFO - 2017-03-02 15:43:15 --> Output Class Initialized
INFO - 2017-03-02 15:43:15 --> Security Class Initialized
DEBUG - 2017-03-02 15:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:43:15 --> Input Class Initialized
INFO - 2017-03-02 15:43:15 --> Language Class Initialized
INFO - 2017-03-02 15:43:15 --> Language Class Initialized
INFO - 2017-03-02 15:43:15 --> Config Class Initialized
INFO - 2017-03-02 15:43:15 --> Loader Class Initialized
INFO - 2017-03-02 15:43:15 --> Helper loaded: form_helper
INFO - 2017-03-02 15:43:15 --> Helper loaded: url_helper
INFO - 2017-03-02 15:43:15 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:43:15 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:43:15 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:43:15 --> Template Class Initialized
INFO - 2017-03-02 15:43:15 --> Model Class Initialized
INFO - 2017-03-02 15:43:15 --> Controller Class Initialized
DEBUG - 2017-03-02 15:43:15 --> Pages MX_Controller Initialized
INFO - 2017-03-02 15:43:15 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:43:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 15:43:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 15:43:15 --> Config Class Initialized
INFO - 2017-03-02 15:43:15 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:43:15 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:43:15 --> Utf8 Class Initialized
INFO - 2017-03-02 15:43:15 --> URI Class Initialized
INFO - 2017-03-02 15:43:15 --> Router Class Initialized
INFO - 2017-03-02 15:43:15 --> Output Class Initialized
INFO - 2017-03-02 15:43:15 --> Security Class Initialized
DEBUG - 2017-03-02 15:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:43:15 --> Input Class Initialized
INFO - 2017-03-02 15:43:15 --> Language Class Initialized
INFO - 2017-03-02 15:43:15 --> Language Class Initialized
INFO - 2017-03-02 15:43:15 --> Config Class Initialized
INFO - 2017-03-02 15:43:15 --> Loader Class Initialized
INFO - 2017-03-02 15:43:15 --> Helper loaded: form_helper
INFO - 2017-03-02 15:43:15 --> Helper loaded: url_helper
INFO - 2017-03-02 15:43:15 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:43:15 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:43:15 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:43:15 --> Template Class Initialized
INFO - 2017-03-02 15:43:15 --> Model Class Initialized
INFO - 2017-03-02 15:43:15 --> Controller Class Initialized
DEBUG - 2017-03-02 15:43:15 --> Pages MX_Controller Initialized
INFO - 2017-03-02 15:43:15 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:43:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 15:43:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 15:43:15 --> Config Class Initialized
INFO - 2017-03-02 15:43:15 --> Hooks Class Initialized
DEBUG - 2017-03-02 15:43:15 --> UTF-8 Support Enabled
INFO - 2017-03-02 15:43:15 --> Utf8 Class Initialized
INFO - 2017-03-02 15:43:15 --> URI Class Initialized
INFO - 2017-03-02 15:43:15 --> Router Class Initialized
INFO - 2017-03-02 15:43:15 --> Output Class Initialized
INFO - 2017-03-02 15:43:15 --> Security Class Initialized
DEBUG - 2017-03-02 15:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 15:43:15 --> Input Class Initialized
INFO - 2017-03-02 15:43:15 --> Language Class Initialized
INFO - 2017-03-02 15:43:15 --> Language Class Initialized
INFO - 2017-03-02 15:43:15 --> Config Class Initialized
INFO - 2017-03-02 15:43:15 --> Loader Class Initialized
INFO - 2017-03-02 15:43:15 --> Helper loaded: form_helper
INFO - 2017-03-02 15:43:15 --> Helper loaded: url_helper
INFO - 2017-03-02 15:43:15 --> Helper loaded: utility_helper
INFO - 2017-03-02 15:43:15 --> Database Driver Class Initialized
DEBUG - 2017-03-02 15:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 15:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 15:43:15 --> User Agent Class Initialized
DEBUG - 2017-03-02 15:43:15 --> Template Class Initialized
INFO - 2017-03-02 15:43:15 --> Model Class Initialized
INFO - 2017-03-02 15:43:15 --> Controller Class Initialized
DEBUG - 2017-03-02 15:43:15 --> Pages MX_Controller Initialized
INFO - 2017-03-02 15:43:15 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 15:43:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 15:43:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 19:57:50 --> Config Class Initialized
INFO - 2017-03-02 19:57:50 --> Hooks Class Initialized
DEBUG - 2017-03-02 19:57:50 --> UTF-8 Support Enabled
INFO - 2017-03-02 19:57:50 --> Utf8 Class Initialized
INFO - 2017-03-02 19:57:50 --> URI Class Initialized
DEBUG - 2017-03-02 19:57:50 --> No URI present. Default controller set.
INFO - 2017-03-02 19:57:50 --> Router Class Initialized
INFO - 2017-03-02 19:57:50 --> Output Class Initialized
INFO - 2017-03-02 19:57:50 --> Security Class Initialized
DEBUG - 2017-03-02 19:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 19:57:50 --> Input Class Initialized
INFO - 2017-03-02 19:57:50 --> Language Class Initialized
INFO - 2017-03-02 19:57:50 --> Language Class Initialized
INFO - 2017-03-02 19:57:50 --> Config Class Initialized
INFO - 2017-03-02 19:57:50 --> Loader Class Initialized
INFO - 2017-03-02 19:57:50 --> Helper loaded: form_helper
INFO - 2017-03-02 19:57:50 --> Helper loaded: url_helper
INFO - 2017-03-02 19:57:50 --> Helper loaded: utility_helper
INFO - 2017-03-02 19:57:50 --> Database Driver Class Initialized
DEBUG - 2017-03-02 19:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 19:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 19:57:50 --> User Agent Class Initialized
DEBUG - 2017-03-02 19:57:50 --> Template Class Initialized
INFO - 2017-03-02 19:57:50 --> Model Class Initialized
INFO - 2017-03-02 19:57:50 --> Controller Class Initialized
DEBUG - 2017-03-02 19:57:50 --> Pages MX_Controller Initialized
INFO - 2017-03-02 19:57:50 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 19:57:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 19:57:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 19:57:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-02 19:57:50 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 19:57:50 --> Final output sent to browser
DEBUG - 2017-03-02 19:57:50 --> Total execution time: 0.2245
INFO - 2017-03-02 21:26:18 --> Config Class Initialized
INFO - 2017-03-02 21:26:18 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:26:18 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:26:18 --> Utf8 Class Initialized
INFO - 2017-03-02 21:26:18 --> URI Class Initialized
INFO - 2017-03-02 21:26:18 --> Router Class Initialized
INFO - 2017-03-02 21:26:18 --> Output Class Initialized
INFO - 2017-03-02 21:26:18 --> Security Class Initialized
DEBUG - 2017-03-02 21:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:26:18 --> Input Class Initialized
INFO - 2017-03-02 21:26:18 --> Language Class Initialized
INFO - 2017-03-02 21:26:18 --> Language Class Initialized
INFO - 2017-03-02 21:26:18 --> Config Class Initialized
INFO - 2017-03-02 21:26:18 --> Loader Class Initialized
INFO - 2017-03-02 21:26:18 --> Helper loaded: form_helper
INFO - 2017-03-02 21:26:18 --> Helper loaded: url_helper
INFO - 2017-03-02 21:26:18 --> Helper loaded: utility_helper
INFO - 2017-03-02 21:26:18 --> Database Driver Class Initialized
DEBUG - 2017-03-02 21:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 21:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:26:18 --> User Agent Class Initialized
DEBUG - 2017-03-02 21:26:18 --> Template Class Initialized
INFO - 2017-03-02 21:26:18 --> Model Class Initialized
INFO - 2017-03-02 21:26:18 --> Controller Class Initialized
DEBUG - 2017-03-02 21:26:18 --> Pages MX_Controller Initialized
INFO - 2017-03-02 21:26:18 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 21:26:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 21:26:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 21:26:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-03-02 21:26:18 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 21:26:18 --> Final output sent to browser
DEBUG - 2017-03-02 21:26:18 --> Total execution time: 0.0752
INFO - 2017-03-02 21:26:21 --> Config Class Initialized
INFO - 2017-03-02 21:26:21 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:26:21 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:26:21 --> Utf8 Class Initialized
INFO - 2017-03-02 21:26:21 --> URI Class Initialized
INFO - 2017-03-02 21:26:21 --> Router Class Initialized
INFO - 2017-03-02 21:26:21 --> Output Class Initialized
INFO - 2017-03-02 21:26:21 --> Security Class Initialized
DEBUG - 2017-03-02 21:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:26:21 --> Input Class Initialized
INFO - 2017-03-02 21:26:21 --> Language Class Initialized
INFO - 2017-03-02 21:26:21 --> Language Class Initialized
INFO - 2017-03-02 21:26:21 --> Config Class Initialized
INFO - 2017-03-02 21:26:21 --> Loader Class Initialized
INFO - 2017-03-02 21:26:21 --> Helper loaded: form_helper
INFO - 2017-03-02 21:26:21 --> Helper loaded: url_helper
INFO - 2017-03-02 21:26:21 --> Helper loaded: utility_helper
INFO - 2017-03-02 21:26:21 --> Database Driver Class Initialized
DEBUG - 2017-03-02 21:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 21:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:26:21 --> User Agent Class Initialized
DEBUG - 2017-03-02 21:26:21 --> Template Class Initialized
INFO - 2017-03-02 21:26:21 --> Model Class Initialized
INFO - 2017-03-02 21:26:21 --> Controller Class Initialized
DEBUG - 2017-03-02 21:26:21 --> Pages MX_Controller Initialized
INFO - 2017-03-02 21:26:21 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 21:26:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 21:26:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 21:26:35 --> Config Class Initialized
INFO - 2017-03-02 21:26:35 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:26:35 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:26:35 --> Utf8 Class Initialized
INFO - 2017-03-02 21:26:35 --> URI Class Initialized
INFO - 2017-03-02 21:26:35 --> Router Class Initialized
INFO - 2017-03-02 21:26:35 --> Output Class Initialized
INFO - 2017-03-02 21:26:35 --> Security Class Initialized
DEBUG - 2017-03-02 21:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:26:35 --> Input Class Initialized
INFO - 2017-03-02 21:26:35 --> Language Class Initialized
INFO - 2017-03-02 21:26:35 --> Language Class Initialized
INFO - 2017-03-02 21:26:35 --> Config Class Initialized
INFO - 2017-03-02 21:26:35 --> Loader Class Initialized
INFO - 2017-03-02 21:26:35 --> Helper loaded: form_helper
INFO - 2017-03-02 21:26:35 --> Helper loaded: url_helper
INFO - 2017-03-02 21:26:35 --> Helper loaded: utility_helper
INFO - 2017-03-02 21:26:35 --> Database Driver Class Initialized
DEBUG - 2017-03-02 21:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 21:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:26:35 --> User Agent Class Initialized
DEBUG - 2017-03-02 21:26:35 --> Template Class Initialized
INFO - 2017-03-02 21:26:35 --> Model Class Initialized
INFO - 2017-03-02 21:26:35 --> Controller Class Initialized
DEBUG - 2017-03-02 21:26:35 --> Pages MX_Controller Initialized
INFO - 2017-03-02 21:26:35 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 21:26:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 21:26:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 21:26:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-02 21:26:35 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 21:26:35 --> Final output sent to browser
DEBUG - 2017-03-02 21:26:35 --> Total execution time: 0.0235
INFO - 2017-03-02 21:26:36 --> Config Class Initialized
INFO - 2017-03-02 21:26:36 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:26:36 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:26:36 --> Utf8 Class Initialized
INFO - 2017-03-02 21:26:36 --> URI Class Initialized
INFO - 2017-03-02 21:26:36 --> Router Class Initialized
INFO - 2017-03-02 21:26:36 --> Output Class Initialized
INFO - 2017-03-02 21:26:36 --> Security Class Initialized
DEBUG - 2017-03-02 21:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:26:36 --> Input Class Initialized
INFO - 2017-03-02 21:26:36 --> Language Class Initialized
INFO - 2017-03-02 21:26:36 --> Language Class Initialized
INFO - 2017-03-02 21:26:36 --> Config Class Initialized
INFO - 2017-03-02 21:26:36 --> Loader Class Initialized
INFO - 2017-03-02 21:26:36 --> Helper loaded: form_helper
INFO - 2017-03-02 21:26:36 --> Helper loaded: url_helper
INFO - 2017-03-02 21:26:36 --> Helper loaded: utility_helper
INFO - 2017-03-02 21:26:36 --> Database Driver Class Initialized
DEBUG - 2017-03-02 21:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 21:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:26:36 --> User Agent Class Initialized
DEBUG - 2017-03-02 21:26:36 --> Template Class Initialized
INFO - 2017-03-02 21:26:36 --> Model Class Initialized
INFO - 2017-03-02 21:26:36 --> Controller Class Initialized
DEBUG - 2017-03-02 21:26:36 --> Pages MX_Controller Initialized
INFO - 2017-03-02 21:26:36 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 21:26:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 21:26:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 21:26:54 --> Config Class Initialized
INFO - 2017-03-02 21:26:54 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:26:54 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:26:54 --> Utf8 Class Initialized
INFO - 2017-03-02 21:26:54 --> URI Class Initialized
INFO - 2017-03-02 21:26:54 --> Router Class Initialized
INFO - 2017-03-02 21:26:54 --> Output Class Initialized
INFO - 2017-03-02 21:26:54 --> Security Class Initialized
DEBUG - 2017-03-02 21:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:26:54 --> Input Class Initialized
INFO - 2017-03-02 21:26:54 --> Language Class Initialized
INFO - 2017-03-02 21:26:54 --> Language Class Initialized
INFO - 2017-03-02 21:26:54 --> Config Class Initialized
INFO - 2017-03-02 21:26:54 --> Loader Class Initialized
INFO - 2017-03-02 21:26:54 --> Helper loaded: form_helper
INFO - 2017-03-02 21:26:54 --> Helper loaded: url_helper
INFO - 2017-03-02 21:26:54 --> Helper loaded: utility_helper
INFO - 2017-03-02 21:26:54 --> Database Driver Class Initialized
DEBUG - 2017-03-02 21:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 21:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:26:54 --> User Agent Class Initialized
DEBUG - 2017-03-02 21:26:54 --> Template Class Initialized
INFO - 2017-03-02 21:26:54 --> Model Class Initialized
INFO - 2017-03-02 21:26:54 --> Controller Class Initialized
DEBUG - 2017-03-02 21:26:54 --> Login MX_Controller Initialized
INFO - 2017-03-02 21:26:54 --> Helper loaded: cookie_helper
INFO - 2017-03-02 21:26:54 --> Form Validation Class Initialized
INFO - 2017-03-02 21:26:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-02 21:26:54 --> Config Class Initialized
INFO - 2017-03-02 21:26:54 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:26:54 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:26:54 --> Utf8 Class Initialized
INFO - 2017-03-02 21:26:54 --> URI Class Initialized
INFO - 2017-03-02 21:26:54 --> Router Class Initialized
INFO - 2017-03-02 21:26:54 --> Output Class Initialized
INFO - 2017-03-02 21:26:54 --> Security Class Initialized
DEBUG - 2017-03-02 21:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:26:54 --> Input Class Initialized
INFO - 2017-03-02 21:26:54 --> Language Class Initialized
INFO - 2017-03-02 21:26:54 --> Language Class Initialized
INFO - 2017-03-02 21:26:54 --> Config Class Initialized
INFO - 2017-03-02 21:26:54 --> Loader Class Initialized
INFO - 2017-03-02 21:26:54 --> Helper loaded: form_helper
INFO - 2017-03-02 21:26:54 --> Helper loaded: url_helper
INFO - 2017-03-02 21:26:54 --> Helper loaded: utility_helper
INFO - 2017-03-02 21:26:54 --> Database Driver Class Initialized
DEBUG - 2017-03-02 21:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 21:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:26:54 --> User Agent Class Initialized
DEBUG - 2017-03-02 21:26:54 --> Template Class Initialized
INFO - 2017-03-02 21:26:54 --> Model Class Initialized
INFO - 2017-03-02 21:26:54 --> Controller Class Initialized
DEBUG - 2017-03-02 21:26:54 --> Pages MX_Controller Initialized
INFO - 2017-03-02 21:26:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 21:26:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 21:26:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 21:26:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-02 21:26:54 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 21:26:54 --> Final output sent to browser
DEBUG - 2017-03-02 21:26:54 --> Total execution time: 0.0124
INFO - 2017-03-02 21:26:55 --> Config Class Initialized
INFO - 2017-03-02 21:26:55 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:26:55 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:26:55 --> Utf8 Class Initialized
INFO - 2017-03-02 21:26:55 --> URI Class Initialized
INFO - 2017-03-02 21:26:55 --> Router Class Initialized
INFO - 2017-03-02 21:26:55 --> Output Class Initialized
INFO - 2017-03-02 21:26:55 --> Security Class Initialized
DEBUG - 2017-03-02 21:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:26:55 --> Input Class Initialized
INFO - 2017-03-02 21:26:55 --> Language Class Initialized
INFO - 2017-03-02 21:26:55 --> Language Class Initialized
INFO - 2017-03-02 21:26:55 --> Config Class Initialized
INFO - 2017-03-02 21:26:55 --> Loader Class Initialized
INFO - 2017-03-02 21:26:55 --> Helper loaded: form_helper
INFO - 2017-03-02 21:26:55 --> Helper loaded: url_helper
INFO - 2017-03-02 21:26:55 --> Helper loaded: utility_helper
INFO - 2017-03-02 21:26:55 --> Database Driver Class Initialized
DEBUG - 2017-03-02 21:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 21:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:26:55 --> User Agent Class Initialized
DEBUG - 2017-03-02 21:26:55 --> Template Class Initialized
INFO - 2017-03-02 21:26:55 --> Model Class Initialized
INFO - 2017-03-02 21:26:55 --> Controller Class Initialized
DEBUG - 2017-03-02 21:26:55 --> Pages MX_Controller Initialized
INFO - 2017-03-02 21:26:55 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 21:26:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 21:26:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 21:29:19 --> Config Class Initialized
INFO - 2017-03-02 21:29:19 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:29:19 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:29:19 --> Utf8 Class Initialized
INFO - 2017-03-02 21:29:19 --> URI Class Initialized
DEBUG - 2017-03-02 21:29:19 --> No URI present. Default controller set.
INFO - 2017-03-02 21:29:19 --> Router Class Initialized
INFO - 2017-03-02 21:29:19 --> Output Class Initialized
INFO - 2017-03-02 21:29:19 --> Security Class Initialized
DEBUG - 2017-03-02 21:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:29:19 --> Input Class Initialized
INFO - 2017-03-02 21:29:19 --> Language Class Initialized
INFO - 2017-03-02 21:29:19 --> Language Class Initialized
INFO - 2017-03-02 21:29:19 --> Config Class Initialized
INFO - 2017-03-02 21:29:19 --> Loader Class Initialized
INFO - 2017-03-02 21:29:19 --> Helper loaded: form_helper
INFO - 2017-03-02 21:29:19 --> Helper loaded: url_helper
INFO - 2017-03-02 21:29:19 --> Helper loaded: utility_helper
INFO - 2017-03-02 21:29:19 --> Database Driver Class Initialized
DEBUG - 2017-03-02 21:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 21:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:29:19 --> User Agent Class Initialized
DEBUG - 2017-03-02 21:29:19 --> Template Class Initialized
INFO - 2017-03-02 21:29:19 --> Model Class Initialized
INFO - 2017-03-02 21:29:19 --> Controller Class Initialized
DEBUG - 2017-03-02 21:29:19 --> Pages MX_Controller Initialized
INFO - 2017-03-02 21:29:19 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 21:29:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 21:29:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 21:29:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-02 21:29:19 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 21:29:19 --> Final output sent to browser
DEBUG - 2017-03-02 21:29:19 --> Total execution time: 0.0596
INFO - 2017-03-02 21:29:19 --> Config Class Initialized
INFO - 2017-03-02 21:29:19 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:29:19 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:29:19 --> Utf8 Class Initialized
INFO - 2017-03-02 21:29:19 --> URI Class Initialized
INFO - 2017-03-02 21:29:19 --> Router Class Initialized
INFO - 2017-03-02 21:29:19 --> Output Class Initialized
INFO - 2017-03-02 21:29:19 --> Security Class Initialized
DEBUG - 2017-03-02 21:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:29:19 --> Input Class Initialized
INFO - 2017-03-02 21:29:19 --> Language Class Initialized
INFO - 2017-03-02 21:29:19 --> Language Class Initialized
INFO - 2017-03-02 21:29:19 --> Config Class Initialized
INFO - 2017-03-02 21:29:19 --> Loader Class Initialized
INFO - 2017-03-02 21:29:19 --> Helper loaded: form_helper
INFO - 2017-03-02 21:29:19 --> Helper loaded: url_helper
INFO - 2017-03-02 21:29:19 --> Helper loaded: utility_helper
INFO - 2017-03-02 21:29:19 --> Database Driver Class Initialized
DEBUG - 2017-03-02 21:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 21:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:29:19 --> User Agent Class Initialized
DEBUG - 2017-03-02 21:29:19 --> Template Class Initialized
INFO - 2017-03-02 21:29:19 --> Model Class Initialized
INFO - 2017-03-02 21:29:19 --> Controller Class Initialized
DEBUG - 2017-03-02 21:29:19 --> Pages MX_Controller Initialized
INFO - 2017-03-02 21:29:19 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 21:29:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 21:29:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 21:29:21 --> Config Class Initialized
INFO - 2017-03-02 21:29:21 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:29:21 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:29:21 --> Utf8 Class Initialized
INFO - 2017-03-02 21:29:21 --> URI Class Initialized
INFO - 2017-03-02 21:29:21 --> Router Class Initialized
INFO - 2017-03-02 21:29:21 --> Output Class Initialized
INFO - 2017-03-02 21:29:21 --> Security Class Initialized
DEBUG - 2017-03-02 21:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:29:21 --> Input Class Initialized
INFO - 2017-03-02 21:29:21 --> Language Class Initialized
INFO - 2017-03-02 21:29:21 --> Language Class Initialized
INFO - 2017-03-02 21:29:21 --> Config Class Initialized
INFO - 2017-03-02 21:29:21 --> Loader Class Initialized
INFO - 2017-03-02 21:29:21 --> Helper loaded: form_helper
INFO - 2017-03-02 21:29:21 --> Helper loaded: url_helper
INFO - 2017-03-02 21:29:21 --> Helper loaded: utility_helper
INFO - 2017-03-02 21:29:21 --> Database Driver Class Initialized
DEBUG - 2017-03-02 21:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 21:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:29:21 --> User Agent Class Initialized
DEBUG - 2017-03-02 21:29:21 --> Template Class Initialized
INFO - 2017-03-02 21:29:21 --> Model Class Initialized
INFO - 2017-03-02 21:29:21 --> Controller Class Initialized
DEBUG - 2017-03-02 21:29:21 --> Pages MX_Controller Initialized
INFO - 2017-03-02 21:29:21 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 21:29:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 21:29:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 21:30:00 --> Config Class Initialized
INFO - 2017-03-02 21:30:00 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:30:00 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:30:00 --> Utf8 Class Initialized
INFO - 2017-03-02 21:30:00 --> URI Class Initialized
INFO - 2017-03-02 21:30:00 --> Router Class Initialized
INFO - 2017-03-02 21:30:00 --> Output Class Initialized
INFO - 2017-03-02 21:30:00 --> Security Class Initialized
DEBUG - 2017-03-02 21:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:30:00 --> Input Class Initialized
INFO - 2017-03-02 21:30:00 --> Language Class Initialized
INFO - 2017-03-02 21:30:00 --> Language Class Initialized
INFO - 2017-03-02 21:30:00 --> Config Class Initialized
INFO - 2017-03-02 21:30:00 --> Loader Class Initialized
INFO - 2017-03-02 21:30:00 --> Helper loaded: form_helper
INFO - 2017-03-02 21:30:00 --> Helper loaded: url_helper
INFO - 2017-03-02 21:30:00 --> Helper loaded: utility_helper
INFO - 2017-03-02 21:30:00 --> Database Driver Class Initialized
DEBUG - 2017-03-02 21:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 21:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:30:00 --> User Agent Class Initialized
DEBUG - 2017-03-02 21:30:00 --> Template Class Initialized
INFO - 2017-03-02 21:30:00 --> Model Class Initialized
INFO - 2017-03-02 21:30:00 --> Controller Class Initialized
DEBUG - 2017-03-02 21:30:00 --> Pages MX_Controller Initialized
INFO - 2017-03-02 21:30:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 21:30:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 21:30:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 21:30:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/support.php
DEBUG - 2017-03-02 21:30:00 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 21:30:00 --> Final output sent to browser
DEBUG - 2017-03-02 21:30:00 --> Total execution time: 0.0669
INFO - 2017-03-02 21:30:00 --> Config Class Initialized
INFO - 2017-03-02 21:30:00 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:30:00 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:30:00 --> Utf8 Class Initialized
INFO - 2017-03-02 21:30:00 --> URI Class Initialized
INFO - 2017-03-02 21:30:00 --> Router Class Initialized
INFO - 2017-03-02 21:30:00 --> Output Class Initialized
INFO - 2017-03-02 21:30:00 --> Security Class Initialized
DEBUG - 2017-03-02 21:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:30:00 --> Input Class Initialized
INFO - 2017-03-02 21:30:00 --> Language Class Initialized
INFO - 2017-03-02 21:30:00 --> Language Class Initialized
INFO - 2017-03-02 21:30:00 --> Config Class Initialized
INFO - 2017-03-02 21:30:00 --> Loader Class Initialized
INFO - 2017-03-02 21:30:00 --> Helper loaded: form_helper
INFO - 2017-03-02 21:30:00 --> Helper loaded: url_helper
INFO - 2017-03-02 21:30:00 --> Helper loaded: utility_helper
INFO - 2017-03-02 21:30:00 --> Database Driver Class Initialized
DEBUG - 2017-03-02 21:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 21:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:30:00 --> User Agent Class Initialized
DEBUG - 2017-03-02 21:30:00 --> Template Class Initialized
INFO - 2017-03-02 21:30:00 --> Model Class Initialized
INFO - 2017-03-02 21:30:00 --> Controller Class Initialized
DEBUG - 2017-03-02 21:30:00 --> Pages MX_Controller Initialized
INFO - 2017-03-02 21:30:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 21:30:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 21:30:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 21:31:40 --> Config Class Initialized
INFO - 2017-03-02 21:31:40 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:31:40 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:31:40 --> Utf8 Class Initialized
INFO - 2017-03-02 21:31:40 --> URI Class Initialized
INFO - 2017-03-02 21:31:40 --> Router Class Initialized
INFO - 2017-03-02 21:31:40 --> Output Class Initialized
INFO - 2017-03-02 21:31:40 --> Security Class Initialized
DEBUG - 2017-03-02 21:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:31:40 --> Input Class Initialized
INFO - 2017-03-02 21:31:40 --> Language Class Initialized
INFO - 2017-03-02 21:31:40 --> Language Class Initialized
INFO - 2017-03-02 21:31:40 --> Config Class Initialized
INFO - 2017-03-02 21:31:40 --> Loader Class Initialized
INFO - 2017-03-02 21:31:40 --> Helper loaded: form_helper
INFO - 2017-03-02 21:31:40 --> Helper loaded: url_helper
INFO - 2017-03-02 21:31:40 --> Helper loaded: utility_helper
INFO - 2017-03-02 21:31:40 --> Database Driver Class Initialized
DEBUG - 2017-03-02 21:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 21:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:31:40 --> User Agent Class Initialized
DEBUG - 2017-03-02 21:31:40 --> Template Class Initialized
INFO - 2017-03-02 21:31:40 --> Model Class Initialized
INFO - 2017-03-02 21:31:40 --> Controller Class Initialized
DEBUG - 2017-03-02 21:31:40 --> Login MX_Controller Initialized
INFO - 2017-03-02 21:31:40 --> Helper loaded: cookie_helper
INFO - 2017-03-02 21:31:40 --> Form Validation Class Initialized
INFO - 2017-03-02 21:31:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-02 21:31:41 --> Config Class Initialized
INFO - 2017-03-02 21:31:41 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:31:41 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:31:41 --> Utf8 Class Initialized
INFO - 2017-03-02 21:31:41 --> URI Class Initialized
INFO - 2017-03-02 21:31:41 --> Router Class Initialized
INFO - 2017-03-02 21:31:41 --> Output Class Initialized
INFO - 2017-03-02 21:31:41 --> Security Class Initialized
DEBUG - 2017-03-02 21:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:31:41 --> Input Class Initialized
INFO - 2017-03-02 21:31:41 --> Language Class Initialized
INFO - 2017-03-02 21:31:41 --> Language Class Initialized
INFO - 2017-03-02 21:31:41 --> Config Class Initialized
INFO - 2017-03-02 21:31:41 --> Loader Class Initialized
INFO - 2017-03-02 21:31:41 --> Helper loaded: form_helper
INFO - 2017-03-02 21:31:41 --> Helper loaded: url_helper
INFO - 2017-03-02 21:31:41 --> Helper loaded: utility_helper
INFO - 2017-03-02 21:31:41 --> Database Driver Class Initialized
DEBUG - 2017-03-02 21:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 21:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:31:41 --> User Agent Class Initialized
DEBUG - 2017-03-02 21:31:41 --> Template Class Initialized
INFO - 2017-03-02 21:31:41 --> Model Class Initialized
INFO - 2017-03-02 21:31:41 --> Controller Class Initialized
DEBUG - 2017-03-02 21:31:41 --> Dashboard MX_Controller Initialized
INFO - 2017-03-02 21:31:41 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 21:31:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-02 21:31:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-02 21:31:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-02 21:31:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-02 21:31:41 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-02 21:31:41 --> Final output sent to browser
DEBUG - 2017-03-02 21:31:41 --> Total execution time: 0.0728
INFO - 2017-03-02 21:33:01 --> Config Class Initialized
INFO - 2017-03-02 21:33:01 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:33:01 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:33:01 --> Utf8 Class Initialized
INFO - 2017-03-02 21:33:01 --> URI Class Initialized
INFO - 2017-03-02 21:33:01 --> Router Class Initialized
INFO - 2017-03-02 21:33:01 --> Output Class Initialized
INFO - 2017-03-02 21:33:01 --> Security Class Initialized
DEBUG - 2017-03-02 21:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:33:01 --> Input Class Initialized
INFO - 2017-03-02 21:33:01 --> Language Class Initialized
INFO - 2017-03-02 21:33:01 --> Language Class Initialized
INFO - 2017-03-02 21:33:01 --> Config Class Initialized
INFO - 2017-03-02 21:33:01 --> Loader Class Initialized
INFO - 2017-03-02 21:33:01 --> Helper loaded: form_helper
INFO - 2017-03-02 21:33:01 --> Helper loaded: url_helper
INFO - 2017-03-02 21:33:01 --> Helper loaded: utility_helper
INFO - 2017-03-02 21:33:01 --> Database Driver Class Initialized
DEBUG - 2017-03-02 21:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 21:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:33:01 --> User Agent Class Initialized
DEBUG - 2017-03-02 21:33:01 --> Template Class Initialized
INFO - 2017-03-02 21:33:01 --> Model Class Initialized
INFO - 2017-03-02 21:33:01 --> Controller Class Initialized
DEBUG - 2017-03-02 21:33:01 --> Login MX_Controller Initialized
INFO - 2017-03-02 21:33:01 --> Helper loaded: cookie_helper
INFO - 2017-03-02 21:33:01 --> Form Validation Class Initialized
INFO - 2017-03-02 21:33:01 --> Config Class Initialized
INFO - 2017-03-02 21:33:01 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:33:01 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:33:01 --> Utf8 Class Initialized
INFO - 2017-03-02 21:33:01 --> URI Class Initialized
DEBUG - 2017-03-02 21:33:01 --> No URI present. Default controller set.
INFO - 2017-03-02 21:33:01 --> Router Class Initialized
INFO - 2017-03-02 21:33:01 --> Output Class Initialized
INFO - 2017-03-02 21:33:01 --> Security Class Initialized
DEBUG - 2017-03-02 21:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:33:01 --> Input Class Initialized
INFO - 2017-03-02 21:33:01 --> Language Class Initialized
INFO - 2017-03-02 21:33:01 --> Language Class Initialized
INFO - 2017-03-02 21:33:01 --> Config Class Initialized
INFO - 2017-03-02 21:33:01 --> Loader Class Initialized
INFO - 2017-03-02 21:33:01 --> Helper loaded: form_helper
INFO - 2017-03-02 21:33:01 --> Helper loaded: url_helper
INFO - 2017-03-02 21:33:01 --> Helper loaded: utility_helper
INFO - 2017-03-02 21:33:01 --> Database Driver Class Initialized
DEBUG - 2017-03-02 21:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 21:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:33:01 --> User Agent Class Initialized
DEBUG - 2017-03-02 21:33:01 --> Template Class Initialized
INFO - 2017-03-02 21:33:01 --> Model Class Initialized
INFO - 2017-03-02 21:33:01 --> Controller Class Initialized
DEBUG - 2017-03-02 21:33:01 --> Pages MX_Controller Initialized
INFO - 2017-03-02 21:33:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 21:33:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 21:33:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 21:33:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-02 21:33:01 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 21:33:01 --> Final output sent to browser
DEBUG - 2017-03-02 21:33:01 --> Total execution time: 0.0098
INFO - 2017-03-02 21:33:02 --> Config Class Initialized
INFO - 2017-03-02 21:33:02 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:33:02 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:33:02 --> Utf8 Class Initialized
INFO - 2017-03-02 21:33:02 --> URI Class Initialized
INFO - 2017-03-02 21:33:02 --> Router Class Initialized
INFO - 2017-03-02 21:33:02 --> Output Class Initialized
INFO - 2017-03-02 21:33:02 --> Security Class Initialized
DEBUG - 2017-03-02 21:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:33:02 --> Input Class Initialized
INFO - 2017-03-02 21:33:02 --> Language Class Initialized
INFO - 2017-03-02 21:33:02 --> Language Class Initialized
INFO - 2017-03-02 21:33:02 --> Config Class Initialized
INFO - 2017-03-02 21:33:02 --> Loader Class Initialized
INFO - 2017-03-02 21:33:02 --> Helper loaded: form_helper
INFO - 2017-03-02 21:33:02 --> Helper loaded: url_helper
INFO - 2017-03-02 21:33:02 --> Helper loaded: utility_helper
INFO - 2017-03-02 21:33:02 --> Database Driver Class Initialized
DEBUG - 2017-03-02 21:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 21:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:33:02 --> User Agent Class Initialized
DEBUG - 2017-03-02 21:33:02 --> Template Class Initialized
INFO - 2017-03-02 21:33:02 --> Model Class Initialized
INFO - 2017-03-02 21:33:02 --> Controller Class Initialized
DEBUG - 2017-03-02 21:33:02 --> Pages MX_Controller Initialized
INFO - 2017-03-02 21:33:02 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 21:33:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 21:33:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 21:33:02 --> Config Class Initialized
INFO - 2017-03-02 21:33:02 --> Hooks Class Initialized
DEBUG - 2017-03-02 21:33:02 --> UTF-8 Support Enabled
INFO - 2017-03-02 21:33:02 --> Utf8 Class Initialized
INFO - 2017-03-02 21:33:02 --> URI Class Initialized
INFO - 2017-03-02 21:33:02 --> Router Class Initialized
INFO - 2017-03-02 21:33:02 --> Output Class Initialized
INFO - 2017-03-02 21:33:02 --> Security Class Initialized
DEBUG - 2017-03-02 21:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 21:33:02 --> Input Class Initialized
INFO - 2017-03-02 21:33:02 --> Language Class Initialized
INFO - 2017-03-02 21:33:02 --> Language Class Initialized
INFO - 2017-03-02 21:33:02 --> Config Class Initialized
INFO - 2017-03-02 21:33:02 --> Loader Class Initialized
INFO - 2017-03-02 21:33:02 --> Helper loaded: form_helper
INFO - 2017-03-02 21:33:02 --> Helper loaded: url_helper
INFO - 2017-03-02 21:33:02 --> Helper loaded: utility_helper
INFO - 2017-03-02 21:33:02 --> Database Driver Class Initialized
DEBUG - 2017-03-02 21:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 21:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 21:33:02 --> User Agent Class Initialized
DEBUG - 2017-03-02 21:33:02 --> Template Class Initialized
INFO - 2017-03-02 21:33:02 --> Model Class Initialized
INFO - 2017-03-02 21:33:02 --> Controller Class Initialized
DEBUG - 2017-03-02 21:33:02 --> Pages MX_Controller Initialized
INFO - 2017-03-02 21:33:02 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 21:33:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 21:33:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-02 23:53:51 --> Config Class Initialized
INFO - 2017-03-02 23:53:51 --> Hooks Class Initialized
DEBUG - 2017-03-02 23:53:51 --> UTF-8 Support Enabled
INFO - 2017-03-02 23:53:51 --> Utf8 Class Initialized
INFO - 2017-03-02 23:53:51 --> URI Class Initialized
INFO - 2017-03-02 23:53:52 --> Router Class Initialized
INFO - 2017-03-02 23:53:52 --> Output Class Initialized
INFO - 2017-03-02 23:53:52 --> Security Class Initialized
DEBUG - 2017-03-02 23:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 23:53:52 --> Input Class Initialized
INFO - 2017-03-02 23:53:52 --> Language Class Initialized
INFO - 2017-03-02 23:53:52 --> Language Class Initialized
INFO - 2017-03-02 23:53:52 --> Config Class Initialized
INFO - 2017-03-02 23:53:52 --> Loader Class Initialized
INFO - 2017-03-02 23:53:52 --> Helper loaded: form_helper
INFO - 2017-03-02 23:53:52 --> Helper loaded: url_helper
INFO - 2017-03-02 23:53:52 --> Helper loaded: utility_helper
INFO - 2017-03-02 23:53:52 --> Database Driver Class Initialized
DEBUG - 2017-03-02 23:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 23:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 23:53:52 --> User Agent Class Initialized
DEBUG - 2017-03-02 23:53:52 --> Template Class Initialized
INFO - 2017-03-02 23:53:52 --> Model Class Initialized
INFO - 2017-03-02 23:53:52 --> Controller Class Initialized
DEBUG - 2017-03-02 23:53:52 --> Pages MX_Controller Initialized
INFO - 2017-03-02 23:53:52 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 23:53:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 23:53:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 23:53:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-03-02 23:53:52 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 23:53:52 --> Final output sent to browser
DEBUG - 2017-03-02 23:53:52 --> Total execution time: 0.3616
INFO - 2017-03-02 23:53:54 --> Config Class Initialized
INFO - 2017-03-02 23:53:54 --> Hooks Class Initialized
DEBUG - 2017-03-02 23:53:54 --> UTF-8 Support Enabled
INFO - 2017-03-02 23:53:54 --> Utf8 Class Initialized
INFO - 2017-03-02 23:53:54 --> URI Class Initialized
INFO - 2017-03-02 23:53:54 --> Router Class Initialized
INFO - 2017-03-02 23:53:54 --> Output Class Initialized
INFO - 2017-03-02 23:53:54 --> Security Class Initialized
DEBUG - 2017-03-02 23:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-02 23:53:54 --> Input Class Initialized
INFO - 2017-03-02 23:53:54 --> Language Class Initialized
INFO - 2017-03-02 23:53:54 --> Language Class Initialized
INFO - 2017-03-02 23:53:54 --> Config Class Initialized
INFO - 2017-03-02 23:53:54 --> Loader Class Initialized
INFO - 2017-03-02 23:53:54 --> Helper loaded: form_helper
INFO - 2017-03-02 23:53:54 --> Helper loaded: url_helper
INFO - 2017-03-02 23:53:54 --> Helper loaded: utility_helper
INFO - 2017-03-02 23:53:54 --> Database Driver Class Initialized
DEBUG - 2017-03-02 23:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-02 23:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-02 23:53:54 --> User Agent Class Initialized
DEBUG - 2017-03-02 23:53:54 --> Template Class Initialized
INFO - 2017-03-02 23:53:54 --> Model Class Initialized
INFO - 2017-03-02 23:53:54 --> Controller Class Initialized
DEBUG - 2017-03-02 23:53:54 --> Pages MX_Controller Initialized
INFO - 2017-03-02 23:53:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-02 23:53:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-02 23:53:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-02 23:53:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-03-02 23:53:54 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-02 23:53:54 --> Final output sent to browser
DEBUG - 2017-03-02 23:53:54 --> Total execution time: 0.0251
