<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-01 00:49:54 --> Config Class Initialized
INFO - 2017-03-01 00:49:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:49:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:49:54 --> Utf8 Class Initialized
INFO - 2017-03-01 00:49:54 --> URI Class Initialized
INFO - 2017-03-01 00:49:54 --> Router Class Initialized
INFO - 2017-03-01 00:49:54 --> Output Class Initialized
INFO - 2017-03-01 00:49:54 --> Security Class Initialized
DEBUG - 2017-03-01 00:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:49:54 --> Input Class Initialized
INFO - 2017-03-01 00:49:54 --> Language Class Initialized
INFO - 2017-03-01 00:49:54 --> Language Class Initialized
INFO - 2017-03-01 00:49:54 --> Config Class Initialized
INFO - 2017-03-01 00:49:54 --> Loader Class Initialized
INFO - 2017-03-01 00:49:54 --> Helper loaded: form_helper
INFO - 2017-03-01 00:49:54 --> Helper loaded: url_helper
INFO - 2017-03-01 00:49:54 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:49:54 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:49:55 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:49:55 --> Template Class Initialized
INFO - 2017-03-01 00:49:55 --> Model Class Initialized
INFO - 2017-03-01 00:49:55 --> Controller Class Initialized
DEBUG - 2017-03-01 00:49:55 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:49:55 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:49:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:49:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 00:49:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/about_us.php
DEBUG - 2017-03-01 00:49:55 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 00:49:55 --> Final output sent to browser
DEBUG - 2017-03-01 00:49:55 --> Total execution time: 0.4103
INFO - 2017-03-01 00:49:59 --> Config Class Initialized
INFO - 2017-03-01 00:49:59 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:49:59 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:49:59 --> Utf8 Class Initialized
INFO - 2017-03-01 00:49:59 --> URI Class Initialized
INFO - 2017-03-01 00:49:59 --> Router Class Initialized
INFO - 2017-03-01 00:49:59 --> Output Class Initialized
INFO - 2017-03-01 00:49:59 --> Security Class Initialized
DEBUG - 2017-03-01 00:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:49:59 --> Input Class Initialized
INFO - 2017-03-01 00:49:59 --> Language Class Initialized
INFO - 2017-03-01 00:49:59 --> Language Class Initialized
INFO - 2017-03-01 00:49:59 --> Config Class Initialized
INFO - 2017-03-01 00:49:59 --> Loader Class Initialized
INFO - 2017-03-01 00:49:59 --> Helper loaded: form_helper
INFO - 2017-03-01 00:49:59 --> Helper loaded: url_helper
INFO - 2017-03-01 00:49:59 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:49:59 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:49:59 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:49:59 --> Template Class Initialized
INFO - 2017-03-01 00:49:59 --> Model Class Initialized
INFO - 2017-03-01 00:49:59 --> Controller Class Initialized
DEBUG - 2017-03-01 00:49:59 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:49:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:49:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:49:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 00:50:02 --> Config Class Initialized
INFO - 2017-03-01 00:50:02 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:50:02 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:50:02 --> Utf8 Class Initialized
INFO - 2017-03-01 00:50:02 --> URI Class Initialized
INFO - 2017-03-01 00:50:02 --> Router Class Initialized
INFO - 2017-03-01 00:50:02 --> Output Class Initialized
INFO - 2017-03-01 00:50:02 --> Security Class Initialized
DEBUG - 2017-03-01 00:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:50:02 --> Input Class Initialized
INFO - 2017-03-01 00:50:02 --> Language Class Initialized
INFO - 2017-03-01 00:50:02 --> Language Class Initialized
INFO - 2017-03-01 00:50:02 --> Config Class Initialized
INFO - 2017-03-01 00:50:02 --> Loader Class Initialized
INFO - 2017-03-01 00:50:02 --> Helper loaded: form_helper
INFO - 2017-03-01 00:50:02 --> Helper loaded: url_helper
INFO - 2017-03-01 00:50:02 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:50:02 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:50:02 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:50:02 --> Template Class Initialized
INFO - 2017-03-01 00:50:02 --> Model Class Initialized
INFO - 2017-03-01 00:50:02 --> Controller Class Initialized
DEBUG - 2017-03-01 00:50:02 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:50:02 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:50:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:50:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 00:50:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/support.php
DEBUG - 2017-03-01 00:50:02 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 00:50:02 --> Final output sent to browser
DEBUG - 2017-03-01 00:50:02 --> Total execution time: 0.0496
INFO - 2017-03-01 00:50:03 --> Config Class Initialized
INFO - 2017-03-01 00:50:03 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:50:03 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:50:03 --> Utf8 Class Initialized
INFO - 2017-03-01 00:50:03 --> URI Class Initialized
INFO - 2017-03-01 00:50:03 --> Router Class Initialized
INFO - 2017-03-01 00:50:03 --> Output Class Initialized
INFO - 2017-03-01 00:50:03 --> Security Class Initialized
DEBUG - 2017-03-01 00:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:50:03 --> Input Class Initialized
INFO - 2017-03-01 00:50:03 --> Language Class Initialized
INFO - 2017-03-01 00:50:03 --> Language Class Initialized
INFO - 2017-03-01 00:50:03 --> Config Class Initialized
INFO - 2017-03-01 00:50:03 --> Loader Class Initialized
INFO - 2017-03-01 00:50:03 --> Helper loaded: form_helper
INFO - 2017-03-01 00:50:03 --> Helper loaded: url_helper
INFO - 2017-03-01 00:50:03 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:50:03 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:50:03 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:50:03 --> Template Class Initialized
INFO - 2017-03-01 00:50:03 --> Model Class Initialized
INFO - 2017-03-01 00:50:03 --> Controller Class Initialized
DEBUG - 2017-03-01 00:50:03 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:50:03 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:50:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:50:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 00:50:06 --> Config Class Initialized
INFO - 2017-03-01 00:50:06 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:50:06 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:50:06 --> Utf8 Class Initialized
INFO - 2017-03-01 00:50:06 --> URI Class Initialized
INFO - 2017-03-01 00:50:06 --> Router Class Initialized
INFO - 2017-03-01 00:50:06 --> Output Class Initialized
INFO - 2017-03-01 00:50:06 --> Security Class Initialized
DEBUG - 2017-03-01 00:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:50:06 --> Input Class Initialized
INFO - 2017-03-01 00:50:06 --> Language Class Initialized
INFO - 2017-03-01 00:50:06 --> Language Class Initialized
INFO - 2017-03-01 00:50:06 --> Config Class Initialized
INFO - 2017-03-01 00:50:06 --> Loader Class Initialized
INFO - 2017-03-01 00:50:06 --> Helper loaded: form_helper
INFO - 2017-03-01 00:50:06 --> Helper loaded: url_helper
INFO - 2017-03-01 00:50:06 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:50:06 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:50:06 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:50:06 --> Template Class Initialized
INFO - 2017-03-01 00:50:06 --> Model Class Initialized
INFO - 2017-03-01 00:50:06 --> Controller Class Initialized
DEBUG - 2017-03-01 00:50:06 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:50:06 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:50:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:50:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 00:50:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-03-01 00:50:06 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 00:50:06 --> Final output sent to browser
DEBUG - 2017-03-01 00:50:06 --> Total execution time: 0.0443
INFO - 2017-03-01 00:50:07 --> Config Class Initialized
INFO - 2017-03-01 00:50:07 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:50:07 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:50:07 --> Utf8 Class Initialized
INFO - 2017-03-01 00:50:07 --> URI Class Initialized
INFO - 2017-03-01 00:50:07 --> Router Class Initialized
INFO - 2017-03-01 00:50:07 --> Output Class Initialized
INFO - 2017-03-01 00:50:07 --> Security Class Initialized
DEBUG - 2017-03-01 00:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:50:07 --> Input Class Initialized
INFO - 2017-03-01 00:50:07 --> Language Class Initialized
INFO - 2017-03-01 00:50:07 --> Language Class Initialized
INFO - 2017-03-01 00:50:07 --> Config Class Initialized
INFO - 2017-03-01 00:50:07 --> Loader Class Initialized
INFO - 2017-03-01 00:50:07 --> Helper loaded: form_helper
INFO - 2017-03-01 00:50:07 --> Helper loaded: url_helper
INFO - 2017-03-01 00:50:07 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:50:07 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:50:07 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:50:07 --> Template Class Initialized
INFO - 2017-03-01 00:50:07 --> Model Class Initialized
INFO - 2017-03-01 00:50:07 --> Controller Class Initialized
DEBUG - 2017-03-01 00:50:07 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:50:07 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:50:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:50:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 00:50:39 --> Config Class Initialized
INFO - 2017-03-01 00:50:39 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:50:39 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:50:39 --> Utf8 Class Initialized
INFO - 2017-03-01 00:50:39 --> URI Class Initialized
DEBUG - 2017-03-01 00:50:39 --> No URI present. Default controller set.
INFO - 2017-03-01 00:50:39 --> Router Class Initialized
INFO - 2017-03-01 00:50:39 --> Output Class Initialized
INFO - 2017-03-01 00:50:39 --> Security Class Initialized
DEBUG - 2017-03-01 00:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:50:39 --> Input Class Initialized
INFO - 2017-03-01 00:50:39 --> Language Class Initialized
INFO - 2017-03-01 00:50:39 --> Language Class Initialized
INFO - 2017-03-01 00:50:39 --> Config Class Initialized
INFO - 2017-03-01 00:50:39 --> Loader Class Initialized
INFO - 2017-03-01 00:50:39 --> Helper loaded: form_helper
INFO - 2017-03-01 00:50:39 --> Helper loaded: url_helper
INFO - 2017-03-01 00:50:39 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:50:39 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:50:39 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:50:39 --> Template Class Initialized
INFO - 2017-03-01 00:50:39 --> Model Class Initialized
INFO - 2017-03-01 00:50:39 --> Controller Class Initialized
DEBUG - 2017-03-01 00:50:39 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:50:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:50:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:50:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 00:50:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-01 00:50:39 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 00:50:39 --> Final output sent to browser
DEBUG - 2017-03-01 00:50:39 --> Total execution time: 0.0202
INFO - 2017-03-01 00:50:39 --> Config Class Initialized
INFO - 2017-03-01 00:50:39 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:50:39 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:50:39 --> Utf8 Class Initialized
INFO - 2017-03-01 00:50:39 --> URI Class Initialized
INFO - 2017-03-01 00:50:39 --> Router Class Initialized
INFO - 2017-03-01 00:50:39 --> Output Class Initialized
INFO - 2017-03-01 00:50:39 --> Security Class Initialized
DEBUG - 2017-03-01 00:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:50:39 --> Input Class Initialized
INFO - 2017-03-01 00:50:39 --> Language Class Initialized
INFO - 2017-03-01 00:50:39 --> Language Class Initialized
INFO - 2017-03-01 00:50:39 --> Config Class Initialized
INFO - 2017-03-01 00:50:39 --> Loader Class Initialized
INFO - 2017-03-01 00:50:39 --> Helper loaded: form_helper
INFO - 2017-03-01 00:50:39 --> Helper loaded: url_helper
INFO - 2017-03-01 00:50:39 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:50:39 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:50:39 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:50:39 --> Template Class Initialized
INFO - 2017-03-01 00:50:39 --> Model Class Initialized
INFO - 2017-03-01 00:50:39 --> Controller Class Initialized
DEBUG - 2017-03-01 00:50:39 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:50:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:50:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:50:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 00:50:41 --> Config Class Initialized
INFO - 2017-03-01 00:50:41 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:50:41 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:50:41 --> Utf8 Class Initialized
INFO - 2017-03-01 00:50:41 --> URI Class Initialized
INFO - 2017-03-01 00:50:41 --> Router Class Initialized
INFO - 2017-03-01 00:50:41 --> Output Class Initialized
INFO - 2017-03-01 00:50:41 --> Security Class Initialized
DEBUG - 2017-03-01 00:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:50:41 --> Input Class Initialized
INFO - 2017-03-01 00:50:41 --> Language Class Initialized
INFO - 2017-03-01 00:50:41 --> Language Class Initialized
INFO - 2017-03-01 00:50:41 --> Config Class Initialized
INFO - 2017-03-01 00:50:41 --> Loader Class Initialized
INFO - 2017-03-01 00:50:41 --> Helper loaded: form_helper
INFO - 2017-03-01 00:50:41 --> Helper loaded: url_helper
INFO - 2017-03-01 00:50:41 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:50:41 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:50:41 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:50:41 --> Template Class Initialized
INFO - 2017-03-01 00:50:41 --> Model Class Initialized
INFO - 2017-03-01 00:50:41 --> Controller Class Initialized
DEBUG - 2017-03-01 00:50:41 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:50:41 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:50:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:50:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 00:51:05 --> Config Class Initialized
INFO - 2017-03-01 00:51:05 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:51:05 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:51:05 --> Utf8 Class Initialized
INFO - 2017-03-01 00:51:05 --> URI Class Initialized
INFO - 2017-03-01 00:51:05 --> Router Class Initialized
INFO - 2017-03-01 00:51:05 --> Output Class Initialized
INFO - 2017-03-01 00:51:05 --> Security Class Initialized
DEBUG - 2017-03-01 00:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:51:05 --> Input Class Initialized
INFO - 2017-03-01 00:51:05 --> Language Class Initialized
INFO - 2017-03-01 00:51:05 --> Language Class Initialized
INFO - 2017-03-01 00:51:05 --> Config Class Initialized
INFO - 2017-03-01 00:51:05 --> Loader Class Initialized
INFO - 2017-03-01 00:51:05 --> Helper loaded: form_helper
INFO - 2017-03-01 00:51:05 --> Helper loaded: url_helper
INFO - 2017-03-01 00:51:05 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:51:05 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:51:05 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:51:05 --> Template Class Initialized
INFO - 2017-03-01 00:51:05 --> Model Class Initialized
INFO - 2017-03-01 00:51:05 --> Controller Class Initialized
DEBUG - 2017-03-01 00:51:05 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:51:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:51:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:51:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 00:51:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/support.php
DEBUG - 2017-03-01 00:51:05 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 00:51:05 --> Final output sent to browser
DEBUG - 2017-03-01 00:51:05 --> Total execution time: 0.0132
INFO - 2017-03-01 00:51:05 --> Config Class Initialized
INFO - 2017-03-01 00:51:05 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:51:05 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:51:05 --> Utf8 Class Initialized
INFO - 2017-03-01 00:51:05 --> URI Class Initialized
INFO - 2017-03-01 00:51:05 --> Router Class Initialized
INFO - 2017-03-01 00:51:05 --> Output Class Initialized
INFO - 2017-03-01 00:51:05 --> Security Class Initialized
DEBUG - 2017-03-01 00:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:51:05 --> Input Class Initialized
INFO - 2017-03-01 00:51:05 --> Language Class Initialized
INFO - 2017-03-01 00:51:05 --> Language Class Initialized
INFO - 2017-03-01 00:51:05 --> Config Class Initialized
INFO - 2017-03-01 00:51:05 --> Loader Class Initialized
INFO - 2017-03-01 00:51:05 --> Helper loaded: form_helper
INFO - 2017-03-01 00:51:05 --> Helper loaded: url_helper
INFO - 2017-03-01 00:51:05 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:51:05 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:51:05 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:51:05 --> Template Class Initialized
INFO - 2017-03-01 00:51:05 --> Model Class Initialized
INFO - 2017-03-01 00:51:05 --> Controller Class Initialized
DEBUG - 2017-03-01 00:51:05 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:51:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:51:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:51:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 00:51:07 --> Config Class Initialized
INFO - 2017-03-01 00:51:07 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:51:07 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:51:07 --> Utf8 Class Initialized
INFO - 2017-03-01 00:51:07 --> URI Class Initialized
INFO - 2017-03-01 00:51:07 --> Router Class Initialized
INFO - 2017-03-01 00:51:07 --> Output Class Initialized
INFO - 2017-03-01 00:51:07 --> Security Class Initialized
DEBUG - 2017-03-01 00:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:51:07 --> Input Class Initialized
INFO - 2017-03-01 00:51:07 --> Language Class Initialized
INFO - 2017-03-01 00:51:07 --> Language Class Initialized
INFO - 2017-03-01 00:51:07 --> Config Class Initialized
INFO - 2017-03-01 00:51:07 --> Loader Class Initialized
INFO - 2017-03-01 00:51:07 --> Helper loaded: form_helper
INFO - 2017-03-01 00:51:07 --> Helper loaded: url_helper
INFO - 2017-03-01 00:51:07 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:51:07 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:51:07 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:51:07 --> Template Class Initialized
INFO - 2017-03-01 00:51:07 --> Model Class Initialized
INFO - 2017-03-01 00:51:07 --> Controller Class Initialized
DEBUG - 2017-03-01 00:51:07 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:51:07 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:51:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:51:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 00:51:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-03-01 00:51:07 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 00:51:07 --> Final output sent to browser
DEBUG - 2017-03-01 00:51:07 --> Total execution time: 0.0137
INFO - 2017-03-01 00:51:08 --> Config Class Initialized
INFO - 2017-03-01 00:51:08 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:51:08 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:51:08 --> Utf8 Class Initialized
INFO - 2017-03-01 00:51:08 --> URI Class Initialized
INFO - 2017-03-01 00:51:08 --> Router Class Initialized
INFO - 2017-03-01 00:51:08 --> Output Class Initialized
INFO - 2017-03-01 00:51:08 --> Security Class Initialized
DEBUG - 2017-03-01 00:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:51:08 --> Input Class Initialized
INFO - 2017-03-01 00:51:08 --> Language Class Initialized
INFO - 2017-03-01 00:51:08 --> Language Class Initialized
INFO - 2017-03-01 00:51:08 --> Config Class Initialized
INFO - 2017-03-01 00:51:08 --> Loader Class Initialized
INFO - 2017-03-01 00:51:08 --> Helper loaded: form_helper
INFO - 2017-03-01 00:51:08 --> Helper loaded: url_helper
INFO - 2017-03-01 00:51:08 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:51:08 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:51:08 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:51:08 --> Template Class Initialized
INFO - 2017-03-01 00:51:08 --> Model Class Initialized
INFO - 2017-03-01 00:51:08 --> Controller Class Initialized
DEBUG - 2017-03-01 00:51:08 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:51:08 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:51:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:51:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 00:51:09 --> Config Class Initialized
INFO - 2017-03-01 00:51:09 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:51:09 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:51:09 --> Utf8 Class Initialized
INFO - 2017-03-01 00:51:09 --> URI Class Initialized
INFO - 2017-03-01 00:51:09 --> Router Class Initialized
INFO - 2017-03-01 00:51:09 --> Output Class Initialized
INFO - 2017-03-01 00:51:09 --> Security Class Initialized
DEBUG - 2017-03-01 00:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:51:09 --> Input Class Initialized
INFO - 2017-03-01 00:51:09 --> Language Class Initialized
INFO - 2017-03-01 00:51:09 --> Language Class Initialized
INFO - 2017-03-01 00:51:09 --> Config Class Initialized
INFO - 2017-03-01 00:51:09 --> Loader Class Initialized
INFO - 2017-03-01 00:51:09 --> Helper loaded: form_helper
INFO - 2017-03-01 00:51:09 --> Helper loaded: url_helper
INFO - 2017-03-01 00:51:09 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:51:09 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:51:09 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:51:09 --> Template Class Initialized
INFO - 2017-03-01 00:51:09 --> Model Class Initialized
INFO - 2017-03-01 00:51:09 --> Controller Class Initialized
DEBUG - 2017-03-01 00:51:09 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:51:09 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:51:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:51:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 00:51:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/about_us.php
DEBUG - 2017-03-01 00:51:09 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 00:51:09 --> Final output sent to browser
DEBUG - 2017-03-01 00:51:09 --> Total execution time: 0.0149
INFO - 2017-03-01 00:51:10 --> Config Class Initialized
INFO - 2017-03-01 00:51:10 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:51:10 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:51:10 --> Utf8 Class Initialized
INFO - 2017-03-01 00:51:10 --> URI Class Initialized
INFO - 2017-03-01 00:51:10 --> Router Class Initialized
INFO - 2017-03-01 00:51:10 --> Output Class Initialized
INFO - 2017-03-01 00:51:10 --> Security Class Initialized
DEBUG - 2017-03-01 00:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:51:10 --> Input Class Initialized
INFO - 2017-03-01 00:51:10 --> Language Class Initialized
INFO - 2017-03-01 00:51:10 --> Language Class Initialized
INFO - 2017-03-01 00:51:10 --> Config Class Initialized
INFO - 2017-03-01 00:51:10 --> Loader Class Initialized
INFO - 2017-03-01 00:51:10 --> Helper loaded: form_helper
INFO - 2017-03-01 00:51:10 --> Helper loaded: url_helper
INFO - 2017-03-01 00:51:10 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:51:10 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:51:10 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:51:10 --> Template Class Initialized
INFO - 2017-03-01 00:51:10 --> Model Class Initialized
INFO - 2017-03-01 00:51:10 --> Controller Class Initialized
DEBUG - 2017-03-01 00:51:10 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:51:10 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:51:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:51:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 00:53:29 --> Config Class Initialized
INFO - 2017-03-01 00:53:29 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:53:29 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:53:29 --> Utf8 Class Initialized
INFO - 2017-03-01 00:53:29 --> URI Class Initialized
INFO - 2017-03-01 00:53:29 --> Router Class Initialized
INFO - 2017-03-01 00:53:29 --> Output Class Initialized
INFO - 2017-03-01 00:53:29 --> Security Class Initialized
DEBUG - 2017-03-01 00:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:53:29 --> Input Class Initialized
INFO - 2017-03-01 00:53:29 --> Language Class Initialized
INFO - 2017-03-01 00:53:29 --> Language Class Initialized
INFO - 2017-03-01 00:53:29 --> Config Class Initialized
INFO - 2017-03-01 00:53:29 --> Loader Class Initialized
INFO - 2017-03-01 00:53:29 --> Helper loaded: form_helper
INFO - 2017-03-01 00:53:29 --> Helper loaded: url_helper
INFO - 2017-03-01 00:53:29 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:53:29 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:53:29 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:53:29 --> Template Class Initialized
INFO - 2017-03-01 00:53:29 --> Model Class Initialized
INFO - 2017-03-01 00:53:29 --> Controller Class Initialized
DEBUG - 2017-03-01 00:53:29 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:53:29 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:53:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:53:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 00:53:32 --> Config Class Initialized
INFO - 2017-03-01 00:53:32 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:53:32 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:53:32 --> Utf8 Class Initialized
INFO - 2017-03-01 00:53:32 --> URI Class Initialized
DEBUG - 2017-03-01 00:53:32 --> No URI present. Default controller set.
INFO - 2017-03-01 00:53:32 --> Router Class Initialized
INFO - 2017-03-01 00:53:32 --> Output Class Initialized
INFO - 2017-03-01 00:53:32 --> Security Class Initialized
DEBUG - 2017-03-01 00:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:53:32 --> Input Class Initialized
INFO - 2017-03-01 00:53:32 --> Language Class Initialized
INFO - 2017-03-01 00:53:32 --> Language Class Initialized
INFO - 2017-03-01 00:53:32 --> Config Class Initialized
INFO - 2017-03-01 00:53:32 --> Loader Class Initialized
INFO - 2017-03-01 00:53:32 --> Helper loaded: form_helper
INFO - 2017-03-01 00:53:32 --> Helper loaded: url_helper
INFO - 2017-03-01 00:53:32 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:53:32 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:53:32 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:53:32 --> Template Class Initialized
INFO - 2017-03-01 00:53:32 --> Model Class Initialized
INFO - 2017-03-01 00:53:32 --> Controller Class Initialized
DEBUG - 2017-03-01 00:53:32 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:53:32 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:53:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:53:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 00:53:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-01 00:53:32 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 00:53:32 --> Final output sent to browser
DEBUG - 2017-03-01 00:53:32 --> Total execution time: 0.0101
INFO - 2017-03-01 00:53:35 --> Config Class Initialized
INFO - 2017-03-01 00:53:35 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:53:35 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:53:35 --> Utf8 Class Initialized
INFO - 2017-03-01 00:53:35 --> URI Class Initialized
INFO - 2017-03-01 00:53:35 --> Router Class Initialized
INFO - 2017-03-01 00:53:35 --> Output Class Initialized
INFO - 2017-03-01 00:53:35 --> Security Class Initialized
DEBUG - 2017-03-01 00:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:53:35 --> Input Class Initialized
INFO - 2017-03-01 00:53:35 --> Language Class Initialized
INFO - 2017-03-01 00:53:35 --> Language Class Initialized
INFO - 2017-03-01 00:53:35 --> Config Class Initialized
INFO - 2017-03-01 00:53:35 --> Loader Class Initialized
INFO - 2017-03-01 00:53:35 --> Helper loaded: form_helper
INFO - 2017-03-01 00:53:35 --> Helper loaded: url_helper
INFO - 2017-03-01 00:53:35 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:53:35 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:53:35 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:53:35 --> Template Class Initialized
INFO - 2017-03-01 00:53:35 --> Model Class Initialized
INFO - 2017-03-01 00:53:35 --> Controller Class Initialized
DEBUG - 2017-03-01 00:53:35 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:53:35 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:53:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:53:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 00:53:35 --> Config Class Initialized
INFO - 2017-03-01 00:53:35 --> Hooks Class Initialized
DEBUG - 2017-03-01 00:53:35 --> UTF-8 Support Enabled
INFO - 2017-03-01 00:53:35 --> Utf8 Class Initialized
INFO - 2017-03-01 00:53:35 --> URI Class Initialized
INFO - 2017-03-01 00:53:35 --> Router Class Initialized
INFO - 2017-03-01 00:53:35 --> Output Class Initialized
INFO - 2017-03-01 00:53:35 --> Security Class Initialized
DEBUG - 2017-03-01 00:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 00:53:35 --> Input Class Initialized
INFO - 2017-03-01 00:53:35 --> Language Class Initialized
INFO - 2017-03-01 00:53:35 --> Language Class Initialized
INFO - 2017-03-01 00:53:35 --> Config Class Initialized
INFO - 2017-03-01 00:53:35 --> Loader Class Initialized
INFO - 2017-03-01 00:53:35 --> Helper loaded: form_helper
INFO - 2017-03-01 00:53:35 --> Helper loaded: url_helper
INFO - 2017-03-01 00:53:35 --> Helper loaded: utility_helper
INFO - 2017-03-01 00:53:35 --> Database Driver Class Initialized
DEBUG - 2017-03-01 00:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 00:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 00:53:35 --> User Agent Class Initialized
DEBUG - 2017-03-01 00:53:35 --> Template Class Initialized
INFO - 2017-03-01 00:53:35 --> Model Class Initialized
INFO - 2017-03-01 00:53:35 --> Controller Class Initialized
DEBUG - 2017-03-01 00:53:35 --> Pages MX_Controller Initialized
INFO - 2017-03-01 00:53:35 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 00:53:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 00:53:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 01:06:15 --> Config Class Initialized
INFO - 2017-03-01 01:06:15 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:06:15 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:06:15 --> Utf8 Class Initialized
INFO - 2017-03-01 01:06:15 --> URI Class Initialized
INFO - 2017-03-01 01:06:15 --> Router Class Initialized
INFO - 2017-03-01 01:06:15 --> Output Class Initialized
INFO - 2017-03-01 01:06:15 --> Security Class Initialized
DEBUG - 2017-03-01 01:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:06:15 --> Input Class Initialized
INFO - 2017-03-01 01:06:15 --> Language Class Initialized
INFO - 2017-03-01 01:06:15 --> Language Class Initialized
INFO - 2017-03-01 01:06:15 --> Config Class Initialized
INFO - 2017-03-01 01:06:15 --> Loader Class Initialized
INFO - 2017-03-01 01:06:15 --> Helper loaded: form_helper
INFO - 2017-03-01 01:06:15 --> Helper loaded: url_helper
INFO - 2017-03-01 01:06:15 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:06:15 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:06:15 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:06:15 --> Template Class Initialized
INFO - 2017-03-01 01:06:15 --> Model Class Initialized
INFO - 2017-03-01 01:06:15 --> Controller Class Initialized
DEBUG - 2017-03-01 01:06:15 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:06:15 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:06:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:06:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 01:06:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/about_us.php
DEBUG - 2017-03-01 01:06:15 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 01:06:15 --> Final output sent to browser
DEBUG - 2017-03-01 01:06:15 --> Total execution time: 0.0643
INFO - 2017-03-01 01:06:17 --> Config Class Initialized
INFO - 2017-03-01 01:06:17 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:06:17 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:06:17 --> Utf8 Class Initialized
INFO - 2017-03-01 01:06:17 --> URI Class Initialized
INFO - 2017-03-01 01:06:17 --> Router Class Initialized
INFO - 2017-03-01 01:06:17 --> Output Class Initialized
INFO - 2017-03-01 01:06:17 --> Security Class Initialized
DEBUG - 2017-03-01 01:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:06:17 --> Input Class Initialized
INFO - 2017-03-01 01:06:17 --> Language Class Initialized
INFO - 2017-03-01 01:06:17 --> Language Class Initialized
INFO - 2017-03-01 01:06:17 --> Config Class Initialized
INFO - 2017-03-01 01:06:17 --> Loader Class Initialized
INFO - 2017-03-01 01:06:17 --> Helper loaded: form_helper
INFO - 2017-03-01 01:06:17 --> Helper loaded: url_helper
INFO - 2017-03-01 01:06:17 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:06:17 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:06:17 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:06:17 --> Template Class Initialized
INFO - 2017-03-01 01:06:17 --> Model Class Initialized
INFO - 2017-03-01 01:06:17 --> Controller Class Initialized
DEBUG - 2017-03-01 01:06:17 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:06:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:06:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:06:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 01:06:33 --> Config Class Initialized
INFO - 2017-03-01 01:06:33 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:06:33 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:06:33 --> Utf8 Class Initialized
INFO - 2017-03-01 01:06:33 --> URI Class Initialized
INFO - 2017-03-01 01:06:33 --> Router Class Initialized
INFO - 2017-03-01 01:06:33 --> Output Class Initialized
INFO - 2017-03-01 01:06:33 --> Security Class Initialized
DEBUG - 2017-03-01 01:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:06:33 --> Input Class Initialized
INFO - 2017-03-01 01:06:33 --> Language Class Initialized
INFO - 2017-03-01 01:06:33 --> Language Class Initialized
INFO - 2017-03-01 01:06:33 --> Config Class Initialized
INFO - 2017-03-01 01:06:33 --> Loader Class Initialized
INFO - 2017-03-01 01:06:33 --> Helper loaded: form_helper
INFO - 2017-03-01 01:06:33 --> Helper loaded: url_helper
INFO - 2017-03-01 01:06:33 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:06:33 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:06:33 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:06:33 --> Template Class Initialized
INFO - 2017-03-01 01:06:33 --> Model Class Initialized
INFO - 2017-03-01 01:06:33 --> Controller Class Initialized
DEBUG - 2017-03-01 01:06:33 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:06:33 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:06:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:06:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 01:06:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/support.php
DEBUG - 2017-03-01 01:06:33 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 01:06:33 --> Final output sent to browser
DEBUG - 2017-03-01 01:06:33 --> Total execution time: 0.0142
INFO - 2017-03-01 01:06:33 --> Config Class Initialized
INFO - 2017-03-01 01:06:33 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:06:33 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:06:33 --> Utf8 Class Initialized
INFO - 2017-03-01 01:06:33 --> URI Class Initialized
INFO - 2017-03-01 01:06:33 --> Router Class Initialized
INFO - 2017-03-01 01:06:33 --> Output Class Initialized
INFO - 2017-03-01 01:06:33 --> Security Class Initialized
DEBUG - 2017-03-01 01:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:06:33 --> Input Class Initialized
INFO - 2017-03-01 01:06:33 --> Language Class Initialized
INFO - 2017-03-01 01:06:33 --> Language Class Initialized
INFO - 2017-03-01 01:06:33 --> Config Class Initialized
INFO - 2017-03-01 01:06:33 --> Loader Class Initialized
INFO - 2017-03-01 01:06:33 --> Helper loaded: form_helper
INFO - 2017-03-01 01:06:33 --> Helper loaded: url_helper
INFO - 2017-03-01 01:06:33 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:06:33 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:06:33 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:06:33 --> Template Class Initialized
INFO - 2017-03-01 01:06:33 --> Model Class Initialized
INFO - 2017-03-01 01:06:33 --> Controller Class Initialized
DEBUG - 2017-03-01 01:06:33 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:06:33 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:06:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:06:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 01:06:40 --> Config Class Initialized
INFO - 2017-03-01 01:06:40 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:06:40 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:06:40 --> Utf8 Class Initialized
INFO - 2017-03-01 01:06:40 --> URI Class Initialized
INFO - 2017-03-01 01:06:40 --> Router Class Initialized
INFO - 2017-03-01 01:06:40 --> Output Class Initialized
INFO - 2017-03-01 01:06:40 --> Security Class Initialized
DEBUG - 2017-03-01 01:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:06:40 --> Input Class Initialized
INFO - 2017-03-01 01:06:40 --> Language Class Initialized
INFO - 2017-03-01 01:06:40 --> Language Class Initialized
INFO - 2017-03-01 01:06:40 --> Config Class Initialized
INFO - 2017-03-01 01:06:40 --> Loader Class Initialized
INFO - 2017-03-01 01:06:40 --> Helper loaded: form_helper
INFO - 2017-03-01 01:06:40 --> Helper loaded: url_helper
INFO - 2017-03-01 01:06:40 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:06:40 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:06:40 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:06:40 --> Template Class Initialized
INFO - 2017-03-01 01:06:40 --> Model Class Initialized
INFO - 2017-03-01 01:06:40 --> Controller Class Initialized
DEBUG - 2017-03-01 01:06:40 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:06:40 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:06:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:06:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 01:06:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-03-01 01:06:40 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 01:06:40 --> Final output sent to browser
DEBUG - 2017-03-01 01:06:40 --> Total execution time: 0.0142
INFO - 2017-03-01 01:06:40 --> Config Class Initialized
INFO - 2017-03-01 01:06:40 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:06:40 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:06:40 --> Utf8 Class Initialized
INFO - 2017-03-01 01:06:40 --> URI Class Initialized
INFO - 2017-03-01 01:06:40 --> Router Class Initialized
INFO - 2017-03-01 01:06:40 --> Output Class Initialized
INFO - 2017-03-01 01:06:40 --> Security Class Initialized
DEBUG - 2017-03-01 01:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:06:40 --> Input Class Initialized
INFO - 2017-03-01 01:06:40 --> Language Class Initialized
INFO - 2017-03-01 01:06:40 --> Language Class Initialized
INFO - 2017-03-01 01:06:40 --> Config Class Initialized
INFO - 2017-03-01 01:06:40 --> Loader Class Initialized
INFO - 2017-03-01 01:06:40 --> Helper loaded: form_helper
INFO - 2017-03-01 01:06:40 --> Helper loaded: url_helper
INFO - 2017-03-01 01:06:40 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:06:40 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:06:40 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:06:40 --> Template Class Initialized
INFO - 2017-03-01 01:06:40 --> Model Class Initialized
INFO - 2017-03-01 01:06:40 --> Controller Class Initialized
DEBUG - 2017-03-01 01:06:40 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:06:40 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:06:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:06:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 01:07:08 --> Config Class Initialized
INFO - 2017-03-01 01:07:08 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:07:08 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:07:08 --> Utf8 Class Initialized
INFO - 2017-03-01 01:07:08 --> URI Class Initialized
INFO - 2017-03-01 01:07:08 --> Router Class Initialized
INFO - 2017-03-01 01:07:08 --> Output Class Initialized
INFO - 2017-03-01 01:07:08 --> Security Class Initialized
DEBUG - 2017-03-01 01:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:07:08 --> Input Class Initialized
INFO - 2017-03-01 01:07:08 --> Language Class Initialized
INFO - 2017-03-01 01:07:08 --> Language Class Initialized
INFO - 2017-03-01 01:07:08 --> Config Class Initialized
INFO - 2017-03-01 01:07:08 --> Loader Class Initialized
INFO - 2017-03-01 01:07:08 --> Helper loaded: form_helper
INFO - 2017-03-01 01:07:08 --> Helper loaded: url_helper
INFO - 2017-03-01 01:07:08 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:07:08 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:07:08 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:07:08 --> Template Class Initialized
INFO - 2017-03-01 01:07:08 --> Model Class Initialized
INFO - 2017-03-01 01:07:08 --> Controller Class Initialized
DEBUG - 2017-03-01 01:07:08 --> Login MX_Controller Initialized
INFO - 2017-03-01 01:07:08 --> Helper loaded: cookie_helper
INFO - 2017-03-01 01:07:08 --> Form Validation Class Initialized
INFO - 2017-03-01 01:07:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-01 01:07:08 --> Config Class Initialized
INFO - 2017-03-01 01:07:08 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:07:08 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:07:08 --> Utf8 Class Initialized
INFO - 2017-03-01 01:07:08 --> URI Class Initialized
INFO - 2017-03-01 01:07:08 --> Router Class Initialized
INFO - 2017-03-01 01:07:08 --> Output Class Initialized
INFO - 2017-03-01 01:07:08 --> Security Class Initialized
DEBUG - 2017-03-01 01:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:07:08 --> Input Class Initialized
INFO - 2017-03-01 01:07:08 --> Language Class Initialized
INFO - 2017-03-01 01:07:08 --> Language Class Initialized
INFO - 2017-03-01 01:07:08 --> Config Class Initialized
INFO - 2017-03-01 01:07:08 --> Loader Class Initialized
INFO - 2017-03-01 01:07:08 --> Helper loaded: form_helper
INFO - 2017-03-01 01:07:08 --> Helper loaded: url_helper
INFO - 2017-03-01 01:07:08 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:07:08 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:07:08 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:07:08 --> Template Class Initialized
INFO - 2017-03-01 01:07:08 --> Model Class Initialized
INFO - 2017-03-01 01:07:08 --> Controller Class Initialized
DEBUG - 2017-03-01 01:07:08 --> Dashboard MX_Controller Initialized
INFO - 2017-03-01 01:07:08 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:07:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-01 01:07:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-03-01 01:07:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-01 01:07:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-01 01:07:08 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-01 01:07:08 --> Final output sent to browser
DEBUG - 2017-03-01 01:07:08 --> Total execution time: 0.0586
INFO - 2017-03-01 01:07:45 --> Config Class Initialized
INFO - 2017-03-01 01:07:45 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:07:45 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:07:45 --> Utf8 Class Initialized
INFO - 2017-03-01 01:07:45 --> URI Class Initialized
INFO - 2017-03-01 01:07:45 --> Router Class Initialized
INFO - 2017-03-01 01:07:45 --> Output Class Initialized
INFO - 2017-03-01 01:07:45 --> Security Class Initialized
DEBUG - 2017-03-01 01:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:07:45 --> Input Class Initialized
INFO - 2017-03-01 01:07:45 --> Language Class Initialized
INFO - 2017-03-01 01:07:45 --> Language Class Initialized
INFO - 2017-03-01 01:07:45 --> Config Class Initialized
INFO - 2017-03-01 01:07:45 --> Loader Class Initialized
INFO - 2017-03-01 01:07:45 --> Helper loaded: form_helper
INFO - 2017-03-01 01:07:45 --> Helper loaded: url_helper
INFO - 2017-03-01 01:07:45 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:07:45 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:07:45 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:07:45 --> Template Class Initialized
INFO - 2017-03-01 01:07:45 --> Model Class Initialized
INFO - 2017-03-01 01:07:45 --> Controller Class Initialized
DEBUG - 2017-03-01 01:07:45 --> Dashboard MX_Controller Initialized
INFO - 2017-03-01 01:07:45 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:07:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-01 01:07:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-03-01 01:07:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-01 01:07:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/my_subscribers.php
DEBUG - 2017-03-01 01:07:46 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-01 01:07:46 --> Final output sent to browser
DEBUG - 2017-03-01 01:07:46 --> Total execution time: 0.0207
INFO - 2017-03-01 01:07:48 --> Config Class Initialized
INFO - 2017-03-01 01:07:48 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:07:48 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:07:48 --> Utf8 Class Initialized
INFO - 2017-03-01 01:07:48 --> URI Class Initialized
INFO - 2017-03-01 01:07:48 --> Router Class Initialized
INFO - 2017-03-01 01:07:48 --> Output Class Initialized
INFO - 2017-03-01 01:07:48 --> Security Class Initialized
DEBUG - 2017-03-01 01:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:07:48 --> Input Class Initialized
INFO - 2017-03-01 01:07:48 --> Language Class Initialized
INFO - 2017-03-01 01:07:48 --> Language Class Initialized
INFO - 2017-03-01 01:07:48 --> Config Class Initialized
INFO - 2017-03-01 01:07:48 --> Loader Class Initialized
INFO - 2017-03-01 01:07:48 --> Helper loaded: form_helper
INFO - 2017-03-01 01:07:48 --> Helper loaded: url_helper
INFO - 2017-03-01 01:07:48 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:07:48 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:07:48 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:07:48 --> Template Class Initialized
INFO - 2017-03-01 01:07:48 --> Model Class Initialized
INFO - 2017-03-01 01:07:48 --> Controller Class Initialized
DEBUG - 2017-03-01 01:07:48 --> Dashboard MX_Controller Initialized
INFO - 2017-03-01 01:07:48 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:07:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-01 01:07:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-03-01 01:07:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-01 01:07:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/order_history.php
DEBUG - 2017-03-01 01:07:48 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-01 01:07:48 --> Final output sent to browser
DEBUG - 2017-03-01 01:07:48 --> Total execution time: 0.0172
INFO - 2017-03-01 01:07:50 --> Config Class Initialized
INFO - 2017-03-01 01:07:50 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:07:50 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:07:50 --> Utf8 Class Initialized
INFO - 2017-03-01 01:07:50 --> URI Class Initialized
INFO - 2017-03-01 01:07:50 --> Router Class Initialized
INFO - 2017-03-01 01:07:50 --> Output Class Initialized
INFO - 2017-03-01 01:07:50 --> Security Class Initialized
DEBUG - 2017-03-01 01:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:07:50 --> Input Class Initialized
INFO - 2017-03-01 01:07:50 --> Language Class Initialized
INFO - 2017-03-01 01:07:50 --> Language Class Initialized
INFO - 2017-03-01 01:07:50 --> Config Class Initialized
INFO - 2017-03-01 01:07:50 --> Loader Class Initialized
INFO - 2017-03-01 01:07:50 --> Helper loaded: form_helper
INFO - 2017-03-01 01:07:50 --> Helper loaded: url_helper
INFO - 2017-03-01 01:07:50 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:07:50 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:07:50 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:07:50 --> Template Class Initialized
INFO - 2017-03-01 01:07:50 --> Model Class Initialized
INFO - 2017-03-01 01:07:50 --> Controller Class Initialized
DEBUG - 2017-03-01 01:07:50 --> Dashboard MX_Controller Initialized
INFO - 2017-03-01 01:07:50 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:07:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-01 01:07:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-03-01 01:07:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-01 01:07:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/download_center.php
DEBUG - 2017-03-01 01:07:50 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-01 01:07:50 --> Final output sent to browser
DEBUG - 2017-03-01 01:07:50 --> Total execution time: 0.0214
INFO - 2017-03-01 01:07:53 --> Config Class Initialized
INFO - 2017-03-01 01:07:53 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:07:53 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:07:53 --> Utf8 Class Initialized
INFO - 2017-03-01 01:07:53 --> URI Class Initialized
INFO - 2017-03-01 01:07:53 --> Router Class Initialized
INFO - 2017-03-01 01:07:53 --> Output Class Initialized
INFO - 2017-03-01 01:07:53 --> Security Class Initialized
DEBUG - 2017-03-01 01:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:07:53 --> Input Class Initialized
INFO - 2017-03-01 01:07:53 --> Language Class Initialized
INFO - 2017-03-01 01:07:53 --> Language Class Initialized
INFO - 2017-03-01 01:07:53 --> Config Class Initialized
INFO - 2017-03-01 01:07:53 --> Loader Class Initialized
INFO - 2017-03-01 01:07:53 --> Helper loaded: form_helper
INFO - 2017-03-01 01:07:53 --> Helper loaded: url_helper
INFO - 2017-03-01 01:07:53 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:07:53 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:07:53 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:07:53 --> Template Class Initialized
INFO - 2017-03-01 01:07:53 --> Model Class Initialized
INFO - 2017-03-01 01:07:53 --> Controller Class Initialized
DEBUG - 2017-03-01 01:07:53 --> Dashboard MX_Controller Initialized
INFO - 2017-03-01 01:07:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:07:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-01 01:07:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-03-01 01:07:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-01 01:07:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/setting.php
DEBUG - 2017-03-01 01:07:53 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-01 01:07:53 --> Final output sent to browser
DEBUG - 2017-03-01 01:07:53 --> Total execution time: 0.0155
INFO - 2017-03-01 01:08:03 --> Config Class Initialized
INFO - 2017-03-01 01:08:03 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:08:03 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:08:03 --> Utf8 Class Initialized
INFO - 2017-03-01 01:08:03 --> URI Class Initialized
INFO - 2017-03-01 01:08:03 --> Router Class Initialized
INFO - 2017-03-01 01:08:03 --> Output Class Initialized
INFO - 2017-03-01 01:08:03 --> Security Class Initialized
DEBUG - 2017-03-01 01:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:08:03 --> Input Class Initialized
INFO - 2017-03-01 01:08:03 --> Language Class Initialized
INFO - 2017-03-01 01:08:03 --> Language Class Initialized
INFO - 2017-03-01 01:08:03 --> Config Class Initialized
INFO - 2017-03-01 01:08:03 --> Loader Class Initialized
INFO - 2017-03-01 01:08:03 --> Helper loaded: form_helper
INFO - 2017-03-01 01:08:03 --> Helper loaded: url_helper
INFO - 2017-03-01 01:08:03 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:08:03 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:08:03 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:08:03 --> Template Class Initialized
INFO - 2017-03-01 01:08:03 --> Model Class Initialized
INFO - 2017-03-01 01:08:03 --> Controller Class Initialized
DEBUG - 2017-03-01 01:08:03 --> Login MX_Controller Initialized
INFO - 2017-03-01 01:08:03 --> Helper loaded: cookie_helper
INFO - 2017-03-01 01:08:03 --> Form Validation Class Initialized
INFO - 2017-03-01 01:08:04 --> Config Class Initialized
INFO - 2017-03-01 01:08:04 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:08:04 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:08:04 --> Utf8 Class Initialized
INFO - 2017-03-01 01:08:04 --> URI Class Initialized
DEBUG - 2017-03-01 01:08:04 --> No URI present. Default controller set.
INFO - 2017-03-01 01:08:04 --> Router Class Initialized
INFO - 2017-03-01 01:08:04 --> Output Class Initialized
INFO - 2017-03-01 01:08:04 --> Security Class Initialized
DEBUG - 2017-03-01 01:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:08:04 --> Input Class Initialized
INFO - 2017-03-01 01:08:04 --> Language Class Initialized
INFO - 2017-03-01 01:08:04 --> Language Class Initialized
INFO - 2017-03-01 01:08:04 --> Config Class Initialized
INFO - 2017-03-01 01:08:04 --> Loader Class Initialized
INFO - 2017-03-01 01:08:04 --> Helper loaded: form_helper
INFO - 2017-03-01 01:08:04 --> Helper loaded: url_helper
INFO - 2017-03-01 01:08:04 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:08:04 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:08:04 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:08:04 --> Template Class Initialized
INFO - 2017-03-01 01:08:04 --> Model Class Initialized
INFO - 2017-03-01 01:08:04 --> Controller Class Initialized
DEBUG - 2017-03-01 01:08:04 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:08:04 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:08:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:08:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 01:08:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-01 01:08:04 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 01:08:04 --> Final output sent to browser
DEBUG - 2017-03-01 01:08:04 --> Total execution time: 0.0156
INFO - 2017-03-01 01:08:04 --> Config Class Initialized
INFO - 2017-03-01 01:08:04 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:08:04 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:08:04 --> Utf8 Class Initialized
INFO - 2017-03-01 01:08:04 --> URI Class Initialized
INFO - 2017-03-01 01:08:04 --> Router Class Initialized
INFO - 2017-03-01 01:08:04 --> Output Class Initialized
INFO - 2017-03-01 01:08:04 --> Security Class Initialized
DEBUG - 2017-03-01 01:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:08:04 --> Input Class Initialized
INFO - 2017-03-01 01:08:04 --> Language Class Initialized
INFO - 2017-03-01 01:08:04 --> Language Class Initialized
INFO - 2017-03-01 01:08:04 --> Config Class Initialized
INFO - 2017-03-01 01:08:04 --> Loader Class Initialized
INFO - 2017-03-01 01:08:04 --> Helper loaded: form_helper
INFO - 2017-03-01 01:08:04 --> Helper loaded: url_helper
INFO - 2017-03-01 01:08:04 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:08:04 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:08:04 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:08:04 --> Template Class Initialized
INFO - 2017-03-01 01:08:04 --> Model Class Initialized
INFO - 2017-03-01 01:08:04 --> Controller Class Initialized
DEBUG - 2017-03-01 01:08:04 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:08:04 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:08:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:08:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 01:08:05 --> Config Class Initialized
INFO - 2017-03-01 01:08:05 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:08:05 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:08:05 --> Utf8 Class Initialized
INFO - 2017-03-01 01:08:05 --> URI Class Initialized
INFO - 2017-03-01 01:08:05 --> Router Class Initialized
INFO - 2017-03-01 01:08:05 --> Output Class Initialized
INFO - 2017-03-01 01:08:05 --> Security Class Initialized
DEBUG - 2017-03-01 01:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:08:05 --> Input Class Initialized
INFO - 2017-03-01 01:08:05 --> Language Class Initialized
INFO - 2017-03-01 01:08:05 --> Language Class Initialized
INFO - 2017-03-01 01:08:05 --> Config Class Initialized
INFO - 2017-03-01 01:08:05 --> Loader Class Initialized
INFO - 2017-03-01 01:08:05 --> Helper loaded: form_helper
INFO - 2017-03-01 01:08:05 --> Helper loaded: url_helper
INFO - 2017-03-01 01:08:05 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:08:05 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:08:05 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:08:05 --> Template Class Initialized
INFO - 2017-03-01 01:08:05 --> Model Class Initialized
INFO - 2017-03-01 01:08:05 --> Controller Class Initialized
DEBUG - 2017-03-01 01:08:05 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:08:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:08:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:08:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 01:08:14 --> Config Class Initialized
INFO - 2017-03-01 01:08:14 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:08:14 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:08:14 --> Utf8 Class Initialized
INFO - 2017-03-01 01:08:14 --> URI Class Initialized
INFO - 2017-03-01 01:08:14 --> Router Class Initialized
INFO - 2017-03-01 01:08:14 --> Output Class Initialized
INFO - 2017-03-01 01:08:14 --> Security Class Initialized
DEBUG - 2017-03-01 01:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:08:14 --> Input Class Initialized
INFO - 2017-03-01 01:08:14 --> Language Class Initialized
INFO - 2017-03-01 01:08:14 --> Language Class Initialized
INFO - 2017-03-01 01:08:14 --> Config Class Initialized
INFO - 2017-03-01 01:08:14 --> Loader Class Initialized
INFO - 2017-03-01 01:08:14 --> Helper loaded: form_helper
INFO - 2017-03-01 01:08:14 --> Helper loaded: url_helper
INFO - 2017-03-01 01:08:14 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:08:14 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:08:14 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:08:14 --> Template Class Initialized
INFO - 2017-03-01 01:08:14 --> Model Class Initialized
INFO - 2017-03-01 01:08:14 --> Controller Class Initialized
DEBUG - 2017-03-01 01:08:14 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:08:14 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:08:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:08:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 01:08:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-01 01:08:14 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 01:08:14 --> Final output sent to browser
DEBUG - 2017-03-01 01:08:14 --> Total execution time: 0.0225
INFO - 2017-03-01 01:08:15 --> Config Class Initialized
INFO - 2017-03-01 01:08:15 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:08:15 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:08:15 --> Utf8 Class Initialized
INFO - 2017-03-01 01:08:15 --> URI Class Initialized
INFO - 2017-03-01 01:08:15 --> Router Class Initialized
INFO - 2017-03-01 01:08:15 --> Output Class Initialized
INFO - 2017-03-01 01:08:15 --> Security Class Initialized
DEBUG - 2017-03-01 01:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:08:15 --> Input Class Initialized
INFO - 2017-03-01 01:08:15 --> Language Class Initialized
INFO - 2017-03-01 01:08:15 --> Language Class Initialized
INFO - 2017-03-01 01:08:15 --> Config Class Initialized
INFO - 2017-03-01 01:08:15 --> Loader Class Initialized
INFO - 2017-03-01 01:08:15 --> Helper loaded: form_helper
INFO - 2017-03-01 01:08:15 --> Helper loaded: url_helper
INFO - 2017-03-01 01:08:15 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:08:15 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:08:15 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:08:15 --> Template Class Initialized
INFO - 2017-03-01 01:08:15 --> Model Class Initialized
INFO - 2017-03-01 01:08:15 --> Controller Class Initialized
DEBUG - 2017-03-01 01:08:15 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:08:15 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:08:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:08:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 01:08:24 --> Config Class Initialized
INFO - 2017-03-01 01:08:24 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:08:24 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:08:24 --> Utf8 Class Initialized
INFO - 2017-03-01 01:08:24 --> URI Class Initialized
INFO - 2017-03-01 01:08:24 --> Router Class Initialized
INFO - 2017-03-01 01:08:24 --> Output Class Initialized
INFO - 2017-03-01 01:08:24 --> Security Class Initialized
DEBUG - 2017-03-01 01:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:08:24 --> Input Class Initialized
INFO - 2017-03-01 01:08:24 --> Language Class Initialized
INFO - 2017-03-01 01:08:24 --> Language Class Initialized
INFO - 2017-03-01 01:08:24 --> Config Class Initialized
INFO - 2017-03-01 01:08:24 --> Loader Class Initialized
INFO - 2017-03-01 01:08:24 --> Helper loaded: form_helper
INFO - 2017-03-01 01:08:24 --> Helper loaded: url_helper
INFO - 2017-03-01 01:08:24 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:08:24 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:08:24 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:08:24 --> Template Class Initialized
INFO - 2017-03-01 01:08:24 --> Model Class Initialized
INFO - 2017-03-01 01:08:24 --> Controller Class Initialized
DEBUG - 2017-03-01 01:08:24 --> Login MX_Controller Initialized
INFO - 2017-03-01 01:08:24 --> Helper loaded: cookie_helper
INFO - 2017-03-01 01:08:24 --> Form Validation Class Initialized
INFO - 2017-03-01 01:08:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-01 01:08:25 --> Config Class Initialized
INFO - 2017-03-01 01:08:25 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:08:25 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:08:25 --> Utf8 Class Initialized
INFO - 2017-03-01 01:08:25 --> URI Class Initialized
INFO - 2017-03-01 01:08:25 --> Router Class Initialized
INFO - 2017-03-01 01:08:25 --> Output Class Initialized
INFO - 2017-03-01 01:08:25 --> Security Class Initialized
DEBUG - 2017-03-01 01:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:08:25 --> Input Class Initialized
INFO - 2017-03-01 01:08:25 --> Language Class Initialized
INFO - 2017-03-01 01:08:25 --> Language Class Initialized
INFO - 2017-03-01 01:08:25 --> Config Class Initialized
INFO - 2017-03-01 01:08:25 --> Loader Class Initialized
INFO - 2017-03-01 01:08:25 --> Helper loaded: form_helper
INFO - 2017-03-01 01:08:25 --> Helper loaded: url_helper
INFO - 2017-03-01 01:08:25 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:08:25 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:08:25 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:08:25 --> Template Class Initialized
INFO - 2017-03-01 01:08:25 --> Model Class Initialized
INFO - 2017-03-01 01:08:25 --> Controller Class Initialized
DEBUG - 2017-03-01 01:08:25 --> Dashboard MX_Controller Initialized
INFO - 2017-03-01 01:08:25 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:08:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-01 01:08:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-01 01:08:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-01 01:08:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-01 01:08:25 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-01 01:08:25 --> Final output sent to browser
DEBUG - 2017-03-01 01:08:25 --> Total execution time: 0.0239
INFO - 2017-03-01 01:09:12 --> Config Class Initialized
INFO - 2017-03-01 01:09:12 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:09:12 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:09:12 --> Utf8 Class Initialized
INFO - 2017-03-01 01:09:12 --> URI Class Initialized
INFO - 2017-03-01 01:09:12 --> Router Class Initialized
INFO - 2017-03-01 01:09:12 --> Output Class Initialized
INFO - 2017-03-01 01:09:12 --> Security Class Initialized
DEBUG - 2017-03-01 01:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:09:12 --> Input Class Initialized
INFO - 2017-03-01 01:09:12 --> Language Class Initialized
INFO - 2017-03-01 01:09:12 --> Language Class Initialized
INFO - 2017-03-01 01:09:12 --> Config Class Initialized
INFO - 2017-03-01 01:09:12 --> Loader Class Initialized
INFO - 2017-03-01 01:09:12 --> Helper loaded: form_helper
INFO - 2017-03-01 01:09:12 --> Helper loaded: url_helper
INFO - 2017-03-01 01:09:12 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:09:12 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:09:12 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:09:12 --> Template Class Initialized
INFO - 2017-03-01 01:09:12 --> Model Class Initialized
INFO - 2017-03-01 01:09:12 --> Controller Class Initialized
DEBUG - 2017-03-01 01:09:12 --> Login MX_Controller Initialized
INFO - 2017-03-01 01:09:12 --> Helper loaded: cookie_helper
INFO - 2017-03-01 01:09:12 --> Form Validation Class Initialized
INFO - 2017-03-01 01:09:12 --> Config Class Initialized
INFO - 2017-03-01 01:09:12 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:09:12 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:09:12 --> Utf8 Class Initialized
INFO - 2017-03-01 01:09:12 --> URI Class Initialized
DEBUG - 2017-03-01 01:09:12 --> No URI present. Default controller set.
INFO - 2017-03-01 01:09:12 --> Router Class Initialized
INFO - 2017-03-01 01:09:12 --> Output Class Initialized
INFO - 2017-03-01 01:09:12 --> Security Class Initialized
DEBUG - 2017-03-01 01:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:09:12 --> Input Class Initialized
INFO - 2017-03-01 01:09:12 --> Language Class Initialized
INFO - 2017-03-01 01:09:12 --> Language Class Initialized
INFO - 2017-03-01 01:09:12 --> Config Class Initialized
INFO - 2017-03-01 01:09:12 --> Loader Class Initialized
INFO - 2017-03-01 01:09:12 --> Helper loaded: form_helper
INFO - 2017-03-01 01:09:12 --> Helper loaded: url_helper
INFO - 2017-03-01 01:09:12 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:09:12 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:09:12 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:09:12 --> Template Class Initialized
INFO - 2017-03-01 01:09:12 --> Model Class Initialized
INFO - 2017-03-01 01:09:12 --> Controller Class Initialized
DEBUG - 2017-03-01 01:09:12 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:09:12 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:09:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:09:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 01:09:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-01 01:09:12 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 01:09:12 --> Final output sent to browser
DEBUG - 2017-03-01 01:09:12 --> Total execution time: 0.0101
INFO - 2017-03-01 01:09:13 --> Config Class Initialized
INFO - 2017-03-01 01:09:13 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:09:13 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:09:13 --> Utf8 Class Initialized
INFO - 2017-03-01 01:09:13 --> URI Class Initialized
INFO - 2017-03-01 01:09:13 --> Router Class Initialized
INFO - 2017-03-01 01:09:13 --> Output Class Initialized
INFO - 2017-03-01 01:09:13 --> Security Class Initialized
DEBUG - 2017-03-01 01:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:09:13 --> Input Class Initialized
INFO - 2017-03-01 01:09:13 --> Language Class Initialized
INFO - 2017-03-01 01:09:13 --> Language Class Initialized
INFO - 2017-03-01 01:09:13 --> Config Class Initialized
INFO - 2017-03-01 01:09:13 --> Loader Class Initialized
INFO - 2017-03-01 01:09:13 --> Helper loaded: form_helper
INFO - 2017-03-01 01:09:13 --> Helper loaded: url_helper
INFO - 2017-03-01 01:09:13 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:09:13 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:09:13 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:09:13 --> Template Class Initialized
INFO - 2017-03-01 01:09:13 --> Model Class Initialized
INFO - 2017-03-01 01:09:13 --> Controller Class Initialized
DEBUG - 2017-03-01 01:09:13 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:09:13 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:09:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:09:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 01:09:13 --> Config Class Initialized
INFO - 2017-03-01 01:09:13 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:09:13 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:09:13 --> Utf8 Class Initialized
INFO - 2017-03-01 01:09:13 --> URI Class Initialized
INFO - 2017-03-01 01:09:13 --> Router Class Initialized
INFO - 2017-03-01 01:09:13 --> Output Class Initialized
INFO - 2017-03-01 01:09:13 --> Security Class Initialized
DEBUG - 2017-03-01 01:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:09:13 --> Input Class Initialized
INFO - 2017-03-01 01:09:13 --> Language Class Initialized
INFO - 2017-03-01 01:09:13 --> Language Class Initialized
INFO - 2017-03-01 01:09:13 --> Config Class Initialized
INFO - 2017-03-01 01:09:13 --> Loader Class Initialized
INFO - 2017-03-01 01:09:13 --> Helper loaded: form_helper
INFO - 2017-03-01 01:09:13 --> Helper loaded: url_helper
INFO - 2017-03-01 01:09:13 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:09:13 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:09:13 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:09:13 --> Template Class Initialized
INFO - 2017-03-01 01:09:13 --> Model Class Initialized
INFO - 2017-03-01 01:09:13 --> Controller Class Initialized
DEBUG - 2017-03-01 01:09:13 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:09:13 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:09:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:09:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 01:09:16 --> Config Class Initialized
INFO - 2017-03-01 01:09:16 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:09:16 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:09:16 --> Utf8 Class Initialized
INFO - 2017-03-01 01:09:16 --> URI Class Initialized
INFO - 2017-03-01 01:09:16 --> Router Class Initialized
INFO - 2017-03-01 01:09:16 --> Output Class Initialized
INFO - 2017-03-01 01:09:16 --> Security Class Initialized
DEBUG - 2017-03-01 01:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:09:16 --> Input Class Initialized
INFO - 2017-03-01 01:09:16 --> Language Class Initialized
INFO - 2017-03-01 01:09:16 --> Language Class Initialized
INFO - 2017-03-01 01:09:16 --> Config Class Initialized
INFO - 2017-03-01 01:09:16 --> Loader Class Initialized
INFO - 2017-03-01 01:09:16 --> Helper loaded: form_helper
INFO - 2017-03-01 01:09:16 --> Helper loaded: url_helper
INFO - 2017-03-01 01:09:16 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:09:16 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:09:16 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:09:16 --> Template Class Initialized
INFO - 2017-03-01 01:09:16 --> Model Class Initialized
INFO - 2017-03-01 01:09:16 --> Controller Class Initialized
DEBUG - 2017-03-01 01:09:16 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:09:16 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:09:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:09:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 01:09:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-01 01:09:16 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 01:09:16 --> Final output sent to browser
DEBUG - 2017-03-01 01:09:16 --> Total execution time: 0.0151
INFO - 2017-03-01 01:09:16 --> Config Class Initialized
INFO - 2017-03-01 01:09:16 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:09:16 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:09:16 --> Utf8 Class Initialized
INFO - 2017-03-01 01:09:16 --> URI Class Initialized
INFO - 2017-03-01 01:09:16 --> Router Class Initialized
INFO - 2017-03-01 01:09:16 --> Output Class Initialized
INFO - 2017-03-01 01:09:16 --> Security Class Initialized
DEBUG - 2017-03-01 01:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:09:16 --> Input Class Initialized
INFO - 2017-03-01 01:09:16 --> Language Class Initialized
INFO - 2017-03-01 01:09:16 --> Language Class Initialized
INFO - 2017-03-01 01:09:16 --> Config Class Initialized
INFO - 2017-03-01 01:09:16 --> Loader Class Initialized
INFO - 2017-03-01 01:09:16 --> Helper loaded: form_helper
INFO - 2017-03-01 01:09:16 --> Helper loaded: url_helper
INFO - 2017-03-01 01:09:16 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:09:16 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:09:16 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:09:16 --> Template Class Initialized
INFO - 2017-03-01 01:09:16 --> Model Class Initialized
INFO - 2017-03-01 01:09:16 --> Controller Class Initialized
DEBUG - 2017-03-01 01:09:16 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:09:16 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:09:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:09:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 01:09:25 --> Config Class Initialized
INFO - 2017-03-01 01:09:25 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:09:25 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:09:25 --> Utf8 Class Initialized
INFO - 2017-03-01 01:09:25 --> URI Class Initialized
INFO - 2017-03-01 01:09:25 --> Router Class Initialized
INFO - 2017-03-01 01:09:25 --> Output Class Initialized
INFO - 2017-03-01 01:09:25 --> Security Class Initialized
DEBUG - 2017-03-01 01:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:09:25 --> Input Class Initialized
INFO - 2017-03-01 01:09:25 --> Language Class Initialized
INFO - 2017-03-01 01:09:25 --> Language Class Initialized
INFO - 2017-03-01 01:09:25 --> Config Class Initialized
INFO - 2017-03-01 01:09:25 --> Loader Class Initialized
INFO - 2017-03-01 01:09:25 --> Helper loaded: form_helper
INFO - 2017-03-01 01:09:25 --> Helper loaded: url_helper
INFO - 2017-03-01 01:09:25 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:09:25 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:09:25 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:09:25 --> Template Class Initialized
INFO - 2017-03-01 01:09:25 --> Model Class Initialized
INFO - 2017-03-01 01:09:25 --> Controller Class Initialized
DEBUG - 2017-03-01 01:09:25 --> Login MX_Controller Initialized
INFO - 2017-03-01 01:09:25 --> Helper loaded: cookie_helper
INFO - 2017-03-01 01:09:25 --> Form Validation Class Initialized
INFO - 2017-03-01 01:09:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-01 01:09:26 --> Config Class Initialized
INFO - 2017-03-01 01:09:26 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:09:26 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:09:26 --> Utf8 Class Initialized
INFO - 2017-03-01 01:09:26 --> URI Class Initialized
INFO - 2017-03-01 01:09:26 --> Router Class Initialized
INFO - 2017-03-01 01:09:26 --> Output Class Initialized
INFO - 2017-03-01 01:09:26 --> Security Class Initialized
DEBUG - 2017-03-01 01:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:09:26 --> Input Class Initialized
INFO - 2017-03-01 01:09:26 --> Language Class Initialized
INFO - 2017-03-01 01:09:26 --> Language Class Initialized
INFO - 2017-03-01 01:09:26 --> Config Class Initialized
INFO - 2017-03-01 01:09:26 --> Loader Class Initialized
INFO - 2017-03-01 01:09:26 --> Helper loaded: form_helper
INFO - 2017-03-01 01:09:26 --> Helper loaded: url_helper
INFO - 2017-03-01 01:09:26 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:09:26 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:09:26 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:09:26 --> Template Class Initialized
INFO - 2017-03-01 01:09:26 --> Model Class Initialized
INFO - 2017-03-01 01:09:26 --> Controller Class Initialized
DEBUG - 2017-03-01 01:09:26 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:09:26 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:09:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:09:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 01:09:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-01 01:09:26 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 01:09:26 --> Final output sent to browser
DEBUG - 2017-03-01 01:09:26 --> Total execution time: 0.0143
INFO - 2017-03-01 01:09:27 --> Config Class Initialized
INFO - 2017-03-01 01:09:27 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:09:27 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:09:27 --> Utf8 Class Initialized
INFO - 2017-03-01 01:09:27 --> URI Class Initialized
INFO - 2017-03-01 01:09:27 --> Router Class Initialized
INFO - 2017-03-01 01:09:27 --> Output Class Initialized
INFO - 2017-03-01 01:09:27 --> Security Class Initialized
DEBUG - 2017-03-01 01:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:09:27 --> Input Class Initialized
INFO - 2017-03-01 01:09:27 --> Language Class Initialized
INFO - 2017-03-01 01:09:27 --> Language Class Initialized
INFO - 2017-03-01 01:09:27 --> Config Class Initialized
INFO - 2017-03-01 01:09:27 --> Loader Class Initialized
INFO - 2017-03-01 01:09:27 --> Helper loaded: form_helper
INFO - 2017-03-01 01:09:27 --> Helper loaded: url_helper
INFO - 2017-03-01 01:09:27 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:09:27 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:09:27 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:09:27 --> Template Class Initialized
INFO - 2017-03-01 01:09:27 --> Model Class Initialized
INFO - 2017-03-01 01:09:27 --> Controller Class Initialized
DEBUG - 2017-03-01 01:09:27 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:09:27 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:09:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:09:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 01:42:41 --> Config Class Initialized
INFO - 2017-03-01 01:42:41 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:42:41 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:42:41 --> Utf8 Class Initialized
INFO - 2017-03-01 01:42:41 --> URI Class Initialized
INFO - 2017-03-01 01:42:41 --> Router Class Initialized
INFO - 2017-03-01 01:42:41 --> Output Class Initialized
INFO - 2017-03-01 01:42:41 --> Security Class Initialized
DEBUG - 2017-03-01 01:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:42:41 --> Input Class Initialized
INFO - 2017-03-01 01:42:41 --> Language Class Initialized
INFO - 2017-03-01 01:42:41 --> Language Class Initialized
INFO - 2017-03-01 01:42:41 --> Config Class Initialized
INFO - 2017-03-01 01:42:41 --> Loader Class Initialized
INFO - 2017-03-01 01:42:41 --> Helper loaded: form_helper
INFO - 2017-03-01 01:42:41 --> Helper loaded: url_helper
INFO - 2017-03-01 01:42:41 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:42:41 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:42:41 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:42:41 --> Template Class Initialized
INFO - 2017-03-01 01:42:41 --> Model Class Initialized
INFO - 2017-03-01 01:42:41 --> Controller Class Initialized
DEBUG - 2017-03-01 01:42:41 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:42:41 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:42:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:42:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 01:42:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-03-01 01:42:41 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 01:42:41 --> Final output sent to browser
DEBUG - 2017-03-01 01:42:41 --> Total execution time: 0.0381
INFO - 2017-03-01 01:42:41 --> Config Class Initialized
INFO - 2017-03-01 01:42:41 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:42:41 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:42:41 --> Utf8 Class Initialized
INFO - 2017-03-01 01:42:41 --> URI Class Initialized
INFO - 2017-03-01 01:42:41 --> Router Class Initialized
INFO - 2017-03-01 01:42:41 --> Output Class Initialized
INFO - 2017-03-01 01:42:41 --> Security Class Initialized
DEBUG - 2017-03-01 01:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:42:41 --> Input Class Initialized
INFO - 2017-03-01 01:42:41 --> Language Class Initialized
INFO - 2017-03-01 01:42:41 --> Language Class Initialized
INFO - 2017-03-01 01:42:41 --> Config Class Initialized
INFO - 2017-03-01 01:42:41 --> Loader Class Initialized
INFO - 2017-03-01 01:42:41 --> Helper loaded: form_helper
INFO - 2017-03-01 01:42:41 --> Helper loaded: url_helper
INFO - 2017-03-01 01:42:41 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:42:41 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:42:41 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:42:41 --> Template Class Initialized
INFO - 2017-03-01 01:42:41 --> Model Class Initialized
INFO - 2017-03-01 01:42:41 --> Controller Class Initialized
DEBUG - 2017-03-01 01:42:41 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:42:41 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:42:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:42:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 01:42:43 --> Config Class Initialized
INFO - 2017-03-01 01:42:43 --> Hooks Class Initialized
DEBUG - 2017-03-01 01:42:43 --> UTF-8 Support Enabled
INFO - 2017-03-01 01:42:43 --> Utf8 Class Initialized
INFO - 2017-03-01 01:42:43 --> URI Class Initialized
INFO - 2017-03-01 01:42:43 --> Router Class Initialized
INFO - 2017-03-01 01:42:43 --> Output Class Initialized
INFO - 2017-03-01 01:42:43 --> Security Class Initialized
DEBUG - 2017-03-01 01:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 01:42:43 --> Input Class Initialized
INFO - 2017-03-01 01:42:43 --> Language Class Initialized
INFO - 2017-03-01 01:42:43 --> Language Class Initialized
INFO - 2017-03-01 01:42:43 --> Config Class Initialized
INFO - 2017-03-01 01:42:43 --> Loader Class Initialized
INFO - 2017-03-01 01:42:43 --> Helper loaded: form_helper
INFO - 2017-03-01 01:42:43 --> Helper loaded: url_helper
INFO - 2017-03-01 01:42:43 --> Helper loaded: utility_helper
INFO - 2017-03-01 01:42:43 --> Database Driver Class Initialized
DEBUG - 2017-03-01 01:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 01:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 01:42:43 --> User Agent Class Initialized
DEBUG - 2017-03-01 01:42:43 --> Template Class Initialized
INFO - 2017-03-01 01:42:43 --> Model Class Initialized
INFO - 2017-03-01 01:42:43 --> Controller Class Initialized
DEBUG - 2017-03-01 01:42:43 --> Pages MX_Controller Initialized
INFO - 2017-03-01 01:42:43 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 01:42:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 01:42:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 11:31:50 --> Config Class Initialized
INFO - 2017-03-01 11:31:50 --> Hooks Class Initialized
DEBUG - 2017-03-01 11:31:50 --> UTF-8 Support Enabled
INFO - 2017-03-01 11:31:50 --> Utf8 Class Initialized
INFO - 2017-03-01 11:31:50 --> URI Class Initialized
DEBUG - 2017-03-01 11:31:50 --> No URI present. Default controller set.
INFO - 2017-03-01 11:31:50 --> Router Class Initialized
INFO - 2017-03-01 11:31:50 --> Output Class Initialized
INFO - 2017-03-01 11:31:50 --> Security Class Initialized
DEBUG - 2017-03-01 11:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 11:31:50 --> Input Class Initialized
INFO - 2017-03-01 11:31:50 --> Language Class Initialized
INFO - 2017-03-01 11:31:50 --> Language Class Initialized
INFO - 2017-03-01 11:31:50 --> Config Class Initialized
INFO - 2017-03-01 11:31:50 --> Loader Class Initialized
INFO - 2017-03-01 11:31:50 --> Helper loaded: form_helper
INFO - 2017-03-01 11:31:50 --> Helper loaded: url_helper
INFO - 2017-03-01 11:31:50 --> Helper loaded: utility_helper
INFO - 2017-03-01 11:31:50 --> Database Driver Class Initialized
DEBUG - 2017-03-01 11:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 11:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 11:31:50 --> User Agent Class Initialized
DEBUG - 2017-03-01 11:31:50 --> Template Class Initialized
INFO - 2017-03-01 11:31:50 --> Model Class Initialized
INFO - 2017-03-01 11:31:50 --> Controller Class Initialized
DEBUG - 2017-03-01 11:31:50 --> Pages MX_Controller Initialized
INFO - 2017-03-01 11:31:50 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 11:31:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 11:31:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 11:31:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-01 11:31:50 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 11:31:50 --> Final output sent to browser
DEBUG - 2017-03-01 11:31:50 --> Total execution time: 0.4701
INFO - 2017-03-01 11:31:52 --> Config Class Initialized
INFO - 2017-03-01 11:31:52 --> Hooks Class Initialized
DEBUG - 2017-03-01 11:31:52 --> UTF-8 Support Enabled
INFO - 2017-03-01 11:31:52 --> Utf8 Class Initialized
INFO - 2017-03-01 11:31:52 --> URI Class Initialized
DEBUG - 2017-03-01 11:31:52 --> No URI present. Default controller set.
INFO - 2017-03-01 11:31:52 --> Router Class Initialized
INFO - 2017-03-01 11:31:52 --> Output Class Initialized
INFO - 2017-03-01 11:31:52 --> Security Class Initialized
DEBUG - 2017-03-01 11:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 11:31:52 --> Input Class Initialized
INFO - 2017-03-01 11:31:52 --> Language Class Initialized
INFO - 2017-03-01 11:31:52 --> Language Class Initialized
INFO - 2017-03-01 11:31:52 --> Config Class Initialized
INFO - 2017-03-01 11:31:52 --> Loader Class Initialized
INFO - 2017-03-01 11:31:52 --> Helper loaded: form_helper
INFO - 2017-03-01 11:31:52 --> Helper loaded: url_helper
INFO - 2017-03-01 11:31:52 --> Helper loaded: utility_helper
INFO - 2017-03-01 11:31:52 --> Database Driver Class Initialized
DEBUG - 2017-03-01 11:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 11:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 11:31:52 --> User Agent Class Initialized
DEBUG - 2017-03-01 11:31:52 --> Template Class Initialized
INFO - 2017-03-01 11:31:52 --> Model Class Initialized
INFO - 2017-03-01 11:31:52 --> Controller Class Initialized
DEBUG - 2017-03-01 11:31:52 --> Pages MX_Controller Initialized
INFO - 2017-03-01 11:31:52 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 11:31:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 11:31:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 11:31:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-01 11:31:52 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 11:31:52 --> Final output sent to browser
DEBUG - 2017-03-01 11:31:52 --> Total execution time: 0.0157
INFO - 2017-03-01 11:32:27 --> Config Class Initialized
INFO - 2017-03-01 11:32:27 --> Hooks Class Initialized
DEBUG - 2017-03-01 11:32:27 --> UTF-8 Support Enabled
INFO - 2017-03-01 11:32:27 --> Utf8 Class Initialized
INFO - 2017-03-01 11:32:27 --> URI Class Initialized
INFO - 2017-03-01 11:32:27 --> Router Class Initialized
INFO - 2017-03-01 11:32:27 --> Output Class Initialized
INFO - 2017-03-01 11:32:27 --> Security Class Initialized
DEBUG - 2017-03-01 11:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 11:32:27 --> Input Class Initialized
INFO - 2017-03-01 11:32:27 --> Language Class Initialized
INFO - 2017-03-01 11:32:27 --> Language Class Initialized
INFO - 2017-03-01 11:32:27 --> Config Class Initialized
INFO - 2017-03-01 11:32:27 --> Loader Class Initialized
INFO - 2017-03-01 11:32:27 --> Helper loaded: form_helper
INFO - 2017-03-01 11:32:27 --> Helper loaded: url_helper
INFO - 2017-03-01 11:32:27 --> Helper loaded: utility_helper
INFO - 2017-03-01 11:32:27 --> Database Driver Class Initialized
DEBUG - 2017-03-01 11:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 11:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 11:32:27 --> User Agent Class Initialized
DEBUG - 2017-03-01 11:32:27 --> Template Class Initialized
INFO - 2017-03-01 11:32:27 --> Model Class Initialized
INFO - 2017-03-01 11:32:27 --> Controller Class Initialized
DEBUG - 2017-03-01 11:32:27 --> Pages MX_Controller Initialized
INFO - 2017-03-01 11:32:27 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 11:32:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 11:32:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 11:36:23 --> Config Class Initialized
INFO - 2017-03-01 11:36:23 --> Hooks Class Initialized
DEBUG - 2017-03-01 11:36:23 --> UTF-8 Support Enabled
INFO - 2017-03-01 11:36:23 --> Utf8 Class Initialized
INFO - 2017-03-01 11:36:23 --> URI Class Initialized
DEBUG - 2017-03-01 11:36:23 --> No URI present. Default controller set.
INFO - 2017-03-01 11:36:23 --> Router Class Initialized
INFO - 2017-03-01 11:36:23 --> Output Class Initialized
INFO - 2017-03-01 11:36:23 --> Security Class Initialized
DEBUG - 2017-03-01 11:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 11:36:23 --> Input Class Initialized
INFO - 2017-03-01 11:36:23 --> Language Class Initialized
INFO - 2017-03-01 11:36:23 --> Language Class Initialized
INFO - 2017-03-01 11:36:23 --> Config Class Initialized
INFO - 2017-03-01 11:36:23 --> Loader Class Initialized
INFO - 2017-03-01 11:36:23 --> Helper loaded: form_helper
INFO - 2017-03-01 11:36:23 --> Helper loaded: url_helper
INFO - 2017-03-01 11:36:23 --> Helper loaded: utility_helper
INFO - 2017-03-01 11:36:23 --> Database Driver Class Initialized
DEBUG - 2017-03-01 11:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 11:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 11:36:23 --> User Agent Class Initialized
DEBUG - 2017-03-01 11:36:23 --> Template Class Initialized
INFO - 2017-03-01 11:36:23 --> Model Class Initialized
INFO - 2017-03-01 11:36:23 --> Controller Class Initialized
DEBUG - 2017-03-01 11:36:23 --> Pages MX_Controller Initialized
INFO - 2017-03-01 11:36:23 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 11:36:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 11:36:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-01 11:36:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-01 11:36:23 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-01 11:36:23 --> Final output sent to browser
DEBUG - 2017-03-01 11:36:23 --> Total execution time: 0.5929
INFO - 2017-03-01 11:39:05 --> Config Class Initialized
INFO - 2017-03-01 11:39:05 --> Hooks Class Initialized
DEBUG - 2017-03-01 11:39:05 --> UTF-8 Support Enabled
INFO - 2017-03-01 11:39:05 --> Utf8 Class Initialized
INFO - 2017-03-01 11:39:05 --> URI Class Initialized
INFO - 2017-03-01 11:39:05 --> Router Class Initialized
INFO - 2017-03-01 11:39:05 --> Output Class Initialized
INFO - 2017-03-01 11:39:05 --> Security Class Initialized
DEBUG - 2017-03-01 11:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 11:39:05 --> Input Class Initialized
INFO - 2017-03-01 11:39:05 --> Language Class Initialized
INFO - 2017-03-01 11:39:05 --> Language Class Initialized
INFO - 2017-03-01 11:39:05 --> Config Class Initialized
INFO - 2017-03-01 11:39:05 --> Loader Class Initialized
INFO - 2017-03-01 11:39:05 --> Helper loaded: form_helper
INFO - 2017-03-01 11:39:05 --> Helper loaded: url_helper
INFO - 2017-03-01 11:39:05 --> Helper loaded: utility_helper
INFO - 2017-03-01 11:39:05 --> Database Driver Class Initialized
DEBUG - 2017-03-01 11:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 11:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 11:39:05 --> User Agent Class Initialized
DEBUG - 2017-03-01 11:39:05 --> Template Class Initialized
INFO - 2017-03-01 11:39:05 --> Model Class Initialized
INFO - 2017-03-01 11:39:05 --> Controller Class Initialized
DEBUG - 2017-03-01 11:39:05 --> Pages MX_Controller Initialized
INFO - 2017-03-01 11:39:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 11:39:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 11:39:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 11:42:48 --> Config Class Initialized
INFO - 2017-03-01 11:42:48 --> Hooks Class Initialized
DEBUG - 2017-03-01 11:42:48 --> UTF-8 Support Enabled
INFO - 2017-03-01 11:42:48 --> Utf8 Class Initialized
INFO - 2017-03-01 11:42:48 --> URI Class Initialized
INFO - 2017-03-01 11:42:48 --> Router Class Initialized
INFO - 2017-03-01 11:42:48 --> Output Class Initialized
INFO - 2017-03-01 11:42:48 --> Security Class Initialized
DEBUG - 2017-03-01 11:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 11:42:48 --> Input Class Initialized
INFO - 2017-03-01 11:42:48 --> Language Class Initialized
INFO - 2017-03-01 11:42:48 --> Language Class Initialized
INFO - 2017-03-01 11:42:48 --> Config Class Initialized
INFO - 2017-03-01 11:42:48 --> Loader Class Initialized
INFO - 2017-03-01 11:42:48 --> Helper loaded: form_helper
INFO - 2017-03-01 11:42:48 --> Helper loaded: url_helper
INFO - 2017-03-01 11:42:48 --> Helper loaded: utility_helper
INFO - 2017-03-01 11:42:48 --> Database Driver Class Initialized
DEBUG - 2017-03-01 11:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 11:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 11:42:48 --> User Agent Class Initialized
DEBUG - 2017-03-01 11:42:48 --> Template Class Initialized
INFO - 2017-03-01 11:42:48 --> Model Class Initialized
INFO - 2017-03-01 11:42:48 --> Controller Class Initialized
DEBUG - 2017-03-01 11:42:48 --> Pages MX_Controller Initialized
INFO - 2017-03-01 11:42:48 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 11:42:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 11:42:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 11:44:57 --> Config Class Initialized
INFO - 2017-03-01 11:44:57 --> Hooks Class Initialized
DEBUG - 2017-03-01 11:44:57 --> UTF-8 Support Enabled
INFO - 2017-03-01 11:44:57 --> Utf8 Class Initialized
INFO - 2017-03-01 11:44:57 --> URI Class Initialized
INFO - 2017-03-01 11:44:57 --> Router Class Initialized
INFO - 2017-03-01 11:44:57 --> Output Class Initialized
INFO - 2017-03-01 11:44:57 --> Security Class Initialized
DEBUG - 2017-03-01 11:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 11:44:57 --> Input Class Initialized
INFO - 2017-03-01 11:44:57 --> Language Class Initialized
INFO - 2017-03-01 11:44:57 --> Language Class Initialized
INFO - 2017-03-01 11:44:57 --> Config Class Initialized
INFO - 2017-03-01 11:44:57 --> Loader Class Initialized
INFO - 2017-03-01 11:44:57 --> Helper loaded: form_helper
INFO - 2017-03-01 11:44:57 --> Helper loaded: url_helper
INFO - 2017-03-01 11:44:57 --> Helper loaded: utility_helper
INFO - 2017-03-01 11:44:57 --> Database Driver Class Initialized
DEBUG - 2017-03-01 11:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 11:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 11:44:57 --> User Agent Class Initialized
DEBUG - 2017-03-01 11:44:57 --> Template Class Initialized
INFO - 2017-03-01 11:44:57 --> Model Class Initialized
INFO - 2017-03-01 11:44:57 --> Controller Class Initialized
DEBUG - 2017-03-01 11:44:57 --> Pages MX_Controller Initialized
INFO - 2017-03-01 11:44:57 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 11:44:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 11:44:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 11:46:38 --> Config Class Initialized
INFO - 2017-03-01 11:46:38 --> Hooks Class Initialized
DEBUG - 2017-03-01 11:46:38 --> UTF-8 Support Enabled
INFO - 2017-03-01 11:46:38 --> Utf8 Class Initialized
INFO - 2017-03-01 11:46:38 --> URI Class Initialized
INFO - 2017-03-01 11:46:38 --> Router Class Initialized
INFO - 2017-03-01 11:46:38 --> Output Class Initialized
INFO - 2017-03-01 11:46:38 --> Security Class Initialized
DEBUG - 2017-03-01 11:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 11:46:39 --> Input Class Initialized
INFO - 2017-03-01 11:46:39 --> Language Class Initialized
INFO - 2017-03-01 11:46:39 --> Language Class Initialized
INFO - 2017-03-01 11:46:39 --> Config Class Initialized
INFO - 2017-03-01 11:46:40 --> Loader Class Initialized
INFO - 2017-03-01 11:46:40 --> Helper loaded: form_helper
INFO - 2017-03-01 11:46:40 --> Helper loaded: url_helper
INFO - 2017-03-01 11:46:40 --> Helper loaded: utility_helper
INFO - 2017-03-01 11:46:40 --> Database Driver Class Initialized
DEBUG - 2017-03-01 11:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 11:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 11:46:40 --> User Agent Class Initialized
DEBUG - 2017-03-01 11:46:40 --> Template Class Initialized
INFO - 2017-03-01 11:46:40 --> Model Class Initialized
INFO - 2017-03-01 11:46:40 --> Controller Class Initialized
DEBUG - 2017-03-01 11:46:40 --> Pages MX_Controller Initialized
INFO - 2017-03-01 11:46:40 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 11:46:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 11:46:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 11:50:01 --> Config Class Initialized
INFO - 2017-03-01 11:50:01 --> Hooks Class Initialized
DEBUG - 2017-03-01 11:50:01 --> UTF-8 Support Enabled
INFO - 2017-03-01 11:50:01 --> Utf8 Class Initialized
INFO - 2017-03-01 11:50:01 --> URI Class Initialized
INFO - 2017-03-01 11:50:01 --> Router Class Initialized
INFO - 2017-03-01 11:50:01 --> Output Class Initialized
INFO - 2017-03-01 11:50:01 --> Security Class Initialized
DEBUG - 2017-03-01 11:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 11:50:01 --> Input Class Initialized
INFO - 2017-03-01 11:50:01 --> Language Class Initialized
INFO - 2017-03-01 11:50:01 --> Language Class Initialized
INFO - 2017-03-01 11:50:01 --> Config Class Initialized
INFO - 2017-03-01 11:50:01 --> Loader Class Initialized
INFO - 2017-03-01 11:50:01 --> Helper loaded: form_helper
INFO - 2017-03-01 11:50:01 --> Helper loaded: url_helper
INFO - 2017-03-01 11:50:01 --> Helper loaded: utility_helper
INFO - 2017-03-01 11:50:01 --> Database Driver Class Initialized
DEBUG - 2017-03-01 11:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 11:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 11:50:02 --> User Agent Class Initialized
DEBUG - 2017-03-01 11:50:02 --> Template Class Initialized
INFO - 2017-03-01 11:50:02 --> Model Class Initialized
INFO - 2017-03-01 11:50:02 --> Controller Class Initialized
DEBUG - 2017-03-01 11:50:02 --> Pages MX_Controller Initialized
INFO - 2017-03-01 11:50:02 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 11:50:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 11:50:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 17:45:06 --> Config Class Initialized
INFO - 2017-03-01 17:45:06 --> Hooks Class Initialized
DEBUG - 2017-03-01 17:45:06 --> UTF-8 Support Enabled
INFO - 2017-03-01 17:45:06 --> Utf8 Class Initialized
INFO - 2017-03-01 17:45:06 --> URI Class Initialized
INFO - 2017-03-01 17:45:06 --> Router Class Initialized
INFO - 2017-03-01 17:45:06 --> Output Class Initialized
INFO - 2017-03-01 17:45:06 --> Security Class Initialized
DEBUG - 2017-03-01 17:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 17:45:06 --> Input Class Initialized
INFO - 2017-03-01 17:45:06 --> Language Class Initialized
INFO - 2017-03-01 17:45:06 --> Language Class Initialized
INFO - 2017-03-01 17:45:06 --> Config Class Initialized
INFO - 2017-03-01 17:45:06 --> Loader Class Initialized
INFO - 2017-03-01 17:45:06 --> Helper loaded: form_helper
INFO - 2017-03-01 17:45:06 --> Helper loaded: url_helper
INFO - 2017-03-01 17:45:06 --> Helper loaded: utility_helper
INFO - 2017-03-01 17:45:06 --> Database Driver Class Initialized
DEBUG - 2017-03-01 17:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 17:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 17:45:06 --> User Agent Class Initialized
DEBUG - 2017-03-01 17:45:06 --> Template Class Initialized
INFO - 2017-03-01 17:45:06 --> Model Class Initialized
INFO - 2017-03-01 17:45:06 --> Controller Class Initialized
DEBUG - 2017-03-01 17:45:06 --> Pages MX_Controller Initialized
INFO - 2017-03-01 17:45:06 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 17:45:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 17:45:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 17:48:48 --> Config Class Initialized
INFO - 2017-03-01 17:48:48 --> Hooks Class Initialized
DEBUG - 2017-03-01 17:48:48 --> UTF-8 Support Enabled
INFO - 2017-03-01 17:48:48 --> Utf8 Class Initialized
INFO - 2017-03-01 17:48:48 --> URI Class Initialized
INFO - 2017-03-01 17:48:48 --> Router Class Initialized
INFO - 2017-03-01 17:48:48 --> Output Class Initialized
INFO - 2017-03-01 17:48:48 --> Security Class Initialized
DEBUG - 2017-03-01 17:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 17:48:48 --> Input Class Initialized
INFO - 2017-03-01 17:48:48 --> Language Class Initialized
INFO - 2017-03-01 17:48:48 --> Language Class Initialized
INFO - 2017-03-01 17:48:48 --> Config Class Initialized
INFO - 2017-03-01 17:48:48 --> Loader Class Initialized
INFO - 2017-03-01 17:48:48 --> Helper loaded: form_helper
INFO - 2017-03-01 17:48:48 --> Helper loaded: url_helper
INFO - 2017-03-01 17:48:48 --> Helper loaded: utility_helper
INFO - 2017-03-01 17:48:48 --> Database Driver Class Initialized
DEBUG - 2017-03-01 17:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 17:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 17:48:48 --> User Agent Class Initialized
DEBUG - 2017-03-01 17:48:48 --> Template Class Initialized
INFO - 2017-03-01 17:48:48 --> Model Class Initialized
INFO - 2017-03-01 17:48:48 --> Controller Class Initialized
DEBUG - 2017-03-01 17:48:48 --> Pages MX_Controller Initialized
INFO - 2017-03-01 17:48:48 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 17:48:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 17:48:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 17:50:08 --> Config Class Initialized
INFO - 2017-03-01 17:50:08 --> Hooks Class Initialized
DEBUG - 2017-03-01 17:50:08 --> UTF-8 Support Enabled
INFO - 2017-03-01 17:50:08 --> Utf8 Class Initialized
INFO - 2017-03-01 17:50:08 --> URI Class Initialized
INFO - 2017-03-01 17:50:08 --> Router Class Initialized
INFO - 2017-03-01 17:50:08 --> Output Class Initialized
INFO - 2017-03-01 17:50:08 --> Security Class Initialized
DEBUG - 2017-03-01 17:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 17:50:08 --> Input Class Initialized
INFO - 2017-03-01 17:50:08 --> Language Class Initialized
INFO - 2017-03-01 17:50:08 --> Language Class Initialized
INFO - 2017-03-01 17:50:08 --> Config Class Initialized
INFO - 2017-03-01 17:50:08 --> Loader Class Initialized
INFO - 2017-03-01 17:50:08 --> Helper loaded: form_helper
INFO - 2017-03-01 17:50:08 --> Helper loaded: url_helper
INFO - 2017-03-01 17:50:08 --> Helper loaded: utility_helper
INFO - 2017-03-01 17:50:08 --> Database Driver Class Initialized
DEBUG - 2017-03-01 17:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 17:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 17:50:08 --> User Agent Class Initialized
DEBUG - 2017-03-01 17:50:08 --> Template Class Initialized
INFO - 2017-03-01 17:50:08 --> Model Class Initialized
INFO - 2017-03-01 17:50:08 --> Controller Class Initialized
DEBUG - 2017-03-01 17:50:08 --> Pages MX_Controller Initialized
INFO - 2017-03-01 17:50:08 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 17:50:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 17:50:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 17:51:13 --> Config Class Initialized
INFO - 2017-03-01 17:51:13 --> Hooks Class Initialized
DEBUG - 2017-03-01 17:51:13 --> UTF-8 Support Enabled
INFO - 2017-03-01 17:51:13 --> Utf8 Class Initialized
INFO - 2017-03-01 17:51:13 --> URI Class Initialized
INFO - 2017-03-01 17:51:13 --> Router Class Initialized
INFO - 2017-03-01 17:51:13 --> Output Class Initialized
INFO - 2017-03-01 17:51:13 --> Security Class Initialized
DEBUG - 2017-03-01 17:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 17:51:13 --> Input Class Initialized
INFO - 2017-03-01 17:51:13 --> Language Class Initialized
INFO - 2017-03-01 17:51:13 --> Language Class Initialized
INFO - 2017-03-01 17:51:13 --> Config Class Initialized
INFO - 2017-03-01 17:51:13 --> Loader Class Initialized
INFO - 2017-03-01 17:51:13 --> Helper loaded: form_helper
INFO - 2017-03-01 17:51:13 --> Helper loaded: url_helper
INFO - 2017-03-01 17:51:13 --> Helper loaded: utility_helper
INFO - 2017-03-01 17:51:13 --> Database Driver Class Initialized
DEBUG - 2017-03-01 17:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 17:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 17:51:13 --> User Agent Class Initialized
DEBUG - 2017-03-01 17:51:13 --> Template Class Initialized
INFO - 2017-03-01 17:51:13 --> Model Class Initialized
INFO - 2017-03-01 17:51:13 --> Controller Class Initialized
DEBUG - 2017-03-01 17:51:13 --> Pages MX_Controller Initialized
INFO - 2017-03-01 17:51:13 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 17:51:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 17:51:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-01 17:52:00 --> Config Class Initialized
INFO - 2017-03-01 17:52:00 --> Hooks Class Initialized
DEBUG - 2017-03-01 17:52:00 --> UTF-8 Support Enabled
INFO - 2017-03-01 17:52:00 --> Utf8 Class Initialized
INFO - 2017-03-01 17:52:00 --> URI Class Initialized
INFO - 2017-03-01 17:52:00 --> Router Class Initialized
INFO - 2017-03-01 17:52:00 --> Output Class Initialized
INFO - 2017-03-01 17:52:00 --> Security Class Initialized
DEBUG - 2017-03-01 17:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 17:52:00 --> Input Class Initialized
INFO - 2017-03-01 17:52:00 --> Language Class Initialized
INFO - 2017-03-01 17:52:00 --> Language Class Initialized
INFO - 2017-03-01 17:52:00 --> Config Class Initialized
INFO - 2017-03-01 17:52:00 --> Loader Class Initialized
INFO - 2017-03-01 17:52:00 --> Helper loaded: form_helper
INFO - 2017-03-01 17:52:00 --> Helper loaded: url_helper
INFO - 2017-03-01 17:52:00 --> Helper loaded: utility_helper
INFO - 2017-03-01 17:52:00 --> Database Driver Class Initialized
DEBUG - 2017-03-01 17:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-01 17:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 17:52:00 --> User Agent Class Initialized
DEBUG - 2017-03-01 17:52:00 --> Template Class Initialized
INFO - 2017-03-01 17:52:00 --> Model Class Initialized
INFO - 2017-03-01 17:52:00 --> Controller Class Initialized
DEBUG - 2017-03-01 17:52:00 --> Pages MX_Controller Initialized
INFO - 2017-03-01 17:52:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-01 17:52:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-01 17:52:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
