<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-27 05:07:21 --> Config Class Initialized
INFO - 2017-02-27 05:07:21 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:07:21 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:07:21 --> Utf8 Class Initialized
INFO - 2017-02-27 05:07:21 --> URI Class Initialized
INFO - 2017-02-27 05:07:21 --> Router Class Initialized
INFO - 2017-02-27 05:07:21 --> Output Class Initialized
INFO - 2017-02-27 05:07:21 --> Security Class Initialized
DEBUG - 2017-02-27 05:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:07:21 --> Input Class Initialized
INFO - 2017-02-27 05:07:21 --> Language Class Initialized
INFO - 2017-02-27 05:07:21 --> Language Class Initialized
INFO - 2017-02-27 05:07:21 --> Config Class Initialized
INFO - 2017-02-27 05:07:21 --> Loader Class Initialized
INFO - 2017-02-27 05:07:21 --> Helper loaded: form_helper
INFO - 2017-02-27 05:07:21 --> Helper loaded: url_helper
INFO - 2017-02-27 05:07:21 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:07:21 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:07:21 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:07:21 --> Template Class Initialized
INFO - 2017-02-27 05:07:21 --> Model Class Initialized
INFO - 2017-02-27 05:07:21 --> Controller Class Initialized
DEBUG - 2017-02-27 05:07:21 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:07:21 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:07:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:07:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 05:07:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-02-27 05:07:21 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 05:07:21 --> Final output sent to browser
DEBUG - 2017-02-27 05:07:21 --> Total execution time: 0.3675
INFO - 2017-02-27 05:07:23 --> Config Class Initialized
INFO - 2017-02-27 05:07:23 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:07:23 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:07:23 --> Utf8 Class Initialized
INFO - 2017-02-27 05:07:23 --> URI Class Initialized
INFO - 2017-02-27 05:07:23 --> Router Class Initialized
INFO - 2017-02-27 05:07:23 --> Output Class Initialized
INFO - 2017-02-27 05:07:23 --> Security Class Initialized
DEBUG - 2017-02-27 05:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:07:23 --> Input Class Initialized
INFO - 2017-02-27 05:07:23 --> Language Class Initialized
INFO - 2017-02-27 05:07:23 --> Language Class Initialized
INFO - 2017-02-27 05:07:23 --> Config Class Initialized
INFO - 2017-02-27 05:07:23 --> Loader Class Initialized
INFO - 2017-02-27 05:07:23 --> Helper loaded: form_helper
INFO - 2017-02-27 05:07:23 --> Helper loaded: url_helper
INFO - 2017-02-27 05:07:23 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:07:23 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:07:23 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:07:23 --> Template Class Initialized
INFO - 2017-02-27 05:07:23 --> Model Class Initialized
INFO - 2017-02-27 05:07:23 --> Controller Class Initialized
DEBUG - 2017-02-27 05:07:23 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:07:23 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:07:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:07:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:07:29 --> Config Class Initialized
INFO - 2017-02-27 05:07:29 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:07:29 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:07:29 --> Utf8 Class Initialized
INFO - 2017-02-27 05:07:29 --> URI Class Initialized
DEBUG - 2017-02-27 05:07:29 --> No URI present. Default controller set.
INFO - 2017-02-27 05:07:29 --> Router Class Initialized
INFO - 2017-02-27 05:07:29 --> Output Class Initialized
INFO - 2017-02-27 05:07:29 --> Security Class Initialized
DEBUG - 2017-02-27 05:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:07:29 --> Input Class Initialized
INFO - 2017-02-27 05:07:29 --> Language Class Initialized
INFO - 2017-02-27 05:07:29 --> Language Class Initialized
INFO - 2017-02-27 05:07:29 --> Config Class Initialized
INFO - 2017-02-27 05:07:29 --> Loader Class Initialized
INFO - 2017-02-27 05:07:29 --> Helper loaded: form_helper
INFO - 2017-02-27 05:07:29 --> Helper loaded: url_helper
INFO - 2017-02-27 05:07:29 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:07:29 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:07:29 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:07:29 --> Template Class Initialized
INFO - 2017-02-27 05:07:29 --> Model Class Initialized
INFO - 2017-02-27 05:07:29 --> Controller Class Initialized
DEBUG - 2017-02-27 05:07:29 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:07:29 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:07:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:07:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 05:07:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-27 05:07:29 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 05:07:29 --> Final output sent to browser
DEBUG - 2017-02-27 05:07:29 --> Total execution time: 0.0195
INFO - 2017-02-27 05:07:29 --> Config Class Initialized
INFO - 2017-02-27 05:07:29 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:07:29 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:07:29 --> Utf8 Class Initialized
INFO - 2017-02-27 05:07:29 --> URI Class Initialized
INFO - 2017-02-27 05:07:29 --> Router Class Initialized
INFO - 2017-02-27 05:07:29 --> Output Class Initialized
INFO - 2017-02-27 05:07:29 --> Security Class Initialized
DEBUG - 2017-02-27 05:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:07:29 --> Input Class Initialized
INFO - 2017-02-27 05:07:29 --> Language Class Initialized
INFO - 2017-02-27 05:07:29 --> Language Class Initialized
INFO - 2017-02-27 05:07:29 --> Config Class Initialized
INFO - 2017-02-27 05:07:29 --> Loader Class Initialized
INFO - 2017-02-27 05:07:29 --> Helper loaded: form_helper
INFO - 2017-02-27 05:07:29 --> Helper loaded: url_helper
INFO - 2017-02-27 05:07:29 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:07:29 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:07:29 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:07:29 --> Template Class Initialized
INFO - 2017-02-27 05:07:29 --> Model Class Initialized
INFO - 2017-02-27 05:07:29 --> Controller Class Initialized
DEBUG - 2017-02-27 05:07:29 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:07:29 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:07:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:07:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:07:29 --> Config Class Initialized
INFO - 2017-02-27 05:07:29 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:07:29 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:07:29 --> Utf8 Class Initialized
INFO - 2017-02-27 05:07:29 --> URI Class Initialized
INFO - 2017-02-27 05:07:29 --> Router Class Initialized
INFO - 2017-02-27 05:07:29 --> Output Class Initialized
INFO - 2017-02-27 05:07:29 --> Security Class Initialized
DEBUG - 2017-02-27 05:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:07:29 --> Input Class Initialized
INFO - 2017-02-27 05:07:29 --> Language Class Initialized
INFO - 2017-02-27 05:07:29 --> Language Class Initialized
INFO - 2017-02-27 05:07:29 --> Config Class Initialized
INFO - 2017-02-27 05:07:29 --> Loader Class Initialized
INFO - 2017-02-27 05:07:29 --> Helper loaded: form_helper
INFO - 2017-02-27 05:07:29 --> Helper loaded: url_helper
INFO - 2017-02-27 05:07:29 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:07:29 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:07:29 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:07:29 --> Template Class Initialized
INFO - 2017-02-27 05:07:29 --> Model Class Initialized
INFO - 2017-02-27 05:07:29 --> Controller Class Initialized
DEBUG - 2017-02-27 05:07:29 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:07:29 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:07:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:07:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:07:59 --> Config Class Initialized
INFO - 2017-02-27 05:07:59 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:07:59 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:07:59 --> Utf8 Class Initialized
INFO - 2017-02-27 05:07:59 --> URI Class Initialized
INFO - 2017-02-27 05:07:59 --> Router Class Initialized
INFO - 2017-02-27 05:07:59 --> Output Class Initialized
INFO - 2017-02-27 05:07:59 --> Security Class Initialized
DEBUG - 2017-02-27 05:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:07:59 --> Input Class Initialized
INFO - 2017-02-27 05:07:59 --> Language Class Initialized
INFO - 2017-02-27 05:07:59 --> Language Class Initialized
INFO - 2017-02-27 05:07:59 --> Config Class Initialized
INFO - 2017-02-27 05:07:59 --> Loader Class Initialized
INFO - 2017-02-27 05:07:59 --> Helper loaded: form_helper
INFO - 2017-02-27 05:07:59 --> Helper loaded: url_helper
INFO - 2017-02-27 05:07:59 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:07:59 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:07:59 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:07:59 --> Template Class Initialized
INFO - 2017-02-27 05:07:59 --> Model Class Initialized
INFO - 2017-02-27 05:07:59 --> Controller Class Initialized
DEBUG - 2017-02-27 05:07:59 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:07:59 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:07:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:07:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 05:07:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-02-27 05:07:59 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 05:07:59 --> Final output sent to browser
DEBUG - 2017-02-27 05:07:59 --> Total execution time: 0.0144
INFO - 2017-02-27 05:07:59 --> Config Class Initialized
INFO - 2017-02-27 05:07:59 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:07:59 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:07:59 --> Utf8 Class Initialized
INFO - 2017-02-27 05:08:00 --> URI Class Initialized
INFO - 2017-02-27 05:08:00 --> Router Class Initialized
INFO - 2017-02-27 05:08:00 --> Output Class Initialized
INFO - 2017-02-27 05:08:00 --> Security Class Initialized
DEBUG - 2017-02-27 05:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:08:00 --> Input Class Initialized
INFO - 2017-02-27 05:08:00 --> Language Class Initialized
INFO - 2017-02-27 05:08:00 --> Language Class Initialized
INFO - 2017-02-27 05:08:00 --> Config Class Initialized
INFO - 2017-02-27 05:08:00 --> Loader Class Initialized
INFO - 2017-02-27 05:08:00 --> Helper loaded: form_helper
INFO - 2017-02-27 05:08:00 --> Helper loaded: url_helper
INFO - 2017-02-27 05:08:00 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:08:00 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:08:00 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:08:00 --> Template Class Initialized
INFO - 2017-02-27 05:08:00 --> Model Class Initialized
INFO - 2017-02-27 05:08:00 --> Controller Class Initialized
DEBUG - 2017-02-27 05:08:00 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:08:00 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:08:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:08:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:13:56 --> Config Class Initialized
INFO - 2017-02-27 05:13:56 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:13:56 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:13:56 --> Utf8 Class Initialized
INFO - 2017-02-27 05:13:56 --> URI Class Initialized
DEBUG - 2017-02-27 05:13:56 --> No URI present. Default controller set.
INFO - 2017-02-27 05:13:56 --> Router Class Initialized
INFO - 2017-02-27 05:13:56 --> Output Class Initialized
INFO - 2017-02-27 05:13:56 --> Security Class Initialized
DEBUG - 2017-02-27 05:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:13:56 --> Input Class Initialized
INFO - 2017-02-27 05:13:56 --> Language Class Initialized
INFO - 2017-02-27 05:13:56 --> Language Class Initialized
INFO - 2017-02-27 05:13:56 --> Config Class Initialized
INFO - 2017-02-27 05:13:56 --> Loader Class Initialized
INFO - 2017-02-27 05:13:56 --> Helper loaded: form_helper
INFO - 2017-02-27 05:13:56 --> Helper loaded: url_helper
INFO - 2017-02-27 05:13:56 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:13:56 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:13:56 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:13:56 --> Template Class Initialized
INFO - 2017-02-27 05:13:56 --> Model Class Initialized
INFO - 2017-02-27 05:13:56 --> Controller Class Initialized
DEBUG - 2017-02-27 05:13:56 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:13:56 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:13:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:13:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 05:13:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-27 05:13:56 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 05:13:56 --> Final output sent to browser
DEBUG - 2017-02-27 05:13:56 --> Total execution time: 0.0626
INFO - 2017-02-27 05:14:00 --> Config Class Initialized
INFO - 2017-02-27 05:14:00 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:14:00 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:14:00 --> Utf8 Class Initialized
INFO - 2017-02-27 05:14:00 --> URI Class Initialized
INFO - 2017-02-27 05:14:00 --> Router Class Initialized
INFO - 2017-02-27 05:14:00 --> Output Class Initialized
INFO - 2017-02-27 05:14:00 --> Security Class Initialized
DEBUG - 2017-02-27 05:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:14:00 --> Input Class Initialized
INFO - 2017-02-27 05:14:00 --> Language Class Initialized
INFO - 2017-02-27 05:14:00 --> Language Class Initialized
INFO - 2017-02-27 05:14:00 --> Config Class Initialized
INFO - 2017-02-27 05:14:00 --> Loader Class Initialized
INFO - 2017-02-27 05:14:00 --> Helper loaded: form_helper
INFO - 2017-02-27 05:14:00 --> Helper loaded: url_helper
INFO - 2017-02-27 05:14:00 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:14:00 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:14:00 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:14:00 --> Template Class Initialized
INFO - 2017-02-27 05:14:00 --> Model Class Initialized
INFO - 2017-02-27 05:14:00 --> Controller Class Initialized
DEBUG - 2017-02-27 05:14:00 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:14:00 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:14:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:14:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:14:29 --> Config Class Initialized
INFO - 2017-02-27 05:14:29 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:14:29 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:14:29 --> Utf8 Class Initialized
INFO - 2017-02-27 05:14:29 --> URI Class Initialized
INFO - 2017-02-27 05:14:29 --> Router Class Initialized
INFO - 2017-02-27 05:14:29 --> Output Class Initialized
INFO - 2017-02-27 05:14:29 --> Security Class Initialized
DEBUG - 2017-02-27 05:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:14:29 --> Input Class Initialized
INFO - 2017-02-27 05:14:29 --> Language Class Initialized
INFO - 2017-02-27 05:14:29 --> Language Class Initialized
INFO - 2017-02-27 05:14:29 --> Config Class Initialized
INFO - 2017-02-27 05:14:29 --> Loader Class Initialized
INFO - 2017-02-27 05:14:29 --> Helper loaded: form_helper
INFO - 2017-02-27 05:14:29 --> Helper loaded: url_helper
INFO - 2017-02-27 05:14:29 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:14:29 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:14:29 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:14:29 --> Template Class Initialized
INFO - 2017-02-27 05:14:29 --> Model Class Initialized
INFO - 2017-02-27 05:14:29 --> Controller Class Initialized
DEBUG - 2017-02-27 05:14:29 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:14:29 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:14:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:14:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:32:04 --> Config Class Initialized
INFO - 2017-02-27 05:32:04 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:04 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:04 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:04 --> URI Class Initialized
DEBUG - 2017-02-27 05:32:04 --> No URI present. Default controller set.
INFO - 2017-02-27 05:32:04 --> Router Class Initialized
INFO - 2017-02-27 05:32:04 --> Output Class Initialized
INFO - 2017-02-27 05:32:04 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:04 --> Input Class Initialized
INFO - 2017-02-27 05:32:04 --> Language Class Initialized
INFO - 2017-02-27 05:32:04 --> Language Class Initialized
INFO - 2017-02-27 05:32:04 --> Config Class Initialized
INFO - 2017-02-27 05:32:04 --> Loader Class Initialized
INFO - 2017-02-27 05:32:04 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:04 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:04 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:04 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:04 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:04 --> Template Class Initialized
INFO - 2017-02-27 05:32:04 --> Model Class Initialized
INFO - 2017-02-27 05:32:04 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:04 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:04 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 05:32:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-27 05:32:04 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 05:32:04 --> Final output sent to browser
DEBUG - 2017-02-27 05:32:04 --> Total execution time: 0.0588
INFO - 2017-02-27 05:32:09 --> Config Class Initialized
INFO - 2017-02-27 05:32:09 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:09 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:09 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:09 --> URI Class Initialized
INFO - 2017-02-27 05:32:09 --> Router Class Initialized
INFO - 2017-02-27 05:32:09 --> Output Class Initialized
INFO - 2017-02-27 05:32:09 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:09 --> Input Class Initialized
INFO - 2017-02-27 05:32:09 --> Language Class Initialized
INFO - 2017-02-27 05:32:09 --> Language Class Initialized
INFO - 2017-02-27 05:32:09 --> Config Class Initialized
INFO - 2017-02-27 05:32:09 --> Loader Class Initialized
INFO - 2017-02-27 05:32:09 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:09 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:09 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:09 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:09 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:09 --> Template Class Initialized
INFO - 2017-02-27 05:32:09 --> Model Class Initialized
INFO - 2017-02-27 05:32:09 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:09 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:09 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:32:09 --> Config Class Initialized
INFO - 2017-02-27 05:32:09 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:09 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:09 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:09 --> URI Class Initialized
INFO - 2017-02-27 05:32:09 --> Router Class Initialized
INFO - 2017-02-27 05:32:09 --> Output Class Initialized
INFO - 2017-02-27 05:32:09 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:09 --> Input Class Initialized
INFO - 2017-02-27 05:32:09 --> Language Class Initialized
INFO - 2017-02-27 05:32:09 --> Language Class Initialized
INFO - 2017-02-27 05:32:09 --> Config Class Initialized
INFO - 2017-02-27 05:32:09 --> Loader Class Initialized
INFO - 2017-02-27 05:32:09 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:09 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:09 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:09 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:09 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:09 --> Template Class Initialized
INFO - 2017-02-27 05:32:09 --> Model Class Initialized
INFO - 2017-02-27 05:32:09 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:09 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:09 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:32:11 --> Config Class Initialized
INFO - 2017-02-27 05:32:11 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:11 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:11 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:11 --> URI Class Initialized
INFO - 2017-02-27 05:32:11 --> Router Class Initialized
INFO - 2017-02-27 05:32:11 --> Output Class Initialized
INFO - 2017-02-27 05:32:11 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:11 --> Input Class Initialized
INFO - 2017-02-27 05:32:11 --> Language Class Initialized
INFO - 2017-02-27 05:32:11 --> Language Class Initialized
INFO - 2017-02-27 05:32:11 --> Config Class Initialized
INFO - 2017-02-27 05:32:11 --> Loader Class Initialized
INFO - 2017-02-27 05:32:11 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:11 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:11 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:11 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:11 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:11 --> Template Class Initialized
INFO - 2017-02-27 05:32:11 --> Model Class Initialized
INFO - 2017-02-27 05:32:11 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:11 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:11 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:32:12 --> Config Class Initialized
INFO - 2017-02-27 05:32:12 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:12 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:12 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:12 --> URI Class Initialized
INFO - 2017-02-27 05:32:12 --> Router Class Initialized
INFO - 2017-02-27 05:32:12 --> Output Class Initialized
INFO - 2017-02-27 05:32:12 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:12 --> Input Class Initialized
INFO - 2017-02-27 05:32:12 --> Language Class Initialized
INFO - 2017-02-27 05:32:12 --> Language Class Initialized
INFO - 2017-02-27 05:32:12 --> Config Class Initialized
INFO - 2017-02-27 05:32:12 --> Loader Class Initialized
INFO - 2017-02-27 05:32:12 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:12 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:12 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:12 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:12 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:12 --> Template Class Initialized
INFO - 2017-02-27 05:32:12 --> Model Class Initialized
INFO - 2017-02-27 05:32:12 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:12 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:12 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:32:23 --> Config Class Initialized
INFO - 2017-02-27 05:32:23 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:23 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:23 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:23 --> URI Class Initialized
INFO - 2017-02-27 05:32:23 --> Router Class Initialized
INFO - 2017-02-27 05:32:23 --> Output Class Initialized
INFO - 2017-02-27 05:32:23 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:23 --> Input Class Initialized
INFO - 2017-02-27 05:32:23 --> Language Class Initialized
INFO - 2017-02-27 05:32:23 --> Language Class Initialized
INFO - 2017-02-27 05:32:23 --> Config Class Initialized
INFO - 2017-02-27 05:32:23 --> Loader Class Initialized
INFO - 2017-02-27 05:32:23 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:23 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:23 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:23 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:23 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:23 --> Template Class Initialized
INFO - 2017-02-27 05:32:23 --> Model Class Initialized
INFO - 2017-02-27 05:32:23 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:23 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:23 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 05:32:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/about_us.php
DEBUG - 2017-02-27 05:32:23 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 05:32:23 --> Final output sent to browser
DEBUG - 2017-02-27 05:32:23 --> Total execution time: 0.0277
INFO - 2017-02-27 05:32:24 --> Config Class Initialized
INFO - 2017-02-27 05:32:24 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:24 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:24 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:24 --> URI Class Initialized
INFO - 2017-02-27 05:32:24 --> Router Class Initialized
INFO - 2017-02-27 05:32:24 --> Output Class Initialized
INFO - 2017-02-27 05:32:24 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:24 --> Input Class Initialized
INFO - 2017-02-27 05:32:24 --> Language Class Initialized
INFO - 2017-02-27 05:32:24 --> Language Class Initialized
INFO - 2017-02-27 05:32:24 --> Config Class Initialized
INFO - 2017-02-27 05:32:24 --> Loader Class Initialized
INFO - 2017-02-27 05:32:24 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:24 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:24 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:24 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:24 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:24 --> Template Class Initialized
INFO - 2017-02-27 05:32:24 --> Model Class Initialized
INFO - 2017-02-27 05:32:24 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:24 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:24 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:32:24 --> Config Class Initialized
INFO - 2017-02-27 05:32:24 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:24 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:24 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:24 --> URI Class Initialized
INFO - 2017-02-27 05:32:24 --> Router Class Initialized
INFO - 2017-02-27 05:32:24 --> Output Class Initialized
INFO - 2017-02-27 05:32:24 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:24 --> Input Class Initialized
INFO - 2017-02-27 05:32:24 --> Language Class Initialized
INFO - 2017-02-27 05:32:24 --> Language Class Initialized
INFO - 2017-02-27 05:32:24 --> Config Class Initialized
INFO - 2017-02-27 05:32:24 --> Loader Class Initialized
INFO - 2017-02-27 05:32:24 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:24 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:24 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:24 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:24 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:24 --> Template Class Initialized
INFO - 2017-02-27 05:32:24 --> Model Class Initialized
INFO - 2017-02-27 05:32:24 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:24 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:24 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:32:30 --> Config Class Initialized
INFO - 2017-02-27 05:32:30 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:30 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:30 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:30 --> URI Class Initialized
INFO - 2017-02-27 05:32:30 --> Router Class Initialized
INFO - 2017-02-27 05:32:30 --> Output Class Initialized
INFO - 2017-02-27 05:32:30 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:30 --> Input Class Initialized
INFO - 2017-02-27 05:32:30 --> Language Class Initialized
INFO - 2017-02-27 05:32:30 --> Language Class Initialized
INFO - 2017-02-27 05:32:30 --> Config Class Initialized
INFO - 2017-02-27 05:32:30 --> Loader Class Initialized
INFO - 2017-02-27 05:32:30 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:30 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:30 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:30 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:30 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:30 --> Template Class Initialized
INFO - 2017-02-27 05:32:30 --> Model Class Initialized
INFO - 2017-02-27 05:32:30 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:30 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:30 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 05:32:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-02-27 05:32:30 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 05:32:30 --> Final output sent to browser
DEBUG - 2017-02-27 05:32:30 --> Total execution time: 0.0639
INFO - 2017-02-27 05:32:31 --> Config Class Initialized
INFO - 2017-02-27 05:32:31 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:31 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:31 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:31 --> URI Class Initialized
INFO - 2017-02-27 05:32:31 --> Router Class Initialized
INFO - 2017-02-27 05:32:31 --> Output Class Initialized
INFO - 2017-02-27 05:32:31 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:31 --> Input Class Initialized
INFO - 2017-02-27 05:32:31 --> Language Class Initialized
INFO - 2017-02-27 05:32:31 --> Language Class Initialized
INFO - 2017-02-27 05:32:31 --> Config Class Initialized
INFO - 2017-02-27 05:32:31 --> Loader Class Initialized
INFO - 2017-02-27 05:32:31 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:31 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:31 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:31 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:31 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:31 --> Template Class Initialized
INFO - 2017-02-27 05:32:31 --> Model Class Initialized
INFO - 2017-02-27 05:32:31 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:31 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:31 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:32:31 --> Config Class Initialized
INFO - 2017-02-27 05:32:31 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:31 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:31 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:31 --> URI Class Initialized
INFO - 2017-02-27 05:32:31 --> Router Class Initialized
INFO - 2017-02-27 05:32:31 --> Output Class Initialized
INFO - 2017-02-27 05:32:31 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:31 --> Input Class Initialized
INFO - 2017-02-27 05:32:31 --> Language Class Initialized
INFO - 2017-02-27 05:32:31 --> Language Class Initialized
INFO - 2017-02-27 05:32:31 --> Config Class Initialized
INFO - 2017-02-27 05:32:31 --> Loader Class Initialized
INFO - 2017-02-27 05:32:31 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:31 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:31 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:31 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:31 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:31 --> Template Class Initialized
INFO - 2017-02-27 05:32:31 --> Model Class Initialized
INFO - 2017-02-27 05:32:31 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:31 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:31 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:32:46 --> Config Class Initialized
INFO - 2017-02-27 05:32:46 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:46 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:46 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:46 --> URI Class Initialized
INFO - 2017-02-27 05:32:46 --> Router Class Initialized
INFO - 2017-02-27 05:32:46 --> Output Class Initialized
INFO - 2017-02-27 05:32:46 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:46 --> Input Class Initialized
INFO - 2017-02-27 05:32:46 --> Language Class Initialized
INFO - 2017-02-27 05:32:46 --> Language Class Initialized
INFO - 2017-02-27 05:32:46 --> Config Class Initialized
INFO - 2017-02-27 05:32:46 --> Loader Class Initialized
INFO - 2017-02-27 05:32:46 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:46 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:46 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:46 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:46 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:46 --> Template Class Initialized
INFO - 2017-02-27 05:32:46 --> Model Class Initialized
INFO - 2017-02-27 05:32:46 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:46 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:46 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:32:46 --> Config Class Initialized
INFO - 2017-02-27 05:32:46 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:46 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:46 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:46 --> URI Class Initialized
INFO - 2017-02-27 05:32:46 --> Router Class Initialized
INFO - 2017-02-27 05:32:46 --> Output Class Initialized
INFO - 2017-02-27 05:32:46 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:46 --> Input Class Initialized
INFO - 2017-02-27 05:32:46 --> Language Class Initialized
INFO - 2017-02-27 05:32:46 --> Language Class Initialized
INFO - 2017-02-27 05:32:46 --> Config Class Initialized
INFO - 2017-02-27 05:32:46 --> Loader Class Initialized
INFO - 2017-02-27 05:32:46 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:46 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:46 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:46 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:46 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:46 --> Template Class Initialized
INFO - 2017-02-27 05:32:46 --> Model Class Initialized
INFO - 2017-02-27 05:32:46 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:46 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:46 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:32:49 --> Config Class Initialized
INFO - 2017-02-27 05:32:49 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:49 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:49 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:49 --> URI Class Initialized
INFO - 2017-02-27 05:32:49 --> Router Class Initialized
INFO - 2017-02-27 05:32:49 --> Output Class Initialized
INFO - 2017-02-27 05:32:49 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:49 --> Input Class Initialized
INFO - 2017-02-27 05:32:49 --> Language Class Initialized
INFO - 2017-02-27 05:32:49 --> Language Class Initialized
INFO - 2017-02-27 05:32:49 --> Config Class Initialized
INFO - 2017-02-27 05:32:49 --> Loader Class Initialized
INFO - 2017-02-27 05:32:49 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:49 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:49 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:49 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:49 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:49 --> Template Class Initialized
INFO - 2017-02-27 05:32:49 --> Model Class Initialized
INFO - 2017-02-27 05:32:49 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:49 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:49 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 05:32:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-02-27 05:32:49 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 05:32:49 --> Final output sent to browser
DEBUG - 2017-02-27 05:32:49 --> Total execution time: 0.0730
INFO - 2017-02-27 05:32:49 --> Config Class Initialized
INFO - 2017-02-27 05:32:49 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:49 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:49 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:49 --> URI Class Initialized
INFO - 2017-02-27 05:32:49 --> Router Class Initialized
INFO - 2017-02-27 05:32:49 --> Output Class Initialized
INFO - 2017-02-27 05:32:49 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:49 --> Input Class Initialized
INFO - 2017-02-27 05:32:49 --> Language Class Initialized
INFO - 2017-02-27 05:32:49 --> Language Class Initialized
INFO - 2017-02-27 05:32:49 --> Config Class Initialized
INFO - 2017-02-27 05:32:49 --> Loader Class Initialized
INFO - 2017-02-27 05:32:49 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:49 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:49 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:49 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:49 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:49 --> Template Class Initialized
INFO - 2017-02-27 05:32:49 --> Model Class Initialized
INFO - 2017-02-27 05:32:49 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:49 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:49 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:32:50 --> Config Class Initialized
INFO - 2017-02-27 05:32:50 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:50 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:50 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:50 --> URI Class Initialized
INFO - 2017-02-27 05:32:50 --> Router Class Initialized
INFO - 2017-02-27 05:32:50 --> Output Class Initialized
INFO - 2017-02-27 05:32:50 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:50 --> Input Class Initialized
INFO - 2017-02-27 05:32:50 --> Language Class Initialized
INFO - 2017-02-27 05:32:50 --> Language Class Initialized
INFO - 2017-02-27 05:32:50 --> Config Class Initialized
INFO - 2017-02-27 05:32:50 --> Loader Class Initialized
INFO - 2017-02-27 05:32:50 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:50 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:50 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:50 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:50 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:50 --> Template Class Initialized
INFO - 2017-02-27 05:32:50 --> Model Class Initialized
INFO - 2017-02-27 05:32:50 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:50 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:50 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:32:51 --> Config Class Initialized
INFO - 2017-02-27 05:32:51 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:51 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:51 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:51 --> URI Class Initialized
INFO - 2017-02-27 05:32:51 --> Router Class Initialized
INFO - 2017-02-27 05:32:51 --> Output Class Initialized
INFO - 2017-02-27 05:32:51 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:51 --> Input Class Initialized
INFO - 2017-02-27 05:32:51 --> Language Class Initialized
INFO - 2017-02-27 05:32:51 --> Language Class Initialized
INFO - 2017-02-27 05:32:51 --> Config Class Initialized
INFO - 2017-02-27 05:32:51 --> Loader Class Initialized
INFO - 2017-02-27 05:32:51 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:51 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:51 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:51 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:51 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:51 --> Template Class Initialized
INFO - 2017-02-27 05:32:51 --> Model Class Initialized
INFO - 2017-02-27 05:32:51 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:51 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:51 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:32:52 --> Config Class Initialized
INFO - 2017-02-27 05:32:52 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:52 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:52 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:52 --> URI Class Initialized
INFO - 2017-02-27 05:32:52 --> Router Class Initialized
INFO - 2017-02-27 05:32:52 --> Output Class Initialized
INFO - 2017-02-27 05:32:52 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:52 --> Input Class Initialized
INFO - 2017-02-27 05:32:52 --> Language Class Initialized
INFO - 2017-02-27 05:32:52 --> Language Class Initialized
INFO - 2017-02-27 05:32:52 --> Config Class Initialized
INFO - 2017-02-27 05:32:52 --> Loader Class Initialized
INFO - 2017-02-27 05:32:52 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:52 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:52 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:52 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:52 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:52 --> Template Class Initialized
INFO - 2017-02-27 05:32:52 --> Model Class Initialized
INFO - 2017-02-27 05:32:52 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:52 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:52 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:32:55 --> Config Class Initialized
INFO - 2017-02-27 05:32:55 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:55 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:55 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:55 --> URI Class Initialized
INFO - 2017-02-27 05:32:55 --> Router Class Initialized
INFO - 2017-02-27 05:32:55 --> Output Class Initialized
INFO - 2017-02-27 05:32:55 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:55 --> Input Class Initialized
INFO - 2017-02-27 05:32:55 --> Language Class Initialized
INFO - 2017-02-27 05:32:55 --> Language Class Initialized
INFO - 2017-02-27 05:32:55 --> Config Class Initialized
INFO - 2017-02-27 05:32:55 --> Loader Class Initialized
INFO - 2017-02-27 05:32:55 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:55 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:55 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:55 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:55 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:55 --> Template Class Initialized
INFO - 2017-02-27 05:32:55 --> Model Class Initialized
INFO - 2017-02-27 05:32:55 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:55 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:55 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 05:32:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-02-27 05:32:55 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 05:32:55 --> Final output sent to browser
DEBUG - 2017-02-27 05:32:55 --> Total execution time: 0.0188
INFO - 2017-02-27 05:32:56 --> Config Class Initialized
INFO - 2017-02-27 05:32:56 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:56 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:56 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:56 --> URI Class Initialized
INFO - 2017-02-27 05:32:56 --> Router Class Initialized
INFO - 2017-02-27 05:32:56 --> Output Class Initialized
INFO - 2017-02-27 05:32:56 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:56 --> Input Class Initialized
INFO - 2017-02-27 05:32:56 --> Language Class Initialized
INFO - 2017-02-27 05:32:56 --> Language Class Initialized
INFO - 2017-02-27 05:32:56 --> Config Class Initialized
INFO - 2017-02-27 05:32:56 --> Loader Class Initialized
INFO - 2017-02-27 05:32:56 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:56 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:56 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:56 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:56 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:56 --> Template Class Initialized
INFO - 2017-02-27 05:32:56 --> Model Class Initialized
INFO - 2017-02-27 05:32:56 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:56 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:56 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:32:56 --> Config Class Initialized
INFO - 2017-02-27 05:32:56 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:32:56 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:32:56 --> Utf8 Class Initialized
INFO - 2017-02-27 05:32:56 --> URI Class Initialized
INFO - 2017-02-27 05:32:56 --> Router Class Initialized
INFO - 2017-02-27 05:32:56 --> Output Class Initialized
INFO - 2017-02-27 05:32:56 --> Security Class Initialized
DEBUG - 2017-02-27 05:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:32:56 --> Input Class Initialized
INFO - 2017-02-27 05:32:56 --> Language Class Initialized
INFO - 2017-02-27 05:32:56 --> Language Class Initialized
INFO - 2017-02-27 05:32:56 --> Config Class Initialized
INFO - 2017-02-27 05:32:56 --> Loader Class Initialized
INFO - 2017-02-27 05:32:56 --> Helper loaded: form_helper
INFO - 2017-02-27 05:32:56 --> Helper loaded: url_helper
INFO - 2017-02-27 05:32:56 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:32:56 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:32:56 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:32:56 --> Template Class Initialized
INFO - 2017-02-27 05:32:56 --> Model Class Initialized
INFO - 2017-02-27 05:32:56 --> Controller Class Initialized
DEBUG - 2017-02-27 05:32:56 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:32:56 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:32:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:32:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:33:33 --> Config Class Initialized
INFO - 2017-02-27 05:33:33 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:33:33 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:33:33 --> Utf8 Class Initialized
INFO - 2017-02-27 05:33:33 --> URI Class Initialized
INFO - 2017-02-27 05:33:33 --> Router Class Initialized
INFO - 2017-02-27 05:33:33 --> Output Class Initialized
INFO - 2017-02-27 05:33:33 --> Security Class Initialized
DEBUG - 2017-02-27 05:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:33:33 --> Input Class Initialized
INFO - 2017-02-27 05:33:33 --> Language Class Initialized
INFO - 2017-02-27 05:33:33 --> Language Class Initialized
INFO - 2017-02-27 05:33:33 --> Config Class Initialized
INFO - 2017-02-27 05:33:33 --> Loader Class Initialized
INFO - 2017-02-27 05:33:33 --> Helper loaded: form_helper
INFO - 2017-02-27 05:33:33 --> Helper loaded: url_helper
INFO - 2017-02-27 05:33:33 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:33:33 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:33:33 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:33:33 --> Template Class Initialized
INFO - 2017-02-27 05:33:33 --> Model Class Initialized
INFO - 2017-02-27 05:33:33 --> Controller Class Initialized
DEBUG - 2017-02-27 05:33:33 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:33:33 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:33:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:33:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 05:33:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-02-27 05:33:33 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 05:33:33 --> Final output sent to browser
DEBUG - 2017-02-27 05:33:33 --> Total execution time: 0.0720
INFO - 2017-02-27 05:33:34 --> Config Class Initialized
INFO - 2017-02-27 05:33:34 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:33:34 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:33:34 --> Utf8 Class Initialized
INFO - 2017-02-27 05:33:34 --> URI Class Initialized
INFO - 2017-02-27 05:33:34 --> Router Class Initialized
INFO - 2017-02-27 05:33:34 --> Output Class Initialized
INFO - 2017-02-27 05:33:34 --> Security Class Initialized
DEBUG - 2017-02-27 05:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:33:34 --> Input Class Initialized
INFO - 2017-02-27 05:33:34 --> Language Class Initialized
INFO - 2017-02-27 05:33:34 --> Language Class Initialized
INFO - 2017-02-27 05:33:34 --> Config Class Initialized
INFO - 2017-02-27 05:33:34 --> Loader Class Initialized
INFO - 2017-02-27 05:33:34 --> Helper loaded: form_helper
INFO - 2017-02-27 05:33:34 --> Helper loaded: url_helper
INFO - 2017-02-27 05:33:34 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:33:34 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:33:34 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:33:34 --> Template Class Initialized
INFO - 2017-02-27 05:33:34 --> Model Class Initialized
INFO - 2017-02-27 05:33:34 --> Controller Class Initialized
DEBUG - 2017-02-27 05:33:34 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:33:34 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:33:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:33:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:33:34 --> Config Class Initialized
INFO - 2017-02-27 05:33:34 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:33:34 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:33:34 --> Utf8 Class Initialized
INFO - 2017-02-27 05:33:34 --> URI Class Initialized
INFO - 2017-02-27 05:33:34 --> Router Class Initialized
INFO - 2017-02-27 05:33:34 --> Output Class Initialized
INFO - 2017-02-27 05:33:34 --> Security Class Initialized
DEBUG - 2017-02-27 05:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:33:34 --> Input Class Initialized
INFO - 2017-02-27 05:33:34 --> Language Class Initialized
INFO - 2017-02-27 05:33:34 --> Language Class Initialized
INFO - 2017-02-27 05:33:34 --> Config Class Initialized
INFO - 2017-02-27 05:33:34 --> Loader Class Initialized
INFO - 2017-02-27 05:33:34 --> Helper loaded: form_helper
INFO - 2017-02-27 05:33:34 --> Helper loaded: url_helper
INFO - 2017-02-27 05:33:34 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:33:34 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:33:34 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:33:34 --> Template Class Initialized
INFO - 2017-02-27 05:33:34 --> Model Class Initialized
INFO - 2017-02-27 05:33:34 --> Controller Class Initialized
DEBUG - 2017-02-27 05:33:34 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:33:34 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:33:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:33:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:33:36 --> Config Class Initialized
INFO - 2017-02-27 05:33:36 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:33:36 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:33:36 --> Utf8 Class Initialized
INFO - 2017-02-27 05:33:36 --> URI Class Initialized
INFO - 2017-02-27 05:33:36 --> Router Class Initialized
INFO - 2017-02-27 05:33:36 --> Output Class Initialized
INFO - 2017-02-27 05:33:36 --> Security Class Initialized
DEBUG - 2017-02-27 05:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:33:36 --> Input Class Initialized
INFO - 2017-02-27 05:33:36 --> Language Class Initialized
INFO - 2017-02-27 05:33:36 --> Language Class Initialized
INFO - 2017-02-27 05:33:36 --> Config Class Initialized
INFO - 2017-02-27 05:33:36 --> Loader Class Initialized
INFO - 2017-02-27 05:33:36 --> Helper loaded: form_helper
INFO - 2017-02-27 05:33:36 --> Helper loaded: url_helper
INFO - 2017-02-27 05:33:36 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:33:36 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:33:36 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:33:36 --> Template Class Initialized
INFO - 2017-02-27 05:33:36 --> Model Class Initialized
INFO - 2017-02-27 05:33:36 --> Controller Class Initialized
DEBUG - 2017-02-27 05:33:36 --> Login MX_Controller Initialized
INFO - 2017-02-27 05:33:36 --> Helper loaded: cookie_helper
INFO - 2017-02-27 05:33:36 --> Form Validation Class Initialized
INFO - 2017-02-27 05:33:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-27 05:33:36 --> Config Class Initialized
INFO - 2017-02-27 05:33:36 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:33:36 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:33:36 --> Utf8 Class Initialized
INFO - 2017-02-27 05:33:36 --> URI Class Initialized
INFO - 2017-02-27 05:33:36 --> Router Class Initialized
INFO - 2017-02-27 05:33:36 --> Output Class Initialized
INFO - 2017-02-27 05:33:36 --> Security Class Initialized
DEBUG - 2017-02-27 05:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:33:36 --> Input Class Initialized
INFO - 2017-02-27 05:33:36 --> Language Class Initialized
INFO - 2017-02-27 05:33:36 --> Language Class Initialized
INFO - 2017-02-27 05:33:36 --> Config Class Initialized
INFO - 2017-02-27 05:33:36 --> Loader Class Initialized
INFO - 2017-02-27 05:33:36 --> Helper loaded: form_helper
INFO - 2017-02-27 05:33:36 --> Helper loaded: url_helper
INFO - 2017-02-27 05:33:36 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:33:36 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:33:36 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:33:36 --> Template Class Initialized
INFO - 2017-02-27 05:33:36 --> Model Class Initialized
INFO - 2017-02-27 05:33:36 --> Controller Class Initialized
DEBUG - 2017-02-27 05:33:36 --> Dashboard MX_Controller Initialized
INFO - 2017-02-27 05:33:36 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:33:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 05:33:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-02-27 05:33:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 05:33:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-02-27 05:33:36 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 05:33:36 --> Final output sent to browser
DEBUG - 2017-02-27 05:33:36 --> Total execution time: 0.0701
INFO - 2017-02-27 05:33:41 --> Config Class Initialized
INFO - 2017-02-27 05:33:41 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:33:41 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:33:41 --> Utf8 Class Initialized
INFO - 2017-02-27 05:33:41 --> URI Class Initialized
INFO - 2017-02-27 05:33:41 --> Router Class Initialized
INFO - 2017-02-27 05:33:41 --> Output Class Initialized
INFO - 2017-02-27 05:33:41 --> Security Class Initialized
DEBUG - 2017-02-27 05:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:33:41 --> Input Class Initialized
INFO - 2017-02-27 05:33:41 --> Language Class Initialized
INFO - 2017-02-27 05:33:41 --> Language Class Initialized
INFO - 2017-02-27 05:33:41 --> Config Class Initialized
INFO - 2017-02-27 05:33:41 --> Loader Class Initialized
INFO - 2017-02-27 05:33:41 --> Helper loaded: form_helper
INFO - 2017-02-27 05:33:41 --> Helper loaded: url_helper
INFO - 2017-02-27 05:33:41 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:33:41 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:33:41 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:33:41 --> Template Class Initialized
INFO - 2017-02-27 05:33:41 --> Model Class Initialized
INFO - 2017-02-27 05:33:41 --> Controller Class Initialized
DEBUG - 2017-02-27 05:33:41 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:33:41 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:33:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:33:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:33:44 --> Config Class Initialized
INFO - 2017-02-27 05:33:44 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:33:44 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:33:44 --> Utf8 Class Initialized
INFO - 2017-02-27 05:33:44 --> URI Class Initialized
INFO - 2017-02-27 05:33:44 --> Router Class Initialized
INFO - 2017-02-27 05:33:44 --> Output Class Initialized
INFO - 2017-02-27 05:33:44 --> Security Class Initialized
DEBUG - 2017-02-27 05:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:33:44 --> Input Class Initialized
INFO - 2017-02-27 05:33:44 --> Language Class Initialized
INFO - 2017-02-27 05:33:44 --> Language Class Initialized
INFO - 2017-02-27 05:33:44 --> Config Class Initialized
INFO - 2017-02-27 05:33:44 --> Loader Class Initialized
INFO - 2017-02-27 05:33:44 --> Helper loaded: form_helper
INFO - 2017-02-27 05:33:44 --> Helper loaded: url_helper
INFO - 2017-02-27 05:33:44 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:33:44 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:33:44 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:33:44 --> Template Class Initialized
INFO - 2017-02-27 05:33:44 --> Model Class Initialized
INFO - 2017-02-27 05:33:44 --> Controller Class Initialized
DEBUG - 2017-02-27 05:33:44 --> Subscriber MX_Controller Initialized
INFO - 2017-02-27 05:33:44 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:33:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 05:33:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-02-27 05:33:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 05:33:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/subscriber_list.php
DEBUG - 2017-02-27 05:33:44 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 05:33:44 --> Final output sent to browser
DEBUG - 2017-02-27 05:33:44 --> Total execution time: 0.0741
INFO - 2017-02-27 05:33:45 --> Config Class Initialized
INFO - 2017-02-27 05:33:45 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:33:45 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:33:45 --> Utf8 Class Initialized
INFO - 2017-02-27 05:33:45 --> URI Class Initialized
INFO - 2017-02-27 05:33:45 --> Router Class Initialized
INFO - 2017-02-27 05:33:45 --> Output Class Initialized
INFO - 2017-02-27 05:33:45 --> Security Class Initialized
DEBUG - 2017-02-27 05:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:33:45 --> Input Class Initialized
INFO - 2017-02-27 05:33:45 --> Language Class Initialized
INFO - 2017-02-27 05:33:45 --> Language Class Initialized
INFO - 2017-02-27 05:33:45 --> Config Class Initialized
INFO - 2017-02-27 05:33:45 --> Loader Class Initialized
INFO - 2017-02-27 05:33:45 --> Helper loaded: form_helper
INFO - 2017-02-27 05:33:45 --> Helper loaded: url_helper
INFO - 2017-02-27 05:33:45 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:33:45 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:33:45 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:33:45 --> Template Class Initialized
INFO - 2017-02-27 05:33:45 --> Model Class Initialized
INFO - 2017-02-27 05:33:45 --> Controller Class Initialized
DEBUG - 2017-02-27 05:33:45 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:33:45 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:33:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:33:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:33:46 --> Config Class Initialized
INFO - 2017-02-27 05:33:46 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:33:46 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:33:46 --> Utf8 Class Initialized
INFO - 2017-02-27 05:33:46 --> URI Class Initialized
INFO - 2017-02-27 05:33:46 --> Router Class Initialized
INFO - 2017-02-27 05:33:46 --> Output Class Initialized
INFO - 2017-02-27 05:33:46 --> Security Class Initialized
DEBUG - 2017-02-27 05:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:33:46 --> Input Class Initialized
INFO - 2017-02-27 05:33:46 --> Language Class Initialized
INFO - 2017-02-27 05:33:46 --> Language Class Initialized
INFO - 2017-02-27 05:33:46 --> Config Class Initialized
INFO - 2017-02-27 05:33:46 --> Loader Class Initialized
INFO - 2017-02-27 05:33:46 --> Helper loaded: form_helper
INFO - 2017-02-27 05:33:46 --> Helper loaded: url_helper
INFO - 2017-02-27 05:33:46 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:33:46 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:33:46 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:33:46 --> Template Class Initialized
INFO - 2017-02-27 05:33:46 --> Model Class Initialized
INFO - 2017-02-27 05:33:46 --> Controller Class Initialized
DEBUG - 2017-02-27 05:33:46 --> Subscriber MX_Controller Initialized
INFO - 2017-02-27 05:33:46 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:33:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 05:33:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-02-27 05:33:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 05:33:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_subscriber.php
DEBUG - 2017-02-27 05:33:46 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 05:33:46 --> Final output sent to browser
DEBUG - 2017-02-27 05:33:46 --> Total execution time: 0.0242
INFO - 2017-02-27 05:33:46 --> Config Class Initialized
INFO - 2017-02-27 05:33:46 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:33:46 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:33:46 --> Utf8 Class Initialized
INFO - 2017-02-27 05:33:46 --> URI Class Initialized
INFO - 2017-02-27 05:33:46 --> Router Class Initialized
INFO - 2017-02-27 05:33:46 --> Output Class Initialized
INFO - 2017-02-27 05:33:46 --> Security Class Initialized
DEBUG - 2017-02-27 05:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:33:46 --> Input Class Initialized
INFO - 2017-02-27 05:33:46 --> Language Class Initialized
INFO - 2017-02-27 05:33:46 --> Language Class Initialized
INFO - 2017-02-27 05:33:46 --> Config Class Initialized
INFO - 2017-02-27 05:33:46 --> Loader Class Initialized
INFO - 2017-02-27 05:33:46 --> Helper loaded: form_helper
INFO - 2017-02-27 05:33:46 --> Helper loaded: url_helper
INFO - 2017-02-27 05:33:46 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:33:46 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:33:46 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:33:46 --> Template Class Initialized
INFO - 2017-02-27 05:33:46 --> Model Class Initialized
INFO - 2017-02-27 05:33:46 --> Controller Class Initialized
DEBUG - 2017-02-27 05:33:46 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:33:46 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:33:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:33:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:33:48 --> Config Class Initialized
INFO - 2017-02-27 05:33:48 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:33:48 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:33:48 --> Utf8 Class Initialized
INFO - 2017-02-27 05:33:48 --> URI Class Initialized
INFO - 2017-02-27 05:33:48 --> Router Class Initialized
INFO - 2017-02-27 05:33:48 --> Output Class Initialized
INFO - 2017-02-27 05:33:48 --> Security Class Initialized
DEBUG - 2017-02-27 05:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:33:48 --> Input Class Initialized
INFO - 2017-02-27 05:33:48 --> Language Class Initialized
INFO - 2017-02-27 05:33:48 --> Language Class Initialized
INFO - 2017-02-27 05:33:48 --> Config Class Initialized
INFO - 2017-02-27 05:33:48 --> Loader Class Initialized
INFO - 2017-02-27 05:33:48 --> Helper loaded: form_helper
INFO - 2017-02-27 05:33:48 --> Helper loaded: url_helper
INFO - 2017-02-27 05:33:48 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:33:48 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:33:48 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:33:48 --> Template Class Initialized
INFO - 2017-02-27 05:33:48 --> Model Class Initialized
INFO - 2017-02-27 05:33:48 --> Controller Class Initialized
DEBUG - 2017-02-27 05:33:48 --> Project MX_Controller Initialized
INFO - 2017-02-27 05:33:48 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:33:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 05:33:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-02-27 05:33:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 05:33:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/project_list.php
DEBUG - 2017-02-27 05:33:48 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 05:33:48 --> Final output sent to browser
DEBUG - 2017-02-27 05:33:48 --> Total execution time: 0.0289
INFO - 2017-02-27 05:33:49 --> Config Class Initialized
INFO - 2017-02-27 05:33:49 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:33:49 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:33:49 --> Utf8 Class Initialized
INFO - 2017-02-27 05:33:49 --> URI Class Initialized
INFO - 2017-02-27 05:33:49 --> Router Class Initialized
INFO - 2017-02-27 05:33:49 --> Output Class Initialized
INFO - 2017-02-27 05:33:49 --> Security Class Initialized
DEBUG - 2017-02-27 05:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:33:49 --> Input Class Initialized
INFO - 2017-02-27 05:33:49 --> Language Class Initialized
INFO - 2017-02-27 05:33:49 --> Language Class Initialized
INFO - 2017-02-27 05:33:49 --> Config Class Initialized
INFO - 2017-02-27 05:33:49 --> Loader Class Initialized
INFO - 2017-02-27 05:33:49 --> Helper loaded: form_helper
INFO - 2017-02-27 05:33:49 --> Helper loaded: url_helper
INFO - 2017-02-27 05:33:49 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:33:49 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:33:49 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:33:49 --> Template Class Initialized
INFO - 2017-02-27 05:33:49 --> Model Class Initialized
INFO - 2017-02-27 05:33:49 --> Controller Class Initialized
DEBUG - 2017-02-27 05:33:49 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:33:49 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:33:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:33:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:33:50 --> Config Class Initialized
INFO - 2017-02-27 05:33:50 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:33:50 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:33:50 --> Utf8 Class Initialized
INFO - 2017-02-27 05:33:50 --> URI Class Initialized
INFO - 2017-02-27 05:33:50 --> Router Class Initialized
INFO - 2017-02-27 05:33:50 --> Output Class Initialized
INFO - 2017-02-27 05:33:50 --> Security Class Initialized
DEBUG - 2017-02-27 05:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:33:50 --> Input Class Initialized
INFO - 2017-02-27 05:33:50 --> Language Class Initialized
INFO - 2017-02-27 05:33:50 --> Language Class Initialized
INFO - 2017-02-27 05:33:50 --> Config Class Initialized
INFO - 2017-02-27 05:33:50 --> Loader Class Initialized
INFO - 2017-02-27 05:33:50 --> Helper loaded: form_helper
INFO - 2017-02-27 05:33:50 --> Helper loaded: url_helper
INFO - 2017-02-27 05:33:50 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:33:50 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:33:50 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:33:50 --> Template Class Initialized
INFO - 2017-02-27 05:33:50 --> Model Class Initialized
INFO - 2017-02-27 05:33:50 --> Controller Class Initialized
DEBUG - 2017-02-27 05:33:50 --> Project MX_Controller Initialized
INFO - 2017-02-27 05:33:50 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:33:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 05:33:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-02-27 05:33:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 05:33:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-02-27 05:33:50 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 05:33:50 --> Final output sent to browser
DEBUG - 2017-02-27 05:33:50 --> Total execution time: 0.0218
INFO - 2017-02-27 05:33:50 --> Config Class Initialized
INFO - 2017-02-27 05:33:50 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:33:50 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:33:50 --> Utf8 Class Initialized
INFO - 2017-02-27 05:33:50 --> URI Class Initialized
INFO - 2017-02-27 05:33:50 --> Router Class Initialized
INFO - 2017-02-27 05:33:50 --> Output Class Initialized
INFO - 2017-02-27 05:33:50 --> Security Class Initialized
DEBUG - 2017-02-27 05:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:33:50 --> Input Class Initialized
INFO - 2017-02-27 05:33:50 --> Language Class Initialized
INFO - 2017-02-27 05:33:50 --> Language Class Initialized
INFO - 2017-02-27 05:33:50 --> Config Class Initialized
INFO - 2017-02-27 05:33:50 --> Loader Class Initialized
INFO - 2017-02-27 05:33:50 --> Helper loaded: form_helper
INFO - 2017-02-27 05:33:50 --> Helper loaded: url_helper
INFO - 2017-02-27 05:33:50 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:33:50 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:33:50 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:33:50 --> Template Class Initialized
INFO - 2017-02-27 05:33:50 --> Model Class Initialized
INFO - 2017-02-27 05:33:50 --> Controller Class Initialized
DEBUG - 2017-02-27 05:33:50 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:33:50 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:33:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:33:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:33:52 --> Config Class Initialized
INFO - 2017-02-27 05:33:52 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:33:52 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:33:52 --> Utf8 Class Initialized
INFO - 2017-02-27 05:33:52 --> URI Class Initialized
INFO - 2017-02-27 05:33:52 --> Router Class Initialized
INFO - 2017-02-27 05:33:52 --> Output Class Initialized
INFO - 2017-02-27 05:33:52 --> Security Class Initialized
DEBUG - 2017-02-27 05:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:33:52 --> Input Class Initialized
INFO - 2017-02-27 05:33:52 --> Language Class Initialized
INFO - 2017-02-27 05:33:52 --> Language Class Initialized
INFO - 2017-02-27 05:33:52 --> Config Class Initialized
INFO - 2017-02-27 05:33:52 --> Loader Class Initialized
INFO - 2017-02-27 05:33:52 --> Helper loaded: form_helper
INFO - 2017-02-27 05:33:52 --> Helper loaded: url_helper
INFO - 2017-02-27 05:33:52 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:33:52 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:33:52 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:33:52 --> Template Class Initialized
INFO - 2017-02-27 05:33:52 --> Model Class Initialized
INFO - 2017-02-27 05:33:52 --> Controller Class Initialized
DEBUG - 2017-02-27 05:33:52 --> Project MX_Controller Initialized
INFO - 2017-02-27 05:33:52 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:33:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 05:33:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-02-27 05:33:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 05:33:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-02-27 05:33:52 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 05:33:52 --> Final output sent to browser
DEBUG - 2017-02-27 05:33:52 --> Total execution time: 0.0158
INFO - 2017-02-27 05:33:52 --> Config Class Initialized
INFO - 2017-02-27 05:33:52 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:33:52 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:33:52 --> Utf8 Class Initialized
INFO - 2017-02-27 05:33:52 --> URI Class Initialized
INFO - 2017-02-27 05:33:52 --> Router Class Initialized
INFO - 2017-02-27 05:33:52 --> Output Class Initialized
INFO - 2017-02-27 05:33:52 --> Security Class Initialized
DEBUG - 2017-02-27 05:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:33:52 --> Input Class Initialized
INFO - 2017-02-27 05:33:52 --> Language Class Initialized
INFO - 2017-02-27 05:33:52 --> Language Class Initialized
INFO - 2017-02-27 05:33:52 --> Config Class Initialized
INFO - 2017-02-27 05:33:52 --> Loader Class Initialized
INFO - 2017-02-27 05:33:52 --> Helper loaded: form_helper
INFO - 2017-02-27 05:33:52 --> Helper loaded: url_helper
INFO - 2017-02-27 05:33:52 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:33:52 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:33:52 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:33:52 --> Template Class Initialized
INFO - 2017-02-27 05:33:52 --> Model Class Initialized
INFO - 2017-02-27 05:33:52 --> Controller Class Initialized
DEBUG - 2017-02-27 05:33:52 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:33:52 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:33:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:33:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:33:56 --> Config Class Initialized
INFO - 2017-02-27 05:33:56 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:33:56 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:33:56 --> Utf8 Class Initialized
INFO - 2017-02-27 05:33:56 --> URI Class Initialized
INFO - 2017-02-27 05:33:56 --> Router Class Initialized
INFO - 2017-02-27 05:33:56 --> Output Class Initialized
INFO - 2017-02-27 05:33:56 --> Security Class Initialized
DEBUG - 2017-02-27 05:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:33:56 --> Input Class Initialized
INFO - 2017-02-27 05:33:56 --> Language Class Initialized
INFO - 2017-02-27 05:33:56 --> Language Class Initialized
INFO - 2017-02-27 05:33:56 --> Config Class Initialized
INFO - 2017-02-27 05:33:56 --> Loader Class Initialized
INFO - 2017-02-27 05:33:56 --> Helper loaded: form_helper
INFO - 2017-02-27 05:33:56 --> Helper loaded: url_helper
INFO - 2017-02-27 05:33:56 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:33:56 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:33:56 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:33:56 --> Template Class Initialized
INFO - 2017-02-27 05:33:56 --> Model Class Initialized
INFO - 2017-02-27 05:33:56 --> Controller Class Initialized
DEBUG - 2017-02-27 05:33:56 --> Download_data MX_Controller Initialized
INFO - 2017-02-27 05:33:56 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:33:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 05:33:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-02-27 05:33:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 05:33:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/download_data.php
DEBUG - 2017-02-27 05:33:56 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 05:33:56 --> Final output sent to browser
DEBUG - 2017-02-27 05:33:56 --> Total execution time: 0.0329
INFO - 2017-02-27 05:33:56 --> Config Class Initialized
INFO - 2017-02-27 05:33:56 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:33:56 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:33:56 --> Utf8 Class Initialized
INFO - 2017-02-27 05:33:56 --> URI Class Initialized
INFO - 2017-02-27 05:33:56 --> Router Class Initialized
INFO - 2017-02-27 05:33:56 --> Output Class Initialized
INFO - 2017-02-27 05:33:56 --> Security Class Initialized
DEBUG - 2017-02-27 05:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:33:56 --> Input Class Initialized
INFO - 2017-02-27 05:33:56 --> Language Class Initialized
INFO - 2017-02-27 05:33:56 --> Language Class Initialized
INFO - 2017-02-27 05:33:56 --> Config Class Initialized
INFO - 2017-02-27 05:33:56 --> Loader Class Initialized
INFO - 2017-02-27 05:33:56 --> Helper loaded: form_helper
INFO - 2017-02-27 05:33:56 --> Helper loaded: url_helper
INFO - 2017-02-27 05:33:56 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:33:56 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:33:56 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:33:56 --> Template Class Initialized
INFO - 2017-02-27 05:33:56 --> Model Class Initialized
INFO - 2017-02-27 05:33:56 --> Controller Class Initialized
DEBUG - 2017-02-27 05:33:56 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:33:56 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:33:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:33:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:34:00 --> Config Class Initialized
INFO - 2017-02-27 05:34:00 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:00 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:00 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:00 --> URI Class Initialized
INFO - 2017-02-27 05:34:00 --> Router Class Initialized
INFO - 2017-02-27 05:34:00 --> Output Class Initialized
INFO - 2017-02-27 05:34:00 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:00 --> Input Class Initialized
INFO - 2017-02-27 05:34:00 --> Language Class Initialized
INFO - 2017-02-27 05:34:00 --> Language Class Initialized
INFO - 2017-02-27 05:34:00 --> Config Class Initialized
INFO - 2017-02-27 05:34:00 --> Loader Class Initialized
INFO - 2017-02-27 05:34:00 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:00 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:00 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:00 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:00 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:00 --> Template Class Initialized
INFO - 2017-02-27 05:34:00 --> Model Class Initialized
INFO - 2017-02-27 05:34:00 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:00 --> Store MX_Controller Initialized
INFO - 2017-02-27 05:34:00 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:34:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 05:34:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-02-27 05:34:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 05:34:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/product_list.php
DEBUG - 2017-02-27 05:34:00 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 05:34:00 --> Final output sent to browser
DEBUG - 2017-02-27 05:34:00 --> Total execution time: 0.0914
INFO - 2017-02-27 05:34:00 --> Config Class Initialized
INFO - 2017-02-27 05:34:00 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:00 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:00 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:00 --> URI Class Initialized
INFO - 2017-02-27 05:34:00 --> Router Class Initialized
INFO - 2017-02-27 05:34:00 --> Output Class Initialized
INFO - 2017-02-27 05:34:00 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:00 --> Input Class Initialized
INFO - 2017-02-27 05:34:00 --> Language Class Initialized
INFO - 2017-02-27 05:34:00 --> Language Class Initialized
INFO - 2017-02-27 05:34:00 --> Config Class Initialized
INFO - 2017-02-27 05:34:00 --> Loader Class Initialized
INFO - 2017-02-27 05:34:00 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:00 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:00 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:00 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:00 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:00 --> Template Class Initialized
INFO - 2017-02-27 05:34:00 --> Model Class Initialized
INFO - 2017-02-27 05:34:00 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:00 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:34:00 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:34:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:34:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:34:03 --> Config Class Initialized
INFO - 2017-02-27 05:34:03 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:03 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:03 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:03 --> URI Class Initialized
INFO - 2017-02-27 05:34:03 --> Router Class Initialized
INFO - 2017-02-27 05:34:03 --> Output Class Initialized
INFO - 2017-02-27 05:34:03 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:03 --> Input Class Initialized
INFO - 2017-02-27 05:34:03 --> Language Class Initialized
INFO - 2017-02-27 05:34:03 --> Language Class Initialized
INFO - 2017-02-27 05:34:03 --> Config Class Initialized
INFO - 2017-02-27 05:34:03 --> Loader Class Initialized
INFO - 2017-02-27 05:34:03 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:03 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:03 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:03 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:03 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:03 --> Template Class Initialized
INFO - 2017-02-27 05:34:03 --> Model Class Initialized
INFO - 2017-02-27 05:34:03 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:03 --> Store MX_Controller Initialized
INFO - 2017-02-27 05:34:03 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:34:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 05:34:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-02-27 05:34:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 05:34:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/pending_orders.php
DEBUG - 2017-02-27 05:34:03 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 05:34:03 --> Final output sent to browser
DEBUG - 2017-02-27 05:34:03 --> Total execution time: 0.0288
INFO - 2017-02-27 05:34:04 --> Config Class Initialized
INFO - 2017-02-27 05:34:04 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:04 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:04 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:04 --> URI Class Initialized
INFO - 2017-02-27 05:34:04 --> Router Class Initialized
INFO - 2017-02-27 05:34:04 --> Output Class Initialized
INFO - 2017-02-27 05:34:04 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:04 --> Input Class Initialized
INFO - 2017-02-27 05:34:04 --> Language Class Initialized
INFO - 2017-02-27 05:34:04 --> Language Class Initialized
INFO - 2017-02-27 05:34:04 --> Config Class Initialized
INFO - 2017-02-27 05:34:04 --> Loader Class Initialized
INFO - 2017-02-27 05:34:04 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:04 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:04 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:04 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:04 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:04 --> Template Class Initialized
INFO - 2017-02-27 05:34:04 --> Model Class Initialized
INFO - 2017-02-27 05:34:04 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:04 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:34:04 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:34:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:34:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:34:06 --> Config Class Initialized
INFO - 2017-02-27 05:34:06 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:06 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:06 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:06 --> URI Class Initialized
INFO - 2017-02-27 05:34:06 --> Router Class Initialized
INFO - 2017-02-27 05:34:06 --> Output Class Initialized
INFO - 2017-02-27 05:34:06 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:06 --> Input Class Initialized
INFO - 2017-02-27 05:34:06 --> Language Class Initialized
INFO - 2017-02-27 05:34:06 --> Language Class Initialized
INFO - 2017-02-27 05:34:06 --> Config Class Initialized
INFO - 2017-02-27 05:34:06 --> Loader Class Initialized
INFO - 2017-02-27 05:34:06 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:06 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:06 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:06 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:06 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:06 --> Template Class Initialized
INFO - 2017-02-27 05:34:06 --> Model Class Initialized
INFO - 2017-02-27 05:34:06 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:06 --> Store MX_Controller Initialized
INFO - 2017-02-27 05:34:06 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:34:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 05:34:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-02-27 05:34:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 05:34:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/revenue.php
DEBUG - 2017-02-27 05:34:06 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 05:34:06 --> Final output sent to browser
DEBUG - 2017-02-27 05:34:06 --> Total execution time: 0.0198
INFO - 2017-02-27 05:34:06 --> Config Class Initialized
INFO - 2017-02-27 05:34:06 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:06 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:06 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:06 --> URI Class Initialized
INFO - 2017-02-27 05:34:06 --> Router Class Initialized
INFO - 2017-02-27 05:34:06 --> Output Class Initialized
INFO - 2017-02-27 05:34:06 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:06 --> Input Class Initialized
INFO - 2017-02-27 05:34:06 --> Language Class Initialized
INFO - 2017-02-27 05:34:06 --> Language Class Initialized
INFO - 2017-02-27 05:34:06 --> Config Class Initialized
INFO - 2017-02-27 05:34:06 --> Loader Class Initialized
INFO - 2017-02-27 05:34:06 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:06 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:06 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:06 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:06 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:06 --> Template Class Initialized
INFO - 2017-02-27 05:34:06 --> Model Class Initialized
INFO - 2017-02-27 05:34:06 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:06 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:34:06 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:34:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:34:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:34:09 --> Config Class Initialized
INFO - 2017-02-27 05:34:09 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:09 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:09 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:09 --> URI Class Initialized
INFO - 2017-02-27 05:34:09 --> Router Class Initialized
INFO - 2017-02-27 05:34:09 --> Output Class Initialized
INFO - 2017-02-27 05:34:09 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:09 --> Input Class Initialized
INFO - 2017-02-27 05:34:09 --> Language Class Initialized
INFO - 2017-02-27 05:34:09 --> Language Class Initialized
INFO - 2017-02-27 05:34:09 --> Config Class Initialized
INFO - 2017-02-27 05:34:09 --> Loader Class Initialized
INFO - 2017-02-27 05:34:09 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:09 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:09 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:09 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:09 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:09 --> Template Class Initialized
INFO - 2017-02-27 05:34:09 --> Model Class Initialized
INFO - 2017-02-27 05:34:09 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:09 --> Setting MX_Controller Initialized
INFO - 2017-02-27 05:34:09 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:34:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 05:34:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-02-27 05:34:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 05:34:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/set_store_name.php
DEBUG - 2017-02-27 05:34:09 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 05:34:09 --> Final output sent to browser
DEBUG - 2017-02-27 05:34:09 --> Total execution time: 0.0221
INFO - 2017-02-27 05:34:10 --> Config Class Initialized
INFO - 2017-02-27 05:34:10 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:10 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:10 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:10 --> URI Class Initialized
INFO - 2017-02-27 05:34:10 --> Router Class Initialized
INFO - 2017-02-27 05:34:10 --> Output Class Initialized
INFO - 2017-02-27 05:34:10 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:10 --> Input Class Initialized
INFO - 2017-02-27 05:34:10 --> Language Class Initialized
INFO - 2017-02-27 05:34:10 --> Language Class Initialized
INFO - 2017-02-27 05:34:10 --> Config Class Initialized
INFO - 2017-02-27 05:34:10 --> Loader Class Initialized
INFO - 2017-02-27 05:34:10 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:10 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:10 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:10 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:10 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:10 --> Template Class Initialized
INFO - 2017-02-27 05:34:10 --> Model Class Initialized
INFO - 2017-02-27 05:34:10 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:10 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:34:10 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:34:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:34:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:34:12 --> Config Class Initialized
INFO - 2017-02-27 05:34:12 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:12 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:12 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:12 --> URI Class Initialized
INFO - 2017-02-27 05:34:12 --> Router Class Initialized
INFO - 2017-02-27 05:34:12 --> Output Class Initialized
INFO - 2017-02-27 05:34:12 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:12 --> Input Class Initialized
INFO - 2017-02-27 05:34:12 --> Language Class Initialized
INFO - 2017-02-27 05:34:12 --> Language Class Initialized
INFO - 2017-02-27 05:34:12 --> Config Class Initialized
INFO - 2017-02-27 05:34:12 --> Loader Class Initialized
INFO - 2017-02-27 05:34:12 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:12 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:12 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:12 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:12 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:12 --> Template Class Initialized
INFO - 2017-02-27 05:34:12 --> Model Class Initialized
INFO - 2017-02-27 05:34:12 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:12 --> Setting MX_Controller Initialized
INFO - 2017-02-27 05:34:12 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:34:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 05:34:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-02-27 05:34:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 05:34:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/payment_details.php
DEBUG - 2017-02-27 05:34:12 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 05:34:12 --> Final output sent to browser
DEBUG - 2017-02-27 05:34:12 --> Total execution time: 0.0213
INFO - 2017-02-27 05:34:13 --> Config Class Initialized
INFO - 2017-02-27 05:34:13 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:13 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:13 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:13 --> URI Class Initialized
INFO - 2017-02-27 05:34:13 --> Router Class Initialized
INFO - 2017-02-27 05:34:13 --> Output Class Initialized
INFO - 2017-02-27 05:34:13 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:13 --> Input Class Initialized
INFO - 2017-02-27 05:34:13 --> Language Class Initialized
INFO - 2017-02-27 05:34:13 --> Language Class Initialized
INFO - 2017-02-27 05:34:13 --> Config Class Initialized
INFO - 2017-02-27 05:34:13 --> Loader Class Initialized
INFO - 2017-02-27 05:34:13 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:13 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:13 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:13 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:13 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:13 --> Template Class Initialized
INFO - 2017-02-27 05:34:13 --> Model Class Initialized
INFO - 2017-02-27 05:34:13 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:13 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:34:13 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:34:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:34:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:34:14 --> Config Class Initialized
INFO - 2017-02-27 05:34:14 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:14 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:14 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:14 --> URI Class Initialized
INFO - 2017-02-27 05:34:14 --> Router Class Initialized
INFO - 2017-02-27 05:34:14 --> Output Class Initialized
INFO - 2017-02-27 05:34:14 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:14 --> Input Class Initialized
INFO - 2017-02-27 05:34:14 --> Language Class Initialized
INFO - 2017-02-27 05:34:14 --> Language Class Initialized
INFO - 2017-02-27 05:34:14 --> Config Class Initialized
INFO - 2017-02-27 05:34:14 --> Loader Class Initialized
INFO - 2017-02-27 05:34:14 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:14 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:14 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:14 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:14 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:14 --> Template Class Initialized
INFO - 2017-02-27 05:34:14 --> Model Class Initialized
INFO - 2017-02-27 05:34:14 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:14 --> Setting MX_Controller Initialized
INFO - 2017-02-27 05:34:14 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:34:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 05:34:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-02-27 05:34:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 05:34:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/sync_with_card.php
DEBUG - 2017-02-27 05:34:14 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 05:34:14 --> Final output sent to browser
DEBUG - 2017-02-27 05:34:14 --> Total execution time: 0.0213
INFO - 2017-02-27 05:34:14 --> Config Class Initialized
INFO - 2017-02-27 05:34:14 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:14 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:14 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:14 --> URI Class Initialized
INFO - 2017-02-27 05:34:14 --> Router Class Initialized
INFO - 2017-02-27 05:34:14 --> Output Class Initialized
INFO - 2017-02-27 05:34:14 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:14 --> Input Class Initialized
INFO - 2017-02-27 05:34:14 --> Language Class Initialized
INFO - 2017-02-27 05:34:14 --> Language Class Initialized
INFO - 2017-02-27 05:34:14 --> Config Class Initialized
INFO - 2017-02-27 05:34:14 --> Loader Class Initialized
INFO - 2017-02-27 05:34:14 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:14 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:14 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:14 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:14 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:14 --> Template Class Initialized
INFO - 2017-02-27 05:34:14 --> Model Class Initialized
INFO - 2017-02-27 05:34:14 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:14 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:34:14 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:34:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:34:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:34:16 --> Config Class Initialized
INFO - 2017-02-27 05:34:16 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:16 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:16 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:16 --> URI Class Initialized
INFO - 2017-02-27 05:34:16 --> Router Class Initialized
INFO - 2017-02-27 05:34:16 --> Output Class Initialized
INFO - 2017-02-27 05:34:16 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:16 --> Input Class Initialized
INFO - 2017-02-27 05:34:16 --> Language Class Initialized
INFO - 2017-02-27 05:34:16 --> Language Class Initialized
INFO - 2017-02-27 05:34:16 --> Config Class Initialized
INFO - 2017-02-27 05:34:16 --> Loader Class Initialized
INFO - 2017-02-27 05:34:16 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:16 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:16 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:16 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:16 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:16 --> Template Class Initialized
INFO - 2017-02-27 05:34:16 --> Model Class Initialized
INFO - 2017-02-27 05:34:16 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:16 --> Dashboard MX_Controller Initialized
INFO - 2017-02-27 05:34:16 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:34:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 05:34:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-02-27 05:34:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 05:34:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-02-27 05:34:16 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 05:34:16 --> Final output sent to browser
DEBUG - 2017-02-27 05:34:16 --> Total execution time: 0.0154
INFO - 2017-02-27 05:34:16 --> Config Class Initialized
INFO - 2017-02-27 05:34:16 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:16 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:16 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:16 --> URI Class Initialized
INFO - 2017-02-27 05:34:16 --> Router Class Initialized
INFO - 2017-02-27 05:34:16 --> Output Class Initialized
INFO - 2017-02-27 05:34:16 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:16 --> Input Class Initialized
INFO - 2017-02-27 05:34:16 --> Language Class Initialized
INFO - 2017-02-27 05:34:16 --> Language Class Initialized
INFO - 2017-02-27 05:34:16 --> Config Class Initialized
INFO - 2017-02-27 05:34:16 --> Loader Class Initialized
INFO - 2017-02-27 05:34:16 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:16 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:16 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:16 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:16 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:16 --> Template Class Initialized
INFO - 2017-02-27 05:34:16 --> Model Class Initialized
INFO - 2017-02-27 05:34:16 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:16 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:34:16 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:34:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:34:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:34:26 --> Config Class Initialized
INFO - 2017-02-27 05:34:26 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:26 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:26 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:26 --> URI Class Initialized
INFO - 2017-02-27 05:34:26 --> Router Class Initialized
INFO - 2017-02-27 05:34:26 --> Output Class Initialized
INFO - 2017-02-27 05:34:26 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:26 --> Input Class Initialized
INFO - 2017-02-27 05:34:26 --> Language Class Initialized
INFO - 2017-02-27 05:34:26 --> Language Class Initialized
INFO - 2017-02-27 05:34:26 --> Config Class Initialized
INFO - 2017-02-27 05:34:26 --> Loader Class Initialized
INFO - 2017-02-27 05:34:26 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:26 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:26 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:26 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:26 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:26 --> Template Class Initialized
INFO - 2017-02-27 05:34:26 --> Model Class Initialized
INFO - 2017-02-27 05:34:26 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:26 --> Login MX_Controller Initialized
INFO - 2017-02-27 05:34:26 --> Helper loaded: cookie_helper
INFO - 2017-02-27 05:34:26 --> Form Validation Class Initialized
INFO - 2017-02-27 05:34:26 --> Config Class Initialized
INFO - 2017-02-27 05:34:26 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:26 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:26 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:26 --> URI Class Initialized
DEBUG - 2017-02-27 05:34:26 --> No URI present. Default controller set.
INFO - 2017-02-27 05:34:26 --> Router Class Initialized
INFO - 2017-02-27 05:34:26 --> Output Class Initialized
INFO - 2017-02-27 05:34:26 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:26 --> Input Class Initialized
INFO - 2017-02-27 05:34:26 --> Language Class Initialized
INFO - 2017-02-27 05:34:26 --> Language Class Initialized
INFO - 2017-02-27 05:34:26 --> Config Class Initialized
INFO - 2017-02-27 05:34:26 --> Loader Class Initialized
INFO - 2017-02-27 05:34:26 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:26 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:26 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:26 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:26 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:26 --> Template Class Initialized
INFO - 2017-02-27 05:34:26 --> Model Class Initialized
INFO - 2017-02-27 05:34:26 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:26 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:34:26 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:34:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:34:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 05:34:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-27 05:34:26 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 05:34:26 --> Final output sent to browser
DEBUG - 2017-02-27 05:34:26 --> Total execution time: 0.0163
INFO - 2017-02-27 05:34:26 --> Config Class Initialized
INFO - 2017-02-27 05:34:26 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:26 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:26 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:26 --> URI Class Initialized
INFO - 2017-02-27 05:34:26 --> Router Class Initialized
INFO - 2017-02-27 05:34:26 --> Output Class Initialized
INFO - 2017-02-27 05:34:26 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:26 --> Input Class Initialized
INFO - 2017-02-27 05:34:26 --> Language Class Initialized
INFO - 2017-02-27 05:34:26 --> Language Class Initialized
INFO - 2017-02-27 05:34:26 --> Config Class Initialized
INFO - 2017-02-27 05:34:26 --> Loader Class Initialized
INFO - 2017-02-27 05:34:26 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:26 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:26 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:26 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:26 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:26 --> Template Class Initialized
INFO - 2017-02-27 05:34:26 --> Model Class Initialized
INFO - 2017-02-27 05:34:26 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:26 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:34:26 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:34:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:34:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:34:26 --> Config Class Initialized
INFO - 2017-02-27 05:34:26 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:26 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:26 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:26 --> URI Class Initialized
INFO - 2017-02-27 05:34:26 --> Router Class Initialized
INFO - 2017-02-27 05:34:26 --> Output Class Initialized
INFO - 2017-02-27 05:34:26 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:26 --> Input Class Initialized
INFO - 2017-02-27 05:34:26 --> Language Class Initialized
INFO - 2017-02-27 05:34:26 --> Language Class Initialized
INFO - 2017-02-27 05:34:26 --> Config Class Initialized
INFO - 2017-02-27 05:34:26 --> Loader Class Initialized
INFO - 2017-02-27 05:34:26 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:26 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:26 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:26 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:26 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:26 --> Template Class Initialized
INFO - 2017-02-27 05:34:26 --> Model Class Initialized
INFO - 2017-02-27 05:34:26 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:26 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:34:26 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:34:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:34:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:34:27 --> Config Class Initialized
INFO - 2017-02-27 05:34:27 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:34:27 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:34:27 --> Utf8 Class Initialized
INFO - 2017-02-27 05:34:27 --> URI Class Initialized
INFO - 2017-02-27 05:34:27 --> Router Class Initialized
INFO - 2017-02-27 05:34:27 --> Output Class Initialized
INFO - 2017-02-27 05:34:27 --> Security Class Initialized
DEBUG - 2017-02-27 05:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:34:27 --> Input Class Initialized
INFO - 2017-02-27 05:34:27 --> Language Class Initialized
INFO - 2017-02-27 05:34:27 --> Language Class Initialized
INFO - 2017-02-27 05:34:27 --> Config Class Initialized
INFO - 2017-02-27 05:34:27 --> Loader Class Initialized
INFO - 2017-02-27 05:34:27 --> Helper loaded: form_helper
INFO - 2017-02-27 05:34:27 --> Helper loaded: url_helper
INFO - 2017-02-27 05:34:27 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:34:27 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:34:27 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:34:27 --> Template Class Initialized
INFO - 2017-02-27 05:34:27 --> Model Class Initialized
INFO - 2017-02-27 05:34:27 --> Controller Class Initialized
DEBUG - 2017-02-27 05:34:27 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:34:27 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:34:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:34:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:44:51 --> Config Class Initialized
INFO - 2017-02-27 05:44:51 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:44:51 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:44:51 --> Utf8 Class Initialized
INFO - 2017-02-27 05:44:51 --> URI Class Initialized
DEBUG - 2017-02-27 05:44:51 --> No URI present. Default controller set.
INFO - 2017-02-27 05:44:51 --> Router Class Initialized
INFO - 2017-02-27 05:44:51 --> Output Class Initialized
INFO - 2017-02-27 05:44:51 --> Security Class Initialized
DEBUG - 2017-02-27 05:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:44:51 --> Input Class Initialized
INFO - 2017-02-27 05:44:51 --> Language Class Initialized
INFO - 2017-02-27 05:44:51 --> Language Class Initialized
INFO - 2017-02-27 05:44:51 --> Config Class Initialized
INFO - 2017-02-27 05:44:51 --> Loader Class Initialized
INFO - 2017-02-27 05:44:51 --> Helper loaded: form_helper
INFO - 2017-02-27 05:44:51 --> Helper loaded: url_helper
INFO - 2017-02-27 05:44:51 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:44:51 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:44:51 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:44:51 --> Template Class Initialized
INFO - 2017-02-27 05:44:51 --> Model Class Initialized
INFO - 2017-02-27 05:44:51 --> Controller Class Initialized
DEBUG - 2017-02-27 05:44:51 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:44:51 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:44:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:44:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 05:44:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-27 05:44:51 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 05:44:51 --> Final output sent to browser
DEBUG - 2017-02-27 05:44:51 --> Total execution time: 0.0575
INFO - 2017-02-27 05:44:52 --> Config Class Initialized
INFO - 2017-02-27 05:44:52 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:44:52 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:44:52 --> Utf8 Class Initialized
INFO - 2017-02-27 05:44:52 --> URI Class Initialized
INFO - 2017-02-27 05:44:52 --> Router Class Initialized
INFO - 2017-02-27 05:44:52 --> Output Class Initialized
INFO - 2017-02-27 05:44:52 --> Security Class Initialized
DEBUG - 2017-02-27 05:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:44:52 --> Input Class Initialized
INFO - 2017-02-27 05:44:52 --> Language Class Initialized
INFO - 2017-02-27 05:44:52 --> Language Class Initialized
INFO - 2017-02-27 05:44:52 --> Config Class Initialized
INFO - 2017-02-27 05:44:52 --> Loader Class Initialized
INFO - 2017-02-27 05:44:52 --> Helper loaded: form_helper
INFO - 2017-02-27 05:44:52 --> Helper loaded: url_helper
INFO - 2017-02-27 05:44:52 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:44:52 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:44:52 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:44:52 --> Template Class Initialized
INFO - 2017-02-27 05:44:52 --> Model Class Initialized
INFO - 2017-02-27 05:44:52 --> Controller Class Initialized
DEBUG - 2017-02-27 05:44:52 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:44:52 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:44:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:44:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:44:52 --> Config Class Initialized
INFO - 2017-02-27 05:44:52 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:44:52 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:44:52 --> Utf8 Class Initialized
INFO - 2017-02-27 05:44:52 --> URI Class Initialized
INFO - 2017-02-27 05:44:52 --> Router Class Initialized
INFO - 2017-02-27 05:44:52 --> Output Class Initialized
INFO - 2017-02-27 05:44:52 --> Security Class Initialized
DEBUG - 2017-02-27 05:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:44:52 --> Input Class Initialized
INFO - 2017-02-27 05:44:52 --> Language Class Initialized
INFO - 2017-02-27 05:44:52 --> Language Class Initialized
INFO - 2017-02-27 05:44:52 --> Config Class Initialized
INFO - 2017-02-27 05:44:52 --> Loader Class Initialized
INFO - 2017-02-27 05:44:52 --> Helper loaded: form_helper
INFO - 2017-02-27 05:44:52 --> Helper loaded: url_helper
INFO - 2017-02-27 05:44:52 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:44:52 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:44:52 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:44:52 --> Template Class Initialized
INFO - 2017-02-27 05:44:52 --> Model Class Initialized
INFO - 2017-02-27 05:44:52 --> Controller Class Initialized
DEBUG - 2017-02-27 05:44:52 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:44:52 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:44:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:44:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:44:53 --> Config Class Initialized
INFO - 2017-02-27 05:44:53 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:44:53 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:44:53 --> Utf8 Class Initialized
INFO - 2017-02-27 05:44:53 --> URI Class Initialized
INFO - 2017-02-27 05:44:53 --> Router Class Initialized
INFO - 2017-02-27 05:44:53 --> Output Class Initialized
INFO - 2017-02-27 05:44:53 --> Security Class Initialized
DEBUG - 2017-02-27 05:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:44:53 --> Input Class Initialized
INFO - 2017-02-27 05:44:53 --> Language Class Initialized
INFO - 2017-02-27 05:44:53 --> Language Class Initialized
INFO - 2017-02-27 05:44:53 --> Config Class Initialized
INFO - 2017-02-27 05:44:53 --> Loader Class Initialized
INFO - 2017-02-27 05:44:53 --> Helper loaded: form_helper
INFO - 2017-02-27 05:44:53 --> Helper loaded: url_helper
INFO - 2017-02-27 05:44:53 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:44:53 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:44:53 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:44:53 --> Template Class Initialized
INFO - 2017-02-27 05:44:53 --> Model Class Initialized
INFO - 2017-02-27 05:44:53 --> Controller Class Initialized
DEBUG - 2017-02-27 05:44:53 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:44:53 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:44:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:44:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:44:54 --> Config Class Initialized
INFO - 2017-02-27 05:44:54 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:44:54 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:44:54 --> Utf8 Class Initialized
INFO - 2017-02-27 05:44:54 --> URI Class Initialized
INFO - 2017-02-27 05:44:54 --> Router Class Initialized
INFO - 2017-02-27 05:44:54 --> Output Class Initialized
INFO - 2017-02-27 05:44:54 --> Security Class Initialized
DEBUG - 2017-02-27 05:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:44:54 --> Input Class Initialized
INFO - 2017-02-27 05:44:54 --> Language Class Initialized
INFO - 2017-02-27 05:44:54 --> Language Class Initialized
INFO - 2017-02-27 05:44:54 --> Config Class Initialized
INFO - 2017-02-27 05:44:54 --> Loader Class Initialized
INFO - 2017-02-27 05:44:54 --> Helper loaded: form_helper
INFO - 2017-02-27 05:44:54 --> Helper loaded: url_helper
INFO - 2017-02-27 05:44:54 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:44:54 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:44:54 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:44:54 --> Template Class Initialized
INFO - 2017-02-27 05:44:54 --> Model Class Initialized
INFO - 2017-02-27 05:44:54 --> Controller Class Initialized
DEBUG - 2017-02-27 05:44:54 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:44:54 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:44:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:44:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 05:44:54 --> Config Class Initialized
INFO - 2017-02-27 05:44:54 --> Hooks Class Initialized
DEBUG - 2017-02-27 05:44:54 --> UTF-8 Support Enabled
INFO - 2017-02-27 05:44:54 --> Utf8 Class Initialized
INFO - 2017-02-27 05:44:54 --> URI Class Initialized
INFO - 2017-02-27 05:44:54 --> Router Class Initialized
INFO - 2017-02-27 05:44:54 --> Output Class Initialized
INFO - 2017-02-27 05:44:54 --> Security Class Initialized
DEBUG - 2017-02-27 05:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 05:44:54 --> Input Class Initialized
INFO - 2017-02-27 05:44:54 --> Language Class Initialized
INFO - 2017-02-27 05:44:54 --> Language Class Initialized
INFO - 2017-02-27 05:44:54 --> Config Class Initialized
INFO - 2017-02-27 05:44:54 --> Loader Class Initialized
INFO - 2017-02-27 05:44:54 --> Helper loaded: form_helper
INFO - 2017-02-27 05:44:54 --> Helper loaded: url_helper
INFO - 2017-02-27 05:44:54 --> Helper loaded: utility_helper
INFO - 2017-02-27 05:44:54 --> Database Driver Class Initialized
DEBUG - 2017-02-27 05:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 05:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 05:44:54 --> User Agent Class Initialized
DEBUG - 2017-02-27 05:44:54 --> Template Class Initialized
INFO - 2017-02-27 05:44:54 --> Model Class Initialized
INFO - 2017-02-27 05:44:54 --> Controller Class Initialized
DEBUG - 2017-02-27 05:44:54 --> Pages MX_Controller Initialized
INFO - 2017-02-27 05:44:54 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 05:44:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 05:44:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 06:55:07 --> Config Class Initialized
INFO - 2017-02-27 06:55:07 --> Hooks Class Initialized
DEBUG - 2017-02-27 06:55:07 --> UTF-8 Support Enabled
INFO - 2017-02-27 06:55:07 --> Utf8 Class Initialized
INFO - 2017-02-27 06:55:07 --> URI Class Initialized
INFO - 2017-02-27 06:55:07 --> Router Class Initialized
INFO - 2017-02-27 06:55:07 --> Output Class Initialized
INFO - 2017-02-27 06:55:07 --> Security Class Initialized
DEBUG - 2017-02-27 06:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 06:55:07 --> Input Class Initialized
INFO - 2017-02-27 06:55:07 --> Language Class Initialized
INFO - 2017-02-27 06:55:07 --> Language Class Initialized
INFO - 2017-02-27 06:55:07 --> Config Class Initialized
INFO - 2017-02-27 06:55:07 --> Loader Class Initialized
INFO - 2017-02-27 06:55:07 --> Helper loaded: form_helper
INFO - 2017-02-27 06:55:07 --> Helper loaded: url_helper
INFO - 2017-02-27 06:55:07 --> Helper loaded: utility_helper
INFO - 2017-02-27 06:55:07 --> Database Driver Class Initialized
DEBUG - 2017-02-27 06:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 06:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 06:55:07 --> User Agent Class Initialized
DEBUG - 2017-02-27 06:55:07 --> Template Class Initialized
INFO - 2017-02-27 06:55:07 --> Model Class Initialized
INFO - 2017-02-27 06:55:07 --> Controller Class Initialized
DEBUG - 2017-02-27 06:55:07 --> Pages MX_Controller Initialized
INFO - 2017-02-27 06:55:07 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 06:55:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 06:55:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 07:48:02 --> Config Class Initialized
INFO - 2017-02-27 07:48:02 --> Hooks Class Initialized
DEBUG - 2017-02-27 07:48:02 --> UTF-8 Support Enabled
INFO - 2017-02-27 07:48:02 --> Utf8 Class Initialized
INFO - 2017-02-27 07:48:02 --> URI Class Initialized
DEBUG - 2017-02-27 07:48:02 --> No URI present. Default controller set.
INFO - 2017-02-27 07:48:02 --> Router Class Initialized
INFO - 2017-02-27 07:48:02 --> Output Class Initialized
INFO - 2017-02-27 07:48:02 --> Security Class Initialized
DEBUG - 2017-02-27 07:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 07:48:02 --> Input Class Initialized
INFO - 2017-02-27 07:48:02 --> Language Class Initialized
INFO - 2017-02-27 07:48:02 --> Language Class Initialized
INFO - 2017-02-27 07:48:02 --> Config Class Initialized
INFO - 2017-02-27 07:48:02 --> Loader Class Initialized
INFO - 2017-02-27 07:48:02 --> Helper loaded: form_helper
INFO - 2017-02-27 07:48:02 --> Helper loaded: url_helper
INFO - 2017-02-27 07:48:02 --> Helper loaded: utility_helper
INFO - 2017-02-27 07:48:02 --> Database Driver Class Initialized
DEBUG - 2017-02-27 07:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 07:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 07:48:02 --> User Agent Class Initialized
DEBUG - 2017-02-27 07:48:02 --> Template Class Initialized
INFO - 2017-02-27 07:48:02 --> Model Class Initialized
INFO - 2017-02-27 07:48:02 --> Controller Class Initialized
DEBUG - 2017-02-27 07:48:02 --> Pages MX_Controller Initialized
INFO - 2017-02-27 07:48:02 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 07:48:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 07:48:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 07:48:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-27 07:48:02 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 07:48:02 --> Final output sent to browser
DEBUG - 2017-02-27 07:48:02 --> Total execution time: 0.2179
INFO - 2017-02-27 08:59:03 --> Config Class Initialized
INFO - 2017-02-27 08:59:03 --> Hooks Class Initialized
DEBUG - 2017-02-27 08:59:03 --> UTF-8 Support Enabled
INFO - 2017-02-27 08:59:03 --> Utf8 Class Initialized
INFO - 2017-02-27 08:59:03 --> URI Class Initialized
INFO - 2017-02-27 08:59:03 --> Router Class Initialized
INFO - 2017-02-27 08:59:03 --> Output Class Initialized
INFO - 2017-02-27 08:59:03 --> Security Class Initialized
DEBUG - 2017-02-27 08:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 08:59:03 --> Input Class Initialized
INFO - 2017-02-27 08:59:03 --> Language Class Initialized
INFO - 2017-02-27 08:59:03 --> Language Class Initialized
INFO - 2017-02-27 08:59:03 --> Config Class Initialized
INFO - 2017-02-27 08:59:03 --> Loader Class Initialized
INFO - 2017-02-27 08:59:03 --> Helper loaded: form_helper
INFO - 2017-02-27 08:59:03 --> Helper loaded: url_helper
INFO - 2017-02-27 08:59:03 --> Helper loaded: utility_helper
INFO - 2017-02-27 08:59:03 --> Database Driver Class Initialized
DEBUG - 2017-02-27 08:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 08:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 08:59:03 --> User Agent Class Initialized
DEBUG - 2017-02-27 08:59:03 --> Template Class Initialized
INFO - 2017-02-27 08:59:03 --> Model Class Initialized
INFO - 2017-02-27 08:59:03 --> Controller Class Initialized
DEBUG - 2017-02-27 08:59:03 --> Pages MX_Controller Initialized
INFO - 2017-02-27 08:59:03 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 08:59:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 08:59:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 17:36:01 --> Config Class Initialized
INFO - 2017-02-27 17:36:01 --> Hooks Class Initialized
DEBUG - 2017-02-27 17:36:01 --> UTF-8 Support Enabled
INFO - 2017-02-27 17:36:01 --> Utf8 Class Initialized
INFO - 2017-02-27 17:36:01 --> URI Class Initialized
INFO - 2017-02-27 17:36:01 --> Router Class Initialized
INFO - 2017-02-27 17:36:01 --> Output Class Initialized
INFO - 2017-02-27 17:36:01 --> Security Class Initialized
DEBUG - 2017-02-27 17:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 17:36:01 --> Input Class Initialized
INFO - 2017-02-27 17:36:01 --> Language Class Initialized
INFO - 2017-02-27 17:36:01 --> Language Class Initialized
INFO - 2017-02-27 17:36:01 --> Config Class Initialized
INFO - 2017-02-27 17:36:01 --> Loader Class Initialized
INFO - 2017-02-27 17:36:01 --> Helper loaded: form_helper
INFO - 2017-02-27 17:36:01 --> Helper loaded: url_helper
INFO - 2017-02-27 17:36:01 --> Helper loaded: utility_helper
INFO - 2017-02-27 17:36:01 --> Database Driver Class Initialized
DEBUG - 2017-02-27 17:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 17:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 17:36:02 --> User Agent Class Initialized
DEBUG - 2017-02-27 17:36:02 --> Template Class Initialized
INFO - 2017-02-27 17:36:02 --> Model Class Initialized
INFO - 2017-02-27 17:36:02 --> Controller Class Initialized
DEBUG - 2017-02-27 17:36:02 --> Pages MX_Controller Initialized
INFO - 2017-02-27 17:36:02 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 17:36:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 17:36:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 17:36:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-02-27 17:36:02 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 17:36:02 --> Final output sent to browser
DEBUG - 2017-02-27 17:36:02 --> Total execution time: 0.2406
INFO - 2017-02-27 17:36:03 --> Config Class Initialized
INFO - 2017-02-27 17:36:03 --> Hooks Class Initialized
DEBUG - 2017-02-27 17:36:03 --> UTF-8 Support Enabled
INFO - 2017-02-27 17:36:03 --> Utf8 Class Initialized
INFO - 2017-02-27 17:36:03 --> URI Class Initialized
INFO - 2017-02-27 17:36:03 --> Router Class Initialized
INFO - 2017-02-27 17:36:03 --> Output Class Initialized
INFO - 2017-02-27 17:36:05 --> Security Class Initialized
DEBUG - 2017-02-27 17:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 17:36:05 --> Input Class Initialized
INFO - 2017-02-27 17:36:05 --> Language Class Initialized
INFO - 2017-02-27 17:36:05 --> Language Class Initialized
INFO - 2017-02-27 17:36:05 --> Config Class Initialized
INFO - 2017-02-27 17:36:05 --> Loader Class Initialized
INFO - 2017-02-27 17:36:05 --> Helper loaded: form_helper
INFO - 2017-02-27 17:36:05 --> Helper loaded: url_helper
INFO - 2017-02-27 17:36:05 --> Helper loaded: utility_helper
INFO - 2017-02-27 17:36:05 --> Database Driver Class Initialized
DEBUG - 2017-02-27 17:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 17:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 17:36:05 --> User Agent Class Initialized
DEBUG - 2017-02-27 17:36:05 --> Template Class Initialized
INFO - 2017-02-27 17:36:05 --> Model Class Initialized
INFO - 2017-02-27 17:36:05 --> Controller Class Initialized
DEBUG - 2017-02-27 17:36:05 --> Pages MX_Controller Initialized
INFO - 2017-02-27 17:36:05 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 17:36:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 17:36:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:03:08 --> Config Class Initialized
INFO - 2017-02-27 18:03:08 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:03:08 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:03:08 --> Utf8 Class Initialized
INFO - 2017-02-27 18:03:08 --> URI Class Initialized
DEBUG - 2017-02-27 18:03:08 --> No URI present. Default controller set.
INFO - 2017-02-27 18:03:08 --> Router Class Initialized
INFO - 2017-02-27 18:03:08 --> Output Class Initialized
INFO - 2017-02-27 18:03:08 --> Security Class Initialized
DEBUG - 2017-02-27 18:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:03:08 --> Input Class Initialized
INFO - 2017-02-27 18:03:08 --> Language Class Initialized
INFO - 2017-02-27 18:03:08 --> Language Class Initialized
INFO - 2017-02-27 18:03:08 --> Config Class Initialized
INFO - 2017-02-27 18:03:08 --> Loader Class Initialized
INFO - 2017-02-27 18:03:08 --> Helper loaded: form_helper
INFO - 2017-02-27 18:03:08 --> Helper loaded: url_helper
INFO - 2017-02-27 18:03:08 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:03:08 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:03:08 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:03:08 --> Template Class Initialized
INFO - 2017-02-27 18:03:08 --> Model Class Initialized
INFO - 2017-02-27 18:03:08 --> Controller Class Initialized
DEBUG - 2017-02-27 18:03:08 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:03:08 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:03:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:03:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 18:03:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-27 18:03:08 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 18:03:08 --> Final output sent to browser
DEBUG - 2017-02-27 18:03:08 --> Total execution time: 0.0634
INFO - 2017-02-27 18:03:11 --> Config Class Initialized
INFO - 2017-02-27 18:03:11 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:03:11 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:03:11 --> Utf8 Class Initialized
INFO - 2017-02-27 18:03:11 --> URI Class Initialized
INFO - 2017-02-27 18:03:11 --> Router Class Initialized
INFO - 2017-02-27 18:03:11 --> Output Class Initialized
INFO - 2017-02-27 18:03:11 --> Security Class Initialized
DEBUG - 2017-02-27 18:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:03:11 --> Input Class Initialized
INFO - 2017-02-27 18:03:11 --> Language Class Initialized
INFO - 2017-02-27 18:03:11 --> Language Class Initialized
INFO - 2017-02-27 18:03:11 --> Config Class Initialized
INFO - 2017-02-27 18:03:11 --> Loader Class Initialized
INFO - 2017-02-27 18:03:11 --> Helper loaded: form_helper
INFO - 2017-02-27 18:03:11 --> Helper loaded: url_helper
INFO - 2017-02-27 18:03:11 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:03:11 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:03:11 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:03:11 --> Template Class Initialized
INFO - 2017-02-27 18:03:11 --> Model Class Initialized
INFO - 2017-02-27 18:03:11 --> Controller Class Initialized
DEBUG - 2017-02-27 18:03:11 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:03:11 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:03:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:03:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:03:12 --> Config Class Initialized
INFO - 2017-02-27 18:03:12 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:03:12 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:03:12 --> Utf8 Class Initialized
INFO - 2017-02-27 18:03:12 --> URI Class Initialized
INFO - 2017-02-27 18:03:12 --> Router Class Initialized
INFO - 2017-02-27 18:03:12 --> Output Class Initialized
INFO - 2017-02-27 18:03:12 --> Security Class Initialized
DEBUG - 2017-02-27 18:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:03:12 --> Input Class Initialized
INFO - 2017-02-27 18:03:12 --> Language Class Initialized
INFO - 2017-02-27 18:03:12 --> Language Class Initialized
INFO - 2017-02-27 18:03:12 --> Config Class Initialized
INFO - 2017-02-27 18:03:12 --> Loader Class Initialized
INFO - 2017-02-27 18:03:12 --> Helper loaded: form_helper
INFO - 2017-02-27 18:03:12 --> Helper loaded: url_helper
INFO - 2017-02-27 18:03:12 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:03:12 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:03:12 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:03:12 --> Template Class Initialized
INFO - 2017-02-27 18:03:12 --> Model Class Initialized
INFO - 2017-02-27 18:03:12 --> Controller Class Initialized
DEBUG - 2017-02-27 18:03:12 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:03:12 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:03:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:03:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:03:13 --> Config Class Initialized
INFO - 2017-02-27 18:03:13 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:03:13 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:03:13 --> Utf8 Class Initialized
INFO - 2017-02-27 18:03:13 --> URI Class Initialized
INFO - 2017-02-27 18:03:13 --> Router Class Initialized
INFO - 2017-02-27 18:03:13 --> Output Class Initialized
INFO - 2017-02-27 18:03:13 --> Security Class Initialized
DEBUG - 2017-02-27 18:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:03:13 --> Input Class Initialized
INFO - 2017-02-27 18:03:13 --> Language Class Initialized
INFO - 2017-02-27 18:03:13 --> Language Class Initialized
INFO - 2017-02-27 18:03:13 --> Config Class Initialized
INFO - 2017-02-27 18:03:13 --> Loader Class Initialized
INFO - 2017-02-27 18:03:13 --> Helper loaded: form_helper
INFO - 2017-02-27 18:03:13 --> Helper loaded: url_helper
INFO - 2017-02-27 18:03:13 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:03:13 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:03:13 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:03:13 --> Template Class Initialized
INFO - 2017-02-27 18:03:13 --> Model Class Initialized
INFO - 2017-02-27 18:03:13 --> Controller Class Initialized
DEBUG - 2017-02-27 18:03:13 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:03:13 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:03:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:03:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:03:25 --> Config Class Initialized
INFO - 2017-02-27 18:03:25 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:03:25 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:03:25 --> Utf8 Class Initialized
INFO - 2017-02-27 18:03:25 --> URI Class Initialized
INFO - 2017-02-27 18:03:25 --> Router Class Initialized
INFO - 2017-02-27 18:03:25 --> Output Class Initialized
INFO - 2017-02-27 18:03:25 --> Security Class Initialized
DEBUG - 2017-02-27 18:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:03:25 --> Input Class Initialized
INFO - 2017-02-27 18:03:25 --> Language Class Initialized
INFO - 2017-02-27 18:03:25 --> Language Class Initialized
INFO - 2017-02-27 18:03:25 --> Config Class Initialized
INFO - 2017-02-27 18:03:25 --> Loader Class Initialized
INFO - 2017-02-27 18:03:25 --> Helper loaded: form_helper
INFO - 2017-02-27 18:03:25 --> Helper loaded: url_helper
INFO - 2017-02-27 18:03:25 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:03:25 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:03:25 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:03:25 --> Template Class Initialized
INFO - 2017-02-27 18:03:25 --> Model Class Initialized
INFO - 2017-02-27 18:03:25 --> Controller Class Initialized
DEBUG - 2017-02-27 18:03:25 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:03:25 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:03:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:03:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:04:33 --> Config Class Initialized
INFO - 2017-02-27 18:04:33 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:04:33 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:04:33 --> Utf8 Class Initialized
INFO - 2017-02-27 18:04:33 --> URI Class Initialized
INFO - 2017-02-27 18:04:33 --> Router Class Initialized
INFO - 2017-02-27 18:04:33 --> Output Class Initialized
INFO - 2017-02-27 18:04:33 --> Security Class Initialized
DEBUG - 2017-02-27 18:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:04:33 --> Input Class Initialized
INFO - 2017-02-27 18:04:33 --> Language Class Initialized
INFO - 2017-02-27 18:04:33 --> Language Class Initialized
INFO - 2017-02-27 18:04:33 --> Config Class Initialized
INFO - 2017-02-27 18:04:33 --> Loader Class Initialized
INFO - 2017-02-27 18:04:33 --> Helper loaded: form_helper
INFO - 2017-02-27 18:04:33 --> Helper loaded: url_helper
INFO - 2017-02-27 18:04:33 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:04:33 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:04:33 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:04:33 --> Template Class Initialized
INFO - 2017-02-27 18:04:33 --> Model Class Initialized
INFO - 2017-02-27 18:04:33 --> Controller Class Initialized
DEBUG - 2017-02-27 18:04:33 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:04:33 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:04:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:04:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:04:33 --> Config Class Initialized
INFO - 2017-02-27 18:04:33 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:04:33 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:04:33 --> Utf8 Class Initialized
INFO - 2017-02-27 18:04:33 --> URI Class Initialized
INFO - 2017-02-27 18:04:33 --> Router Class Initialized
INFO - 2017-02-27 18:04:33 --> Output Class Initialized
INFO - 2017-02-27 18:04:33 --> Security Class Initialized
DEBUG - 2017-02-27 18:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:04:33 --> Input Class Initialized
INFO - 2017-02-27 18:04:33 --> Language Class Initialized
INFO - 2017-02-27 18:04:33 --> Language Class Initialized
INFO - 2017-02-27 18:04:33 --> Config Class Initialized
INFO - 2017-02-27 18:04:33 --> Loader Class Initialized
INFO - 2017-02-27 18:04:33 --> Helper loaded: form_helper
INFO - 2017-02-27 18:04:33 --> Helper loaded: url_helper
INFO - 2017-02-27 18:04:33 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:04:33 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:04:33 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:04:33 --> Template Class Initialized
INFO - 2017-02-27 18:04:33 --> Model Class Initialized
INFO - 2017-02-27 18:04:33 --> Controller Class Initialized
DEBUG - 2017-02-27 18:04:33 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:04:33 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:04:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:04:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:04:40 --> Config Class Initialized
INFO - 2017-02-27 18:04:40 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:04:40 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:04:40 --> Utf8 Class Initialized
INFO - 2017-02-27 18:04:40 --> URI Class Initialized
INFO - 2017-02-27 18:04:40 --> Router Class Initialized
INFO - 2017-02-27 18:04:40 --> Output Class Initialized
INFO - 2017-02-27 18:04:40 --> Security Class Initialized
DEBUG - 2017-02-27 18:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:04:40 --> Input Class Initialized
INFO - 2017-02-27 18:04:40 --> Language Class Initialized
INFO - 2017-02-27 18:04:40 --> Language Class Initialized
INFO - 2017-02-27 18:04:40 --> Config Class Initialized
INFO - 2017-02-27 18:04:40 --> Loader Class Initialized
INFO - 2017-02-27 18:04:40 --> Helper loaded: form_helper
INFO - 2017-02-27 18:04:40 --> Helper loaded: url_helper
INFO - 2017-02-27 18:04:40 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:04:40 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:04:40 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:04:40 --> Template Class Initialized
INFO - 2017-02-27 18:04:40 --> Model Class Initialized
INFO - 2017-02-27 18:04:40 --> Controller Class Initialized
DEBUG - 2017-02-27 18:04:40 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:04:40 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:04:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:04:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 18:04:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-02-27 18:04:40 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 18:04:40 --> Final output sent to browser
DEBUG - 2017-02-27 18:04:40 --> Total execution time: 0.0211
INFO - 2017-02-27 18:04:40 --> Config Class Initialized
INFO - 2017-02-27 18:04:40 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:04:40 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:04:40 --> Utf8 Class Initialized
INFO - 2017-02-27 18:04:40 --> URI Class Initialized
INFO - 2017-02-27 18:04:40 --> Router Class Initialized
INFO - 2017-02-27 18:04:40 --> Output Class Initialized
INFO - 2017-02-27 18:04:40 --> Security Class Initialized
DEBUG - 2017-02-27 18:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:04:40 --> Input Class Initialized
INFO - 2017-02-27 18:04:40 --> Language Class Initialized
INFO - 2017-02-27 18:04:40 --> Language Class Initialized
INFO - 2017-02-27 18:04:40 --> Config Class Initialized
INFO - 2017-02-27 18:04:40 --> Loader Class Initialized
INFO - 2017-02-27 18:04:40 --> Helper loaded: form_helper
INFO - 2017-02-27 18:04:40 --> Helper loaded: url_helper
INFO - 2017-02-27 18:04:40 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:04:40 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:04:40 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:04:40 --> Template Class Initialized
INFO - 2017-02-27 18:04:40 --> Model Class Initialized
INFO - 2017-02-27 18:04:40 --> Controller Class Initialized
DEBUG - 2017-02-27 18:04:40 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:04:40 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:04:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:04:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:04:41 --> Config Class Initialized
INFO - 2017-02-27 18:04:41 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:04:41 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:04:41 --> Utf8 Class Initialized
INFO - 2017-02-27 18:04:41 --> URI Class Initialized
INFO - 2017-02-27 18:04:41 --> Router Class Initialized
INFO - 2017-02-27 18:04:41 --> Output Class Initialized
INFO - 2017-02-27 18:04:41 --> Security Class Initialized
DEBUG - 2017-02-27 18:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:04:41 --> Input Class Initialized
INFO - 2017-02-27 18:04:41 --> Language Class Initialized
INFO - 2017-02-27 18:04:41 --> Language Class Initialized
INFO - 2017-02-27 18:04:41 --> Config Class Initialized
INFO - 2017-02-27 18:04:41 --> Loader Class Initialized
INFO - 2017-02-27 18:04:41 --> Helper loaded: form_helper
INFO - 2017-02-27 18:04:41 --> Helper loaded: url_helper
INFO - 2017-02-27 18:04:41 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:04:41 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:04:41 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:04:41 --> Template Class Initialized
INFO - 2017-02-27 18:04:41 --> Model Class Initialized
INFO - 2017-02-27 18:04:41 --> Controller Class Initialized
DEBUG - 2017-02-27 18:04:41 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:04:41 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:04:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:04:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:04:42 --> Config Class Initialized
INFO - 2017-02-27 18:04:42 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:04:42 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:04:42 --> Utf8 Class Initialized
INFO - 2017-02-27 18:04:42 --> URI Class Initialized
INFO - 2017-02-27 18:04:42 --> Router Class Initialized
INFO - 2017-02-27 18:04:42 --> Output Class Initialized
INFO - 2017-02-27 18:04:42 --> Security Class Initialized
DEBUG - 2017-02-27 18:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:04:42 --> Input Class Initialized
INFO - 2017-02-27 18:04:42 --> Language Class Initialized
INFO - 2017-02-27 18:04:42 --> Language Class Initialized
INFO - 2017-02-27 18:04:42 --> Config Class Initialized
INFO - 2017-02-27 18:04:42 --> Loader Class Initialized
INFO - 2017-02-27 18:04:42 --> Helper loaded: form_helper
INFO - 2017-02-27 18:04:42 --> Helper loaded: url_helper
INFO - 2017-02-27 18:04:42 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:04:42 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:04:42 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:04:42 --> Template Class Initialized
INFO - 2017-02-27 18:04:42 --> Model Class Initialized
INFO - 2017-02-27 18:04:42 --> Controller Class Initialized
DEBUG - 2017-02-27 18:04:42 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:04:42 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:04:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:04:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:04:59 --> Config Class Initialized
INFO - 2017-02-27 18:04:59 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:04:59 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:04:59 --> Utf8 Class Initialized
INFO - 2017-02-27 18:04:59 --> URI Class Initialized
INFO - 2017-02-27 18:04:59 --> Router Class Initialized
INFO - 2017-02-27 18:04:59 --> Output Class Initialized
INFO - 2017-02-27 18:04:59 --> Security Class Initialized
DEBUG - 2017-02-27 18:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:04:59 --> Input Class Initialized
INFO - 2017-02-27 18:04:59 --> Language Class Initialized
INFO - 2017-02-27 18:04:59 --> Language Class Initialized
INFO - 2017-02-27 18:04:59 --> Config Class Initialized
INFO - 2017-02-27 18:04:59 --> Loader Class Initialized
INFO - 2017-02-27 18:04:59 --> Helper loaded: form_helper
INFO - 2017-02-27 18:04:59 --> Helper loaded: url_helper
INFO - 2017-02-27 18:04:59 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:04:59 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:04:59 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:04:59 --> Template Class Initialized
INFO - 2017-02-27 18:04:59 --> Model Class Initialized
INFO - 2017-02-27 18:04:59 --> Controller Class Initialized
DEBUG - 2017-02-27 18:04:59 --> Login MX_Controller Initialized
INFO - 2017-02-27 18:04:59 --> Helper loaded: cookie_helper
INFO - 2017-02-27 18:04:59 --> Form Validation Class Initialized
INFO - 2017-02-27 18:04:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-27 18:04:59 --> Config Class Initialized
INFO - 2017-02-27 18:04:59 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:04:59 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:04:59 --> Utf8 Class Initialized
INFO - 2017-02-27 18:04:59 --> URI Class Initialized
INFO - 2017-02-27 18:04:59 --> Router Class Initialized
INFO - 2017-02-27 18:04:59 --> Output Class Initialized
INFO - 2017-02-27 18:04:59 --> Security Class Initialized
DEBUG - 2017-02-27 18:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:04:59 --> Input Class Initialized
INFO - 2017-02-27 18:04:59 --> Language Class Initialized
INFO - 2017-02-27 18:04:59 --> Language Class Initialized
INFO - 2017-02-27 18:04:59 --> Config Class Initialized
INFO - 2017-02-27 18:04:59 --> Loader Class Initialized
INFO - 2017-02-27 18:04:59 --> Helper loaded: form_helper
INFO - 2017-02-27 18:04:59 --> Helper loaded: url_helper
INFO - 2017-02-27 18:04:59 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:04:59 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:04:59 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:04:59 --> Template Class Initialized
INFO - 2017-02-27 18:04:59 --> Model Class Initialized
INFO - 2017-02-27 18:04:59 --> Controller Class Initialized
DEBUG - 2017-02-27 18:04:59 --> Dashboard MX_Controller Initialized
INFO - 2017-02-27 18:04:59 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:04:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 18:04:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-02-27 18:04:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 18:04:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-02-27 18:04:59 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 18:04:59 --> Final output sent to browser
DEBUG - 2017-02-27 18:04:59 --> Total execution time: 0.0617
INFO - 2017-02-27 18:05:11 --> Config Class Initialized
INFO - 2017-02-27 18:05:11 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:05:11 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:05:11 --> Utf8 Class Initialized
INFO - 2017-02-27 18:05:11 --> URI Class Initialized
INFO - 2017-02-27 18:05:11 --> Router Class Initialized
INFO - 2017-02-27 18:05:11 --> Output Class Initialized
INFO - 2017-02-27 18:05:11 --> Security Class Initialized
DEBUG - 2017-02-27 18:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:05:11 --> Input Class Initialized
INFO - 2017-02-27 18:05:11 --> Language Class Initialized
INFO - 2017-02-27 18:05:11 --> Language Class Initialized
INFO - 2017-02-27 18:05:11 --> Config Class Initialized
INFO - 2017-02-27 18:05:11 --> Loader Class Initialized
INFO - 2017-02-27 18:05:11 --> Helper loaded: form_helper
INFO - 2017-02-27 18:05:11 --> Helper loaded: url_helper
INFO - 2017-02-27 18:05:11 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:05:11 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:05:11 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:05:11 --> Template Class Initialized
INFO - 2017-02-27 18:05:11 --> Model Class Initialized
INFO - 2017-02-27 18:05:11 --> Controller Class Initialized
DEBUG - 2017-02-27 18:05:11 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:05:11 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:05:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:05:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:05:56 --> Config Class Initialized
INFO - 2017-02-27 18:05:56 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:05:56 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:05:56 --> Utf8 Class Initialized
INFO - 2017-02-27 18:05:56 --> URI Class Initialized
DEBUG - 2017-02-27 18:05:56 --> No URI present. Default controller set.
INFO - 2017-02-27 18:05:56 --> Router Class Initialized
INFO - 2017-02-27 18:05:56 --> Output Class Initialized
INFO - 2017-02-27 18:05:56 --> Security Class Initialized
DEBUG - 2017-02-27 18:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:05:56 --> Input Class Initialized
INFO - 2017-02-27 18:05:56 --> Language Class Initialized
INFO - 2017-02-27 18:05:56 --> Language Class Initialized
INFO - 2017-02-27 18:05:56 --> Config Class Initialized
INFO - 2017-02-27 18:05:56 --> Loader Class Initialized
INFO - 2017-02-27 18:05:56 --> Helper loaded: form_helper
INFO - 2017-02-27 18:05:56 --> Helper loaded: url_helper
INFO - 2017-02-27 18:05:56 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:05:56 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:05:56 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:05:56 --> Template Class Initialized
INFO - 2017-02-27 18:05:56 --> Model Class Initialized
INFO - 2017-02-27 18:05:56 --> Controller Class Initialized
DEBUG - 2017-02-27 18:05:56 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:05:56 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:05:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:05:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 18:05:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-27 18:05:56 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 18:05:56 --> Final output sent to browser
DEBUG - 2017-02-27 18:05:56 --> Total execution time: 0.0103
INFO - 2017-02-27 18:05:56 --> Config Class Initialized
INFO - 2017-02-27 18:05:56 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:05:56 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:05:56 --> Utf8 Class Initialized
INFO - 2017-02-27 18:05:56 --> URI Class Initialized
INFO - 2017-02-27 18:05:56 --> Router Class Initialized
INFO - 2017-02-27 18:05:56 --> Output Class Initialized
INFO - 2017-02-27 18:05:56 --> Security Class Initialized
DEBUG - 2017-02-27 18:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:05:56 --> Input Class Initialized
INFO - 2017-02-27 18:05:56 --> Language Class Initialized
INFO - 2017-02-27 18:05:56 --> Language Class Initialized
INFO - 2017-02-27 18:05:56 --> Config Class Initialized
INFO - 2017-02-27 18:05:56 --> Loader Class Initialized
INFO - 2017-02-27 18:05:56 --> Helper loaded: form_helper
INFO - 2017-02-27 18:05:56 --> Helper loaded: url_helper
INFO - 2017-02-27 18:05:56 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:05:56 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:05:56 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:05:56 --> Template Class Initialized
INFO - 2017-02-27 18:05:56 --> Model Class Initialized
INFO - 2017-02-27 18:05:56 --> Controller Class Initialized
DEBUG - 2017-02-27 18:05:56 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:05:56 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:05:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:05:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:05:56 --> Config Class Initialized
INFO - 2017-02-27 18:05:56 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:05:56 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:05:56 --> Utf8 Class Initialized
INFO - 2017-02-27 18:05:56 --> URI Class Initialized
INFO - 2017-02-27 18:05:56 --> Router Class Initialized
INFO - 2017-02-27 18:05:56 --> Output Class Initialized
INFO - 2017-02-27 18:05:56 --> Security Class Initialized
DEBUG - 2017-02-27 18:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:05:56 --> Input Class Initialized
INFO - 2017-02-27 18:05:56 --> Language Class Initialized
INFO - 2017-02-27 18:05:56 --> Language Class Initialized
INFO - 2017-02-27 18:05:56 --> Config Class Initialized
INFO - 2017-02-27 18:05:56 --> Loader Class Initialized
INFO - 2017-02-27 18:05:56 --> Helper loaded: form_helper
INFO - 2017-02-27 18:05:56 --> Helper loaded: url_helper
INFO - 2017-02-27 18:05:56 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:05:56 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:05:56 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:05:56 --> Template Class Initialized
INFO - 2017-02-27 18:05:56 --> Model Class Initialized
INFO - 2017-02-27 18:05:56 --> Controller Class Initialized
DEBUG - 2017-02-27 18:05:56 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:05:56 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:05:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:05:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:05:56 --> Config Class Initialized
INFO - 2017-02-27 18:05:56 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:05:56 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:05:56 --> Utf8 Class Initialized
INFO - 2017-02-27 18:05:56 --> URI Class Initialized
INFO - 2017-02-27 18:05:56 --> Router Class Initialized
INFO - 2017-02-27 18:05:56 --> Output Class Initialized
INFO - 2017-02-27 18:05:56 --> Security Class Initialized
DEBUG - 2017-02-27 18:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:05:56 --> Input Class Initialized
INFO - 2017-02-27 18:05:56 --> Language Class Initialized
INFO - 2017-02-27 18:05:56 --> Language Class Initialized
INFO - 2017-02-27 18:05:56 --> Config Class Initialized
INFO - 2017-02-27 18:05:56 --> Loader Class Initialized
INFO - 2017-02-27 18:05:56 --> Helper loaded: form_helper
INFO - 2017-02-27 18:05:56 --> Helper loaded: url_helper
INFO - 2017-02-27 18:05:56 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:05:56 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:05:56 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:05:56 --> Template Class Initialized
INFO - 2017-02-27 18:05:56 --> Model Class Initialized
INFO - 2017-02-27 18:05:56 --> Controller Class Initialized
DEBUG - 2017-02-27 18:05:56 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:05:56 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:05:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:05:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:05:58 --> Config Class Initialized
INFO - 2017-02-27 18:05:58 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:05:58 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:05:58 --> Utf8 Class Initialized
INFO - 2017-02-27 18:05:58 --> URI Class Initialized
INFO - 2017-02-27 18:05:58 --> Router Class Initialized
INFO - 2017-02-27 18:05:58 --> Output Class Initialized
INFO - 2017-02-27 18:05:58 --> Security Class Initialized
DEBUG - 2017-02-27 18:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:05:58 --> Input Class Initialized
INFO - 2017-02-27 18:05:58 --> Language Class Initialized
INFO - 2017-02-27 18:05:58 --> Language Class Initialized
INFO - 2017-02-27 18:05:58 --> Config Class Initialized
INFO - 2017-02-27 18:05:58 --> Loader Class Initialized
INFO - 2017-02-27 18:05:58 --> Helper loaded: form_helper
INFO - 2017-02-27 18:05:58 --> Helper loaded: url_helper
INFO - 2017-02-27 18:05:58 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:05:58 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:05:58 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:05:58 --> Template Class Initialized
INFO - 2017-02-27 18:05:58 --> Model Class Initialized
INFO - 2017-02-27 18:05:58 --> Controller Class Initialized
DEBUG - 2017-02-27 18:05:58 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:05:58 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:05:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:05:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:05:58 --> Config Class Initialized
INFO - 2017-02-27 18:05:58 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:05:58 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:05:58 --> Utf8 Class Initialized
INFO - 2017-02-27 18:05:58 --> URI Class Initialized
INFO - 2017-02-27 18:05:58 --> Router Class Initialized
INFO - 2017-02-27 18:05:58 --> Output Class Initialized
INFO - 2017-02-27 18:05:58 --> Security Class Initialized
DEBUG - 2017-02-27 18:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:05:58 --> Input Class Initialized
INFO - 2017-02-27 18:05:58 --> Language Class Initialized
INFO - 2017-02-27 18:05:58 --> Language Class Initialized
INFO - 2017-02-27 18:05:58 --> Config Class Initialized
INFO - 2017-02-27 18:05:58 --> Loader Class Initialized
INFO - 2017-02-27 18:05:58 --> Helper loaded: form_helper
INFO - 2017-02-27 18:05:58 --> Helper loaded: url_helper
INFO - 2017-02-27 18:05:58 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:05:58 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:05:58 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:05:58 --> Template Class Initialized
INFO - 2017-02-27 18:05:58 --> Model Class Initialized
INFO - 2017-02-27 18:05:58 --> Controller Class Initialized
DEBUG - 2017-02-27 18:05:58 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:05:58 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:05:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:05:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:07:27 --> Config Class Initialized
INFO - 2017-02-27 18:07:27 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:07:27 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:07:27 --> Utf8 Class Initialized
INFO - 2017-02-27 18:07:27 --> URI Class Initialized
INFO - 2017-02-27 18:07:27 --> Router Class Initialized
INFO - 2017-02-27 18:07:27 --> Output Class Initialized
INFO - 2017-02-27 18:07:27 --> Security Class Initialized
DEBUG - 2017-02-27 18:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:07:27 --> Input Class Initialized
INFO - 2017-02-27 18:07:27 --> Language Class Initialized
INFO - 2017-02-27 18:07:27 --> Language Class Initialized
INFO - 2017-02-27 18:07:27 --> Config Class Initialized
INFO - 2017-02-27 18:07:27 --> Loader Class Initialized
INFO - 2017-02-27 18:07:27 --> Helper loaded: form_helper
INFO - 2017-02-27 18:07:27 --> Helper loaded: url_helper
INFO - 2017-02-27 18:07:27 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:07:27 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:07:27 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:07:27 --> Template Class Initialized
INFO - 2017-02-27 18:07:27 --> Model Class Initialized
INFO - 2017-02-27 18:07:27 --> Controller Class Initialized
DEBUG - 2017-02-27 18:07:27 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:07:27 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:07:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:07:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:07:28 --> Config Class Initialized
INFO - 2017-02-27 18:07:28 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:07:28 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:07:28 --> Utf8 Class Initialized
INFO - 2017-02-27 18:07:28 --> URI Class Initialized
INFO - 2017-02-27 18:07:28 --> Router Class Initialized
INFO - 2017-02-27 18:07:28 --> Output Class Initialized
INFO - 2017-02-27 18:07:28 --> Security Class Initialized
DEBUG - 2017-02-27 18:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:07:28 --> Input Class Initialized
INFO - 2017-02-27 18:07:28 --> Language Class Initialized
INFO - 2017-02-27 18:07:28 --> Language Class Initialized
INFO - 2017-02-27 18:07:28 --> Config Class Initialized
INFO - 2017-02-27 18:07:28 --> Loader Class Initialized
INFO - 2017-02-27 18:07:28 --> Helper loaded: form_helper
INFO - 2017-02-27 18:07:28 --> Helper loaded: url_helper
INFO - 2017-02-27 18:07:28 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:07:28 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:07:28 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:07:28 --> Template Class Initialized
INFO - 2017-02-27 18:07:28 --> Model Class Initialized
INFO - 2017-02-27 18:07:28 --> Controller Class Initialized
DEBUG - 2017-02-27 18:07:28 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:07:28 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:07:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:07:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:07:29 --> Config Class Initialized
INFO - 2017-02-27 18:07:29 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:07:29 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:07:29 --> Utf8 Class Initialized
INFO - 2017-02-27 18:07:29 --> URI Class Initialized
INFO - 2017-02-27 18:07:29 --> Router Class Initialized
INFO - 2017-02-27 18:07:29 --> Output Class Initialized
INFO - 2017-02-27 18:07:29 --> Security Class Initialized
DEBUG - 2017-02-27 18:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:07:29 --> Input Class Initialized
INFO - 2017-02-27 18:07:29 --> Language Class Initialized
INFO - 2017-02-27 18:07:29 --> Language Class Initialized
INFO - 2017-02-27 18:07:29 --> Config Class Initialized
INFO - 2017-02-27 18:07:29 --> Loader Class Initialized
INFO - 2017-02-27 18:07:29 --> Helper loaded: form_helper
INFO - 2017-02-27 18:07:29 --> Helper loaded: url_helper
INFO - 2017-02-27 18:07:29 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:07:29 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:07:29 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:07:29 --> Template Class Initialized
INFO - 2017-02-27 18:07:29 --> Model Class Initialized
INFO - 2017-02-27 18:07:29 --> Controller Class Initialized
DEBUG - 2017-02-27 18:07:29 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:07:29 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:07:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:07:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:07:29 --> Config Class Initialized
INFO - 2017-02-27 18:07:29 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:07:29 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:07:29 --> Utf8 Class Initialized
INFO - 2017-02-27 18:07:29 --> URI Class Initialized
INFO - 2017-02-27 18:07:29 --> Router Class Initialized
INFO - 2017-02-27 18:07:29 --> Output Class Initialized
INFO - 2017-02-27 18:07:29 --> Security Class Initialized
DEBUG - 2017-02-27 18:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:07:29 --> Input Class Initialized
INFO - 2017-02-27 18:07:29 --> Language Class Initialized
INFO - 2017-02-27 18:07:29 --> Language Class Initialized
INFO - 2017-02-27 18:07:29 --> Config Class Initialized
INFO - 2017-02-27 18:07:29 --> Loader Class Initialized
INFO - 2017-02-27 18:07:29 --> Helper loaded: form_helper
INFO - 2017-02-27 18:07:29 --> Helper loaded: url_helper
INFO - 2017-02-27 18:07:29 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:07:29 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:07:29 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:07:29 --> Template Class Initialized
INFO - 2017-02-27 18:07:29 --> Model Class Initialized
INFO - 2017-02-27 18:07:29 --> Controller Class Initialized
DEBUG - 2017-02-27 18:07:29 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:07:29 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:07:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:07:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:20:04 --> Config Class Initialized
INFO - 2017-02-27 18:20:04 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:20:04 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:20:04 --> Utf8 Class Initialized
INFO - 2017-02-27 18:20:04 --> URI Class Initialized
INFO - 2017-02-27 18:20:04 --> Router Class Initialized
INFO - 2017-02-27 18:20:04 --> Output Class Initialized
INFO - 2017-02-27 18:20:04 --> Security Class Initialized
DEBUG - 2017-02-27 18:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:20:04 --> Input Class Initialized
INFO - 2017-02-27 18:20:04 --> Language Class Initialized
INFO - 2017-02-27 18:20:04 --> Language Class Initialized
INFO - 2017-02-27 18:20:04 --> Config Class Initialized
INFO - 2017-02-27 18:20:04 --> Loader Class Initialized
INFO - 2017-02-27 18:20:04 --> Helper loaded: form_helper
INFO - 2017-02-27 18:20:04 --> Helper loaded: url_helper
INFO - 2017-02-27 18:20:04 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:20:04 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:20:04 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:20:04 --> Template Class Initialized
INFO - 2017-02-27 18:20:04 --> Model Class Initialized
INFO - 2017-02-27 18:20:04 --> Controller Class Initialized
DEBUG - 2017-02-27 18:20:04 --> Dashboard MX_Controller Initialized
INFO - 2017-02-27 18:20:04 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:20:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 18:20:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-02-27 18:20:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 18:20:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/my_subscribers.php
DEBUG - 2017-02-27 18:20:04 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 18:20:04 --> Final output sent to browser
DEBUG - 2017-02-27 18:20:04 --> Total execution time: 0.0672
INFO - 2017-02-27 18:20:05 --> Config Class Initialized
INFO - 2017-02-27 18:20:05 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:20:05 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:20:05 --> Utf8 Class Initialized
INFO - 2017-02-27 18:20:05 --> URI Class Initialized
INFO - 2017-02-27 18:20:05 --> Router Class Initialized
INFO - 2017-02-27 18:20:05 --> Output Class Initialized
INFO - 2017-02-27 18:20:05 --> Security Class Initialized
DEBUG - 2017-02-27 18:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:20:05 --> Input Class Initialized
INFO - 2017-02-27 18:20:05 --> Language Class Initialized
INFO - 2017-02-27 18:20:05 --> Language Class Initialized
INFO - 2017-02-27 18:20:05 --> Config Class Initialized
INFO - 2017-02-27 18:20:05 --> Loader Class Initialized
INFO - 2017-02-27 18:20:05 --> Helper loaded: form_helper
INFO - 2017-02-27 18:20:05 --> Helper loaded: url_helper
INFO - 2017-02-27 18:20:05 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:20:05 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:20:05 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:20:05 --> Template Class Initialized
INFO - 2017-02-27 18:20:05 --> Model Class Initialized
INFO - 2017-02-27 18:20:05 --> Controller Class Initialized
DEBUG - 2017-02-27 18:20:05 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:20:05 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:20:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:20:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:20:06 --> Config Class Initialized
INFO - 2017-02-27 18:20:06 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:20:06 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:20:06 --> Utf8 Class Initialized
INFO - 2017-02-27 18:20:06 --> URI Class Initialized
INFO - 2017-02-27 18:20:06 --> Router Class Initialized
INFO - 2017-02-27 18:20:06 --> Output Class Initialized
INFO - 2017-02-27 18:20:06 --> Security Class Initialized
DEBUG - 2017-02-27 18:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:20:06 --> Input Class Initialized
INFO - 2017-02-27 18:20:06 --> Language Class Initialized
INFO - 2017-02-27 18:20:06 --> Language Class Initialized
INFO - 2017-02-27 18:20:06 --> Config Class Initialized
INFO - 2017-02-27 18:20:06 --> Loader Class Initialized
INFO - 2017-02-27 18:20:06 --> Helper loaded: form_helper
INFO - 2017-02-27 18:20:06 --> Helper loaded: url_helper
INFO - 2017-02-27 18:20:06 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:20:06 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:20:06 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:20:06 --> Template Class Initialized
INFO - 2017-02-27 18:20:06 --> Model Class Initialized
INFO - 2017-02-27 18:20:06 --> Controller Class Initialized
DEBUG - 2017-02-27 18:20:06 --> Dashboard MX_Controller Initialized
INFO - 2017-02-27 18:20:06 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:20:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 18:20:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-02-27 18:20:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 18:20:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/order_history.php
DEBUG - 2017-02-27 18:20:06 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 18:20:06 --> Final output sent to browser
DEBUG - 2017-02-27 18:20:06 --> Total execution time: 0.0134
INFO - 2017-02-27 18:20:07 --> Config Class Initialized
INFO - 2017-02-27 18:20:07 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:20:07 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:20:07 --> Utf8 Class Initialized
INFO - 2017-02-27 18:20:07 --> URI Class Initialized
INFO - 2017-02-27 18:20:07 --> Router Class Initialized
INFO - 2017-02-27 18:20:07 --> Output Class Initialized
INFO - 2017-02-27 18:20:07 --> Security Class Initialized
DEBUG - 2017-02-27 18:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:20:07 --> Input Class Initialized
INFO - 2017-02-27 18:20:07 --> Language Class Initialized
INFO - 2017-02-27 18:20:07 --> Language Class Initialized
INFO - 2017-02-27 18:20:07 --> Config Class Initialized
INFO - 2017-02-27 18:20:07 --> Loader Class Initialized
INFO - 2017-02-27 18:20:07 --> Helper loaded: form_helper
INFO - 2017-02-27 18:20:07 --> Helper loaded: url_helper
INFO - 2017-02-27 18:20:07 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:20:07 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:20:07 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:20:07 --> Template Class Initialized
INFO - 2017-02-27 18:20:07 --> Model Class Initialized
INFO - 2017-02-27 18:20:07 --> Controller Class Initialized
DEBUG - 2017-02-27 18:20:07 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:20:07 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:20:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:20:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:20:09 --> Config Class Initialized
INFO - 2017-02-27 18:20:09 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:20:09 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:20:09 --> Utf8 Class Initialized
INFO - 2017-02-27 18:20:09 --> URI Class Initialized
INFO - 2017-02-27 18:20:09 --> Router Class Initialized
INFO - 2017-02-27 18:20:09 --> Output Class Initialized
INFO - 2017-02-27 18:20:09 --> Security Class Initialized
DEBUG - 2017-02-27 18:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:20:09 --> Input Class Initialized
INFO - 2017-02-27 18:20:09 --> Language Class Initialized
INFO - 2017-02-27 18:20:09 --> Language Class Initialized
INFO - 2017-02-27 18:20:09 --> Config Class Initialized
INFO - 2017-02-27 18:20:09 --> Loader Class Initialized
INFO - 2017-02-27 18:20:09 --> Helper loaded: form_helper
INFO - 2017-02-27 18:20:09 --> Helper loaded: url_helper
INFO - 2017-02-27 18:20:09 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:20:09 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:20:09 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:20:09 --> Template Class Initialized
INFO - 2017-02-27 18:20:09 --> Model Class Initialized
INFO - 2017-02-27 18:20:09 --> Controller Class Initialized
DEBUG - 2017-02-27 18:20:09 --> Dashboard MX_Controller Initialized
INFO - 2017-02-27 18:20:09 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:20:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 18:20:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-02-27 18:20:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 18:20:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/download_center.php
DEBUG - 2017-02-27 18:20:09 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 18:20:09 --> Final output sent to browser
DEBUG - 2017-02-27 18:20:09 --> Total execution time: 0.0267
INFO - 2017-02-27 18:20:10 --> Config Class Initialized
INFO - 2017-02-27 18:20:10 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:20:10 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:20:10 --> Utf8 Class Initialized
INFO - 2017-02-27 18:20:10 --> URI Class Initialized
INFO - 2017-02-27 18:20:10 --> Router Class Initialized
INFO - 2017-02-27 18:20:10 --> Output Class Initialized
INFO - 2017-02-27 18:20:10 --> Security Class Initialized
DEBUG - 2017-02-27 18:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:20:10 --> Input Class Initialized
INFO - 2017-02-27 18:20:10 --> Language Class Initialized
INFO - 2017-02-27 18:20:10 --> Language Class Initialized
INFO - 2017-02-27 18:20:10 --> Config Class Initialized
INFO - 2017-02-27 18:20:10 --> Loader Class Initialized
INFO - 2017-02-27 18:20:10 --> Helper loaded: form_helper
INFO - 2017-02-27 18:20:10 --> Helper loaded: url_helper
INFO - 2017-02-27 18:20:10 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:20:10 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:20:10 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:20:10 --> Template Class Initialized
INFO - 2017-02-27 18:20:10 --> Model Class Initialized
INFO - 2017-02-27 18:20:10 --> Controller Class Initialized
DEBUG - 2017-02-27 18:20:10 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:20:10 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:20:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:20:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:20:10 --> Config Class Initialized
INFO - 2017-02-27 18:20:10 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:20:10 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:20:10 --> Utf8 Class Initialized
INFO - 2017-02-27 18:20:10 --> URI Class Initialized
INFO - 2017-02-27 18:20:10 --> Router Class Initialized
INFO - 2017-02-27 18:20:10 --> Output Class Initialized
INFO - 2017-02-27 18:20:10 --> Security Class Initialized
DEBUG - 2017-02-27 18:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:20:10 --> Input Class Initialized
INFO - 2017-02-27 18:20:10 --> Language Class Initialized
INFO - 2017-02-27 18:20:10 --> Language Class Initialized
INFO - 2017-02-27 18:20:10 --> Config Class Initialized
INFO - 2017-02-27 18:20:10 --> Loader Class Initialized
INFO - 2017-02-27 18:20:10 --> Helper loaded: form_helper
INFO - 2017-02-27 18:20:10 --> Helper loaded: url_helper
INFO - 2017-02-27 18:20:10 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:20:10 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:20:10 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:20:10 --> Template Class Initialized
INFO - 2017-02-27 18:20:10 --> Model Class Initialized
INFO - 2017-02-27 18:20:10 --> Controller Class Initialized
DEBUG - 2017-02-27 18:20:10 --> Dashboard MX_Controller Initialized
INFO - 2017-02-27 18:20:10 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:20:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 18:20:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-02-27 18:20:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 18:20:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/setting.php
DEBUG - 2017-02-27 18:20:10 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 18:20:10 --> Final output sent to browser
DEBUG - 2017-02-27 18:20:10 --> Total execution time: 0.0221
INFO - 2017-02-27 18:20:11 --> Config Class Initialized
INFO - 2017-02-27 18:20:11 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:20:11 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:20:11 --> Utf8 Class Initialized
INFO - 2017-02-27 18:20:11 --> URI Class Initialized
INFO - 2017-02-27 18:20:11 --> Router Class Initialized
INFO - 2017-02-27 18:20:11 --> Output Class Initialized
INFO - 2017-02-27 18:20:11 --> Security Class Initialized
DEBUG - 2017-02-27 18:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:20:11 --> Input Class Initialized
INFO - 2017-02-27 18:20:11 --> Language Class Initialized
INFO - 2017-02-27 18:20:11 --> Language Class Initialized
INFO - 2017-02-27 18:20:11 --> Config Class Initialized
INFO - 2017-02-27 18:20:11 --> Loader Class Initialized
INFO - 2017-02-27 18:20:11 --> Helper loaded: form_helper
INFO - 2017-02-27 18:20:11 --> Helper loaded: url_helper
INFO - 2017-02-27 18:20:11 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:20:11 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:20:11 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:20:11 --> Template Class Initialized
INFO - 2017-02-27 18:20:11 --> Model Class Initialized
INFO - 2017-02-27 18:20:11 --> Controller Class Initialized
DEBUG - 2017-02-27 18:20:11 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:20:11 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:20:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:20:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:20:13 --> Config Class Initialized
INFO - 2017-02-27 18:20:13 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:20:13 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:20:13 --> Utf8 Class Initialized
INFO - 2017-02-27 18:20:13 --> URI Class Initialized
INFO - 2017-02-27 18:20:13 --> Router Class Initialized
INFO - 2017-02-27 18:20:13 --> Output Class Initialized
INFO - 2017-02-27 18:20:13 --> Security Class Initialized
DEBUG - 2017-02-27 18:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:20:13 --> Input Class Initialized
INFO - 2017-02-27 18:20:13 --> Language Class Initialized
INFO - 2017-02-27 18:20:13 --> Language Class Initialized
INFO - 2017-02-27 18:20:13 --> Config Class Initialized
INFO - 2017-02-27 18:20:13 --> Loader Class Initialized
INFO - 2017-02-27 18:20:13 --> Helper loaded: form_helper
INFO - 2017-02-27 18:20:13 --> Helper loaded: url_helper
INFO - 2017-02-27 18:20:13 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:20:13 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:20:13 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:20:13 --> Template Class Initialized
INFO - 2017-02-27 18:20:13 --> Model Class Initialized
INFO - 2017-02-27 18:20:13 --> Controller Class Initialized
DEBUG - 2017-02-27 18:20:13 --> Dashboard MX_Controller Initialized
INFO - 2017-02-27 18:20:13 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:20:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 18:20:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-02-27 18:20:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 18:20:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/download_center.php
DEBUG - 2017-02-27 18:20:13 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 18:20:13 --> Final output sent to browser
DEBUG - 2017-02-27 18:20:13 --> Total execution time: 0.0141
INFO - 2017-02-27 18:20:13 --> Config Class Initialized
INFO - 2017-02-27 18:20:13 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:20:13 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:20:13 --> Utf8 Class Initialized
INFO - 2017-02-27 18:20:13 --> URI Class Initialized
INFO - 2017-02-27 18:20:13 --> Router Class Initialized
INFO - 2017-02-27 18:20:13 --> Output Class Initialized
INFO - 2017-02-27 18:20:13 --> Security Class Initialized
DEBUG - 2017-02-27 18:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:20:13 --> Input Class Initialized
INFO - 2017-02-27 18:20:13 --> Language Class Initialized
INFO - 2017-02-27 18:20:13 --> Language Class Initialized
INFO - 2017-02-27 18:20:13 --> Config Class Initialized
INFO - 2017-02-27 18:20:13 --> Loader Class Initialized
INFO - 2017-02-27 18:20:13 --> Helper loaded: form_helper
INFO - 2017-02-27 18:20:13 --> Helper loaded: url_helper
INFO - 2017-02-27 18:20:13 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:20:13 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:20:13 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:20:13 --> Template Class Initialized
INFO - 2017-02-27 18:20:13 --> Model Class Initialized
INFO - 2017-02-27 18:20:13 --> Controller Class Initialized
DEBUG - 2017-02-27 18:20:13 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:20:13 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:20:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:20:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:20:14 --> Config Class Initialized
INFO - 2017-02-27 18:20:14 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:20:14 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:20:14 --> Utf8 Class Initialized
INFO - 2017-02-27 18:20:14 --> URI Class Initialized
INFO - 2017-02-27 18:20:14 --> Router Class Initialized
INFO - 2017-02-27 18:20:14 --> Output Class Initialized
INFO - 2017-02-27 18:20:14 --> Security Class Initialized
DEBUG - 2017-02-27 18:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:20:14 --> Input Class Initialized
INFO - 2017-02-27 18:20:14 --> Language Class Initialized
INFO - 2017-02-27 18:20:14 --> Language Class Initialized
INFO - 2017-02-27 18:20:14 --> Config Class Initialized
INFO - 2017-02-27 18:20:14 --> Loader Class Initialized
INFO - 2017-02-27 18:20:14 --> Helper loaded: form_helper
INFO - 2017-02-27 18:20:14 --> Helper loaded: url_helper
INFO - 2017-02-27 18:20:14 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:20:14 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:20:14 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:20:14 --> Template Class Initialized
INFO - 2017-02-27 18:20:14 --> Model Class Initialized
INFO - 2017-02-27 18:20:14 --> Controller Class Initialized
DEBUG - 2017-02-27 18:20:14 --> Dashboard MX_Controller Initialized
INFO - 2017-02-27 18:20:14 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:20:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 18:20:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-02-27 18:20:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 18:20:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/order_history.php
DEBUG - 2017-02-27 18:20:14 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 18:20:14 --> Final output sent to browser
DEBUG - 2017-02-27 18:20:14 --> Total execution time: 0.0139
INFO - 2017-02-27 18:20:14 --> Config Class Initialized
INFO - 2017-02-27 18:20:14 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:20:14 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:20:14 --> Utf8 Class Initialized
INFO - 2017-02-27 18:20:14 --> URI Class Initialized
INFO - 2017-02-27 18:20:14 --> Router Class Initialized
INFO - 2017-02-27 18:20:14 --> Output Class Initialized
INFO - 2017-02-27 18:20:14 --> Security Class Initialized
DEBUG - 2017-02-27 18:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:20:14 --> Input Class Initialized
INFO - 2017-02-27 18:20:14 --> Language Class Initialized
INFO - 2017-02-27 18:20:14 --> Language Class Initialized
INFO - 2017-02-27 18:20:14 --> Config Class Initialized
INFO - 2017-02-27 18:20:14 --> Loader Class Initialized
INFO - 2017-02-27 18:20:14 --> Helper loaded: form_helper
INFO - 2017-02-27 18:20:14 --> Helper loaded: url_helper
INFO - 2017-02-27 18:20:14 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:20:14 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:20:14 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:20:14 --> Template Class Initialized
INFO - 2017-02-27 18:20:14 --> Model Class Initialized
INFO - 2017-02-27 18:20:14 --> Controller Class Initialized
DEBUG - 2017-02-27 18:20:14 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:20:14 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:20:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:20:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:20:15 --> Config Class Initialized
INFO - 2017-02-27 18:20:15 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:20:15 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:20:15 --> Utf8 Class Initialized
INFO - 2017-02-27 18:20:15 --> URI Class Initialized
INFO - 2017-02-27 18:20:15 --> Router Class Initialized
INFO - 2017-02-27 18:20:15 --> Output Class Initialized
INFO - 2017-02-27 18:20:15 --> Security Class Initialized
DEBUG - 2017-02-27 18:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:20:15 --> Input Class Initialized
INFO - 2017-02-27 18:20:15 --> Language Class Initialized
INFO - 2017-02-27 18:20:15 --> Language Class Initialized
INFO - 2017-02-27 18:20:15 --> Config Class Initialized
INFO - 2017-02-27 18:20:15 --> Loader Class Initialized
INFO - 2017-02-27 18:20:15 --> Helper loaded: form_helper
INFO - 2017-02-27 18:20:15 --> Helper loaded: url_helper
INFO - 2017-02-27 18:20:15 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:20:15 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:20:15 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:20:15 --> Template Class Initialized
INFO - 2017-02-27 18:20:15 --> Model Class Initialized
INFO - 2017-02-27 18:20:15 --> Controller Class Initialized
DEBUG - 2017-02-27 18:20:15 --> Dashboard MX_Controller Initialized
INFO - 2017-02-27 18:20:15 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:20:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 18:20:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-02-27 18:20:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 18:20:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/my_subscribers.php
DEBUG - 2017-02-27 18:20:15 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 18:20:15 --> Final output sent to browser
DEBUG - 2017-02-27 18:20:15 --> Total execution time: 0.0165
INFO - 2017-02-27 18:20:15 --> Config Class Initialized
INFO - 2017-02-27 18:20:15 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:20:15 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:20:15 --> Utf8 Class Initialized
INFO - 2017-02-27 18:20:15 --> URI Class Initialized
INFO - 2017-02-27 18:20:15 --> Router Class Initialized
INFO - 2017-02-27 18:20:15 --> Output Class Initialized
INFO - 2017-02-27 18:20:15 --> Security Class Initialized
DEBUG - 2017-02-27 18:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:20:15 --> Input Class Initialized
INFO - 2017-02-27 18:20:15 --> Language Class Initialized
INFO - 2017-02-27 18:20:15 --> Language Class Initialized
INFO - 2017-02-27 18:20:15 --> Config Class Initialized
INFO - 2017-02-27 18:20:15 --> Loader Class Initialized
INFO - 2017-02-27 18:20:15 --> Helper loaded: form_helper
INFO - 2017-02-27 18:20:15 --> Helper loaded: url_helper
INFO - 2017-02-27 18:20:15 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:20:15 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:20:15 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:20:15 --> Template Class Initialized
INFO - 2017-02-27 18:20:15 --> Model Class Initialized
INFO - 2017-02-27 18:20:15 --> Controller Class Initialized
DEBUG - 2017-02-27 18:20:15 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:20:15 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:20:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:20:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:20:16 --> Config Class Initialized
INFO - 2017-02-27 18:20:16 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:20:16 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:20:16 --> Utf8 Class Initialized
INFO - 2017-02-27 18:20:16 --> URI Class Initialized
INFO - 2017-02-27 18:20:16 --> Router Class Initialized
INFO - 2017-02-27 18:20:16 --> Output Class Initialized
INFO - 2017-02-27 18:20:16 --> Security Class Initialized
DEBUG - 2017-02-27 18:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:20:16 --> Input Class Initialized
INFO - 2017-02-27 18:20:16 --> Language Class Initialized
INFO - 2017-02-27 18:20:16 --> Language Class Initialized
INFO - 2017-02-27 18:20:16 --> Config Class Initialized
INFO - 2017-02-27 18:20:16 --> Loader Class Initialized
INFO - 2017-02-27 18:20:16 --> Helper loaded: form_helper
INFO - 2017-02-27 18:20:16 --> Helper loaded: url_helper
INFO - 2017-02-27 18:20:16 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:20:16 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:20:16 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:20:16 --> Template Class Initialized
INFO - 2017-02-27 18:20:16 --> Model Class Initialized
INFO - 2017-02-27 18:20:16 --> Controller Class Initialized
DEBUG - 2017-02-27 18:20:16 --> Dashboard MX_Controller Initialized
INFO - 2017-02-27 18:20:16 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:20:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-27 18:20:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-02-27 18:20:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-27 18:20:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-02-27 18:20:16 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-27 18:20:16 --> Final output sent to browser
DEBUG - 2017-02-27 18:20:16 --> Total execution time: 0.0097
INFO - 2017-02-27 18:20:17 --> Config Class Initialized
INFO - 2017-02-27 18:20:17 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:20:17 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:20:17 --> Utf8 Class Initialized
INFO - 2017-02-27 18:20:17 --> URI Class Initialized
INFO - 2017-02-27 18:20:17 --> Router Class Initialized
INFO - 2017-02-27 18:20:17 --> Output Class Initialized
INFO - 2017-02-27 18:20:17 --> Security Class Initialized
DEBUG - 2017-02-27 18:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:20:17 --> Input Class Initialized
INFO - 2017-02-27 18:20:17 --> Language Class Initialized
INFO - 2017-02-27 18:20:17 --> Language Class Initialized
INFO - 2017-02-27 18:20:17 --> Config Class Initialized
INFO - 2017-02-27 18:20:17 --> Loader Class Initialized
INFO - 2017-02-27 18:20:17 --> Helper loaded: form_helper
INFO - 2017-02-27 18:20:17 --> Helper loaded: url_helper
INFO - 2017-02-27 18:20:17 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:20:17 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:20:17 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:20:17 --> Template Class Initialized
INFO - 2017-02-27 18:20:17 --> Model Class Initialized
INFO - 2017-02-27 18:20:17 --> Controller Class Initialized
DEBUG - 2017-02-27 18:20:17 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:20:17 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:20:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:20:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:25:39 --> Config Class Initialized
INFO - 2017-02-27 18:25:39 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:25:39 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:25:39 --> Utf8 Class Initialized
INFO - 2017-02-27 18:25:39 --> URI Class Initialized
INFO - 2017-02-27 18:25:39 --> Router Class Initialized
INFO - 2017-02-27 18:25:39 --> Output Class Initialized
INFO - 2017-02-27 18:25:39 --> Security Class Initialized
DEBUG - 2017-02-27 18:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:25:39 --> Input Class Initialized
INFO - 2017-02-27 18:25:39 --> Language Class Initialized
INFO - 2017-02-27 18:25:39 --> Language Class Initialized
INFO - 2017-02-27 18:25:39 --> Config Class Initialized
INFO - 2017-02-27 18:25:39 --> Loader Class Initialized
INFO - 2017-02-27 18:25:39 --> Helper loaded: form_helper
INFO - 2017-02-27 18:25:39 --> Helper loaded: url_helper
INFO - 2017-02-27 18:25:39 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:25:39 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:25:39 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:25:39 --> Template Class Initialized
INFO - 2017-02-27 18:25:39 --> Model Class Initialized
INFO - 2017-02-27 18:25:39 --> Controller Class Initialized
DEBUG - 2017-02-27 18:25:39 --> Login MX_Controller Initialized
INFO - 2017-02-27 18:25:39 --> Helper loaded: cookie_helper
INFO - 2017-02-27 18:25:39 --> Form Validation Class Initialized
INFO - 2017-02-27 18:25:39 --> Config Class Initialized
INFO - 2017-02-27 18:25:39 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:25:39 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:25:39 --> Utf8 Class Initialized
INFO - 2017-02-27 18:25:39 --> URI Class Initialized
DEBUG - 2017-02-27 18:25:39 --> No URI present. Default controller set.
INFO - 2017-02-27 18:25:39 --> Router Class Initialized
INFO - 2017-02-27 18:25:39 --> Output Class Initialized
INFO - 2017-02-27 18:25:39 --> Security Class Initialized
DEBUG - 2017-02-27 18:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:25:39 --> Input Class Initialized
INFO - 2017-02-27 18:25:39 --> Language Class Initialized
INFO - 2017-02-27 18:25:39 --> Language Class Initialized
INFO - 2017-02-27 18:25:39 --> Config Class Initialized
INFO - 2017-02-27 18:25:39 --> Loader Class Initialized
INFO - 2017-02-27 18:25:39 --> Helper loaded: form_helper
INFO - 2017-02-27 18:25:39 --> Helper loaded: url_helper
INFO - 2017-02-27 18:25:39 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:25:39 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:25:39 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:25:39 --> Template Class Initialized
INFO - 2017-02-27 18:25:39 --> Model Class Initialized
INFO - 2017-02-27 18:25:39 --> Controller Class Initialized
DEBUG - 2017-02-27 18:25:39 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:25:39 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:25:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:25:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 18:25:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-27 18:25:39 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 18:25:39 --> Final output sent to browser
DEBUG - 2017-02-27 18:25:39 --> Total execution time: 0.0144
INFO - 2017-02-27 18:25:39 --> Config Class Initialized
INFO - 2017-02-27 18:25:39 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:25:39 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:25:39 --> Utf8 Class Initialized
INFO - 2017-02-27 18:25:39 --> URI Class Initialized
INFO - 2017-02-27 18:25:39 --> Router Class Initialized
INFO - 2017-02-27 18:25:39 --> Output Class Initialized
INFO - 2017-02-27 18:25:39 --> Security Class Initialized
DEBUG - 2017-02-27 18:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:25:39 --> Input Class Initialized
INFO - 2017-02-27 18:25:39 --> Language Class Initialized
INFO - 2017-02-27 18:25:39 --> Language Class Initialized
INFO - 2017-02-27 18:25:39 --> Config Class Initialized
INFO - 2017-02-27 18:25:39 --> Loader Class Initialized
INFO - 2017-02-27 18:25:39 --> Helper loaded: form_helper
INFO - 2017-02-27 18:25:39 --> Helper loaded: url_helper
INFO - 2017-02-27 18:25:39 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:25:39 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:25:39 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:25:39 --> Template Class Initialized
INFO - 2017-02-27 18:25:39 --> Model Class Initialized
INFO - 2017-02-27 18:25:39 --> Controller Class Initialized
DEBUG - 2017-02-27 18:25:39 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:25:39 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:25:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:25:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:25:39 --> Config Class Initialized
INFO - 2017-02-27 18:25:39 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:25:39 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:25:39 --> Utf8 Class Initialized
INFO - 2017-02-27 18:25:39 --> URI Class Initialized
INFO - 2017-02-27 18:25:39 --> Router Class Initialized
INFO - 2017-02-27 18:25:39 --> Output Class Initialized
INFO - 2017-02-27 18:25:39 --> Security Class Initialized
DEBUG - 2017-02-27 18:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:25:39 --> Input Class Initialized
INFO - 2017-02-27 18:25:39 --> Language Class Initialized
INFO - 2017-02-27 18:25:39 --> Language Class Initialized
INFO - 2017-02-27 18:25:39 --> Config Class Initialized
INFO - 2017-02-27 18:25:39 --> Loader Class Initialized
INFO - 2017-02-27 18:25:39 --> Helper loaded: form_helper
INFO - 2017-02-27 18:25:39 --> Helper loaded: url_helper
INFO - 2017-02-27 18:25:39 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:25:39 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:25:39 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:25:39 --> Template Class Initialized
INFO - 2017-02-27 18:25:39 --> Model Class Initialized
INFO - 2017-02-27 18:25:39 --> Controller Class Initialized
DEBUG - 2017-02-27 18:25:39 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:25:39 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:25:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:25:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:25:40 --> Config Class Initialized
INFO - 2017-02-27 18:25:40 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:25:40 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:25:40 --> Utf8 Class Initialized
INFO - 2017-02-27 18:25:40 --> URI Class Initialized
INFO - 2017-02-27 18:25:40 --> Router Class Initialized
INFO - 2017-02-27 18:25:40 --> Output Class Initialized
INFO - 2017-02-27 18:25:40 --> Security Class Initialized
DEBUG - 2017-02-27 18:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:25:40 --> Input Class Initialized
INFO - 2017-02-27 18:25:40 --> Language Class Initialized
INFO - 2017-02-27 18:25:40 --> Language Class Initialized
INFO - 2017-02-27 18:25:40 --> Config Class Initialized
INFO - 2017-02-27 18:25:40 --> Loader Class Initialized
INFO - 2017-02-27 18:25:40 --> Helper loaded: form_helper
INFO - 2017-02-27 18:25:40 --> Helper loaded: url_helper
INFO - 2017-02-27 18:25:40 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:25:40 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:25:40 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:25:40 --> Template Class Initialized
INFO - 2017-02-27 18:25:40 --> Model Class Initialized
INFO - 2017-02-27 18:25:40 --> Controller Class Initialized
DEBUG - 2017-02-27 18:25:40 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:25:40 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:25:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:25:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 18:25:40 --> Config Class Initialized
INFO - 2017-02-27 18:25:40 --> Hooks Class Initialized
DEBUG - 2017-02-27 18:25:40 --> UTF-8 Support Enabled
INFO - 2017-02-27 18:25:40 --> Utf8 Class Initialized
INFO - 2017-02-27 18:25:40 --> URI Class Initialized
INFO - 2017-02-27 18:25:40 --> Router Class Initialized
INFO - 2017-02-27 18:25:40 --> Output Class Initialized
INFO - 2017-02-27 18:25:40 --> Security Class Initialized
DEBUG - 2017-02-27 18:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 18:25:40 --> Input Class Initialized
INFO - 2017-02-27 18:25:40 --> Language Class Initialized
INFO - 2017-02-27 18:25:40 --> Language Class Initialized
INFO - 2017-02-27 18:25:40 --> Config Class Initialized
INFO - 2017-02-27 18:25:40 --> Loader Class Initialized
INFO - 2017-02-27 18:25:40 --> Helper loaded: form_helper
INFO - 2017-02-27 18:25:40 --> Helper loaded: url_helper
INFO - 2017-02-27 18:25:40 --> Helper loaded: utility_helper
INFO - 2017-02-27 18:25:40 --> Database Driver Class Initialized
DEBUG - 2017-02-27 18:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 18:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 18:25:40 --> User Agent Class Initialized
DEBUG - 2017-02-27 18:25:40 --> Template Class Initialized
INFO - 2017-02-27 18:25:40 --> Model Class Initialized
INFO - 2017-02-27 18:25:40 --> Controller Class Initialized
DEBUG - 2017-02-27 18:25:40 --> Pages MX_Controller Initialized
INFO - 2017-02-27 18:25:40 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 18:25:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 18:25:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:20:22 --> Config Class Initialized
INFO - 2017-02-27 20:20:22 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:20:22 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:20:22 --> Utf8 Class Initialized
INFO - 2017-02-27 20:20:22 --> URI Class Initialized
DEBUG - 2017-02-27 20:20:22 --> No URI present. Default controller set.
INFO - 2017-02-27 20:20:22 --> Router Class Initialized
INFO - 2017-02-27 20:20:22 --> Output Class Initialized
INFO - 2017-02-27 20:20:22 --> Security Class Initialized
DEBUG - 2017-02-27 20:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:20:22 --> Input Class Initialized
INFO - 2017-02-27 20:20:22 --> Language Class Initialized
INFO - 2017-02-27 20:20:22 --> Language Class Initialized
INFO - 2017-02-27 20:20:22 --> Config Class Initialized
INFO - 2017-02-27 20:20:22 --> Loader Class Initialized
INFO - 2017-02-27 20:20:23 --> Helper loaded: form_helper
INFO - 2017-02-27 20:20:23 --> Helper loaded: url_helper
INFO - 2017-02-27 20:20:23 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:20:23 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:20:23 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:20:23 --> Template Class Initialized
INFO - 2017-02-27 20:20:23 --> Model Class Initialized
INFO - 2017-02-27 20:20:23 --> Controller Class Initialized
DEBUG - 2017-02-27 20:20:23 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:20:23 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:20:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:20:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 20:20:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-27 20:20:23 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 20:20:23 --> Final output sent to browser
DEBUG - 2017-02-27 20:20:23 --> Total execution time: 0.2252
INFO - 2017-02-27 20:20:24 --> Config Class Initialized
INFO - 2017-02-27 20:20:24 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:20:24 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:20:24 --> Utf8 Class Initialized
INFO - 2017-02-27 20:20:24 --> URI Class Initialized
INFO - 2017-02-27 20:20:24 --> Router Class Initialized
INFO - 2017-02-27 20:20:24 --> Output Class Initialized
INFO - 2017-02-27 20:20:24 --> Security Class Initialized
DEBUG - 2017-02-27 20:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:20:24 --> Input Class Initialized
INFO - 2017-02-27 20:20:24 --> Language Class Initialized
INFO - 2017-02-27 20:20:24 --> Language Class Initialized
INFO - 2017-02-27 20:20:24 --> Config Class Initialized
INFO - 2017-02-27 20:20:24 --> Loader Class Initialized
INFO - 2017-02-27 20:20:24 --> Helper loaded: form_helper
INFO - 2017-02-27 20:20:24 --> Helper loaded: url_helper
INFO - 2017-02-27 20:20:24 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:20:24 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:20:24 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:20:24 --> Template Class Initialized
INFO - 2017-02-27 20:20:24 --> Model Class Initialized
INFO - 2017-02-27 20:20:24 --> Controller Class Initialized
DEBUG - 2017-02-27 20:20:24 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:20:24 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:20:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:20:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:20:24 --> Config Class Initialized
INFO - 2017-02-27 20:20:24 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:20:24 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:20:24 --> Utf8 Class Initialized
INFO - 2017-02-27 20:20:24 --> URI Class Initialized
INFO - 2017-02-27 20:20:24 --> Router Class Initialized
INFO - 2017-02-27 20:20:24 --> Output Class Initialized
INFO - 2017-02-27 20:20:24 --> Security Class Initialized
DEBUG - 2017-02-27 20:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:20:24 --> Input Class Initialized
INFO - 2017-02-27 20:20:24 --> Language Class Initialized
INFO - 2017-02-27 20:20:24 --> Language Class Initialized
INFO - 2017-02-27 20:20:24 --> Config Class Initialized
INFO - 2017-02-27 20:20:24 --> Loader Class Initialized
INFO - 2017-02-27 20:20:24 --> Helper loaded: form_helper
INFO - 2017-02-27 20:20:24 --> Helper loaded: url_helper
INFO - 2017-02-27 20:20:24 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:20:24 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:20:24 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:20:24 --> Template Class Initialized
INFO - 2017-02-27 20:20:24 --> Model Class Initialized
INFO - 2017-02-27 20:20:24 --> Controller Class Initialized
DEBUG - 2017-02-27 20:20:24 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:20:24 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:20:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:20:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:20:24 --> Config Class Initialized
INFO - 2017-02-27 20:20:24 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:20:24 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:20:24 --> Utf8 Class Initialized
INFO - 2017-02-27 20:20:24 --> URI Class Initialized
INFO - 2017-02-27 20:20:24 --> Router Class Initialized
INFO - 2017-02-27 20:20:24 --> Output Class Initialized
INFO - 2017-02-27 20:20:24 --> Security Class Initialized
DEBUG - 2017-02-27 20:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:20:24 --> Input Class Initialized
INFO - 2017-02-27 20:20:24 --> Language Class Initialized
INFO - 2017-02-27 20:20:24 --> Language Class Initialized
INFO - 2017-02-27 20:20:24 --> Config Class Initialized
INFO - 2017-02-27 20:20:24 --> Loader Class Initialized
INFO - 2017-02-27 20:20:24 --> Helper loaded: form_helper
INFO - 2017-02-27 20:20:24 --> Helper loaded: url_helper
INFO - 2017-02-27 20:20:24 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:20:24 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:20:24 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:20:24 --> Template Class Initialized
INFO - 2017-02-27 20:20:24 --> Model Class Initialized
INFO - 2017-02-27 20:20:24 --> Controller Class Initialized
DEBUG - 2017-02-27 20:20:24 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:20:24 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:20:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:20:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:21:37 --> Config Class Initialized
INFO - 2017-02-27 20:21:37 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:21:37 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:21:37 --> Utf8 Class Initialized
INFO - 2017-02-27 20:21:37 --> URI Class Initialized
INFO - 2017-02-27 20:21:37 --> Router Class Initialized
INFO - 2017-02-27 20:21:37 --> Output Class Initialized
INFO - 2017-02-27 20:21:37 --> Security Class Initialized
DEBUG - 2017-02-27 20:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:21:37 --> Input Class Initialized
INFO - 2017-02-27 20:21:37 --> Language Class Initialized
INFO - 2017-02-27 20:21:37 --> Language Class Initialized
INFO - 2017-02-27 20:21:37 --> Config Class Initialized
INFO - 2017-02-27 20:21:37 --> Loader Class Initialized
INFO - 2017-02-27 20:21:37 --> Helper loaded: form_helper
INFO - 2017-02-27 20:21:37 --> Helper loaded: url_helper
INFO - 2017-02-27 20:21:37 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:21:37 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:21:37 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:21:37 --> Template Class Initialized
INFO - 2017-02-27 20:21:37 --> Model Class Initialized
INFO - 2017-02-27 20:21:37 --> Controller Class Initialized
DEBUG - 2017-02-27 20:21:37 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:21:37 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:21:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:21:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 20:21:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-02-27 20:21:37 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 20:21:37 --> Final output sent to browser
DEBUG - 2017-02-27 20:21:37 --> Total execution time: 0.0195
INFO - 2017-02-27 20:21:38 --> Config Class Initialized
INFO - 2017-02-27 20:21:38 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:21:38 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:21:38 --> Utf8 Class Initialized
INFO - 2017-02-27 20:21:38 --> URI Class Initialized
INFO - 2017-02-27 20:21:38 --> Router Class Initialized
INFO - 2017-02-27 20:21:38 --> Output Class Initialized
INFO - 2017-02-27 20:21:38 --> Security Class Initialized
DEBUG - 2017-02-27 20:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:21:38 --> Input Class Initialized
INFO - 2017-02-27 20:21:38 --> Language Class Initialized
INFO - 2017-02-27 20:21:38 --> Language Class Initialized
INFO - 2017-02-27 20:21:38 --> Config Class Initialized
INFO - 2017-02-27 20:21:38 --> Loader Class Initialized
INFO - 2017-02-27 20:21:38 --> Helper loaded: form_helper
INFO - 2017-02-27 20:21:38 --> Helper loaded: url_helper
INFO - 2017-02-27 20:21:38 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:21:38 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:21:38 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:21:38 --> Template Class Initialized
INFO - 2017-02-27 20:21:38 --> Model Class Initialized
INFO - 2017-02-27 20:21:38 --> Controller Class Initialized
DEBUG - 2017-02-27 20:21:38 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:21:38 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:21:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:21:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:21:52 --> Config Class Initialized
INFO - 2017-02-27 20:21:52 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:21:52 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:21:52 --> Utf8 Class Initialized
INFO - 2017-02-27 20:21:52 --> URI Class Initialized
INFO - 2017-02-27 20:21:52 --> Router Class Initialized
INFO - 2017-02-27 20:21:52 --> Output Class Initialized
INFO - 2017-02-27 20:21:52 --> Security Class Initialized
DEBUG - 2017-02-27 20:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:21:52 --> Input Class Initialized
INFO - 2017-02-27 20:21:52 --> Language Class Initialized
INFO - 2017-02-27 20:21:52 --> Language Class Initialized
INFO - 2017-02-27 20:21:52 --> Config Class Initialized
INFO - 2017-02-27 20:21:52 --> Loader Class Initialized
INFO - 2017-02-27 20:21:52 --> Helper loaded: form_helper
INFO - 2017-02-27 20:21:52 --> Helper loaded: url_helper
INFO - 2017-02-27 20:21:52 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:21:52 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:21:52 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:21:52 --> Template Class Initialized
INFO - 2017-02-27 20:21:52 --> Model Class Initialized
INFO - 2017-02-27 20:21:52 --> Controller Class Initialized
DEBUG - 2017-02-27 20:21:52 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:21:52 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:21:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:21:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 20:21:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-02-27 20:21:52 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 20:21:52 --> Final output sent to browser
DEBUG - 2017-02-27 20:21:52 --> Total execution time: 0.0221
INFO - 2017-02-27 20:21:52 --> Config Class Initialized
INFO - 2017-02-27 20:21:52 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:21:52 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:21:52 --> Utf8 Class Initialized
INFO - 2017-02-27 20:21:52 --> URI Class Initialized
INFO - 2017-02-27 20:21:52 --> Router Class Initialized
INFO - 2017-02-27 20:21:52 --> Output Class Initialized
INFO - 2017-02-27 20:21:52 --> Security Class Initialized
DEBUG - 2017-02-27 20:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:21:53 --> Input Class Initialized
INFO - 2017-02-27 20:21:53 --> Language Class Initialized
INFO - 2017-02-27 20:21:53 --> Language Class Initialized
INFO - 2017-02-27 20:21:53 --> Config Class Initialized
INFO - 2017-02-27 20:21:53 --> Loader Class Initialized
INFO - 2017-02-27 20:21:53 --> Helper loaded: form_helper
INFO - 2017-02-27 20:21:53 --> Helper loaded: url_helper
INFO - 2017-02-27 20:21:53 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:21:53 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:21:53 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:21:53 --> Template Class Initialized
INFO - 2017-02-27 20:21:53 --> Model Class Initialized
INFO - 2017-02-27 20:21:53 --> Controller Class Initialized
DEBUG - 2017-02-27 20:21:53 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:21:53 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:21:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:21:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:22:06 --> Config Class Initialized
INFO - 2017-02-27 20:22:06 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:22:06 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:22:06 --> Utf8 Class Initialized
INFO - 2017-02-27 20:22:06 --> URI Class Initialized
INFO - 2017-02-27 20:22:06 --> Router Class Initialized
INFO - 2017-02-27 20:22:06 --> Output Class Initialized
INFO - 2017-02-27 20:22:06 --> Security Class Initialized
DEBUG - 2017-02-27 20:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:22:06 --> Input Class Initialized
INFO - 2017-02-27 20:22:06 --> Language Class Initialized
INFO - 2017-02-27 20:22:06 --> Language Class Initialized
INFO - 2017-02-27 20:22:06 --> Config Class Initialized
INFO - 2017-02-27 20:22:06 --> Loader Class Initialized
INFO - 2017-02-27 20:22:06 --> Helper loaded: form_helper
INFO - 2017-02-27 20:22:06 --> Helper loaded: url_helper
INFO - 2017-02-27 20:22:06 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:22:06 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:22:06 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:22:06 --> Template Class Initialized
INFO - 2017-02-27 20:22:06 --> Model Class Initialized
INFO - 2017-02-27 20:22:06 --> Controller Class Initialized
DEBUG - 2017-02-27 20:22:06 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:22:06 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:22:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:22:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 20:22:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-02-27 20:22:06 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 20:22:06 --> Final output sent to browser
DEBUG - 2017-02-27 20:22:06 --> Total execution time: 0.0159
INFO - 2017-02-27 20:22:06 --> Config Class Initialized
INFO - 2017-02-27 20:22:06 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:22:06 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:22:06 --> Utf8 Class Initialized
INFO - 2017-02-27 20:22:06 --> URI Class Initialized
INFO - 2017-02-27 20:22:06 --> Router Class Initialized
INFO - 2017-02-27 20:22:06 --> Output Class Initialized
INFO - 2017-02-27 20:22:06 --> Security Class Initialized
DEBUG - 2017-02-27 20:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:22:06 --> Input Class Initialized
INFO - 2017-02-27 20:22:06 --> Language Class Initialized
INFO - 2017-02-27 20:22:06 --> Language Class Initialized
INFO - 2017-02-27 20:22:06 --> Config Class Initialized
INFO - 2017-02-27 20:22:06 --> Loader Class Initialized
INFO - 2017-02-27 20:22:06 --> Helper loaded: form_helper
INFO - 2017-02-27 20:22:06 --> Helper loaded: url_helper
INFO - 2017-02-27 20:22:06 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:22:06 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:22:06 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:22:06 --> Template Class Initialized
INFO - 2017-02-27 20:22:06 --> Model Class Initialized
INFO - 2017-02-27 20:22:06 --> Controller Class Initialized
DEBUG - 2017-02-27 20:22:06 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:22:06 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:22:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:22:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:22:25 --> Config Class Initialized
INFO - 2017-02-27 20:22:25 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:22:25 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:22:25 --> Utf8 Class Initialized
INFO - 2017-02-27 20:22:25 --> URI Class Initialized
INFO - 2017-02-27 20:22:25 --> Router Class Initialized
INFO - 2017-02-27 20:22:25 --> Output Class Initialized
INFO - 2017-02-27 20:22:25 --> Security Class Initialized
DEBUG - 2017-02-27 20:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:22:25 --> Input Class Initialized
INFO - 2017-02-27 20:22:25 --> Language Class Initialized
INFO - 2017-02-27 20:22:25 --> Language Class Initialized
INFO - 2017-02-27 20:22:25 --> Config Class Initialized
INFO - 2017-02-27 20:22:25 --> Loader Class Initialized
INFO - 2017-02-27 20:22:25 --> Helper loaded: form_helper
INFO - 2017-02-27 20:22:25 --> Helper loaded: url_helper
INFO - 2017-02-27 20:22:25 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:22:25 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:22:25 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:22:25 --> Template Class Initialized
INFO - 2017-02-27 20:22:25 --> Model Class Initialized
INFO - 2017-02-27 20:22:25 --> Controller Class Initialized
DEBUG - 2017-02-27 20:22:25 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:22:25 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:22:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:22:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:22:27 --> Config Class Initialized
INFO - 2017-02-27 20:22:27 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:22:27 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:22:27 --> Utf8 Class Initialized
INFO - 2017-02-27 20:22:27 --> URI Class Initialized
INFO - 2017-02-27 20:22:27 --> Router Class Initialized
INFO - 2017-02-27 20:22:27 --> Output Class Initialized
INFO - 2017-02-27 20:22:27 --> Security Class Initialized
DEBUG - 2017-02-27 20:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:22:27 --> Input Class Initialized
INFO - 2017-02-27 20:22:27 --> Language Class Initialized
INFO - 2017-02-27 20:22:27 --> Language Class Initialized
INFO - 2017-02-27 20:22:27 --> Config Class Initialized
INFO - 2017-02-27 20:22:27 --> Loader Class Initialized
INFO - 2017-02-27 20:22:27 --> Helper loaded: form_helper
INFO - 2017-02-27 20:22:27 --> Helper loaded: url_helper
INFO - 2017-02-27 20:22:27 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:22:27 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:22:27 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:22:27 --> Template Class Initialized
INFO - 2017-02-27 20:22:27 --> Model Class Initialized
INFO - 2017-02-27 20:22:27 --> Controller Class Initialized
DEBUG - 2017-02-27 20:22:27 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:22:27 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:22:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:22:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 20:22:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-02-27 20:22:27 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 20:22:27 --> Final output sent to browser
DEBUG - 2017-02-27 20:22:27 --> Total execution time: 0.0147
INFO - 2017-02-27 20:22:28 --> Config Class Initialized
INFO - 2017-02-27 20:22:28 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:22:28 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:22:28 --> Utf8 Class Initialized
INFO - 2017-02-27 20:22:28 --> URI Class Initialized
INFO - 2017-02-27 20:22:28 --> Router Class Initialized
INFO - 2017-02-27 20:22:28 --> Output Class Initialized
INFO - 2017-02-27 20:22:28 --> Security Class Initialized
DEBUG - 2017-02-27 20:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:22:28 --> Input Class Initialized
INFO - 2017-02-27 20:22:28 --> Language Class Initialized
INFO - 2017-02-27 20:22:28 --> Language Class Initialized
INFO - 2017-02-27 20:22:28 --> Config Class Initialized
INFO - 2017-02-27 20:22:28 --> Loader Class Initialized
INFO - 2017-02-27 20:22:28 --> Helper loaded: form_helper
INFO - 2017-02-27 20:22:28 --> Helper loaded: url_helper
INFO - 2017-02-27 20:22:28 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:22:28 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:22:28 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:22:28 --> Template Class Initialized
INFO - 2017-02-27 20:22:28 --> Model Class Initialized
INFO - 2017-02-27 20:22:28 --> Controller Class Initialized
DEBUG - 2017-02-27 20:22:28 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:22:28 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:22:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:22:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:22:30 --> Config Class Initialized
INFO - 2017-02-27 20:22:30 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:22:30 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:22:30 --> Utf8 Class Initialized
INFO - 2017-02-27 20:22:30 --> URI Class Initialized
DEBUG - 2017-02-27 20:22:30 --> No URI present. Default controller set.
INFO - 2017-02-27 20:22:30 --> Router Class Initialized
INFO - 2017-02-27 20:22:30 --> Output Class Initialized
INFO - 2017-02-27 20:22:30 --> Security Class Initialized
DEBUG - 2017-02-27 20:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:22:30 --> Input Class Initialized
INFO - 2017-02-27 20:22:30 --> Language Class Initialized
INFO - 2017-02-27 20:22:30 --> Language Class Initialized
INFO - 2017-02-27 20:22:30 --> Config Class Initialized
INFO - 2017-02-27 20:22:30 --> Loader Class Initialized
INFO - 2017-02-27 20:22:30 --> Helper loaded: form_helper
INFO - 2017-02-27 20:22:30 --> Helper loaded: url_helper
INFO - 2017-02-27 20:22:30 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:22:30 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:22:30 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:22:30 --> Template Class Initialized
INFO - 2017-02-27 20:22:30 --> Model Class Initialized
INFO - 2017-02-27 20:22:30 --> Controller Class Initialized
DEBUG - 2017-02-27 20:22:30 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:22:30 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:22:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:22:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 20:22:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-27 20:22:30 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 20:22:30 --> Final output sent to browser
DEBUG - 2017-02-27 20:22:30 --> Total execution time: 0.0152
INFO - 2017-02-27 20:22:30 --> Config Class Initialized
INFO - 2017-02-27 20:22:30 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:22:30 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:22:30 --> Utf8 Class Initialized
INFO - 2017-02-27 20:22:30 --> URI Class Initialized
INFO - 2017-02-27 20:22:30 --> Router Class Initialized
INFO - 2017-02-27 20:22:30 --> Output Class Initialized
INFO - 2017-02-27 20:22:30 --> Security Class Initialized
DEBUG - 2017-02-27 20:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:22:30 --> Input Class Initialized
INFO - 2017-02-27 20:22:30 --> Language Class Initialized
INFO - 2017-02-27 20:22:30 --> Language Class Initialized
INFO - 2017-02-27 20:22:30 --> Config Class Initialized
INFO - 2017-02-27 20:22:30 --> Loader Class Initialized
INFO - 2017-02-27 20:22:30 --> Helper loaded: form_helper
INFO - 2017-02-27 20:22:30 --> Helper loaded: url_helper
INFO - 2017-02-27 20:22:30 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:22:30 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:22:30 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:22:30 --> Template Class Initialized
INFO - 2017-02-27 20:22:30 --> Model Class Initialized
INFO - 2017-02-27 20:22:30 --> Controller Class Initialized
DEBUG - 2017-02-27 20:22:30 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:22:30 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:22:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:22:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:22:30 --> Config Class Initialized
INFO - 2017-02-27 20:22:30 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:22:30 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:22:30 --> Utf8 Class Initialized
INFO - 2017-02-27 20:22:30 --> URI Class Initialized
INFO - 2017-02-27 20:22:30 --> Router Class Initialized
INFO - 2017-02-27 20:22:30 --> Output Class Initialized
INFO - 2017-02-27 20:22:30 --> Security Class Initialized
DEBUG - 2017-02-27 20:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:22:30 --> Input Class Initialized
INFO - 2017-02-27 20:22:30 --> Language Class Initialized
INFO - 2017-02-27 20:22:30 --> Language Class Initialized
INFO - 2017-02-27 20:22:30 --> Config Class Initialized
INFO - 2017-02-27 20:22:30 --> Loader Class Initialized
INFO - 2017-02-27 20:22:30 --> Helper loaded: form_helper
INFO - 2017-02-27 20:22:30 --> Helper loaded: url_helper
INFO - 2017-02-27 20:22:30 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:22:30 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:22:30 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:22:30 --> Template Class Initialized
INFO - 2017-02-27 20:22:30 --> Model Class Initialized
INFO - 2017-02-27 20:22:30 --> Controller Class Initialized
DEBUG - 2017-02-27 20:22:30 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:22:30 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:22:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:22:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:22:53 --> Config Class Initialized
INFO - 2017-02-27 20:22:53 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:22:53 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:22:53 --> Utf8 Class Initialized
INFO - 2017-02-27 20:22:53 --> URI Class Initialized
INFO - 2017-02-27 20:22:53 --> Router Class Initialized
INFO - 2017-02-27 20:22:53 --> Output Class Initialized
INFO - 2017-02-27 20:22:53 --> Security Class Initialized
DEBUG - 2017-02-27 20:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:22:53 --> Input Class Initialized
INFO - 2017-02-27 20:22:53 --> Language Class Initialized
INFO - 2017-02-27 20:22:53 --> Language Class Initialized
INFO - 2017-02-27 20:22:53 --> Config Class Initialized
INFO - 2017-02-27 20:22:53 --> Loader Class Initialized
INFO - 2017-02-27 20:22:53 --> Helper loaded: form_helper
INFO - 2017-02-27 20:22:53 --> Helper loaded: url_helper
INFO - 2017-02-27 20:22:53 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:22:53 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:22:53 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:22:53 --> Template Class Initialized
INFO - 2017-02-27 20:22:53 --> Model Class Initialized
INFO - 2017-02-27 20:22:53 --> Controller Class Initialized
DEBUG - 2017-02-27 20:22:53 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:22:53 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:22:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:22:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 20:22:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-02-27 20:22:53 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 20:22:53 --> Final output sent to browser
DEBUG - 2017-02-27 20:22:53 --> Total execution time: 0.0171
INFO - 2017-02-27 20:22:54 --> Config Class Initialized
INFO - 2017-02-27 20:22:54 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:22:54 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:22:54 --> Utf8 Class Initialized
INFO - 2017-02-27 20:22:54 --> URI Class Initialized
INFO - 2017-02-27 20:22:54 --> Router Class Initialized
INFO - 2017-02-27 20:22:54 --> Output Class Initialized
INFO - 2017-02-27 20:22:54 --> Security Class Initialized
DEBUG - 2017-02-27 20:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:22:54 --> Input Class Initialized
INFO - 2017-02-27 20:22:54 --> Language Class Initialized
INFO - 2017-02-27 20:22:54 --> Language Class Initialized
INFO - 2017-02-27 20:22:54 --> Config Class Initialized
INFO - 2017-02-27 20:22:54 --> Loader Class Initialized
INFO - 2017-02-27 20:22:54 --> Helper loaded: form_helper
INFO - 2017-02-27 20:22:54 --> Helper loaded: url_helper
INFO - 2017-02-27 20:22:54 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:22:54 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:22:54 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:22:54 --> Template Class Initialized
INFO - 2017-02-27 20:22:54 --> Model Class Initialized
INFO - 2017-02-27 20:22:54 --> Controller Class Initialized
DEBUG - 2017-02-27 20:22:54 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:22:54 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:22:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:22:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:22:56 --> Config Class Initialized
INFO - 2017-02-27 20:22:56 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:22:56 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:22:56 --> Utf8 Class Initialized
INFO - 2017-02-27 20:22:56 --> URI Class Initialized
DEBUG - 2017-02-27 20:22:56 --> No URI present. Default controller set.
INFO - 2017-02-27 20:22:56 --> Router Class Initialized
INFO - 2017-02-27 20:22:56 --> Output Class Initialized
INFO - 2017-02-27 20:22:56 --> Security Class Initialized
DEBUG - 2017-02-27 20:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:22:56 --> Input Class Initialized
INFO - 2017-02-27 20:22:56 --> Language Class Initialized
INFO - 2017-02-27 20:22:56 --> Language Class Initialized
INFO - 2017-02-27 20:22:56 --> Config Class Initialized
INFO - 2017-02-27 20:22:56 --> Loader Class Initialized
INFO - 2017-02-27 20:22:56 --> Helper loaded: form_helper
INFO - 2017-02-27 20:22:56 --> Helper loaded: url_helper
INFO - 2017-02-27 20:22:56 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:22:56 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:22:56 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:22:56 --> Template Class Initialized
INFO - 2017-02-27 20:22:56 --> Model Class Initialized
INFO - 2017-02-27 20:22:56 --> Controller Class Initialized
DEBUG - 2017-02-27 20:22:56 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:22:56 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:22:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:22:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 20:22:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-27 20:22:56 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 20:22:56 --> Final output sent to browser
DEBUG - 2017-02-27 20:22:56 --> Total execution time: 0.0151
INFO - 2017-02-27 20:22:56 --> Config Class Initialized
INFO - 2017-02-27 20:22:56 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:22:56 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:22:56 --> Utf8 Class Initialized
INFO - 2017-02-27 20:22:56 --> URI Class Initialized
INFO - 2017-02-27 20:22:56 --> Router Class Initialized
INFO - 2017-02-27 20:22:56 --> Output Class Initialized
INFO - 2017-02-27 20:22:56 --> Security Class Initialized
DEBUG - 2017-02-27 20:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:22:56 --> Input Class Initialized
INFO - 2017-02-27 20:22:56 --> Language Class Initialized
INFO - 2017-02-27 20:22:56 --> Language Class Initialized
INFO - 2017-02-27 20:22:56 --> Config Class Initialized
INFO - 2017-02-27 20:22:56 --> Loader Class Initialized
INFO - 2017-02-27 20:22:56 --> Helper loaded: form_helper
INFO - 2017-02-27 20:22:56 --> Helper loaded: url_helper
INFO - 2017-02-27 20:22:56 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:22:56 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:22:56 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:22:56 --> Template Class Initialized
INFO - 2017-02-27 20:22:56 --> Model Class Initialized
INFO - 2017-02-27 20:22:56 --> Controller Class Initialized
DEBUG - 2017-02-27 20:22:56 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:22:56 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:22:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:22:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:22:56 --> Config Class Initialized
INFO - 2017-02-27 20:22:56 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:22:56 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:22:56 --> Utf8 Class Initialized
INFO - 2017-02-27 20:22:56 --> URI Class Initialized
INFO - 2017-02-27 20:22:56 --> Router Class Initialized
INFO - 2017-02-27 20:22:56 --> Output Class Initialized
INFO - 2017-02-27 20:22:56 --> Security Class Initialized
DEBUG - 2017-02-27 20:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:22:56 --> Input Class Initialized
INFO - 2017-02-27 20:22:56 --> Language Class Initialized
INFO - 2017-02-27 20:22:56 --> Language Class Initialized
INFO - 2017-02-27 20:22:56 --> Config Class Initialized
INFO - 2017-02-27 20:22:56 --> Loader Class Initialized
INFO - 2017-02-27 20:22:56 --> Helper loaded: form_helper
INFO - 2017-02-27 20:22:56 --> Helper loaded: url_helper
INFO - 2017-02-27 20:22:56 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:22:56 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:22:56 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:22:56 --> Template Class Initialized
INFO - 2017-02-27 20:22:56 --> Model Class Initialized
INFO - 2017-02-27 20:22:56 --> Controller Class Initialized
DEBUG - 2017-02-27 20:22:56 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:22:56 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:22:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:22:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:22:59 --> Config Class Initialized
INFO - 2017-02-27 20:22:59 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:22:59 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:22:59 --> Utf8 Class Initialized
INFO - 2017-02-27 20:22:59 --> URI Class Initialized
INFO - 2017-02-27 20:22:59 --> Router Class Initialized
INFO - 2017-02-27 20:22:59 --> Output Class Initialized
INFO - 2017-02-27 20:22:59 --> Security Class Initialized
DEBUG - 2017-02-27 20:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:22:59 --> Input Class Initialized
INFO - 2017-02-27 20:22:59 --> Language Class Initialized
INFO - 2017-02-27 20:22:59 --> Language Class Initialized
INFO - 2017-02-27 20:22:59 --> Config Class Initialized
INFO - 2017-02-27 20:22:59 --> Loader Class Initialized
INFO - 2017-02-27 20:22:59 --> Helper loaded: form_helper
INFO - 2017-02-27 20:22:59 --> Helper loaded: url_helper
INFO - 2017-02-27 20:22:59 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:22:59 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:22:59 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:22:59 --> Template Class Initialized
INFO - 2017-02-27 20:22:59 --> Model Class Initialized
INFO - 2017-02-27 20:22:59 --> Controller Class Initialized
DEBUG - 2017-02-27 20:22:59 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:22:59 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:22:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:22:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 20:22:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/about_us.php
DEBUG - 2017-02-27 20:22:59 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 20:22:59 --> Final output sent to browser
DEBUG - 2017-02-27 20:22:59 --> Total execution time: 0.0167
INFO - 2017-02-27 20:22:59 --> Config Class Initialized
INFO - 2017-02-27 20:22:59 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:22:59 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:22:59 --> Utf8 Class Initialized
INFO - 2017-02-27 20:22:59 --> URI Class Initialized
INFO - 2017-02-27 20:22:59 --> Router Class Initialized
INFO - 2017-02-27 20:22:59 --> Output Class Initialized
INFO - 2017-02-27 20:22:59 --> Security Class Initialized
DEBUG - 2017-02-27 20:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:22:59 --> Input Class Initialized
INFO - 2017-02-27 20:22:59 --> Language Class Initialized
INFO - 2017-02-27 20:22:59 --> Language Class Initialized
INFO - 2017-02-27 20:22:59 --> Config Class Initialized
INFO - 2017-02-27 20:22:59 --> Loader Class Initialized
INFO - 2017-02-27 20:22:59 --> Helper loaded: form_helper
INFO - 2017-02-27 20:22:59 --> Helper loaded: url_helper
INFO - 2017-02-27 20:22:59 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:22:59 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:22:59 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:22:59 --> Template Class Initialized
INFO - 2017-02-27 20:22:59 --> Model Class Initialized
INFO - 2017-02-27 20:22:59 --> Controller Class Initialized
DEBUG - 2017-02-27 20:22:59 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:22:59 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:22:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:22:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:23:01 --> Config Class Initialized
INFO - 2017-02-27 20:23:01 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:23:01 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:23:01 --> Utf8 Class Initialized
INFO - 2017-02-27 20:23:01 --> URI Class Initialized
INFO - 2017-02-27 20:23:01 --> Router Class Initialized
INFO - 2017-02-27 20:23:01 --> Output Class Initialized
INFO - 2017-02-27 20:23:01 --> Security Class Initialized
DEBUG - 2017-02-27 20:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:23:01 --> Input Class Initialized
INFO - 2017-02-27 20:23:01 --> Language Class Initialized
INFO - 2017-02-27 20:23:01 --> Language Class Initialized
INFO - 2017-02-27 20:23:01 --> Config Class Initialized
INFO - 2017-02-27 20:23:01 --> Loader Class Initialized
INFO - 2017-02-27 20:23:01 --> Helper loaded: form_helper
INFO - 2017-02-27 20:23:01 --> Helper loaded: url_helper
INFO - 2017-02-27 20:23:01 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:23:01 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:23:01 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:23:01 --> Template Class Initialized
INFO - 2017-02-27 20:23:01 --> Model Class Initialized
INFO - 2017-02-27 20:23:01 --> Controller Class Initialized
DEBUG - 2017-02-27 20:23:01 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:23:01 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:23:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:23:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 20:23:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/support.php
DEBUG - 2017-02-27 20:23:01 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 20:23:01 --> Final output sent to browser
DEBUG - 2017-02-27 20:23:01 --> Total execution time: 0.0142
INFO - 2017-02-27 20:23:02 --> Config Class Initialized
INFO - 2017-02-27 20:23:02 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:23:02 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:23:02 --> Utf8 Class Initialized
INFO - 2017-02-27 20:23:02 --> URI Class Initialized
INFO - 2017-02-27 20:23:02 --> Router Class Initialized
INFO - 2017-02-27 20:23:02 --> Output Class Initialized
INFO - 2017-02-27 20:23:02 --> Security Class Initialized
DEBUG - 2017-02-27 20:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:23:02 --> Input Class Initialized
INFO - 2017-02-27 20:23:02 --> Language Class Initialized
INFO - 2017-02-27 20:23:02 --> Language Class Initialized
INFO - 2017-02-27 20:23:02 --> Config Class Initialized
INFO - 2017-02-27 20:23:02 --> Loader Class Initialized
INFO - 2017-02-27 20:23:02 --> Helper loaded: form_helper
INFO - 2017-02-27 20:23:02 --> Helper loaded: url_helper
INFO - 2017-02-27 20:23:02 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:23:02 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:23:02 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:23:02 --> Template Class Initialized
INFO - 2017-02-27 20:23:02 --> Model Class Initialized
INFO - 2017-02-27 20:23:02 --> Controller Class Initialized
DEBUG - 2017-02-27 20:23:02 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:23:02 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:23:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:23:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:23:06 --> Config Class Initialized
INFO - 2017-02-27 20:23:06 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:23:06 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:23:06 --> Utf8 Class Initialized
INFO - 2017-02-27 20:23:06 --> URI Class Initialized
INFO - 2017-02-27 20:23:06 --> Router Class Initialized
INFO - 2017-02-27 20:23:06 --> Output Class Initialized
INFO - 2017-02-27 20:23:06 --> Security Class Initialized
DEBUG - 2017-02-27 20:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:23:06 --> Input Class Initialized
INFO - 2017-02-27 20:23:06 --> Language Class Initialized
INFO - 2017-02-27 20:23:06 --> Language Class Initialized
INFO - 2017-02-27 20:23:06 --> Config Class Initialized
INFO - 2017-02-27 20:23:06 --> Loader Class Initialized
INFO - 2017-02-27 20:23:06 --> Helper loaded: form_helper
INFO - 2017-02-27 20:23:06 --> Helper loaded: url_helper
INFO - 2017-02-27 20:23:06 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:23:06 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:23:06 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:23:06 --> Template Class Initialized
INFO - 2017-02-27 20:23:06 --> Model Class Initialized
INFO - 2017-02-27 20:23:06 --> Controller Class Initialized
DEBUG - 2017-02-27 20:23:06 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:23:06 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:23:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:23:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 20:23:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-02-27 20:23:06 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 20:23:06 --> Final output sent to browser
DEBUG - 2017-02-27 20:23:06 --> Total execution time: 0.0131
INFO - 2017-02-27 20:23:06 --> Config Class Initialized
INFO - 2017-02-27 20:23:06 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:23:06 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:23:06 --> Utf8 Class Initialized
INFO - 2017-02-27 20:23:06 --> URI Class Initialized
INFO - 2017-02-27 20:23:06 --> Router Class Initialized
INFO - 2017-02-27 20:23:06 --> Output Class Initialized
INFO - 2017-02-27 20:23:06 --> Security Class Initialized
DEBUG - 2017-02-27 20:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:23:06 --> Input Class Initialized
INFO - 2017-02-27 20:23:06 --> Language Class Initialized
INFO - 2017-02-27 20:23:06 --> Language Class Initialized
INFO - 2017-02-27 20:23:06 --> Config Class Initialized
INFO - 2017-02-27 20:23:06 --> Loader Class Initialized
INFO - 2017-02-27 20:23:06 --> Helper loaded: form_helper
INFO - 2017-02-27 20:23:06 --> Helper loaded: url_helper
INFO - 2017-02-27 20:23:06 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:23:06 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:23:06 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:23:06 --> Template Class Initialized
INFO - 2017-02-27 20:23:06 --> Model Class Initialized
INFO - 2017-02-27 20:23:06 --> Controller Class Initialized
DEBUG - 2017-02-27 20:23:06 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:23:06 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:23:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:23:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:23:08 --> Config Class Initialized
INFO - 2017-02-27 20:23:08 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:23:08 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:23:08 --> Utf8 Class Initialized
INFO - 2017-02-27 20:23:08 --> URI Class Initialized
DEBUG - 2017-02-27 20:23:08 --> No URI present. Default controller set.
INFO - 2017-02-27 20:23:08 --> Router Class Initialized
INFO - 2017-02-27 20:23:08 --> Output Class Initialized
INFO - 2017-02-27 20:23:08 --> Security Class Initialized
DEBUG - 2017-02-27 20:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:23:08 --> Input Class Initialized
INFO - 2017-02-27 20:23:08 --> Language Class Initialized
INFO - 2017-02-27 20:23:08 --> Language Class Initialized
INFO - 2017-02-27 20:23:08 --> Config Class Initialized
INFO - 2017-02-27 20:23:08 --> Loader Class Initialized
INFO - 2017-02-27 20:23:08 --> Helper loaded: form_helper
INFO - 2017-02-27 20:23:08 --> Helper loaded: url_helper
INFO - 2017-02-27 20:23:08 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:23:08 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:23:08 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:23:08 --> Template Class Initialized
INFO - 2017-02-27 20:23:08 --> Model Class Initialized
INFO - 2017-02-27 20:23:08 --> Controller Class Initialized
DEBUG - 2017-02-27 20:23:08 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:23:08 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:23:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:23:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 20:23:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-27 20:23:08 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 20:23:08 --> Final output sent to browser
DEBUG - 2017-02-27 20:23:08 --> Total execution time: 0.0155
INFO - 2017-02-27 20:23:09 --> Config Class Initialized
INFO - 2017-02-27 20:23:09 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:23:09 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:23:09 --> Utf8 Class Initialized
INFO - 2017-02-27 20:23:09 --> URI Class Initialized
INFO - 2017-02-27 20:23:09 --> Router Class Initialized
INFO - 2017-02-27 20:23:09 --> Output Class Initialized
INFO - 2017-02-27 20:23:09 --> Security Class Initialized
DEBUG - 2017-02-27 20:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:23:09 --> Input Class Initialized
INFO - 2017-02-27 20:23:09 --> Language Class Initialized
INFO - 2017-02-27 20:23:09 --> Language Class Initialized
INFO - 2017-02-27 20:23:09 --> Config Class Initialized
INFO - 2017-02-27 20:23:09 --> Loader Class Initialized
INFO - 2017-02-27 20:23:09 --> Helper loaded: form_helper
INFO - 2017-02-27 20:23:09 --> Helper loaded: url_helper
INFO - 2017-02-27 20:23:09 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:23:09 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:23:09 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:23:09 --> Template Class Initialized
INFO - 2017-02-27 20:23:09 --> Model Class Initialized
INFO - 2017-02-27 20:23:09 --> Controller Class Initialized
DEBUG - 2017-02-27 20:23:09 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:23:09 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:23:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:23:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:23:09 --> Config Class Initialized
INFO - 2017-02-27 20:23:09 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:23:09 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:23:09 --> Utf8 Class Initialized
INFO - 2017-02-27 20:23:09 --> URI Class Initialized
INFO - 2017-02-27 20:23:09 --> Router Class Initialized
INFO - 2017-02-27 20:23:09 --> Output Class Initialized
INFO - 2017-02-27 20:23:09 --> Security Class Initialized
DEBUG - 2017-02-27 20:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:23:09 --> Input Class Initialized
INFO - 2017-02-27 20:23:09 --> Language Class Initialized
INFO - 2017-02-27 20:23:09 --> Language Class Initialized
INFO - 2017-02-27 20:23:09 --> Config Class Initialized
INFO - 2017-02-27 20:23:09 --> Loader Class Initialized
INFO - 2017-02-27 20:23:09 --> Helper loaded: form_helper
INFO - 2017-02-27 20:23:09 --> Helper loaded: url_helper
INFO - 2017-02-27 20:23:09 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:23:09 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:23:09 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:23:09 --> Template Class Initialized
INFO - 2017-02-27 20:23:09 --> Model Class Initialized
INFO - 2017-02-27 20:23:09 --> Controller Class Initialized
DEBUG - 2017-02-27 20:23:09 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:23:09 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:23:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:23:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:23:49 --> Config Class Initialized
INFO - 2017-02-27 20:23:49 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:23:49 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:23:49 --> Utf8 Class Initialized
INFO - 2017-02-27 20:23:49 --> URI Class Initialized
INFO - 2017-02-27 20:23:49 --> Router Class Initialized
INFO - 2017-02-27 20:23:49 --> Output Class Initialized
INFO - 2017-02-27 20:23:49 --> Security Class Initialized
DEBUG - 2017-02-27 20:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:23:49 --> Input Class Initialized
INFO - 2017-02-27 20:23:49 --> Language Class Initialized
INFO - 2017-02-27 20:23:49 --> Language Class Initialized
INFO - 2017-02-27 20:23:49 --> Config Class Initialized
INFO - 2017-02-27 20:23:49 --> Loader Class Initialized
INFO - 2017-02-27 20:23:49 --> Helper loaded: form_helper
INFO - 2017-02-27 20:23:49 --> Helper loaded: url_helper
INFO - 2017-02-27 20:23:49 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:23:49 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:23:49 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:23:49 --> Template Class Initialized
INFO - 2017-02-27 20:23:49 --> Model Class Initialized
INFO - 2017-02-27 20:23:49 --> Controller Class Initialized
DEBUG - 2017-02-27 20:23:49 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:23:49 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:23:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:23:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 20:23:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/about_us.php
DEBUG - 2017-02-27 20:23:49 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 20:23:49 --> Final output sent to browser
DEBUG - 2017-02-27 20:23:49 --> Total execution time: 0.0161
INFO - 2017-02-27 20:23:50 --> Config Class Initialized
INFO - 2017-02-27 20:23:50 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:23:50 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:23:50 --> Utf8 Class Initialized
INFO - 2017-02-27 20:23:50 --> URI Class Initialized
INFO - 2017-02-27 20:23:50 --> Router Class Initialized
INFO - 2017-02-27 20:23:50 --> Output Class Initialized
INFO - 2017-02-27 20:23:50 --> Security Class Initialized
DEBUG - 2017-02-27 20:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:23:50 --> Input Class Initialized
INFO - 2017-02-27 20:23:50 --> Language Class Initialized
INFO - 2017-02-27 20:23:50 --> Language Class Initialized
INFO - 2017-02-27 20:23:50 --> Config Class Initialized
INFO - 2017-02-27 20:23:50 --> Loader Class Initialized
INFO - 2017-02-27 20:23:50 --> Helper loaded: form_helper
INFO - 2017-02-27 20:23:50 --> Helper loaded: url_helper
INFO - 2017-02-27 20:23:50 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:23:50 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:23:50 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:23:50 --> Template Class Initialized
INFO - 2017-02-27 20:23:50 --> Model Class Initialized
INFO - 2017-02-27 20:23:50 --> Controller Class Initialized
DEBUG - 2017-02-27 20:23:50 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:23:50 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:23:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:23:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:23:57 --> Config Class Initialized
INFO - 2017-02-27 20:23:57 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:23:57 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:23:57 --> Utf8 Class Initialized
INFO - 2017-02-27 20:23:57 --> URI Class Initialized
INFO - 2017-02-27 20:23:57 --> Router Class Initialized
INFO - 2017-02-27 20:23:57 --> Output Class Initialized
INFO - 2017-02-27 20:23:57 --> Security Class Initialized
DEBUG - 2017-02-27 20:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:23:57 --> Input Class Initialized
INFO - 2017-02-27 20:23:57 --> Language Class Initialized
INFO - 2017-02-27 20:23:57 --> Language Class Initialized
INFO - 2017-02-27 20:23:57 --> Config Class Initialized
INFO - 2017-02-27 20:23:57 --> Loader Class Initialized
INFO - 2017-02-27 20:23:57 --> Helper loaded: form_helper
INFO - 2017-02-27 20:23:57 --> Helper loaded: url_helper
INFO - 2017-02-27 20:23:57 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:23:57 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:23:57 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:23:57 --> Template Class Initialized
INFO - 2017-02-27 20:23:57 --> Model Class Initialized
INFO - 2017-02-27 20:23:57 --> Controller Class Initialized
DEBUG - 2017-02-27 20:23:57 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:23:57 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:23:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:23:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 20:23:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/support.php
DEBUG - 2017-02-27 20:23:57 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 20:23:57 --> Final output sent to browser
DEBUG - 2017-02-27 20:23:57 --> Total execution time: 0.0145
INFO - 2017-02-27 20:23:58 --> Config Class Initialized
INFO - 2017-02-27 20:23:58 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:23:58 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:23:58 --> Utf8 Class Initialized
INFO - 2017-02-27 20:23:58 --> URI Class Initialized
INFO - 2017-02-27 20:23:58 --> Router Class Initialized
INFO - 2017-02-27 20:23:58 --> Output Class Initialized
INFO - 2017-02-27 20:23:58 --> Security Class Initialized
DEBUG - 2017-02-27 20:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:23:58 --> Input Class Initialized
INFO - 2017-02-27 20:23:58 --> Language Class Initialized
INFO - 2017-02-27 20:23:58 --> Language Class Initialized
INFO - 2017-02-27 20:23:58 --> Config Class Initialized
INFO - 2017-02-27 20:23:58 --> Loader Class Initialized
INFO - 2017-02-27 20:23:58 --> Helper loaded: form_helper
INFO - 2017-02-27 20:23:58 --> Helper loaded: url_helper
INFO - 2017-02-27 20:23:58 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:23:58 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:23:58 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:23:58 --> Template Class Initialized
INFO - 2017-02-27 20:23:58 --> Model Class Initialized
INFO - 2017-02-27 20:23:58 --> Controller Class Initialized
DEBUG - 2017-02-27 20:23:58 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:23:58 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:23:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:23:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:24:25 --> Config Class Initialized
INFO - 2017-02-27 20:24:25 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:24:25 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:24:25 --> Utf8 Class Initialized
INFO - 2017-02-27 20:24:25 --> URI Class Initialized
INFO - 2017-02-27 20:24:25 --> Router Class Initialized
INFO - 2017-02-27 20:24:25 --> Output Class Initialized
INFO - 2017-02-27 20:24:25 --> Security Class Initialized
DEBUG - 2017-02-27 20:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:24:25 --> Input Class Initialized
INFO - 2017-02-27 20:24:25 --> Language Class Initialized
INFO - 2017-02-27 20:24:25 --> Language Class Initialized
INFO - 2017-02-27 20:24:25 --> Config Class Initialized
INFO - 2017-02-27 20:24:25 --> Loader Class Initialized
INFO - 2017-02-27 20:24:25 --> Helper loaded: form_helper
INFO - 2017-02-27 20:24:25 --> Helper loaded: url_helper
INFO - 2017-02-27 20:24:25 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:24:25 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:24:25 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:24:25 --> Template Class Initialized
INFO - 2017-02-27 20:24:25 --> Model Class Initialized
INFO - 2017-02-27 20:24:25 --> Controller Class Initialized
DEBUG - 2017-02-27 20:24:25 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:24:25 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:24:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:24:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 20:24:28 --> Config Class Initialized
INFO - 2017-02-27 20:24:28 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:24:28 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:24:28 --> Utf8 Class Initialized
INFO - 2017-02-27 20:24:28 --> URI Class Initialized
INFO - 2017-02-27 20:24:28 --> Router Class Initialized
INFO - 2017-02-27 20:24:28 --> Output Class Initialized
INFO - 2017-02-27 20:24:28 --> Security Class Initialized
DEBUG - 2017-02-27 20:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:24:28 --> Input Class Initialized
INFO - 2017-02-27 20:24:28 --> Language Class Initialized
INFO - 2017-02-27 20:24:28 --> Language Class Initialized
INFO - 2017-02-27 20:24:28 --> Config Class Initialized
INFO - 2017-02-27 20:24:28 --> Loader Class Initialized
INFO - 2017-02-27 20:24:28 --> Helper loaded: form_helper
INFO - 2017-02-27 20:24:28 --> Helper loaded: url_helper
INFO - 2017-02-27 20:24:28 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:24:28 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:24:28 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:24:28 --> Template Class Initialized
INFO - 2017-02-27 20:24:28 --> Model Class Initialized
INFO - 2017-02-27 20:24:28 --> Controller Class Initialized
DEBUG - 2017-02-27 20:24:28 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:24:28 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:24:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:24:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 20:24:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/support.php
DEBUG - 2017-02-27 20:24:28 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 20:24:28 --> Final output sent to browser
DEBUG - 2017-02-27 20:24:28 --> Total execution time: 0.0157
INFO - 2017-02-27 20:24:28 --> Config Class Initialized
INFO - 2017-02-27 20:24:28 --> Hooks Class Initialized
DEBUG - 2017-02-27 20:24:28 --> UTF-8 Support Enabled
INFO - 2017-02-27 20:24:28 --> Utf8 Class Initialized
INFO - 2017-02-27 20:24:28 --> URI Class Initialized
INFO - 2017-02-27 20:24:28 --> Router Class Initialized
INFO - 2017-02-27 20:24:28 --> Output Class Initialized
INFO - 2017-02-27 20:24:28 --> Security Class Initialized
DEBUG - 2017-02-27 20:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 20:24:28 --> Input Class Initialized
INFO - 2017-02-27 20:24:28 --> Language Class Initialized
INFO - 2017-02-27 20:24:28 --> Language Class Initialized
INFO - 2017-02-27 20:24:28 --> Config Class Initialized
INFO - 2017-02-27 20:24:28 --> Loader Class Initialized
INFO - 2017-02-27 20:24:28 --> Helper loaded: form_helper
INFO - 2017-02-27 20:24:28 --> Helper loaded: url_helper
INFO - 2017-02-27 20:24:28 --> Helper loaded: utility_helper
INFO - 2017-02-27 20:24:28 --> Database Driver Class Initialized
DEBUG - 2017-02-27 20:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 20:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 20:24:28 --> User Agent Class Initialized
DEBUG - 2017-02-27 20:24:28 --> Template Class Initialized
INFO - 2017-02-27 20:24:28 --> Model Class Initialized
INFO - 2017-02-27 20:24:28 --> Controller Class Initialized
DEBUG - 2017-02-27 20:24:28 --> Pages MX_Controller Initialized
INFO - 2017-02-27 20:24:28 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 20:24:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 20:24:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 21:44:40 --> Config Class Initialized
INFO - 2017-02-27 21:44:40 --> Hooks Class Initialized
DEBUG - 2017-02-27 21:44:40 --> UTF-8 Support Enabled
INFO - 2017-02-27 21:44:40 --> Utf8 Class Initialized
INFO - 2017-02-27 21:44:40 --> URI Class Initialized
INFO - 2017-02-27 21:44:40 --> Router Class Initialized
INFO - 2017-02-27 21:44:40 --> Output Class Initialized
INFO - 2017-02-27 21:44:40 --> Security Class Initialized
DEBUG - 2017-02-27 21:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:44:40 --> Input Class Initialized
INFO - 2017-02-27 21:44:40 --> Language Class Initialized
INFO - 2017-02-27 21:44:40 --> Language Class Initialized
INFO - 2017-02-27 21:44:40 --> Config Class Initialized
INFO - 2017-02-27 21:44:40 --> Loader Class Initialized
INFO - 2017-02-27 21:44:40 --> Helper loaded: form_helper
INFO - 2017-02-27 21:44:40 --> Helper loaded: url_helper
INFO - 2017-02-27 21:44:40 --> Helper loaded: utility_helper
INFO - 2017-02-27 21:44:40 --> Database Driver Class Initialized
DEBUG - 2017-02-27 21:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 21:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:44:40 --> User Agent Class Initialized
DEBUG - 2017-02-27 21:44:40 --> Template Class Initialized
INFO - 2017-02-27 21:44:40 --> Model Class Initialized
INFO - 2017-02-27 21:44:40 --> Controller Class Initialized
DEBUG - 2017-02-27 21:44:40 --> Pages MX_Controller Initialized
INFO - 2017-02-27 21:44:40 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 21:44:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 21:44:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 21:44:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-02-27 21:44:40 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 21:44:40 --> Final output sent to browser
DEBUG - 2017-02-27 21:44:40 --> Total execution time: 0.0589
INFO - 2017-02-27 21:44:41 --> Config Class Initialized
INFO - 2017-02-27 21:44:41 --> Hooks Class Initialized
DEBUG - 2017-02-27 21:44:41 --> UTF-8 Support Enabled
INFO - 2017-02-27 21:44:41 --> Utf8 Class Initialized
INFO - 2017-02-27 21:44:41 --> URI Class Initialized
INFO - 2017-02-27 21:44:41 --> Router Class Initialized
INFO - 2017-02-27 21:44:41 --> Output Class Initialized
INFO - 2017-02-27 21:44:41 --> Security Class Initialized
DEBUG - 2017-02-27 21:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 21:44:41 --> Input Class Initialized
INFO - 2017-02-27 21:44:41 --> Language Class Initialized
INFO - 2017-02-27 21:44:41 --> Language Class Initialized
INFO - 2017-02-27 21:44:41 --> Config Class Initialized
INFO - 2017-02-27 21:44:41 --> Loader Class Initialized
INFO - 2017-02-27 21:44:41 --> Helper loaded: form_helper
INFO - 2017-02-27 21:44:41 --> Helper loaded: url_helper
INFO - 2017-02-27 21:44:41 --> Helper loaded: utility_helper
INFO - 2017-02-27 21:44:41 --> Database Driver Class Initialized
DEBUG - 2017-02-27 21:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 21:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 21:44:41 --> User Agent Class Initialized
DEBUG - 2017-02-27 21:44:41 --> Template Class Initialized
INFO - 2017-02-27 21:44:41 --> Model Class Initialized
INFO - 2017-02-27 21:44:41 --> Controller Class Initialized
DEBUG - 2017-02-27 21:44:41 --> Pages MX_Controller Initialized
INFO - 2017-02-27 21:44:41 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 21:44:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 21:44:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 21:44:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-02-27 21:44:41 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 21:44:41 --> Final output sent to browser
DEBUG - 2017-02-27 21:44:41 --> Total execution time: 0.0155
INFO - 2017-02-27 22:27:33 --> Config Class Initialized
INFO - 2017-02-27 22:27:33 --> Hooks Class Initialized
DEBUG - 2017-02-27 22:27:33 --> UTF-8 Support Enabled
INFO - 2017-02-27 22:27:33 --> Utf8 Class Initialized
INFO - 2017-02-27 22:27:33 --> URI Class Initialized
INFO - 2017-02-27 22:27:33 --> Router Class Initialized
INFO - 2017-02-27 22:27:33 --> Output Class Initialized
INFO - 2017-02-27 22:27:33 --> Security Class Initialized
DEBUG - 2017-02-27 22:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 22:27:33 --> Input Class Initialized
INFO - 2017-02-27 22:27:33 --> Language Class Initialized
INFO - 2017-02-27 22:27:33 --> Language Class Initialized
INFO - 2017-02-27 22:27:33 --> Config Class Initialized
INFO - 2017-02-27 22:27:33 --> Loader Class Initialized
INFO - 2017-02-27 22:27:33 --> Helper loaded: form_helper
INFO - 2017-02-27 22:27:33 --> Helper loaded: url_helper
INFO - 2017-02-27 22:27:33 --> Helper loaded: utility_helper
INFO - 2017-02-27 22:27:33 --> Database Driver Class Initialized
DEBUG - 2017-02-27 22:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 22:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 22:27:33 --> User Agent Class Initialized
DEBUG - 2017-02-27 22:27:33 --> Template Class Initialized
INFO - 2017-02-27 22:27:33 --> Model Class Initialized
INFO - 2017-02-27 22:27:33 --> Controller Class Initialized
DEBUG - 2017-02-27 22:27:33 --> Pages MX_Controller Initialized
INFO - 2017-02-27 22:27:33 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 22:27:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 22:27:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 22:27:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-02-27 22:27:33 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 22:27:33 --> Final output sent to browser
DEBUG - 2017-02-27 22:27:33 --> Total execution time: 0.0739
INFO - 2017-02-27 22:27:33 --> Config Class Initialized
INFO - 2017-02-27 22:27:33 --> Hooks Class Initialized
DEBUG - 2017-02-27 22:27:33 --> UTF-8 Support Enabled
INFO - 2017-02-27 22:27:33 --> Utf8 Class Initialized
INFO - 2017-02-27 22:27:33 --> URI Class Initialized
INFO - 2017-02-27 22:27:33 --> Router Class Initialized
INFO - 2017-02-27 22:27:33 --> Output Class Initialized
INFO - 2017-02-27 22:27:33 --> Security Class Initialized
DEBUG - 2017-02-27 22:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 22:27:33 --> Input Class Initialized
INFO - 2017-02-27 22:27:33 --> Language Class Initialized
INFO - 2017-02-27 22:27:33 --> Language Class Initialized
INFO - 2017-02-27 22:27:33 --> Config Class Initialized
INFO - 2017-02-27 22:27:33 --> Loader Class Initialized
INFO - 2017-02-27 22:27:33 --> Helper loaded: form_helper
INFO - 2017-02-27 22:27:33 --> Helper loaded: url_helper
INFO - 2017-02-27 22:27:33 --> Helper loaded: utility_helper
INFO - 2017-02-27 22:27:33 --> Database Driver Class Initialized
DEBUG - 2017-02-27 22:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 22:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 22:27:33 --> User Agent Class Initialized
DEBUG - 2017-02-27 22:27:33 --> Template Class Initialized
INFO - 2017-02-27 22:27:33 --> Model Class Initialized
INFO - 2017-02-27 22:27:33 --> Controller Class Initialized
DEBUG - 2017-02-27 22:27:33 --> Pages MX_Controller Initialized
INFO - 2017-02-27 22:27:33 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 22:27:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 22:27:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-27 22:27:53 --> Config Class Initialized
INFO - 2017-02-27 22:27:53 --> Hooks Class Initialized
DEBUG - 2017-02-27 22:27:53 --> UTF-8 Support Enabled
INFO - 2017-02-27 22:27:53 --> Utf8 Class Initialized
INFO - 2017-02-27 22:27:53 --> URI Class Initialized
INFO - 2017-02-27 22:27:53 --> Router Class Initialized
INFO - 2017-02-27 22:27:53 --> Output Class Initialized
INFO - 2017-02-27 22:27:53 --> Security Class Initialized
DEBUG - 2017-02-27 22:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 22:27:53 --> Input Class Initialized
INFO - 2017-02-27 22:27:53 --> Language Class Initialized
INFO - 2017-02-27 22:27:53 --> Language Class Initialized
INFO - 2017-02-27 22:27:53 --> Config Class Initialized
INFO - 2017-02-27 22:27:53 --> Loader Class Initialized
INFO - 2017-02-27 22:27:53 --> Helper loaded: form_helper
INFO - 2017-02-27 22:27:53 --> Helper loaded: url_helper
INFO - 2017-02-27 22:27:53 --> Helper loaded: utility_helper
INFO - 2017-02-27 22:27:53 --> Database Driver Class Initialized
DEBUG - 2017-02-27 22:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 22:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 22:27:53 --> User Agent Class Initialized
DEBUG - 2017-02-27 22:27:53 --> Template Class Initialized
INFO - 2017-02-27 22:27:53 --> Model Class Initialized
INFO - 2017-02-27 22:27:53 --> Controller Class Initialized
DEBUG - 2017-02-27 22:27:53 --> Pages MX_Controller Initialized
INFO - 2017-02-27 22:27:53 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 22:27:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 22:27:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-27 22:27:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/support.php
DEBUG - 2017-02-27 22:27:53 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-27 22:27:53 --> Final output sent to browser
DEBUG - 2017-02-27 22:27:53 --> Total execution time: 0.0210
INFO - 2017-02-27 22:27:54 --> Config Class Initialized
INFO - 2017-02-27 22:27:54 --> Hooks Class Initialized
DEBUG - 2017-02-27 22:27:54 --> UTF-8 Support Enabled
INFO - 2017-02-27 22:27:54 --> Utf8 Class Initialized
INFO - 2017-02-27 22:27:54 --> URI Class Initialized
INFO - 2017-02-27 22:27:54 --> Router Class Initialized
INFO - 2017-02-27 22:27:54 --> Output Class Initialized
INFO - 2017-02-27 22:27:54 --> Security Class Initialized
DEBUG - 2017-02-27 22:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-27 22:27:54 --> Input Class Initialized
INFO - 2017-02-27 22:27:54 --> Language Class Initialized
INFO - 2017-02-27 22:27:54 --> Language Class Initialized
INFO - 2017-02-27 22:27:54 --> Config Class Initialized
INFO - 2017-02-27 22:27:54 --> Loader Class Initialized
INFO - 2017-02-27 22:27:54 --> Helper loaded: form_helper
INFO - 2017-02-27 22:27:54 --> Helper loaded: url_helper
INFO - 2017-02-27 22:27:54 --> Helper loaded: utility_helper
INFO - 2017-02-27 22:27:54 --> Database Driver Class Initialized
DEBUG - 2017-02-27 22:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-27 22:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-27 22:27:54 --> User Agent Class Initialized
DEBUG - 2017-02-27 22:27:54 --> Template Class Initialized
INFO - 2017-02-27 22:27:54 --> Model Class Initialized
INFO - 2017-02-27 22:27:54 --> Controller Class Initialized
DEBUG - 2017-02-27 22:27:54 --> Pages MX_Controller Initialized
INFO - 2017-02-27 22:27:54 --> Helper loaded: cookie_helper
DEBUG - 2017-02-27 22:27:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-27 22:27:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
