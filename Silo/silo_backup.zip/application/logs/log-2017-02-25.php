<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-25 00:05:46 --> Config Class Initialized
INFO - 2017-02-25 00:05:46 --> Hooks Class Initialized
DEBUG - 2017-02-25 00:05:46 --> UTF-8 Support Enabled
INFO - 2017-02-25 00:05:46 --> Utf8 Class Initialized
INFO - 2017-02-25 00:05:46 --> URI Class Initialized
DEBUG - 2017-02-25 00:05:46 --> No URI present. Default controller set.
INFO - 2017-02-25 00:05:46 --> Router Class Initialized
INFO - 2017-02-25 00:05:46 --> Output Class Initialized
INFO - 2017-02-25 00:05:46 --> Security Class Initialized
DEBUG - 2017-02-25 00:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 00:05:46 --> Input Class Initialized
INFO - 2017-02-25 00:05:46 --> Language Class Initialized
INFO - 2017-02-25 00:05:46 --> Language Class Initialized
INFO - 2017-02-25 00:05:46 --> Config Class Initialized
INFO - 2017-02-25 00:05:46 --> Loader Class Initialized
INFO - 2017-02-25 00:05:46 --> Helper loaded: form_helper
INFO - 2017-02-25 00:05:46 --> Helper loaded: url_helper
INFO - 2017-02-25 00:05:46 --> Helper loaded: utility_helper
INFO - 2017-02-25 00:05:46 --> Database Driver Class Initialized
DEBUG - 2017-02-25 00:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 00:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 00:05:46 --> User Agent Class Initialized
DEBUG - 2017-02-25 00:05:46 --> Template Class Initialized
INFO - 2017-02-25 00:05:46 --> Model Class Initialized
INFO - 2017-02-25 00:05:46 --> Controller Class Initialized
DEBUG - 2017-02-25 00:05:46 --> Pages MX_Controller Initialized
INFO - 2017-02-25 00:05:46 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 00:05:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 00:05:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 00:05:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-25 00:05:46 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 00:05:46 --> Final output sent to browser
DEBUG - 2017-02-25 00:05:46 --> Total execution time: 0.0604
INFO - 2017-02-25 00:05:47 --> Config Class Initialized
INFO - 2017-02-25 00:05:47 --> Hooks Class Initialized
DEBUG - 2017-02-25 00:05:47 --> UTF-8 Support Enabled
INFO - 2017-02-25 00:05:47 --> Utf8 Class Initialized
INFO - 2017-02-25 00:05:47 --> URI Class Initialized
INFO - 2017-02-25 00:05:47 --> Router Class Initialized
INFO - 2017-02-25 00:05:47 --> Output Class Initialized
INFO - 2017-02-25 00:05:47 --> Security Class Initialized
DEBUG - 2017-02-25 00:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 00:05:47 --> Input Class Initialized
INFO - 2017-02-25 00:05:47 --> Language Class Initialized
INFO - 2017-02-25 00:05:47 --> Language Class Initialized
INFO - 2017-02-25 00:05:47 --> Config Class Initialized
INFO - 2017-02-25 00:05:47 --> Loader Class Initialized
INFO - 2017-02-25 00:05:47 --> Helper loaded: form_helper
INFO - 2017-02-25 00:05:47 --> Helper loaded: url_helper
INFO - 2017-02-25 00:05:47 --> Helper loaded: utility_helper
INFO - 2017-02-25 00:05:47 --> Database Driver Class Initialized
DEBUG - 2017-02-25 00:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 00:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 00:05:47 --> User Agent Class Initialized
DEBUG - 2017-02-25 00:05:47 --> Template Class Initialized
INFO - 2017-02-25 00:05:47 --> Model Class Initialized
INFO - 2017-02-25 00:05:47 --> Controller Class Initialized
DEBUG - 2017-02-25 00:05:47 --> Pages MX_Controller Initialized
INFO - 2017-02-25 00:05:47 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 00:05:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 00:05:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 00:05:47 --> Config Class Initialized
INFO - 2017-02-25 00:05:47 --> Hooks Class Initialized
DEBUG - 2017-02-25 00:05:47 --> UTF-8 Support Enabled
INFO - 2017-02-25 00:05:47 --> Utf8 Class Initialized
INFO - 2017-02-25 00:05:47 --> URI Class Initialized
INFO - 2017-02-25 00:05:47 --> Router Class Initialized
INFO - 2017-02-25 00:05:47 --> Output Class Initialized
INFO - 2017-02-25 00:05:47 --> Security Class Initialized
DEBUG - 2017-02-25 00:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 00:05:47 --> Input Class Initialized
INFO - 2017-02-25 00:05:47 --> Language Class Initialized
INFO - 2017-02-25 00:05:47 --> Language Class Initialized
INFO - 2017-02-25 00:05:47 --> Config Class Initialized
INFO - 2017-02-25 00:05:47 --> Loader Class Initialized
INFO - 2017-02-25 00:05:47 --> Helper loaded: form_helper
INFO - 2017-02-25 00:05:47 --> Helper loaded: url_helper
INFO - 2017-02-25 00:05:47 --> Helper loaded: utility_helper
INFO - 2017-02-25 00:05:47 --> Database Driver Class Initialized
DEBUG - 2017-02-25 00:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 00:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 00:05:47 --> User Agent Class Initialized
DEBUG - 2017-02-25 00:05:47 --> Template Class Initialized
INFO - 2017-02-25 00:05:47 --> Model Class Initialized
INFO - 2017-02-25 00:05:47 --> Controller Class Initialized
DEBUG - 2017-02-25 00:05:47 --> Pages MX_Controller Initialized
INFO - 2017-02-25 00:05:47 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 00:05:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 00:05:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 01:23:24 --> Config Class Initialized
INFO - 2017-02-25 01:23:24 --> Hooks Class Initialized
DEBUG - 2017-02-25 01:23:24 --> UTF-8 Support Enabled
INFO - 2017-02-25 01:23:24 --> Utf8 Class Initialized
INFO - 2017-02-25 01:23:24 --> URI Class Initialized
DEBUG - 2017-02-25 01:23:24 --> No URI present. Default controller set.
INFO - 2017-02-25 01:23:24 --> Router Class Initialized
INFO - 2017-02-25 01:23:24 --> Output Class Initialized
INFO - 2017-02-25 01:23:24 --> Security Class Initialized
DEBUG - 2017-02-25 01:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 01:23:24 --> Input Class Initialized
INFO - 2017-02-25 01:23:24 --> Language Class Initialized
INFO - 2017-02-25 01:23:24 --> Language Class Initialized
INFO - 2017-02-25 01:23:24 --> Config Class Initialized
INFO - 2017-02-25 01:23:24 --> Loader Class Initialized
INFO - 2017-02-25 01:23:24 --> Helper loaded: form_helper
INFO - 2017-02-25 01:23:24 --> Helper loaded: url_helper
INFO - 2017-02-25 01:23:24 --> Helper loaded: utility_helper
INFO - 2017-02-25 01:23:24 --> Database Driver Class Initialized
DEBUG - 2017-02-25 01:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 01:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 01:23:24 --> User Agent Class Initialized
DEBUG - 2017-02-25 01:23:24 --> Template Class Initialized
INFO - 2017-02-25 01:23:24 --> Model Class Initialized
INFO - 2017-02-25 01:23:24 --> Controller Class Initialized
DEBUG - 2017-02-25 01:23:24 --> Pages MX_Controller Initialized
INFO - 2017-02-25 01:23:24 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 01:23:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 01:23:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 01:23:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-25 01:23:24 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 01:23:24 --> Final output sent to browser
DEBUG - 2017-02-25 01:23:24 --> Total execution time: 0.0429
INFO - 2017-02-25 01:55:16 --> Config Class Initialized
INFO - 2017-02-25 01:55:16 --> Hooks Class Initialized
DEBUG - 2017-02-25 01:55:16 --> UTF-8 Support Enabled
INFO - 2017-02-25 01:55:16 --> Utf8 Class Initialized
INFO - 2017-02-25 01:55:16 --> URI Class Initialized
INFO - 2017-02-25 01:55:16 --> Router Class Initialized
INFO - 2017-02-25 01:55:16 --> Output Class Initialized
INFO - 2017-02-25 01:55:16 --> Security Class Initialized
DEBUG - 2017-02-25 01:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 01:55:16 --> Input Class Initialized
INFO - 2017-02-25 01:55:16 --> Language Class Initialized
INFO - 2017-02-25 01:55:16 --> Language Class Initialized
INFO - 2017-02-25 01:55:16 --> Config Class Initialized
INFO - 2017-02-25 01:55:16 --> Loader Class Initialized
INFO - 2017-02-25 01:55:16 --> Helper loaded: form_helper
INFO - 2017-02-25 01:55:16 --> Helper loaded: url_helper
INFO - 2017-02-25 01:55:16 --> Helper loaded: utility_helper
INFO - 2017-02-25 01:55:16 --> Database Driver Class Initialized
DEBUG - 2017-02-25 01:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 01:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 01:55:16 --> User Agent Class Initialized
DEBUG - 2017-02-25 01:55:16 --> Template Class Initialized
INFO - 2017-02-25 01:55:16 --> Model Class Initialized
INFO - 2017-02-25 01:55:16 --> Controller Class Initialized
DEBUG - 2017-02-25 01:55:16 --> Pages MX_Controller Initialized
INFO - 2017-02-25 01:55:16 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 01:55:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 01:55:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 01:55:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-02-25 01:55:16 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 01:55:16 --> Final output sent to browser
DEBUG - 2017-02-25 01:55:16 --> Total execution time: 0.0705
INFO - 2017-02-25 01:55:19 --> Config Class Initialized
INFO - 2017-02-25 01:55:19 --> Hooks Class Initialized
DEBUG - 2017-02-25 01:55:19 --> UTF-8 Support Enabled
INFO - 2017-02-25 01:55:19 --> Utf8 Class Initialized
INFO - 2017-02-25 01:55:19 --> URI Class Initialized
INFO - 2017-02-25 01:55:19 --> Router Class Initialized
INFO - 2017-02-25 01:55:19 --> Output Class Initialized
INFO - 2017-02-25 01:55:19 --> Security Class Initialized
DEBUG - 2017-02-25 01:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 01:55:19 --> Input Class Initialized
INFO - 2017-02-25 01:55:19 --> Language Class Initialized
INFO - 2017-02-25 01:55:19 --> Language Class Initialized
INFO - 2017-02-25 01:55:19 --> Config Class Initialized
INFO - 2017-02-25 01:55:19 --> Loader Class Initialized
INFO - 2017-02-25 01:55:19 --> Helper loaded: form_helper
INFO - 2017-02-25 01:55:19 --> Helper loaded: url_helper
INFO - 2017-02-25 01:55:19 --> Helper loaded: utility_helper
INFO - 2017-02-25 01:55:19 --> Database Driver Class Initialized
DEBUG - 2017-02-25 01:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 01:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 01:55:19 --> User Agent Class Initialized
DEBUG - 2017-02-25 01:55:19 --> Template Class Initialized
INFO - 2017-02-25 01:55:19 --> Model Class Initialized
INFO - 2017-02-25 01:55:19 --> Controller Class Initialized
DEBUG - 2017-02-25 01:55:19 --> Pages MX_Controller Initialized
INFO - 2017-02-25 01:55:19 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 01:55:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 01:55:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 01:56:34 --> Config Class Initialized
INFO - 2017-02-25 01:56:34 --> Hooks Class Initialized
DEBUG - 2017-02-25 01:56:34 --> UTF-8 Support Enabled
INFO - 2017-02-25 01:56:34 --> Utf8 Class Initialized
INFO - 2017-02-25 01:56:34 --> URI Class Initialized
INFO - 2017-02-25 01:56:34 --> Router Class Initialized
INFO - 2017-02-25 01:56:34 --> Output Class Initialized
INFO - 2017-02-25 01:56:34 --> Security Class Initialized
DEBUG - 2017-02-25 01:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 01:56:34 --> Input Class Initialized
INFO - 2017-02-25 01:56:34 --> Language Class Initialized
INFO - 2017-02-25 01:56:34 --> Language Class Initialized
INFO - 2017-02-25 01:56:34 --> Config Class Initialized
INFO - 2017-02-25 01:56:34 --> Loader Class Initialized
INFO - 2017-02-25 01:56:34 --> Helper loaded: form_helper
INFO - 2017-02-25 01:56:34 --> Helper loaded: url_helper
INFO - 2017-02-25 01:56:34 --> Helper loaded: utility_helper
INFO - 2017-02-25 01:56:34 --> Database Driver Class Initialized
DEBUG - 2017-02-25 01:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 01:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 01:56:34 --> User Agent Class Initialized
DEBUG - 2017-02-25 01:56:34 --> Template Class Initialized
INFO - 2017-02-25 01:56:34 --> Model Class Initialized
INFO - 2017-02-25 01:56:34 --> Controller Class Initialized
DEBUG - 2017-02-25 01:56:34 --> Pages MX_Controller Initialized
INFO - 2017-02-25 01:56:34 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 01:56:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 01:56:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 01:56:36 --> Config Class Initialized
INFO - 2017-02-25 01:56:36 --> Hooks Class Initialized
DEBUG - 2017-02-25 01:56:36 --> UTF-8 Support Enabled
INFO - 2017-02-25 01:56:36 --> Utf8 Class Initialized
INFO - 2017-02-25 01:56:36 --> URI Class Initialized
INFO - 2017-02-25 01:56:36 --> Router Class Initialized
INFO - 2017-02-25 01:56:36 --> Output Class Initialized
INFO - 2017-02-25 01:56:36 --> Security Class Initialized
DEBUG - 2017-02-25 01:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 01:56:36 --> Input Class Initialized
INFO - 2017-02-25 01:56:36 --> Language Class Initialized
INFO - 2017-02-25 01:56:36 --> Language Class Initialized
INFO - 2017-02-25 01:56:36 --> Config Class Initialized
INFO - 2017-02-25 01:56:36 --> Loader Class Initialized
INFO - 2017-02-25 01:56:36 --> Helper loaded: form_helper
INFO - 2017-02-25 01:56:36 --> Helper loaded: url_helper
INFO - 2017-02-25 01:56:36 --> Helper loaded: utility_helper
INFO - 2017-02-25 01:56:36 --> Database Driver Class Initialized
DEBUG - 2017-02-25 01:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 01:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 01:56:36 --> User Agent Class Initialized
DEBUG - 2017-02-25 01:56:36 --> Template Class Initialized
INFO - 2017-02-25 01:56:36 --> Model Class Initialized
INFO - 2017-02-25 01:56:36 --> Controller Class Initialized
DEBUG - 2017-02-25 01:56:36 --> Pages MX_Controller Initialized
INFO - 2017-02-25 01:56:36 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 01:56:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 01:56:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 01:56:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-02-25 01:56:36 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 01:56:36 --> Final output sent to browser
DEBUG - 2017-02-25 01:56:36 --> Total execution time: 0.0175
INFO - 2017-02-25 01:56:37 --> Config Class Initialized
INFO - 2017-02-25 01:56:37 --> Hooks Class Initialized
DEBUG - 2017-02-25 01:56:37 --> UTF-8 Support Enabled
INFO - 2017-02-25 01:56:37 --> Utf8 Class Initialized
INFO - 2017-02-25 01:56:37 --> URI Class Initialized
INFO - 2017-02-25 01:56:37 --> Router Class Initialized
INFO - 2017-02-25 01:56:37 --> Output Class Initialized
INFO - 2017-02-25 01:56:37 --> Security Class Initialized
DEBUG - 2017-02-25 01:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 01:56:37 --> Input Class Initialized
INFO - 2017-02-25 01:56:37 --> Language Class Initialized
INFO - 2017-02-25 01:56:37 --> Language Class Initialized
INFO - 2017-02-25 01:56:37 --> Config Class Initialized
INFO - 2017-02-25 01:56:37 --> Loader Class Initialized
INFO - 2017-02-25 01:56:37 --> Helper loaded: form_helper
INFO - 2017-02-25 01:56:37 --> Helper loaded: url_helper
INFO - 2017-02-25 01:56:37 --> Helper loaded: utility_helper
INFO - 2017-02-25 01:56:37 --> Database Driver Class Initialized
DEBUG - 2017-02-25 01:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 01:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 01:56:37 --> User Agent Class Initialized
DEBUG - 2017-02-25 01:56:37 --> Template Class Initialized
INFO - 2017-02-25 01:56:37 --> Model Class Initialized
INFO - 2017-02-25 01:56:37 --> Controller Class Initialized
DEBUG - 2017-02-25 01:56:37 --> Pages MX_Controller Initialized
INFO - 2017-02-25 01:56:37 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 01:56:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 01:56:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 01:56:40 --> Config Class Initialized
INFO - 2017-02-25 01:56:40 --> Hooks Class Initialized
DEBUG - 2017-02-25 01:56:40 --> UTF-8 Support Enabled
INFO - 2017-02-25 01:56:40 --> Utf8 Class Initialized
INFO - 2017-02-25 01:56:40 --> URI Class Initialized
DEBUG - 2017-02-25 01:56:40 --> No URI present. Default controller set.
INFO - 2017-02-25 01:56:40 --> Router Class Initialized
INFO - 2017-02-25 01:56:40 --> Output Class Initialized
INFO - 2017-02-25 01:56:40 --> Security Class Initialized
DEBUG - 2017-02-25 01:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 01:56:40 --> Input Class Initialized
INFO - 2017-02-25 01:56:40 --> Language Class Initialized
INFO - 2017-02-25 01:56:40 --> Language Class Initialized
INFO - 2017-02-25 01:56:40 --> Config Class Initialized
INFO - 2017-02-25 01:56:40 --> Loader Class Initialized
INFO - 2017-02-25 01:56:40 --> Helper loaded: form_helper
INFO - 2017-02-25 01:56:40 --> Helper loaded: url_helper
INFO - 2017-02-25 01:56:40 --> Helper loaded: utility_helper
INFO - 2017-02-25 01:56:40 --> Database Driver Class Initialized
DEBUG - 2017-02-25 01:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 01:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 01:56:40 --> User Agent Class Initialized
DEBUG - 2017-02-25 01:56:40 --> Template Class Initialized
INFO - 2017-02-25 01:56:40 --> Model Class Initialized
INFO - 2017-02-25 01:56:40 --> Controller Class Initialized
DEBUG - 2017-02-25 01:56:40 --> Pages MX_Controller Initialized
INFO - 2017-02-25 01:56:40 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 01:56:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 01:56:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 01:56:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-25 01:56:40 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 01:56:40 --> Final output sent to browser
DEBUG - 2017-02-25 01:56:40 --> Total execution time: 0.0145
INFO - 2017-02-25 01:56:40 --> Config Class Initialized
INFO - 2017-02-25 01:56:40 --> Hooks Class Initialized
DEBUG - 2017-02-25 01:56:40 --> UTF-8 Support Enabled
INFO - 2017-02-25 01:56:40 --> Utf8 Class Initialized
INFO - 2017-02-25 01:56:40 --> URI Class Initialized
INFO - 2017-02-25 01:56:40 --> Router Class Initialized
INFO - 2017-02-25 01:56:40 --> Output Class Initialized
INFO - 2017-02-25 01:56:40 --> Security Class Initialized
DEBUG - 2017-02-25 01:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 01:56:40 --> Input Class Initialized
INFO - 2017-02-25 01:56:40 --> Language Class Initialized
INFO - 2017-02-25 01:56:40 --> Language Class Initialized
INFO - 2017-02-25 01:56:40 --> Config Class Initialized
INFO - 2017-02-25 01:56:40 --> Loader Class Initialized
INFO - 2017-02-25 01:56:40 --> Helper loaded: form_helper
INFO - 2017-02-25 01:56:40 --> Helper loaded: url_helper
INFO - 2017-02-25 01:56:40 --> Helper loaded: utility_helper
INFO - 2017-02-25 01:56:40 --> Database Driver Class Initialized
DEBUG - 2017-02-25 01:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 01:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 01:56:40 --> User Agent Class Initialized
DEBUG - 2017-02-25 01:56:40 --> Template Class Initialized
INFO - 2017-02-25 01:56:40 --> Model Class Initialized
INFO - 2017-02-25 01:56:40 --> Controller Class Initialized
DEBUG - 2017-02-25 01:56:40 --> Pages MX_Controller Initialized
INFO - 2017-02-25 01:56:40 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 01:56:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 01:56:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 01:56:41 --> Config Class Initialized
INFO - 2017-02-25 01:56:41 --> Hooks Class Initialized
DEBUG - 2017-02-25 01:56:41 --> UTF-8 Support Enabled
INFO - 2017-02-25 01:56:41 --> Utf8 Class Initialized
INFO - 2017-02-25 01:56:41 --> URI Class Initialized
INFO - 2017-02-25 01:56:41 --> Router Class Initialized
INFO - 2017-02-25 01:56:41 --> Output Class Initialized
INFO - 2017-02-25 01:56:41 --> Security Class Initialized
DEBUG - 2017-02-25 01:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 01:56:41 --> Input Class Initialized
INFO - 2017-02-25 01:56:41 --> Language Class Initialized
INFO - 2017-02-25 01:56:41 --> Language Class Initialized
INFO - 2017-02-25 01:56:41 --> Config Class Initialized
INFO - 2017-02-25 01:56:41 --> Loader Class Initialized
INFO - 2017-02-25 01:56:41 --> Helper loaded: form_helper
INFO - 2017-02-25 01:56:41 --> Helper loaded: url_helper
INFO - 2017-02-25 01:56:41 --> Helper loaded: utility_helper
INFO - 2017-02-25 01:56:41 --> Database Driver Class Initialized
DEBUG - 2017-02-25 01:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 01:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 01:56:41 --> User Agent Class Initialized
DEBUG - 2017-02-25 01:56:41 --> Template Class Initialized
INFO - 2017-02-25 01:56:41 --> Model Class Initialized
INFO - 2017-02-25 01:56:41 --> Controller Class Initialized
DEBUG - 2017-02-25 01:56:41 --> Pages MX_Controller Initialized
INFO - 2017-02-25 01:56:41 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 01:56:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 01:56:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 01:57:11 --> Config Class Initialized
INFO - 2017-02-25 01:57:11 --> Hooks Class Initialized
DEBUG - 2017-02-25 01:57:11 --> UTF-8 Support Enabled
INFO - 2017-02-25 01:57:11 --> Utf8 Class Initialized
INFO - 2017-02-25 01:57:11 --> URI Class Initialized
INFO - 2017-02-25 01:57:11 --> Router Class Initialized
INFO - 2017-02-25 01:57:11 --> Output Class Initialized
INFO - 2017-02-25 01:57:11 --> Security Class Initialized
DEBUG - 2017-02-25 01:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 01:57:11 --> Input Class Initialized
INFO - 2017-02-25 01:57:11 --> Language Class Initialized
INFO - 2017-02-25 01:57:11 --> Language Class Initialized
INFO - 2017-02-25 01:57:11 --> Config Class Initialized
INFO - 2017-02-25 01:57:11 --> Loader Class Initialized
INFO - 2017-02-25 01:57:11 --> Helper loaded: form_helper
INFO - 2017-02-25 01:57:11 --> Helper loaded: url_helper
INFO - 2017-02-25 01:57:11 --> Helper loaded: utility_helper
INFO - 2017-02-25 01:57:11 --> Database Driver Class Initialized
DEBUG - 2017-02-25 01:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 01:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 01:57:11 --> User Agent Class Initialized
DEBUG - 2017-02-25 01:57:11 --> Template Class Initialized
INFO - 2017-02-25 01:57:11 --> Model Class Initialized
INFO - 2017-02-25 01:57:11 --> Controller Class Initialized
DEBUG - 2017-02-25 01:57:11 --> Pages MX_Controller Initialized
INFO - 2017-02-25 01:57:11 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 01:57:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 01:57:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 01:57:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/about_us.php
DEBUG - 2017-02-25 01:57:11 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 01:57:11 --> Final output sent to browser
DEBUG - 2017-02-25 01:57:11 --> Total execution time: 0.0234
INFO - 2017-02-25 01:57:11 --> Config Class Initialized
INFO - 2017-02-25 01:57:11 --> Hooks Class Initialized
DEBUG - 2017-02-25 01:57:11 --> UTF-8 Support Enabled
INFO - 2017-02-25 01:57:11 --> Utf8 Class Initialized
INFO - 2017-02-25 01:57:11 --> URI Class Initialized
INFO - 2017-02-25 01:57:11 --> Router Class Initialized
INFO - 2017-02-25 01:57:11 --> Output Class Initialized
INFO - 2017-02-25 01:57:11 --> Security Class Initialized
DEBUG - 2017-02-25 01:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 01:57:11 --> Input Class Initialized
INFO - 2017-02-25 01:57:11 --> Language Class Initialized
INFO - 2017-02-25 01:57:11 --> Language Class Initialized
INFO - 2017-02-25 01:57:11 --> Config Class Initialized
INFO - 2017-02-25 01:57:11 --> Loader Class Initialized
INFO - 2017-02-25 01:57:11 --> Helper loaded: form_helper
INFO - 2017-02-25 01:57:11 --> Helper loaded: url_helper
INFO - 2017-02-25 01:57:11 --> Helper loaded: utility_helper
INFO - 2017-02-25 01:57:11 --> Database Driver Class Initialized
DEBUG - 2017-02-25 01:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 01:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 01:57:11 --> User Agent Class Initialized
DEBUG - 2017-02-25 01:57:11 --> Template Class Initialized
INFO - 2017-02-25 01:57:11 --> Model Class Initialized
INFO - 2017-02-25 01:57:11 --> Controller Class Initialized
DEBUG - 2017-02-25 01:57:11 --> Pages MX_Controller Initialized
INFO - 2017-02-25 01:57:11 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 01:57:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 01:57:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 01:59:11 --> Config Class Initialized
INFO - 2017-02-25 01:59:11 --> Hooks Class Initialized
DEBUG - 2017-02-25 01:59:11 --> UTF-8 Support Enabled
INFO - 2017-02-25 01:59:11 --> Utf8 Class Initialized
INFO - 2017-02-25 01:59:11 --> URI Class Initialized
INFO - 2017-02-25 01:59:11 --> Router Class Initialized
INFO - 2017-02-25 01:59:11 --> Output Class Initialized
INFO - 2017-02-25 01:59:11 --> Security Class Initialized
DEBUG - 2017-02-25 01:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 01:59:11 --> Input Class Initialized
INFO - 2017-02-25 01:59:11 --> Language Class Initialized
INFO - 2017-02-25 01:59:11 --> Language Class Initialized
INFO - 2017-02-25 01:59:11 --> Config Class Initialized
INFO - 2017-02-25 01:59:11 --> Loader Class Initialized
INFO - 2017-02-25 01:59:11 --> Helper loaded: form_helper
INFO - 2017-02-25 01:59:11 --> Helper loaded: url_helper
INFO - 2017-02-25 01:59:11 --> Helper loaded: utility_helper
INFO - 2017-02-25 01:59:11 --> Database Driver Class Initialized
DEBUG - 2017-02-25 01:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 01:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 01:59:11 --> User Agent Class Initialized
DEBUG - 2017-02-25 01:59:11 --> Template Class Initialized
INFO - 2017-02-25 01:59:11 --> Model Class Initialized
INFO - 2017-02-25 01:59:11 --> Controller Class Initialized
DEBUG - 2017-02-25 01:59:11 --> Pages MX_Controller Initialized
INFO - 2017-02-25 01:59:11 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 01:59:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 01:59:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 01:59:13 --> Config Class Initialized
INFO - 2017-02-25 01:59:13 --> Hooks Class Initialized
DEBUG - 2017-02-25 01:59:13 --> UTF-8 Support Enabled
INFO - 2017-02-25 01:59:13 --> Utf8 Class Initialized
INFO - 2017-02-25 01:59:13 --> URI Class Initialized
INFO - 2017-02-25 01:59:13 --> Router Class Initialized
INFO - 2017-02-25 01:59:13 --> Output Class Initialized
INFO - 2017-02-25 01:59:13 --> Security Class Initialized
DEBUG - 2017-02-25 01:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 01:59:13 --> Input Class Initialized
INFO - 2017-02-25 01:59:13 --> Language Class Initialized
INFO - 2017-02-25 01:59:13 --> Language Class Initialized
INFO - 2017-02-25 01:59:13 --> Config Class Initialized
INFO - 2017-02-25 01:59:13 --> Loader Class Initialized
INFO - 2017-02-25 01:59:13 --> Helper loaded: form_helper
INFO - 2017-02-25 01:59:13 --> Helper loaded: url_helper
INFO - 2017-02-25 01:59:13 --> Helper loaded: utility_helper
INFO - 2017-02-25 01:59:13 --> Database Driver Class Initialized
DEBUG - 2017-02-25 01:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 01:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 01:59:13 --> User Agent Class Initialized
DEBUG - 2017-02-25 01:59:13 --> Template Class Initialized
INFO - 2017-02-25 01:59:13 --> Model Class Initialized
INFO - 2017-02-25 01:59:13 --> Controller Class Initialized
DEBUG - 2017-02-25 01:59:13 --> Pages MX_Controller Initialized
INFO - 2017-02-25 01:59:13 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 01:59:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 01:59:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 01:59:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/about_us.php
DEBUG - 2017-02-25 01:59:13 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 01:59:13 --> Final output sent to browser
DEBUG - 2017-02-25 01:59:13 --> Total execution time: 0.0167
INFO - 2017-02-25 01:59:14 --> Config Class Initialized
INFO - 2017-02-25 01:59:14 --> Hooks Class Initialized
DEBUG - 2017-02-25 01:59:14 --> UTF-8 Support Enabled
INFO - 2017-02-25 01:59:14 --> Utf8 Class Initialized
INFO - 2017-02-25 01:59:14 --> URI Class Initialized
INFO - 2017-02-25 01:59:14 --> Router Class Initialized
INFO - 2017-02-25 01:59:14 --> Output Class Initialized
INFO - 2017-02-25 01:59:14 --> Security Class Initialized
DEBUG - 2017-02-25 01:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 01:59:14 --> Input Class Initialized
INFO - 2017-02-25 01:59:14 --> Language Class Initialized
INFO - 2017-02-25 01:59:14 --> Language Class Initialized
INFO - 2017-02-25 01:59:14 --> Config Class Initialized
INFO - 2017-02-25 01:59:14 --> Loader Class Initialized
INFO - 2017-02-25 01:59:14 --> Helper loaded: form_helper
INFO - 2017-02-25 01:59:14 --> Helper loaded: url_helper
INFO - 2017-02-25 01:59:14 --> Helper loaded: utility_helper
INFO - 2017-02-25 01:59:14 --> Database Driver Class Initialized
DEBUG - 2017-02-25 01:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 01:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 01:59:14 --> User Agent Class Initialized
DEBUG - 2017-02-25 01:59:14 --> Template Class Initialized
INFO - 2017-02-25 01:59:14 --> Model Class Initialized
INFO - 2017-02-25 01:59:14 --> Controller Class Initialized
DEBUG - 2017-02-25 01:59:14 --> Pages MX_Controller Initialized
INFO - 2017-02-25 01:59:14 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 01:59:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 01:59:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 02:02:24 --> Config Class Initialized
INFO - 2017-02-25 02:02:24 --> Hooks Class Initialized
DEBUG - 2017-02-25 02:02:24 --> UTF-8 Support Enabled
INFO - 2017-02-25 02:02:24 --> Utf8 Class Initialized
INFO - 2017-02-25 02:02:24 --> URI Class Initialized
DEBUG - 2017-02-25 02:02:24 --> No URI present. Default controller set.
INFO - 2017-02-25 02:02:24 --> Router Class Initialized
INFO - 2017-02-25 02:02:24 --> Output Class Initialized
INFO - 2017-02-25 02:02:24 --> Security Class Initialized
DEBUG - 2017-02-25 02:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 02:02:24 --> Input Class Initialized
INFO - 2017-02-25 02:02:24 --> Language Class Initialized
INFO - 2017-02-25 02:02:24 --> Language Class Initialized
INFO - 2017-02-25 02:02:24 --> Config Class Initialized
INFO - 2017-02-25 02:02:24 --> Loader Class Initialized
INFO - 2017-02-25 02:02:24 --> Helper loaded: form_helper
INFO - 2017-02-25 02:02:24 --> Helper loaded: url_helper
INFO - 2017-02-25 02:02:24 --> Helper loaded: utility_helper
INFO - 2017-02-25 02:02:24 --> Database Driver Class Initialized
DEBUG - 2017-02-25 02:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 02:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 02:02:24 --> User Agent Class Initialized
DEBUG - 2017-02-25 02:02:24 --> Template Class Initialized
INFO - 2017-02-25 02:02:24 --> Model Class Initialized
INFO - 2017-02-25 02:02:24 --> Controller Class Initialized
DEBUG - 2017-02-25 02:02:24 --> Pages MX_Controller Initialized
INFO - 2017-02-25 02:02:24 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 02:02:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 02:02:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 02:02:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-25 02:02:24 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 02:02:24 --> Final output sent to browser
DEBUG - 2017-02-25 02:02:24 --> Total execution time: 0.0618
INFO - 2017-02-25 02:02:24 --> Config Class Initialized
INFO - 2017-02-25 02:02:24 --> Hooks Class Initialized
DEBUG - 2017-02-25 02:02:24 --> UTF-8 Support Enabled
INFO - 2017-02-25 02:02:24 --> Utf8 Class Initialized
INFO - 2017-02-25 02:02:24 --> URI Class Initialized
INFO - 2017-02-25 02:02:24 --> Router Class Initialized
INFO - 2017-02-25 02:02:24 --> Output Class Initialized
INFO - 2017-02-25 02:02:24 --> Security Class Initialized
DEBUG - 2017-02-25 02:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 02:02:24 --> Input Class Initialized
INFO - 2017-02-25 02:02:24 --> Language Class Initialized
INFO - 2017-02-25 02:02:24 --> Language Class Initialized
INFO - 2017-02-25 02:02:24 --> Config Class Initialized
INFO - 2017-02-25 02:02:24 --> Loader Class Initialized
INFO - 2017-02-25 02:02:24 --> Helper loaded: form_helper
INFO - 2017-02-25 02:02:24 --> Helper loaded: url_helper
INFO - 2017-02-25 02:02:24 --> Helper loaded: utility_helper
INFO - 2017-02-25 02:02:24 --> Database Driver Class Initialized
DEBUG - 2017-02-25 02:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 02:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 02:02:24 --> User Agent Class Initialized
DEBUG - 2017-02-25 02:02:24 --> Template Class Initialized
INFO - 2017-02-25 02:02:24 --> Model Class Initialized
INFO - 2017-02-25 02:02:24 --> Controller Class Initialized
DEBUG - 2017-02-25 02:02:24 --> Pages MX_Controller Initialized
INFO - 2017-02-25 02:02:24 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 02:02:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 02:02:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 02:02:24 --> Config Class Initialized
INFO - 2017-02-25 02:02:24 --> Hooks Class Initialized
DEBUG - 2017-02-25 02:02:24 --> UTF-8 Support Enabled
INFO - 2017-02-25 02:02:24 --> Utf8 Class Initialized
INFO - 2017-02-25 02:02:24 --> URI Class Initialized
INFO - 2017-02-25 02:02:24 --> Router Class Initialized
INFO - 2017-02-25 02:02:24 --> Output Class Initialized
INFO - 2017-02-25 02:02:24 --> Security Class Initialized
DEBUG - 2017-02-25 02:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 02:02:24 --> Input Class Initialized
INFO - 2017-02-25 02:02:24 --> Language Class Initialized
INFO - 2017-02-25 02:02:24 --> Language Class Initialized
INFO - 2017-02-25 02:02:24 --> Config Class Initialized
INFO - 2017-02-25 02:02:24 --> Loader Class Initialized
INFO - 2017-02-25 02:02:24 --> Helper loaded: form_helper
INFO - 2017-02-25 02:02:24 --> Helper loaded: url_helper
INFO - 2017-02-25 02:02:24 --> Helper loaded: utility_helper
INFO - 2017-02-25 02:02:24 --> Database Driver Class Initialized
DEBUG - 2017-02-25 02:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 02:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 02:02:24 --> User Agent Class Initialized
DEBUG - 2017-02-25 02:02:24 --> Template Class Initialized
INFO - 2017-02-25 02:02:24 --> Model Class Initialized
INFO - 2017-02-25 02:02:24 --> Controller Class Initialized
DEBUG - 2017-02-25 02:02:24 --> Pages MX_Controller Initialized
INFO - 2017-02-25 02:02:24 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 02:02:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 02:02:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 02:07:40 --> Config Class Initialized
INFO - 2017-02-25 02:07:40 --> Hooks Class Initialized
DEBUG - 2017-02-25 02:07:40 --> UTF-8 Support Enabled
INFO - 2017-02-25 02:07:40 --> Utf8 Class Initialized
INFO - 2017-02-25 02:07:40 --> URI Class Initialized
INFO - 2017-02-25 02:07:40 --> Router Class Initialized
INFO - 2017-02-25 02:07:40 --> Output Class Initialized
INFO - 2017-02-25 02:07:40 --> Security Class Initialized
DEBUG - 2017-02-25 02:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 02:07:40 --> Input Class Initialized
INFO - 2017-02-25 02:07:40 --> Language Class Initialized
INFO - 2017-02-25 02:07:40 --> Language Class Initialized
INFO - 2017-02-25 02:07:40 --> Config Class Initialized
INFO - 2017-02-25 02:07:40 --> Loader Class Initialized
INFO - 2017-02-25 02:07:40 --> Helper loaded: form_helper
INFO - 2017-02-25 02:07:40 --> Helper loaded: url_helper
INFO - 2017-02-25 02:07:40 --> Helper loaded: utility_helper
INFO - 2017-02-25 02:07:40 --> Database Driver Class Initialized
DEBUG - 2017-02-25 02:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 02:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 02:07:40 --> User Agent Class Initialized
DEBUG - 2017-02-25 02:07:40 --> Template Class Initialized
INFO - 2017-02-25 02:07:40 --> Model Class Initialized
INFO - 2017-02-25 02:07:40 --> Controller Class Initialized
DEBUG - 2017-02-25 02:07:40 --> Pages MX_Controller Initialized
INFO - 2017-02-25 02:07:40 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 02:07:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 02:07:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 02:34:46 --> Config Class Initialized
INFO - 2017-02-25 02:34:46 --> Hooks Class Initialized
DEBUG - 2017-02-25 02:34:46 --> UTF-8 Support Enabled
INFO - 2017-02-25 02:34:46 --> Utf8 Class Initialized
INFO - 2017-02-25 02:34:46 --> URI Class Initialized
INFO - 2017-02-25 02:34:46 --> Router Class Initialized
INFO - 2017-02-25 02:34:46 --> Output Class Initialized
INFO - 2017-02-25 02:34:46 --> Security Class Initialized
DEBUG - 2017-02-25 02:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 02:34:46 --> Input Class Initialized
INFO - 2017-02-25 02:34:46 --> Language Class Initialized
INFO - 2017-02-25 02:34:46 --> Language Class Initialized
INFO - 2017-02-25 02:34:46 --> Config Class Initialized
INFO - 2017-02-25 02:34:46 --> Loader Class Initialized
INFO - 2017-02-25 02:34:46 --> Helper loaded: form_helper
INFO - 2017-02-25 02:34:46 --> Helper loaded: url_helper
INFO - 2017-02-25 02:34:46 --> Helper loaded: utility_helper
INFO - 2017-02-25 02:34:46 --> Database Driver Class Initialized
DEBUG - 2017-02-25 02:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 02:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 02:34:46 --> User Agent Class Initialized
DEBUG - 2017-02-25 02:34:46 --> Template Class Initialized
INFO - 2017-02-25 02:34:46 --> Model Class Initialized
INFO - 2017-02-25 02:34:46 --> Controller Class Initialized
DEBUG - 2017-02-25 02:34:46 --> Pages MX_Controller Initialized
INFO - 2017-02-25 02:34:46 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 02:34:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 02:34:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 02:34:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-02-25 02:34:46 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 02:34:46 --> Final output sent to browser
DEBUG - 2017-02-25 02:34:46 --> Total execution time: 0.0693
INFO - 2017-02-25 03:21:21 --> Config Class Initialized
INFO - 2017-02-25 03:21:21 --> Hooks Class Initialized
DEBUG - 2017-02-25 03:21:21 --> UTF-8 Support Enabled
INFO - 2017-02-25 03:21:21 --> Utf8 Class Initialized
INFO - 2017-02-25 03:21:21 --> URI Class Initialized
DEBUG - 2017-02-25 03:21:21 --> No URI present. Default controller set.
INFO - 2017-02-25 03:21:21 --> Router Class Initialized
INFO - 2017-02-25 03:21:21 --> Output Class Initialized
INFO - 2017-02-25 03:21:21 --> Security Class Initialized
DEBUG - 2017-02-25 03:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 03:21:21 --> Input Class Initialized
INFO - 2017-02-25 03:21:21 --> Language Class Initialized
INFO - 2017-02-25 03:21:21 --> Language Class Initialized
INFO - 2017-02-25 03:21:21 --> Config Class Initialized
INFO - 2017-02-25 03:21:21 --> Loader Class Initialized
INFO - 2017-02-25 03:21:21 --> Helper loaded: form_helper
INFO - 2017-02-25 03:21:21 --> Helper loaded: url_helper
INFO - 2017-02-25 03:21:21 --> Helper loaded: utility_helper
INFO - 2017-02-25 03:21:21 --> Database Driver Class Initialized
DEBUG - 2017-02-25 03:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 03:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 03:21:21 --> User Agent Class Initialized
DEBUG - 2017-02-25 03:21:21 --> Template Class Initialized
INFO - 2017-02-25 03:21:21 --> Model Class Initialized
INFO - 2017-02-25 03:21:21 --> Controller Class Initialized
DEBUG - 2017-02-25 03:21:21 --> Pages MX_Controller Initialized
INFO - 2017-02-25 03:21:21 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 03:21:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 03:21:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 03:21:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-25 03:21:21 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 03:21:21 --> Final output sent to browser
DEBUG - 2017-02-25 03:21:21 --> Total execution time: 0.0748
INFO - 2017-02-25 03:21:25 --> Config Class Initialized
INFO - 2017-02-25 03:21:25 --> Hooks Class Initialized
DEBUG - 2017-02-25 03:21:25 --> UTF-8 Support Enabled
INFO - 2017-02-25 03:21:25 --> Utf8 Class Initialized
INFO - 2017-02-25 03:21:25 --> URI Class Initialized
INFO - 2017-02-25 03:21:25 --> Router Class Initialized
INFO - 2017-02-25 03:21:25 --> Output Class Initialized
INFO - 2017-02-25 03:21:25 --> Security Class Initialized
DEBUG - 2017-02-25 03:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 03:21:25 --> Input Class Initialized
INFO - 2017-02-25 03:21:25 --> Language Class Initialized
INFO - 2017-02-25 03:21:25 --> Language Class Initialized
INFO - 2017-02-25 03:21:25 --> Config Class Initialized
INFO - 2017-02-25 03:21:25 --> Loader Class Initialized
INFO - 2017-02-25 03:21:25 --> Helper loaded: form_helper
INFO - 2017-02-25 03:21:25 --> Helper loaded: url_helper
INFO - 2017-02-25 03:21:25 --> Helper loaded: utility_helper
INFO - 2017-02-25 03:21:25 --> Database Driver Class Initialized
DEBUG - 2017-02-25 03:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 03:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 03:21:25 --> User Agent Class Initialized
DEBUG - 2017-02-25 03:21:25 --> Template Class Initialized
INFO - 2017-02-25 03:21:25 --> Model Class Initialized
INFO - 2017-02-25 03:21:25 --> Controller Class Initialized
DEBUG - 2017-02-25 03:21:25 --> Pages MX_Controller Initialized
INFO - 2017-02-25 03:21:25 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 03:21:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 03:21:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 03:21:25 --> Config Class Initialized
INFO - 2017-02-25 03:21:25 --> Hooks Class Initialized
DEBUG - 2017-02-25 03:21:25 --> UTF-8 Support Enabled
INFO - 2017-02-25 03:21:25 --> Utf8 Class Initialized
INFO - 2017-02-25 03:21:25 --> URI Class Initialized
INFO - 2017-02-25 03:21:25 --> Router Class Initialized
INFO - 2017-02-25 03:21:25 --> Output Class Initialized
INFO - 2017-02-25 03:21:25 --> Security Class Initialized
DEBUG - 2017-02-25 03:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 03:21:25 --> Input Class Initialized
INFO - 2017-02-25 03:21:25 --> Language Class Initialized
INFO - 2017-02-25 03:21:25 --> Language Class Initialized
INFO - 2017-02-25 03:21:25 --> Config Class Initialized
INFO - 2017-02-25 03:21:25 --> Loader Class Initialized
INFO - 2017-02-25 03:21:25 --> Helper loaded: form_helper
INFO - 2017-02-25 03:21:25 --> Helper loaded: url_helper
INFO - 2017-02-25 03:21:25 --> Helper loaded: utility_helper
INFO - 2017-02-25 03:21:25 --> Database Driver Class Initialized
DEBUG - 2017-02-25 03:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 03:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 03:21:25 --> User Agent Class Initialized
DEBUG - 2017-02-25 03:21:25 --> Template Class Initialized
INFO - 2017-02-25 03:21:25 --> Model Class Initialized
INFO - 2017-02-25 03:21:25 --> Controller Class Initialized
DEBUG - 2017-02-25 03:21:25 --> Pages MX_Controller Initialized
INFO - 2017-02-25 03:21:25 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 03:21:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 03:21:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 04:32:20 --> Config Class Initialized
INFO - 2017-02-25 04:32:20 --> Hooks Class Initialized
DEBUG - 2017-02-25 04:32:20 --> UTF-8 Support Enabled
INFO - 2017-02-25 04:32:20 --> Utf8 Class Initialized
INFO - 2017-02-25 04:32:20 --> URI Class Initialized
INFO - 2017-02-25 04:32:20 --> Router Class Initialized
INFO - 2017-02-25 04:32:20 --> Output Class Initialized
INFO - 2017-02-25 04:32:20 --> Security Class Initialized
DEBUG - 2017-02-25 04:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 04:32:20 --> Input Class Initialized
INFO - 2017-02-25 04:32:20 --> Language Class Initialized
INFO - 2017-02-25 04:32:20 --> Language Class Initialized
INFO - 2017-02-25 04:32:20 --> Config Class Initialized
INFO - 2017-02-25 04:32:20 --> Loader Class Initialized
INFO - 2017-02-25 04:32:20 --> Helper loaded: form_helper
INFO - 2017-02-25 04:32:20 --> Helper loaded: url_helper
INFO - 2017-02-25 04:32:20 --> Helper loaded: utility_helper
INFO - 2017-02-25 04:32:20 --> Database Driver Class Initialized
DEBUG - 2017-02-25 04:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 04:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 04:32:21 --> User Agent Class Initialized
DEBUG - 2017-02-25 04:32:21 --> Template Class Initialized
INFO - 2017-02-25 04:32:21 --> Model Class Initialized
INFO - 2017-02-25 04:32:21 --> Controller Class Initialized
DEBUG - 2017-02-25 04:32:21 --> Dashboard MX_Controller Initialized
INFO - 2017-02-25 04:32:21 --> Helper loaded: cookie_helper
INFO - 2017-02-25 04:32:21 --> Config Class Initialized
INFO - 2017-02-25 04:32:21 --> Hooks Class Initialized
DEBUG - 2017-02-25 04:32:21 --> UTF-8 Support Enabled
INFO - 2017-02-25 04:32:21 --> Utf8 Class Initialized
INFO - 2017-02-25 04:32:21 --> URI Class Initialized
DEBUG - 2017-02-25 04:32:21 --> No URI present. Default controller set.
INFO - 2017-02-25 04:32:21 --> Router Class Initialized
INFO - 2017-02-25 04:32:21 --> Output Class Initialized
INFO - 2017-02-25 04:32:21 --> Security Class Initialized
DEBUG - 2017-02-25 04:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 04:32:21 --> Input Class Initialized
INFO - 2017-02-25 04:32:21 --> Language Class Initialized
INFO - 2017-02-25 04:32:21 --> Language Class Initialized
INFO - 2017-02-25 04:32:21 --> Config Class Initialized
INFO - 2017-02-25 04:32:21 --> Loader Class Initialized
INFO - 2017-02-25 04:32:21 --> Helper loaded: form_helper
INFO - 2017-02-25 04:32:21 --> Helper loaded: url_helper
INFO - 2017-02-25 04:32:21 --> Helper loaded: utility_helper
INFO - 2017-02-25 04:32:21 --> Database Driver Class Initialized
DEBUG - 2017-02-25 04:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 04:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 04:32:21 --> User Agent Class Initialized
DEBUG - 2017-02-25 04:32:21 --> Template Class Initialized
INFO - 2017-02-25 04:32:21 --> Model Class Initialized
INFO - 2017-02-25 04:32:21 --> Controller Class Initialized
DEBUG - 2017-02-25 04:32:21 --> Pages MX_Controller Initialized
INFO - 2017-02-25 04:32:21 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 04:32:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 04:32:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 04:32:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-25 04:32:21 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 04:32:21 --> Final output sent to browser
DEBUG - 2017-02-25 04:32:21 --> Total execution time: 0.0574
INFO - 2017-02-25 04:32:25 --> Config Class Initialized
INFO - 2017-02-25 04:32:25 --> Hooks Class Initialized
DEBUG - 2017-02-25 04:32:25 --> UTF-8 Support Enabled
INFO - 2017-02-25 04:32:25 --> Utf8 Class Initialized
INFO - 2017-02-25 04:32:25 --> URI Class Initialized
INFO - 2017-02-25 04:32:25 --> Router Class Initialized
INFO - 2017-02-25 04:32:25 --> Output Class Initialized
INFO - 2017-02-25 04:32:25 --> Security Class Initialized
DEBUG - 2017-02-25 04:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 04:32:25 --> Input Class Initialized
INFO - 2017-02-25 04:32:25 --> Language Class Initialized
INFO - 2017-02-25 04:32:25 --> Language Class Initialized
INFO - 2017-02-25 04:32:25 --> Config Class Initialized
INFO - 2017-02-25 04:32:25 --> Loader Class Initialized
INFO - 2017-02-25 04:32:25 --> Helper loaded: form_helper
INFO - 2017-02-25 04:32:25 --> Helper loaded: url_helper
INFO - 2017-02-25 04:32:25 --> Helper loaded: utility_helper
INFO - 2017-02-25 04:32:25 --> Database Driver Class Initialized
DEBUG - 2017-02-25 04:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 04:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 04:32:25 --> User Agent Class Initialized
DEBUG - 2017-02-25 04:32:25 --> Template Class Initialized
INFO - 2017-02-25 04:32:25 --> Model Class Initialized
INFO - 2017-02-25 04:32:25 --> Controller Class Initialized
DEBUG - 2017-02-25 04:32:25 --> Pages MX_Controller Initialized
INFO - 2017-02-25 04:32:25 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 04:32:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 04:32:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 04:32:25 --> Config Class Initialized
INFO - 2017-02-25 04:32:25 --> Hooks Class Initialized
DEBUG - 2017-02-25 04:32:25 --> UTF-8 Support Enabled
INFO - 2017-02-25 04:32:25 --> Utf8 Class Initialized
INFO - 2017-02-25 04:32:25 --> URI Class Initialized
INFO - 2017-02-25 04:32:25 --> Router Class Initialized
INFO - 2017-02-25 04:32:25 --> Output Class Initialized
INFO - 2017-02-25 04:32:25 --> Security Class Initialized
DEBUG - 2017-02-25 04:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 04:32:25 --> Input Class Initialized
INFO - 2017-02-25 04:32:25 --> Language Class Initialized
INFO - 2017-02-25 04:32:25 --> Language Class Initialized
INFO - 2017-02-25 04:32:25 --> Config Class Initialized
INFO - 2017-02-25 04:32:25 --> Loader Class Initialized
INFO - 2017-02-25 04:32:25 --> Helper loaded: form_helper
INFO - 2017-02-25 04:32:25 --> Helper loaded: url_helper
INFO - 2017-02-25 04:32:25 --> Helper loaded: utility_helper
INFO - 2017-02-25 04:32:25 --> Database Driver Class Initialized
DEBUG - 2017-02-25 04:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 04:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 04:32:25 --> User Agent Class Initialized
DEBUG - 2017-02-25 04:32:25 --> Template Class Initialized
INFO - 2017-02-25 04:32:25 --> Model Class Initialized
INFO - 2017-02-25 04:32:25 --> Controller Class Initialized
DEBUG - 2017-02-25 04:32:25 --> Pages MX_Controller Initialized
INFO - 2017-02-25 04:32:25 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 04:32:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 04:32:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 08:52:01 --> Config Class Initialized
INFO - 2017-02-25 08:52:01 --> Hooks Class Initialized
DEBUG - 2017-02-25 08:52:01 --> UTF-8 Support Enabled
INFO - 2017-02-25 08:52:01 --> Utf8 Class Initialized
INFO - 2017-02-25 08:52:01 --> URI Class Initialized
INFO - 2017-02-25 08:52:01 --> Router Class Initialized
INFO - 2017-02-25 08:52:02 --> Output Class Initialized
INFO - 2017-02-25 08:52:02 --> Security Class Initialized
DEBUG - 2017-02-25 08:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 08:52:02 --> Input Class Initialized
INFO - 2017-02-25 08:52:02 --> Language Class Initialized
INFO - 2017-02-25 08:52:02 --> Language Class Initialized
INFO - 2017-02-25 08:52:02 --> Config Class Initialized
INFO - 2017-02-25 08:52:02 --> Loader Class Initialized
INFO - 2017-02-25 08:52:02 --> Helper loaded: form_helper
INFO - 2017-02-25 08:52:02 --> Helper loaded: url_helper
INFO - 2017-02-25 08:52:02 --> Helper loaded: utility_helper
INFO - 2017-02-25 08:52:02 --> Database Driver Class Initialized
DEBUG - 2017-02-25 08:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 08:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 08:52:02 --> User Agent Class Initialized
DEBUG - 2017-02-25 08:52:02 --> Template Class Initialized
INFO - 2017-02-25 08:52:02 --> Model Class Initialized
INFO - 2017-02-25 08:52:02 --> Controller Class Initialized
DEBUG - 2017-02-25 08:52:02 --> Pages MX_Controller Initialized
INFO - 2017-02-25 08:52:02 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 08:52:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 08:52:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 08:53:49 --> Config Class Initialized
INFO - 2017-02-25 08:53:49 --> Hooks Class Initialized
DEBUG - 2017-02-25 08:53:49 --> UTF-8 Support Enabled
INFO - 2017-02-25 08:53:49 --> Utf8 Class Initialized
INFO - 2017-02-25 08:53:49 --> URI Class Initialized
INFO - 2017-02-25 08:53:49 --> Router Class Initialized
INFO - 2017-02-25 08:53:49 --> Output Class Initialized
INFO - 2017-02-25 08:53:49 --> Security Class Initialized
DEBUG - 2017-02-25 08:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 08:53:49 --> Input Class Initialized
INFO - 2017-02-25 08:53:49 --> Language Class Initialized
INFO - 2017-02-25 08:53:49 --> Language Class Initialized
INFO - 2017-02-25 08:53:49 --> Config Class Initialized
INFO - 2017-02-25 08:53:49 --> Loader Class Initialized
INFO - 2017-02-25 08:53:49 --> Helper loaded: form_helper
INFO - 2017-02-25 08:53:49 --> Helper loaded: url_helper
INFO - 2017-02-25 08:53:49 --> Helper loaded: utility_helper
INFO - 2017-02-25 08:53:49 --> Database Driver Class Initialized
DEBUG - 2017-02-25 08:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 08:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 08:53:49 --> User Agent Class Initialized
DEBUG - 2017-02-25 08:53:49 --> Template Class Initialized
INFO - 2017-02-25 08:53:49 --> Model Class Initialized
INFO - 2017-02-25 08:53:49 --> Controller Class Initialized
DEBUG - 2017-02-25 08:53:49 --> Pages MX_Controller Initialized
INFO - 2017-02-25 08:53:49 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 08:53:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 08:53:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 08:53:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/checkout.php
DEBUG - 2017-02-25 08:53:49 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 08:53:49 --> Final output sent to browser
DEBUG - 2017-02-25 08:53:49 --> Total execution time: 0.0642
INFO - 2017-02-25 12:57:17 --> Config Class Initialized
INFO - 2017-02-25 12:57:17 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:57:17 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:57:17 --> Utf8 Class Initialized
INFO - 2017-02-25 12:57:17 --> URI Class Initialized
INFO - 2017-02-25 12:57:17 --> Router Class Initialized
INFO - 2017-02-25 12:57:17 --> Output Class Initialized
INFO - 2017-02-25 12:57:17 --> Security Class Initialized
DEBUG - 2017-02-25 12:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:57:17 --> Input Class Initialized
INFO - 2017-02-25 12:57:17 --> Language Class Initialized
INFO - 2017-02-25 12:57:17 --> Language Class Initialized
INFO - 2017-02-25 12:57:17 --> Config Class Initialized
INFO - 2017-02-25 12:57:17 --> Loader Class Initialized
INFO - 2017-02-25 12:57:17 --> Helper loaded: form_helper
INFO - 2017-02-25 12:57:17 --> Helper loaded: url_helper
INFO - 2017-02-25 12:57:17 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:57:17 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:57:18 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:57:18 --> Template Class Initialized
INFO - 2017-02-25 12:57:18 --> Model Class Initialized
INFO - 2017-02-25 12:57:18 --> Controller Class Initialized
DEBUG - 2017-02-25 12:57:18 --> Pages MX_Controller Initialized
INFO - 2017-02-25 12:57:18 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:57:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 12:57:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 12:57:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/about_us.php
DEBUG - 2017-02-25 12:57:18 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 12:57:18 --> Final output sent to browser
DEBUG - 2017-02-25 12:57:18 --> Total execution time: 0.2351
INFO - 2017-02-25 12:57:19 --> Config Class Initialized
INFO - 2017-02-25 12:57:19 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:57:19 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:57:19 --> Utf8 Class Initialized
INFO - 2017-02-25 12:57:19 --> URI Class Initialized
INFO - 2017-02-25 12:57:19 --> Router Class Initialized
INFO - 2017-02-25 12:57:19 --> Output Class Initialized
INFO - 2017-02-25 12:57:19 --> Security Class Initialized
DEBUG - 2017-02-25 12:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:57:19 --> Input Class Initialized
INFO - 2017-02-25 12:57:19 --> Language Class Initialized
INFO - 2017-02-25 12:57:19 --> Language Class Initialized
INFO - 2017-02-25 12:57:19 --> Config Class Initialized
INFO - 2017-02-25 12:57:19 --> Loader Class Initialized
INFO - 2017-02-25 12:57:19 --> Helper loaded: form_helper
INFO - 2017-02-25 12:57:19 --> Helper loaded: url_helper
INFO - 2017-02-25 12:57:19 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:57:19 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:57:19 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:57:19 --> Template Class Initialized
INFO - 2017-02-25 12:57:19 --> Model Class Initialized
INFO - 2017-02-25 12:57:19 --> Controller Class Initialized
DEBUG - 2017-02-25 12:57:19 --> Pages MX_Controller Initialized
INFO - 2017-02-25 12:57:19 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:57:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 12:57:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 12:57:35 --> Config Class Initialized
INFO - 2017-02-25 12:57:35 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:57:35 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:57:35 --> Utf8 Class Initialized
INFO - 2017-02-25 12:57:35 --> URI Class Initialized
INFO - 2017-02-25 12:57:35 --> Router Class Initialized
INFO - 2017-02-25 12:57:35 --> Output Class Initialized
INFO - 2017-02-25 12:57:35 --> Security Class Initialized
DEBUG - 2017-02-25 12:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:57:35 --> Input Class Initialized
INFO - 2017-02-25 12:57:35 --> Language Class Initialized
INFO - 2017-02-25 12:57:35 --> Language Class Initialized
INFO - 2017-02-25 12:57:35 --> Config Class Initialized
INFO - 2017-02-25 12:57:35 --> Loader Class Initialized
INFO - 2017-02-25 12:57:35 --> Helper loaded: form_helper
INFO - 2017-02-25 12:57:35 --> Helper loaded: url_helper
INFO - 2017-02-25 12:57:35 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:57:35 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:57:35 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:57:35 --> Template Class Initialized
INFO - 2017-02-25 12:57:35 --> Model Class Initialized
INFO - 2017-02-25 12:57:35 --> Controller Class Initialized
DEBUG - 2017-02-25 12:57:35 --> Pages MX_Controller Initialized
INFO - 2017-02-25 12:57:35 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:57:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 12:57:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 12:57:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/support.php
DEBUG - 2017-02-25 12:57:35 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 12:57:35 --> Final output sent to browser
DEBUG - 2017-02-25 12:57:35 --> Total execution time: 0.0547
INFO - 2017-02-25 12:57:35 --> Config Class Initialized
INFO - 2017-02-25 12:57:35 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:57:35 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:57:35 --> Utf8 Class Initialized
INFO - 2017-02-25 12:57:35 --> URI Class Initialized
INFO - 2017-02-25 12:57:35 --> Router Class Initialized
INFO - 2017-02-25 12:57:35 --> Output Class Initialized
INFO - 2017-02-25 12:57:35 --> Security Class Initialized
DEBUG - 2017-02-25 12:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:57:35 --> Input Class Initialized
INFO - 2017-02-25 12:57:35 --> Language Class Initialized
INFO - 2017-02-25 12:57:35 --> Language Class Initialized
INFO - 2017-02-25 12:57:35 --> Config Class Initialized
INFO - 2017-02-25 12:57:35 --> Loader Class Initialized
INFO - 2017-02-25 12:57:35 --> Helper loaded: form_helper
INFO - 2017-02-25 12:57:35 --> Helper loaded: url_helper
INFO - 2017-02-25 12:57:35 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:57:35 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:57:35 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:57:35 --> Template Class Initialized
INFO - 2017-02-25 12:57:35 --> Model Class Initialized
INFO - 2017-02-25 12:57:35 --> Controller Class Initialized
DEBUG - 2017-02-25 12:57:35 --> Pages MX_Controller Initialized
INFO - 2017-02-25 12:57:35 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:57:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 12:57:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 12:57:42 --> Config Class Initialized
INFO - 2017-02-25 12:57:42 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:57:42 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:57:42 --> Utf8 Class Initialized
INFO - 2017-02-25 12:57:42 --> URI Class Initialized
INFO - 2017-02-25 12:57:42 --> Router Class Initialized
INFO - 2017-02-25 12:57:42 --> Output Class Initialized
INFO - 2017-02-25 12:57:42 --> Security Class Initialized
DEBUG - 2017-02-25 12:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:57:42 --> Input Class Initialized
INFO - 2017-02-25 12:57:42 --> Language Class Initialized
INFO - 2017-02-25 12:57:42 --> Language Class Initialized
INFO - 2017-02-25 12:57:42 --> Config Class Initialized
INFO - 2017-02-25 12:57:42 --> Loader Class Initialized
INFO - 2017-02-25 12:57:42 --> Helper loaded: form_helper
INFO - 2017-02-25 12:57:42 --> Helper loaded: url_helper
INFO - 2017-02-25 12:57:42 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:57:42 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:57:42 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:57:42 --> Template Class Initialized
INFO - 2017-02-25 12:57:42 --> Model Class Initialized
INFO - 2017-02-25 12:57:42 --> Controller Class Initialized
DEBUG - 2017-02-25 12:57:42 --> Pages MX_Controller Initialized
INFO - 2017-02-25 12:57:42 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:57:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 12:57:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 12:57:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-02-25 12:57:42 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 12:57:42 --> Final output sent to browser
DEBUG - 2017-02-25 12:57:42 --> Total execution time: 0.1246
INFO - 2017-02-25 12:57:43 --> Config Class Initialized
INFO - 2017-02-25 12:57:43 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:57:43 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:57:43 --> Utf8 Class Initialized
INFO - 2017-02-25 12:57:43 --> URI Class Initialized
INFO - 2017-02-25 12:57:43 --> Router Class Initialized
INFO - 2017-02-25 12:57:43 --> Output Class Initialized
INFO - 2017-02-25 12:57:43 --> Security Class Initialized
DEBUG - 2017-02-25 12:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:57:43 --> Input Class Initialized
INFO - 2017-02-25 12:57:43 --> Language Class Initialized
INFO - 2017-02-25 12:57:43 --> Language Class Initialized
INFO - 2017-02-25 12:57:43 --> Config Class Initialized
INFO - 2017-02-25 12:57:43 --> Loader Class Initialized
INFO - 2017-02-25 12:57:43 --> Helper loaded: form_helper
INFO - 2017-02-25 12:57:43 --> Helper loaded: url_helper
INFO - 2017-02-25 12:57:43 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:57:43 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:57:43 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:57:43 --> Template Class Initialized
INFO - 2017-02-25 12:57:43 --> Model Class Initialized
INFO - 2017-02-25 12:57:43 --> Controller Class Initialized
DEBUG - 2017-02-25 12:57:43 --> Pages MX_Controller Initialized
INFO - 2017-02-25 12:57:43 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:57:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 12:57:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 12:57:48 --> Config Class Initialized
INFO - 2017-02-25 12:57:48 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:57:48 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:57:48 --> Utf8 Class Initialized
INFO - 2017-02-25 12:57:48 --> URI Class Initialized
INFO - 2017-02-25 12:57:48 --> Router Class Initialized
INFO - 2017-02-25 12:57:48 --> Output Class Initialized
INFO - 2017-02-25 12:57:48 --> Security Class Initialized
DEBUG - 2017-02-25 12:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:57:48 --> Input Class Initialized
INFO - 2017-02-25 12:57:48 --> Language Class Initialized
INFO - 2017-02-25 12:57:48 --> Language Class Initialized
INFO - 2017-02-25 12:57:48 --> Config Class Initialized
INFO - 2017-02-25 12:57:48 --> Loader Class Initialized
INFO - 2017-02-25 12:57:48 --> Helper loaded: form_helper
INFO - 2017-02-25 12:57:48 --> Helper loaded: url_helper
INFO - 2017-02-25 12:57:48 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:57:48 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:57:48 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:57:48 --> Template Class Initialized
INFO - 2017-02-25 12:57:48 --> Model Class Initialized
INFO - 2017-02-25 12:57:48 --> Controller Class Initialized
DEBUG - 2017-02-25 12:57:48 --> Pages MX_Controller Initialized
INFO - 2017-02-25 12:57:48 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:57:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 12:57:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 12:57:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-02-25 12:57:48 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 12:57:48 --> Final output sent to browser
DEBUG - 2017-02-25 12:57:48 --> Total execution time: 0.0705
INFO - 2017-02-25 12:57:48 --> Config Class Initialized
INFO - 2017-02-25 12:57:48 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:57:48 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:57:48 --> Utf8 Class Initialized
INFO - 2017-02-25 12:57:48 --> URI Class Initialized
INFO - 2017-02-25 12:57:48 --> Router Class Initialized
INFO - 2017-02-25 12:57:48 --> Output Class Initialized
INFO - 2017-02-25 12:57:48 --> Security Class Initialized
DEBUG - 2017-02-25 12:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:57:48 --> Input Class Initialized
INFO - 2017-02-25 12:57:48 --> Language Class Initialized
INFO - 2017-02-25 12:57:48 --> Language Class Initialized
INFO - 2017-02-25 12:57:48 --> Config Class Initialized
INFO - 2017-02-25 12:57:48 --> Loader Class Initialized
INFO - 2017-02-25 12:57:48 --> Helper loaded: form_helper
INFO - 2017-02-25 12:57:48 --> Helper loaded: url_helper
INFO - 2017-02-25 12:57:48 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:57:48 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:57:48 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:57:48 --> Template Class Initialized
INFO - 2017-02-25 12:57:48 --> Model Class Initialized
INFO - 2017-02-25 12:57:48 --> Controller Class Initialized
DEBUG - 2017-02-25 12:57:48 --> Pages MX_Controller Initialized
INFO - 2017-02-25 12:57:48 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:57:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 12:57:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 12:58:00 --> Config Class Initialized
INFO - 2017-02-25 12:58:00 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:58:00 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:58:00 --> Utf8 Class Initialized
INFO - 2017-02-25 12:58:00 --> URI Class Initialized
INFO - 2017-02-25 12:58:00 --> Router Class Initialized
INFO - 2017-02-25 12:58:00 --> Output Class Initialized
INFO - 2017-02-25 12:58:00 --> Security Class Initialized
DEBUG - 2017-02-25 12:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:58:00 --> Input Class Initialized
INFO - 2017-02-25 12:58:00 --> Language Class Initialized
INFO - 2017-02-25 12:58:00 --> Language Class Initialized
INFO - 2017-02-25 12:58:00 --> Config Class Initialized
INFO - 2017-02-25 12:58:00 --> Loader Class Initialized
INFO - 2017-02-25 12:58:00 --> Helper loaded: form_helper
INFO - 2017-02-25 12:58:00 --> Helper loaded: url_helper
INFO - 2017-02-25 12:58:00 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:58:00 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:58:00 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:58:00 --> Template Class Initialized
INFO - 2017-02-25 12:58:00 --> Model Class Initialized
INFO - 2017-02-25 12:58:00 --> Controller Class Initialized
DEBUG - 2017-02-25 12:58:00 --> Login MX_Controller Initialized
INFO - 2017-02-25 12:58:00 --> Helper loaded: cookie_helper
INFO - 2017-02-25 12:58:00 --> Form Validation Class Initialized
INFO - 2017-02-25 12:58:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-25 12:58:00 --> Config Class Initialized
INFO - 2017-02-25 12:58:00 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:58:00 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:58:00 --> Utf8 Class Initialized
INFO - 2017-02-25 12:58:00 --> URI Class Initialized
INFO - 2017-02-25 12:58:00 --> Router Class Initialized
INFO - 2017-02-25 12:58:00 --> Output Class Initialized
INFO - 2017-02-25 12:58:00 --> Security Class Initialized
DEBUG - 2017-02-25 12:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:58:00 --> Input Class Initialized
INFO - 2017-02-25 12:58:00 --> Language Class Initialized
INFO - 2017-02-25 12:58:00 --> Language Class Initialized
INFO - 2017-02-25 12:58:00 --> Config Class Initialized
INFO - 2017-02-25 12:58:00 --> Loader Class Initialized
INFO - 2017-02-25 12:58:00 --> Helper loaded: form_helper
INFO - 2017-02-25 12:58:00 --> Helper loaded: url_helper
INFO - 2017-02-25 12:58:00 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:58:00 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:58:00 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:58:00 --> Template Class Initialized
INFO - 2017-02-25 12:58:00 --> Model Class Initialized
INFO - 2017-02-25 12:58:00 --> Controller Class Initialized
DEBUG - 2017-02-25 12:58:00 --> Pages MX_Controller Initialized
INFO - 2017-02-25 12:58:00 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:58:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 12:58:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 12:58:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-02-25 12:58:00 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 12:58:00 --> Final output sent to browser
DEBUG - 2017-02-25 12:58:00 --> Total execution time: 0.0155
INFO - 2017-02-25 12:58:00 --> Config Class Initialized
INFO - 2017-02-25 12:58:00 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:58:00 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:58:00 --> Utf8 Class Initialized
INFO - 2017-02-25 12:58:00 --> URI Class Initialized
INFO - 2017-02-25 12:58:00 --> Router Class Initialized
INFO - 2017-02-25 12:58:00 --> Output Class Initialized
INFO - 2017-02-25 12:58:00 --> Security Class Initialized
DEBUG - 2017-02-25 12:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:58:00 --> Input Class Initialized
INFO - 2017-02-25 12:58:00 --> Language Class Initialized
INFO - 2017-02-25 12:58:00 --> Language Class Initialized
INFO - 2017-02-25 12:58:00 --> Config Class Initialized
INFO - 2017-02-25 12:58:00 --> Loader Class Initialized
INFO - 2017-02-25 12:58:00 --> Helper loaded: form_helper
INFO - 2017-02-25 12:58:00 --> Helper loaded: url_helper
INFO - 2017-02-25 12:58:00 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:58:00 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:58:00 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:58:00 --> Template Class Initialized
INFO - 2017-02-25 12:58:00 --> Model Class Initialized
INFO - 2017-02-25 12:58:00 --> Controller Class Initialized
DEBUG - 2017-02-25 12:58:00 --> Pages MX_Controller Initialized
INFO - 2017-02-25 12:58:00 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:58:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 12:58:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 12:58:13 --> Config Class Initialized
INFO - 2017-02-25 12:58:13 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:58:13 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:58:13 --> Utf8 Class Initialized
INFO - 2017-02-25 12:58:13 --> URI Class Initialized
INFO - 2017-02-25 12:58:13 --> Router Class Initialized
INFO - 2017-02-25 12:58:13 --> Output Class Initialized
INFO - 2017-02-25 12:58:13 --> Security Class Initialized
DEBUG - 2017-02-25 12:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:58:13 --> Input Class Initialized
INFO - 2017-02-25 12:58:13 --> Language Class Initialized
INFO - 2017-02-25 12:58:13 --> Language Class Initialized
INFO - 2017-02-25 12:58:13 --> Config Class Initialized
INFO - 2017-02-25 12:58:13 --> Loader Class Initialized
INFO - 2017-02-25 12:58:13 --> Helper loaded: form_helper
INFO - 2017-02-25 12:58:13 --> Helper loaded: url_helper
INFO - 2017-02-25 12:58:13 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:58:13 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:58:13 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:58:13 --> Template Class Initialized
INFO - 2017-02-25 12:58:13 --> Model Class Initialized
INFO - 2017-02-25 12:58:13 --> Controller Class Initialized
DEBUG - 2017-02-25 12:58:13 --> Login MX_Controller Initialized
INFO - 2017-02-25 12:58:13 --> Helper loaded: cookie_helper
INFO - 2017-02-25 12:58:13 --> Form Validation Class Initialized
INFO - 2017-02-25 12:58:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-25 12:58:14 --> Config Class Initialized
INFO - 2017-02-25 12:58:14 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:58:14 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:58:14 --> Utf8 Class Initialized
INFO - 2017-02-25 12:58:14 --> URI Class Initialized
INFO - 2017-02-25 12:58:14 --> Router Class Initialized
INFO - 2017-02-25 12:58:14 --> Output Class Initialized
INFO - 2017-02-25 12:58:14 --> Security Class Initialized
DEBUG - 2017-02-25 12:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:58:14 --> Input Class Initialized
INFO - 2017-02-25 12:58:14 --> Language Class Initialized
INFO - 2017-02-25 12:58:14 --> Language Class Initialized
INFO - 2017-02-25 12:58:14 --> Config Class Initialized
INFO - 2017-02-25 12:58:14 --> Loader Class Initialized
INFO - 2017-02-25 12:58:14 --> Helper loaded: form_helper
INFO - 2017-02-25 12:58:14 --> Helper loaded: url_helper
INFO - 2017-02-25 12:58:14 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:58:14 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:58:14 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:58:14 --> Template Class Initialized
INFO - 2017-02-25 12:58:14 --> Model Class Initialized
INFO - 2017-02-25 12:58:14 --> Controller Class Initialized
DEBUG - 2017-02-25 12:58:14 --> Dashboard MX_Controller Initialized
INFO - 2017-02-25 12:58:14 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:58:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-25 12:58:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-02-25 12:58:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-25 12:58:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-02-25 12:58:14 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-25 12:58:14 --> Final output sent to browser
DEBUG - 2017-02-25 12:58:14 --> Total execution time: 0.0804
INFO - 2017-02-25 12:58:22 --> Config Class Initialized
INFO - 2017-02-25 12:58:22 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:58:22 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:58:22 --> Utf8 Class Initialized
INFO - 2017-02-25 12:58:22 --> URI Class Initialized
INFO - 2017-02-25 12:58:22 --> Router Class Initialized
INFO - 2017-02-25 12:58:22 --> Output Class Initialized
INFO - 2017-02-25 12:58:22 --> Security Class Initialized
DEBUG - 2017-02-25 12:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:58:22 --> Input Class Initialized
INFO - 2017-02-25 12:58:22 --> Language Class Initialized
INFO - 2017-02-25 12:58:22 --> Language Class Initialized
INFO - 2017-02-25 12:58:22 --> Config Class Initialized
INFO - 2017-02-25 12:58:22 --> Loader Class Initialized
INFO - 2017-02-25 12:58:22 --> Helper loaded: form_helper
INFO - 2017-02-25 12:58:22 --> Helper loaded: url_helper
INFO - 2017-02-25 12:58:22 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:58:22 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:58:22 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:58:22 --> Template Class Initialized
INFO - 2017-02-25 12:58:22 --> Model Class Initialized
INFO - 2017-02-25 12:58:22 --> Controller Class Initialized
DEBUG - 2017-02-25 12:58:22 --> Dashboard MX_Controller Initialized
INFO - 2017-02-25 12:58:22 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:58:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-25 12:58:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-02-25 12:58:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-25 12:58:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/my_subscribers.php
DEBUG - 2017-02-25 12:58:22 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-25 12:58:22 --> Final output sent to browser
DEBUG - 2017-02-25 12:58:22 --> Total execution time: 0.0555
INFO - 2017-02-25 12:58:24 --> Config Class Initialized
INFO - 2017-02-25 12:58:24 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:58:24 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:58:24 --> Utf8 Class Initialized
INFO - 2017-02-25 12:58:24 --> URI Class Initialized
INFO - 2017-02-25 12:58:24 --> Router Class Initialized
INFO - 2017-02-25 12:58:24 --> Output Class Initialized
INFO - 2017-02-25 12:58:24 --> Security Class Initialized
DEBUG - 2017-02-25 12:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:58:24 --> Input Class Initialized
INFO - 2017-02-25 12:58:24 --> Language Class Initialized
INFO - 2017-02-25 12:58:24 --> Language Class Initialized
INFO - 2017-02-25 12:58:24 --> Config Class Initialized
INFO - 2017-02-25 12:58:24 --> Loader Class Initialized
INFO - 2017-02-25 12:58:24 --> Helper loaded: form_helper
INFO - 2017-02-25 12:58:24 --> Helper loaded: url_helper
INFO - 2017-02-25 12:58:24 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:58:24 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:58:24 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:58:24 --> Template Class Initialized
INFO - 2017-02-25 12:58:24 --> Model Class Initialized
INFO - 2017-02-25 12:58:24 --> Controller Class Initialized
DEBUG - 2017-02-25 12:58:24 --> Dashboard MX_Controller Initialized
INFO - 2017-02-25 12:58:24 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:58:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-25 12:58:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-02-25 12:58:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-25 12:58:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/order_history.php
DEBUG - 2017-02-25 12:58:24 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-25 12:58:24 --> Final output sent to browser
DEBUG - 2017-02-25 12:58:24 --> Total execution time: 0.0179
INFO - 2017-02-25 12:58:25 --> Config Class Initialized
INFO - 2017-02-25 12:58:25 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:58:25 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:58:25 --> Utf8 Class Initialized
INFO - 2017-02-25 12:58:25 --> URI Class Initialized
INFO - 2017-02-25 12:58:25 --> Router Class Initialized
INFO - 2017-02-25 12:58:25 --> Output Class Initialized
INFO - 2017-02-25 12:58:25 --> Security Class Initialized
DEBUG - 2017-02-25 12:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:58:25 --> Input Class Initialized
INFO - 2017-02-25 12:58:25 --> Language Class Initialized
INFO - 2017-02-25 12:58:25 --> Language Class Initialized
INFO - 2017-02-25 12:58:25 --> Config Class Initialized
INFO - 2017-02-25 12:58:25 --> Loader Class Initialized
INFO - 2017-02-25 12:58:25 --> Helper loaded: form_helper
INFO - 2017-02-25 12:58:25 --> Helper loaded: url_helper
INFO - 2017-02-25 12:58:25 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:58:25 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:58:25 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:58:25 --> Template Class Initialized
INFO - 2017-02-25 12:58:25 --> Model Class Initialized
INFO - 2017-02-25 12:58:25 --> Controller Class Initialized
DEBUG - 2017-02-25 12:58:25 --> Dashboard MX_Controller Initialized
INFO - 2017-02-25 12:58:25 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:58:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-25 12:58:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-02-25 12:58:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-25 12:58:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/download_center.php
DEBUG - 2017-02-25 12:58:25 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-25 12:58:25 --> Final output sent to browser
DEBUG - 2017-02-25 12:58:25 --> Total execution time: 0.0379
INFO - 2017-02-25 12:58:27 --> Config Class Initialized
INFO - 2017-02-25 12:58:27 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:58:27 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:58:27 --> Utf8 Class Initialized
INFO - 2017-02-25 12:58:27 --> URI Class Initialized
INFO - 2017-02-25 12:58:27 --> Router Class Initialized
INFO - 2017-02-25 12:58:27 --> Output Class Initialized
INFO - 2017-02-25 12:58:27 --> Security Class Initialized
DEBUG - 2017-02-25 12:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:58:27 --> Input Class Initialized
INFO - 2017-02-25 12:58:27 --> Language Class Initialized
INFO - 2017-02-25 12:58:27 --> Language Class Initialized
INFO - 2017-02-25 12:58:27 --> Config Class Initialized
INFO - 2017-02-25 12:58:27 --> Loader Class Initialized
INFO - 2017-02-25 12:58:27 --> Helper loaded: form_helper
INFO - 2017-02-25 12:58:27 --> Helper loaded: url_helper
INFO - 2017-02-25 12:58:27 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:58:27 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:58:27 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:58:27 --> Template Class Initialized
INFO - 2017-02-25 12:58:27 --> Model Class Initialized
INFO - 2017-02-25 12:58:27 --> Controller Class Initialized
DEBUG - 2017-02-25 12:58:27 --> Dashboard MX_Controller Initialized
INFO - 2017-02-25 12:58:27 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:58:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-25 12:58:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-02-25 12:58:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-25 12:58:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/setting.php
DEBUG - 2017-02-25 12:58:27 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-25 12:58:27 --> Final output sent to browser
DEBUG - 2017-02-25 12:58:27 --> Total execution time: 0.0166
INFO - 2017-02-25 12:58:28 --> Config Class Initialized
INFO - 2017-02-25 12:58:28 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:58:28 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:58:28 --> Utf8 Class Initialized
INFO - 2017-02-25 12:58:28 --> URI Class Initialized
INFO - 2017-02-25 12:58:28 --> Router Class Initialized
INFO - 2017-02-25 12:58:28 --> Output Class Initialized
INFO - 2017-02-25 12:58:28 --> Security Class Initialized
DEBUG - 2017-02-25 12:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:58:28 --> Input Class Initialized
INFO - 2017-02-25 12:58:28 --> Language Class Initialized
INFO - 2017-02-25 12:58:28 --> Language Class Initialized
INFO - 2017-02-25 12:58:28 --> Config Class Initialized
INFO - 2017-02-25 12:58:28 --> Loader Class Initialized
INFO - 2017-02-25 12:58:28 --> Helper loaded: form_helper
INFO - 2017-02-25 12:58:28 --> Helper loaded: url_helper
INFO - 2017-02-25 12:58:28 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:58:28 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:58:28 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:58:28 --> Template Class Initialized
INFO - 2017-02-25 12:58:28 --> Model Class Initialized
INFO - 2017-02-25 12:58:28 --> Controller Class Initialized
DEBUG - 2017-02-25 12:58:28 --> Dashboard MX_Controller Initialized
INFO - 2017-02-25 12:58:28 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:58:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-25 12:58:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/marketplace_sidebar.php
DEBUG - 2017-02-25 12:58:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-25 12:58:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-02-25 12:58:28 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-25 12:58:28 --> Final output sent to browser
DEBUG - 2017-02-25 12:58:28 --> Total execution time: 0.0191
INFO - 2017-02-25 12:58:32 --> Config Class Initialized
INFO - 2017-02-25 12:58:32 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:58:32 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:58:32 --> Utf8 Class Initialized
INFO - 2017-02-25 12:58:32 --> URI Class Initialized
INFO - 2017-02-25 12:58:32 --> Router Class Initialized
INFO - 2017-02-25 12:58:32 --> Output Class Initialized
INFO - 2017-02-25 12:58:32 --> Security Class Initialized
DEBUG - 2017-02-25 12:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:58:32 --> Input Class Initialized
INFO - 2017-02-25 12:58:32 --> Language Class Initialized
INFO - 2017-02-25 12:58:32 --> Language Class Initialized
INFO - 2017-02-25 12:58:32 --> Config Class Initialized
INFO - 2017-02-25 12:58:32 --> Loader Class Initialized
INFO - 2017-02-25 12:58:32 --> Helper loaded: form_helper
INFO - 2017-02-25 12:58:32 --> Helper loaded: url_helper
INFO - 2017-02-25 12:58:32 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:58:32 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:58:32 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:58:32 --> Template Class Initialized
INFO - 2017-02-25 12:58:32 --> Model Class Initialized
INFO - 2017-02-25 12:58:32 --> Controller Class Initialized
DEBUG - 2017-02-25 12:58:32 --> Login MX_Controller Initialized
INFO - 2017-02-25 12:58:32 --> Helper loaded: cookie_helper
INFO - 2017-02-25 12:58:32 --> Form Validation Class Initialized
INFO - 2017-02-25 12:58:33 --> Config Class Initialized
INFO - 2017-02-25 12:58:33 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:58:33 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:58:33 --> Utf8 Class Initialized
INFO - 2017-02-25 12:58:33 --> URI Class Initialized
DEBUG - 2017-02-25 12:58:33 --> No URI present. Default controller set.
INFO - 2017-02-25 12:58:33 --> Router Class Initialized
INFO - 2017-02-25 12:58:33 --> Output Class Initialized
INFO - 2017-02-25 12:58:33 --> Security Class Initialized
DEBUG - 2017-02-25 12:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:58:33 --> Input Class Initialized
INFO - 2017-02-25 12:58:33 --> Language Class Initialized
INFO - 2017-02-25 12:58:33 --> Language Class Initialized
INFO - 2017-02-25 12:58:33 --> Config Class Initialized
INFO - 2017-02-25 12:58:33 --> Loader Class Initialized
INFO - 2017-02-25 12:58:33 --> Helper loaded: form_helper
INFO - 2017-02-25 12:58:33 --> Helper loaded: url_helper
INFO - 2017-02-25 12:58:33 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:58:33 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:58:33 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:58:33 --> Template Class Initialized
INFO - 2017-02-25 12:58:33 --> Model Class Initialized
INFO - 2017-02-25 12:58:33 --> Controller Class Initialized
DEBUG - 2017-02-25 12:58:33 --> Pages MX_Controller Initialized
INFO - 2017-02-25 12:58:33 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:58:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 12:58:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 12:58:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-25 12:58:33 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 12:58:33 --> Final output sent to browser
DEBUG - 2017-02-25 12:58:33 --> Total execution time: 0.1329
INFO - 2017-02-25 12:58:33 --> Config Class Initialized
INFO - 2017-02-25 12:58:33 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:58:33 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:58:33 --> Utf8 Class Initialized
INFO - 2017-02-25 12:58:33 --> URI Class Initialized
INFO - 2017-02-25 12:58:33 --> Router Class Initialized
INFO - 2017-02-25 12:58:33 --> Output Class Initialized
INFO - 2017-02-25 12:58:33 --> Security Class Initialized
DEBUG - 2017-02-25 12:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:58:33 --> Input Class Initialized
INFO - 2017-02-25 12:58:33 --> Language Class Initialized
INFO - 2017-02-25 12:58:33 --> Language Class Initialized
INFO - 2017-02-25 12:58:33 --> Config Class Initialized
INFO - 2017-02-25 12:58:33 --> Loader Class Initialized
INFO - 2017-02-25 12:58:33 --> Helper loaded: form_helper
INFO - 2017-02-25 12:58:33 --> Helper loaded: url_helper
INFO - 2017-02-25 12:58:33 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:58:33 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:58:33 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:58:33 --> Template Class Initialized
INFO - 2017-02-25 12:58:33 --> Model Class Initialized
INFO - 2017-02-25 12:58:33 --> Controller Class Initialized
DEBUG - 2017-02-25 12:58:33 --> Pages MX_Controller Initialized
INFO - 2017-02-25 12:58:33 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:58:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 12:58:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 12:58:34 --> Config Class Initialized
INFO - 2017-02-25 12:58:34 --> Hooks Class Initialized
DEBUG - 2017-02-25 12:58:34 --> UTF-8 Support Enabled
INFO - 2017-02-25 12:58:34 --> Utf8 Class Initialized
INFO - 2017-02-25 12:58:34 --> URI Class Initialized
INFO - 2017-02-25 12:58:34 --> Router Class Initialized
INFO - 2017-02-25 12:58:34 --> Output Class Initialized
INFO - 2017-02-25 12:58:34 --> Security Class Initialized
DEBUG - 2017-02-25 12:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 12:58:34 --> Input Class Initialized
INFO - 2017-02-25 12:58:34 --> Language Class Initialized
INFO - 2017-02-25 12:58:34 --> Language Class Initialized
INFO - 2017-02-25 12:58:34 --> Config Class Initialized
INFO - 2017-02-25 12:58:34 --> Loader Class Initialized
INFO - 2017-02-25 12:58:34 --> Helper loaded: form_helper
INFO - 2017-02-25 12:58:34 --> Helper loaded: url_helper
INFO - 2017-02-25 12:58:34 --> Helper loaded: utility_helper
INFO - 2017-02-25 12:58:34 --> Database Driver Class Initialized
DEBUG - 2017-02-25 12:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 12:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 12:58:34 --> User Agent Class Initialized
DEBUG - 2017-02-25 12:58:34 --> Template Class Initialized
INFO - 2017-02-25 12:58:34 --> Model Class Initialized
INFO - 2017-02-25 12:58:34 --> Controller Class Initialized
DEBUG - 2017-02-25 12:58:34 --> Pages MX_Controller Initialized
INFO - 2017-02-25 12:58:34 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 12:58:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 12:58:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 13:15:17 --> Config Class Initialized
INFO - 2017-02-25 13:15:17 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:15:17 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:15:17 --> Utf8 Class Initialized
INFO - 2017-02-25 13:15:17 --> URI Class Initialized
INFO - 2017-02-25 13:15:17 --> Router Class Initialized
INFO - 2017-02-25 13:15:17 --> Output Class Initialized
INFO - 2017-02-25 13:15:17 --> Security Class Initialized
DEBUG - 2017-02-25 13:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:15:17 --> Input Class Initialized
INFO - 2017-02-25 13:15:17 --> Language Class Initialized
INFO - 2017-02-25 13:15:17 --> Language Class Initialized
INFO - 2017-02-25 13:15:17 --> Config Class Initialized
INFO - 2017-02-25 13:15:17 --> Loader Class Initialized
INFO - 2017-02-25 13:15:17 --> Helper loaded: form_helper
INFO - 2017-02-25 13:15:17 --> Helper loaded: url_helper
INFO - 2017-02-25 13:15:17 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:15:17 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:15:17 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:15:17 --> Template Class Initialized
INFO - 2017-02-25 13:15:17 --> Model Class Initialized
INFO - 2017-02-25 13:15:17 --> Controller Class Initialized
DEBUG - 2017-02-25 13:15:17 --> Login MX_Controller Initialized
INFO - 2017-02-25 13:15:17 --> Helper loaded: cookie_helper
INFO - 2017-02-25 13:15:17 --> Form Validation Class Initialized
INFO - 2017-02-25 13:15:18 --> Config Class Initialized
INFO - 2017-02-25 13:15:18 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:15:18 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:15:18 --> Utf8 Class Initialized
INFO - 2017-02-25 13:15:18 --> URI Class Initialized
DEBUG - 2017-02-25 13:15:18 --> No URI present. Default controller set.
INFO - 2017-02-25 13:15:18 --> Router Class Initialized
INFO - 2017-02-25 13:15:18 --> Output Class Initialized
INFO - 2017-02-25 13:15:18 --> Security Class Initialized
DEBUG - 2017-02-25 13:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:15:18 --> Input Class Initialized
INFO - 2017-02-25 13:15:18 --> Language Class Initialized
INFO - 2017-02-25 13:15:18 --> Language Class Initialized
INFO - 2017-02-25 13:15:18 --> Config Class Initialized
INFO - 2017-02-25 13:15:18 --> Loader Class Initialized
INFO - 2017-02-25 13:15:18 --> Helper loaded: form_helper
INFO - 2017-02-25 13:15:18 --> Helper loaded: url_helper
INFO - 2017-02-25 13:15:18 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:15:18 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:15:18 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:15:18 --> Template Class Initialized
INFO - 2017-02-25 13:15:18 --> Model Class Initialized
INFO - 2017-02-25 13:15:18 --> Controller Class Initialized
DEBUG - 2017-02-25 13:15:18 --> Pages MX_Controller Initialized
INFO - 2017-02-25 13:15:18 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 13:15:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 13:15:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 13:15:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-25 13:15:18 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 13:15:18 --> Final output sent to browser
DEBUG - 2017-02-25 13:15:18 --> Total execution time: 0.0422
INFO - 2017-02-25 13:15:18 --> Config Class Initialized
INFO - 2017-02-25 13:15:18 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:15:18 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:15:18 --> Utf8 Class Initialized
INFO - 2017-02-25 13:15:18 --> URI Class Initialized
INFO - 2017-02-25 13:15:18 --> Router Class Initialized
INFO - 2017-02-25 13:15:18 --> Output Class Initialized
INFO - 2017-02-25 13:15:18 --> Security Class Initialized
DEBUG - 2017-02-25 13:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:15:18 --> Input Class Initialized
INFO - 2017-02-25 13:15:18 --> Language Class Initialized
INFO - 2017-02-25 13:15:18 --> Language Class Initialized
INFO - 2017-02-25 13:15:18 --> Config Class Initialized
INFO - 2017-02-25 13:15:18 --> Loader Class Initialized
INFO - 2017-02-25 13:15:18 --> Helper loaded: form_helper
INFO - 2017-02-25 13:15:18 --> Helper loaded: url_helper
INFO - 2017-02-25 13:15:18 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:15:18 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:15:18 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:15:18 --> Template Class Initialized
INFO - 2017-02-25 13:15:18 --> Model Class Initialized
INFO - 2017-02-25 13:15:18 --> Controller Class Initialized
DEBUG - 2017-02-25 13:15:18 --> Pages MX_Controller Initialized
INFO - 2017-02-25 13:15:18 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 13:15:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 13:15:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 13:15:18 --> Config Class Initialized
INFO - 2017-02-25 13:15:18 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:15:18 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:15:18 --> Utf8 Class Initialized
INFO - 2017-02-25 13:15:18 --> URI Class Initialized
INFO - 2017-02-25 13:15:18 --> Router Class Initialized
INFO - 2017-02-25 13:15:18 --> Output Class Initialized
INFO - 2017-02-25 13:15:18 --> Security Class Initialized
DEBUG - 2017-02-25 13:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:15:18 --> Input Class Initialized
INFO - 2017-02-25 13:15:18 --> Language Class Initialized
INFO - 2017-02-25 13:15:18 --> Language Class Initialized
INFO - 2017-02-25 13:15:18 --> Config Class Initialized
INFO - 2017-02-25 13:15:18 --> Loader Class Initialized
INFO - 2017-02-25 13:15:18 --> Helper loaded: form_helper
INFO - 2017-02-25 13:15:18 --> Helper loaded: url_helper
INFO - 2017-02-25 13:15:18 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:15:18 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:15:18 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:15:18 --> Template Class Initialized
INFO - 2017-02-25 13:15:18 --> Model Class Initialized
INFO - 2017-02-25 13:15:18 --> Controller Class Initialized
DEBUG - 2017-02-25 13:15:18 --> Pages MX_Controller Initialized
INFO - 2017-02-25 13:15:18 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 13:15:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 13:15:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 13:15:26 --> Config Class Initialized
INFO - 2017-02-25 13:15:26 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:15:26 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:15:26 --> Utf8 Class Initialized
INFO - 2017-02-25 13:15:26 --> URI Class Initialized
INFO - 2017-02-25 13:15:26 --> Router Class Initialized
INFO - 2017-02-25 13:15:26 --> Output Class Initialized
INFO - 2017-02-25 13:15:26 --> Security Class Initialized
DEBUG - 2017-02-25 13:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:15:26 --> Input Class Initialized
INFO - 2017-02-25 13:15:26 --> Language Class Initialized
INFO - 2017-02-25 13:15:26 --> Language Class Initialized
INFO - 2017-02-25 13:15:26 --> Config Class Initialized
INFO - 2017-02-25 13:15:26 --> Loader Class Initialized
INFO - 2017-02-25 13:15:26 --> Helper loaded: form_helper
INFO - 2017-02-25 13:15:26 --> Helper loaded: url_helper
INFO - 2017-02-25 13:15:26 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:15:26 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:15:26 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:15:26 --> Template Class Initialized
INFO - 2017-02-25 13:15:26 --> Model Class Initialized
INFO - 2017-02-25 13:15:26 --> Controller Class Initialized
DEBUG - 2017-02-25 13:15:26 --> Pages MX_Controller Initialized
INFO - 2017-02-25 13:15:26 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 13:15:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 13:15:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 13:15:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-02-25 13:15:26 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 13:15:26 --> Final output sent to browser
DEBUG - 2017-02-25 13:15:26 --> Total execution time: 0.0131
INFO - 2017-02-25 13:15:26 --> Config Class Initialized
INFO - 2017-02-25 13:15:26 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:15:26 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:15:26 --> Utf8 Class Initialized
INFO - 2017-02-25 13:15:26 --> URI Class Initialized
INFO - 2017-02-25 13:15:26 --> Router Class Initialized
INFO - 2017-02-25 13:15:26 --> Output Class Initialized
INFO - 2017-02-25 13:15:26 --> Security Class Initialized
DEBUG - 2017-02-25 13:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:15:26 --> Input Class Initialized
INFO - 2017-02-25 13:15:26 --> Language Class Initialized
INFO - 2017-02-25 13:15:26 --> Language Class Initialized
INFO - 2017-02-25 13:15:26 --> Config Class Initialized
INFO - 2017-02-25 13:15:26 --> Loader Class Initialized
INFO - 2017-02-25 13:15:26 --> Helper loaded: form_helper
INFO - 2017-02-25 13:15:26 --> Helper loaded: url_helper
INFO - 2017-02-25 13:15:26 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:15:26 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:15:26 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:15:26 --> Template Class Initialized
INFO - 2017-02-25 13:15:26 --> Model Class Initialized
INFO - 2017-02-25 13:15:26 --> Controller Class Initialized
DEBUG - 2017-02-25 13:15:26 --> Pages MX_Controller Initialized
INFO - 2017-02-25 13:15:26 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 13:15:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 13:15:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 13:15:30 --> Config Class Initialized
INFO - 2017-02-25 13:15:30 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:15:30 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:15:30 --> Utf8 Class Initialized
INFO - 2017-02-25 13:15:30 --> URI Class Initialized
INFO - 2017-02-25 13:15:30 --> Router Class Initialized
INFO - 2017-02-25 13:15:30 --> Output Class Initialized
INFO - 2017-02-25 13:15:30 --> Security Class Initialized
DEBUG - 2017-02-25 13:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:15:30 --> Input Class Initialized
INFO - 2017-02-25 13:15:30 --> Language Class Initialized
INFO - 2017-02-25 13:15:30 --> Language Class Initialized
INFO - 2017-02-25 13:15:30 --> Config Class Initialized
INFO - 2017-02-25 13:15:30 --> Loader Class Initialized
INFO - 2017-02-25 13:15:30 --> Helper loaded: form_helper
INFO - 2017-02-25 13:15:30 --> Helper loaded: url_helper
INFO - 2017-02-25 13:15:30 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:15:30 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:15:30 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:15:30 --> Template Class Initialized
INFO - 2017-02-25 13:15:30 --> Model Class Initialized
INFO - 2017-02-25 13:15:30 --> Controller Class Initialized
DEBUG - 2017-02-25 13:15:30 --> Login MX_Controller Initialized
INFO - 2017-02-25 13:15:30 --> Helper loaded: cookie_helper
INFO - 2017-02-25 13:15:30 --> Form Validation Class Initialized
INFO - 2017-02-25 13:15:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-25 13:15:31 --> Config Class Initialized
INFO - 2017-02-25 13:15:31 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:15:31 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:15:31 --> Utf8 Class Initialized
INFO - 2017-02-25 13:15:31 --> URI Class Initialized
INFO - 2017-02-25 13:15:31 --> Router Class Initialized
INFO - 2017-02-25 13:15:31 --> Output Class Initialized
INFO - 2017-02-25 13:15:31 --> Security Class Initialized
DEBUG - 2017-02-25 13:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:15:31 --> Input Class Initialized
INFO - 2017-02-25 13:15:31 --> Language Class Initialized
INFO - 2017-02-25 13:15:31 --> Language Class Initialized
INFO - 2017-02-25 13:15:31 --> Config Class Initialized
INFO - 2017-02-25 13:15:31 --> Loader Class Initialized
INFO - 2017-02-25 13:15:31 --> Helper loaded: form_helper
INFO - 2017-02-25 13:15:31 --> Helper loaded: url_helper
INFO - 2017-02-25 13:15:31 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:15:31 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:15:31 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:15:31 --> Template Class Initialized
INFO - 2017-02-25 13:15:31 --> Model Class Initialized
INFO - 2017-02-25 13:15:31 --> Controller Class Initialized
DEBUG - 2017-02-25 13:15:31 --> Dashboard MX_Controller Initialized
INFO - 2017-02-25 13:15:31 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 13:15:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-25 13:15:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-02-25 13:15:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-25 13:15:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-02-25 13:15:31 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-25 13:15:31 --> Final output sent to browser
DEBUG - 2017-02-25 13:15:31 --> Total execution time: 0.0258
INFO - 2017-02-25 13:15:37 --> Config Class Initialized
INFO - 2017-02-25 13:15:37 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:15:37 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:15:37 --> Utf8 Class Initialized
INFO - 2017-02-25 13:15:37 --> URI Class Initialized
INFO - 2017-02-25 13:15:37 --> Router Class Initialized
INFO - 2017-02-25 13:15:37 --> Output Class Initialized
INFO - 2017-02-25 13:15:37 --> Security Class Initialized
DEBUG - 2017-02-25 13:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:15:37 --> Input Class Initialized
INFO - 2017-02-25 13:15:37 --> Language Class Initialized
INFO - 2017-02-25 13:15:37 --> Language Class Initialized
INFO - 2017-02-25 13:15:37 --> Config Class Initialized
INFO - 2017-02-25 13:15:37 --> Loader Class Initialized
INFO - 2017-02-25 13:15:37 --> Helper loaded: form_helper
INFO - 2017-02-25 13:15:37 --> Helper loaded: url_helper
INFO - 2017-02-25 13:15:37 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:15:37 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:15:37 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:15:37 --> Template Class Initialized
INFO - 2017-02-25 13:15:37 --> Model Class Initialized
INFO - 2017-02-25 13:15:37 --> Controller Class Initialized
DEBUG - 2017-02-25 13:15:37 --> Login MX_Controller Initialized
INFO - 2017-02-25 13:15:37 --> Helper loaded: cookie_helper
INFO - 2017-02-25 13:15:37 --> Form Validation Class Initialized
INFO - 2017-02-25 13:15:38 --> Config Class Initialized
INFO - 2017-02-25 13:15:38 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:15:38 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:15:38 --> Utf8 Class Initialized
INFO - 2017-02-25 13:15:38 --> URI Class Initialized
DEBUG - 2017-02-25 13:15:38 --> No URI present. Default controller set.
INFO - 2017-02-25 13:15:38 --> Router Class Initialized
INFO - 2017-02-25 13:15:38 --> Output Class Initialized
INFO - 2017-02-25 13:15:38 --> Security Class Initialized
DEBUG - 2017-02-25 13:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:15:38 --> Input Class Initialized
INFO - 2017-02-25 13:15:38 --> Language Class Initialized
INFO - 2017-02-25 13:15:38 --> Language Class Initialized
INFO - 2017-02-25 13:15:38 --> Config Class Initialized
INFO - 2017-02-25 13:15:38 --> Loader Class Initialized
INFO - 2017-02-25 13:15:38 --> Helper loaded: form_helper
INFO - 2017-02-25 13:15:38 --> Helper loaded: url_helper
INFO - 2017-02-25 13:15:38 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:15:38 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:15:38 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:15:38 --> Template Class Initialized
INFO - 2017-02-25 13:15:38 --> Model Class Initialized
INFO - 2017-02-25 13:15:38 --> Controller Class Initialized
DEBUG - 2017-02-25 13:15:38 --> Pages MX_Controller Initialized
INFO - 2017-02-25 13:15:38 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 13:15:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 13:15:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 13:15:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-25 13:15:38 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 13:15:38 --> Final output sent to browser
DEBUG - 2017-02-25 13:15:38 --> Total execution time: 0.0173
INFO - 2017-02-25 13:15:38 --> Config Class Initialized
INFO - 2017-02-25 13:15:38 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:15:38 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:15:38 --> Utf8 Class Initialized
INFO - 2017-02-25 13:15:38 --> URI Class Initialized
INFO - 2017-02-25 13:15:38 --> Router Class Initialized
INFO - 2017-02-25 13:15:38 --> Output Class Initialized
INFO - 2017-02-25 13:15:38 --> Security Class Initialized
DEBUG - 2017-02-25 13:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:15:38 --> Input Class Initialized
INFO - 2017-02-25 13:15:38 --> Language Class Initialized
INFO - 2017-02-25 13:15:38 --> Language Class Initialized
INFO - 2017-02-25 13:15:38 --> Config Class Initialized
INFO - 2017-02-25 13:15:38 --> Loader Class Initialized
INFO - 2017-02-25 13:15:38 --> Helper loaded: form_helper
INFO - 2017-02-25 13:15:38 --> Helper loaded: url_helper
INFO - 2017-02-25 13:15:38 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:15:38 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:15:38 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:15:38 --> Template Class Initialized
INFO - 2017-02-25 13:15:38 --> Model Class Initialized
INFO - 2017-02-25 13:15:38 --> Controller Class Initialized
DEBUG - 2017-02-25 13:15:38 --> Pages MX_Controller Initialized
INFO - 2017-02-25 13:15:38 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 13:15:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 13:15:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 13:15:38 --> Config Class Initialized
INFO - 2017-02-25 13:15:38 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:15:38 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:15:38 --> Utf8 Class Initialized
INFO - 2017-02-25 13:15:38 --> URI Class Initialized
INFO - 2017-02-25 13:15:38 --> Router Class Initialized
INFO - 2017-02-25 13:15:38 --> Output Class Initialized
INFO - 2017-02-25 13:15:38 --> Security Class Initialized
DEBUG - 2017-02-25 13:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:15:38 --> Input Class Initialized
INFO - 2017-02-25 13:15:38 --> Language Class Initialized
INFO - 2017-02-25 13:15:38 --> Language Class Initialized
INFO - 2017-02-25 13:15:38 --> Config Class Initialized
INFO - 2017-02-25 13:15:38 --> Loader Class Initialized
INFO - 2017-02-25 13:15:38 --> Helper loaded: form_helper
INFO - 2017-02-25 13:15:38 --> Helper loaded: url_helper
INFO - 2017-02-25 13:15:38 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:15:38 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:15:38 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:15:38 --> Template Class Initialized
INFO - 2017-02-25 13:15:38 --> Model Class Initialized
INFO - 2017-02-25 13:15:38 --> Controller Class Initialized
DEBUG - 2017-02-25 13:15:38 --> Pages MX_Controller Initialized
INFO - 2017-02-25 13:15:38 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 13:15:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 13:15:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 13:16:08 --> Config Class Initialized
INFO - 2017-02-25 13:16:08 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:16:08 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:16:08 --> Utf8 Class Initialized
INFO - 2017-02-25 13:16:08 --> URI Class Initialized
INFO - 2017-02-25 13:16:08 --> Router Class Initialized
INFO - 2017-02-25 13:16:08 --> Output Class Initialized
INFO - 2017-02-25 13:16:08 --> Security Class Initialized
DEBUG - 2017-02-25 13:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:16:08 --> Input Class Initialized
INFO - 2017-02-25 13:16:08 --> Language Class Initialized
INFO - 2017-02-25 13:16:08 --> Language Class Initialized
INFO - 2017-02-25 13:16:08 --> Config Class Initialized
INFO - 2017-02-25 13:16:08 --> Loader Class Initialized
INFO - 2017-02-25 13:16:08 --> Helper loaded: form_helper
INFO - 2017-02-25 13:16:08 --> Helper loaded: url_helper
INFO - 2017-02-25 13:16:08 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:16:08 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:16:08 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:16:08 --> Template Class Initialized
INFO - 2017-02-25 13:16:08 --> Model Class Initialized
INFO - 2017-02-25 13:16:08 --> Controller Class Initialized
DEBUG - 2017-02-25 13:16:08 --> Pages MX_Controller Initialized
INFO - 2017-02-25 13:16:08 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 13:16:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 13:16:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 13:16:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-02-25 13:16:08 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 13:16:08 --> Final output sent to browser
DEBUG - 2017-02-25 13:16:08 --> Total execution time: 0.0140
INFO - 2017-02-25 13:16:09 --> Config Class Initialized
INFO - 2017-02-25 13:16:09 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:16:09 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:16:09 --> Utf8 Class Initialized
INFO - 2017-02-25 13:16:09 --> URI Class Initialized
INFO - 2017-02-25 13:16:09 --> Router Class Initialized
INFO - 2017-02-25 13:16:09 --> Output Class Initialized
INFO - 2017-02-25 13:16:09 --> Security Class Initialized
DEBUG - 2017-02-25 13:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:16:09 --> Input Class Initialized
INFO - 2017-02-25 13:16:09 --> Language Class Initialized
INFO - 2017-02-25 13:16:09 --> Language Class Initialized
INFO - 2017-02-25 13:16:09 --> Config Class Initialized
INFO - 2017-02-25 13:16:09 --> Loader Class Initialized
INFO - 2017-02-25 13:16:09 --> Helper loaded: form_helper
INFO - 2017-02-25 13:16:09 --> Helper loaded: url_helper
INFO - 2017-02-25 13:16:09 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:16:09 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:16:09 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:16:09 --> Template Class Initialized
INFO - 2017-02-25 13:16:09 --> Model Class Initialized
INFO - 2017-02-25 13:16:09 --> Controller Class Initialized
DEBUG - 2017-02-25 13:16:09 --> Pages MX_Controller Initialized
INFO - 2017-02-25 13:16:09 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 13:16:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 13:16:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 13:16:15 --> Config Class Initialized
INFO - 2017-02-25 13:16:15 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:16:15 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:16:15 --> Utf8 Class Initialized
INFO - 2017-02-25 13:16:15 --> URI Class Initialized
INFO - 2017-02-25 13:16:15 --> Router Class Initialized
INFO - 2017-02-25 13:16:15 --> Output Class Initialized
INFO - 2017-02-25 13:16:15 --> Security Class Initialized
DEBUG - 2017-02-25 13:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:16:15 --> Input Class Initialized
INFO - 2017-02-25 13:16:15 --> Language Class Initialized
INFO - 2017-02-25 13:16:15 --> Language Class Initialized
INFO - 2017-02-25 13:16:15 --> Config Class Initialized
INFO - 2017-02-25 13:16:15 --> Loader Class Initialized
INFO - 2017-02-25 13:16:15 --> Helper loaded: form_helper
INFO - 2017-02-25 13:16:15 --> Helper loaded: url_helper
INFO - 2017-02-25 13:16:15 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:16:15 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:16:15 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:16:15 --> Template Class Initialized
INFO - 2017-02-25 13:16:15 --> Model Class Initialized
INFO - 2017-02-25 13:16:15 --> Controller Class Initialized
DEBUG - 2017-02-25 13:16:15 --> Login MX_Controller Initialized
INFO - 2017-02-25 13:16:15 --> Helper loaded: cookie_helper
INFO - 2017-02-25 13:16:15 --> Form Validation Class Initialized
INFO - 2017-02-25 13:16:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-02-25 13:16:15 --> Config Class Initialized
INFO - 2017-02-25 13:16:15 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:16:15 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:16:15 --> Utf8 Class Initialized
INFO - 2017-02-25 13:16:15 --> URI Class Initialized
INFO - 2017-02-25 13:16:15 --> Router Class Initialized
INFO - 2017-02-25 13:16:15 --> Output Class Initialized
INFO - 2017-02-25 13:16:15 --> Security Class Initialized
DEBUG - 2017-02-25 13:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:16:15 --> Input Class Initialized
INFO - 2017-02-25 13:16:15 --> Language Class Initialized
INFO - 2017-02-25 13:16:15 --> Language Class Initialized
INFO - 2017-02-25 13:16:15 --> Config Class Initialized
INFO - 2017-02-25 13:16:15 --> Loader Class Initialized
INFO - 2017-02-25 13:16:15 --> Helper loaded: form_helper
INFO - 2017-02-25 13:16:15 --> Helper loaded: url_helper
INFO - 2017-02-25 13:16:15 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:16:15 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:16:15 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:16:15 --> Template Class Initialized
INFO - 2017-02-25 13:16:15 --> Model Class Initialized
INFO - 2017-02-25 13:16:15 --> Controller Class Initialized
DEBUG - 2017-02-25 13:16:15 --> Dashboard MX_Controller Initialized
INFO - 2017-02-25 13:16:15 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 13:16:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-25 13:16:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-02-25 13:16:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-25 13:16:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-02-25 13:16:15 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-25 13:16:15 --> Final output sent to browser
DEBUG - 2017-02-25 13:16:15 --> Total execution time: 0.0165
INFO - 2017-02-25 13:17:13 --> Config Class Initialized
INFO - 2017-02-25 13:17:13 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:17:13 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:17:13 --> Utf8 Class Initialized
INFO - 2017-02-25 13:17:13 --> URI Class Initialized
INFO - 2017-02-25 13:17:13 --> Router Class Initialized
INFO - 2017-02-25 13:17:13 --> Output Class Initialized
INFO - 2017-02-25 13:17:13 --> Security Class Initialized
DEBUG - 2017-02-25 13:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:17:13 --> Input Class Initialized
INFO - 2017-02-25 13:17:13 --> Language Class Initialized
INFO - 2017-02-25 13:17:13 --> Language Class Initialized
INFO - 2017-02-25 13:17:13 --> Config Class Initialized
INFO - 2017-02-25 13:17:13 --> Loader Class Initialized
INFO - 2017-02-25 13:17:13 --> Helper loaded: form_helper
INFO - 2017-02-25 13:17:13 --> Helper loaded: url_helper
INFO - 2017-02-25 13:17:13 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:17:13 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:17:13 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:17:13 --> Template Class Initialized
INFO - 2017-02-25 13:17:13 --> Model Class Initialized
INFO - 2017-02-25 13:17:13 --> Controller Class Initialized
DEBUG - 2017-02-25 13:17:13 --> Download_data MX_Controller Initialized
INFO - 2017-02-25 13:17:13 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 13:17:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-02-25 13:17:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-02-25 13:17:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-02-25 13:17:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/download_data.php
DEBUG - 2017-02-25 13:17:13 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-02-25 13:17:13 --> Final output sent to browser
DEBUG - 2017-02-25 13:17:13 --> Total execution time: 0.0318
INFO - 2017-02-25 13:17:33 --> Config Class Initialized
INFO - 2017-02-25 13:17:33 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:17:33 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:17:33 --> Utf8 Class Initialized
INFO - 2017-02-25 13:17:33 --> URI Class Initialized
INFO - 2017-02-25 13:17:33 --> Router Class Initialized
INFO - 2017-02-25 13:17:33 --> Output Class Initialized
INFO - 2017-02-25 13:17:33 --> Security Class Initialized
DEBUG - 2017-02-25 13:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:17:33 --> Input Class Initialized
INFO - 2017-02-25 13:17:33 --> Language Class Initialized
INFO - 2017-02-25 13:17:33 --> Language Class Initialized
INFO - 2017-02-25 13:17:33 --> Config Class Initialized
INFO - 2017-02-25 13:17:33 --> Loader Class Initialized
INFO - 2017-02-25 13:17:33 --> Helper loaded: form_helper
INFO - 2017-02-25 13:17:33 --> Helper loaded: url_helper
INFO - 2017-02-25 13:17:33 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:17:33 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:17:33 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:17:33 --> Template Class Initialized
INFO - 2017-02-25 13:17:33 --> Model Class Initialized
INFO - 2017-02-25 13:17:33 --> Controller Class Initialized
DEBUG - 2017-02-25 13:17:33 --> Login MX_Controller Initialized
INFO - 2017-02-25 13:17:33 --> Helper loaded: cookie_helper
INFO - 2017-02-25 13:17:33 --> Form Validation Class Initialized
INFO - 2017-02-25 13:17:33 --> Config Class Initialized
INFO - 2017-02-25 13:17:33 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:17:33 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:17:33 --> Utf8 Class Initialized
INFO - 2017-02-25 13:17:33 --> URI Class Initialized
DEBUG - 2017-02-25 13:17:33 --> No URI present. Default controller set.
INFO - 2017-02-25 13:17:33 --> Router Class Initialized
INFO - 2017-02-25 13:17:33 --> Output Class Initialized
INFO - 2017-02-25 13:17:33 --> Security Class Initialized
DEBUG - 2017-02-25 13:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:17:33 --> Input Class Initialized
INFO - 2017-02-25 13:17:33 --> Language Class Initialized
INFO - 2017-02-25 13:17:33 --> Language Class Initialized
INFO - 2017-02-25 13:17:33 --> Config Class Initialized
INFO - 2017-02-25 13:17:33 --> Loader Class Initialized
INFO - 2017-02-25 13:17:33 --> Helper loaded: form_helper
INFO - 2017-02-25 13:17:33 --> Helper loaded: url_helper
INFO - 2017-02-25 13:17:33 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:17:33 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:17:33 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:17:33 --> Template Class Initialized
INFO - 2017-02-25 13:17:33 --> Model Class Initialized
INFO - 2017-02-25 13:17:33 --> Controller Class Initialized
DEBUG - 2017-02-25 13:17:33 --> Pages MX_Controller Initialized
INFO - 2017-02-25 13:17:33 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 13:17:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 13:17:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-02-25 13:17:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-02-25 13:17:33 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-02-25 13:17:33 --> Final output sent to browser
DEBUG - 2017-02-25 13:17:33 --> Total execution time: 0.0143
INFO - 2017-02-25 13:17:33 --> Config Class Initialized
INFO - 2017-02-25 13:17:33 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:17:33 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:17:33 --> Utf8 Class Initialized
INFO - 2017-02-25 13:17:33 --> URI Class Initialized
INFO - 2017-02-25 13:17:33 --> Router Class Initialized
INFO - 2017-02-25 13:17:33 --> Output Class Initialized
INFO - 2017-02-25 13:17:33 --> Security Class Initialized
DEBUG - 2017-02-25 13:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:17:33 --> Input Class Initialized
INFO - 2017-02-25 13:17:33 --> Language Class Initialized
INFO - 2017-02-25 13:17:33 --> Language Class Initialized
INFO - 2017-02-25 13:17:33 --> Config Class Initialized
INFO - 2017-02-25 13:17:33 --> Loader Class Initialized
INFO - 2017-02-25 13:17:33 --> Helper loaded: form_helper
INFO - 2017-02-25 13:17:33 --> Helper loaded: url_helper
INFO - 2017-02-25 13:17:33 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:17:33 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:17:33 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:17:33 --> Template Class Initialized
INFO - 2017-02-25 13:17:33 --> Model Class Initialized
INFO - 2017-02-25 13:17:33 --> Controller Class Initialized
DEBUG - 2017-02-25 13:17:33 --> Pages MX_Controller Initialized
INFO - 2017-02-25 13:17:33 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 13:17:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 13:17:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 13:17:33 --> Config Class Initialized
INFO - 2017-02-25 13:17:33 --> Hooks Class Initialized
DEBUG - 2017-02-25 13:17:33 --> UTF-8 Support Enabled
INFO - 2017-02-25 13:17:33 --> Utf8 Class Initialized
INFO - 2017-02-25 13:17:33 --> URI Class Initialized
INFO - 2017-02-25 13:17:33 --> Router Class Initialized
INFO - 2017-02-25 13:17:33 --> Output Class Initialized
INFO - 2017-02-25 13:17:33 --> Security Class Initialized
DEBUG - 2017-02-25 13:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 13:17:33 --> Input Class Initialized
INFO - 2017-02-25 13:17:33 --> Language Class Initialized
INFO - 2017-02-25 13:17:33 --> Language Class Initialized
INFO - 2017-02-25 13:17:33 --> Config Class Initialized
INFO - 2017-02-25 13:17:33 --> Loader Class Initialized
INFO - 2017-02-25 13:17:33 --> Helper loaded: form_helper
INFO - 2017-02-25 13:17:33 --> Helper loaded: url_helper
INFO - 2017-02-25 13:17:33 --> Helper loaded: utility_helper
INFO - 2017-02-25 13:17:33 --> Database Driver Class Initialized
DEBUG - 2017-02-25 13:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 13:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 13:17:33 --> User Agent Class Initialized
DEBUG - 2017-02-25 13:17:33 --> Template Class Initialized
INFO - 2017-02-25 13:17:33 --> Model Class Initialized
INFO - 2017-02-25 13:17:33 --> Controller Class Initialized
DEBUG - 2017-02-25 13:17:33 --> Pages MX_Controller Initialized
INFO - 2017-02-25 13:17:33 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 13:17:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 13:17:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 16:04:34 --> Config Class Initialized
INFO - 2017-02-25 16:04:34 --> Hooks Class Initialized
DEBUG - 2017-02-25 16:04:34 --> UTF-8 Support Enabled
INFO - 2017-02-25 16:04:34 --> Utf8 Class Initialized
INFO - 2017-02-25 16:04:34 --> URI Class Initialized
INFO - 2017-02-25 16:04:34 --> Router Class Initialized
INFO - 2017-02-25 16:04:34 --> Output Class Initialized
INFO - 2017-02-25 16:04:34 --> Security Class Initialized
DEBUG - 2017-02-25 16:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 16:04:34 --> Input Class Initialized
INFO - 2017-02-25 16:04:34 --> Language Class Initialized
INFO - 2017-02-25 16:04:34 --> Language Class Initialized
INFO - 2017-02-25 16:04:34 --> Config Class Initialized
INFO - 2017-02-25 16:04:34 --> Loader Class Initialized
INFO - 2017-02-25 16:04:34 --> Helper loaded: form_helper
INFO - 2017-02-25 16:04:34 --> Helper loaded: url_helper
INFO - 2017-02-25 16:04:34 --> Helper loaded: utility_helper
INFO - 2017-02-25 16:04:34 --> Database Driver Class Initialized
DEBUG - 2017-02-25 16:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 16:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 16:04:34 --> User Agent Class Initialized
DEBUG - 2017-02-25 16:04:34 --> Template Class Initialized
INFO - 2017-02-25 16:04:34 --> Model Class Initialized
INFO - 2017-02-25 16:04:34 --> Controller Class Initialized
DEBUG - 2017-02-25 16:04:34 --> Pages MX_Controller Initialized
INFO - 2017-02-25 16:04:34 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 16:04:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 16:04:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 22:44:09 --> Config Class Initialized
INFO - 2017-02-25 22:44:09 --> Hooks Class Initialized
DEBUG - 2017-02-25 22:44:10 --> UTF-8 Support Enabled
INFO - 2017-02-25 22:44:10 --> Utf8 Class Initialized
INFO - 2017-02-25 22:44:10 --> URI Class Initialized
INFO - 2017-02-25 22:44:10 --> Router Class Initialized
INFO - 2017-02-25 22:44:10 --> Output Class Initialized
INFO - 2017-02-25 22:44:10 --> Security Class Initialized
DEBUG - 2017-02-25 22:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 22:44:10 --> Input Class Initialized
INFO - 2017-02-25 22:44:10 --> Language Class Initialized
INFO - 2017-02-25 22:44:10 --> Language Class Initialized
INFO - 2017-02-25 22:44:10 --> Config Class Initialized
INFO - 2017-02-25 22:44:10 --> Loader Class Initialized
INFO - 2017-02-25 22:44:10 --> Helper loaded: form_helper
INFO - 2017-02-25 22:44:10 --> Helper loaded: url_helper
INFO - 2017-02-25 22:44:10 --> Helper loaded: utility_helper
INFO - 2017-02-25 22:44:10 --> Database Driver Class Initialized
DEBUG - 2017-02-25 22:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 22:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 22:44:10 --> User Agent Class Initialized
DEBUG - 2017-02-25 22:44:10 --> Template Class Initialized
INFO - 2017-02-25 22:44:10 --> Model Class Initialized
INFO - 2017-02-25 22:44:10 --> Controller Class Initialized
DEBUG - 2017-02-25 22:44:10 --> Pages MX_Controller Initialized
INFO - 2017-02-25 22:44:10 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 22:44:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 22:44:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-02-25 22:48:21 --> Config Class Initialized
INFO - 2017-02-25 22:48:21 --> Hooks Class Initialized
DEBUG - 2017-02-25 22:48:21 --> UTF-8 Support Enabled
INFO - 2017-02-25 22:48:21 --> Utf8 Class Initialized
INFO - 2017-02-25 22:48:21 --> URI Class Initialized
INFO - 2017-02-25 22:48:21 --> Router Class Initialized
INFO - 2017-02-25 22:48:21 --> Output Class Initialized
INFO - 2017-02-25 22:48:21 --> Security Class Initialized
DEBUG - 2017-02-25 22:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-25 22:48:21 --> Input Class Initialized
INFO - 2017-02-25 22:48:21 --> Language Class Initialized
INFO - 2017-02-25 22:48:21 --> Language Class Initialized
INFO - 2017-02-25 22:48:21 --> Config Class Initialized
INFO - 2017-02-25 22:48:21 --> Loader Class Initialized
INFO - 2017-02-25 22:48:21 --> Helper loaded: form_helper
INFO - 2017-02-25 22:48:21 --> Helper loaded: url_helper
INFO - 2017-02-25 22:48:21 --> Helper loaded: utility_helper
INFO - 2017-02-25 22:48:21 --> Database Driver Class Initialized
DEBUG - 2017-02-25 22:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-02-25 22:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-25 22:48:21 --> User Agent Class Initialized
DEBUG - 2017-02-25 22:48:21 --> Template Class Initialized
INFO - 2017-02-25 22:48:21 --> Model Class Initialized
INFO - 2017-02-25 22:48:21 --> Controller Class Initialized
DEBUG - 2017-02-25 22:48:21 --> Pages MX_Controller Initialized
INFO - 2017-02-25 22:48:21 --> Helper loaded: cookie_helper
DEBUG - 2017-02-25 22:48:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-02-25 22:48:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
