<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-03 01:15:40 --> Config Class Initialized
INFO - 2017-03-03 01:15:40 --> Hooks Class Initialized
DEBUG - 2017-03-03 01:15:40 --> UTF-8 Support Enabled
INFO - 2017-03-03 01:15:40 --> Utf8 Class Initialized
INFO - 2017-03-03 01:15:40 --> URI Class Initialized
INFO - 2017-03-03 01:15:40 --> Router Class Initialized
INFO - 2017-03-03 01:15:40 --> Output Class Initialized
INFO - 2017-03-03 01:15:40 --> Security Class Initialized
DEBUG - 2017-03-03 01:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 01:15:40 --> Input Class Initialized
INFO - 2017-03-03 01:15:40 --> Language Class Initialized
INFO - 2017-03-03 01:15:40 --> Language Class Initialized
INFO - 2017-03-03 01:15:40 --> Config Class Initialized
INFO - 2017-03-03 01:15:40 --> Loader Class Initialized
INFO - 2017-03-03 01:15:40 --> Helper loaded: form_helper
INFO - 2017-03-03 01:15:40 --> Helper loaded: url_helper
INFO - 2017-03-03 01:15:40 --> Helper loaded: utility_helper
INFO - 2017-03-03 01:15:40 --> Database Driver Class Initialized
DEBUG - 2017-03-03 01:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 01:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 01:15:40 --> User Agent Class Initialized
DEBUG - 2017-03-03 01:15:40 --> Template Class Initialized
INFO - 2017-03-03 01:15:40 --> Model Class Initialized
INFO - 2017-03-03 01:15:40 --> Controller Class Initialized
DEBUG - 2017-03-03 01:15:40 --> Pages MX_Controller Initialized
INFO - 2017-03-03 01:15:40 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 01:15:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 01:15:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 02:43:14 --> Config Class Initialized
INFO - 2017-03-03 02:43:14 --> Hooks Class Initialized
DEBUG - 2017-03-03 02:43:14 --> UTF-8 Support Enabled
INFO - 2017-03-03 02:43:14 --> Utf8 Class Initialized
INFO - 2017-03-03 02:43:14 --> URI Class Initialized
DEBUG - 2017-03-03 02:43:14 --> No URI present. Default controller set.
INFO - 2017-03-03 02:43:14 --> Router Class Initialized
INFO - 2017-03-03 02:43:14 --> Output Class Initialized
INFO - 2017-03-03 02:43:14 --> Security Class Initialized
DEBUG - 2017-03-03 02:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 02:43:14 --> Input Class Initialized
INFO - 2017-03-03 02:43:14 --> Language Class Initialized
INFO - 2017-03-03 02:43:14 --> Language Class Initialized
INFO - 2017-03-03 02:43:14 --> Config Class Initialized
INFO - 2017-03-03 02:43:14 --> Loader Class Initialized
INFO - 2017-03-03 02:43:14 --> Helper loaded: form_helper
INFO - 2017-03-03 02:43:14 --> Helper loaded: url_helper
INFO - 2017-03-03 02:43:14 --> Helper loaded: utility_helper
INFO - 2017-03-03 02:43:14 --> Database Driver Class Initialized
DEBUG - 2017-03-03 02:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 02:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 02:43:14 --> User Agent Class Initialized
DEBUG - 2017-03-03 02:43:14 --> Template Class Initialized
INFO - 2017-03-03 02:43:14 --> Model Class Initialized
INFO - 2017-03-03 02:43:14 --> Controller Class Initialized
DEBUG - 2017-03-03 02:43:14 --> Pages MX_Controller Initialized
INFO - 2017-03-03 02:43:14 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 02:43:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 02:43:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 02:43:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-03 02:43:15 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 02:43:15 --> Final output sent to browser
DEBUG - 2017-03-03 02:43:15 --> Total execution time: 0.1017
INFO - 2017-03-03 02:43:17 --> Config Class Initialized
INFO - 2017-03-03 02:43:17 --> Hooks Class Initialized
DEBUG - 2017-03-03 02:43:17 --> UTF-8 Support Enabled
INFO - 2017-03-03 02:43:17 --> Utf8 Class Initialized
INFO - 2017-03-03 02:43:17 --> URI Class Initialized
INFO - 2017-03-03 02:43:17 --> Router Class Initialized
INFO - 2017-03-03 02:43:17 --> Output Class Initialized
INFO - 2017-03-03 02:43:17 --> Security Class Initialized
DEBUG - 2017-03-03 02:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 02:43:17 --> Input Class Initialized
INFO - 2017-03-03 02:43:17 --> Language Class Initialized
INFO - 2017-03-03 02:43:17 --> Language Class Initialized
INFO - 2017-03-03 02:43:17 --> Config Class Initialized
INFO - 2017-03-03 02:43:17 --> Loader Class Initialized
INFO - 2017-03-03 02:43:17 --> Helper loaded: form_helper
INFO - 2017-03-03 02:43:17 --> Helper loaded: url_helper
INFO - 2017-03-03 02:43:17 --> Helper loaded: utility_helper
INFO - 2017-03-03 02:43:17 --> Database Driver Class Initialized
DEBUG - 2017-03-03 02:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 02:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 02:43:17 --> User Agent Class Initialized
DEBUG - 2017-03-03 02:43:17 --> Template Class Initialized
INFO - 2017-03-03 02:43:17 --> Model Class Initialized
INFO - 2017-03-03 02:43:17 --> Controller Class Initialized
DEBUG - 2017-03-03 02:43:17 --> Pages MX_Controller Initialized
INFO - 2017-03-03 02:43:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 02:43:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 02:43:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 02:43:18 --> Config Class Initialized
INFO - 2017-03-03 02:43:18 --> Hooks Class Initialized
DEBUG - 2017-03-03 02:43:18 --> UTF-8 Support Enabled
INFO - 2017-03-03 02:43:18 --> Utf8 Class Initialized
INFO - 2017-03-03 02:43:18 --> URI Class Initialized
INFO - 2017-03-03 02:43:18 --> Router Class Initialized
INFO - 2017-03-03 02:43:18 --> Output Class Initialized
INFO - 2017-03-03 02:43:18 --> Security Class Initialized
DEBUG - 2017-03-03 02:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 02:43:18 --> Input Class Initialized
INFO - 2017-03-03 02:43:18 --> Language Class Initialized
INFO - 2017-03-03 02:43:18 --> Language Class Initialized
INFO - 2017-03-03 02:43:18 --> Config Class Initialized
INFO - 2017-03-03 02:43:18 --> Loader Class Initialized
INFO - 2017-03-03 02:43:18 --> Helper loaded: form_helper
INFO - 2017-03-03 02:43:18 --> Helper loaded: url_helper
INFO - 2017-03-03 02:43:18 --> Helper loaded: utility_helper
INFO - 2017-03-03 02:43:18 --> Database Driver Class Initialized
DEBUG - 2017-03-03 02:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 02:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 02:43:18 --> User Agent Class Initialized
DEBUG - 2017-03-03 02:43:18 --> Template Class Initialized
INFO - 2017-03-03 02:43:18 --> Model Class Initialized
INFO - 2017-03-03 02:43:18 --> Controller Class Initialized
DEBUG - 2017-03-03 02:43:18 --> Pages MX_Controller Initialized
INFO - 2017-03-03 02:43:18 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 02:43:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 02:43:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 02:45:08 --> Config Class Initialized
INFO - 2017-03-03 02:45:08 --> Hooks Class Initialized
DEBUG - 2017-03-03 02:45:08 --> UTF-8 Support Enabled
INFO - 2017-03-03 02:45:08 --> Utf8 Class Initialized
INFO - 2017-03-03 02:45:08 --> URI Class Initialized
INFO - 2017-03-03 02:45:08 --> Router Class Initialized
INFO - 2017-03-03 02:45:08 --> Output Class Initialized
INFO - 2017-03-03 02:45:08 --> Security Class Initialized
DEBUG - 2017-03-03 02:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 02:45:08 --> Input Class Initialized
INFO - 2017-03-03 02:45:08 --> Language Class Initialized
INFO - 2017-03-03 02:45:08 --> Language Class Initialized
INFO - 2017-03-03 02:45:08 --> Config Class Initialized
INFO - 2017-03-03 02:45:08 --> Loader Class Initialized
INFO - 2017-03-03 02:45:08 --> Helper loaded: form_helper
INFO - 2017-03-03 02:45:08 --> Helper loaded: url_helper
INFO - 2017-03-03 02:45:08 --> Helper loaded: utility_helper
INFO - 2017-03-03 02:45:08 --> Database Driver Class Initialized
DEBUG - 2017-03-03 02:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 02:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 02:45:08 --> User Agent Class Initialized
DEBUG - 2017-03-03 02:45:08 --> Template Class Initialized
INFO - 2017-03-03 02:45:08 --> Model Class Initialized
INFO - 2017-03-03 02:45:08 --> Controller Class Initialized
DEBUG - 2017-03-03 02:45:08 --> Pages MX_Controller Initialized
INFO - 2017-03-03 02:45:08 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 02:45:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 02:45:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 02:45:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-03-03 02:45:08 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 02:45:08 --> Final output sent to browser
DEBUG - 2017-03-03 02:45:08 --> Total execution time: 0.0302
INFO - 2017-03-03 02:45:09 --> Config Class Initialized
INFO - 2017-03-03 02:45:09 --> Hooks Class Initialized
DEBUG - 2017-03-03 02:45:09 --> UTF-8 Support Enabled
INFO - 2017-03-03 02:45:09 --> Utf8 Class Initialized
INFO - 2017-03-03 02:45:09 --> URI Class Initialized
INFO - 2017-03-03 02:45:09 --> Router Class Initialized
INFO - 2017-03-03 02:45:09 --> Output Class Initialized
INFO - 2017-03-03 02:45:09 --> Security Class Initialized
DEBUG - 2017-03-03 02:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 02:45:09 --> Input Class Initialized
INFO - 2017-03-03 02:45:09 --> Language Class Initialized
INFO - 2017-03-03 02:45:09 --> Language Class Initialized
INFO - 2017-03-03 02:45:09 --> Config Class Initialized
INFO - 2017-03-03 02:45:09 --> Loader Class Initialized
INFO - 2017-03-03 02:45:09 --> Helper loaded: form_helper
INFO - 2017-03-03 02:45:09 --> Helper loaded: url_helper
INFO - 2017-03-03 02:45:09 --> Helper loaded: utility_helper
INFO - 2017-03-03 02:45:09 --> Database Driver Class Initialized
DEBUG - 2017-03-03 02:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 02:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 02:45:09 --> User Agent Class Initialized
DEBUG - 2017-03-03 02:45:09 --> Template Class Initialized
INFO - 2017-03-03 02:45:09 --> Model Class Initialized
INFO - 2017-03-03 02:45:09 --> Controller Class Initialized
DEBUG - 2017-03-03 02:45:09 --> Pages MX_Controller Initialized
INFO - 2017-03-03 02:45:09 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 02:45:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 02:45:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 02:46:17 --> Config Class Initialized
INFO - 2017-03-03 02:46:17 --> Hooks Class Initialized
DEBUG - 2017-03-03 02:46:17 --> UTF-8 Support Enabled
INFO - 2017-03-03 02:46:17 --> Utf8 Class Initialized
INFO - 2017-03-03 02:46:17 --> URI Class Initialized
DEBUG - 2017-03-03 02:46:17 --> No URI present. Default controller set.
INFO - 2017-03-03 02:46:17 --> Router Class Initialized
INFO - 2017-03-03 02:46:17 --> Output Class Initialized
INFO - 2017-03-03 02:46:17 --> Security Class Initialized
DEBUG - 2017-03-03 02:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 02:46:17 --> Input Class Initialized
INFO - 2017-03-03 02:46:17 --> Language Class Initialized
INFO - 2017-03-03 02:46:17 --> Language Class Initialized
INFO - 2017-03-03 02:46:17 --> Config Class Initialized
INFO - 2017-03-03 02:46:17 --> Loader Class Initialized
INFO - 2017-03-03 02:46:17 --> Helper loaded: form_helper
INFO - 2017-03-03 02:46:17 --> Helper loaded: url_helper
INFO - 2017-03-03 02:46:17 --> Helper loaded: utility_helper
INFO - 2017-03-03 02:46:17 --> Database Driver Class Initialized
DEBUG - 2017-03-03 02:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 02:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 02:46:17 --> User Agent Class Initialized
DEBUG - 2017-03-03 02:46:17 --> Template Class Initialized
INFO - 2017-03-03 02:46:17 --> Model Class Initialized
INFO - 2017-03-03 02:46:17 --> Controller Class Initialized
DEBUG - 2017-03-03 02:46:17 --> Pages MX_Controller Initialized
INFO - 2017-03-03 02:46:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 02:46:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 02:46:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 02:46:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-03 02:46:17 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 02:46:17 --> Final output sent to browser
DEBUG - 2017-03-03 02:46:17 --> Total execution time: 0.0175
INFO - 2017-03-03 02:46:17 --> Config Class Initialized
INFO - 2017-03-03 02:46:17 --> Hooks Class Initialized
DEBUG - 2017-03-03 02:46:17 --> UTF-8 Support Enabled
INFO - 2017-03-03 02:46:17 --> Utf8 Class Initialized
INFO - 2017-03-03 02:46:17 --> URI Class Initialized
INFO - 2017-03-03 02:46:17 --> Router Class Initialized
INFO - 2017-03-03 02:46:17 --> Output Class Initialized
INFO - 2017-03-03 02:46:17 --> Security Class Initialized
DEBUG - 2017-03-03 02:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 02:46:17 --> Input Class Initialized
INFO - 2017-03-03 02:46:17 --> Language Class Initialized
INFO - 2017-03-03 02:46:17 --> Language Class Initialized
INFO - 2017-03-03 02:46:17 --> Config Class Initialized
INFO - 2017-03-03 02:46:17 --> Loader Class Initialized
INFO - 2017-03-03 02:46:17 --> Helper loaded: form_helper
INFO - 2017-03-03 02:46:17 --> Helper loaded: url_helper
INFO - 2017-03-03 02:46:17 --> Helper loaded: utility_helper
INFO - 2017-03-03 02:46:17 --> Database Driver Class Initialized
DEBUG - 2017-03-03 02:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 02:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 02:46:17 --> User Agent Class Initialized
DEBUG - 2017-03-03 02:46:17 --> Template Class Initialized
INFO - 2017-03-03 02:46:17 --> Model Class Initialized
INFO - 2017-03-03 02:46:17 --> Controller Class Initialized
DEBUG - 2017-03-03 02:46:17 --> Pages MX_Controller Initialized
INFO - 2017-03-03 02:46:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 02:46:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 02:46:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 02:46:18 --> Config Class Initialized
INFO - 2017-03-03 02:46:18 --> Hooks Class Initialized
DEBUG - 2017-03-03 02:46:18 --> UTF-8 Support Enabled
INFO - 2017-03-03 02:46:18 --> Utf8 Class Initialized
INFO - 2017-03-03 02:46:18 --> URI Class Initialized
INFO - 2017-03-03 02:46:18 --> Router Class Initialized
INFO - 2017-03-03 02:46:18 --> Output Class Initialized
INFO - 2017-03-03 02:46:18 --> Security Class Initialized
DEBUG - 2017-03-03 02:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 02:46:18 --> Input Class Initialized
INFO - 2017-03-03 02:46:18 --> Language Class Initialized
INFO - 2017-03-03 02:46:18 --> Language Class Initialized
INFO - 2017-03-03 02:46:18 --> Config Class Initialized
INFO - 2017-03-03 02:46:18 --> Loader Class Initialized
INFO - 2017-03-03 02:46:18 --> Helper loaded: form_helper
INFO - 2017-03-03 02:46:18 --> Helper loaded: url_helper
INFO - 2017-03-03 02:46:18 --> Helper loaded: utility_helper
INFO - 2017-03-03 02:46:18 --> Database Driver Class Initialized
DEBUG - 2017-03-03 02:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 02:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 02:46:18 --> User Agent Class Initialized
DEBUG - 2017-03-03 02:46:18 --> Template Class Initialized
INFO - 2017-03-03 02:46:18 --> Model Class Initialized
INFO - 2017-03-03 02:46:18 --> Controller Class Initialized
DEBUG - 2017-03-03 02:46:18 --> Pages MX_Controller Initialized
INFO - 2017-03-03 02:46:18 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 02:46:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 02:46:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 16:44:35 --> Config Class Initialized
INFO - 2017-03-03 16:44:35 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:44:35 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:44:35 --> Utf8 Class Initialized
INFO - 2017-03-03 16:44:35 --> URI Class Initialized
DEBUG - 2017-03-03 16:44:35 --> No URI present. Default controller set.
INFO - 2017-03-03 16:44:35 --> Router Class Initialized
INFO - 2017-03-03 16:44:35 --> Output Class Initialized
INFO - 2017-03-03 16:44:35 --> Security Class Initialized
DEBUG - 2017-03-03 16:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:44:35 --> Input Class Initialized
INFO - 2017-03-03 16:44:35 --> Language Class Initialized
INFO - 2017-03-03 16:44:35 --> Language Class Initialized
INFO - 2017-03-03 16:44:35 --> Config Class Initialized
INFO - 2017-03-03 16:44:35 --> Loader Class Initialized
INFO - 2017-03-03 16:44:35 --> Helper loaded: form_helper
INFO - 2017-03-03 16:44:35 --> Helper loaded: url_helper
INFO - 2017-03-03 16:44:35 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:44:35 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:44:35 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:44:35 --> Template Class Initialized
INFO - 2017-03-03 16:44:35 --> Model Class Initialized
INFO - 2017-03-03 16:44:35 --> Controller Class Initialized
DEBUG - 2017-03-03 16:44:35 --> Pages MX_Controller Initialized
INFO - 2017-03-03 16:44:35 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:44:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 16:44:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 16:44:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-03 16:44:36 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 16:44:36 --> Final output sent to browser
DEBUG - 2017-03-03 16:44:36 --> Total execution time: 0.2316
INFO - 2017-03-03 16:44:37 --> Config Class Initialized
INFO - 2017-03-03 16:44:37 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:44:37 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:44:37 --> Utf8 Class Initialized
INFO - 2017-03-03 16:44:37 --> URI Class Initialized
INFO - 2017-03-03 16:44:37 --> Router Class Initialized
INFO - 2017-03-03 16:44:37 --> Output Class Initialized
INFO - 2017-03-03 16:44:37 --> Security Class Initialized
DEBUG - 2017-03-03 16:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:44:37 --> Input Class Initialized
INFO - 2017-03-03 16:44:37 --> Language Class Initialized
INFO - 2017-03-03 16:44:37 --> Language Class Initialized
INFO - 2017-03-03 16:44:37 --> Config Class Initialized
INFO - 2017-03-03 16:44:37 --> Loader Class Initialized
INFO - 2017-03-03 16:44:37 --> Helper loaded: form_helper
INFO - 2017-03-03 16:44:37 --> Helper loaded: url_helper
INFO - 2017-03-03 16:44:37 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:44:37 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:44:37 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:44:37 --> Template Class Initialized
INFO - 2017-03-03 16:44:37 --> Model Class Initialized
INFO - 2017-03-03 16:44:37 --> Controller Class Initialized
DEBUG - 2017-03-03 16:44:37 --> Pages MX_Controller Initialized
INFO - 2017-03-03 16:44:37 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:44:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 16:44:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 16:44:38 --> Config Class Initialized
INFO - 2017-03-03 16:44:38 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:44:38 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:44:38 --> Utf8 Class Initialized
INFO - 2017-03-03 16:44:38 --> URI Class Initialized
INFO - 2017-03-03 16:44:38 --> Router Class Initialized
INFO - 2017-03-03 16:44:38 --> Output Class Initialized
INFO - 2017-03-03 16:44:38 --> Security Class Initialized
DEBUG - 2017-03-03 16:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:44:38 --> Input Class Initialized
INFO - 2017-03-03 16:44:38 --> Language Class Initialized
INFO - 2017-03-03 16:44:38 --> Language Class Initialized
INFO - 2017-03-03 16:44:38 --> Config Class Initialized
INFO - 2017-03-03 16:44:38 --> Loader Class Initialized
INFO - 2017-03-03 16:44:38 --> Helper loaded: form_helper
INFO - 2017-03-03 16:44:38 --> Helper loaded: url_helper
INFO - 2017-03-03 16:44:38 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:44:38 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:44:38 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:44:38 --> Template Class Initialized
INFO - 2017-03-03 16:44:38 --> Model Class Initialized
INFO - 2017-03-03 16:44:38 --> Controller Class Initialized
DEBUG - 2017-03-03 16:44:38 --> Pages MX_Controller Initialized
INFO - 2017-03-03 16:44:38 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:44:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 16:44:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 16:44:39 --> Config Class Initialized
INFO - 2017-03-03 16:44:39 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:44:39 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:44:39 --> Utf8 Class Initialized
INFO - 2017-03-03 16:44:39 --> URI Class Initialized
INFO - 2017-03-03 16:44:39 --> Router Class Initialized
INFO - 2017-03-03 16:44:39 --> Output Class Initialized
INFO - 2017-03-03 16:44:39 --> Security Class Initialized
DEBUG - 2017-03-03 16:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:44:39 --> Input Class Initialized
INFO - 2017-03-03 16:44:39 --> Language Class Initialized
INFO - 2017-03-03 16:44:39 --> Language Class Initialized
INFO - 2017-03-03 16:44:39 --> Config Class Initialized
INFO - 2017-03-03 16:44:39 --> Loader Class Initialized
INFO - 2017-03-03 16:44:39 --> Helper loaded: form_helper
INFO - 2017-03-03 16:44:39 --> Helper loaded: url_helper
INFO - 2017-03-03 16:44:39 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:44:39 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:44:39 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:44:39 --> Template Class Initialized
INFO - 2017-03-03 16:44:39 --> Model Class Initialized
INFO - 2017-03-03 16:44:39 --> Controller Class Initialized
DEBUG - 2017-03-03 16:44:39 --> Pages MX_Controller Initialized
INFO - 2017-03-03 16:44:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:44:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 16:44:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 16:44:39 --> Config Class Initialized
INFO - 2017-03-03 16:44:39 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:44:39 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:44:39 --> Utf8 Class Initialized
INFO - 2017-03-03 16:44:39 --> URI Class Initialized
INFO - 2017-03-03 16:44:39 --> Router Class Initialized
INFO - 2017-03-03 16:44:39 --> Output Class Initialized
INFO - 2017-03-03 16:44:39 --> Security Class Initialized
DEBUG - 2017-03-03 16:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:44:39 --> Input Class Initialized
INFO - 2017-03-03 16:44:39 --> Language Class Initialized
INFO - 2017-03-03 16:44:39 --> Language Class Initialized
INFO - 2017-03-03 16:44:39 --> Config Class Initialized
INFO - 2017-03-03 16:44:39 --> Loader Class Initialized
INFO - 2017-03-03 16:44:39 --> Helper loaded: form_helper
INFO - 2017-03-03 16:44:39 --> Helper loaded: url_helper
INFO - 2017-03-03 16:44:39 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:44:39 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:44:39 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:44:39 --> Template Class Initialized
INFO - 2017-03-03 16:44:39 --> Model Class Initialized
INFO - 2017-03-03 16:44:39 --> Controller Class Initialized
DEBUG - 2017-03-03 16:44:39 --> Pages MX_Controller Initialized
INFO - 2017-03-03 16:44:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:44:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 16:44:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 16:44:40 --> Config Class Initialized
INFO - 2017-03-03 16:44:40 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:44:40 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:44:40 --> Utf8 Class Initialized
INFO - 2017-03-03 16:44:40 --> URI Class Initialized
INFO - 2017-03-03 16:44:40 --> Router Class Initialized
INFO - 2017-03-03 16:44:40 --> Output Class Initialized
INFO - 2017-03-03 16:44:40 --> Security Class Initialized
DEBUG - 2017-03-03 16:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:44:40 --> Input Class Initialized
INFO - 2017-03-03 16:44:40 --> Language Class Initialized
INFO - 2017-03-03 16:44:40 --> Language Class Initialized
INFO - 2017-03-03 16:44:40 --> Config Class Initialized
INFO - 2017-03-03 16:44:40 --> Loader Class Initialized
INFO - 2017-03-03 16:44:40 --> Helper loaded: form_helper
INFO - 2017-03-03 16:44:40 --> Helper loaded: url_helper
INFO - 2017-03-03 16:44:40 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:44:40 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:44:40 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:44:40 --> Template Class Initialized
INFO - 2017-03-03 16:44:40 --> Model Class Initialized
INFO - 2017-03-03 16:44:40 --> Controller Class Initialized
DEBUG - 2017-03-03 16:44:40 --> Pages MX_Controller Initialized
INFO - 2017-03-03 16:44:40 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:44:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 16:44:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 16:44:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-03 16:44:40 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 16:44:40 --> Final output sent to browser
DEBUG - 2017-03-03 16:44:40 --> Total execution time: 0.0173
INFO - 2017-03-03 16:44:40 --> Config Class Initialized
INFO - 2017-03-03 16:44:40 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:44:40 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:44:40 --> Utf8 Class Initialized
INFO - 2017-03-03 16:44:40 --> URI Class Initialized
INFO - 2017-03-03 16:44:40 --> Router Class Initialized
INFO - 2017-03-03 16:44:40 --> Output Class Initialized
INFO - 2017-03-03 16:44:40 --> Security Class Initialized
DEBUG - 2017-03-03 16:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:44:40 --> Input Class Initialized
INFO - 2017-03-03 16:44:40 --> Language Class Initialized
INFO - 2017-03-03 16:44:40 --> Language Class Initialized
INFO - 2017-03-03 16:44:40 --> Config Class Initialized
INFO - 2017-03-03 16:44:40 --> Loader Class Initialized
INFO - 2017-03-03 16:44:40 --> Helper loaded: form_helper
INFO - 2017-03-03 16:44:40 --> Helper loaded: url_helper
INFO - 2017-03-03 16:44:40 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:44:40 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:44:40 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:44:40 --> Template Class Initialized
INFO - 2017-03-03 16:44:40 --> Model Class Initialized
INFO - 2017-03-03 16:44:40 --> Controller Class Initialized
DEBUG - 2017-03-03 16:44:40 --> Pages MX_Controller Initialized
INFO - 2017-03-03 16:44:40 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:44:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 16:44:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 16:44:41 --> Config Class Initialized
INFO - 2017-03-03 16:44:41 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:44:41 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:44:41 --> Utf8 Class Initialized
INFO - 2017-03-03 16:44:41 --> URI Class Initialized
INFO - 2017-03-03 16:44:41 --> Router Class Initialized
INFO - 2017-03-03 16:44:41 --> Output Class Initialized
INFO - 2017-03-03 16:44:41 --> Security Class Initialized
DEBUG - 2017-03-03 16:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:44:41 --> Input Class Initialized
INFO - 2017-03-03 16:44:41 --> Language Class Initialized
INFO - 2017-03-03 16:44:41 --> Language Class Initialized
INFO - 2017-03-03 16:44:41 --> Config Class Initialized
INFO - 2017-03-03 16:44:41 --> Loader Class Initialized
INFO - 2017-03-03 16:44:41 --> Helper loaded: form_helper
INFO - 2017-03-03 16:44:41 --> Helper loaded: url_helper
INFO - 2017-03-03 16:44:41 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:44:41 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:44:41 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:44:41 --> Template Class Initialized
INFO - 2017-03-03 16:44:41 --> Model Class Initialized
INFO - 2017-03-03 16:44:41 --> Controller Class Initialized
DEBUG - 2017-03-03 16:44:41 --> Pages MX_Controller Initialized
INFO - 2017-03-03 16:44:41 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:44:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 16:44:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 16:44:41 --> Config Class Initialized
INFO - 2017-03-03 16:44:41 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:44:41 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:44:41 --> Utf8 Class Initialized
INFO - 2017-03-03 16:44:41 --> URI Class Initialized
INFO - 2017-03-03 16:44:41 --> Router Class Initialized
INFO - 2017-03-03 16:44:41 --> Output Class Initialized
INFO - 2017-03-03 16:44:41 --> Security Class Initialized
DEBUG - 2017-03-03 16:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:44:41 --> Input Class Initialized
INFO - 2017-03-03 16:44:41 --> Language Class Initialized
INFO - 2017-03-03 16:44:41 --> Language Class Initialized
INFO - 2017-03-03 16:44:41 --> Config Class Initialized
INFO - 2017-03-03 16:44:41 --> Loader Class Initialized
INFO - 2017-03-03 16:44:41 --> Helper loaded: form_helper
INFO - 2017-03-03 16:44:41 --> Helper loaded: url_helper
INFO - 2017-03-03 16:44:41 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:44:41 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:44:41 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:44:41 --> Template Class Initialized
INFO - 2017-03-03 16:44:41 --> Model Class Initialized
INFO - 2017-03-03 16:44:41 --> Controller Class Initialized
DEBUG - 2017-03-03 16:44:41 --> Pages MX_Controller Initialized
INFO - 2017-03-03 16:44:41 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:44:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 16:44:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 16:44:49 --> Config Class Initialized
INFO - 2017-03-03 16:44:49 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:44:49 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:44:49 --> Utf8 Class Initialized
INFO - 2017-03-03 16:44:49 --> URI Class Initialized
INFO - 2017-03-03 16:44:49 --> Router Class Initialized
INFO - 2017-03-03 16:44:49 --> Output Class Initialized
INFO - 2017-03-03 16:44:49 --> Security Class Initialized
DEBUG - 2017-03-03 16:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:44:49 --> Input Class Initialized
INFO - 2017-03-03 16:44:49 --> Language Class Initialized
INFO - 2017-03-03 16:44:49 --> Language Class Initialized
INFO - 2017-03-03 16:44:49 --> Config Class Initialized
INFO - 2017-03-03 16:44:49 --> Loader Class Initialized
INFO - 2017-03-03 16:44:49 --> Helper loaded: form_helper
INFO - 2017-03-03 16:44:49 --> Helper loaded: url_helper
INFO - 2017-03-03 16:44:49 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:44:49 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:44:49 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:44:49 --> Template Class Initialized
INFO - 2017-03-03 16:44:49 --> Model Class Initialized
INFO - 2017-03-03 16:44:49 --> Controller Class Initialized
DEBUG - 2017-03-03 16:44:49 --> Login MX_Controller Initialized
INFO - 2017-03-03 16:44:49 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:44:49 --> Form Validation Class Initialized
INFO - 2017-03-03 16:44:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-03 16:44:50 --> Config Class Initialized
INFO - 2017-03-03 16:44:50 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:44:50 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:44:50 --> Utf8 Class Initialized
INFO - 2017-03-03 16:44:50 --> URI Class Initialized
INFO - 2017-03-03 16:44:50 --> Router Class Initialized
INFO - 2017-03-03 16:44:50 --> Output Class Initialized
INFO - 2017-03-03 16:44:50 --> Security Class Initialized
DEBUG - 2017-03-03 16:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:44:50 --> Input Class Initialized
INFO - 2017-03-03 16:44:50 --> Language Class Initialized
INFO - 2017-03-03 16:44:50 --> Language Class Initialized
INFO - 2017-03-03 16:44:50 --> Config Class Initialized
INFO - 2017-03-03 16:44:50 --> Loader Class Initialized
INFO - 2017-03-03 16:44:50 --> Helper loaded: form_helper
INFO - 2017-03-03 16:44:50 --> Helper loaded: url_helper
INFO - 2017-03-03 16:44:50 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:44:50 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:44:50 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:44:50 --> Template Class Initialized
INFO - 2017-03-03 16:44:50 --> Model Class Initialized
INFO - 2017-03-03 16:44:50 --> Controller Class Initialized
DEBUG - 2017-03-03 16:44:50 --> Dashboard MX_Controller Initialized
INFO - 2017-03-03 16:44:50 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:44:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 16:44:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 16:44:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 16:44:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-03 16:44:50 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 16:44:50 --> Final output sent to browser
DEBUG - 2017-03-03 16:44:50 --> Total execution time: 0.0463
INFO - 2017-03-03 16:45:01 --> Config Class Initialized
INFO - 2017-03-03 16:45:01 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:45:01 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:45:01 --> Utf8 Class Initialized
INFO - 2017-03-03 16:45:01 --> URI Class Initialized
INFO - 2017-03-03 16:45:01 --> Router Class Initialized
INFO - 2017-03-03 16:45:01 --> Output Class Initialized
INFO - 2017-03-03 16:45:01 --> Security Class Initialized
DEBUG - 2017-03-03 16:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:45:01 --> Input Class Initialized
INFO - 2017-03-03 16:45:01 --> Language Class Initialized
INFO - 2017-03-03 16:45:01 --> Language Class Initialized
INFO - 2017-03-03 16:45:01 --> Config Class Initialized
INFO - 2017-03-03 16:45:01 --> Loader Class Initialized
INFO - 2017-03-03 16:45:01 --> Helper loaded: form_helper
INFO - 2017-03-03 16:45:01 --> Helper loaded: url_helper
INFO - 2017-03-03 16:45:01 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:45:01 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:45:01 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:45:01 --> Template Class Initialized
INFO - 2017-03-03 16:45:01 --> Model Class Initialized
INFO - 2017-03-03 16:45:01 --> Controller Class Initialized
DEBUG - 2017-03-03 16:45:01 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:45:01 --> Helper loaded: cookie_helper
ERROR - 2017-03-03 16:45:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Project_Model /home/rebelute/public_html/silohost/system/core/Loader.php 344
INFO - 2017-03-03 16:45:58 --> Config Class Initialized
INFO - 2017-03-03 16:45:58 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:45:58 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:45:58 --> Utf8 Class Initialized
INFO - 2017-03-03 16:45:58 --> URI Class Initialized
INFO - 2017-03-03 16:45:58 --> Router Class Initialized
INFO - 2017-03-03 16:45:58 --> Output Class Initialized
INFO - 2017-03-03 16:45:58 --> Security Class Initialized
DEBUG - 2017-03-03 16:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:45:58 --> Input Class Initialized
INFO - 2017-03-03 16:45:58 --> Language Class Initialized
INFO - 2017-03-03 16:45:58 --> Language Class Initialized
INFO - 2017-03-03 16:45:58 --> Config Class Initialized
INFO - 2017-03-03 16:45:58 --> Loader Class Initialized
INFO - 2017-03-03 16:45:58 --> Helper loaded: form_helper
INFO - 2017-03-03 16:45:58 --> Helper loaded: url_helper
INFO - 2017-03-03 16:45:58 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:45:58 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:45:58 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:45:58 --> Template Class Initialized
INFO - 2017-03-03 16:45:58 --> Model Class Initialized
INFO - 2017-03-03 16:45:58 --> Controller Class Initialized
DEBUG - 2017-03-03 16:45:58 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:45:58 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:45:58 --> Model Class Initialized
ERROR - 2017-03-03 16:45:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/rebelute/public_html/silohost/application/models/Project_Model.php:44) /home/rebelute/public_html/silohost/system/core/Common.php 573
ERROR - 2017-03-03 16:45:58 --> Severity: Error --> Access to undeclared static property: TABLES::$USER_PROJECTS /home/rebelute/public_html/silohost/application/models/Project_Model.php 44
INFO - 2017-03-03 16:46:35 --> Config Class Initialized
INFO - 2017-03-03 16:46:35 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:46:35 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:46:35 --> Utf8 Class Initialized
INFO - 2017-03-03 16:46:35 --> URI Class Initialized
INFO - 2017-03-03 16:46:35 --> Router Class Initialized
INFO - 2017-03-03 16:46:35 --> Output Class Initialized
INFO - 2017-03-03 16:46:35 --> Security Class Initialized
DEBUG - 2017-03-03 16:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:46:35 --> Input Class Initialized
INFO - 2017-03-03 16:46:35 --> Language Class Initialized
INFO - 2017-03-03 16:46:35 --> Language Class Initialized
INFO - 2017-03-03 16:46:35 --> Config Class Initialized
INFO - 2017-03-03 16:46:35 --> Loader Class Initialized
INFO - 2017-03-03 16:46:35 --> Helper loaded: form_helper
INFO - 2017-03-03 16:46:35 --> Helper loaded: url_helper
INFO - 2017-03-03 16:46:35 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:46:35 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:46:35 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:46:35 --> Template Class Initialized
INFO - 2017-03-03 16:46:35 --> Model Class Initialized
INFO - 2017-03-03 16:46:35 --> Controller Class Initialized
DEBUG - 2017-03-03 16:46:35 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:46:35 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:46:35 --> Model Class Initialized
DEBUG - 2017-03-03 16:46:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 16:46:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 16:46:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 16:46:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/project_list.php
DEBUG - 2017-03-03 16:46:35 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 16:46:35 --> Final output sent to browser
DEBUG - 2017-03-03 16:46:35 --> Total execution time: 0.0199
INFO - 2017-03-03 16:46:38 --> Config Class Initialized
INFO - 2017-03-03 16:46:38 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:46:38 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:46:38 --> Utf8 Class Initialized
INFO - 2017-03-03 16:46:38 --> URI Class Initialized
INFO - 2017-03-03 16:46:38 --> Router Class Initialized
INFO - 2017-03-03 16:46:38 --> Output Class Initialized
INFO - 2017-03-03 16:46:38 --> Security Class Initialized
DEBUG - 2017-03-03 16:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:46:38 --> Input Class Initialized
INFO - 2017-03-03 16:46:38 --> Language Class Initialized
INFO - 2017-03-03 16:46:38 --> Language Class Initialized
INFO - 2017-03-03 16:46:38 --> Config Class Initialized
INFO - 2017-03-03 16:46:38 --> Loader Class Initialized
INFO - 2017-03-03 16:46:38 --> Helper loaded: form_helper
INFO - 2017-03-03 16:46:38 --> Helper loaded: url_helper
INFO - 2017-03-03 16:46:38 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:46:38 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:46:38 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:46:38 --> Template Class Initialized
INFO - 2017-03-03 16:46:38 --> Model Class Initialized
INFO - 2017-03-03 16:46:38 --> Controller Class Initialized
DEBUG - 2017-03-03 16:46:38 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:46:38 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:46:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 16:46:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 16:46:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 16:46:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 16:46:38 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 16:46:38 --> Final output sent to browser
DEBUG - 2017-03-03 16:46:38 --> Total execution time: 0.0157
INFO - 2017-03-03 16:46:52 --> Config Class Initialized
INFO - 2017-03-03 16:46:52 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:46:52 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:46:52 --> Utf8 Class Initialized
INFO - 2017-03-03 16:46:52 --> URI Class Initialized
INFO - 2017-03-03 16:46:52 --> Router Class Initialized
INFO - 2017-03-03 16:46:52 --> Output Class Initialized
INFO - 2017-03-03 16:46:52 --> Security Class Initialized
DEBUG - 2017-03-03 16:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:46:52 --> Input Class Initialized
INFO - 2017-03-03 16:46:52 --> Language Class Initialized
INFO - 2017-03-03 16:46:52 --> Language Class Initialized
INFO - 2017-03-03 16:46:52 --> Config Class Initialized
INFO - 2017-03-03 16:46:52 --> Loader Class Initialized
INFO - 2017-03-03 16:46:52 --> Helper loaded: form_helper
INFO - 2017-03-03 16:46:52 --> Helper loaded: url_helper
INFO - 2017-03-03 16:46:52 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:46:52 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:46:52 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:46:52 --> Template Class Initialized
INFO - 2017-03-03 16:46:52 --> Model Class Initialized
INFO - 2017-03-03 16:46:52 --> Controller Class Initialized
DEBUG - 2017-03-03 16:46:52 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:46:52 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:46:52 --> Model Class Initialized
INFO - 2017-03-03 16:46:52 --> Config Class Initialized
INFO - 2017-03-03 16:46:52 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:46:52 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:46:52 --> Utf8 Class Initialized
INFO - 2017-03-03 16:46:52 --> URI Class Initialized
INFO - 2017-03-03 16:46:52 --> Router Class Initialized
INFO - 2017-03-03 16:46:52 --> Output Class Initialized
INFO - 2017-03-03 16:46:52 --> Security Class Initialized
DEBUG - 2017-03-03 16:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:46:52 --> Input Class Initialized
INFO - 2017-03-03 16:46:52 --> Language Class Initialized
INFO - 2017-03-03 16:46:52 --> Language Class Initialized
INFO - 2017-03-03 16:46:52 --> Config Class Initialized
INFO - 2017-03-03 16:46:52 --> Loader Class Initialized
INFO - 2017-03-03 16:46:52 --> Helper loaded: form_helper
INFO - 2017-03-03 16:46:52 --> Helper loaded: url_helper
INFO - 2017-03-03 16:46:52 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:46:52 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:46:52 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:46:52 --> Template Class Initialized
INFO - 2017-03-03 16:46:52 --> Model Class Initialized
INFO - 2017-03-03 16:46:52 --> Controller Class Initialized
DEBUG - 2017-03-03 16:46:52 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:46:52 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:46:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 16:46:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 16:46:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 16:46:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 16:46:52 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 16:46:52 --> Final output sent to browser
DEBUG - 2017-03-03 16:46:52 --> Total execution time: 0.0141
INFO - 2017-03-03 16:47:06 --> Config Class Initialized
INFO - 2017-03-03 16:47:06 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:47:06 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:47:06 --> Utf8 Class Initialized
INFO - 2017-03-03 16:47:06 --> URI Class Initialized
INFO - 2017-03-03 16:47:06 --> Router Class Initialized
INFO - 2017-03-03 16:47:06 --> Output Class Initialized
INFO - 2017-03-03 16:47:06 --> Security Class Initialized
DEBUG - 2017-03-03 16:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:47:06 --> Input Class Initialized
INFO - 2017-03-03 16:47:06 --> Language Class Initialized
INFO - 2017-03-03 16:47:06 --> Language Class Initialized
INFO - 2017-03-03 16:47:06 --> Config Class Initialized
INFO - 2017-03-03 16:47:06 --> Loader Class Initialized
INFO - 2017-03-03 16:47:06 --> Helper loaded: form_helper
INFO - 2017-03-03 16:47:06 --> Helper loaded: url_helper
INFO - 2017-03-03 16:47:06 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:47:06 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:47:06 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:47:06 --> Template Class Initialized
INFO - 2017-03-03 16:47:06 --> Model Class Initialized
INFO - 2017-03-03 16:47:06 --> Controller Class Initialized
DEBUG - 2017-03-03 16:47:06 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:47:06 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:47:06 --> Model Class Initialized
INFO - 2017-03-03 16:47:09 --> Config Class Initialized
INFO - 2017-03-03 16:47:09 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:47:09 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:47:09 --> Utf8 Class Initialized
INFO - 2017-03-03 16:47:09 --> URI Class Initialized
INFO - 2017-03-03 16:47:09 --> Router Class Initialized
INFO - 2017-03-03 16:47:09 --> Output Class Initialized
INFO - 2017-03-03 16:47:09 --> Security Class Initialized
DEBUG - 2017-03-03 16:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:47:09 --> Input Class Initialized
INFO - 2017-03-03 16:47:09 --> Language Class Initialized
INFO - 2017-03-03 16:47:09 --> Language Class Initialized
INFO - 2017-03-03 16:47:09 --> Config Class Initialized
INFO - 2017-03-03 16:47:09 --> Loader Class Initialized
INFO - 2017-03-03 16:47:09 --> Helper loaded: form_helper
INFO - 2017-03-03 16:47:09 --> Helper loaded: url_helper
INFO - 2017-03-03 16:47:09 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:47:09 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:47:09 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:47:09 --> Template Class Initialized
INFO - 2017-03-03 16:47:09 --> Model Class Initialized
INFO - 2017-03-03 16:47:09 --> Controller Class Initialized
DEBUG - 2017-03-03 16:47:09 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:47:09 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:47:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 16:47:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 16:47:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 16:47:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 16:47:09 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 16:47:09 --> Final output sent to browser
DEBUG - 2017-03-03 16:47:09 --> Total execution time: 0.0188
INFO - 2017-03-03 16:47:12 --> Config Class Initialized
INFO - 2017-03-03 16:47:12 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:47:12 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:47:12 --> Utf8 Class Initialized
INFO - 2017-03-03 16:47:12 --> URI Class Initialized
INFO - 2017-03-03 16:47:12 --> Router Class Initialized
INFO - 2017-03-03 16:47:12 --> Output Class Initialized
INFO - 2017-03-03 16:47:12 --> Security Class Initialized
DEBUG - 2017-03-03 16:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:47:12 --> Input Class Initialized
INFO - 2017-03-03 16:47:12 --> Language Class Initialized
INFO - 2017-03-03 16:47:12 --> Language Class Initialized
INFO - 2017-03-03 16:47:12 --> Config Class Initialized
INFO - 2017-03-03 16:47:12 --> Loader Class Initialized
INFO - 2017-03-03 16:47:12 --> Helper loaded: form_helper
INFO - 2017-03-03 16:47:12 --> Helper loaded: url_helper
INFO - 2017-03-03 16:47:12 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:47:12 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:47:12 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:47:12 --> Template Class Initialized
INFO - 2017-03-03 16:47:12 --> Model Class Initialized
INFO - 2017-03-03 16:47:12 --> Controller Class Initialized
DEBUG - 2017-03-03 16:47:12 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:47:12 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:47:12 --> Model Class Initialized
DEBUG - 2017-03-03 16:47:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 16:47:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 16:47:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 16:47:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 16:47:12 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 16:47:12 --> Final output sent to browser
DEBUG - 2017-03-03 16:47:12 --> Total execution time: 0.0166
INFO - 2017-03-03 16:47:14 --> Config Class Initialized
INFO - 2017-03-03 16:47:14 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:47:14 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:47:14 --> Utf8 Class Initialized
INFO - 2017-03-03 16:47:14 --> URI Class Initialized
INFO - 2017-03-03 16:47:14 --> Router Class Initialized
INFO - 2017-03-03 16:47:14 --> Output Class Initialized
INFO - 2017-03-03 16:47:14 --> Security Class Initialized
DEBUG - 2017-03-03 16:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:47:14 --> Input Class Initialized
INFO - 2017-03-03 16:47:14 --> Language Class Initialized
INFO - 2017-03-03 16:47:14 --> Language Class Initialized
INFO - 2017-03-03 16:47:14 --> Config Class Initialized
INFO - 2017-03-03 16:47:14 --> Loader Class Initialized
INFO - 2017-03-03 16:47:14 --> Helper loaded: form_helper
INFO - 2017-03-03 16:47:14 --> Helper loaded: url_helper
INFO - 2017-03-03 16:47:14 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:47:14 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:47:14 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:47:14 --> Template Class Initialized
INFO - 2017-03-03 16:47:14 --> Model Class Initialized
INFO - 2017-03-03 16:47:14 --> Controller Class Initialized
DEBUG - 2017-03-03 16:47:14 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:47:14 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:47:14 --> Model Class Initialized
DEBUG - 2017-03-03 16:47:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 16:47:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 16:47:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 16:47:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/project_list.php
DEBUG - 2017-03-03 16:47:14 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 16:47:14 --> Final output sent to browser
DEBUG - 2017-03-03 16:47:14 --> Total execution time: 0.0177
INFO - 2017-03-03 16:47:18 --> Config Class Initialized
INFO - 2017-03-03 16:47:18 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:47:18 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:47:18 --> Utf8 Class Initialized
INFO - 2017-03-03 16:47:18 --> URI Class Initialized
INFO - 2017-03-03 16:47:18 --> Router Class Initialized
INFO - 2017-03-03 16:47:18 --> Output Class Initialized
INFO - 2017-03-03 16:47:18 --> Security Class Initialized
DEBUG - 2017-03-03 16:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:47:18 --> Input Class Initialized
INFO - 2017-03-03 16:47:18 --> Language Class Initialized
INFO - 2017-03-03 16:47:18 --> Language Class Initialized
INFO - 2017-03-03 16:47:18 --> Config Class Initialized
INFO - 2017-03-03 16:47:18 --> Loader Class Initialized
INFO - 2017-03-03 16:47:18 --> Helper loaded: form_helper
INFO - 2017-03-03 16:47:18 --> Helper loaded: url_helper
INFO - 2017-03-03 16:47:18 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:47:18 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:47:18 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:47:18 --> Template Class Initialized
INFO - 2017-03-03 16:47:18 --> Model Class Initialized
INFO - 2017-03-03 16:47:18 --> Controller Class Initialized
DEBUG - 2017-03-03 16:47:18 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:47:18 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:47:18 --> Model Class Initialized
DEBUG - 2017-03-03 16:47:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 16:47:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 16:47:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 16:47:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 16:47:18 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 16:47:18 --> Final output sent to browser
DEBUG - 2017-03-03 16:47:18 --> Total execution time: 0.0127
INFO - 2017-03-03 16:47:20 --> Config Class Initialized
INFO - 2017-03-03 16:47:20 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:47:20 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:47:20 --> Utf8 Class Initialized
INFO - 2017-03-03 16:47:20 --> URI Class Initialized
INFO - 2017-03-03 16:47:20 --> Router Class Initialized
INFO - 2017-03-03 16:47:20 --> Output Class Initialized
INFO - 2017-03-03 16:47:20 --> Security Class Initialized
DEBUG - 2017-03-03 16:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:47:20 --> Input Class Initialized
INFO - 2017-03-03 16:47:20 --> Language Class Initialized
INFO - 2017-03-03 16:47:20 --> Language Class Initialized
INFO - 2017-03-03 16:47:20 --> Config Class Initialized
INFO - 2017-03-03 16:47:20 --> Loader Class Initialized
INFO - 2017-03-03 16:47:20 --> Helper loaded: form_helper
INFO - 2017-03-03 16:47:20 --> Helper loaded: url_helper
INFO - 2017-03-03 16:47:20 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:47:20 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:47:20 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:47:20 --> Template Class Initialized
INFO - 2017-03-03 16:47:20 --> Model Class Initialized
INFO - 2017-03-03 16:47:20 --> Controller Class Initialized
DEBUG - 2017-03-03 16:47:20 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:47:20 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:47:20 --> Final output sent to browser
DEBUG - 2017-03-03 16:47:20 --> Total execution time: 0.0110
INFO - 2017-03-03 16:48:05 --> Config Class Initialized
INFO - 2017-03-03 16:48:05 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:48:05 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:48:05 --> Utf8 Class Initialized
INFO - 2017-03-03 16:48:05 --> URI Class Initialized
INFO - 2017-03-03 16:48:05 --> Router Class Initialized
INFO - 2017-03-03 16:48:05 --> Output Class Initialized
INFO - 2017-03-03 16:48:05 --> Security Class Initialized
DEBUG - 2017-03-03 16:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:48:05 --> Input Class Initialized
INFO - 2017-03-03 16:48:05 --> Language Class Initialized
INFO - 2017-03-03 16:48:05 --> Language Class Initialized
INFO - 2017-03-03 16:48:05 --> Config Class Initialized
INFO - 2017-03-03 16:48:05 --> Loader Class Initialized
INFO - 2017-03-03 16:48:05 --> Helper loaded: form_helper
INFO - 2017-03-03 16:48:05 --> Helper loaded: url_helper
INFO - 2017-03-03 16:48:05 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:48:05 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:48:05 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:48:05 --> Template Class Initialized
INFO - 2017-03-03 16:48:05 --> Model Class Initialized
INFO - 2017-03-03 16:48:05 --> Controller Class Initialized
DEBUG - 2017-03-03 16:48:05 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:48:05 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:48:05 --> Model Class Initialized
DEBUG - 2017-03-03 16:48:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 16:48:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 16:48:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 16:48:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 16:48:05 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 16:48:05 --> Final output sent to browser
DEBUG - 2017-03-03 16:48:05 --> Total execution time: 0.0181
INFO - 2017-03-03 16:48:11 --> Config Class Initialized
INFO - 2017-03-03 16:48:11 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:48:11 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:48:11 --> Utf8 Class Initialized
INFO - 2017-03-03 16:48:11 --> URI Class Initialized
INFO - 2017-03-03 16:48:11 --> Router Class Initialized
INFO - 2017-03-03 16:48:11 --> Output Class Initialized
INFO - 2017-03-03 16:48:11 --> Security Class Initialized
DEBUG - 2017-03-03 16:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:48:11 --> Input Class Initialized
INFO - 2017-03-03 16:48:11 --> Language Class Initialized
INFO - 2017-03-03 16:48:11 --> Language Class Initialized
INFO - 2017-03-03 16:48:11 --> Config Class Initialized
INFO - 2017-03-03 16:48:11 --> Loader Class Initialized
INFO - 2017-03-03 16:48:11 --> Helper loaded: form_helper
INFO - 2017-03-03 16:48:11 --> Helper loaded: url_helper
INFO - 2017-03-03 16:48:11 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:48:11 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:48:11 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:48:11 --> Template Class Initialized
INFO - 2017-03-03 16:48:11 --> Model Class Initialized
INFO - 2017-03-03 16:48:11 --> Controller Class Initialized
DEBUG - 2017-03-03 16:48:11 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:48:11 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:48:11 --> Final output sent to browser
DEBUG - 2017-03-03 16:48:11 --> Total execution time: 0.0140
INFO - 2017-03-03 16:48:28 --> Config Class Initialized
INFO - 2017-03-03 16:48:28 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:48:28 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:48:28 --> Utf8 Class Initialized
INFO - 2017-03-03 16:48:28 --> URI Class Initialized
INFO - 2017-03-03 16:48:28 --> Router Class Initialized
INFO - 2017-03-03 16:48:28 --> Output Class Initialized
INFO - 2017-03-03 16:48:28 --> Security Class Initialized
DEBUG - 2017-03-03 16:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:48:28 --> Input Class Initialized
INFO - 2017-03-03 16:48:28 --> Language Class Initialized
INFO - 2017-03-03 16:48:28 --> Language Class Initialized
INFO - 2017-03-03 16:48:28 --> Config Class Initialized
INFO - 2017-03-03 16:48:28 --> Loader Class Initialized
INFO - 2017-03-03 16:48:28 --> Helper loaded: form_helper
INFO - 2017-03-03 16:48:28 --> Helper loaded: url_helper
INFO - 2017-03-03 16:48:28 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:48:28 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:48:28 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:48:28 --> Template Class Initialized
INFO - 2017-03-03 16:48:28 --> Model Class Initialized
INFO - 2017-03-03 16:48:28 --> Controller Class Initialized
DEBUG - 2017-03-03 16:48:28 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:48:28 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:48:28 --> Upload Class Initialized
INFO - 2017-03-03 16:48:28 --> Model Class Initialized
INFO - 2017-03-03 16:48:28 --> Final output sent to browser
DEBUG - 2017-03-03 16:48:28 --> Total execution time: 0.0323
INFO - 2017-03-03 16:51:27 --> Config Class Initialized
INFO - 2017-03-03 16:51:27 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:51:27 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:51:27 --> Utf8 Class Initialized
INFO - 2017-03-03 16:51:27 --> URI Class Initialized
INFO - 2017-03-03 16:51:27 --> Router Class Initialized
INFO - 2017-03-03 16:51:27 --> Output Class Initialized
INFO - 2017-03-03 16:51:27 --> Security Class Initialized
DEBUG - 2017-03-03 16:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:51:27 --> Input Class Initialized
INFO - 2017-03-03 16:51:27 --> Language Class Initialized
INFO - 2017-03-03 16:51:27 --> Language Class Initialized
INFO - 2017-03-03 16:51:27 --> Config Class Initialized
INFO - 2017-03-03 16:51:27 --> Loader Class Initialized
INFO - 2017-03-03 16:51:27 --> Helper loaded: form_helper
INFO - 2017-03-03 16:51:27 --> Helper loaded: url_helper
INFO - 2017-03-03 16:51:27 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:51:27 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:51:27 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:51:27 --> Template Class Initialized
INFO - 2017-03-03 16:51:27 --> Model Class Initialized
INFO - 2017-03-03 16:51:27 --> Controller Class Initialized
DEBUG - 2017-03-03 16:51:27 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:51:27 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:51:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 16:51:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 16:51:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 16:51:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 16:51:27 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 16:51:27 --> Final output sent to browser
DEBUG - 2017-03-03 16:51:27 --> Total execution time: 0.0604
INFO - 2017-03-03 16:51:32 --> Config Class Initialized
INFO - 2017-03-03 16:51:32 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:51:32 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:51:32 --> Utf8 Class Initialized
INFO - 2017-03-03 16:51:32 --> URI Class Initialized
INFO - 2017-03-03 16:51:32 --> Router Class Initialized
INFO - 2017-03-03 16:51:32 --> Output Class Initialized
INFO - 2017-03-03 16:51:32 --> Security Class Initialized
DEBUG - 2017-03-03 16:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:51:32 --> Input Class Initialized
INFO - 2017-03-03 16:51:32 --> Language Class Initialized
INFO - 2017-03-03 16:51:32 --> Language Class Initialized
INFO - 2017-03-03 16:51:32 --> Config Class Initialized
INFO - 2017-03-03 16:51:32 --> Loader Class Initialized
INFO - 2017-03-03 16:51:32 --> Helper loaded: form_helper
INFO - 2017-03-03 16:51:32 --> Helper loaded: url_helper
INFO - 2017-03-03 16:51:32 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:51:32 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:51:32 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:51:32 --> Template Class Initialized
INFO - 2017-03-03 16:51:32 --> Model Class Initialized
INFO - 2017-03-03 16:51:32 --> Controller Class Initialized
DEBUG - 2017-03-03 16:51:32 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:51:32 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:51:32 --> Model Class Initialized
INFO - 2017-03-03 16:51:32 --> Config Class Initialized
INFO - 2017-03-03 16:51:32 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:51:32 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:51:32 --> Utf8 Class Initialized
INFO - 2017-03-03 16:51:32 --> URI Class Initialized
INFO - 2017-03-03 16:51:32 --> Router Class Initialized
INFO - 2017-03-03 16:51:32 --> Output Class Initialized
INFO - 2017-03-03 16:51:32 --> Security Class Initialized
DEBUG - 2017-03-03 16:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:51:32 --> Input Class Initialized
INFO - 2017-03-03 16:51:32 --> Language Class Initialized
INFO - 2017-03-03 16:51:32 --> Language Class Initialized
INFO - 2017-03-03 16:51:32 --> Config Class Initialized
INFO - 2017-03-03 16:51:32 --> Loader Class Initialized
INFO - 2017-03-03 16:51:32 --> Helper loaded: form_helper
INFO - 2017-03-03 16:51:32 --> Helper loaded: url_helper
INFO - 2017-03-03 16:51:32 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:51:32 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:51:32 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:51:32 --> Template Class Initialized
INFO - 2017-03-03 16:51:32 --> Model Class Initialized
INFO - 2017-03-03 16:51:32 --> Controller Class Initialized
DEBUG - 2017-03-03 16:51:32 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:51:32 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:51:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 16:51:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 16:51:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 16:51:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 16:51:32 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 16:51:32 --> Final output sent to browser
DEBUG - 2017-03-03 16:51:32 --> Total execution time: 0.0144
INFO - 2017-03-03 16:52:10 --> Config Class Initialized
INFO - 2017-03-03 16:52:10 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:52:10 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:52:10 --> Utf8 Class Initialized
INFO - 2017-03-03 16:52:10 --> URI Class Initialized
INFO - 2017-03-03 16:52:10 --> Router Class Initialized
INFO - 2017-03-03 16:52:10 --> Output Class Initialized
INFO - 2017-03-03 16:52:10 --> Security Class Initialized
DEBUG - 2017-03-03 16:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:52:10 --> Input Class Initialized
INFO - 2017-03-03 16:52:10 --> Language Class Initialized
INFO - 2017-03-03 16:52:10 --> Language Class Initialized
INFO - 2017-03-03 16:52:10 --> Config Class Initialized
INFO - 2017-03-03 16:52:10 --> Loader Class Initialized
INFO - 2017-03-03 16:52:10 --> Helper loaded: form_helper
INFO - 2017-03-03 16:52:10 --> Helper loaded: url_helper
INFO - 2017-03-03 16:52:10 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:52:10 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:52:10 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:52:10 --> Template Class Initialized
INFO - 2017-03-03 16:52:10 --> Model Class Initialized
INFO - 2017-03-03 16:52:10 --> Controller Class Initialized
DEBUG - 2017-03-03 16:52:10 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:52:10 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:52:10 --> Model Class Initialized
INFO - 2017-03-03 16:52:10 --> Config Class Initialized
INFO - 2017-03-03 16:52:10 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:52:10 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:52:10 --> Utf8 Class Initialized
INFO - 2017-03-03 16:52:10 --> URI Class Initialized
INFO - 2017-03-03 16:52:10 --> Router Class Initialized
INFO - 2017-03-03 16:52:10 --> Output Class Initialized
INFO - 2017-03-03 16:52:10 --> Security Class Initialized
DEBUG - 2017-03-03 16:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:52:10 --> Input Class Initialized
INFO - 2017-03-03 16:52:10 --> Language Class Initialized
INFO - 2017-03-03 16:52:10 --> Language Class Initialized
INFO - 2017-03-03 16:52:10 --> Config Class Initialized
INFO - 2017-03-03 16:52:10 --> Loader Class Initialized
INFO - 2017-03-03 16:52:10 --> Helper loaded: form_helper
INFO - 2017-03-03 16:52:10 --> Helper loaded: url_helper
INFO - 2017-03-03 16:52:10 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:52:10 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:52:10 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:52:10 --> Template Class Initialized
INFO - 2017-03-03 16:52:10 --> Model Class Initialized
INFO - 2017-03-03 16:52:10 --> Controller Class Initialized
DEBUG - 2017-03-03 16:52:10 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:52:10 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:52:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 16:52:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 16:52:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 16:52:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 16:52:10 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 16:52:10 --> Final output sent to browser
DEBUG - 2017-03-03 16:52:10 --> Total execution time: 0.0143
INFO - 2017-03-03 16:53:54 --> Config Class Initialized
INFO - 2017-03-03 16:53:54 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:53:54 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:53:54 --> Utf8 Class Initialized
INFO - 2017-03-03 16:53:54 --> URI Class Initialized
INFO - 2017-03-03 16:53:54 --> Router Class Initialized
INFO - 2017-03-03 16:53:54 --> Output Class Initialized
INFO - 2017-03-03 16:53:54 --> Security Class Initialized
DEBUG - 2017-03-03 16:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:53:54 --> Input Class Initialized
INFO - 2017-03-03 16:53:54 --> Language Class Initialized
INFO - 2017-03-03 16:53:54 --> Language Class Initialized
INFO - 2017-03-03 16:53:54 --> Config Class Initialized
INFO - 2017-03-03 16:53:54 --> Loader Class Initialized
INFO - 2017-03-03 16:53:54 --> Helper loaded: form_helper
INFO - 2017-03-03 16:53:54 --> Helper loaded: url_helper
INFO - 2017-03-03 16:53:54 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:53:54 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:53:54 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:53:54 --> Template Class Initialized
INFO - 2017-03-03 16:53:54 --> Model Class Initialized
INFO - 2017-03-03 16:53:54 --> Controller Class Initialized
DEBUG - 2017-03-03 16:53:54 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:53:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:53:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 16:53:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 16:53:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 16:53:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 16:53:54 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 16:53:54 --> Final output sent to browser
DEBUG - 2017-03-03 16:53:54 --> Total execution time: 0.0164
INFO - 2017-03-03 16:54:01 --> Config Class Initialized
INFO - 2017-03-03 16:54:01 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:54:01 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:54:01 --> Utf8 Class Initialized
INFO - 2017-03-03 16:54:01 --> URI Class Initialized
INFO - 2017-03-03 16:54:01 --> Router Class Initialized
INFO - 2017-03-03 16:54:01 --> Output Class Initialized
INFO - 2017-03-03 16:54:01 --> Security Class Initialized
DEBUG - 2017-03-03 16:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:54:01 --> Input Class Initialized
INFO - 2017-03-03 16:54:01 --> Language Class Initialized
INFO - 2017-03-03 16:54:01 --> Language Class Initialized
INFO - 2017-03-03 16:54:01 --> Config Class Initialized
INFO - 2017-03-03 16:54:01 --> Loader Class Initialized
INFO - 2017-03-03 16:54:01 --> Helper loaded: form_helper
INFO - 2017-03-03 16:54:01 --> Helper loaded: url_helper
INFO - 2017-03-03 16:54:01 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:54:01 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:54:01 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:54:01 --> Template Class Initialized
INFO - 2017-03-03 16:54:01 --> Model Class Initialized
INFO - 2017-03-03 16:54:01 --> Controller Class Initialized
DEBUG - 2017-03-03 16:54:01 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:54:01 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:54:01 --> Model Class Initialized
INFO - 2017-03-03 16:54:01 --> Config Class Initialized
INFO - 2017-03-03 16:54:01 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:54:01 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:54:01 --> Utf8 Class Initialized
INFO - 2017-03-03 16:54:01 --> URI Class Initialized
INFO - 2017-03-03 16:54:01 --> Router Class Initialized
INFO - 2017-03-03 16:54:01 --> Output Class Initialized
INFO - 2017-03-03 16:54:01 --> Security Class Initialized
DEBUG - 2017-03-03 16:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:54:01 --> Input Class Initialized
INFO - 2017-03-03 16:54:01 --> Language Class Initialized
INFO - 2017-03-03 16:54:01 --> Language Class Initialized
INFO - 2017-03-03 16:54:01 --> Config Class Initialized
INFO - 2017-03-03 16:54:01 --> Loader Class Initialized
INFO - 2017-03-03 16:54:01 --> Helper loaded: form_helper
INFO - 2017-03-03 16:54:01 --> Helper loaded: url_helper
INFO - 2017-03-03 16:54:01 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:54:01 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:54:01 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:54:01 --> Template Class Initialized
INFO - 2017-03-03 16:54:01 --> Model Class Initialized
INFO - 2017-03-03 16:54:01 --> Controller Class Initialized
DEBUG - 2017-03-03 16:54:01 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:54:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:54:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 16:54:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 16:54:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 16:54:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 16:54:01 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 16:54:01 --> Final output sent to browser
DEBUG - 2017-03-03 16:54:01 --> Total execution time: 0.0165
INFO - 2017-03-03 16:56:27 --> Config Class Initialized
INFO - 2017-03-03 16:56:27 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:56:27 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:56:27 --> Utf8 Class Initialized
INFO - 2017-03-03 16:56:27 --> URI Class Initialized
INFO - 2017-03-03 16:56:27 --> Router Class Initialized
INFO - 2017-03-03 16:56:27 --> Output Class Initialized
INFO - 2017-03-03 16:56:27 --> Security Class Initialized
DEBUG - 2017-03-03 16:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:56:27 --> Input Class Initialized
INFO - 2017-03-03 16:56:27 --> Language Class Initialized
INFO - 2017-03-03 16:56:27 --> Language Class Initialized
INFO - 2017-03-03 16:56:27 --> Config Class Initialized
INFO - 2017-03-03 16:56:27 --> Loader Class Initialized
INFO - 2017-03-03 16:56:27 --> Helper loaded: form_helper
INFO - 2017-03-03 16:56:27 --> Helper loaded: url_helper
INFO - 2017-03-03 16:56:27 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:56:27 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:56:27 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:56:27 --> Template Class Initialized
INFO - 2017-03-03 16:56:27 --> Model Class Initialized
INFO - 2017-03-03 16:56:27 --> Controller Class Initialized
DEBUG - 2017-03-03 16:56:27 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:56:27 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:56:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 16:56:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 16:56:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 16:56:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 16:56:27 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 16:56:27 --> Final output sent to browser
DEBUG - 2017-03-03 16:56:27 --> Total execution time: 0.0653
INFO - 2017-03-03 16:56:34 --> Config Class Initialized
INFO - 2017-03-03 16:56:34 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:56:34 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:56:34 --> Utf8 Class Initialized
INFO - 2017-03-03 16:56:34 --> URI Class Initialized
INFO - 2017-03-03 16:56:34 --> Router Class Initialized
INFO - 2017-03-03 16:56:34 --> Output Class Initialized
INFO - 2017-03-03 16:56:34 --> Security Class Initialized
DEBUG - 2017-03-03 16:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:56:34 --> Input Class Initialized
INFO - 2017-03-03 16:56:34 --> Language Class Initialized
INFO - 2017-03-03 16:56:34 --> Language Class Initialized
INFO - 2017-03-03 16:56:34 --> Config Class Initialized
INFO - 2017-03-03 16:56:34 --> Loader Class Initialized
INFO - 2017-03-03 16:56:34 --> Helper loaded: form_helper
INFO - 2017-03-03 16:56:34 --> Helper loaded: url_helper
INFO - 2017-03-03 16:56:34 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:56:34 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:56:34 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:56:34 --> Template Class Initialized
INFO - 2017-03-03 16:56:34 --> Model Class Initialized
INFO - 2017-03-03 16:56:34 --> Controller Class Initialized
DEBUG - 2017-03-03 16:56:34 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:56:34 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:56:34 --> Model Class Initialized
INFO - 2017-03-03 16:56:34 --> Config Class Initialized
INFO - 2017-03-03 16:56:34 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:56:34 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:56:34 --> Utf8 Class Initialized
INFO - 2017-03-03 16:56:34 --> URI Class Initialized
INFO - 2017-03-03 16:56:34 --> Router Class Initialized
INFO - 2017-03-03 16:56:34 --> Output Class Initialized
INFO - 2017-03-03 16:56:34 --> Security Class Initialized
DEBUG - 2017-03-03 16:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:56:34 --> Input Class Initialized
INFO - 2017-03-03 16:56:34 --> Language Class Initialized
INFO - 2017-03-03 16:56:34 --> Language Class Initialized
INFO - 2017-03-03 16:56:34 --> Config Class Initialized
INFO - 2017-03-03 16:56:34 --> Loader Class Initialized
INFO - 2017-03-03 16:56:34 --> Helper loaded: form_helper
INFO - 2017-03-03 16:56:34 --> Helper loaded: url_helper
INFO - 2017-03-03 16:56:34 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:56:34 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:56:34 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:56:34 --> Template Class Initialized
INFO - 2017-03-03 16:56:34 --> Model Class Initialized
INFO - 2017-03-03 16:56:34 --> Controller Class Initialized
DEBUG - 2017-03-03 16:56:34 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:56:34 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 16:56:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 16:56:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 16:56:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 16:56:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 16:56:34 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 16:56:34 --> Final output sent to browser
DEBUG - 2017-03-03 16:56:34 --> Total execution time: 0.0153
INFO - 2017-03-03 16:56:43 --> Config Class Initialized
INFO - 2017-03-03 16:56:43 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:56:43 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:56:43 --> Utf8 Class Initialized
INFO - 2017-03-03 16:56:43 --> URI Class Initialized
INFO - 2017-03-03 16:56:43 --> Router Class Initialized
INFO - 2017-03-03 16:56:43 --> Output Class Initialized
INFO - 2017-03-03 16:56:43 --> Security Class Initialized
DEBUG - 2017-03-03 16:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:56:43 --> Input Class Initialized
INFO - 2017-03-03 16:56:43 --> Language Class Initialized
INFO - 2017-03-03 16:56:43 --> Language Class Initialized
INFO - 2017-03-03 16:56:43 --> Config Class Initialized
INFO - 2017-03-03 16:56:43 --> Loader Class Initialized
INFO - 2017-03-03 16:56:43 --> Helper loaded: form_helper
INFO - 2017-03-03 16:56:43 --> Helper loaded: url_helper
INFO - 2017-03-03 16:56:43 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:56:43 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:56:43 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:56:43 --> Template Class Initialized
INFO - 2017-03-03 16:56:43 --> Model Class Initialized
INFO - 2017-03-03 16:56:43 --> Controller Class Initialized
DEBUG - 2017-03-03 16:56:43 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:56:43 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:56:43 --> Model Class Initialized
DEBUG - 2017-03-03 16:56:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 16:56:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 16:56:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 16:56:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 16:56:43 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 16:56:43 --> Final output sent to browser
DEBUG - 2017-03-03 16:56:43 --> Total execution time: 0.0229
INFO - 2017-03-03 16:56:46 --> Config Class Initialized
INFO - 2017-03-03 16:56:46 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:56:46 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:56:46 --> Utf8 Class Initialized
INFO - 2017-03-03 16:56:46 --> URI Class Initialized
INFO - 2017-03-03 16:56:46 --> Router Class Initialized
INFO - 2017-03-03 16:56:46 --> Output Class Initialized
INFO - 2017-03-03 16:56:46 --> Security Class Initialized
DEBUG - 2017-03-03 16:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:56:46 --> Input Class Initialized
INFO - 2017-03-03 16:56:46 --> Language Class Initialized
INFO - 2017-03-03 16:56:46 --> Language Class Initialized
INFO - 2017-03-03 16:56:46 --> Config Class Initialized
INFO - 2017-03-03 16:56:46 --> Loader Class Initialized
INFO - 2017-03-03 16:56:46 --> Helper loaded: form_helper
INFO - 2017-03-03 16:56:46 --> Helper loaded: url_helper
INFO - 2017-03-03 16:56:46 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:56:46 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:56:46 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:56:46 --> Template Class Initialized
INFO - 2017-03-03 16:56:46 --> Model Class Initialized
INFO - 2017-03-03 16:56:46 --> Controller Class Initialized
DEBUG - 2017-03-03 16:56:46 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:56:46 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:56:46 --> Final output sent to browser
DEBUG - 2017-03-03 16:56:46 --> Total execution time: 0.0136
INFO - 2017-03-03 16:56:50 --> Config Class Initialized
INFO - 2017-03-03 16:56:50 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:56:50 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:56:50 --> Utf8 Class Initialized
INFO - 2017-03-03 16:56:50 --> URI Class Initialized
INFO - 2017-03-03 16:56:50 --> Router Class Initialized
INFO - 2017-03-03 16:56:50 --> Output Class Initialized
INFO - 2017-03-03 16:56:50 --> Security Class Initialized
DEBUG - 2017-03-03 16:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:56:50 --> Input Class Initialized
INFO - 2017-03-03 16:56:50 --> Language Class Initialized
INFO - 2017-03-03 16:56:50 --> Language Class Initialized
INFO - 2017-03-03 16:56:50 --> Config Class Initialized
INFO - 2017-03-03 16:56:50 --> Loader Class Initialized
INFO - 2017-03-03 16:56:50 --> Helper loaded: form_helper
INFO - 2017-03-03 16:56:50 --> Helper loaded: url_helper
INFO - 2017-03-03 16:56:50 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:56:50 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:56:50 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:56:50 --> Template Class Initialized
INFO - 2017-03-03 16:56:50 --> Model Class Initialized
INFO - 2017-03-03 16:56:50 --> Controller Class Initialized
DEBUG - 2017-03-03 16:56:50 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:56:50 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:56:50 --> Upload Class Initialized
INFO - 2017-03-03 16:56:50 --> Model Class Initialized
INFO - 2017-03-03 16:56:50 --> Final output sent to browser
DEBUG - 2017-03-03 16:56:50 --> Total execution time: 0.0198
INFO - 2017-03-03 16:57:09 --> Config Class Initialized
INFO - 2017-03-03 16:57:09 --> Hooks Class Initialized
DEBUG - 2017-03-03 16:57:09 --> UTF-8 Support Enabled
INFO - 2017-03-03 16:57:09 --> Utf8 Class Initialized
INFO - 2017-03-03 16:57:09 --> URI Class Initialized
INFO - 2017-03-03 16:57:09 --> Router Class Initialized
INFO - 2017-03-03 16:57:09 --> Output Class Initialized
INFO - 2017-03-03 16:57:09 --> Security Class Initialized
DEBUG - 2017-03-03 16:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 16:57:09 --> Input Class Initialized
INFO - 2017-03-03 16:57:09 --> Language Class Initialized
INFO - 2017-03-03 16:57:09 --> Language Class Initialized
INFO - 2017-03-03 16:57:09 --> Config Class Initialized
INFO - 2017-03-03 16:57:09 --> Loader Class Initialized
INFO - 2017-03-03 16:57:09 --> Helper loaded: form_helper
INFO - 2017-03-03 16:57:09 --> Helper loaded: url_helper
INFO - 2017-03-03 16:57:09 --> Helper loaded: utility_helper
INFO - 2017-03-03 16:57:09 --> Database Driver Class Initialized
DEBUG - 2017-03-03 16:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 16:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 16:57:09 --> User Agent Class Initialized
DEBUG - 2017-03-03 16:57:09 --> Template Class Initialized
INFO - 2017-03-03 16:57:09 --> Model Class Initialized
INFO - 2017-03-03 16:57:09 --> Controller Class Initialized
DEBUG - 2017-03-03 16:57:09 --> Project MX_Controller Initialized
INFO - 2017-03-03 16:57:09 --> Helper loaded: cookie_helper
INFO - 2017-03-03 16:57:09 --> Model Class Initialized
DEBUG - 2017-03-03 16:57:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 16:57:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 16:57:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 16:57:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 16:57:09 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 16:57:09 --> Final output sent to browser
DEBUG - 2017-03-03 16:57:09 --> Total execution time: 0.0223
INFO - 2017-03-03 17:15:36 --> Config Class Initialized
INFO - 2017-03-03 17:15:36 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:15:36 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:15:36 --> Utf8 Class Initialized
INFO - 2017-03-03 17:15:36 --> URI Class Initialized
DEBUG - 2017-03-03 17:15:36 --> No URI present. Default controller set.
INFO - 2017-03-03 17:15:36 --> Router Class Initialized
INFO - 2017-03-03 17:15:36 --> Output Class Initialized
INFO - 2017-03-03 17:15:36 --> Security Class Initialized
DEBUG - 2017-03-03 17:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:15:36 --> Input Class Initialized
INFO - 2017-03-03 17:15:36 --> Language Class Initialized
INFO - 2017-03-03 17:15:36 --> Language Class Initialized
INFO - 2017-03-03 17:15:36 --> Config Class Initialized
INFO - 2017-03-03 17:15:36 --> Loader Class Initialized
INFO - 2017-03-03 17:15:36 --> Helper loaded: form_helper
INFO - 2017-03-03 17:15:36 --> Helper loaded: url_helper
INFO - 2017-03-03 17:15:36 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:15:36 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:15:36 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:15:36 --> Template Class Initialized
INFO - 2017-03-03 17:15:36 --> Model Class Initialized
INFO - 2017-03-03 17:15:36 --> Controller Class Initialized
DEBUG - 2017-03-03 17:15:36 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:15:36 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:15:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:15:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 17:15:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-03 17:15:36 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 17:15:36 --> Final output sent to browser
DEBUG - 2017-03-03 17:15:36 --> Total execution time: 0.0418
INFO - 2017-03-03 17:15:40 --> Config Class Initialized
INFO - 2017-03-03 17:15:40 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:15:40 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:15:40 --> Utf8 Class Initialized
INFO - 2017-03-03 17:15:40 --> URI Class Initialized
INFO - 2017-03-03 17:15:40 --> Router Class Initialized
INFO - 2017-03-03 17:15:40 --> Output Class Initialized
INFO - 2017-03-03 17:15:40 --> Security Class Initialized
DEBUG - 2017-03-03 17:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:15:40 --> Input Class Initialized
INFO - 2017-03-03 17:15:40 --> Language Class Initialized
INFO - 2017-03-03 17:15:40 --> Language Class Initialized
INFO - 2017-03-03 17:15:40 --> Config Class Initialized
INFO - 2017-03-03 17:15:40 --> Loader Class Initialized
INFO - 2017-03-03 17:15:40 --> Helper loaded: form_helper
INFO - 2017-03-03 17:15:40 --> Helper loaded: url_helper
INFO - 2017-03-03 17:15:40 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:15:40 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:15:40 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:15:40 --> Template Class Initialized
INFO - 2017-03-03 17:15:40 --> Model Class Initialized
INFO - 2017-03-03 17:15:40 --> Controller Class Initialized
DEBUG - 2017-03-03 17:15:40 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:15:40 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:15:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:15:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:15:40 --> Config Class Initialized
INFO - 2017-03-03 17:15:40 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:15:40 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:15:40 --> Utf8 Class Initialized
INFO - 2017-03-03 17:15:40 --> URI Class Initialized
INFO - 2017-03-03 17:15:40 --> Router Class Initialized
INFO - 2017-03-03 17:15:40 --> Output Class Initialized
INFO - 2017-03-03 17:15:40 --> Security Class Initialized
DEBUG - 2017-03-03 17:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:15:40 --> Input Class Initialized
INFO - 2017-03-03 17:15:40 --> Language Class Initialized
INFO - 2017-03-03 17:15:40 --> Language Class Initialized
INFO - 2017-03-03 17:15:40 --> Config Class Initialized
INFO - 2017-03-03 17:15:40 --> Loader Class Initialized
INFO - 2017-03-03 17:15:40 --> Helper loaded: form_helper
INFO - 2017-03-03 17:15:40 --> Helper loaded: url_helper
INFO - 2017-03-03 17:15:40 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:15:40 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:15:40 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:15:40 --> Template Class Initialized
INFO - 2017-03-03 17:15:40 --> Model Class Initialized
INFO - 2017-03-03 17:15:40 --> Controller Class Initialized
DEBUG - 2017-03-03 17:15:40 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:15:40 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:15:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:15:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:15:50 --> Config Class Initialized
INFO - 2017-03-03 17:15:50 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:15:50 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:15:50 --> Utf8 Class Initialized
INFO - 2017-03-03 17:15:50 --> URI Class Initialized
INFO - 2017-03-03 17:15:50 --> Router Class Initialized
INFO - 2017-03-03 17:15:50 --> Output Class Initialized
INFO - 2017-03-03 17:15:50 --> Security Class Initialized
DEBUG - 2017-03-03 17:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:15:50 --> Input Class Initialized
INFO - 2017-03-03 17:15:50 --> Language Class Initialized
INFO - 2017-03-03 17:15:50 --> Language Class Initialized
INFO - 2017-03-03 17:15:50 --> Config Class Initialized
INFO - 2017-03-03 17:15:50 --> Loader Class Initialized
INFO - 2017-03-03 17:15:50 --> Helper loaded: form_helper
INFO - 2017-03-03 17:15:50 --> Helper loaded: url_helper
INFO - 2017-03-03 17:15:50 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:15:50 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:15:50 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:15:50 --> Template Class Initialized
INFO - 2017-03-03 17:15:50 --> Model Class Initialized
INFO - 2017-03-03 17:15:50 --> Controller Class Initialized
DEBUG - 2017-03-03 17:15:50 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:15:50 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:15:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:15:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:15:50 --> Config Class Initialized
INFO - 2017-03-03 17:15:50 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:15:50 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:15:50 --> Utf8 Class Initialized
INFO - 2017-03-03 17:15:50 --> URI Class Initialized
INFO - 2017-03-03 17:15:50 --> Router Class Initialized
INFO - 2017-03-03 17:15:50 --> Output Class Initialized
INFO - 2017-03-03 17:15:50 --> Security Class Initialized
DEBUG - 2017-03-03 17:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:15:50 --> Input Class Initialized
INFO - 2017-03-03 17:15:50 --> Language Class Initialized
INFO - 2017-03-03 17:15:50 --> Language Class Initialized
INFO - 2017-03-03 17:15:50 --> Config Class Initialized
INFO - 2017-03-03 17:15:50 --> Loader Class Initialized
INFO - 2017-03-03 17:15:50 --> Helper loaded: form_helper
INFO - 2017-03-03 17:15:50 --> Helper loaded: url_helper
INFO - 2017-03-03 17:15:50 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:15:50 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:15:50 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:15:50 --> Template Class Initialized
INFO - 2017-03-03 17:15:50 --> Model Class Initialized
INFO - 2017-03-03 17:15:50 --> Controller Class Initialized
DEBUG - 2017-03-03 17:15:50 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:15:50 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:15:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:15:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:15:59 --> Config Class Initialized
INFO - 2017-03-03 17:15:59 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:15:59 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:15:59 --> Utf8 Class Initialized
INFO - 2017-03-03 17:15:59 --> URI Class Initialized
INFO - 2017-03-03 17:15:59 --> Router Class Initialized
INFO - 2017-03-03 17:15:59 --> Output Class Initialized
INFO - 2017-03-03 17:15:59 --> Security Class Initialized
DEBUG - 2017-03-03 17:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:15:59 --> Input Class Initialized
INFO - 2017-03-03 17:15:59 --> Language Class Initialized
INFO - 2017-03-03 17:15:59 --> Language Class Initialized
INFO - 2017-03-03 17:15:59 --> Config Class Initialized
INFO - 2017-03-03 17:15:59 --> Loader Class Initialized
INFO - 2017-03-03 17:15:59 --> Helper loaded: form_helper
INFO - 2017-03-03 17:15:59 --> Helper loaded: url_helper
INFO - 2017-03-03 17:15:59 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:15:59 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:15:59 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:15:59 --> Template Class Initialized
INFO - 2017-03-03 17:15:59 --> Model Class Initialized
INFO - 2017-03-03 17:15:59 --> Controller Class Initialized
DEBUG - 2017-03-03 17:15:59 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:15:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:15:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:15:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 17:15:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-03 17:15:59 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 17:15:59 --> Final output sent to browser
DEBUG - 2017-03-03 17:15:59 --> Total execution time: 0.0135
INFO - 2017-03-03 17:16:00 --> Config Class Initialized
INFO - 2017-03-03 17:16:00 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:16:00 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:16:00 --> Utf8 Class Initialized
INFO - 2017-03-03 17:16:00 --> URI Class Initialized
INFO - 2017-03-03 17:16:00 --> Router Class Initialized
INFO - 2017-03-03 17:16:00 --> Output Class Initialized
INFO - 2017-03-03 17:16:00 --> Security Class Initialized
DEBUG - 2017-03-03 17:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:16:00 --> Input Class Initialized
INFO - 2017-03-03 17:16:00 --> Language Class Initialized
INFO - 2017-03-03 17:16:00 --> Language Class Initialized
INFO - 2017-03-03 17:16:00 --> Config Class Initialized
INFO - 2017-03-03 17:16:00 --> Loader Class Initialized
INFO - 2017-03-03 17:16:00 --> Helper loaded: form_helper
INFO - 2017-03-03 17:16:00 --> Helper loaded: url_helper
INFO - 2017-03-03 17:16:00 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:16:00 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:16:00 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:16:00 --> Template Class Initialized
INFO - 2017-03-03 17:16:00 --> Model Class Initialized
INFO - 2017-03-03 17:16:00 --> Controller Class Initialized
DEBUG - 2017-03-03 17:16:00 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:16:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:16:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:16:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:16:00 --> Config Class Initialized
INFO - 2017-03-03 17:16:00 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:16:00 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:16:00 --> Utf8 Class Initialized
INFO - 2017-03-03 17:16:00 --> URI Class Initialized
INFO - 2017-03-03 17:16:00 --> Router Class Initialized
INFO - 2017-03-03 17:16:00 --> Output Class Initialized
INFO - 2017-03-03 17:16:00 --> Security Class Initialized
DEBUG - 2017-03-03 17:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:16:00 --> Input Class Initialized
INFO - 2017-03-03 17:16:00 --> Language Class Initialized
INFO - 2017-03-03 17:16:00 --> Language Class Initialized
INFO - 2017-03-03 17:16:00 --> Config Class Initialized
INFO - 2017-03-03 17:16:00 --> Loader Class Initialized
INFO - 2017-03-03 17:16:00 --> Helper loaded: form_helper
INFO - 2017-03-03 17:16:00 --> Helper loaded: url_helper
INFO - 2017-03-03 17:16:00 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:16:00 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:16:00 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:16:00 --> Template Class Initialized
INFO - 2017-03-03 17:16:00 --> Model Class Initialized
INFO - 2017-03-03 17:16:00 --> Controller Class Initialized
DEBUG - 2017-03-03 17:16:00 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:16:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:16:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:16:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:16:01 --> Config Class Initialized
INFO - 2017-03-03 17:16:01 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:16:01 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:16:01 --> Utf8 Class Initialized
INFO - 2017-03-03 17:16:01 --> URI Class Initialized
INFO - 2017-03-03 17:16:01 --> Router Class Initialized
INFO - 2017-03-03 17:16:01 --> Output Class Initialized
INFO - 2017-03-03 17:16:01 --> Security Class Initialized
DEBUG - 2017-03-03 17:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:16:01 --> Input Class Initialized
INFO - 2017-03-03 17:16:01 --> Language Class Initialized
INFO - 2017-03-03 17:16:01 --> Language Class Initialized
INFO - 2017-03-03 17:16:01 --> Config Class Initialized
INFO - 2017-03-03 17:16:01 --> Loader Class Initialized
INFO - 2017-03-03 17:16:01 --> Helper loaded: form_helper
INFO - 2017-03-03 17:16:01 --> Helper loaded: url_helper
INFO - 2017-03-03 17:16:01 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:16:01 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:16:01 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:16:01 --> Template Class Initialized
INFO - 2017-03-03 17:16:01 --> Model Class Initialized
INFO - 2017-03-03 17:16:01 --> Controller Class Initialized
DEBUG - 2017-03-03 17:16:01 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:16:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:16:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:16:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:16:11 --> Config Class Initialized
INFO - 2017-03-03 17:16:11 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:16:11 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:16:11 --> Utf8 Class Initialized
INFO - 2017-03-03 17:16:11 --> URI Class Initialized
INFO - 2017-03-03 17:16:11 --> Router Class Initialized
INFO - 2017-03-03 17:16:11 --> Output Class Initialized
INFO - 2017-03-03 17:16:11 --> Security Class Initialized
DEBUG - 2017-03-03 17:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:16:11 --> Input Class Initialized
INFO - 2017-03-03 17:16:11 --> Language Class Initialized
INFO - 2017-03-03 17:16:11 --> Language Class Initialized
INFO - 2017-03-03 17:16:11 --> Config Class Initialized
INFO - 2017-03-03 17:16:11 --> Loader Class Initialized
INFO - 2017-03-03 17:16:11 --> Helper loaded: form_helper
INFO - 2017-03-03 17:16:11 --> Helper loaded: url_helper
INFO - 2017-03-03 17:16:11 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:16:11 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:16:11 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:16:11 --> Template Class Initialized
INFO - 2017-03-03 17:16:11 --> Model Class Initialized
INFO - 2017-03-03 17:16:11 --> Controller Class Initialized
DEBUG - 2017-03-03 17:16:11 --> Login MX_Controller Initialized
INFO - 2017-03-03 17:16:11 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:16:11 --> Form Validation Class Initialized
INFO - 2017-03-03 17:16:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-03 17:16:11 --> Config Class Initialized
INFO - 2017-03-03 17:16:11 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:16:11 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:16:11 --> Utf8 Class Initialized
INFO - 2017-03-03 17:16:11 --> URI Class Initialized
INFO - 2017-03-03 17:16:11 --> Router Class Initialized
INFO - 2017-03-03 17:16:11 --> Output Class Initialized
INFO - 2017-03-03 17:16:11 --> Security Class Initialized
DEBUG - 2017-03-03 17:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:16:11 --> Input Class Initialized
INFO - 2017-03-03 17:16:11 --> Language Class Initialized
INFO - 2017-03-03 17:16:11 --> Language Class Initialized
INFO - 2017-03-03 17:16:11 --> Config Class Initialized
INFO - 2017-03-03 17:16:11 --> Loader Class Initialized
INFO - 2017-03-03 17:16:11 --> Helper loaded: form_helper
INFO - 2017-03-03 17:16:11 --> Helper loaded: url_helper
INFO - 2017-03-03 17:16:11 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:16:11 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:16:11 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:16:11 --> Template Class Initialized
INFO - 2017-03-03 17:16:11 --> Model Class Initialized
INFO - 2017-03-03 17:16:11 --> Controller Class Initialized
DEBUG - 2017-03-03 17:16:11 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:16:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:16:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:16:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 17:16:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-03 17:16:11 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 17:16:11 --> Final output sent to browser
DEBUG - 2017-03-03 17:16:11 --> Total execution time: 0.0143
INFO - 2017-03-03 17:16:11 --> Config Class Initialized
INFO - 2017-03-03 17:16:11 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:16:11 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:16:11 --> Utf8 Class Initialized
INFO - 2017-03-03 17:16:11 --> URI Class Initialized
INFO - 2017-03-03 17:16:11 --> Router Class Initialized
INFO - 2017-03-03 17:16:11 --> Output Class Initialized
INFO - 2017-03-03 17:16:11 --> Security Class Initialized
DEBUG - 2017-03-03 17:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:16:11 --> Input Class Initialized
INFO - 2017-03-03 17:16:11 --> Language Class Initialized
INFO - 2017-03-03 17:16:11 --> Language Class Initialized
INFO - 2017-03-03 17:16:11 --> Config Class Initialized
INFO - 2017-03-03 17:16:11 --> Loader Class Initialized
INFO - 2017-03-03 17:16:11 --> Helper loaded: form_helper
INFO - 2017-03-03 17:16:11 --> Helper loaded: url_helper
INFO - 2017-03-03 17:16:11 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:16:11 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:16:11 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:16:11 --> Template Class Initialized
INFO - 2017-03-03 17:16:11 --> Model Class Initialized
INFO - 2017-03-03 17:16:11 --> Controller Class Initialized
DEBUG - 2017-03-03 17:16:11 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:16:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:16:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:16:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:16:12 --> Config Class Initialized
INFO - 2017-03-03 17:16:12 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:16:12 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:16:12 --> Utf8 Class Initialized
INFO - 2017-03-03 17:16:12 --> URI Class Initialized
INFO - 2017-03-03 17:16:12 --> Router Class Initialized
INFO - 2017-03-03 17:16:12 --> Output Class Initialized
INFO - 2017-03-03 17:16:12 --> Security Class Initialized
DEBUG - 2017-03-03 17:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:16:12 --> Input Class Initialized
INFO - 2017-03-03 17:16:12 --> Language Class Initialized
INFO - 2017-03-03 17:16:12 --> Language Class Initialized
INFO - 2017-03-03 17:16:12 --> Config Class Initialized
INFO - 2017-03-03 17:16:12 --> Loader Class Initialized
INFO - 2017-03-03 17:16:12 --> Helper loaded: form_helper
INFO - 2017-03-03 17:16:12 --> Helper loaded: url_helper
INFO - 2017-03-03 17:16:12 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:16:12 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:16:12 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:16:12 --> Template Class Initialized
INFO - 2017-03-03 17:16:12 --> Model Class Initialized
INFO - 2017-03-03 17:16:12 --> Controller Class Initialized
DEBUG - 2017-03-03 17:16:12 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:16:12 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:16:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:16:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:16:12 --> Config Class Initialized
INFO - 2017-03-03 17:16:12 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:16:12 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:16:12 --> Utf8 Class Initialized
INFO - 2017-03-03 17:16:12 --> URI Class Initialized
INFO - 2017-03-03 17:16:12 --> Router Class Initialized
INFO - 2017-03-03 17:16:12 --> Output Class Initialized
INFO - 2017-03-03 17:16:12 --> Security Class Initialized
DEBUG - 2017-03-03 17:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:16:12 --> Input Class Initialized
INFO - 2017-03-03 17:16:12 --> Language Class Initialized
INFO - 2017-03-03 17:16:12 --> Language Class Initialized
INFO - 2017-03-03 17:16:12 --> Config Class Initialized
INFO - 2017-03-03 17:16:12 --> Loader Class Initialized
INFO - 2017-03-03 17:16:12 --> Helper loaded: form_helper
INFO - 2017-03-03 17:16:12 --> Helper loaded: url_helper
INFO - 2017-03-03 17:16:12 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:16:12 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:16:12 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:16:12 --> Template Class Initialized
INFO - 2017-03-03 17:16:12 --> Model Class Initialized
INFO - 2017-03-03 17:16:12 --> Controller Class Initialized
DEBUG - 2017-03-03 17:16:12 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:16:12 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:16:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:16:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:20:45 --> Config Class Initialized
INFO - 2017-03-03 17:20:45 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:20:45 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:20:45 --> Utf8 Class Initialized
INFO - 2017-03-03 17:20:45 --> URI Class Initialized
DEBUG - 2017-03-03 17:20:45 --> No URI present. Default controller set.
INFO - 2017-03-03 17:20:45 --> Router Class Initialized
INFO - 2017-03-03 17:20:45 --> Output Class Initialized
INFO - 2017-03-03 17:20:45 --> Security Class Initialized
DEBUG - 2017-03-03 17:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:20:45 --> Input Class Initialized
INFO - 2017-03-03 17:20:45 --> Language Class Initialized
INFO - 2017-03-03 17:20:45 --> Language Class Initialized
INFO - 2017-03-03 17:20:45 --> Config Class Initialized
INFO - 2017-03-03 17:20:45 --> Loader Class Initialized
INFO - 2017-03-03 17:20:45 --> Helper loaded: form_helper
INFO - 2017-03-03 17:20:45 --> Helper loaded: url_helper
INFO - 2017-03-03 17:20:45 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:20:45 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:20:45 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:20:45 --> Template Class Initialized
INFO - 2017-03-03 17:20:45 --> Model Class Initialized
INFO - 2017-03-03 17:20:45 --> Controller Class Initialized
DEBUG - 2017-03-03 17:20:45 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:20:45 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:20:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:20:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 17:20:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-03 17:20:45 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 17:20:45 --> Final output sent to browser
DEBUG - 2017-03-03 17:20:45 --> Total execution time: 0.0326
INFO - 2017-03-03 17:20:45 --> Config Class Initialized
INFO - 2017-03-03 17:20:45 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:20:45 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:20:45 --> Utf8 Class Initialized
INFO - 2017-03-03 17:20:45 --> URI Class Initialized
INFO - 2017-03-03 17:20:45 --> Router Class Initialized
INFO - 2017-03-03 17:20:45 --> Output Class Initialized
INFO - 2017-03-03 17:20:45 --> Security Class Initialized
DEBUG - 2017-03-03 17:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:20:45 --> Input Class Initialized
INFO - 2017-03-03 17:20:45 --> Language Class Initialized
INFO - 2017-03-03 17:20:45 --> Language Class Initialized
INFO - 2017-03-03 17:20:45 --> Config Class Initialized
INFO - 2017-03-03 17:20:45 --> Loader Class Initialized
INFO - 2017-03-03 17:20:45 --> Helper loaded: form_helper
INFO - 2017-03-03 17:20:45 --> Helper loaded: url_helper
INFO - 2017-03-03 17:20:45 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:20:45 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:20:45 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:20:45 --> Template Class Initialized
INFO - 2017-03-03 17:20:45 --> Model Class Initialized
INFO - 2017-03-03 17:20:45 --> Controller Class Initialized
DEBUG - 2017-03-03 17:20:45 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:20:45 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:20:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:20:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:20:45 --> Config Class Initialized
INFO - 2017-03-03 17:20:45 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:20:45 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:20:45 --> Utf8 Class Initialized
INFO - 2017-03-03 17:20:45 --> URI Class Initialized
INFO - 2017-03-03 17:20:45 --> Router Class Initialized
INFO - 2017-03-03 17:20:45 --> Output Class Initialized
INFO - 2017-03-03 17:20:45 --> Security Class Initialized
DEBUG - 2017-03-03 17:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:20:45 --> Input Class Initialized
INFO - 2017-03-03 17:20:45 --> Language Class Initialized
INFO - 2017-03-03 17:20:45 --> Language Class Initialized
INFO - 2017-03-03 17:20:45 --> Config Class Initialized
INFO - 2017-03-03 17:20:45 --> Loader Class Initialized
INFO - 2017-03-03 17:20:45 --> Helper loaded: form_helper
INFO - 2017-03-03 17:20:45 --> Helper loaded: url_helper
INFO - 2017-03-03 17:20:45 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:20:45 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:20:45 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:20:45 --> Template Class Initialized
INFO - 2017-03-03 17:20:45 --> Model Class Initialized
INFO - 2017-03-03 17:20:45 --> Controller Class Initialized
DEBUG - 2017-03-03 17:20:45 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:20:45 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:20:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:20:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:20:45 --> Config Class Initialized
INFO - 2017-03-03 17:20:45 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:20:45 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:20:45 --> Utf8 Class Initialized
INFO - 2017-03-03 17:20:45 --> URI Class Initialized
INFO - 2017-03-03 17:20:45 --> Router Class Initialized
INFO - 2017-03-03 17:20:45 --> Output Class Initialized
INFO - 2017-03-03 17:20:45 --> Security Class Initialized
DEBUG - 2017-03-03 17:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:20:45 --> Input Class Initialized
INFO - 2017-03-03 17:20:45 --> Language Class Initialized
INFO - 2017-03-03 17:20:45 --> Language Class Initialized
INFO - 2017-03-03 17:20:45 --> Config Class Initialized
INFO - 2017-03-03 17:20:45 --> Loader Class Initialized
INFO - 2017-03-03 17:20:45 --> Helper loaded: form_helper
INFO - 2017-03-03 17:20:45 --> Helper loaded: url_helper
INFO - 2017-03-03 17:20:45 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:20:45 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:20:45 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:20:45 --> Template Class Initialized
INFO - 2017-03-03 17:20:45 --> Model Class Initialized
INFO - 2017-03-03 17:20:45 --> Controller Class Initialized
DEBUG - 2017-03-03 17:20:45 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:20:45 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:20:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:20:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:20:56 --> Config Class Initialized
INFO - 2017-03-03 17:20:56 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:20:56 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:20:56 --> Utf8 Class Initialized
INFO - 2017-03-03 17:20:56 --> URI Class Initialized
INFO - 2017-03-03 17:20:56 --> Router Class Initialized
INFO - 2017-03-03 17:20:56 --> Output Class Initialized
INFO - 2017-03-03 17:20:56 --> Security Class Initialized
DEBUG - 2017-03-03 17:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:20:56 --> Input Class Initialized
INFO - 2017-03-03 17:20:56 --> Language Class Initialized
INFO - 2017-03-03 17:20:56 --> Language Class Initialized
INFO - 2017-03-03 17:20:56 --> Config Class Initialized
INFO - 2017-03-03 17:20:56 --> Loader Class Initialized
INFO - 2017-03-03 17:20:56 --> Helper loaded: form_helper
INFO - 2017-03-03 17:20:56 --> Helper loaded: url_helper
INFO - 2017-03-03 17:20:56 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:20:56 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:20:56 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:20:56 --> Template Class Initialized
INFO - 2017-03-03 17:20:56 --> Model Class Initialized
INFO - 2017-03-03 17:20:56 --> Controller Class Initialized
DEBUG - 2017-03-03 17:20:56 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:20:56 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:20:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:20:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:21:17 --> Config Class Initialized
INFO - 2017-03-03 17:21:17 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:17 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:17 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:17 --> URI Class Initialized
INFO - 2017-03-03 17:21:17 --> Router Class Initialized
INFO - 2017-03-03 17:21:17 --> Output Class Initialized
INFO - 2017-03-03 17:21:17 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:17 --> Input Class Initialized
INFO - 2017-03-03 17:21:17 --> Language Class Initialized
INFO - 2017-03-03 17:21:17 --> Language Class Initialized
INFO - 2017-03-03 17:21:17 --> Config Class Initialized
INFO - 2017-03-03 17:21:17 --> Loader Class Initialized
INFO - 2017-03-03 17:21:17 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:17 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:17 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:17 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:17 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:17 --> Template Class Initialized
INFO - 2017-03-03 17:21:17 --> Model Class Initialized
INFO - 2017-03-03 17:21:17 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:17 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:21:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:21:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 17:21:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-03 17:21:17 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 17:21:17 --> Final output sent to browser
DEBUG - 2017-03-03 17:21:17 --> Total execution time: 0.0155
INFO - 2017-03-03 17:21:17 --> Config Class Initialized
INFO - 2017-03-03 17:21:17 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:17 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:17 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:17 --> URI Class Initialized
INFO - 2017-03-03 17:21:17 --> Router Class Initialized
INFO - 2017-03-03 17:21:17 --> Output Class Initialized
INFO - 2017-03-03 17:21:17 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:17 --> Input Class Initialized
INFO - 2017-03-03 17:21:17 --> Language Class Initialized
INFO - 2017-03-03 17:21:17 --> Language Class Initialized
INFO - 2017-03-03 17:21:17 --> Config Class Initialized
INFO - 2017-03-03 17:21:17 --> Loader Class Initialized
INFO - 2017-03-03 17:21:17 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:17 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:17 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:17 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:17 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:17 --> Template Class Initialized
INFO - 2017-03-03 17:21:17 --> Model Class Initialized
INFO - 2017-03-03 17:21:17 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:17 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:21:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:21:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:21:17 --> Config Class Initialized
INFO - 2017-03-03 17:21:17 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:17 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:17 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:17 --> URI Class Initialized
INFO - 2017-03-03 17:21:17 --> Router Class Initialized
INFO - 2017-03-03 17:21:17 --> Output Class Initialized
INFO - 2017-03-03 17:21:17 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:17 --> Input Class Initialized
INFO - 2017-03-03 17:21:17 --> Language Class Initialized
INFO - 2017-03-03 17:21:17 --> Language Class Initialized
INFO - 2017-03-03 17:21:17 --> Config Class Initialized
INFO - 2017-03-03 17:21:17 --> Loader Class Initialized
INFO - 2017-03-03 17:21:17 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:17 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:17 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:17 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:17 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:17 --> Template Class Initialized
INFO - 2017-03-03 17:21:17 --> Model Class Initialized
INFO - 2017-03-03 17:21:17 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:17 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:21:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:21:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:21:31 --> Config Class Initialized
INFO - 2017-03-03 17:21:31 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:31 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:31 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:31 --> URI Class Initialized
INFO - 2017-03-03 17:21:31 --> Router Class Initialized
INFO - 2017-03-03 17:21:31 --> Output Class Initialized
INFO - 2017-03-03 17:21:31 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:31 --> Input Class Initialized
INFO - 2017-03-03 17:21:31 --> Language Class Initialized
INFO - 2017-03-03 17:21:31 --> Language Class Initialized
INFO - 2017-03-03 17:21:31 --> Config Class Initialized
INFO - 2017-03-03 17:21:31 --> Loader Class Initialized
INFO - 2017-03-03 17:21:31 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:31 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:31 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:31 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:31 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:31 --> Template Class Initialized
INFO - 2017-03-03 17:21:31 --> Model Class Initialized
INFO - 2017-03-03 17:21:31 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:31 --> Login MX_Controller Initialized
INFO - 2017-03-03 17:21:31 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:21:31 --> Form Validation Class Initialized
INFO - 2017-03-03 17:21:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-03 17:21:31 --> Config Class Initialized
INFO - 2017-03-03 17:21:31 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:31 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:31 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:31 --> URI Class Initialized
INFO - 2017-03-03 17:21:31 --> Router Class Initialized
INFO - 2017-03-03 17:21:31 --> Output Class Initialized
INFO - 2017-03-03 17:21:31 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:31 --> Input Class Initialized
INFO - 2017-03-03 17:21:31 --> Language Class Initialized
INFO - 2017-03-03 17:21:31 --> Language Class Initialized
INFO - 2017-03-03 17:21:31 --> Config Class Initialized
INFO - 2017-03-03 17:21:31 --> Loader Class Initialized
INFO - 2017-03-03 17:21:31 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:31 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:31 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:31 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:31 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:31 --> Template Class Initialized
INFO - 2017-03-03 17:21:31 --> Model Class Initialized
INFO - 2017-03-03 17:21:31 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:31 --> Dashboard MX_Controller Initialized
INFO - 2017-03-03 17:21:31 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:21:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:21:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:21:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-03 17:21:31 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:21:31 --> Final output sent to browser
DEBUG - 2017-03-03 17:21:31 --> Total execution time: 0.0157
INFO - 2017-03-03 17:21:36 --> Config Class Initialized
INFO - 2017-03-03 17:21:36 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:36 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:36 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:36 --> URI Class Initialized
INFO - 2017-03-03 17:21:36 --> Router Class Initialized
INFO - 2017-03-03 17:21:36 --> Output Class Initialized
INFO - 2017-03-03 17:21:36 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:36 --> Input Class Initialized
INFO - 2017-03-03 17:21:36 --> Language Class Initialized
INFO - 2017-03-03 17:21:36 --> Language Class Initialized
INFO - 2017-03-03 17:21:36 --> Config Class Initialized
INFO - 2017-03-03 17:21:36 --> Loader Class Initialized
INFO - 2017-03-03 17:21:36 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:36 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:36 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:36 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:36 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:36 --> Template Class Initialized
INFO - 2017-03-03 17:21:36 --> Model Class Initialized
INFO - 2017-03-03 17:21:36 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:36 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:21:36 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:21:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:21:38 --> Config Class Initialized
INFO - 2017-03-03 17:21:38 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:38 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:38 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:38 --> URI Class Initialized
INFO - 2017-03-03 17:21:38 --> Router Class Initialized
INFO - 2017-03-03 17:21:38 --> Output Class Initialized
INFO - 2017-03-03 17:21:38 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:38 --> Input Class Initialized
INFO - 2017-03-03 17:21:38 --> Language Class Initialized
INFO - 2017-03-03 17:21:38 --> Language Class Initialized
INFO - 2017-03-03 17:21:38 --> Config Class Initialized
INFO - 2017-03-03 17:21:38 --> Loader Class Initialized
INFO - 2017-03-03 17:21:38 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:38 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:38 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:38 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:38 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:38 --> Template Class Initialized
INFO - 2017-03-03 17:21:38 --> Model Class Initialized
INFO - 2017-03-03 17:21:38 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:38 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:21:38 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:21:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:21:40 --> Config Class Initialized
INFO - 2017-03-03 17:21:40 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:40 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:40 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:40 --> URI Class Initialized
INFO - 2017-03-03 17:21:40 --> Router Class Initialized
INFO - 2017-03-03 17:21:40 --> Output Class Initialized
INFO - 2017-03-03 17:21:40 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:40 --> Input Class Initialized
INFO - 2017-03-03 17:21:40 --> Language Class Initialized
INFO - 2017-03-03 17:21:40 --> Language Class Initialized
INFO - 2017-03-03 17:21:40 --> Config Class Initialized
INFO - 2017-03-03 17:21:40 --> Loader Class Initialized
INFO - 2017-03-03 17:21:40 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:40 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:40 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:40 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:40 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:40 --> Template Class Initialized
INFO - 2017-03-03 17:21:40 --> Model Class Initialized
INFO - 2017-03-03 17:21:40 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:40 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:21:40 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:21:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:21:44 --> Config Class Initialized
INFO - 2017-03-03 17:21:44 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:44 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:44 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:44 --> URI Class Initialized
INFO - 2017-03-03 17:21:44 --> Router Class Initialized
INFO - 2017-03-03 17:21:44 --> Output Class Initialized
INFO - 2017-03-03 17:21:44 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:44 --> Input Class Initialized
INFO - 2017-03-03 17:21:44 --> Language Class Initialized
INFO - 2017-03-03 17:21:44 --> Language Class Initialized
INFO - 2017-03-03 17:21:44 --> Config Class Initialized
INFO - 2017-03-03 17:21:44 --> Loader Class Initialized
INFO - 2017-03-03 17:21:44 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:44 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:44 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:44 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:44 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:44 --> Template Class Initialized
INFO - 2017-03-03 17:21:44 --> Model Class Initialized
INFO - 2017-03-03 17:21:44 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:44 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:21:44 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:21:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:21:46 --> Config Class Initialized
INFO - 2017-03-03 17:21:46 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:46 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:46 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:46 --> URI Class Initialized
INFO - 2017-03-03 17:21:46 --> Router Class Initialized
INFO - 2017-03-03 17:21:46 --> Output Class Initialized
INFO - 2017-03-03 17:21:46 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:46 --> Input Class Initialized
INFO - 2017-03-03 17:21:46 --> Language Class Initialized
INFO - 2017-03-03 17:21:46 --> Language Class Initialized
INFO - 2017-03-03 17:21:46 --> Config Class Initialized
INFO - 2017-03-03 17:21:46 --> Loader Class Initialized
INFO - 2017-03-03 17:21:46 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:46 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:46 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:46 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:46 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:46 --> Template Class Initialized
INFO - 2017-03-03 17:21:46 --> Model Class Initialized
INFO - 2017-03-03 17:21:46 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:46 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:21:46 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:21:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:21:46 --> Config Class Initialized
INFO - 2017-03-03 17:21:46 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:46 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:46 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:46 --> URI Class Initialized
INFO - 2017-03-03 17:21:46 --> Router Class Initialized
INFO - 2017-03-03 17:21:46 --> Output Class Initialized
INFO - 2017-03-03 17:21:46 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:46 --> Input Class Initialized
INFO - 2017-03-03 17:21:46 --> Language Class Initialized
INFO - 2017-03-03 17:21:46 --> Language Class Initialized
INFO - 2017-03-03 17:21:46 --> Config Class Initialized
INFO - 2017-03-03 17:21:46 --> Loader Class Initialized
INFO - 2017-03-03 17:21:46 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:46 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:46 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:46 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:46 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:46 --> Template Class Initialized
INFO - 2017-03-03 17:21:46 --> Model Class Initialized
INFO - 2017-03-03 17:21:46 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:46 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:21:46 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:21:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:21:47 --> Config Class Initialized
INFO - 2017-03-03 17:21:47 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:47 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:47 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:47 --> URI Class Initialized
INFO - 2017-03-03 17:21:47 --> Router Class Initialized
INFO - 2017-03-03 17:21:47 --> Output Class Initialized
INFO - 2017-03-03 17:21:47 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:47 --> Input Class Initialized
INFO - 2017-03-03 17:21:47 --> Language Class Initialized
INFO - 2017-03-03 17:21:47 --> Language Class Initialized
INFO - 2017-03-03 17:21:47 --> Config Class Initialized
INFO - 2017-03-03 17:21:47 --> Loader Class Initialized
INFO - 2017-03-03 17:21:47 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:47 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:47 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:47 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:47 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:47 --> Template Class Initialized
INFO - 2017-03-03 17:21:47 --> Model Class Initialized
INFO - 2017-03-03 17:21:47 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:47 --> Dashboard MX_Controller Initialized
INFO - 2017-03-03 17:21:47 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:21:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:21:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:21:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-03 17:21:47 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:21:47 --> Final output sent to browser
DEBUG - 2017-03-03 17:21:47 --> Total execution time: 0.0138
INFO - 2017-03-03 17:21:48 --> Config Class Initialized
INFO - 2017-03-03 17:21:48 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:48 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:48 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:48 --> URI Class Initialized
INFO - 2017-03-03 17:21:48 --> Router Class Initialized
INFO - 2017-03-03 17:21:48 --> Output Class Initialized
INFO - 2017-03-03 17:21:48 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:48 --> Input Class Initialized
INFO - 2017-03-03 17:21:48 --> Language Class Initialized
INFO - 2017-03-03 17:21:48 --> Language Class Initialized
INFO - 2017-03-03 17:21:48 --> Config Class Initialized
INFO - 2017-03-03 17:21:48 --> Loader Class Initialized
INFO - 2017-03-03 17:21:48 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:48 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:48 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:48 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:48 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:48 --> Template Class Initialized
INFO - 2017-03-03 17:21:48 --> Model Class Initialized
INFO - 2017-03-03 17:21:48 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:48 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:21:48 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:21:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:21:48 --> Config Class Initialized
INFO - 2017-03-03 17:21:48 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:48 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:48 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:48 --> URI Class Initialized
INFO - 2017-03-03 17:21:48 --> Router Class Initialized
INFO - 2017-03-03 17:21:48 --> Output Class Initialized
INFO - 2017-03-03 17:21:48 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:48 --> Input Class Initialized
INFO - 2017-03-03 17:21:48 --> Language Class Initialized
INFO - 2017-03-03 17:21:48 --> Language Class Initialized
INFO - 2017-03-03 17:21:48 --> Config Class Initialized
INFO - 2017-03-03 17:21:48 --> Loader Class Initialized
INFO - 2017-03-03 17:21:48 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:48 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:48 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:48 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:48 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:48 --> Template Class Initialized
INFO - 2017-03-03 17:21:48 --> Model Class Initialized
INFO - 2017-03-03 17:21:48 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:48 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:21:48 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:21:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 17:21:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-03 17:21:48 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 17:21:48 --> Final output sent to browser
DEBUG - 2017-03-03 17:21:48 --> Total execution time: 0.0127
INFO - 2017-03-03 17:21:48 --> Config Class Initialized
INFO - 2017-03-03 17:21:48 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:48 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:48 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:48 --> URI Class Initialized
INFO - 2017-03-03 17:21:48 --> Router Class Initialized
INFO - 2017-03-03 17:21:48 --> Output Class Initialized
INFO - 2017-03-03 17:21:48 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:48 --> Input Class Initialized
INFO - 2017-03-03 17:21:48 --> Language Class Initialized
INFO - 2017-03-03 17:21:48 --> Language Class Initialized
INFO - 2017-03-03 17:21:48 --> Config Class Initialized
INFO - 2017-03-03 17:21:48 --> Loader Class Initialized
INFO - 2017-03-03 17:21:48 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:48 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:48 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:48 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:48 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:48 --> Template Class Initialized
INFO - 2017-03-03 17:21:48 --> Model Class Initialized
INFO - 2017-03-03 17:21:48 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:48 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:21:48 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:21:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:21:48 --> Config Class Initialized
INFO - 2017-03-03 17:21:48 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:48 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:48 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:48 --> URI Class Initialized
INFO - 2017-03-03 17:21:48 --> Router Class Initialized
INFO - 2017-03-03 17:21:48 --> Output Class Initialized
INFO - 2017-03-03 17:21:48 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:48 --> Input Class Initialized
INFO - 2017-03-03 17:21:48 --> Language Class Initialized
INFO - 2017-03-03 17:21:48 --> Language Class Initialized
INFO - 2017-03-03 17:21:48 --> Config Class Initialized
INFO - 2017-03-03 17:21:48 --> Loader Class Initialized
INFO - 2017-03-03 17:21:48 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:48 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:48 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:48 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:48 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:48 --> Template Class Initialized
INFO - 2017-03-03 17:21:48 --> Model Class Initialized
INFO - 2017-03-03 17:21:48 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:48 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:21:48 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:21:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:21:49 --> Config Class Initialized
INFO - 2017-03-03 17:21:49 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:49 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:49 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:49 --> URI Class Initialized
INFO - 2017-03-03 17:21:49 --> Router Class Initialized
INFO - 2017-03-03 17:21:49 --> Output Class Initialized
INFO - 2017-03-03 17:21:49 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:49 --> Input Class Initialized
INFO - 2017-03-03 17:21:49 --> Language Class Initialized
INFO - 2017-03-03 17:21:49 --> Language Class Initialized
INFO - 2017-03-03 17:21:49 --> Config Class Initialized
INFO - 2017-03-03 17:21:49 --> Loader Class Initialized
INFO - 2017-03-03 17:21:49 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:49 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:49 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:49 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:49 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:49 --> Template Class Initialized
INFO - 2017-03-03 17:21:49 --> Model Class Initialized
INFO - 2017-03-03 17:21:49 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:49 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:21:49 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:21:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:21:51 --> Config Class Initialized
INFO - 2017-03-03 17:21:51 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:51 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:51 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:51 --> URI Class Initialized
INFO - 2017-03-03 17:21:51 --> Router Class Initialized
INFO - 2017-03-03 17:21:51 --> Output Class Initialized
INFO - 2017-03-03 17:21:51 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:51 --> Input Class Initialized
INFO - 2017-03-03 17:21:51 --> Language Class Initialized
INFO - 2017-03-03 17:21:51 --> Language Class Initialized
INFO - 2017-03-03 17:21:51 --> Config Class Initialized
INFO - 2017-03-03 17:21:51 --> Loader Class Initialized
INFO - 2017-03-03 17:21:51 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:51 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:51 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:51 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:51 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:51 --> Template Class Initialized
INFO - 2017-03-03 17:21:51 --> Model Class Initialized
INFO - 2017-03-03 17:21:51 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:51 --> Dashboard MX_Controller Initialized
INFO - 2017-03-03 17:21:51 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:21:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:21:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:21:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-03 17:21:51 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:21:51 --> Final output sent to browser
DEBUG - 2017-03-03 17:21:51 --> Total execution time: 0.0115
INFO - 2017-03-03 17:21:51 --> Config Class Initialized
INFO - 2017-03-03 17:21:51 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:51 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:51 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:51 --> URI Class Initialized
INFO - 2017-03-03 17:21:51 --> Router Class Initialized
INFO - 2017-03-03 17:21:51 --> Output Class Initialized
INFO - 2017-03-03 17:21:51 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:51 --> Input Class Initialized
INFO - 2017-03-03 17:21:51 --> Language Class Initialized
INFO - 2017-03-03 17:21:51 --> Language Class Initialized
INFO - 2017-03-03 17:21:51 --> Config Class Initialized
INFO - 2017-03-03 17:21:51 --> Loader Class Initialized
INFO - 2017-03-03 17:21:51 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:51 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:51 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:51 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:52 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:52 --> Template Class Initialized
INFO - 2017-03-03 17:21:52 --> Model Class Initialized
INFO - 2017-03-03 17:21:52 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:52 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:21:52 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:21:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:21:55 --> Config Class Initialized
INFO - 2017-03-03 17:21:55 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:55 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:55 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:55 --> URI Class Initialized
INFO - 2017-03-03 17:21:55 --> Router Class Initialized
INFO - 2017-03-03 17:21:55 --> Output Class Initialized
INFO - 2017-03-03 17:21:55 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:55 --> Input Class Initialized
INFO - 2017-03-03 17:21:55 --> Language Class Initialized
INFO - 2017-03-03 17:21:55 --> Language Class Initialized
INFO - 2017-03-03 17:21:55 --> Config Class Initialized
INFO - 2017-03-03 17:21:55 --> Loader Class Initialized
INFO - 2017-03-03 17:21:55 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:55 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:55 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:55 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:55 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:55 --> Template Class Initialized
INFO - 2017-03-03 17:21:55 --> Model Class Initialized
INFO - 2017-03-03 17:21:55 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:55 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:21:55 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:21:55 --> Model Class Initialized
DEBUG - 2017-03-03 17:21:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:21:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:21:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:21:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/project_list.php
DEBUG - 2017-03-03 17:21:55 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:21:55 --> Final output sent to browser
DEBUG - 2017-03-03 17:21:55 --> Total execution time: 0.0173
INFO - 2017-03-03 17:21:58 --> Config Class Initialized
INFO - 2017-03-03 17:21:58 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:21:58 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:21:58 --> Utf8 Class Initialized
INFO - 2017-03-03 17:21:58 --> URI Class Initialized
INFO - 2017-03-03 17:21:58 --> Router Class Initialized
INFO - 2017-03-03 17:21:58 --> Output Class Initialized
INFO - 2017-03-03 17:21:58 --> Security Class Initialized
DEBUG - 2017-03-03 17:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:21:58 --> Input Class Initialized
INFO - 2017-03-03 17:21:58 --> Language Class Initialized
INFO - 2017-03-03 17:21:58 --> Language Class Initialized
INFO - 2017-03-03 17:21:58 --> Config Class Initialized
INFO - 2017-03-03 17:21:58 --> Loader Class Initialized
INFO - 2017-03-03 17:21:58 --> Helper loaded: form_helper
INFO - 2017-03-03 17:21:58 --> Helper loaded: url_helper
INFO - 2017-03-03 17:21:58 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:21:58 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:21:58 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:21:58 --> Template Class Initialized
INFO - 2017-03-03 17:21:58 --> Model Class Initialized
INFO - 2017-03-03 17:21:58 --> Controller Class Initialized
DEBUG - 2017-03-03 17:21:58 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:21:58 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:21:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:21:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:22:02 --> Config Class Initialized
INFO - 2017-03-03 17:22:02 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:22:02 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:22:02 --> Utf8 Class Initialized
INFO - 2017-03-03 17:22:02 --> URI Class Initialized
INFO - 2017-03-03 17:22:02 --> Router Class Initialized
INFO - 2017-03-03 17:22:02 --> Output Class Initialized
INFO - 2017-03-03 17:22:02 --> Security Class Initialized
DEBUG - 2017-03-03 17:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:22:02 --> Input Class Initialized
INFO - 2017-03-03 17:22:02 --> Language Class Initialized
INFO - 2017-03-03 17:22:02 --> Language Class Initialized
INFO - 2017-03-03 17:22:02 --> Config Class Initialized
INFO - 2017-03-03 17:22:02 --> Loader Class Initialized
INFO - 2017-03-03 17:22:02 --> Helper loaded: form_helper
INFO - 2017-03-03 17:22:02 --> Helper loaded: url_helper
INFO - 2017-03-03 17:22:02 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:22:02 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:22:02 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:22:02 --> Template Class Initialized
INFO - 2017-03-03 17:22:02 --> Model Class Initialized
INFO - 2017-03-03 17:22:02 --> Controller Class Initialized
DEBUG - 2017-03-03 17:22:02 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:22:02 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:22:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:22:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:22:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:22:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 17:22:02 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:22:02 --> Final output sent to browser
DEBUG - 2017-03-03 17:22:02 --> Total execution time: 0.0134
INFO - 2017-03-03 17:22:03 --> Config Class Initialized
INFO - 2017-03-03 17:22:03 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:22:03 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:22:03 --> Utf8 Class Initialized
INFO - 2017-03-03 17:22:03 --> URI Class Initialized
INFO - 2017-03-03 17:22:03 --> Router Class Initialized
INFO - 2017-03-03 17:22:03 --> Output Class Initialized
INFO - 2017-03-03 17:22:03 --> Security Class Initialized
DEBUG - 2017-03-03 17:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:22:03 --> Input Class Initialized
INFO - 2017-03-03 17:22:03 --> Language Class Initialized
INFO - 2017-03-03 17:22:03 --> Language Class Initialized
INFO - 2017-03-03 17:22:03 --> Config Class Initialized
INFO - 2017-03-03 17:22:03 --> Loader Class Initialized
INFO - 2017-03-03 17:22:03 --> Helper loaded: form_helper
INFO - 2017-03-03 17:22:03 --> Helper loaded: url_helper
INFO - 2017-03-03 17:22:03 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:22:03 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:22:03 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:22:03 --> Template Class Initialized
INFO - 2017-03-03 17:22:03 --> Model Class Initialized
INFO - 2017-03-03 17:22:03 --> Controller Class Initialized
DEBUG - 2017-03-03 17:22:03 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:22:03 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:22:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:22:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:22:10 --> Config Class Initialized
INFO - 2017-03-03 17:22:10 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:22:10 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:22:10 --> Utf8 Class Initialized
INFO - 2017-03-03 17:22:10 --> URI Class Initialized
INFO - 2017-03-03 17:22:10 --> Router Class Initialized
INFO - 2017-03-03 17:22:10 --> Output Class Initialized
INFO - 2017-03-03 17:22:10 --> Security Class Initialized
DEBUG - 2017-03-03 17:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:22:10 --> Input Class Initialized
INFO - 2017-03-03 17:22:10 --> Language Class Initialized
INFO - 2017-03-03 17:22:10 --> Language Class Initialized
INFO - 2017-03-03 17:22:10 --> Config Class Initialized
INFO - 2017-03-03 17:22:10 --> Loader Class Initialized
INFO - 2017-03-03 17:22:10 --> Helper loaded: form_helper
INFO - 2017-03-03 17:22:10 --> Helper loaded: url_helper
INFO - 2017-03-03 17:22:10 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:22:10 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:22:10 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:22:10 --> Template Class Initialized
INFO - 2017-03-03 17:22:10 --> Model Class Initialized
INFO - 2017-03-03 17:22:10 --> Controller Class Initialized
DEBUG - 2017-03-03 17:22:10 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:22:10 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:22:10 --> Model Class Initialized
INFO - 2017-03-03 17:22:10 --> Config Class Initialized
INFO - 2017-03-03 17:22:10 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:22:10 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:22:10 --> Utf8 Class Initialized
INFO - 2017-03-03 17:22:10 --> URI Class Initialized
INFO - 2017-03-03 17:22:10 --> Router Class Initialized
INFO - 2017-03-03 17:22:10 --> Output Class Initialized
INFO - 2017-03-03 17:22:10 --> Security Class Initialized
DEBUG - 2017-03-03 17:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:22:10 --> Input Class Initialized
INFO - 2017-03-03 17:22:10 --> Language Class Initialized
INFO - 2017-03-03 17:22:10 --> Language Class Initialized
INFO - 2017-03-03 17:22:10 --> Config Class Initialized
INFO - 2017-03-03 17:22:10 --> Loader Class Initialized
INFO - 2017-03-03 17:22:10 --> Helper loaded: form_helper
INFO - 2017-03-03 17:22:10 --> Helper loaded: url_helper
INFO - 2017-03-03 17:22:10 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:22:10 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:22:10 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:22:10 --> Template Class Initialized
INFO - 2017-03-03 17:22:10 --> Model Class Initialized
INFO - 2017-03-03 17:22:10 --> Controller Class Initialized
DEBUG - 2017-03-03 17:22:10 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:22:10 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:22:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:22:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:22:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:22:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 17:22:10 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:22:10 --> Final output sent to browser
DEBUG - 2017-03-03 17:22:10 --> Total execution time: 0.0133
INFO - 2017-03-03 17:22:10 --> Config Class Initialized
INFO - 2017-03-03 17:22:10 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:22:10 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:22:10 --> Utf8 Class Initialized
INFO - 2017-03-03 17:22:10 --> URI Class Initialized
INFO - 2017-03-03 17:22:10 --> Router Class Initialized
INFO - 2017-03-03 17:22:10 --> Output Class Initialized
INFO - 2017-03-03 17:22:10 --> Security Class Initialized
DEBUG - 2017-03-03 17:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:22:10 --> Input Class Initialized
INFO - 2017-03-03 17:22:10 --> Language Class Initialized
INFO - 2017-03-03 17:22:10 --> Language Class Initialized
INFO - 2017-03-03 17:22:10 --> Config Class Initialized
INFO - 2017-03-03 17:22:10 --> Loader Class Initialized
INFO - 2017-03-03 17:22:10 --> Helper loaded: form_helper
INFO - 2017-03-03 17:22:10 --> Helper loaded: url_helper
INFO - 2017-03-03 17:22:10 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:22:10 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:22:10 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:22:10 --> Template Class Initialized
INFO - 2017-03-03 17:22:10 --> Model Class Initialized
INFO - 2017-03-03 17:22:10 --> Controller Class Initialized
DEBUG - 2017-03-03 17:22:10 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:22:10 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:22:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:22:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:22:12 --> Config Class Initialized
INFO - 2017-03-03 17:22:12 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:22:12 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:22:12 --> Utf8 Class Initialized
INFO - 2017-03-03 17:22:12 --> URI Class Initialized
INFO - 2017-03-03 17:22:12 --> Router Class Initialized
INFO - 2017-03-03 17:22:12 --> Output Class Initialized
INFO - 2017-03-03 17:22:12 --> Security Class Initialized
DEBUG - 2017-03-03 17:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:22:12 --> Input Class Initialized
INFO - 2017-03-03 17:22:12 --> Language Class Initialized
INFO - 2017-03-03 17:22:12 --> Language Class Initialized
INFO - 2017-03-03 17:22:12 --> Config Class Initialized
INFO - 2017-03-03 17:22:12 --> Loader Class Initialized
INFO - 2017-03-03 17:22:12 --> Helper loaded: form_helper
INFO - 2017-03-03 17:22:12 --> Helper loaded: url_helper
INFO - 2017-03-03 17:22:12 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:22:12 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:22:12 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:22:12 --> Template Class Initialized
INFO - 2017-03-03 17:22:12 --> Model Class Initialized
INFO - 2017-03-03 17:22:12 --> Controller Class Initialized
DEBUG - 2017-03-03 17:22:12 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:22:12 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:22:12 --> Model Class Initialized
DEBUG - 2017-03-03 17:22:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:22:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:22:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:22:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/project_list.php
DEBUG - 2017-03-03 17:22:12 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:22:12 --> Final output sent to browser
DEBUG - 2017-03-03 17:22:12 --> Total execution time: 0.0191
INFO - 2017-03-03 17:22:13 --> Config Class Initialized
INFO - 2017-03-03 17:22:13 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:22:13 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:22:13 --> Utf8 Class Initialized
INFO - 2017-03-03 17:22:13 --> URI Class Initialized
INFO - 2017-03-03 17:22:13 --> Router Class Initialized
INFO - 2017-03-03 17:22:13 --> Output Class Initialized
INFO - 2017-03-03 17:22:13 --> Security Class Initialized
DEBUG - 2017-03-03 17:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:22:13 --> Input Class Initialized
INFO - 2017-03-03 17:22:13 --> Language Class Initialized
INFO - 2017-03-03 17:22:13 --> Language Class Initialized
INFO - 2017-03-03 17:22:13 --> Config Class Initialized
INFO - 2017-03-03 17:22:13 --> Loader Class Initialized
INFO - 2017-03-03 17:22:13 --> Helper loaded: form_helper
INFO - 2017-03-03 17:22:13 --> Helper loaded: url_helper
INFO - 2017-03-03 17:22:13 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:22:13 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:22:13 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:22:13 --> Template Class Initialized
INFO - 2017-03-03 17:22:13 --> Model Class Initialized
INFO - 2017-03-03 17:22:13 --> Controller Class Initialized
DEBUG - 2017-03-03 17:22:13 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:22:13 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:22:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:22:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:22:19 --> Config Class Initialized
INFO - 2017-03-03 17:22:19 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:22:19 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:22:19 --> Utf8 Class Initialized
INFO - 2017-03-03 17:22:19 --> URI Class Initialized
INFO - 2017-03-03 17:22:19 --> Router Class Initialized
INFO - 2017-03-03 17:22:19 --> Output Class Initialized
INFO - 2017-03-03 17:22:19 --> Security Class Initialized
DEBUG - 2017-03-03 17:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:22:19 --> Input Class Initialized
INFO - 2017-03-03 17:22:19 --> Language Class Initialized
INFO - 2017-03-03 17:22:19 --> Language Class Initialized
INFO - 2017-03-03 17:22:19 --> Config Class Initialized
INFO - 2017-03-03 17:22:19 --> Loader Class Initialized
INFO - 2017-03-03 17:22:19 --> Helper loaded: form_helper
INFO - 2017-03-03 17:22:19 --> Helper loaded: url_helper
INFO - 2017-03-03 17:22:19 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:22:19 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:22:19 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:22:19 --> Template Class Initialized
INFO - 2017-03-03 17:22:19 --> Model Class Initialized
INFO - 2017-03-03 17:22:19 --> Controller Class Initialized
DEBUG - 2017-03-03 17:22:19 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:22:19 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:22:19 --> Model Class Initialized
DEBUG - 2017-03-03 17:22:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:22:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:22:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:22:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:22:19 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:22:19 --> Final output sent to browser
DEBUG - 2017-03-03 17:22:19 --> Total execution time: 0.0174
INFO - 2017-03-03 17:22:19 --> Config Class Initialized
INFO - 2017-03-03 17:22:19 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:22:19 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:22:19 --> Utf8 Class Initialized
INFO - 2017-03-03 17:22:19 --> URI Class Initialized
INFO - 2017-03-03 17:22:19 --> Router Class Initialized
INFO - 2017-03-03 17:22:19 --> Output Class Initialized
INFO - 2017-03-03 17:22:19 --> Security Class Initialized
DEBUG - 2017-03-03 17:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:22:19 --> Input Class Initialized
INFO - 2017-03-03 17:22:19 --> Language Class Initialized
INFO - 2017-03-03 17:22:19 --> Language Class Initialized
INFO - 2017-03-03 17:22:19 --> Config Class Initialized
INFO - 2017-03-03 17:22:19 --> Loader Class Initialized
INFO - 2017-03-03 17:22:19 --> Helper loaded: form_helper
INFO - 2017-03-03 17:22:19 --> Helper loaded: url_helper
INFO - 2017-03-03 17:22:19 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:22:19 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:22:19 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:22:19 --> Template Class Initialized
INFO - 2017-03-03 17:22:19 --> Model Class Initialized
INFO - 2017-03-03 17:22:19 --> Controller Class Initialized
DEBUG - 2017-03-03 17:22:19 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:22:19 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:22:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:22:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:22:25 --> Config Class Initialized
INFO - 2017-03-03 17:22:25 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:22:25 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:22:25 --> Utf8 Class Initialized
INFO - 2017-03-03 17:22:25 --> URI Class Initialized
INFO - 2017-03-03 17:22:25 --> Router Class Initialized
INFO - 2017-03-03 17:22:25 --> Output Class Initialized
INFO - 2017-03-03 17:22:25 --> Security Class Initialized
DEBUG - 2017-03-03 17:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:22:25 --> Input Class Initialized
INFO - 2017-03-03 17:22:25 --> Language Class Initialized
INFO - 2017-03-03 17:22:25 --> Language Class Initialized
INFO - 2017-03-03 17:22:25 --> Config Class Initialized
INFO - 2017-03-03 17:22:25 --> Loader Class Initialized
INFO - 2017-03-03 17:22:25 --> Helper loaded: form_helper
INFO - 2017-03-03 17:22:25 --> Helper loaded: url_helper
INFO - 2017-03-03 17:22:25 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:22:25 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:22:25 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:22:25 --> Template Class Initialized
INFO - 2017-03-03 17:22:25 --> Model Class Initialized
INFO - 2017-03-03 17:22:25 --> Controller Class Initialized
DEBUG - 2017-03-03 17:22:25 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:22:25 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:22:25 --> Final output sent to browser
DEBUG - 2017-03-03 17:22:25 --> Total execution time: 0.0122
INFO - 2017-03-03 17:22:50 --> Config Class Initialized
INFO - 2017-03-03 17:22:50 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:22:50 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:22:50 --> Utf8 Class Initialized
INFO - 2017-03-03 17:22:50 --> URI Class Initialized
INFO - 2017-03-03 17:22:50 --> Router Class Initialized
INFO - 2017-03-03 17:22:50 --> Output Class Initialized
INFO - 2017-03-03 17:22:50 --> Security Class Initialized
DEBUG - 2017-03-03 17:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:22:50 --> Input Class Initialized
INFO - 2017-03-03 17:22:50 --> Language Class Initialized
INFO - 2017-03-03 17:22:50 --> Language Class Initialized
INFO - 2017-03-03 17:22:50 --> Config Class Initialized
INFO - 2017-03-03 17:22:50 --> Loader Class Initialized
INFO - 2017-03-03 17:22:50 --> Helper loaded: form_helper
INFO - 2017-03-03 17:22:50 --> Helper loaded: url_helper
INFO - 2017-03-03 17:22:50 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:22:50 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:22:50 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:22:50 --> Template Class Initialized
INFO - 2017-03-03 17:22:50 --> Model Class Initialized
INFO - 2017-03-03 17:22:50 --> Controller Class Initialized
DEBUG - 2017-03-03 17:22:50 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:22:50 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:22:50 --> Upload Class Initialized
INFO - 2017-03-03 17:22:50 --> Model Class Initialized
INFO - 2017-03-03 17:22:50 --> Final output sent to browser
DEBUG - 2017-03-03 17:22:50 --> Total execution time: 0.0176
INFO - 2017-03-03 17:23:17 --> Config Class Initialized
INFO - 2017-03-03 17:23:17 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:23:17 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:23:17 --> Utf8 Class Initialized
INFO - 2017-03-03 17:23:17 --> URI Class Initialized
INFO - 2017-03-03 17:23:17 --> Router Class Initialized
INFO - 2017-03-03 17:23:17 --> Output Class Initialized
INFO - 2017-03-03 17:23:17 --> Security Class Initialized
DEBUG - 2017-03-03 17:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:23:17 --> Input Class Initialized
INFO - 2017-03-03 17:23:17 --> Language Class Initialized
INFO - 2017-03-03 17:23:17 --> Language Class Initialized
INFO - 2017-03-03 17:23:17 --> Config Class Initialized
INFO - 2017-03-03 17:23:17 --> Loader Class Initialized
INFO - 2017-03-03 17:23:17 --> Helper loaded: form_helper
INFO - 2017-03-03 17:23:17 --> Helper loaded: url_helper
INFO - 2017-03-03 17:23:17 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:23:17 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:23:17 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:23:17 --> Template Class Initialized
INFO - 2017-03-03 17:23:17 --> Model Class Initialized
INFO - 2017-03-03 17:23:17 --> Controller Class Initialized
DEBUG - 2017-03-03 17:23:17 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:23:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:23:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:23:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:23:23 --> Config Class Initialized
INFO - 2017-03-03 17:23:23 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:23:23 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:23:23 --> Utf8 Class Initialized
INFO - 2017-03-03 17:23:23 --> URI Class Initialized
INFO - 2017-03-03 17:23:23 --> Router Class Initialized
INFO - 2017-03-03 17:23:23 --> Output Class Initialized
INFO - 2017-03-03 17:23:23 --> Security Class Initialized
DEBUG - 2017-03-03 17:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:23:23 --> Input Class Initialized
INFO - 2017-03-03 17:23:23 --> Language Class Initialized
INFO - 2017-03-03 17:23:23 --> Language Class Initialized
INFO - 2017-03-03 17:23:23 --> Config Class Initialized
INFO - 2017-03-03 17:23:23 --> Loader Class Initialized
INFO - 2017-03-03 17:23:23 --> Helper loaded: form_helper
INFO - 2017-03-03 17:23:23 --> Helper loaded: url_helper
INFO - 2017-03-03 17:23:23 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:23:23 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:23:23 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:23:23 --> Template Class Initialized
INFO - 2017-03-03 17:23:23 --> Model Class Initialized
INFO - 2017-03-03 17:23:23 --> Controller Class Initialized
DEBUG - 2017-03-03 17:23:23 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:23:23 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:23:23 --> Model Class Initialized
DEBUG - 2017-03-03 17:23:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:23:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:23:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:23:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:23:23 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:23:23 --> Final output sent to browser
DEBUG - 2017-03-03 17:23:23 --> Total execution time: 0.0107
INFO - 2017-03-03 17:23:23 --> Config Class Initialized
INFO - 2017-03-03 17:23:23 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:23:23 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:23:23 --> Utf8 Class Initialized
INFO - 2017-03-03 17:23:23 --> URI Class Initialized
INFO - 2017-03-03 17:23:23 --> Router Class Initialized
INFO - 2017-03-03 17:23:23 --> Output Class Initialized
INFO - 2017-03-03 17:23:23 --> Security Class Initialized
DEBUG - 2017-03-03 17:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:23:23 --> Input Class Initialized
INFO - 2017-03-03 17:23:23 --> Language Class Initialized
INFO - 2017-03-03 17:23:23 --> Language Class Initialized
INFO - 2017-03-03 17:23:23 --> Config Class Initialized
INFO - 2017-03-03 17:23:23 --> Loader Class Initialized
INFO - 2017-03-03 17:23:23 --> Helper loaded: form_helper
INFO - 2017-03-03 17:23:23 --> Helper loaded: url_helper
INFO - 2017-03-03 17:23:23 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:23:23 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:23:23 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:23:23 --> Template Class Initialized
INFO - 2017-03-03 17:23:23 --> Model Class Initialized
INFO - 2017-03-03 17:23:23 --> Controller Class Initialized
DEBUG - 2017-03-03 17:23:23 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:23:23 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:23:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:23:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:23:28 --> Config Class Initialized
INFO - 2017-03-03 17:23:28 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:23:28 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:23:28 --> Utf8 Class Initialized
INFO - 2017-03-03 17:23:28 --> URI Class Initialized
INFO - 2017-03-03 17:23:28 --> Router Class Initialized
INFO - 2017-03-03 17:23:28 --> Output Class Initialized
INFO - 2017-03-03 17:23:28 --> Security Class Initialized
DEBUG - 2017-03-03 17:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:23:28 --> Input Class Initialized
INFO - 2017-03-03 17:23:28 --> Language Class Initialized
INFO - 2017-03-03 17:23:28 --> Language Class Initialized
INFO - 2017-03-03 17:23:28 --> Config Class Initialized
INFO - 2017-03-03 17:23:28 --> Loader Class Initialized
INFO - 2017-03-03 17:23:28 --> Helper loaded: form_helper
INFO - 2017-03-03 17:23:28 --> Helper loaded: url_helper
INFO - 2017-03-03 17:23:28 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:23:28 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:23:28 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:23:28 --> Template Class Initialized
INFO - 2017-03-03 17:23:28 --> Model Class Initialized
INFO - 2017-03-03 17:23:28 --> Controller Class Initialized
DEBUG - 2017-03-03 17:23:28 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:23:28 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:23:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:23:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:23:32 --> Config Class Initialized
INFO - 2017-03-03 17:23:32 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:23:32 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:23:32 --> Utf8 Class Initialized
INFO - 2017-03-03 17:23:32 --> URI Class Initialized
INFO - 2017-03-03 17:23:32 --> Router Class Initialized
INFO - 2017-03-03 17:23:32 --> Output Class Initialized
INFO - 2017-03-03 17:23:32 --> Security Class Initialized
DEBUG - 2017-03-03 17:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:23:32 --> Input Class Initialized
INFO - 2017-03-03 17:23:32 --> Language Class Initialized
INFO - 2017-03-03 17:23:32 --> Language Class Initialized
INFO - 2017-03-03 17:23:32 --> Config Class Initialized
INFO - 2017-03-03 17:23:32 --> Loader Class Initialized
INFO - 2017-03-03 17:23:32 --> Helper loaded: form_helper
INFO - 2017-03-03 17:23:32 --> Helper loaded: url_helper
INFO - 2017-03-03 17:23:32 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:23:32 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:23:32 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:23:32 --> Template Class Initialized
INFO - 2017-03-03 17:23:32 --> Model Class Initialized
INFO - 2017-03-03 17:23:32 --> Controller Class Initialized
DEBUG - 2017-03-03 17:23:32 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:23:32 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:23:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:23:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:23:33 --> Config Class Initialized
INFO - 2017-03-03 17:23:33 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:23:33 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:23:33 --> Utf8 Class Initialized
INFO - 2017-03-03 17:23:33 --> URI Class Initialized
INFO - 2017-03-03 17:23:33 --> Router Class Initialized
INFO - 2017-03-03 17:23:33 --> Output Class Initialized
INFO - 2017-03-03 17:23:33 --> Security Class Initialized
DEBUG - 2017-03-03 17:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:23:33 --> Input Class Initialized
INFO - 2017-03-03 17:23:33 --> Language Class Initialized
INFO - 2017-03-03 17:23:33 --> Language Class Initialized
INFO - 2017-03-03 17:23:33 --> Config Class Initialized
INFO - 2017-03-03 17:23:33 --> Loader Class Initialized
INFO - 2017-03-03 17:23:33 --> Helper loaded: form_helper
INFO - 2017-03-03 17:23:33 --> Helper loaded: url_helper
INFO - 2017-03-03 17:23:33 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:23:33 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:23:33 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:23:33 --> Template Class Initialized
INFO - 2017-03-03 17:23:33 --> Model Class Initialized
INFO - 2017-03-03 17:23:33 --> Controller Class Initialized
DEBUG - 2017-03-03 17:23:33 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:23:33 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:23:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:23:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:23:36 --> Config Class Initialized
INFO - 2017-03-03 17:23:36 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:23:36 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:23:36 --> Utf8 Class Initialized
INFO - 2017-03-03 17:23:36 --> URI Class Initialized
INFO - 2017-03-03 17:23:36 --> Router Class Initialized
INFO - 2017-03-03 17:23:36 --> Output Class Initialized
INFO - 2017-03-03 17:23:36 --> Security Class Initialized
DEBUG - 2017-03-03 17:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:23:36 --> Input Class Initialized
INFO - 2017-03-03 17:23:36 --> Language Class Initialized
INFO - 2017-03-03 17:23:36 --> Language Class Initialized
INFO - 2017-03-03 17:23:36 --> Config Class Initialized
INFO - 2017-03-03 17:23:36 --> Loader Class Initialized
INFO - 2017-03-03 17:23:36 --> Helper loaded: form_helper
INFO - 2017-03-03 17:23:36 --> Helper loaded: url_helper
INFO - 2017-03-03 17:23:36 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:23:36 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:23:36 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:23:36 --> Template Class Initialized
INFO - 2017-03-03 17:23:36 --> Model Class Initialized
INFO - 2017-03-03 17:23:36 --> Controller Class Initialized
DEBUG - 2017-03-03 17:23:36 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:23:36 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:23:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:23:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:23:39 --> Config Class Initialized
INFO - 2017-03-03 17:23:39 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:23:39 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:23:39 --> Utf8 Class Initialized
INFO - 2017-03-03 17:23:39 --> URI Class Initialized
INFO - 2017-03-03 17:23:39 --> Router Class Initialized
INFO - 2017-03-03 17:23:39 --> Output Class Initialized
INFO - 2017-03-03 17:23:39 --> Security Class Initialized
DEBUG - 2017-03-03 17:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:23:39 --> Input Class Initialized
INFO - 2017-03-03 17:23:39 --> Language Class Initialized
INFO - 2017-03-03 17:23:39 --> Language Class Initialized
INFO - 2017-03-03 17:23:39 --> Config Class Initialized
INFO - 2017-03-03 17:23:39 --> Loader Class Initialized
INFO - 2017-03-03 17:23:39 --> Helper loaded: form_helper
INFO - 2017-03-03 17:23:39 --> Helper loaded: url_helper
INFO - 2017-03-03 17:23:39 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:23:39 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:23:39 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:23:39 --> Template Class Initialized
INFO - 2017-03-03 17:23:39 --> Model Class Initialized
INFO - 2017-03-03 17:23:39 --> Controller Class Initialized
DEBUG - 2017-03-03 17:23:39 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:23:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:23:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:23:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:23:42 --> Config Class Initialized
INFO - 2017-03-03 17:23:42 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:23:42 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:23:42 --> Utf8 Class Initialized
INFO - 2017-03-03 17:23:42 --> URI Class Initialized
INFO - 2017-03-03 17:23:42 --> Router Class Initialized
INFO - 2017-03-03 17:23:42 --> Output Class Initialized
INFO - 2017-03-03 17:23:42 --> Security Class Initialized
DEBUG - 2017-03-03 17:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:23:42 --> Input Class Initialized
INFO - 2017-03-03 17:23:42 --> Language Class Initialized
INFO - 2017-03-03 17:23:42 --> Language Class Initialized
INFO - 2017-03-03 17:23:42 --> Config Class Initialized
INFO - 2017-03-03 17:23:42 --> Loader Class Initialized
INFO - 2017-03-03 17:23:42 --> Helper loaded: form_helper
INFO - 2017-03-03 17:23:42 --> Helper loaded: url_helper
INFO - 2017-03-03 17:23:42 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:23:42 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:23:42 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:23:42 --> Template Class Initialized
INFO - 2017-03-03 17:23:42 --> Model Class Initialized
INFO - 2017-03-03 17:23:42 --> Controller Class Initialized
DEBUG - 2017-03-03 17:23:42 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:23:42 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:23:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:23:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:24:01 --> Config Class Initialized
INFO - 2017-03-03 17:24:01 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:24:01 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:24:01 --> Utf8 Class Initialized
INFO - 2017-03-03 17:24:01 --> URI Class Initialized
INFO - 2017-03-03 17:24:01 --> Router Class Initialized
INFO - 2017-03-03 17:24:01 --> Output Class Initialized
INFO - 2017-03-03 17:24:01 --> Security Class Initialized
DEBUG - 2017-03-03 17:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:24:01 --> Input Class Initialized
INFO - 2017-03-03 17:24:01 --> Language Class Initialized
INFO - 2017-03-03 17:24:01 --> Language Class Initialized
INFO - 2017-03-03 17:24:01 --> Config Class Initialized
INFO - 2017-03-03 17:24:01 --> Loader Class Initialized
INFO - 2017-03-03 17:24:01 --> Helper loaded: form_helper
INFO - 2017-03-03 17:24:01 --> Helper loaded: url_helper
INFO - 2017-03-03 17:24:01 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:24:01 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:24:01 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:24:01 --> Template Class Initialized
INFO - 2017-03-03 17:24:01 --> Model Class Initialized
INFO - 2017-03-03 17:24:01 --> Controller Class Initialized
DEBUG - 2017-03-03 17:24:01 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:24:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:24:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:24:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:24:37 --> Config Class Initialized
INFO - 2017-03-03 17:24:37 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:24:37 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:24:37 --> Utf8 Class Initialized
INFO - 2017-03-03 17:24:37 --> URI Class Initialized
DEBUG - 2017-03-03 17:24:37 --> No URI present. Default controller set.
INFO - 2017-03-03 17:24:37 --> Router Class Initialized
INFO - 2017-03-03 17:24:37 --> Output Class Initialized
INFO - 2017-03-03 17:24:37 --> Security Class Initialized
DEBUG - 2017-03-03 17:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:24:37 --> Input Class Initialized
INFO - 2017-03-03 17:24:37 --> Language Class Initialized
INFO - 2017-03-03 17:24:37 --> Language Class Initialized
INFO - 2017-03-03 17:24:37 --> Config Class Initialized
INFO - 2017-03-03 17:24:37 --> Loader Class Initialized
INFO - 2017-03-03 17:24:37 --> Helper loaded: form_helper
INFO - 2017-03-03 17:24:37 --> Helper loaded: url_helper
INFO - 2017-03-03 17:24:37 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:24:37 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:24:37 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:24:37 --> Template Class Initialized
INFO - 2017-03-03 17:24:37 --> Model Class Initialized
INFO - 2017-03-03 17:24:37 --> Controller Class Initialized
DEBUG - 2017-03-03 17:24:37 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:24:37 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:24:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:24:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 17:24:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-03 17:24:37 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 17:24:37 --> Final output sent to browser
DEBUG - 2017-03-03 17:24:37 --> Total execution time: 0.0140
INFO - 2017-03-03 17:24:38 --> Config Class Initialized
INFO - 2017-03-03 17:24:38 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:24:38 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:24:38 --> Utf8 Class Initialized
INFO - 2017-03-03 17:24:38 --> URI Class Initialized
INFO - 2017-03-03 17:24:38 --> Router Class Initialized
INFO - 2017-03-03 17:24:38 --> Output Class Initialized
INFO - 2017-03-03 17:24:38 --> Security Class Initialized
DEBUG - 2017-03-03 17:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:24:38 --> Input Class Initialized
INFO - 2017-03-03 17:24:38 --> Language Class Initialized
INFO - 2017-03-03 17:24:38 --> Language Class Initialized
INFO - 2017-03-03 17:24:38 --> Config Class Initialized
INFO - 2017-03-03 17:24:38 --> Loader Class Initialized
INFO - 2017-03-03 17:24:38 --> Helper loaded: form_helper
INFO - 2017-03-03 17:24:38 --> Helper loaded: url_helper
INFO - 2017-03-03 17:24:38 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:24:38 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:24:38 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:24:38 --> Template Class Initialized
INFO - 2017-03-03 17:24:38 --> Model Class Initialized
INFO - 2017-03-03 17:24:38 --> Controller Class Initialized
DEBUG - 2017-03-03 17:24:38 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:24:38 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:24:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:24:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:24:38 --> Config Class Initialized
INFO - 2017-03-03 17:24:38 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:24:38 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:24:38 --> Utf8 Class Initialized
INFO - 2017-03-03 17:24:38 --> URI Class Initialized
INFO - 2017-03-03 17:24:38 --> Router Class Initialized
INFO - 2017-03-03 17:24:38 --> Output Class Initialized
INFO - 2017-03-03 17:24:38 --> Security Class Initialized
DEBUG - 2017-03-03 17:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:24:38 --> Input Class Initialized
INFO - 2017-03-03 17:24:38 --> Language Class Initialized
INFO - 2017-03-03 17:24:38 --> Language Class Initialized
INFO - 2017-03-03 17:24:38 --> Config Class Initialized
INFO - 2017-03-03 17:24:38 --> Loader Class Initialized
INFO - 2017-03-03 17:24:38 --> Helper loaded: form_helper
INFO - 2017-03-03 17:24:38 --> Helper loaded: url_helper
INFO - 2017-03-03 17:24:38 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:24:38 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:24:38 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:24:38 --> Template Class Initialized
INFO - 2017-03-03 17:24:38 --> Model Class Initialized
INFO - 2017-03-03 17:24:38 --> Controller Class Initialized
DEBUG - 2017-03-03 17:24:38 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:24:38 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:24:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:24:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 17:24:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-03-03 17:24:38 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 17:24:38 --> Final output sent to browser
DEBUG - 2017-03-03 17:24:38 --> Total execution time: 0.0255
INFO - 2017-03-03 17:24:43 --> Config Class Initialized
INFO - 2017-03-03 17:24:43 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:24:43 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:24:43 --> Utf8 Class Initialized
INFO - 2017-03-03 17:24:43 --> URI Class Initialized
INFO - 2017-03-03 17:24:43 --> Router Class Initialized
INFO - 2017-03-03 17:24:43 --> Output Class Initialized
INFO - 2017-03-03 17:24:43 --> Security Class Initialized
DEBUG - 2017-03-03 17:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:24:43 --> Input Class Initialized
INFO - 2017-03-03 17:24:43 --> Language Class Initialized
INFO - 2017-03-03 17:24:43 --> Language Class Initialized
INFO - 2017-03-03 17:24:43 --> Config Class Initialized
INFO - 2017-03-03 17:24:43 --> Loader Class Initialized
INFO - 2017-03-03 17:24:43 --> Helper loaded: form_helper
INFO - 2017-03-03 17:24:43 --> Helper loaded: url_helper
INFO - 2017-03-03 17:24:43 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:24:43 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:24:43 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:24:43 --> Template Class Initialized
INFO - 2017-03-03 17:24:43 --> Model Class Initialized
INFO - 2017-03-03 17:24:43 --> Controller Class Initialized
DEBUG - 2017-03-03 17:24:43 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:24:43 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:24:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:24:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:24:44 --> Config Class Initialized
INFO - 2017-03-03 17:24:44 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:24:44 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:24:44 --> Utf8 Class Initialized
INFO - 2017-03-03 17:24:44 --> URI Class Initialized
INFO - 2017-03-03 17:24:44 --> Router Class Initialized
INFO - 2017-03-03 17:24:44 --> Output Class Initialized
INFO - 2017-03-03 17:24:44 --> Security Class Initialized
DEBUG - 2017-03-03 17:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:24:44 --> Input Class Initialized
INFO - 2017-03-03 17:24:44 --> Language Class Initialized
INFO - 2017-03-03 17:24:44 --> Language Class Initialized
INFO - 2017-03-03 17:24:44 --> Config Class Initialized
INFO - 2017-03-03 17:24:44 --> Loader Class Initialized
INFO - 2017-03-03 17:24:44 --> Helper loaded: form_helper
INFO - 2017-03-03 17:24:44 --> Helper loaded: url_helper
INFO - 2017-03-03 17:24:44 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:24:44 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:24:44 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:24:44 --> Template Class Initialized
INFO - 2017-03-03 17:24:44 --> Model Class Initialized
INFO - 2017-03-03 17:24:44 --> Controller Class Initialized
DEBUG - 2017-03-03 17:24:44 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:24:44 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:24:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:24:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:25:57 --> Config Class Initialized
INFO - 2017-03-03 17:25:57 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:25:57 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:25:57 --> Utf8 Class Initialized
INFO - 2017-03-03 17:25:57 --> URI Class Initialized
INFO - 2017-03-03 17:25:57 --> Router Class Initialized
INFO - 2017-03-03 17:25:57 --> Output Class Initialized
INFO - 2017-03-03 17:25:57 --> Security Class Initialized
DEBUG - 2017-03-03 17:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:25:57 --> Input Class Initialized
INFO - 2017-03-03 17:25:57 --> Language Class Initialized
INFO - 2017-03-03 17:25:57 --> Language Class Initialized
INFO - 2017-03-03 17:25:57 --> Config Class Initialized
INFO - 2017-03-03 17:25:57 --> Loader Class Initialized
INFO - 2017-03-03 17:25:57 --> Helper loaded: form_helper
INFO - 2017-03-03 17:25:57 --> Helper loaded: url_helper
INFO - 2017-03-03 17:25:57 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:25:57 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:25:57 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:25:57 --> Template Class Initialized
INFO - 2017-03-03 17:25:57 --> Model Class Initialized
INFO - 2017-03-03 17:25:57 --> Controller Class Initialized
DEBUG - 2017-03-03 17:25:57 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:25:57 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:25:57 --> Model Class Initialized
DEBUG - 2017-03-03 17:25:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:25:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:25:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:25:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:25:57 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:25:57 --> Final output sent to browser
DEBUG - 2017-03-03 17:25:57 --> Total execution time: 0.0202
INFO - 2017-03-03 17:25:58 --> Config Class Initialized
INFO - 2017-03-03 17:25:58 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:25:58 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:25:58 --> Utf8 Class Initialized
INFO - 2017-03-03 17:25:58 --> URI Class Initialized
INFO - 2017-03-03 17:25:58 --> Router Class Initialized
INFO - 2017-03-03 17:25:58 --> Output Class Initialized
INFO - 2017-03-03 17:25:58 --> Security Class Initialized
DEBUG - 2017-03-03 17:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:25:58 --> Input Class Initialized
INFO - 2017-03-03 17:25:58 --> Language Class Initialized
INFO - 2017-03-03 17:25:58 --> Language Class Initialized
INFO - 2017-03-03 17:25:58 --> Config Class Initialized
INFO - 2017-03-03 17:25:58 --> Loader Class Initialized
INFO - 2017-03-03 17:25:58 --> Helper loaded: form_helper
INFO - 2017-03-03 17:25:58 --> Helper loaded: url_helper
INFO - 2017-03-03 17:25:58 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:25:58 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:25:58 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:25:58 --> Template Class Initialized
INFO - 2017-03-03 17:25:58 --> Model Class Initialized
INFO - 2017-03-03 17:25:58 --> Controller Class Initialized
DEBUG - 2017-03-03 17:25:58 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:25:58 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:25:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:25:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:26:03 --> Config Class Initialized
INFO - 2017-03-03 17:26:03 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:26:03 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:26:03 --> Utf8 Class Initialized
INFO - 2017-03-03 17:26:03 --> URI Class Initialized
INFO - 2017-03-03 17:26:03 --> Router Class Initialized
INFO - 2017-03-03 17:26:03 --> Output Class Initialized
INFO - 2017-03-03 17:26:03 --> Security Class Initialized
DEBUG - 2017-03-03 17:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:26:03 --> Input Class Initialized
INFO - 2017-03-03 17:26:03 --> Language Class Initialized
INFO - 2017-03-03 17:26:03 --> Language Class Initialized
INFO - 2017-03-03 17:26:03 --> Config Class Initialized
INFO - 2017-03-03 17:26:03 --> Loader Class Initialized
INFO - 2017-03-03 17:26:03 --> Helper loaded: form_helper
INFO - 2017-03-03 17:26:03 --> Helper loaded: url_helper
INFO - 2017-03-03 17:26:03 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:26:03 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:26:03 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:26:03 --> Template Class Initialized
INFO - 2017-03-03 17:26:03 --> Model Class Initialized
INFO - 2017-03-03 17:26:03 --> Controller Class Initialized
DEBUG - 2017-03-03 17:26:03 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:26:03 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:26:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:26:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:26:08 --> Config Class Initialized
INFO - 2017-03-03 17:26:08 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:26:08 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:26:08 --> Utf8 Class Initialized
INFO - 2017-03-03 17:26:08 --> URI Class Initialized
INFO - 2017-03-03 17:26:08 --> Router Class Initialized
INFO - 2017-03-03 17:26:08 --> Output Class Initialized
INFO - 2017-03-03 17:26:08 --> Security Class Initialized
DEBUG - 2017-03-03 17:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:26:08 --> Input Class Initialized
INFO - 2017-03-03 17:26:08 --> Language Class Initialized
INFO - 2017-03-03 17:26:08 --> Language Class Initialized
INFO - 2017-03-03 17:26:08 --> Config Class Initialized
INFO - 2017-03-03 17:26:08 --> Loader Class Initialized
INFO - 2017-03-03 17:26:08 --> Helper loaded: form_helper
INFO - 2017-03-03 17:26:08 --> Helper loaded: url_helper
INFO - 2017-03-03 17:26:08 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:26:08 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:26:08 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:26:08 --> Template Class Initialized
INFO - 2017-03-03 17:26:08 --> Model Class Initialized
INFO - 2017-03-03 17:26:08 --> Controller Class Initialized
DEBUG - 2017-03-03 17:26:08 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:26:08 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:26:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:26:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:26:09 --> Config Class Initialized
INFO - 2017-03-03 17:26:09 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:26:09 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:26:09 --> Utf8 Class Initialized
INFO - 2017-03-03 17:26:09 --> URI Class Initialized
INFO - 2017-03-03 17:26:09 --> Router Class Initialized
INFO - 2017-03-03 17:26:09 --> Output Class Initialized
INFO - 2017-03-03 17:26:09 --> Security Class Initialized
DEBUG - 2017-03-03 17:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:26:09 --> Input Class Initialized
INFO - 2017-03-03 17:26:09 --> Language Class Initialized
INFO - 2017-03-03 17:26:09 --> Language Class Initialized
INFO - 2017-03-03 17:26:09 --> Config Class Initialized
INFO - 2017-03-03 17:26:09 --> Loader Class Initialized
INFO - 2017-03-03 17:26:09 --> Helper loaded: form_helper
INFO - 2017-03-03 17:26:09 --> Helper loaded: url_helper
INFO - 2017-03-03 17:26:09 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:26:09 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:26:09 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:26:09 --> Template Class Initialized
INFO - 2017-03-03 17:26:09 --> Model Class Initialized
INFO - 2017-03-03 17:26:09 --> Controller Class Initialized
DEBUG - 2017-03-03 17:26:09 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:26:09 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:26:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:26:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:26:40 --> Config Class Initialized
INFO - 2017-03-03 17:26:40 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:26:40 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:26:40 --> Utf8 Class Initialized
INFO - 2017-03-03 17:26:40 --> URI Class Initialized
INFO - 2017-03-03 17:26:40 --> Router Class Initialized
INFO - 2017-03-03 17:26:40 --> Output Class Initialized
INFO - 2017-03-03 17:26:40 --> Security Class Initialized
DEBUG - 2017-03-03 17:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:26:40 --> Input Class Initialized
INFO - 2017-03-03 17:26:40 --> Language Class Initialized
INFO - 2017-03-03 17:26:40 --> Language Class Initialized
INFO - 2017-03-03 17:26:40 --> Config Class Initialized
INFO - 2017-03-03 17:26:40 --> Loader Class Initialized
INFO - 2017-03-03 17:26:40 --> Helper loaded: form_helper
INFO - 2017-03-03 17:26:40 --> Helper loaded: url_helper
INFO - 2017-03-03 17:26:40 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:26:40 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:26:40 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:26:40 --> Template Class Initialized
INFO - 2017-03-03 17:26:40 --> Model Class Initialized
INFO - 2017-03-03 17:26:40 --> Controller Class Initialized
DEBUG - 2017-03-03 17:26:40 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:26:40 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:26:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:26:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:26:42 --> Config Class Initialized
INFO - 2017-03-03 17:26:42 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:26:42 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:26:42 --> Utf8 Class Initialized
INFO - 2017-03-03 17:26:42 --> URI Class Initialized
INFO - 2017-03-03 17:26:42 --> Router Class Initialized
INFO - 2017-03-03 17:26:42 --> Output Class Initialized
INFO - 2017-03-03 17:26:42 --> Security Class Initialized
DEBUG - 2017-03-03 17:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:26:42 --> Input Class Initialized
INFO - 2017-03-03 17:26:42 --> Language Class Initialized
INFO - 2017-03-03 17:26:42 --> Language Class Initialized
INFO - 2017-03-03 17:26:42 --> Config Class Initialized
INFO - 2017-03-03 17:26:42 --> Loader Class Initialized
INFO - 2017-03-03 17:26:42 --> Helper loaded: form_helper
INFO - 2017-03-03 17:26:42 --> Helper loaded: url_helper
INFO - 2017-03-03 17:26:42 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:26:42 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:26:42 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:26:42 --> Template Class Initialized
INFO - 2017-03-03 17:26:42 --> Model Class Initialized
INFO - 2017-03-03 17:26:42 --> Controller Class Initialized
DEBUG - 2017-03-03 17:26:42 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:26:42 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:26:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:26:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:26:43 --> Config Class Initialized
INFO - 2017-03-03 17:26:43 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:26:43 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:26:43 --> Utf8 Class Initialized
INFO - 2017-03-03 17:26:43 --> URI Class Initialized
INFO - 2017-03-03 17:26:43 --> Router Class Initialized
INFO - 2017-03-03 17:26:43 --> Output Class Initialized
INFO - 2017-03-03 17:26:43 --> Security Class Initialized
DEBUG - 2017-03-03 17:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:26:43 --> Input Class Initialized
INFO - 2017-03-03 17:26:43 --> Language Class Initialized
INFO - 2017-03-03 17:26:43 --> Language Class Initialized
INFO - 2017-03-03 17:26:43 --> Config Class Initialized
INFO - 2017-03-03 17:26:43 --> Loader Class Initialized
INFO - 2017-03-03 17:26:43 --> Helper loaded: form_helper
INFO - 2017-03-03 17:26:43 --> Helper loaded: url_helper
INFO - 2017-03-03 17:26:43 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:26:43 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:26:43 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:26:43 --> Template Class Initialized
INFO - 2017-03-03 17:26:43 --> Model Class Initialized
INFO - 2017-03-03 17:26:43 --> Controller Class Initialized
DEBUG - 2017-03-03 17:26:43 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:26:43 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:26:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:26:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:26:43 --> Config Class Initialized
INFO - 2017-03-03 17:26:43 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:26:43 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:26:43 --> Utf8 Class Initialized
INFO - 2017-03-03 17:26:43 --> URI Class Initialized
INFO - 2017-03-03 17:26:43 --> Router Class Initialized
INFO - 2017-03-03 17:26:43 --> Output Class Initialized
INFO - 2017-03-03 17:26:43 --> Security Class Initialized
DEBUG - 2017-03-03 17:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:26:43 --> Input Class Initialized
INFO - 2017-03-03 17:26:43 --> Language Class Initialized
INFO - 2017-03-03 17:26:43 --> Language Class Initialized
INFO - 2017-03-03 17:26:43 --> Config Class Initialized
INFO - 2017-03-03 17:26:43 --> Loader Class Initialized
INFO - 2017-03-03 17:26:43 --> Helper loaded: form_helper
INFO - 2017-03-03 17:26:43 --> Helper loaded: url_helper
INFO - 2017-03-03 17:26:43 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:26:43 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:26:43 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:26:43 --> Template Class Initialized
INFO - 2017-03-03 17:26:43 --> Model Class Initialized
INFO - 2017-03-03 17:26:43 --> Controller Class Initialized
DEBUG - 2017-03-03 17:26:43 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:26:43 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:26:43 --> Model Class Initialized
DEBUG - 2017-03-03 17:26:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:26:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:26:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:26:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:26:43 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:26:43 --> Final output sent to browser
DEBUG - 2017-03-03 17:26:43 --> Total execution time: 0.0166
INFO - 2017-03-03 17:26:46 --> Config Class Initialized
INFO - 2017-03-03 17:26:46 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:26:46 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:26:46 --> Utf8 Class Initialized
INFO - 2017-03-03 17:26:46 --> URI Class Initialized
INFO - 2017-03-03 17:26:46 --> Router Class Initialized
INFO - 2017-03-03 17:26:46 --> Output Class Initialized
INFO - 2017-03-03 17:26:46 --> Security Class Initialized
DEBUG - 2017-03-03 17:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:26:46 --> Input Class Initialized
INFO - 2017-03-03 17:26:46 --> Language Class Initialized
INFO - 2017-03-03 17:26:46 --> Language Class Initialized
INFO - 2017-03-03 17:26:46 --> Config Class Initialized
INFO - 2017-03-03 17:26:46 --> Loader Class Initialized
INFO - 2017-03-03 17:26:46 --> Helper loaded: form_helper
INFO - 2017-03-03 17:26:46 --> Helper loaded: url_helper
INFO - 2017-03-03 17:26:46 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:26:46 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:26:46 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:26:46 --> Template Class Initialized
INFO - 2017-03-03 17:26:46 --> Model Class Initialized
INFO - 2017-03-03 17:26:46 --> Controller Class Initialized
DEBUG - 2017-03-03 17:26:46 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:26:46 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:26:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:26:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:26:47 --> Config Class Initialized
INFO - 2017-03-03 17:26:47 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:26:47 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:26:47 --> Utf8 Class Initialized
INFO - 2017-03-03 17:26:47 --> URI Class Initialized
INFO - 2017-03-03 17:26:47 --> Router Class Initialized
INFO - 2017-03-03 17:26:47 --> Output Class Initialized
INFO - 2017-03-03 17:26:47 --> Security Class Initialized
DEBUG - 2017-03-03 17:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:26:47 --> Input Class Initialized
INFO - 2017-03-03 17:26:47 --> Language Class Initialized
INFO - 2017-03-03 17:26:47 --> Language Class Initialized
INFO - 2017-03-03 17:26:47 --> Config Class Initialized
INFO - 2017-03-03 17:26:47 --> Loader Class Initialized
INFO - 2017-03-03 17:26:47 --> Helper loaded: form_helper
INFO - 2017-03-03 17:26:47 --> Helper loaded: url_helper
INFO - 2017-03-03 17:26:47 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:26:47 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:26:47 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:26:47 --> Template Class Initialized
INFO - 2017-03-03 17:26:47 --> Model Class Initialized
INFO - 2017-03-03 17:26:47 --> Controller Class Initialized
DEBUG - 2017-03-03 17:26:47 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:26:47 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:26:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:26:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:26:52 --> Config Class Initialized
INFO - 2017-03-03 17:26:52 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:26:52 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:26:52 --> Utf8 Class Initialized
INFO - 2017-03-03 17:26:52 --> URI Class Initialized
INFO - 2017-03-03 17:26:52 --> Router Class Initialized
INFO - 2017-03-03 17:26:52 --> Output Class Initialized
INFO - 2017-03-03 17:26:52 --> Security Class Initialized
DEBUG - 2017-03-03 17:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:26:52 --> Input Class Initialized
INFO - 2017-03-03 17:26:52 --> Language Class Initialized
INFO - 2017-03-03 17:26:52 --> Language Class Initialized
INFO - 2017-03-03 17:26:52 --> Config Class Initialized
INFO - 2017-03-03 17:26:52 --> Loader Class Initialized
INFO - 2017-03-03 17:26:52 --> Helper loaded: form_helper
INFO - 2017-03-03 17:26:52 --> Helper loaded: url_helper
INFO - 2017-03-03 17:26:52 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:26:52 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:26:52 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:26:52 --> Template Class Initialized
INFO - 2017-03-03 17:26:52 --> Model Class Initialized
INFO - 2017-03-03 17:26:52 --> Controller Class Initialized
DEBUG - 2017-03-03 17:26:52 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:26:52 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:26:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:26:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:26:52 --> Config Class Initialized
INFO - 2017-03-03 17:26:52 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:26:52 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:26:52 --> Utf8 Class Initialized
INFO - 2017-03-03 17:26:52 --> URI Class Initialized
INFO - 2017-03-03 17:26:52 --> Router Class Initialized
INFO - 2017-03-03 17:26:52 --> Output Class Initialized
INFO - 2017-03-03 17:26:52 --> Security Class Initialized
DEBUG - 2017-03-03 17:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:26:52 --> Input Class Initialized
INFO - 2017-03-03 17:26:52 --> Language Class Initialized
INFO - 2017-03-03 17:26:52 --> Language Class Initialized
INFO - 2017-03-03 17:26:52 --> Config Class Initialized
INFO - 2017-03-03 17:26:52 --> Loader Class Initialized
INFO - 2017-03-03 17:26:52 --> Helper loaded: form_helper
INFO - 2017-03-03 17:26:52 --> Helper loaded: url_helper
INFO - 2017-03-03 17:26:52 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:26:52 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:26:52 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:26:52 --> Template Class Initialized
INFO - 2017-03-03 17:26:52 --> Model Class Initialized
INFO - 2017-03-03 17:26:52 --> Controller Class Initialized
DEBUG - 2017-03-03 17:26:52 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:26:52 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:26:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:26:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:26:53 --> Config Class Initialized
INFO - 2017-03-03 17:26:53 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:26:53 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:26:53 --> Utf8 Class Initialized
INFO - 2017-03-03 17:26:53 --> URI Class Initialized
INFO - 2017-03-03 17:26:53 --> Router Class Initialized
INFO - 2017-03-03 17:26:53 --> Output Class Initialized
INFO - 2017-03-03 17:26:53 --> Security Class Initialized
DEBUG - 2017-03-03 17:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:26:53 --> Input Class Initialized
INFO - 2017-03-03 17:26:53 --> Language Class Initialized
INFO - 2017-03-03 17:26:53 --> Language Class Initialized
INFO - 2017-03-03 17:26:53 --> Config Class Initialized
INFO - 2017-03-03 17:26:53 --> Loader Class Initialized
INFO - 2017-03-03 17:26:53 --> Helper loaded: form_helper
INFO - 2017-03-03 17:26:53 --> Helper loaded: url_helper
INFO - 2017-03-03 17:26:53 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:26:53 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:26:53 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:26:53 --> Template Class Initialized
INFO - 2017-03-03 17:26:53 --> Model Class Initialized
INFO - 2017-03-03 17:26:53 --> Controller Class Initialized
DEBUG - 2017-03-03 17:26:53 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:26:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:26:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:26:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:26:54 --> Config Class Initialized
INFO - 2017-03-03 17:26:54 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:26:54 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:26:54 --> Utf8 Class Initialized
INFO - 2017-03-03 17:26:54 --> URI Class Initialized
INFO - 2017-03-03 17:26:54 --> Router Class Initialized
INFO - 2017-03-03 17:26:54 --> Output Class Initialized
INFO - 2017-03-03 17:26:54 --> Security Class Initialized
DEBUG - 2017-03-03 17:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:26:54 --> Input Class Initialized
INFO - 2017-03-03 17:26:54 --> Language Class Initialized
INFO - 2017-03-03 17:26:54 --> Language Class Initialized
INFO - 2017-03-03 17:26:54 --> Config Class Initialized
INFO - 2017-03-03 17:26:54 --> Loader Class Initialized
INFO - 2017-03-03 17:26:54 --> Helper loaded: form_helper
INFO - 2017-03-03 17:26:54 --> Helper loaded: url_helper
INFO - 2017-03-03 17:26:54 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:26:54 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:26:54 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:26:54 --> Template Class Initialized
INFO - 2017-03-03 17:26:54 --> Model Class Initialized
INFO - 2017-03-03 17:26:54 --> Controller Class Initialized
DEBUG - 2017-03-03 17:26:54 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:26:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:26:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:26:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:26:55 --> Config Class Initialized
INFO - 2017-03-03 17:26:55 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:26:55 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:26:55 --> Utf8 Class Initialized
INFO - 2017-03-03 17:26:55 --> URI Class Initialized
INFO - 2017-03-03 17:26:55 --> Router Class Initialized
INFO - 2017-03-03 17:26:55 --> Output Class Initialized
INFO - 2017-03-03 17:26:55 --> Security Class Initialized
DEBUG - 2017-03-03 17:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:26:55 --> Input Class Initialized
INFO - 2017-03-03 17:26:55 --> Language Class Initialized
INFO - 2017-03-03 17:26:55 --> Language Class Initialized
INFO - 2017-03-03 17:26:55 --> Config Class Initialized
INFO - 2017-03-03 17:26:55 --> Loader Class Initialized
INFO - 2017-03-03 17:26:55 --> Helper loaded: form_helper
INFO - 2017-03-03 17:26:55 --> Helper loaded: url_helper
INFO - 2017-03-03 17:26:55 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:26:55 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:26:55 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:26:55 --> Template Class Initialized
INFO - 2017-03-03 17:26:55 --> Model Class Initialized
INFO - 2017-03-03 17:26:55 --> Controller Class Initialized
DEBUG - 2017-03-03 17:26:55 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:26:55 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:26:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:26:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:26:56 --> Config Class Initialized
INFO - 2017-03-03 17:26:56 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:26:56 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:26:56 --> Utf8 Class Initialized
INFO - 2017-03-03 17:26:56 --> URI Class Initialized
INFO - 2017-03-03 17:26:56 --> Router Class Initialized
INFO - 2017-03-03 17:26:56 --> Output Class Initialized
INFO - 2017-03-03 17:26:56 --> Security Class Initialized
DEBUG - 2017-03-03 17:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:26:56 --> Input Class Initialized
INFO - 2017-03-03 17:26:56 --> Language Class Initialized
INFO - 2017-03-03 17:26:56 --> Language Class Initialized
INFO - 2017-03-03 17:26:56 --> Config Class Initialized
INFO - 2017-03-03 17:26:56 --> Loader Class Initialized
INFO - 2017-03-03 17:26:56 --> Helper loaded: form_helper
INFO - 2017-03-03 17:26:56 --> Helper loaded: url_helper
INFO - 2017-03-03 17:26:56 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:26:56 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:26:56 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:26:56 --> Template Class Initialized
INFO - 2017-03-03 17:26:56 --> Model Class Initialized
INFO - 2017-03-03 17:26:56 --> Controller Class Initialized
DEBUG - 2017-03-03 17:26:56 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:26:56 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:26:56 --> Model Class Initialized
DEBUG - 2017-03-03 17:26:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:26:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:26:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:26:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:26:56 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:26:56 --> Final output sent to browser
DEBUG - 2017-03-03 17:26:56 --> Total execution time: 0.0182
INFO - 2017-03-03 17:26:57 --> Config Class Initialized
INFO - 2017-03-03 17:26:57 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:26:57 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:26:57 --> Utf8 Class Initialized
INFO - 2017-03-03 17:26:57 --> URI Class Initialized
INFO - 2017-03-03 17:26:57 --> Router Class Initialized
INFO - 2017-03-03 17:26:57 --> Output Class Initialized
INFO - 2017-03-03 17:26:57 --> Security Class Initialized
DEBUG - 2017-03-03 17:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:26:57 --> Input Class Initialized
INFO - 2017-03-03 17:26:57 --> Language Class Initialized
INFO - 2017-03-03 17:26:57 --> Language Class Initialized
INFO - 2017-03-03 17:26:57 --> Config Class Initialized
INFO - 2017-03-03 17:26:57 --> Loader Class Initialized
INFO - 2017-03-03 17:26:57 --> Helper loaded: form_helper
INFO - 2017-03-03 17:26:57 --> Helper loaded: url_helper
INFO - 2017-03-03 17:26:57 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:26:57 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:26:57 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:26:57 --> Template Class Initialized
INFO - 2017-03-03 17:26:57 --> Model Class Initialized
INFO - 2017-03-03 17:26:57 --> Controller Class Initialized
DEBUG - 2017-03-03 17:26:57 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:26:57 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:26:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:26:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:31:36 --> Config Class Initialized
INFO - 2017-03-03 17:31:36 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:31:36 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:31:36 --> Utf8 Class Initialized
INFO - 2017-03-03 17:31:36 --> URI Class Initialized
INFO - 2017-03-03 17:31:36 --> Router Class Initialized
INFO - 2017-03-03 17:31:36 --> Output Class Initialized
INFO - 2017-03-03 17:31:36 --> Security Class Initialized
DEBUG - 2017-03-03 17:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:31:36 --> Input Class Initialized
INFO - 2017-03-03 17:31:36 --> Language Class Initialized
INFO - 2017-03-03 17:31:36 --> Language Class Initialized
INFO - 2017-03-03 17:31:36 --> Config Class Initialized
INFO - 2017-03-03 17:31:36 --> Loader Class Initialized
INFO - 2017-03-03 17:31:36 --> Helper loaded: form_helper
INFO - 2017-03-03 17:31:36 --> Helper loaded: url_helper
INFO - 2017-03-03 17:31:36 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:31:36 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:31:36 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:31:36 --> Template Class Initialized
INFO - 2017-03-03 17:31:36 --> Model Class Initialized
INFO - 2017-03-03 17:31:36 --> Controller Class Initialized
DEBUG - 2017-03-03 17:31:36 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:31:36 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:31:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:31:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:31:38 --> Config Class Initialized
INFO - 2017-03-03 17:31:38 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:31:38 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:31:38 --> Utf8 Class Initialized
INFO - 2017-03-03 17:31:38 --> URI Class Initialized
INFO - 2017-03-03 17:31:38 --> Router Class Initialized
INFO - 2017-03-03 17:31:38 --> Output Class Initialized
INFO - 2017-03-03 17:31:38 --> Security Class Initialized
DEBUG - 2017-03-03 17:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:31:38 --> Input Class Initialized
INFO - 2017-03-03 17:31:38 --> Language Class Initialized
INFO - 2017-03-03 17:31:38 --> Language Class Initialized
INFO - 2017-03-03 17:31:38 --> Config Class Initialized
INFO - 2017-03-03 17:31:38 --> Loader Class Initialized
INFO - 2017-03-03 17:31:38 --> Helper loaded: form_helper
INFO - 2017-03-03 17:31:38 --> Helper loaded: url_helper
INFO - 2017-03-03 17:31:38 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:31:38 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:31:38 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:31:38 --> Template Class Initialized
INFO - 2017-03-03 17:31:38 --> Model Class Initialized
INFO - 2017-03-03 17:31:38 --> Controller Class Initialized
DEBUG - 2017-03-03 17:31:38 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:31:38 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:31:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:31:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:31:42 --> Config Class Initialized
INFO - 2017-03-03 17:31:42 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:31:42 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:31:42 --> Utf8 Class Initialized
INFO - 2017-03-03 17:31:42 --> URI Class Initialized
INFO - 2017-03-03 17:31:42 --> Router Class Initialized
INFO - 2017-03-03 17:31:42 --> Output Class Initialized
INFO - 2017-03-03 17:31:42 --> Security Class Initialized
DEBUG - 2017-03-03 17:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:31:42 --> Input Class Initialized
INFO - 2017-03-03 17:31:42 --> Language Class Initialized
INFO - 2017-03-03 17:31:42 --> Language Class Initialized
INFO - 2017-03-03 17:31:42 --> Config Class Initialized
INFO - 2017-03-03 17:31:42 --> Loader Class Initialized
INFO - 2017-03-03 17:31:42 --> Helper loaded: form_helper
INFO - 2017-03-03 17:31:42 --> Helper loaded: url_helper
INFO - 2017-03-03 17:31:42 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:31:42 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:31:42 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:31:42 --> Template Class Initialized
INFO - 2017-03-03 17:31:42 --> Model Class Initialized
INFO - 2017-03-03 17:31:42 --> Controller Class Initialized
DEBUG - 2017-03-03 17:31:42 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:31:42 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:31:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:31:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:31:45 --> Config Class Initialized
INFO - 2017-03-03 17:31:45 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:31:45 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:31:45 --> Utf8 Class Initialized
INFO - 2017-03-03 17:31:45 --> URI Class Initialized
INFO - 2017-03-03 17:31:45 --> Router Class Initialized
INFO - 2017-03-03 17:31:45 --> Output Class Initialized
INFO - 2017-03-03 17:31:45 --> Security Class Initialized
DEBUG - 2017-03-03 17:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:31:45 --> Input Class Initialized
INFO - 2017-03-03 17:31:45 --> Language Class Initialized
INFO - 2017-03-03 17:31:45 --> Language Class Initialized
INFO - 2017-03-03 17:31:45 --> Config Class Initialized
INFO - 2017-03-03 17:31:45 --> Loader Class Initialized
INFO - 2017-03-03 17:31:45 --> Helper loaded: form_helper
INFO - 2017-03-03 17:31:45 --> Helper loaded: url_helper
INFO - 2017-03-03 17:31:45 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:31:45 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:31:45 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:31:45 --> Template Class Initialized
INFO - 2017-03-03 17:31:45 --> Model Class Initialized
INFO - 2017-03-03 17:31:45 --> Controller Class Initialized
DEBUG - 2017-03-03 17:31:45 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:31:45 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:31:45 --> Model Class Initialized
DEBUG - 2017-03-03 17:31:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:31:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:31:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:31:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:31:45 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:31:45 --> Final output sent to browser
DEBUG - 2017-03-03 17:31:45 --> Total execution time: 0.0136
INFO - 2017-03-03 17:31:46 --> Config Class Initialized
INFO - 2017-03-03 17:31:46 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:31:46 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:31:46 --> Utf8 Class Initialized
INFO - 2017-03-03 17:31:46 --> URI Class Initialized
INFO - 2017-03-03 17:31:46 --> Router Class Initialized
INFO - 2017-03-03 17:31:46 --> Output Class Initialized
INFO - 2017-03-03 17:31:46 --> Security Class Initialized
DEBUG - 2017-03-03 17:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:31:46 --> Input Class Initialized
INFO - 2017-03-03 17:31:46 --> Language Class Initialized
INFO - 2017-03-03 17:31:46 --> Language Class Initialized
INFO - 2017-03-03 17:31:46 --> Config Class Initialized
INFO - 2017-03-03 17:31:46 --> Loader Class Initialized
INFO - 2017-03-03 17:31:46 --> Helper loaded: form_helper
INFO - 2017-03-03 17:31:46 --> Helper loaded: url_helper
INFO - 2017-03-03 17:31:46 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:31:46 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:31:46 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:31:46 --> Template Class Initialized
INFO - 2017-03-03 17:31:46 --> Model Class Initialized
INFO - 2017-03-03 17:31:46 --> Controller Class Initialized
DEBUG - 2017-03-03 17:31:46 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:31:46 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:31:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:31:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:31:48 --> Config Class Initialized
INFO - 2017-03-03 17:31:48 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:31:48 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:31:48 --> Utf8 Class Initialized
INFO - 2017-03-03 17:31:48 --> URI Class Initialized
INFO - 2017-03-03 17:31:48 --> Router Class Initialized
INFO - 2017-03-03 17:31:48 --> Output Class Initialized
INFO - 2017-03-03 17:31:48 --> Security Class Initialized
DEBUG - 2017-03-03 17:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:31:48 --> Input Class Initialized
INFO - 2017-03-03 17:31:48 --> Language Class Initialized
INFO - 2017-03-03 17:31:48 --> Language Class Initialized
INFO - 2017-03-03 17:31:48 --> Config Class Initialized
INFO - 2017-03-03 17:31:48 --> Loader Class Initialized
INFO - 2017-03-03 17:31:48 --> Helper loaded: form_helper
INFO - 2017-03-03 17:31:48 --> Helper loaded: url_helper
INFO - 2017-03-03 17:31:48 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:31:48 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:31:48 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:31:48 --> Template Class Initialized
INFO - 2017-03-03 17:31:48 --> Model Class Initialized
INFO - 2017-03-03 17:31:48 --> Controller Class Initialized
DEBUG - 2017-03-03 17:31:48 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:31:48 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:31:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:31:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:31:53 --> Config Class Initialized
INFO - 2017-03-03 17:31:53 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:31:53 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:31:53 --> Utf8 Class Initialized
INFO - 2017-03-03 17:31:53 --> URI Class Initialized
INFO - 2017-03-03 17:31:53 --> Router Class Initialized
INFO - 2017-03-03 17:31:53 --> Output Class Initialized
INFO - 2017-03-03 17:31:53 --> Security Class Initialized
DEBUG - 2017-03-03 17:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:31:53 --> Input Class Initialized
INFO - 2017-03-03 17:31:53 --> Language Class Initialized
INFO - 2017-03-03 17:31:53 --> Language Class Initialized
INFO - 2017-03-03 17:31:53 --> Config Class Initialized
INFO - 2017-03-03 17:31:53 --> Loader Class Initialized
INFO - 2017-03-03 17:31:53 --> Helper loaded: form_helper
INFO - 2017-03-03 17:31:53 --> Helper loaded: url_helper
INFO - 2017-03-03 17:31:53 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:31:53 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:31:53 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:31:53 --> Template Class Initialized
INFO - 2017-03-03 17:31:53 --> Model Class Initialized
INFO - 2017-03-03 17:31:53 --> Controller Class Initialized
DEBUG - 2017-03-03 17:31:53 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:31:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:31:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:31:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:32:10 --> Config Class Initialized
INFO - 2017-03-03 17:32:10 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:32:10 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:32:10 --> Utf8 Class Initialized
INFO - 2017-03-03 17:32:10 --> URI Class Initialized
INFO - 2017-03-03 17:32:10 --> Router Class Initialized
INFO - 2017-03-03 17:32:10 --> Output Class Initialized
INFO - 2017-03-03 17:32:10 --> Security Class Initialized
DEBUG - 2017-03-03 17:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:32:10 --> Input Class Initialized
INFO - 2017-03-03 17:32:10 --> Language Class Initialized
INFO - 2017-03-03 17:32:10 --> Language Class Initialized
INFO - 2017-03-03 17:32:10 --> Config Class Initialized
INFO - 2017-03-03 17:32:10 --> Loader Class Initialized
INFO - 2017-03-03 17:32:10 --> Helper loaded: form_helper
INFO - 2017-03-03 17:32:10 --> Helper loaded: url_helper
INFO - 2017-03-03 17:32:10 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:32:10 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:32:10 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:32:10 --> Template Class Initialized
INFO - 2017-03-03 17:32:10 --> Model Class Initialized
INFO - 2017-03-03 17:32:10 --> Controller Class Initialized
DEBUG - 2017-03-03 17:32:10 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:32:10 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:32:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:32:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:32:20 --> Config Class Initialized
INFO - 2017-03-03 17:32:20 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:32:20 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:32:20 --> Utf8 Class Initialized
INFO - 2017-03-03 17:32:20 --> URI Class Initialized
INFO - 2017-03-03 17:32:20 --> Router Class Initialized
INFO - 2017-03-03 17:32:20 --> Output Class Initialized
INFO - 2017-03-03 17:32:20 --> Security Class Initialized
DEBUG - 2017-03-03 17:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:32:20 --> Input Class Initialized
INFO - 2017-03-03 17:32:20 --> Language Class Initialized
INFO - 2017-03-03 17:32:20 --> Language Class Initialized
INFO - 2017-03-03 17:32:20 --> Config Class Initialized
INFO - 2017-03-03 17:32:20 --> Loader Class Initialized
INFO - 2017-03-03 17:32:20 --> Helper loaded: form_helper
INFO - 2017-03-03 17:32:20 --> Helper loaded: url_helper
INFO - 2017-03-03 17:32:20 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:32:20 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:32:20 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:32:20 --> Template Class Initialized
INFO - 2017-03-03 17:32:20 --> Model Class Initialized
INFO - 2017-03-03 17:32:20 --> Controller Class Initialized
DEBUG - 2017-03-03 17:32:20 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:32:20 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:32:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:32:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:32:40 --> Config Class Initialized
INFO - 2017-03-03 17:32:40 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:32:40 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:32:40 --> Utf8 Class Initialized
INFO - 2017-03-03 17:32:40 --> URI Class Initialized
INFO - 2017-03-03 17:32:40 --> Router Class Initialized
INFO - 2017-03-03 17:32:40 --> Output Class Initialized
INFO - 2017-03-03 17:32:40 --> Security Class Initialized
DEBUG - 2017-03-03 17:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:32:40 --> Input Class Initialized
INFO - 2017-03-03 17:32:40 --> Language Class Initialized
INFO - 2017-03-03 17:32:40 --> Language Class Initialized
INFO - 2017-03-03 17:32:40 --> Config Class Initialized
INFO - 2017-03-03 17:32:40 --> Loader Class Initialized
INFO - 2017-03-03 17:32:40 --> Helper loaded: form_helper
INFO - 2017-03-03 17:32:40 --> Helper loaded: url_helper
INFO - 2017-03-03 17:32:40 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:32:40 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:32:40 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:32:40 --> Template Class Initialized
INFO - 2017-03-03 17:32:40 --> Model Class Initialized
INFO - 2017-03-03 17:32:40 --> Controller Class Initialized
DEBUG - 2017-03-03 17:32:40 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:32:40 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:32:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:32:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:32:44 --> Config Class Initialized
INFO - 2017-03-03 17:32:44 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:32:44 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:32:44 --> Utf8 Class Initialized
INFO - 2017-03-03 17:32:44 --> URI Class Initialized
INFO - 2017-03-03 17:32:44 --> Router Class Initialized
INFO - 2017-03-03 17:32:44 --> Output Class Initialized
INFO - 2017-03-03 17:32:44 --> Security Class Initialized
DEBUG - 2017-03-03 17:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:32:44 --> Input Class Initialized
INFO - 2017-03-03 17:32:44 --> Language Class Initialized
INFO - 2017-03-03 17:32:44 --> Language Class Initialized
INFO - 2017-03-03 17:32:44 --> Config Class Initialized
INFO - 2017-03-03 17:32:44 --> Loader Class Initialized
INFO - 2017-03-03 17:32:44 --> Helper loaded: form_helper
INFO - 2017-03-03 17:32:44 --> Helper loaded: url_helper
INFO - 2017-03-03 17:32:44 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:32:44 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:32:44 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:32:44 --> Template Class Initialized
INFO - 2017-03-03 17:32:44 --> Model Class Initialized
INFO - 2017-03-03 17:32:44 --> Controller Class Initialized
DEBUG - 2017-03-03 17:32:44 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:32:44 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:32:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:32:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:32:49 --> Config Class Initialized
INFO - 2017-03-03 17:32:49 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:32:49 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:32:49 --> Utf8 Class Initialized
INFO - 2017-03-03 17:32:49 --> URI Class Initialized
INFO - 2017-03-03 17:32:49 --> Router Class Initialized
INFO - 2017-03-03 17:32:49 --> Output Class Initialized
INFO - 2017-03-03 17:32:49 --> Security Class Initialized
DEBUG - 2017-03-03 17:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:32:49 --> Input Class Initialized
INFO - 2017-03-03 17:32:49 --> Language Class Initialized
INFO - 2017-03-03 17:32:49 --> Language Class Initialized
INFO - 2017-03-03 17:32:49 --> Config Class Initialized
INFO - 2017-03-03 17:32:49 --> Loader Class Initialized
INFO - 2017-03-03 17:32:49 --> Helper loaded: form_helper
INFO - 2017-03-03 17:32:49 --> Helper loaded: url_helper
INFO - 2017-03-03 17:32:49 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:32:49 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:32:49 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:32:49 --> Template Class Initialized
INFO - 2017-03-03 17:32:49 --> Model Class Initialized
INFO - 2017-03-03 17:32:49 --> Controller Class Initialized
DEBUG - 2017-03-03 17:32:49 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:32:49 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:32:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:32:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:32:50 --> Config Class Initialized
INFO - 2017-03-03 17:32:50 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:32:50 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:32:50 --> Utf8 Class Initialized
INFO - 2017-03-03 17:32:50 --> URI Class Initialized
INFO - 2017-03-03 17:32:50 --> Router Class Initialized
INFO - 2017-03-03 17:32:50 --> Output Class Initialized
INFO - 2017-03-03 17:32:50 --> Security Class Initialized
DEBUG - 2017-03-03 17:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:32:50 --> Input Class Initialized
INFO - 2017-03-03 17:32:50 --> Language Class Initialized
INFO - 2017-03-03 17:32:50 --> Language Class Initialized
INFO - 2017-03-03 17:32:50 --> Config Class Initialized
INFO - 2017-03-03 17:32:50 --> Loader Class Initialized
INFO - 2017-03-03 17:32:50 --> Helper loaded: form_helper
INFO - 2017-03-03 17:32:50 --> Helper loaded: url_helper
INFO - 2017-03-03 17:32:50 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:32:50 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:32:50 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:32:50 --> Template Class Initialized
INFO - 2017-03-03 17:32:50 --> Model Class Initialized
INFO - 2017-03-03 17:32:50 --> Controller Class Initialized
DEBUG - 2017-03-03 17:32:50 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:32:50 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:32:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:32:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:32:51 --> Config Class Initialized
INFO - 2017-03-03 17:32:51 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:32:51 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:32:51 --> Utf8 Class Initialized
INFO - 2017-03-03 17:32:51 --> URI Class Initialized
INFO - 2017-03-03 17:32:51 --> Router Class Initialized
INFO - 2017-03-03 17:32:51 --> Output Class Initialized
INFO - 2017-03-03 17:32:51 --> Security Class Initialized
DEBUG - 2017-03-03 17:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:32:51 --> Input Class Initialized
INFO - 2017-03-03 17:32:51 --> Language Class Initialized
INFO - 2017-03-03 17:32:51 --> Language Class Initialized
INFO - 2017-03-03 17:32:51 --> Config Class Initialized
INFO - 2017-03-03 17:32:51 --> Loader Class Initialized
INFO - 2017-03-03 17:32:51 --> Helper loaded: form_helper
INFO - 2017-03-03 17:32:51 --> Helper loaded: url_helper
INFO - 2017-03-03 17:32:51 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:32:51 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:32:51 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:32:51 --> Template Class Initialized
INFO - 2017-03-03 17:32:51 --> Model Class Initialized
INFO - 2017-03-03 17:32:51 --> Controller Class Initialized
DEBUG - 2017-03-03 17:32:51 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:32:51 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:32:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:32:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:32:51 --> Config Class Initialized
INFO - 2017-03-03 17:32:51 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:32:51 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:32:51 --> Utf8 Class Initialized
INFO - 2017-03-03 17:32:51 --> URI Class Initialized
INFO - 2017-03-03 17:32:51 --> Router Class Initialized
INFO - 2017-03-03 17:32:51 --> Output Class Initialized
INFO - 2017-03-03 17:32:51 --> Security Class Initialized
DEBUG - 2017-03-03 17:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:32:51 --> Input Class Initialized
INFO - 2017-03-03 17:32:51 --> Language Class Initialized
INFO - 2017-03-03 17:32:51 --> Language Class Initialized
INFO - 2017-03-03 17:32:51 --> Config Class Initialized
INFO - 2017-03-03 17:32:51 --> Loader Class Initialized
INFO - 2017-03-03 17:32:51 --> Helper loaded: form_helper
INFO - 2017-03-03 17:32:51 --> Helper loaded: url_helper
INFO - 2017-03-03 17:32:51 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:32:51 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:32:51 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:32:51 --> Template Class Initialized
INFO - 2017-03-03 17:32:51 --> Model Class Initialized
INFO - 2017-03-03 17:32:51 --> Controller Class Initialized
DEBUG - 2017-03-03 17:32:51 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:32:51 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:32:51 --> Model Class Initialized
DEBUG - 2017-03-03 17:32:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:32:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:32:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:32:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:32:51 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:32:51 --> Final output sent to browser
DEBUG - 2017-03-03 17:32:51 --> Total execution time: 0.0134
INFO - 2017-03-03 17:32:52 --> Config Class Initialized
INFO - 2017-03-03 17:32:52 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:32:52 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:32:52 --> Utf8 Class Initialized
INFO - 2017-03-03 17:32:52 --> URI Class Initialized
INFO - 2017-03-03 17:32:52 --> Router Class Initialized
INFO - 2017-03-03 17:32:52 --> Output Class Initialized
INFO - 2017-03-03 17:32:52 --> Security Class Initialized
DEBUG - 2017-03-03 17:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:32:52 --> Input Class Initialized
INFO - 2017-03-03 17:32:52 --> Language Class Initialized
INFO - 2017-03-03 17:32:52 --> Language Class Initialized
INFO - 2017-03-03 17:32:52 --> Config Class Initialized
INFO - 2017-03-03 17:32:52 --> Loader Class Initialized
INFO - 2017-03-03 17:32:52 --> Helper loaded: form_helper
INFO - 2017-03-03 17:32:52 --> Helper loaded: url_helper
INFO - 2017-03-03 17:32:52 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:32:52 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:32:52 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:32:52 --> Template Class Initialized
INFO - 2017-03-03 17:32:52 --> Model Class Initialized
INFO - 2017-03-03 17:32:52 --> Controller Class Initialized
DEBUG - 2017-03-03 17:32:52 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:32:52 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:32:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:32:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:32:58 --> Config Class Initialized
INFO - 2017-03-03 17:32:58 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:32:58 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:32:58 --> Utf8 Class Initialized
INFO - 2017-03-03 17:32:58 --> URI Class Initialized
INFO - 2017-03-03 17:32:58 --> Router Class Initialized
INFO - 2017-03-03 17:32:58 --> Output Class Initialized
INFO - 2017-03-03 17:32:58 --> Security Class Initialized
DEBUG - 2017-03-03 17:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:32:58 --> Input Class Initialized
INFO - 2017-03-03 17:32:58 --> Language Class Initialized
INFO - 2017-03-03 17:32:58 --> Language Class Initialized
INFO - 2017-03-03 17:32:58 --> Config Class Initialized
INFO - 2017-03-03 17:32:58 --> Loader Class Initialized
INFO - 2017-03-03 17:32:58 --> Helper loaded: form_helper
INFO - 2017-03-03 17:32:58 --> Helper loaded: url_helper
INFO - 2017-03-03 17:32:58 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:32:58 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:32:58 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:32:58 --> Template Class Initialized
INFO - 2017-03-03 17:32:58 --> Model Class Initialized
INFO - 2017-03-03 17:32:58 --> Controller Class Initialized
DEBUG - 2017-03-03 17:32:58 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:32:58 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:32:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:32:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:32:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:32:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 17:32:58 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:32:58 --> Final output sent to browser
DEBUG - 2017-03-03 17:32:58 --> Total execution time: 0.0136
INFO - 2017-03-03 17:32:59 --> Config Class Initialized
INFO - 2017-03-03 17:32:59 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:32:59 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:32:59 --> Utf8 Class Initialized
INFO - 2017-03-03 17:32:59 --> URI Class Initialized
INFO - 2017-03-03 17:32:59 --> Router Class Initialized
INFO - 2017-03-03 17:32:59 --> Output Class Initialized
INFO - 2017-03-03 17:32:59 --> Security Class Initialized
DEBUG - 2017-03-03 17:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:32:59 --> Input Class Initialized
INFO - 2017-03-03 17:32:59 --> Language Class Initialized
INFO - 2017-03-03 17:32:59 --> Language Class Initialized
INFO - 2017-03-03 17:32:59 --> Config Class Initialized
INFO - 2017-03-03 17:32:59 --> Loader Class Initialized
INFO - 2017-03-03 17:32:59 --> Helper loaded: form_helper
INFO - 2017-03-03 17:32:59 --> Helper loaded: url_helper
INFO - 2017-03-03 17:32:59 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:32:59 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:32:59 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:32:59 --> Template Class Initialized
INFO - 2017-03-03 17:32:59 --> Model Class Initialized
INFO - 2017-03-03 17:32:59 --> Controller Class Initialized
DEBUG - 2017-03-03 17:32:59 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:32:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:32:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:32:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:33:00 --> Config Class Initialized
INFO - 2017-03-03 17:33:00 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:33:00 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:33:00 --> Utf8 Class Initialized
INFO - 2017-03-03 17:33:00 --> URI Class Initialized
INFO - 2017-03-03 17:33:00 --> Router Class Initialized
INFO - 2017-03-03 17:33:00 --> Output Class Initialized
INFO - 2017-03-03 17:33:00 --> Security Class Initialized
DEBUG - 2017-03-03 17:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:33:00 --> Input Class Initialized
INFO - 2017-03-03 17:33:00 --> Language Class Initialized
INFO - 2017-03-03 17:33:00 --> Language Class Initialized
INFO - 2017-03-03 17:33:00 --> Config Class Initialized
INFO - 2017-03-03 17:33:00 --> Loader Class Initialized
INFO - 2017-03-03 17:33:00 --> Helper loaded: form_helper
INFO - 2017-03-03 17:33:00 --> Helper loaded: url_helper
INFO - 2017-03-03 17:33:00 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:33:00 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:33:00 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:33:00 --> Template Class Initialized
INFO - 2017-03-03 17:33:00 --> Model Class Initialized
INFO - 2017-03-03 17:33:00 --> Controller Class Initialized
DEBUG - 2017-03-03 17:33:00 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:33:00 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:33:00 --> Model Class Initialized
DEBUG - 2017-03-03 17:33:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:33:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:33:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:33:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:33:00 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:33:00 --> Final output sent to browser
DEBUG - 2017-03-03 17:33:00 --> Total execution time: 0.0234
INFO - 2017-03-03 17:33:01 --> Config Class Initialized
INFO - 2017-03-03 17:33:01 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:33:01 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:33:01 --> Utf8 Class Initialized
INFO - 2017-03-03 17:33:01 --> URI Class Initialized
INFO - 2017-03-03 17:33:01 --> Router Class Initialized
INFO - 2017-03-03 17:33:01 --> Output Class Initialized
INFO - 2017-03-03 17:33:01 --> Security Class Initialized
DEBUG - 2017-03-03 17:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:33:01 --> Input Class Initialized
INFO - 2017-03-03 17:33:01 --> Language Class Initialized
INFO - 2017-03-03 17:33:01 --> Language Class Initialized
INFO - 2017-03-03 17:33:01 --> Config Class Initialized
INFO - 2017-03-03 17:33:01 --> Loader Class Initialized
INFO - 2017-03-03 17:33:01 --> Helper loaded: form_helper
INFO - 2017-03-03 17:33:01 --> Helper loaded: url_helper
INFO - 2017-03-03 17:33:01 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:33:01 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:33:01 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:33:01 --> Template Class Initialized
INFO - 2017-03-03 17:33:01 --> Model Class Initialized
INFO - 2017-03-03 17:33:01 --> Controller Class Initialized
DEBUG - 2017-03-03 17:33:01 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:33:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:33:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:33:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:33:08 --> Config Class Initialized
INFO - 2017-03-03 17:33:08 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:33:08 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:33:08 --> Utf8 Class Initialized
INFO - 2017-03-03 17:33:08 --> URI Class Initialized
INFO - 2017-03-03 17:33:08 --> Router Class Initialized
INFO - 2017-03-03 17:33:08 --> Output Class Initialized
INFO - 2017-03-03 17:33:08 --> Security Class Initialized
DEBUG - 2017-03-03 17:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:33:08 --> Input Class Initialized
INFO - 2017-03-03 17:33:08 --> Language Class Initialized
INFO - 2017-03-03 17:33:08 --> Language Class Initialized
INFO - 2017-03-03 17:33:08 --> Config Class Initialized
INFO - 2017-03-03 17:33:08 --> Loader Class Initialized
INFO - 2017-03-03 17:33:08 --> Helper loaded: form_helper
INFO - 2017-03-03 17:33:08 --> Helper loaded: url_helper
INFO - 2017-03-03 17:33:08 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:33:08 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:33:08 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:33:08 --> Template Class Initialized
INFO - 2017-03-03 17:33:08 --> Model Class Initialized
INFO - 2017-03-03 17:33:08 --> Controller Class Initialized
DEBUG - 2017-03-03 17:33:08 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:33:08 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:33:08 --> Final output sent to browser
DEBUG - 2017-03-03 17:33:08 --> Total execution time: 0.0121
INFO - 2017-03-03 17:33:36 --> Config Class Initialized
INFO - 2017-03-03 17:33:36 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:33:36 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:33:36 --> Utf8 Class Initialized
INFO - 2017-03-03 17:33:36 --> URI Class Initialized
INFO - 2017-03-03 17:33:36 --> Router Class Initialized
INFO - 2017-03-03 17:33:36 --> Output Class Initialized
INFO - 2017-03-03 17:33:36 --> Security Class Initialized
DEBUG - 2017-03-03 17:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:33:36 --> Input Class Initialized
INFO - 2017-03-03 17:33:36 --> Language Class Initialized
INFO - 2017-03-03 17:33:36 --> Language Class Initialized
INFO - 2017-03-03 17:33:36 --> Config Class Initialized
INFO - 2017-03-03 17:33:36 --> Loader Class Initialized
INFO - 2017-03-03 17:33:36 --> Helper loaded: form_helper
INFO - 2017-03-03 17:33:36 --> Helper loaded: url_helper
INFO - 2017-03-03 17:33:36 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:33:36 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:33:36 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:33:36 --> Template Class Initialized
INFO - 2017-03-03 17:33:36 --> Model Class Initialized
INFO - 2017-03-03 17:33:36 --> Controller Class Initialized
DEBUG - 2017-03-03 17:33:36 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:33:36 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:33:36 --> Upload Class Initialized
INFO - 2017-03-03 17:33:36 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2017-03-03 17:33:36 --> The filetype you are attempting to upload is not allowed.
INFO - 2017-03-03 17:33:36 --> Model Class Initialized
INFO - 2017-03-03 17:33:36 --> Final output sent to browser
DEBUG - 2017-03-03 17:33:36 --> Total execution time: 0.0246
INFO - 2017-03-03 17:33:53 --> Config Class Initialized
INFO - 2017-03-03 17:33:53 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:33:53 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:33:53 --> Utf8 Class Initialized
INFO - 2017-03-03 17:33:53 --> URI Class Initialized
INFO - 2017-03-03 17:33:53 --> Router Class Initialized
INFO - 2017-03-03 17:33:53 --> Output Class Initialized
INFO - 2017-03-03 17:33:53 --> Security Class Initialized
DEBUG - 2017-03-03 17:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:33:53 --> Input Class Initialized
INFO - 2017-03-03 17:33:53 --> Language Class Initialized
INFO - 2017-03-03 17:33:53 --> Language Class Initialized
INFO - 2017-03-03 17:33:53 --> Config Class Initialized
INFO - 2017-03-03 17:33:53 --> Loader Class Initialized
INFO - 2017-03-03 17:33:53 --> Helper loaded: form_helper
INFO - 2017-03-03 17:33:53 --> Helper loaded: url_helper
INFO - 2017-03-03 17:33:53 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:33:53 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:33:53 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:33:53 --> Template Class Initialized
INFO - 2017-03-03 17:33:53 --> Model Class Initialized
INFO - 2017-03-03 17:33:53 --> Controller Class Initialized
DEBUG - 2017-03-03 17:33:53 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:33:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:33:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:33:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:33:55 --> Config Class Initialized
INFO - 2017-03-03 17:33:55 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:33:55 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:33:55 --> Utf8 Class Initialized
INFO - 2017-03-03 17:33:55 --> URI Class Initialized
INFO - 2017-03-03 17:33:55 --> Router Class Initialized
INFO - 2017-03-03 17:33:55 --> Output Class Initialized
INFO - 2017-03-03 17:33:55 --> Security Class Initialized
DEBUG - 2017-03-03 17:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:33:55 --> Input Class Initialized
INFO - 2017-03-03 17:33:55 --> Language Class Initialized
INFO - 2017-03-03 17:33:55 --> Language Class Initialized
INFO - 2017-03-03 17:33:55 --> Config Class Initialized
INFO - 2017-03-03 17:33:55 --> Loader Class Initialized
INFO - 2017-03-03 17:33:55 --> Helper loaded: form_helper
INFO - 2017-03-03 17:33:55 --> Helper loaded: url_helper
INFO - 2017-03-03 17:33:55 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:33:55 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:33:55 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:33:55 --> Template Class Initialized
INFO - 2017-03-03 17:33:55 --> Model Class Initialized
INFO - 2017-03-03 17:33:55 --> Controller Class Initialized
DEBUG - 2017-03-03 17:33:55 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:33:55 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:33:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:33:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:33:58 --> Config Class Initialized
INFO - 2017-03-03 17:33:58 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:33:58 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:33:58 --> Utf8 Class Initialized
INFO - 2017-03-03 17:33:58 --> URI Class Initialized
INFO - 2017-03-03 17:33:58 --> Router Class Initialized
INFO - 2017-03-03 17:33:58 --> Output Class Initialized
INFO - 2017-03-03 17:33:58 --> Security Class Initialized
DEBUG - 2017-03-03 17:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:33:58 --> Input Class Initialized
INFO - 2017-03-03 17:33:58 --> Language Class Initialized
INFO - 2017-03-03 17:33:58 --> Language Class Initialized
INFO - 2017-03-03 17:33:58 --> Config Class Initialized
INFO - 2017-03-03 17:33:58 --> Loader Class Initialized
INFO - 2017-03-03 17:33:58 --> Helper loaded: form_helper
INFO - 2017-03-03 17:33:58 --> Helper loaded: url_helper
INFO - 2017-03-03 17:33:58 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:33:58 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:33:58 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:33:58 --> Template Class Initialized
INFO - 2017-03-03 17:33:58 --> Model Class Initialized
INFO - 2017-03-03 17:33:58 --> Controller Class Initialized
DEBUG - 2017-03-03 17:33:58 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:33:58 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:33:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:33:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:34:09 --> Config Class Initialized
INFO - 2017-03-03 17:34:09 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:34:09 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:34:09 --> Utf8 Class Initialized
INFO - 2017-03-03 17:34:09 --> URI Class Initialized
INFO - 2017-03-03 17:34:09 --> Router Class Initialized
INFO - 2017-03-03 17:34:09 --> Output Class Initialized
INFO - 2017-03-03 17:34:09 --> Security Class Initialized
DEBUG - 2017-03-03 17:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:34:09 --> Input Class Initialized
INFO - 2017-03-03 17:34:09 --> Language Class Initialized
INFO - 2017-03-03 17:34:09 --> Language Class Initialized
INFO - 2017-03-03 17:34:09 --> Config Class Initialized
INFO - 2017-03-03 17:34:09 --> Loader Class Initialized
INFO - 2017-03-03 17:34:09 --> Helper loaded: form_helper
INFO - 2017-03-03 17:34:09 --> Helper loaded: url_helper
INFO - 2017-03-03 17:34:09 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:34:09 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:34:09 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:34:09 --> Template Class Initialized
INFO - 2017-03-03 17:34:09 --> Model Class Initialized
INFO - 2017-03-03 17:34:09 --> Controller Class Initialized
DEBUG - 2017-03-03 17:34:09 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:34:09 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:34:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:34:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:34:10 --> Config Class Initialized
INFO - 2017-03-03 17:34:10 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:34:10 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:34:10 --> Utf8 Class Initialized
INFO - 2017-03-03 17:34:10 --> URI Class Initialized
INFO - 2017-03-03 17:34:10 --> Router Class Initialized
INFO - 2017-03-03 17:34:10 --> Output Class Initialized
INFO - 2017-03-03 17:34:10 --> Security Class Initialized
DEBUG - 2017-03-03 17:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:34:10 --> Input Class Initialized
INFO - 2017-03-03 17:34:10 --> Language Class Initialized
INFO - 2017-03-03 17:34:10 --> Language Class Initialized
INFO - 2017-03-03 17:34:10 --> Config Class Initialized
INFO - 2017-03-03 17:34:10 --> Loader Class Initialized
INFO - 2017-03-03 17:34:10 --> Helper loaded: form_helper
INFO - 2017-03-03 17:34:10 --> Helper loaded: url_helper
INFO - 2017-03-03 17:34:10 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:34:10 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:34:10 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:34:10 --> Template Class Initialized
INFO - 2017-03-03 17:34:10 --> Model Class Initialized
INFO - 2017-03-03 17:34:10 --> Controller Class Initialized
DEBUG - 2017-03-03 17:34:10 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:34:10 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:34:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:34:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:34:12 --> Config Class Initialized
INFO - 2017-03-03 17:34:12 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:34:12 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:34:12 --> Utf8 Class Initialized
INFO - 2017-03-03 17:34:12 --> URI Class Initialized
INFO - 2017-03-03 17:34:12 --> Router Class Initialized
INFO - 2017-03-03 17:34:12 --> Output Class Initialized
INFO - 2017-03-03 17:34:12 --> Security Class Initialized
DEBUG - 2017-03-03 17:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:34:12 --> Input Class Initialized
INFO - 2017-03-03 17:34:12 --> Language Class Initialized
INFO - 2017-03-03 17:34:12 --> Language Class Initialized
INFO - 2017-03-03 17:34:12 --> Config Class Initialized
INFO - 2017-03-03 17:34:12 --> Loader Class Initialized
INFO - 2017-03-03 17:34:12 --> Helper loaded: form_helper
INFO - 2017-03-03 17:34:12 --> Helper loaded: url_helper
INFO - 2017-03-03 17:34:12 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:34:12 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:34:12 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:34:12 --> Template Class Initialized
INFO - 2017-03-03 17:34:12 --> Model Class Initialized
INFO - 2017-03-03 17:34:12 --> Controller Class Initialized
DEBUG - 2017-03-03 17:34:12 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:34:12 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:34:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:34:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:34:13 --> Config Class Initialized
INFO - 2017-03-03 17:34:13 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:34:13 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:34:13 --> Utf8 Class Initialized
INFO - 2017-03-03 17:34:13 --> URI Class Initialized
INFO - 2017-03-03 17:34:13 --> Router Class Initialized
INFO - 2017-03-03 17:34:13 --> Output Class Initialized
INFO - 2017-03-03 17:34:13 --> Security Class Initialized
DEBUG - 2017-03-03 17:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:34:13 --> Input Class Initialized
INFO - 2017-03-03 17:34:13 --> Language Class Initialized
INFO - 2017-03-03 17:34:13 --> Language Class Initialized
INFO - 2017-03-03 17:34:13 --> Config Class Initialized
INFO - 2017-03-03 17:34:13 --> Loader Class Initialized
INFO - 2017-03-03 17:34:13 --> Helper loaded: form_helper
INFO - 2017-03-03 17:34:13 --> Helper loaded: url_helper
INFO - 2017-03-03 17:34:13 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:34:13 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:34:13 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:34:13 --> Template Class Initialized
INFO - 2017-03-03 17:34:13 --> Model Class Initialized
INFO - 2017-03-03 17:34:13 --> Controller Class Initialized
DEBUG - 2017-03-03 17:34:13 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:34:13 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:34:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:34:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:34:16 --> Config Class Initialized
INFO - 2017-03-03 17:34:16 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:34:16 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:34:16 --> Utf8 Class Initialized
INFO - 2017-03-03 17:34:16 --> URI Class Initialized
INFO - 2017-03-03 17:34:16 --> Router Class Initialized
INFO - 2017-03-03 17:34:16 --> Output Class Initialized
INFO - 2017-03-03 17:34:16 --> Security Class Initialized
DEBUG - 2017-03-03 17:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:34:16 --> Input Class Initialized
INFO - 2017-03-03 17:34:16 --> Language Class Initialized
INFO - 2017-03-03 17:34:16 --> Language Class Initialized
INFO - 2017-03-03 17:34:16 --> Config Class Initialized
INFO - 2017-03-03 17:34:16 --> Loader Class Initialized
INFO - 2017-03-03 17:34:16 --> Helper loaded: form_helper
INFO - 2017-03-03 17:34:16 --> Helper loaded: url_helper
INFO - 2017-03-03 17:34:16 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:34:16 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:34:16 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:34:16 --> Template Class Initialized
INFO - 2017-03-03 17:34:16 --> Model Class Initialized
INFO - 2017-03-03 17:34:16 --> Controller Class Initialized
DEBUG - 2017-03-03 17:34:16 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:34:16 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:34:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:34:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:34:17 --> Config Class Initialized
INFO - 2017-03-03 17:34:17 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:34:17 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:34:17 --> Utf8 Class Initialized
INFO - 2017-03-03 17:34:17 --> URI Class Initialized
INFO - 2017-03-03 17:34:17 --> Router Class Initialized
INFO - 2017-03-03 17:34:17 --> Output Class Initialized
INFO - 2017-03-03 17:34:17 --> Security Class Initialized
DEBUG - 2017-03-03 17:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:34:17 --> Input Class Initialized
INFO - 2017-03-03 17:34:17 --> Language Class Initialized
INFO - 2017-03-03 17:34:17 --> Language Class Initialized
INFO - 2017-03-03 17:34:17 --> Config Class Initialized
INFO - 2017-03-03 17:34:17 --> Loader Class Initialized
INFO - 2017-03-03 17:34:17 --> Helper loaded: form_helper
INFO - 2017-03-03 17:34:17 --> Helper loaded: url_helper
INFO - 2017-03-03 17:34:17 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:34:17 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:34:17 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:34:17 --> Template Class Initialized
INFO - 2017-03-03 17:34:17 --> Model Class Initialized
INFO - 2017-03-03 17:34:17 --> Controller Class Initialized
DEBUG - 2017-03-03 17:34:17 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:34:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:34:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:34:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:34:18 --> Config Class Initialized
INFO - 2017-03-03 17:34:18 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:34:18 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:34:18 --> Utf8 Class Initialized
INFO - 2017-03-03 17:34:18 --> URI Class Initialized
INFO - 2017-03-03 17:34:18 --> Router Class Initialized
INFO - 2017-03-03 17:34:18 --> Output Class Initialized
INFO - 2017-03-03 17:34:18 --> Security Class Initialized
DEBUG - 2017-03-03 17:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:34:18 --> Input Class Initialized
INFO - 2017-03-03 17:34:18 --> Language Class Initialized
INFO - 2017-03-03 17:34:18 --> Language Class Initialized
INFO - 2017-03-03 17:34:18 --> Config Class Initialized
INFO - 2017-03-03 17:34:18 --> Loader Class Initialized
INFO - 2017-03-03 17:34:18 --> Helper loaded: form_helper
INFO - 2017-03-03 17:34:18 --> Helper loaded: url_helper
INFO - 2017-03-03 17:34:18 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:34:18 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:34:18 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:34:18 --> Template Class Initialized
INFO - 2017-03-03 17:34:18 --> Model Class Initialized
INFO - 2017-03-03 17:34:18 --> Controller Class Initialized
DEBUG - 2017-03-03 17:34:18 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:34:18 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:34:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:34:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:34:21 --> Config Class Initialized
INFO - 2017-03-03 17:34:21 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:34:21 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:34:21 --> Utf8 Class Initialized
INFO - 2017-03-03 17:34:21 --> URI Class Initialized
INFO - 2017-03-03 17:34:21 --> Router Class Initialized
INFO - 2017-03-03 17:34:21 --> Output Class Initialized
INFO - 2017-03-03 17:34:21 --> Security Class Initialized
DEBUG - 2017-03-03 17:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:34:21 --> Input Class Initialized
INFO - 2017-03-03 17:34:21 --> Language Class Initialized
INFO - 2017-03-03 17:34:21 --> Language Class Initialized
INFO - 2017-03-03 17:34:21 --> Config Class Initialized
INFO - 2017-03-03 17:34:21 --> Loader Class Initialized
INFO - 2017-03-03 17:34:21 --> Helper loaded: form_helper
INFO - 2017-03-03 17:34:21 --> Helper loaded: url_helper
INFO - 2017-03-03 17:34:21 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:34:21 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:34:21 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:34:21 --> Template Class Initialized
INFO - 2017-03-03 17:34:21 --> Model Class Initialized
INFO - 2017-03-03 17:34:21 --> Controller Class Initialized
DEBUG - 2017-03-03 17:34:21 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:34:21 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:34:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:34:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:35:11 --> Config Class Initialized
INFO - 2017-03-03 17:35:11 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:35:11 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:35:11 --> Utf8 Class Initialized
INFO - 2017-03-03 17:35:11 --> URI Class Initialized
INFO - 2017-03-03 17:35:11 --> Router Class Initialized
INFO - 2017-03-03 17:35:11 --> Output Class Initialized
INFO - 2017-03-03 17:35:11 --> Security Class Initialized
DEBUG - 2017-03-03 17:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:35:11 --> Input Class Initialized
INFO - 2017-03-03 17:35:11 --> Language Class Initialized
INFO - 2017-03-03 17:35:11 --> Language Class Initialized
INFO - 2017-03-03 17:35:11 --> Config Class Initialized
INFO - 2017-03-03 17:35:11 --> Loader Class Initialized
INFO - 2017-03-03 17:35:11 --> Helper loaded: form_helper
INFO - 2017-03-03 17:35:11 --> Helper loaded: url_helper
INFO - 2017-03-03 17:35:11 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:35:11 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:35:11 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:35:11 --> Template Class Initialized
INFO - 2017-03-03 17:35:11 --> Model Class Initialized
INFO - 2017-03-03 17:35:11 --> Controller Class Initialized
DEBUG - 2017-03-03 17:35:11 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:35:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:35:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:35:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:38:01 --> Config Class Initialized
INFO - 2017-03-03 17:38:01 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:38:01 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:38:01 --> Utf8 Class Initialized
INFO - 2017-03-03 17:38:01 --> URI Class Initialized
INFO - 2017-03-03 17:38:01 --> Router Class Initialized
INFO - 2017-03-03 17:38:01 --> Output Class Initialized
INFO - 2017-03-03 17:38:01 --> Security Class Initialized
DEBUG - 2017-03-03 17:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:38:01 --> Input Class Initialized
INFO - 2017-03-03 17:38:01 --> Language Class Initialized
INFO - 2017-03-03 17:38:01 --> Language Class Initialized
INFO - 2017-03-03 17:38:01 --> Config Class Initialized
INFO - 2017-03-03 17:38:01 --> Loader Class Initialized
INFO - 2017-03-03 17:38:01 --> Helper loaded: form_helper
INFO - 2017-03-03 17:38:01 --> Helper loaded: url_helper
INFO - 2017-03-03 17:38:01 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:38:01 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:38:01 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:38:01 --> Template Class Initialized
INFO - 2017-03-03 17:38:01 --> Model Class Initialized
INFO - 2017-03-03 17:38:01 --> Controller Class Initialized
DEBUG - 2017-03-03 17:38:01 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:38:01 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:38:01 --> Model Class Initialized
DEBUG - 2017-03-03 17:38:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:38:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:38:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:38:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:38:01 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:38:01 --> Final output sent to browser
DEBUG - 2017-03-03 17:38:01 --> Total execution time: 0.0713
INFO - 2017-03-03 17:45:15 --> Config Class Initialized
INFO - 2017-03-03 17:45:15 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:45:15 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:45:15 --> Utf8 Class Initialized
INFO - 2017-03-03 17:45:15 --> URI Class Initialized
INFO - 2017-03-03 17:45:15 --> Router Class Initialized
INFO - 2017-03-03 17:45:15 --> Output Class Initialized
INFO - 2017-03-03 17:45:15 --> Security Class Initialized
DEBUG - 2017-03-03 17:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:45:15 --> Input Class Initialized
INFO - 2017-03-03 17:45:15 --> Language Class Initialized
INFO - 2017-03-03 17:45:15 --> Language Class Initialized
INFO - 2017-03-03 17:45:15 --> Config Class Initialized
INFO - 2017-03-03 17:45:15 --> Loader Class Initialized
INFO - 2017-03-03 17:45:15 --> Helper loaded: form_helper
INFO - 2017-03-03 17:45:15 --> Helper loaded: url_helper
INFO - 2017-03-03 17:45:15 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:45:15 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:45:15 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:45:15 --> Template Class Initialized
INFO - 2017-03-03 17:45:15 --> Model Class Initialized
INFO - 2017-03-03 17:45:15 --> Controller Class Initialized
DEBUG - 2017-03-03 17:45:15 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:45:15 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:45:15 --> Model Class Initialized
DEBUG - 2017-03-03 17:45:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:45:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:45:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:45:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:45:15 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:45:15 --> Final output sent to browser
DEBUG - 2017-03-03 17:45:15 --> Total execution time: 0.0679
INFO - 2017-03-03 17:45:19 --> Config Class Initialized
INFO - 2017-03-03 17:45:19 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:45:19 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:45:19 --> Utf8 Class Initialized
INFO - 2017-03-03 17:45:19 --> URI Class Initialized
INFO - 2017-03-03 17:45:19 --> Router Class Initialized
INFO - 2017-03-03 17:45:19 --> Output Class Initialized
INFO - 2017-03-03 17:45:19 --> Security Class Initialized
DEBUG - 2017-03-03 17:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:45:19 --> Input Class Initialized
INFO - 2017-03-03 17:45:19 --> Language Class Initialized
INFO - 2017-03-03 17:45:19 --> Language Class Initialized
INFO - 2017-03-03 17:45:19 --> Config Class Initialized
INFO - 2017-03-03 17:45:19 --> Loader Class Initialized
INFO - 2017-03-03 17:45:19 --> Helper loaded: form_helper
INFO - 2017-03-03 17:45:19 --> Helper loaded: url_helper
INFO - 2017-03-03 17:45:19 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:45:19 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:45:19 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:45:19 --> Template Class Initialized
INFO - 2017-03-03 17:45:19 --> Model Class Initialized
INFO - 2017-03-03 17:45:19 --> Controller Class Initialized
DEBUG - 2017-03-03 17:45:19 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:45:19 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:45:19 --> Final output sent to browser
DEBUG - 2017-03-03 17:45:19 --> Total execution time: 0.0108
INFO - 2017-03-03 17:45:56 --> Config Class Initialized
INFO - 2017-03-03 17:45:56 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:45:56 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:45:56 --> Utf8 Class Initialized
INFO - 2017-03-03 17:45:56 --> URI Class Initialized
INFO - 2017-03-03 17:45:56 --> Router Class Initialized
INFO - 2017-03-03 17:45:56 --> Output Class Initialized
INFO - 2017-03-03 17:45:56 --> Security Class Initialized
DEBUG - 2017-03-03 17:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:45:56 --> Input Class Initialized
INFO - 2017-03-03 17:45:56 --> Language Class Initialized
INFO - 2017-03-03 17:45:56 --> Language Class Initialized
INFO - 2017-03-03 17:45:56 --> Config Class Initialized
INFO - 2017-03-03 17:45:56 --> Loader Class Initialized
INFO - 2017-03-03 17:45:56 --> Helper loaded: form_helper
INFO - 2017-03-03 17:45:56 --> Helper loaded: url_helper
INFO - 2017-03-03 17:45:56 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:45:56 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:45:56 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:45:56 --> Template Class Initialized
INFO - 2017-03-03 17:45:56 --> Model Class Initialized
INFO - 2017-03-03 17:45:56 --> Controller Class Initialized
DEBUG - 2017-03-03 17:45:56 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:45:56 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:45:56 --> Upload Class Initialized
INFO - 2017-03-03 17:45:56 --> Model Class Initialized
INFO - 2017-03-03 17:45:56 --> Final output sent to browser
DEBUG - 2017-03-03 17:45:56 --> Total execution time: 0.0228
INFO - 2017-03-03 17:46:59 --> Config Class Initialized
INFO - 2017-03-03 17:46:59 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:46:59 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:46:59 --> Utf8 Class Initialized
INFO - 2017-03-03 17:46:59 --> URI Class Initialized
INFO - 2017-03-03 17:46:59 --> Router Class Initialized
INFO - 2017-03-03 17:46:59 --> Output Class Initialized
INFO - 2017-03-03 17:46:59 --> Security Class Initialized
DEBUG - 2017-03-03 17:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:46:59 --> Input Class Initialized
INFO - 2017-03-03 17:46:59 --> Language Class Initialized
INFO - 2017-03-03 17:46:59 --> Language Class Initialized
INFO - 2017-03-03 17:46:59 --> Config Class Initialized
INFO - 2017-03-03 17:46:59 --> Loader Class Initialized
INFO - 2017-03-03 17:46:59 --> Helper loaded: form_helper
INFO - 2017-03-03 17:46:59 --> Helper loaded: url_helper
INFO - 2017-03-03 17:46:59 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:46:59 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:46:59 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:46:59 --> Template Class Initialized
INFO - 2017-03-03 17:46:59 --> Model Class Initialized
INFO - 2017-03-03 17:46:59 --> Controller Class Initialized
DEBUG - 2017-03-03 17:46:59 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:46:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:46:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:46:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:47:00 --> Config Class Initialized
INFO - 2017-03-03 17:47:00 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:47:00 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:47:00 --> Utf8 Class Initialized
INFO - 2017-03-03 17:47:00 --> URI Class Initialized
INFO - 2017-03-03 17:47:00 --> Router Class Initialized
INFO - 2017-03-03 17:47:00 --> Output Class Initialized
INFO - 2017-03-03 17:47:00 --> Security Class Initialized
DEBUG - 2017-03-03 17:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:47:00 --> Input Class Initialized
INFO - 2017-03-03 17:47:00 --> Language Class Initialized
INFO - 2017-03-03 17:47:00 --> Language Class Initialized
INFO - 2017-03-03 17:47:00 --> Config Class Initialized
INFO - 2017-03-03 17:47:00 --> Loader Class Initialized
INFO - 2017-03-03 17:47:00 --> Helper loaded: form_helper
INFO - 2017-03-03 17:47:00 --> Helper loaded: url_helper
INFO - 2017-03-03 17:47:00 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:47:00 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:47:00 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:47:00 --> Template Class Initialized
INFO - 2017-03-03 17:47:00 --> Model Class Initialized
INFO - 2017-03-03 17:47:00 --> Controller Class Initialized
DEBUG - 2017-03-03 17:47:00 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:47:00 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:47:00 --> Model Class Initialized
DEBUG - 2017-03-03 17:47:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:47:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:47:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:47:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:47:00 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:47:00 --> Final output sent to browser
DEBUG - 2017-03-03 17:47:00 --> Total execution time: 0.0154
INFO - 2017-03-03 17:47:01 --> Config Class Initialized
INFO - 2017-03-03 17:47:01 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:47:01 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:47:01 --> Utf8 Class Initialized
INFO - 2017-03-03 17:47:01 --> URI Class Initialized
INFO - 2017-03-03 17:47:01 --> Router Class Initialized
INFO - 2017-03-03 17:47:01 --> Output Class Initialized
INFO - 2017-03-03 17:47:01 --> Security Class Initialized
DEBUG - 2017-03-03 17:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:47:01 --> Input Class Initialized
INFO - 2017-03-03 17:47:01 --> Language Class Initialized
INFO - 2017-03-03 17:47:01 --> Language Class Initialized
INFO - 2017-03-03 17:47:01 --> Config Class Initialized
INFO - 2017-03-03 17:47:01 --> Loader Class Initialized
INFO - 2017-03-03 17:47:01 --> Helper loaded: form_helper
INFO - 2017-03-03 17:47:01 --> Helper loaded: url_helper
INFO - 2017-03-03 17:47:01 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:47:01 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:47:01 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:47:01 --> Template Class Initialized
INFO - 2017-03-03 17:47:01 --> Model Class Initialized
INFO - 2017-03-03 17:47:01 --> Controller Class Initialized
DEBUG - 2017-03-03 17:47:01 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:47:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:47:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:47:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:47:06 --> Config Class Initialized
INFO - 2017-03-03 17:47:06 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:47:06 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:47:06 --> Utf8 Class Initialized
INFO - 2017-03-03 17:47:06 --> URI Class Initialized
INFO - 2017-03-03 17:47:06 --> Router Class Initialized
INFO - 2017-03-03 17:47:06 --> Output Class Initialized
INFO - 2017-03-03 17:47:06 --> Security Class Initialized
DEBUG - 2017-03-03 17:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:47:06 --> Input Class Initialized
INFO - 2017-03-03 17:47:06 --> Language Class Initialized
INFO - 2017-03-03 17:47:06 --> Language Class Initialized
INFO - 2017-03-03 17:47:06 --> Config Class Initialized
INFO - 2017-03-03 17:47:06 --> Loader Class Initialized
INFO - 2017-03-03 17:47:06 --> Helper loaded: form_helper
INFO - 2017-03-03 17:47:06 --> Helper loaded: url_helper
INFO - 2017-03-03 17:47:06 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:47:06 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:47:06 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:47:06 --> Template Class Initialized
INFO - 2017-03-03 17:47:06 --> Model Class Initialized
INFO - 2017-03-03 17:47:06 --> Controller Class Initialized
DEBUG - 2017-03-03 17:47:06 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:47:06 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:47:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:47:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:47:31 --> Config Class Initialized
INFO - 2017-03-03 17:47:31 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:47:31 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:47:31 --> Utf8 Class Initialized
INFO - 2017-03-03 17:47:31 --> URI Class Initialized
INFO - 2017-03-03 17:47:31 --> Router Class Initialized
INFO - 2017-03-03 17:47:31 --> Output Class Initialized
INFO - 2017-03-03 17:47:31 --> Security Class Initialized
DEBUG - 2017-03-03 17:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:47:31 --> Input Class Initialized
INFO - 2017-03-03 17:47:31 --> Language Class Initialized
INFO - 2017-03-03 17:47:31 --> Language Class Initialized
INFO - 2017-03-03 17:47:31 --> Config Class Initialized
INFO - 2017-03-03 17:47:31 --> Loader Class Initialized
INFO - 2017-03-03 17:47:31 --> Helper loaded: form_helper
INFO - 2017-03-03 17:47:31 --> Helper loaded: url_helper
INFO - 2017-03-03 17:47:31 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:47:31 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:47:31 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:47:31 --> Template Class Initialized
INFO - 2017-03-03 17:47:31 --> Model Class Initialized
INFO - 2017-03-03 17:47:31 --> Controller Class Initialized
DEBUG - 2017-03-03 17:47:31 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:47:31 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:47:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:47:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:47:33 --> Config Class Initialized
INFO - 2017-03-03 17:47:33 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:47:33 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:47:33 --> Utf8 Class Initialized
INFO - 2017-03-03 17:47:33 --> URI Class Initialized
INFO - 2017-03-03 17:47:33 --> Router Class Initialized
INFO - 2017-03-03 17:47:33 --> Output Class Initialized
INFO - 2017-03-03 17:47:33 --> Security Class Initialized
DEBUG - 2017-03-03 17:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:47:33 --> Input Class Initialized
INFO - 2017-03-03 17:47:33 --> Language Class Initialized
INFO - 2017-03-03 17:47:33 --> Language Class Initialized
INFO - 2017-03-03 17:47:33 --> Config Class Initialized
INFO - 2017-03-03 17:47:33 --> Loader Class Initialized
INFO - 2017-03-03 17:47:33 --> Helper loaded: form_helper
INFO - 2017-03-03 17:47:33 --> Helper loaded: url_helper
INFO - 2017-03-03 17:47:33 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:47:33 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:47:33 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:47:33 --> Template Class Initialized
INFO - 2017-03-03 17:47:33 --> Model Class Initialized
INFO - 2017-03-03 17:47:33 --> Controller Class Initialized
DEBUG - 2017-03-03 17:47:33 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:47:33 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:47:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:47:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:47:54 --> Config Class Initialized
INFO - 2017-03-03 17:47:54 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:47:54 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:47:54 --> Utf8 Class Initialized
INFO - 2017-03-03 17:47:54 --> URI Class Initialized
INFO - 2017-03-03 17:47:54 --> Router Class Initialized
INFO - 2017-03-03 17:47:54 --> Output Class Initialized
INFO - 2017-03-03 17:47:54 --> Security Class Initialized
DEBUG - 2017-03-03 17:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:47:54 --> Input Class Initialized
INFO - 2017-03-03 17:47:54 --> Language Class Initialized
INFO - 2017-03-03 17:47:54 --> Language Class Initialized
INFO - 2017-03-03 17:47:54 --> Config Class Initialized
INFO - 2017-03-03 17:47:54 --> Loader Class Initialized
INFO - 2017-03-03 17:47:54 --> Helper loaded: form_helper
INFO - 2017-03-03 17:47:54 --> Helper loaded: url_helper
INFO - 2017-03-03 17:47:54 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:47:54 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:47:54 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:47:54 --> Template Class Initialized
INFO - 2017-03-03 17:47:54 --> Model Class Initialized
INFO - 2017-03-03 17:47:54 --> Controller Class Initialized
DEBUG - 2017-03-03 17:47:54 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:47:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:47:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:47:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:47:55 --> Config Class Initialized
INFO - 2017-03-03 17:47:55 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:47:55 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:47:55 --> Utf8 Class Initialized
INFO - 2017-03-03 17:47:55 --> URI Class Initialized
INFO - 2017-03-03 17:47:55 --> Router Class Initialized
INFO - 2017-03-03 17:47:55 --> Output Class Initialized
INFO - 2017-03-03 17:47:55 --> Security Class Initialized
DEBUG - 2017-03-03 17:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:47:55 --> Input Class Initialized
INFO - 2017-03-03 17:47:55 --> Language Class Initialized
INFO - 2017-03-03 17:47:55 --> Language Class Initialized
INFO - 2017-03-03 17:47:55 --> Config Class Initialized
INFO - 2017-03-03 17:47:55 --> Loader Class Initialized
INFO - 2017-03-03 17:47:55 --> Helper loaded: form_helper
INFO - 2017-03-03 17:47:55 --> Helper loaded: url_helper
INFO - 2017-03-03 17:47:55 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:47:55 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:47:55 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:47:55 --> Template Class Initialized
INFO - 2017-03-03 17:47:55 --> Model Class Initialized
INFO - 2017-03-03 17:47:55 --> Controller Class Initialized
DEBUG - 2017-03-03 17:47:55 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:47:55 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:47:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:47:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:47:56 --> Config Class Initialized
INFO - 2017-03-03 17:47:56 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:47:56 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:47:56 --> Utf8 Class Initialized
INFO - 2017-03-03 17:47:56 --> URI Class Initialized
INFO - 2017-03-03 17:47:56 --> Router Class Initialized
INFO - 2017-03-03 17:47:56 --> Output Class Initialized
INFO - 2017-03-03 17:47:56 --> Security Class Initialized
DEBUG - 2017-03-03 17:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:47:56 --> Input Class Initialized
INFO - 2017-03-03 17:47:56 --> Language Class Initialized
INFO - 2017-03-03 17:47:56 --> Language Class Initialized
INFO - 2017-03-03 17:47:56 --> Config Class Initialized
INFO - 2017-03-03 17:47:56 --> Loader Class Initialized
INFO - 2017-03-03 17:47:56 --> Helper loaded: form_helper
INFO - 2017-03-03 17:47:56 --> Helper loaded: url_helper
INFO - 2017-03-03 17:47:56 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:47:56 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:47:56 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:47:56 --> Template Class Initialized
INFO - 2017-03-03 17:47:56 --> Model Class Initialized
INFO - 2017-03-03 17:47:56 --> Controller Class Initialized
DEBUG - 2017-03-03 17:47:56 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:47:56 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:47:56 --> Model Class Initialized
DEBUG - 2017-03-03 17:47:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:47:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:47:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:47:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:47:56 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:47:56 --> Final output sent to browser
DEBUG - 2017-03-03 17:47:56 --> Total execution time: 0.0170
INFO - 2017-03-03 17:47:56 --> Config Class Initialized
INFO - 2017-03-03 17:47:56 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:47:56 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:47:56 --> Utf8 Class Initialized
INFO - 2017-03-03 17:47:56 --> URI Class Initialized
INFO - 2017-03-03 17:47:56 --> Router Class Initialized
INFO - 2017-03-03 17:47:56 --> Output Class Initialized
INFO - 2017-03-03 17:47:56 --> Security Class Initialized
DEBUG - 2017-03-03 17:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:47:56 --> Input Class Initialized
INFO - 2017-03-03 17:47:56 --> Language Class Initialized
INFO - 2017-03-03 17:47:56 --> Language Class Initialized
INFO - 2017-03-03 17:47:56 --> Config Class Initialized
INFO - 2017-03-03 17:47:56 --> Loader Class Initialized
INFO - 2017-03-03 17:47:56 --> Helper loaded: form_helper
INFO - 2017-03-03 17:47:56 --> Helper loaded: url_helper
INFO - 2017-03-03 17:47:56 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:47:56 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:47:56 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:47:56 --> Template Class Initialized
INFO - 2017-03-03 17:47:56 --> Model Class Initialized
INFO - 2017-03-03 17:47:56 --> Controller Class Initialized
DEBUG - 2017-03-03 17:47:56 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:47:56 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:47:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:47:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:47:59 --> Config Class Initialized
INFO - 2017-03-03 17:47:59 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:47:59 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:47:59 --> Utf8 Class Initialized
INFO - 2017-03-03 17:47:59 --> URI Class Initialized
INFO - 2017-03-03 17:47:59 --> Router Class Initialized
INFO - 2017-03-03 17:47:59 --> Output Class Initialized
INFO - 2017-03-03 17:47:59 --> Security Class Initialized
DEBUG - 2017-03-03 17:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:47:59 --> Input Class Initialized
INFO - 2017-03-03 17:47:59 --> Language Class Initialized
INFO - 2017-03-03 17:47:59 --> Language Class Initialized
INFO - 2017-03-03 17:47:59 --> Config Class Initialized
INFO - 2017-03-03 17:47:59 --> Loader Class Initialized
INFO - 2017-03-03 17:47:59 --> Helper loaded: form_helper
INFO - 2017-03-03 17:47:59 --> Helper loaded: url_helper
INFO - 2017-03-03 17:47:59 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:47:59 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:47:59 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:47:59 --> Template Class Initialized
INFO - 2017-03-03 17:47:59 --> Model Class Initialized
INFO - 2017-03-03 17:47:59 --> Controller Class Initialized
DEBUG - 2017-03-03 17:47:59 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:47:59 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:47:59 --> Model Class Initialized
DEBUG - 2017-03-03 17:47:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:47:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:47:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:47:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:47:59 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:47:59 --> Final output sent to browser
DEBUG - 2017-03-03 17:47:59 --> Total execution time: 0.0169
INFO - 2017-03-03 17:47:59 --> Config Class Initialized
INFO - 2017-03-03 17:47:59 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:47:59 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:47:59 --> Utf8 Class Initialized
INFO - 2017-03-03 17:47:59 --> URI Class Initialized
INFO - 2017-03-03 17:47:59 --> Router Class Initialized
INFO - 2017-03-03 17:47:59 --> Output Class Initialized
INFO - 2017-03-03 17:47:59 --> Security Class Initialized
DEBUG - 2017-03-03 17:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:47:59 --> Input Class Initialized
INFO - 2017-03-03 17:47:59 --> Language Class Initialized
INFO - 2017-03-03 17:47:59 --> Language Class Initialized
INFO - 2017-03-03 17:47:59 --> Config Class Initialized
INFO - 2017-03-03 17:47:59 --> Loader Class Initialized
INFO - 2017-03-03 17:47:59 --> Helper loaded: form_helper
INFO - 2017-03-03 17:47:59 --> Helper loaded: url_helper
INFO - 2017-03-03 17:47:59 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:47:59 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:47:59 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:47:59 --> Template Class Initialized
INFO - 2017-03-03 17:47:59 --> Model Class Initialized
INFO - 2017-03-03 17:47:59 --> Controller Class Initialized
DEBUG - 2017-03-03 17:47:59 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:47:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:47:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:47:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:48:04 --> Config Class Initialized
INFO - 2017-03-03 17:48:04 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:48:04 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:48:04 --> Utf8 Class Initialized
INFO - 2017-03-03 17:48:04 --> URI Class Initialized
INFO - 2017-03-03 17:48:04 --> Router Class Initialized
INFO - 2017-03-03 17:48:04 --> Output Class Initialized
INFO - 2017-03-03 17:48:04 --> Security Class Initialized
DEBUG - 2017-03-03 17:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:48:04 --> Input Class Initialized
INFO - 2017-03-03 17:48:04 --> Language Class Initialized
INFO - 2017-03-03 17:48:04 --> Language Class Initialized
INFO - 2017-03-03 17:48:04 --> Config Class Initialized
INFO - 2017-03-03 17:48:04 --> Loader Class Initialized
INFO - 2017-03-03 17:48:04 --> Helper loaded: form_helper
INFO - 2017-03-03 17:48:04 --> Helper loaded: url_helper
INFO - 2017-03-03 17:48:04 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:48:04 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:48:04 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:48:04 --> Template Class Initialized
INFO - 2017-03-03 17:48:04 --> Model Class Initialized
INFO - 2017-03-03 17:48:04 --> Controller Class Initialized
DEBUG - 2017-03-03 17:48:04 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:48:04 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:48:04 --> Final output sent to browser
DEBUG - 2017-03-03 17:48:04 --> Total execution time: 0.0086
INFO - 2017-03-03 17:48:54 --> Config Class Initialized
INFO - 2017-03-03 17:48:54 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:48:54 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:48:54 --> Utf8 Class Initialized
INFO - 2017-03-03 17:48:54 --> URI Class Initialized
INFO - 2017-03-03 17:48:54 --> Router Class Initialized
INFO - 2017-03-03 17:48:54 --> Output Class Initialized
INFO - 2017-03-03 17:48:54 --> Security Class Initialized
DEBUG - 2017-03-03 17:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:48:54 --> Input Class Initialized
INFO - 2017-03-03 17:48:54 --> Language Class Initialized
INFO - 2017-03-03 17:48:54 --> Language Class Initialized
INFO - 2017-03-03 17:48:54 --> Config Class Initialized
INFO - 2017-03-03 17:48:54 --> Loader Class Initialized
INFO - 2017-03-03 17:48:54 --> Helper loaded: form_helper
INFO - 2017-03-03 17:48:54 --> Helper loaded: url_helper
INFO - 2017-03-03 17:48:54 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:48:54 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:48:54 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:48:54 --> Template Class Initialized
INFO - 2017-03-03 17:48:54 --> Model Class Initialized
INFO - 2017-03-03 17:48:54 --> Controller Class Initialized
DEBUG - 2017-03-03 17:48:54 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:48:54 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:48:54 --> Upload Class Initialized
INFO - 2017-03-03 17:48:54 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-03-03 17:48:54 --> The upload path does not appear to be valid.
INFO - 2017-03-03 17:48:54 --> Model Class Initialized
INFO - 2017-03-03 17:48:54 --> Final output sent to browser
DEBUG - 2017-03-03 17:48:54 --> Total execution time: 0.0096
INFO - 2017-03-03 17:48:59 --> Config Class Initialized
INFO - 2017-03-03 17:48:59 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:48:59 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:48:59 --> Utf8 Class Initialized
INFO - 2017-03-03 17:48:59 --> URI Class Initialized
INFO - 2017-03-03 17:48:59 --> Router Class Initialized
INFO - 2017-03-03 17:48:59 --> Output Class Initialized
INFO - 2017-03-03 17:48:59 --> Security Class Initialized
DEBUG - 2017-03-03 17:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:48:59 --> Input Class Initialized
INFO - 2017-03-03 17:48:59 --> Language Class Initialized
INFO - 2017-03-03 17:48:59 --> Language Class Initialized
INFO - 2017-03-03 17:48:59 --> Config Class Initialized
INFO - 2017-03-03 17:48:59 --> Loader Class Initialized
INFO - 2017-03-03 17:48:59 --> Helper loaded: form_helper
INFO - 2017-03-03 17:48:59 --> Helper loaded: url_helper
INFO - 2017-03-03 17:48:59 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:48:59 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:48:59 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:48:59 --> Template Class Initialized
INFO - 2017-03-03 17:48:59 --> Model Class Initialized
INFO - 2017-03-03 17:48:59 --> Controller Class Initialized
DEBUG - 2017-03-03 17:48:59 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:48:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:48:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:48:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:49:03 --> Config Class Initialized
INFO - 2017-03-03 17:49:03 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:49:03 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:49:03 --> Utf8 Class Initialized
INFO - 2017-03-03 17:49:03 --> URI Class Initialized
INFO - 2017-03-03 17:49:03 --> Router Class Initialized
INFO - 2017-03-03 17:49:03 --> Output Class Initialized
INFO - 2017-03-03 17:49:03 --> Security Class Initialized
DEBUG - 2017-03-03 17:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:49:03 --> Input Class Initialized
INFO - 2017-03-03 17:49:03 --> Language Class Initialized
INFO - 2017-03-03 17:49:03 --> Language Class Initialized
INFO - 2017-03-03 17:49:03 --> Config Class Initialized
INFO - 2017-03-03 17:49:03 --> Loader Class Initialized
INFO - 2017-03-03 17:49:03 --> Helper loaded: form_helper
INFO - 2017-03-03 17:49:03 --> Helper loaded: url_helper
INFO - 2017-03-03 17:49:03 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:49:03 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:49:03 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:49:03 --> Template Class Initialized
INFO - 2017-03-03 17:49:03 --> Model Class Initialized
INFO - 2017-03-03 17:49:03 --> Controller Class Initialized
DEBUG - 2017-03-03 17:49:03 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:49:03 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:49:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:49:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:49:05 --> Config Class Initialized
INFO - 2017-03-03 17:49:05 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:49:05 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:49:05 --> Utf8 Class Initialized
INFO - 2017-03-03 17:49:05 --> URI Class Initialized
INFO - 2017-03-03 17:49:05 --> Router Class Initialized
INFO - 2017-03-03 17:49:05 --> Output Class Initialized
INFO - 2017-03-03 17:49:05 --> Security Class Initialized
DEBUG - 2017-03-03 17:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:49:05 --> Input Class Initialized
INFO - 2017-03-03 17:49:05 --> Language Class Initialized
INFO - 2017-03-03 17:49:05 --> Language Class Initialized
INFO - 2017-03-03 17:49:05 --> Config Class Initialized
INFO - 2017-03-03 17:49:05 --> Loader Class Initialized
INFO - 2017-03-03 17:49:05 --> Helper loaded: form_helper
INFO - 2017-03-03 17:49:05 --> Helper loaded: url_helper
INFO - 2017-03-03 17:49:05 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:49:05 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:49:05 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:49:05 --> Template Class Initialized
INFO - 2017-03-03 17:49:05 --> Model Class Initialized
INFO - 2017-03-03 17:49:05 --> Controller Class Initialized
DEBUG - 2017-03-03 17:49:05 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:49:05 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:49:05 --> Model Class Initialized
DEBUG - 2017-03-03 17:49:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:49:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:49:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:49:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:49:05 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:49:05 --> Final output sent to browser
DEBUG - 2017-03-03 17:49:05 --> Total execution time: 0.0157
INFO - 2017-03-03 17:49:06 --> Config Class Initialized
INFO - 2017-03-03 17:49:06 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:49:06 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:49:06 --> Utf8 Class Initialized
INFO - 2017-03-03 17:49:06 --> URI Class Initialized
INFO - 2017-03-03 17:49:06 --> Router Class Initialized
INFO - 2017-03-03 17:49:06 --> Output Class Initialized
INFO - 2017-03-03 17:49:06 --> Security Class Initialized
DEBUG - 2017-03-03 17:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:49:06 --> Input Class Initialized
INFO - 2017-03-03 17:49:06 --> Language Class Initialized
INFO - 2017-03-03 17:49:06 --> Language Class Initialized
INFO - 2017-03-03 17:49:06 --> Config Class Initialized
INFO - 2017-03-03 17:49:06 --> Loader Class Initialized
INFO - 2017-03-03 17:49:06 --> Helper loaded: form_helper
INFO - 2017-03-03 17:49:06 --> Helper loaded: url_helper
INFO - 2017-03-03 17:49:06 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:49:06 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:49:06 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:49:06 --> Template Class Initialized
INFO - 2017-03-03 17:49:06 --> Model Class Initialized
INFO - 2017-03-03 17:49:06 --> Controller Class Initialized
DEBUG - 2017-03-03 17:49:06 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:49:06 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:49:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:49:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:56:19 --> Config Class Initialized
INFO - 2017-03-03 17:56:19 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:56:19 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:56:19 --> Utf8 Class Initialized
INFO - 2017-03-03 17:56:19 --> URI Class Initialized
INFO - 2017-03-03 17:56:19 --> Router Class Initialized
INFO - 2017-03-03 17:56:19 --> Output Class Initialized
INFO - 2017-03-03 17:56:19 --> Security Class Initialized
DEBUG - 2017-03-03 17:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:56:19 --> Input Class Initialized
INFO - 2017-03-03 17:56:19 --> Language Class Initialized
INFO - 2017-03-03 17:56:19 --> Language Class Initialized
INFO - 2017-03-03 17:56:19 --> Config Class Initialized
INFO - 2017-03-03 17:56:19 --> Loader Class Initialized
INFO - 2017-03-03 17:56:19 --> Helper loaded: form_helper
INFO - 2017-03-03 17:56:19 --> Helper loaded: url_helper
INFO - 2017-03-03 17:56:19 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:56:19 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:56:19 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:56:19 --> Template Class Initialized
INFO - 2017-03-03 17:56:19 --> Model Class Initialized
INFO - 2017-03-03 17:56:19 --> Controller Class Initialized
DEBUG - 2017-03-03 17:56:19 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:56:19 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:56:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:56:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:56:21 --> Config Class Initialized
INFO - 2017-03-03 17:56:21 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:56:21 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:56:21 --> Utf8 Class Initialized
INFO - 2017-03-03 17:56:21 --> URI Class Initialized
INFO - 2017-03-03 17:56:21 --> Router Class Initialized
INFO - 2017-03-03 17:56:21 --> Output Class Initialized
INFO - 2017-03-03 17:56:21 --> Security Class Initialized
DEBUG - 2017-03-03 17:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:56:21 --> Input Class Initialized
INFO - 2017-03-03 17:56:21 --> Language Class Initialized
INFO - 2017-03-03 17:56:21 --> Language Class Initialized
INFO - 2017-03-03 17:56:21 --> Config Class Initialized
INFO - 2017-03-03 17:56:21 --> Loader Class Initialized
INFO - 2017-03-03 17:56:21 --> Helper loaded: form_helper
INFO - 2017-03-03 17:56:21 --> Helper loaded: url_helper
INFO - 2017-03-03 17:56:21 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:56:21 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:56:21 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:56:21 --> Template Class Initialized
INFO - 2017-03-03 17:56:21 --> Model Class Initialized
INFO - 2017-03-03 17:56:21 --> Controller Class Initialized
DEBUG - 2017-03-03 17:56:21 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:56:21 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:56:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:56:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:56:24 --> Config Class Initialized
INFO - 2017-03-03 17:56:24 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:56:24 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:56:24 --> Utf8 Class Initialized
INFO - 2017-03-03 17:56:24 --> URI Class Initialized
INFO - 2017-03-03 17:56:24 --> Router Class Initialized
INFO - 2017-03-03 17:56:24 --> Output Class Initialized
INFO - 2017-03-03 17:56:24 --> Security Class Initialized
DEBUG - 2017-03-03 17:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:56:24 --> Input Class Initialized
INFO - 2017-03-03 17:56:24 --> Language Class Initialized
INFO - 2017-03-03 17:56:24 --> Language Class Initialized
INFO - 2017-03-03 17:56:24 --> Config Class Initialized
INFO - 2017-03-03 17:56:24 --> Loader Class Initialized
INFO - 2017-03-03 17:56:24 --> Helper loaded: form_helper
INFO - 2017-03-03 17:56:24 --> Helper loaded: url_helper
INFO - 2017-03-03 17:56:24 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:56:24 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:56:24 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:56:24 --> Template Class Initialized
INFO - 2017-03-03 17:56:24 --> Model Class Initialized
INFO - 2017-03-03 17:56:24 --> Controller Class Initialized
DEBUG - 2017-03-03 17:56:24 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:56:24 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:56:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:56:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:56:25 --> Config Class Initialized
INFO - 2017-03-03 17:56:25 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:56:25 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:56:25 --> Utf8 Class Initialized
INFO - 2017-03-03 17:56:25 --> URI Class Initialized
INFO - 2017-03-03 17:56:25 --> Router Class Initialized
INFO - 2017-03-03 17:56:25 --> Output Class Initialized
INFO - 2017-03-03 17:56:25 --> Security Class Initialized
DEBUG - 2017-03-03 17:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:56:25 --> Input Class Initialized
INFO - 2017-03-03 17:56:25 --> Language Class Initialized
INFO - 2017-03-03 17:56:25 --> Language Class Initialized
INFO - 2017-03-03 17:56:25 --> Config Class Initialized
INFO - 2017-03-03 17:56:25 --> Loader Class Initialized
INFO - 2017-03-03 17:56:25 --> Helper loaded: form_helper
INFO - 2017-03-03 17:56:25 --> Helper loaded: url_helper
INFO - 2017-03-03 17:56:25 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:56:25 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:56:25 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:56:25 --> Template Class Initialized
INFO - 2017-03-03 17:56:25 --> Model Class Initialized
INFO - 2017-03-03 17:56:25 --> Controller Class Initialized
DEBUG - 2017-03-03 17:56:25 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:56:25 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:56:25 --> Model Class Initialized
DEBUG - 2017-03-03 17:56:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:56:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:56:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:56:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:56:25 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:56:25 --> Final output sent to browser
DEBUG - 2017-03-03 17:56:25 --> Total execution time: 0.0218
INFO - 2017-03-03 17:56:25 --> Config Class Initialized
INFO - 2017-03-03 17:56:25 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:56:25 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:56:25 --> Utf8 Class Initialized
INFO - 2017-03-03 17:56:25 --> URI Class Initialized
INFO - 2017-03-03 17:56:25 --> Router Class Initialized
INFO - 2017-03-03 17:56:25 --> Output Class Initialized
INFO - 2017-03-03 17:56:25 --> Security Class Initialized
DEBUG - 2017-03-03 17:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:56:25 --> Input Class Initialized
INFO - 2017-03-03 17:56:25 --> Language Class Initialized
INFO - 2017-03-03 17:56:25 --> Language Class Initialized
INFO - 2017-03-03 17:56:25 --> Config Class Initialized
INFO - 2017-03-03 17:56:25 --> Loader Class Initialized
INFO - 2017-03-03 17:56:25 --> Helper loaded: form_helper
INFO - 2017-03-03 17:56:25 --> Helper loaded: url_helper
INFO - 2017-03-03 17:56:25 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:56:25 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:56:25 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:56:25 --> Template Class Initialized
INFO - 2017-03-03 17:56:25 --> Model Class Initialized
INFO - 2017-03-03 17:56:25 --> Controller Class Initialized
DEBUG - 2017-03-03 17:56:25 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:56:25 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:56:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:56:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:56:27 --> Config Class Initialized
INFO - 2017-03-03 17:56:27 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:56:27 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:56:27 --> Utf8 Class Initialized
INFO - 2017-03-03 17:56:27 --> URI Class Initialized
INFO - 2017-03-03 17:56:27 --> Router Class Initialized
INFO - 2017-03-03 17:56:27 --> Output Class Initialized
INFO - 2017-03-03 17:56:27 --> Security Class Initialized
DEBUG - 2017-03-03 17:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:56:27 --> Input Class Initialized
INFO - 2017-03-03 17:56:27 --> Language Class Initialized
INFO - 2017-03-03 17:56:27 --> Language Class Initialized
INFO - 2017-03-03 17:56:27 --> Config Class Initialized
INFO - 2017-03-03 17:56:27 --> Loader Class Initialized
INFO - 2017-03-03 17:56:27 --> Helper loaded: form_helper
INFO - 2017-03-03 17:56:27 --> Helper loaded: url_helper
INFO - 2017-03-03 17:56:27 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:56:27 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:56:27 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:56:27 --> Template Class Initialized
INFO - 2017-03-03 17:56:27 --> Model Class Initialized
INFO - 2017-03-03 17:56:27 --> Controller Class Initialized
DEBUG - 2017-03-03 17:56:27 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:56:27 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:56:27 --> Model Class Initialized
DEBUG - 2017-03-03 17:56:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:56:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:56:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:56:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:56:27 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:56:27 --> Final output sent to browser
DEBUG - 2017-03-03 17:56:27 --> Total execution time: 0.0168
INFO - 2017-03-03 17:56:27 --> Config Class Initialized
INFO - 2017-03-03 17:56:27 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:56:27 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:56:27 --> Utf8 Class Initialized
INFO - 2017-03-03 17:56:27 --> URI Class Initialized
INFO - 2017-03-03 17:56:27 --> Router Class Initialized
INFO - 2017-03-03 17:56:27 --> Output Class Initialized
INFO - 2017-03-03 17:56:27 --> Security Class Initialized
DEBUG - 2017-03-03 17:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:56:27 --> Input Class Initialized
INFO - 2017-03-03 17:56:27 --> Language Class Initialized
INFO - 2017-03-03 17:56:27 --> Language Class Initialized
INFO - 2017-03-03 17:56:27 --> Config Class Initialized
INFO - 2017-03-03 17:56:27 --> Loader Class Initialized
INFO - 2017-03-03 17:56:27 --> Helper loaded: form_helper
INFO - 2017-03-03 17:56:27 --> Helper loaded: url_helper
INFO - 2017-03-03 17:56:27 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:56:27 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:56:27 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:56:27 --> Template Class Initialized
INFO - 2017-03-03 17:56:27 --> Model Class Initialized
INFO - 2017-03-03 17:56:27 --> Controller Class Initialized
DEBUG - 2017-03-03 17:56:27 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:56:27 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:56:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:56:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:56:29 --> Config Class Initialized
INFO - 2017-03-03 17:56:29 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:56:29 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:56:29 --> Utf8 Class Initialized
INFO - 2017-03-03 17:56:29 --> URI Class Initialized
INFO - 2017-03-03 17:56:29 --> Router Class Initialized
INFO - 2017-03-03 17:56:29 --> Output Class Initialized
INFO - 2017-03-03 17:56:29 --> Security Class Initialized
DEBUG - 2017-03-03 17:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:56:29 --> Input Class Initialized
INFO - 2017-03-03 17:56:29 --> Language Class Initialized
INFO - 2017-03-03 17:56:29 --> Language Class Initialized
INFO - 2017-03-03 17:56:29 --> Config Class Initialized
INFO - 2017-03-03 17:56:29 --> Loader Class Initialized
INFO - 2017-03-03 17:56:29 --> Helper loaded: form_helper
INFO - 2017-03-03 17:56:29 --> Helper loaded: url_helper
INFO - 2017-03-03 17:56:29 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:56:29 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:56:29 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:56:29 --> Template Class Initialized
INFO - 2017-03-03 17:56:29 --> Model Class Initialized
INFO - 2017-03-03 17:56:29 --> Controller Class Initialized
DEBUG - 2017-03-03 17:56:29 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:56:29 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:56:29 --> Final output sent to browser
DEBUG - 2017-03-03 17:56:29 --> Total execution time: 0.0130
INFO - 2017-03-03 17:56:41 --> Config Class Initialized
INFO - 2017-03-03 17:56:41 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:56:41 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:56:41 --> Utf8 Class Initialized
INFO - 2017-03-03 17:56:41 --> URI Class Initialized
INFO - 2017-03-03 17:56:41 --> Router Class Initialized
INFO - 2017-03-03 17:56:41 --> Output Class Initialized
INFO - 2017-03-03 17:56:41 --> Security Class Initialized
DEBUG - 2017-03-03 17:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:56:41 --> Input Class Initialized
INFO - 2017-03-03 17:56:41 --> Language Class Initialized
INFO - 2017-03-03 17:56:41 --> Language Class Initialized
INFO - 2017-03-03 17:56:41 --> Config Class Initialized
INFO - 2017-03-03 17:56:41 --> Loader Class Initialized
INFO - 2017-03-03 17:56:41 --> Helper loaded: form_helper
INFO - 2017-03-03 17:56:41 --> Helper loaded: url_helper
INFO - 2017-03-03 17:56:41 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:56:41 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:56:41 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:56:41 --> Template Class Initialized
INFO - 2017-03-03 17:56:41 --> Model Class Initialized
INFO - 2017-03-03 17:56:41 --> Controller Class Initialized
DEBUG - 2017-03-03 17:56:41 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:56:41 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:56:41 --> Upload Class Initialized
INFO - 2017-03-03 17:56:41 --> Model Class Initialized
INFO - 2017-03-03 17:56:41 --> Final output sent to browser
DEBUG - 2017-03-03 17:56:41 --> Total execution time: 0.0198
INFO - 2017-03-03 17:56:46 --> Config Class Initialized
INFO - 2017-03-03 17:56:46 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:56:46 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:56:46 --> Utf8 Class Initialized
INFO - 2017-03-03 17:56:46 --> URI Class Initialized
INFO - 2017-03-03 17:56:46 --> Router Class Initialized
INFO - 2017-03-03 17:56:46 --> Output Class Initialized
INFO - 2017-03-03 17:56:46 --> Security Class Initialized
DEBUG - 2017-03-03 17:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:56:46 --> Input Class Initialized
INFO - 2017-03-03 17:56:46 --> Language Class Initialized
INFO - 2017-03-03 17:56:46 --> Language Class Initialized
INFO - 2017-03-03 17:56:46 --> Config Class Initialized
INFO - 2017-03-03 17:56:46 --> Loader Class Initialized
INFO - 2017-03-03 17:56:46 --> Helper loaded: form_helper
INFO - 2017-03-03 17:56:46 --> Helper loaded: url_helper
INFO - 2017-03-03 17:56:46 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:56:46 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:56:46 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:56:46 --> Template Class Initialized
INFO - 2017-03-03 17:56:46 --> Model Class Initialized
INFO - 2017-03-03 17:56:46 --> Controller Class Initialized
DEBUG - 2017-03-03 17:56:46 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:56:46 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:56:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:56:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:56:47 --> Config Class Initialized
INFO - 2017-03-03 17:56:47 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:56:47 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:56:47 --> Utf8 Class Initialized
INFO - 2017-03-03 17:56:47 --> URI Class Initialized
INFO - 2017-03-03 17:56:47 --> Router Class Initialized
INFO - 2017-03-03 17:56:47 --> Output Class Initialized
INFO - 2017-03-03 17:56:47 --> Security Class Initialized
DEBUG - 2017-03-03 17:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:56:47 --> Input Class Initialized
INFO - 2017-03-03 17:56:47 --> Language Class Initialized
INFO - 2017-03-03 17:56:47 --> Language Class Initialized
INFO - 2017-03-03 17:56:47 --> Config Class Initialized
INFO - 2017-03-03 17:56:47 --> Loader Class Initialized
INFO - 2017-03-03 17:56:47 --> Helper loaded: form_helper
INFO - 2017-03-03 17:56:47 --> Helper loaded: url_helper
INFO - 2017-03-03 17:56:47 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:56:47 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:56:48 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:56:48 --> Template Class Initialized
INFO - 2017-03-03 17:56:48 --> Model Class Initialized
INFO - 2017-03-03 17:56:48 --> Controller Class Initialized
DEBUG - 2017-03-03 17:56:48 --> Pages MX_Controller Initialized
INFO - 2017-03-03 17:56:48 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:56:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 17:56:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 17:57:50 --> Config Class Initialized
INFO - 2017-03-03 17:57:50 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:57:50 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:57:50 --> Utf8 Class Initialized
INFO - 2017-03-03 17:57:50 --> URI Class Initialized
INFO - 2017-03-03 17:57:50 --> Router Class Initialized
INFO - 2017-03-03 17:57:50 --> Output Class Initialized
INFO - 2017-03-03 17:57:50 --> Security Class Initialized
DEBUG - 2017-03-03 17:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:57:50 --> Input Class Initialized
INFO - 2017-03-03 17:57:50 --> Language Class Initialized
INFO - 2017-03-03 17:57:50 --> Language Class Initialized
INFO - 2017-03-03 17:57:50 --> Config Class Initialized
INFO - 2017-03-03 17:57:50 --> Loader Class Initialized
INFO - 2017-03-03 17:57:50 --> Helper loaded: form_helper
INFO - 2017-03-03 17:57:50 --> Helper loaded: url_helper
INFO - 2017-03-03 17:57:50 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:57:50 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:57:50 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:57:50 --> Template Class Initialized
INFO - 2017-03-03 17:57:50 --> Model Class Initialized
INFO - 2017-03-03 17:57:50 --> Controller Class Initialized
DEBUG - 2017-03-03 17:57:50 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:57:50 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:57:50 --> Model Class Initialized
DEBUG - 2017-03-03 17:57:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:57:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:57:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:57:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:57:50 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:57:50 --> Final output sent to browser
DEBUG - 2017-03-03 17:57:50 --> Total execution time: 0.0184
INFO - 2017-03-03 17:57:55 --> Config Class Initialized
INFO - 2017-03-03 17:57:55 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:57:55 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:57:55 --> Utf8 Class Initialized
INFO - 2017-03-03 17:57:55 --> URI Class Initialized
INFO - 2017-03-03 17:57:55 --> Router Class Initialized
INFO - 2017-03-03 17:57:55 --> Output Class Initialized
INFO - 2017-03-03 17:57:55 --> Security Class Initialized
DEBUG - 2017-03-03 17:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:57:55 --> Input Class Initialized
INFO - 2017-03-03 17:57:55 --> Language Class Initialized
INFO - 2017-03-03 17:57:55 --> Language Class Initialized
INFO - 2017-03-03 17:57:55 --> Config Class Initialized
INFO - 2017-03-03 17:57:55 --> Loader Class Initialized
INFO - 2017-03-03 17:57:55 --> Helper loaded: form_helper
INFO - 2017-03-03 17:57:55 --> Helper loaded: url_helper
INFO - 2017-03-03 17:57:55 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:57:55 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:57:55 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:57:55 --> Template Class Initialized
INFO - 2017-03-03 17:57:55 --> Model Class Initialized
INFO - 2017-03-03 17:57:55 --> Controller Class Initialized
DEBUG - 2017-03-03 17:57:55 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:57:55 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:57:55 --> Model Class Initialized
DEBUG - 2017-03-03 17:57:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:57:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:57:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:57:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:57:55 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:57:55 --> Final output sent to browser
DEBUG - 2017-03-03 17:57:55 --> Total execution time: 0.0181
INFO - 2017-03-03 17:57:57 --> Config Class Initialized
INFO - 2017-03-03 17:57:57 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:57:57 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:57:57 --> Utf8 Class Initialized
INFO - 2017-03-03 17:57:57 --> URI Class Initialized
INFO - 2017-03-03 17:57:57 --> Router Class Initialized
INFO - 2017-03-03 17:57:57 --> Output Class Initialized
INFO - 2017-03-03 17:57:57 --> Security Class Initialized
DEBUG - 2017-03-03 17:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:57:57 --> Input Class Initialized
INFO - 2017-03-03 17:57:57 --> Language Class Initialized
INFO - 2017-03-03 17:57:57 --> Language Class Initialized
INFO - 2017-03-03 17:57:57 --> Config Class Initialized
INFO - 2017-03-03 17:57:57 --> Loader Class Initialized
INFO - 2017-03-03 17:57:57 --> Helper loaded: form_helper
INFO - 2017-03-03 17:57:57 --> Helper loaded: url_helper
INFO - 2017-03-03 17:57:57 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:57:57 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:57:57 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:57:57 --> Template Class Initialized
INFO - 2017-03-03 17:57:57 --> Model Class Initialized
INFO - 2017-03-03 17:57:57 --> Controller Class Initialized
DEBUG - 2017-03-03 17:57:57 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:57:57 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:57:57 --> Model Class Initialized
DEBUG - 2017-03-03 17:57:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:57:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:57:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:57:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:57:57 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:57:57 --> Final output sent to browser
DEBUG - 2017-03-03 17:57:57 --> Total execution time: 0.0178
INFO - 2017-03-03 17:57:59 --> Config Class Initialized
INFO - 2017-03-03 17:57:59 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:57:59 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:57:59 --> Utf8 Class Initialized
INFO - 2017-03-03 17:57:59 --> URI Class Initialized
INFO - 2017-03-03 17:57:59 --> Router Class Initialized
INFO - 2017-03-03 17:57:59 --> Output Class Initialized
INFO - 2017-03-03 17:57:59 --> Security Class Initialized
DEBUG - 2017-03-03 17:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:57:59 --> Input Class Initialized
INFO - 2017-03-03 17:57:59 --> Language Class Initialized
INFO - 2017-03-03 17:57:59 --> Language Class Initialized
INFO - 2017-03-03 17:57:59 --> Config Class Initialized
INFO - 2017-03-03 17:57:59 --> Loader Class Initialized
INFO - 2017-03-03 17:57:59 --> Helper loaded: form_helper
INFO - 2017-03-03 17:57:59 --> Helper loaded: url_helper
INFO - 2017-03-03 17:57:59 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:57:59 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:57:59 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:57:59 --> Template Class Initialized
INFO - 2017-03-03 17:57:59 --> Model Class Initialized
INFO - 2017-03-03 17:57:59 --> Controller Class Initialized
DEBUG - 2017-03-03 17:57:59 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:57:59 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:57:59 --> Final output sent to browser
DEBUG - 2017-03-03 17:57:59 --> Total execution time: 0.0122
INFO - 2017-03-03 17:58:07 --> Config Class Initialized
INFO - 2017-03-03 17:58:07 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:58:07 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:58:07 --> Utf8 Class Initialized
INFO - 2017-03-03 17:58:07 --> URI Class Initialized
INFO - 2017-03-03 17:58:07 --> Router Class Initialized
INFO - 2017-03-03 17:58:07 --> Output Class Initialized
INFO - 2017-03-03 17:58:07 --> Security Class Initialized
DEBUG - 2017-03-03 17:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:58:07 --> Input Class Initialized
INFO - 2017-03-03 17:58:07 --> Language Class Initialized
INFO - 2017-03-03 17:58:07 --> Language Class Initialized
INFO - 2017-03-03 17:58:07 --> Config Class Initialized
INFO - 2017-03-03 17:58:07 --> Loader Class Initialized
INFO - 2017-03-03 17:58:07 --> Helper loaded: form_helper
INFO - 2017-03-03 17:58:07 --> Helper loaded: url_helper
INFO - 2017-03-03 17:58:07 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:58:07 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:58:07 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:58:07 --> Template Class Initialized
INFO - 2017-03-03 17:58:07 --> Model Class Initialized
INFO - 2017-03-03 17:58:07 --> Controller Class Initialized
DEBUG - 2017-03-03 17:58:07 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:58:07 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:58:07 --> Upload Class Initialized
INFO - 2017-03-03 17:58:07 --> Model Class Initialized
INFO - 2017-03-03 17:58:07 --> Final output sent to browser
DEBUG - 2017-03-03 17:58:07 --> Total execution time: 0.0176
INFO - 2017-03-03 17:58:45 --> Config Class Initialized
INFO - 2017-03-03 17:58:45 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:58:45 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:58:45 --> Utf8 Class Initialized
INFO - 2017-03-03 17:58:45 --> URI Class Initialized
INFO - 2017-03-03 17:58:45 --> Router Class Initialized
INFO - 2017-03-03 17:58:45 --> Output Class Initialized
INFO - 2017-03-03 17:58:45 --> Security Class Initialized
DEBUG - 2017-03-03 17:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:58:45 --> Input Class Initialized
INFO - 2017-03-03 17:58:45 --> Language Class Initialized
INFO - 2017-03-03 17:58:45 --> Language Class Initialized
INFO - 2017-03-03 17:58:45 --> Config Class Initialized
INFO - 2017-03-03 17:58:45 --> Loader Class Initialized
INFO - 2017-03-03 17:58:45 --> Helper loaded: form_helper
INFO - 2017-03-03 17:58:45 --> Helper loaded: url_helper
INFO - 2017-03-03 17:58:45 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:58:45 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:58:45 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:58:45 --> Template Class Initialized
INFO - 2017-03-03 17:58:45 --> Model Class Initialized
INFO - 2017-03-03 17:58:45 --> Controller Class Initialized
DEBUG - 2017-03-03 17:58:45 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:58:45 --> Helper loaded: cookie_helper
INFO - 2017-03-03 17:58:45 --> Model Class Initialized
DEBUG - 2017-03-03 17:58:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:58:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:58:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:58:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 17:58:45 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:58:45 --> Final output sent to browser
DEBUG - 2017-03-03 17:58:45 --> Total execution time: 0.0164
INFO - 2017-03-03 17:58:46 --> Config Class Initialized
INFO - 2017-03-03 17:58:46 --> Hooks Class Initialized
DEBUG - 2017-03-03 17:58:46 --> UTF-8 Support Enabled
INFO - 2017-03-03 17:58:46 --> Utf8 Class Initialized
INFO - 2017-03-03 17:58:46 --> URI Class Initialized
INFO - 2017-03-03 17:58:46 --> Router Class Initialized
INFO - 2017-03-03 17:58:46 --> Output Class Initialized
INFO - 2017-03-03 17:58:46 --> Security Class Initialized
DEBUG - 2017-03-03 17:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 17:58:46 --> Input Class Initialized
INFO - 2017-03-03 17:58:46 --> Language Class Initialized
INFO - 2017-03-03 17:58:46 --> Language Class Initialized
INFO - 2017-03-03 17:58:46 --> Config Class Initialized
INFO - 2017-03-03 17:58:46 --> Loader Class Initialized
INFO - 2017-03-03 17:58:46 --> Helper loaded: form_helper
INFO - 2017-03-03 17:58:46 --> Helper loaded: url_helper
INFO - 2017-03-03 17:58:46 --> Helper loaded: utility_helper
INFO - 2017-03-03 17:58:46 --> Database Driver Class Initialized
DEBUG - 2017-03-03 17:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 17:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 17:58:46 --> User Agent Class Initialized
DEBUG - 2017-03-03 17:58:46 --> Template Class Initialized
INFO - 2017-03-03 17:58:46 --> Model Class Initialized
INFO - 2017-03-03 17:58:46 --> Controller Class Initialized
DEBUG - 2017-03-03 17:58:46 --> Project MX_Controller Initialized
INFO - 2017-03-03 17:58:46 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 17:58:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 17:58:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 17:58:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 17:58:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 17:58:46 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 17:58:46 --> Final output sent to browser
DEBUG - 2017-03-03 17:58:46 --> Total execution time: 0.0152
INFO - 2017-03-03 18:05:56 --> Config Class Initialized
INFO - 2017-03-03 18:05:56 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:05:56 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:05:56 --> Utf8 Class Initialized
INFO - 2017-03-03 18:05:56 --> URI Class Initialized
INFO - 2017-03-03 18:05:56 --> Router Class Initialized
INFO - 2017-03-03 18:05:56 --> Output Class Initialized
INFO - 2017-03-03 18:05:56 --> Security Class Initialized
DEBUG - 2017-03-03 18:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:05:56 --> Input Class Initialized
INFO - 2017-03-03 18:05:56 --> Language Class Initialized
INFO - 2017-03-03 18:05:56 --> Language Class Initialized
INFO - 2017-03-03 18:05:56 --> Config Class Initialized
INFO - 2017-03-03 18:05:56 --> Loader Class Initialized
INFO - 2017-03-03 18:05:56 --> Helper loaded: form_helper
INFO - 2017-03-03 18:05:56 --> Helper loaded: url_helper
INFO - 2017-03-03 18:05:56 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:05:56 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:05:56 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:05:56 --> Template Class Initialized
INFO - 2017-03-03 18:05:56 --> Model Class Initialized
INFO - 2017-03-03 18:05:56 --> Controller Class Initialized
DEBUG - 2017-03-03 18:05:56 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:05:56 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:05:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:05:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:05:59 --> Config Class Initialized
INFO - 2017-03-03 18:05:59 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:05:59 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:05:59 --> Utf8 Class Initialized
INFO - 2017-03-03 18:05:59 --> URI Class Initialized
INFO - 2017-03-03 18:05:59 --> Router Class Initialized
INFO - 2017-03-03 18:05:59 --> Output Class Initialized
INFO - 2017-03-03 18:05:59 --> Security Class Initialized
DEBUG - 2017-03-03 18:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:05:59 --> Input Class Initialized
INFO - 2017-03-03 18:05:59 --> Language Class Initialized
INFO - 2017-03-03 18:05:59 --> Language Class Initialized
INFO - 2017-03-03 18:05:59 --> Config Class Initialized
INFO - 2017-03-03 18:05:59 --> Loader Class Initialized
INFO - 2017-03-03 18:05:59 --> Helper loaded: form_helper
INFO - 2017-03-03 18:05:59 --> Helper loaded: url_helper
INFO - 2017-03-03 18:05:59 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:05:59 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:05:59 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:05:59 --> Template Class Initialized
INFO - 2017-03-03 18:05:59 --> Model Class Initialized
INFO - 2017-03-03 18:05:59 --> Controller Class Initialized
DEBUG - 2017-03-03 18:05:59 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:05:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:05:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:05:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:06:04 --> Config Class Initialized
INFO - 2017-03-03 18:06:04 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:06:04 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:06:04 --> Utf8 Class Initialized
INFO - 2017-03-03 18:06:04 --> URI Class Initialized
INFO - 2017-03-03 18:06:04 --> Router Class Initialized
INFO - 2017-03-03 18:06:04 --> Output Class Initialized
INFO - 2017-03-03 18:06:04 --> Security Class Initialized
DEBUG - 2017-03-03 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:06:04 --> Input Class Initialized
INFO - 2017-03-03 18:06:04 --> Language Class Initialized
INFO - 2017-03-03 18:06:04 --> Language Class Initialized
INFO - 2017-03-03 18:06:04 --> Config Class Initialized
INFO - 2017-03-03 18:06:04 --> Loader Class Initialized
INFO - 2017-03-03 18:06:04 --> Helper loaded: form_helper
INFO - 2017-03-03 18:06:04 --> Helper loaded: url_helper
INFO - 2017-03-03 18:06:04 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:06:04 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:06:04 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:06:04 --> Template Class Initialized
INFO - 2017-03-03 18:06:04 --> Model Class Initialized
INFO - 2017-03-03 18:06:04 --> Controller Class Initialized
DEBUG - 2017-03-03 18:06:04 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:06:04 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:06:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:06:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:06:10 --> Config Class Initialized
INFO - 2017-03-03 18:06:10 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:06:10 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:06:10 --> Utf8 Class Initialized
INFO - 2017-03-03 18:06:10 --> URI Class Initialized
INFO - 2017-03-03 18:06:10 --> Router Class Initialized
INFO - 2017-03-03 18:06:10 --> Output Class Initialized
INFO - 2017-03-03 18:06:10 --> Security Class Initialized
DEBUG - 2017-03-03 18:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:06:10 --> Input Class Initialized
INFO - 2017-03-03 18:06:10 --> Language Class Initialized
INFO - 2017-03-03 18:06:10 --> Language Class Initialized
INFO - 2017-03-03 18:06:10 --> Config Class Initialized
INFO - 2017-03-03 18:06:10 --> Loader Class Initialized
INFO - 2017-03-03 18:06:10 --> Helper loaded: form_helper
INFO - 2017-03-03 18:06:10 --> Helper loaded: url_helper
INFO - 2017-03-03 18:06:10 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:06:10 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:06:10 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:06:10 --> Template Class Initialized
INFO - 2017-03-03 18:06:10 --> Model Class Initialized
INFO - 2017-03-03 18:06:10 --> Controller Class Initialized
DEBUG - 2017-03-03 18:06:10 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:06:10 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:06:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:06:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:06:11 --> Config Class Initialized
INFO - 2017-03-03 18:06:11 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:06:11 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:06:11 --> Utf8 Class Initialized
INFO - 2017-03-03 18:06:11 --> URI Class Initialized
INFO - 2017-03-03 18:06:11 --> Router Class Initialized
INFO - 2017-03-03 18:06:11 --> Output Class Initialized
INFO - 2017-03-03 18:06:11 --> Security Class Initialized
DEBUG - 2017-03-03 18:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:06:11 --> Input Class Initialized
INFO - 2017-03-03 18:06:11 --> Language Class Initialized
INFO - 2017-03-03 18:06:11 --> Language Class Initialized
INFO - 2017-03-03 18:06:11 --> Config Class Initialized
INFO - 2017-03-03 18:06:11 --> Loader Class Initialized
INFO - 2017-03-03 18:06:11 --> Helper loaded: form_helper
INFO - 2017-03-03 18:06:11 --> Helper loaded: url_helper
INFO - 2017-03-03 18:06:11 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:06:11 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:06:11 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:06:11 --> Template Class Initialized
INFO - 2017-03-03 18:06:11 --> Model Class Initialized
INFO - 2017-03-03 18:06:11 --> Controller Class Initialized
DEBUG - 2017-03-03 18:06:11 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:06:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:06:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:06:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:06:12 --> Config Class Initialized
INFO - 2017-03-03 18:06:12 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:06:12 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:06:12 --> Utf8 Class Initialized
INFO - 2017-03-03 18:06:12 --> URI Class Initialized
INFO - 2017-03-03 18:06:12 --> Router Class Initialized
INFO - 2017-03-03 18:06:12 --> Output Class Initialized
INFO - 2017-03-03 18:06:12 --> Security Class Initialized
DEBUG - 2017-03-03 18:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:06:12 --> Input Class Initialized
INFO - 2017-03-03 18:06:12 --> Language Class Initialized
INFO - 2017-03-03 18:06:12 --> Language Class Initialized
INFO - 2017-03-03 18:06:12 --> Config Class Initialized
INFO - 2017-03-03 18:06:12 --> Loader Class Initialized
INFO - 2017-03-03 18:06:12 --> Helper loaded: form_helper
INFO - 2017-03-03 18:06:12 --> Helper loaded: url_helper
INFO - 2017-03-03 18:06:12 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:06:12 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:06:12 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:06:12 --> Template Class Initialized
INFO - 2017-03-03 18:06:12 --> Model Class Initialized
INFO - 2017-03-03 18:06:12 --> Controller Class Initialized
DEBUG - 2017-03-03 18:06:12 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:06:12 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:06:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:06:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:13:53 --> Config Class Initialized
INFO - 2017-03-03 18:13:53 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:13:53 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:13:53 --> Utf8 Class Initialized
INFO - 2017-03-03 18:13:53 --> URI Class Initialized
DEBUG - 2017-03-03 18:13:53 --> No URI present. Default controller set.
INFO - 2017-03-03 18:13:53 --> Router Class Initialized
INFO - 2017-03-03 18:13:53 --> Output Class Initialized
INFO - 2017-03-03 18:13:53 --> Security Class Initialized
DEBUG - 2017-03-03 18:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:13:53 --> Input Class Initialized
INFO - 2017-03-03 18:13:53 --> Language Class Initialized
INFO - 2017-03-03 18:13:53 --> Language Class Initialized
INFO - 2017-03-03 18:13:53 --> Config Class Initialized
INFO - 2017-03-03 18:13:53 --> Loader Class Initialized
INFO - 2017-03-03 18:13:53 --> Helper loaded: form_helper
INFO - 2017-03-03 18:13:53 --> Helper loaded: url_helper
INFO - 2017-03-03 18:13:53 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:13:53 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:13:53 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:13:53 --> Template Class Initialized
INFO - 2017-03-03 18:13:53 --> Model Class Initialized
INFO - 2017-03-03 18:13:53 --> Controller Class Initialized
DEBUG - 2017-03-03 18:13:53 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:13:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:13:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:13:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 18:13:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-03 18:13:53 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 18:13:53 --> Final output sent to browser
DEBUG - 2017-03-03 18:13:53 --> Total execution time: 0.0631
INFO - 2017-03-03 18:13:54 --> Config Class Initialized
INFO - 2017-03-03 18:13:54 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:13:54 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:13:54 --> Utf8 Class Initialized
INFO - 2017-03-03 18:13:54 --> URI Class Initialized
INFO - 2017-03-03 18:13:54 --> Router Class Initialized
INFO - 2017-03-03 18:13:54 --> Output Class Initialized
INFO - 2017-03-03 18:13:54 --> Security Class Initialized
DEBUG - 2017-03-03 18:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:13:54 --> Input Class Initialized
INFO - 2017-03-03 18:13:54 --> Language Class Initialized
INFO - 2017-03-03 18:13:54 --> Language Class Initialized
INFO - 2017-03-03 18:13:54 --> Config Class Initialized
INFO - 2017-03-03 18:13:54 --> Loader Class Initialized
INFO - 2017-03-03 18:13:54 --> Helper loaded: form_helper
INFO - 2017-03-03 18:13:54 --> Helper loaded: url_helper
INFO - 2017-03-03 18:13:54 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:13:54 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:13:54 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:13:54 --> Template Class Initialized
INFO - 2017-03-03 18:13:54 --> Model Class Initialized
INFO - 2017-03-03 18:13:54 --> Controller Class Initialized
DEBUG - 2017-03-03 18:13:54 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:13:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:13:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:13:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:13:54 --> Config Class Initialized
INFO - 2017-03-03 18:13:54 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:13:54 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:13:54 --> Utf8 Class Initialized
INFO - 2017-03-03 18:13:54 --> URI Class Initialized
INFO - 2017-03-03 18:13:54 --> Router Class Initialized
INFO - 2017-03-03 18:13:54 --> Output Class Initialized
INFO - 2017-03-03 18:13:54 --> Security Class Initialized
DEBUG - 2017-03-03 18:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:13:54 --> Input Class Initialized
INFO - 2017-03-03 18:13:54 --> Language Class Initialized
INFO - 2017-03-03 18:13:54 --> Language Class Initialized
INFO - 2017-03-03 18:13:54 --> Config Class Initialized
INFO - 2017-03-03 18:13:54 --> Loader Class Initialized
INFO - 2017-03-03 18:13:54 --> Helper loaded: form_helper
INFO - 2017-03-03 18:13:54 --> Helper loaded: url_helper
INFO - 2017-03-03 18:13:54 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:13:54 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:13:54 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:13:54 --> Template Class Initialized
INFO - 2017-03-03 18:13:54 --> Model Class Initialized
INFO - 2017-03-03 18:13:54 --> Controller Class Initialized
DEBUG - 2017-03-03 18:13:54 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:13:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:13:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:13:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:14:00 --> Config Class Initialized
INFO - 2017-03-03 18:14:00 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:14:00 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:14:00 --> Utf8 Class Initialized
INFO - 2017-03-03 18:14:00 --> URI Class Initialized
DEBUG - 2017-03-03 18:14:00 --> No URI present. Default controller set.
INFO - 2017-03-03 18:14:00 --> Router Class Initialized
INFO - 2017-03-03 18:14:00 --> Output Class Initialized
INFO - 2017-03-03 18:14:00 --> Security Class Initialized
DEBUG - 2017-03-03 18:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:14:00 --> Input Class Initialized
INFO - 2017-03-03 18:14:00 --> Language Class Initialized
INFO - 2017-03-03 18:14:00 --> Language Class Initialized
INFO - 2017-03-03 18:14:00 --> Config Class Initialized
INFO - 2017-03-03 18:14:00 --> Loader Class Initialized
INFO - 2017-03-03 18:14:00 --> Helper loaded: form_helper
INFO - 2017-03-03 18:14:00 --> Helper loaded: url_helper
INFO - 2017-03-03 18:14:00 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:14:00 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:14:00 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:14:00 --> Template Class Initialized
INFO - 2017-03-03 18:14:00 --> Model Class Initialized
INFO - 2017-03-03 18:14:00 --> Controller Class Initialized
DEBUG - 2017-03-03 18:14:00 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:14:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:14:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:14:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 18:14:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-03 18:14:00 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 18:14:00 --> Final output sent to browser
DEBUG - 2017-03-03 18:14:00 --> Total execution time: 0.0100
INFO - 2017-03-03 18:14:01 --> Config Class Initialized
INFO - 2017-03-03 18:14:01 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:14:01 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:14:01 --> Utf8 Class Initialized
INFO - 2017-03-03 18:14:01 --> URI Class Initialized
INFO - 2017-03-03 18:14:01 --> Router Class Initialized
INFO - 2017-03-03 18:14:01 --> Output Class Initialized
INFO - 2017-03-03 18:14:01 --> Security Class Initialized
DEBUG - 2017-03-03 18:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:14:01 --> Input Class Initialized
INFO - 2017-03-03 18:14:01 --> Language Class Initialized
INFO - 2017-03-03 18:14:01 --> Language Class Initialized
INFO - 2017-03-03 18:14:01 --> Config Class Initialized
INFO - 2017-03-03 18:14:01 --> Loader Class Initialized
INFO - 2017-03-03 18:14:01 --> Helper loaded: form_helper
INFO - 2017-03-03 18:14:01 --> Helper loaded: url_helper
INFO - 2017-03-03 18:14:01 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:14:01 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:14:01 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:14:01 --> Template Class Initialized
INFO - 2017-03-03 18:14:01 --> Model Class Initialized
INFO - 2017-03-03 18:14:01 --> Controller Class Initialized
DEBUG - 2017-03-03 18:14:01 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:14:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:14:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:14:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:14:01 --> Config Class Initialized
INFO - 2017-03-03 18:14:01 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:14:01 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:14:01 --> Utf8 Class Initialized
INFO - 2017-03-03 18:14:01 --> URI Class Initialized
INFO - 2017-03-03 18:14:01 --> Router Class Initialized
INFO - 2017-03-03 18:14:01 --> Output Class Initialized
INFO - 2017-03-03 18:14:01 --> Security Class Initialized
DEBUG - 2017-03-03 18:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:14:01 --> Input Class Initialized
INFO - 2017-03-03 18:14:01 --> Language Class Initialized
INFO - 2017-03-03 18:14:01 --> Language Class Initialized
INFO - 2017-03-03 18:14:01 --> Config Class Initialized
INFO - 2017-03-03 18:14:01 --> Loader Class Initialized
INFO - 2017-03-03 18:14:01 --> Helper loaded: form_helper
INFO - 2017-03-03 18:14:01 --> Helper loaded: url_helper
INFO - 2017-03-03 18:14:01 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:14:01 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:14:01 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:14:01 --> Template Class Initialized
INFO - 2017-03-03 18:14:01 --> Model Class Initialized
INFO - 2017-03-03 18:14:01 --> Controller Class Initialized
DEBUG - 2017-03-03 18:14:01 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:14:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:14:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:14:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:14:02 --> Config Class Initialized
INFO - 2017-03-03 18:14:02 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:14:02 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:14:02 --> Utf8 Class Initialized
INFO - 2017-03-03 18:14:02 --> URI Class Initialized
INFO - 2017-03-03 18:14:02 --> Router Class Initialized
INFO - 2017-03-03 18:14:02 --> Output Class Initialized
INFO - 2017-03-03 18:14:02 --> Security Class Initialized
DEBUG - 2017-03-03 18:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:14:02 --> Input Class Initialized
INFO - 2017-03-03 18:14:02 --> Language Class Initialized
INFO - 2017-03-03 18:14:02 --> Language Class Initialized
INFO - 2017-03-03 18:14:02 --> Config Class Initialized
INFO - 2017-03-03 18:14:02 --> Loader Class Initialized
INFO - 2017-03-03 18:14:02 --> Helper loaded: form_helper
INFO - 2017-03-03 18:14:02 --> Helper loaded: url_helper
INFO - 2017-03-03 18:14:02 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:14:02 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:14:02 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:14:02 --> Template Class Initialized
INFO - 2017-03-03 18:14:02 --> Model Class Initialized
INFO - 2017-03-03 18:14:02 --> Controller Class Initialized
DEBUG - 2017-03-03 18:14:02 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:14:02 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:14:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:14:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:14:04 --> Config Class Initialized
INFO - 2017-03-03 18:14:04 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:14:04 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:14:04 --> Utf8 Class Initialized
INFO - 2017-03-03 18:14:04 --> URI Class Initialized
INFO - 2017-03-03 18:14:04 --> Router Class Initialized
INFO - 2017-03-03 18:14:04 --> Output Class Initialized
INFO - 2017-03-03 18:14:04 --> Security Class Initialized
DEBUG - 2017-03-03 18:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:14:04 --> Input Class Initialized
INFO - 2017-03-03 18:14:04 --> Language Class Initialized
INFO - 2017-03-03 18:14:04 --> Language Class Initialized
INFO - 2017-03-03 18:14:04 --> Config Class Initialized
INFO - 2017-03-03 18:14:04 --> Loader Class Initialized
INFO - 2017-03-03 18:14:04 --> Helper loaded: form_helper
INFO - 2017-03-03 18:14:04 --> Helper loaded: url_helper
INFO - 2017-03-03 18:14:04 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:14:04 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:14:04 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:14:04 --> Template Class Initialized
INFO - 2017-03-03 18:14:04 --> Model Class Initialized
INFO - 2017-03-03 18:14:04 --> Controller Class Initialized
DEBUG - 2017-03-03 18:14:04 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:14:04 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:14:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:14:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 18:14:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-03 18:14:04 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 18:14:04 --> Final output sent to browser
DEBUG - 2017-03-03 18:14:04 --> Total execution time: 0.0146
INFO - 2017-03-03 18:14:04 --> Config Class Initialized
INFO - 2017-03-03 18:14:04 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:14:04 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:14:04 --> Utf8 Class Initialized
INFO - 2017-03-03 18:14:04 --> URI Class Initialized
INFO - 2017-03-03 18:14:04 --> Router Class Initialized
INFO - 2017-03-03 18:14:04 --> Output Class Initialized
INFO - 2017-03-03 18:14:04 --> Security Class Initialized
DEBUG - 2017-03-03 18:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:14:04 --> Input Class Initialized
INFO - 2017-03-03 18:14:04 --> Language Class Initialized
INFO - 2017-03-03 18:14:04 --> Language Class Initialized
INFO - 2017-03-03 18:14:04 --> Config Class Initialized
INFO - 2017-03-03 18:14:04 --> Loader Class Initialized
INFO - 2017-03-03 18:14:04 --> Helper loaded: form_helper
INFO - 2017-03-03 18:14:04 --> Helper loaded: url_helper
INFO - 2017-03-03 18:14:04 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:14:04 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:14:04 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:14:04 --> Template Class Initialized
INFO - 2017-03-03 18:14:04 --> Model Class Initialized
INFO - 2017-03-03 18:14:04 --> Controller Class Initialized
DEBUG - 2017-03-03 18:14:04 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:14:04 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:14:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:14:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:14:05 --> Config Class Initialized
INFO - 2017-03-03 18:14:05 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:14:05 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:14:05 --> Utf8 Class Initialized
INFO - 2017-03-03 18:14:05 --> URI Class Initialized
INFO - 2017-03-03 18:14:05 --> Router Class Initialized
INFO - 2017-03-03 18:14:05 --> Output Class Initialized
INFO - 2017-03-03 18:14:05 --> Security Class Initialized
DEBUG - 2017-03-03 18:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:14:05 --> Input Class Initialized
INFO - 2017-03-03 18:14:05 --> Language Class Initialized
INFO - 2017-03-03 18:14:05 --> Language Class Initialized
INFO - 2017-03-03 18:14:05 --> Config Class Initialized
INFO - 2017-03-03 18:14:05 --> Loader Class Initialized
INFO - 2017-03-03 18:14:05 --> Helper loaded: form_helper
INFO - 2017-03-03 18:14:05 --> Helper loaded: url_helper
INFO - 2017-03-03 18:14:05 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:14:05 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:14:05 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:14:05 --> Template Class Initialized
INFO - 2017-03-03 18:14:05 --> Model Class Initialized
INFO - 2017-03-03 18:14:05 --> Controller Class Initialized
DEBUG - 2017-03-03 18:14:05 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:14:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:14:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:14:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:14:05 --> Config Class Initialized
INFO - 2017-03-03 18:14:05 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:14:05 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:14:05 --> Utf8 Class Initialized
INFO - 2017-03-03 18:14:05 --> URI Class Initialized
INFO - 2017-03-03 18:14:05 --> Router Class Initialized
INFO - 2017-03-03 18:14:05 --> Output Class Initialized
INFO - 2017-03-03 18:14:05 --> Security Class Initialized
DEBUG - 2017-03-03 18:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:14:05 --> Input Class Initialized
INFO - 2017-03-03 18:14:05 --> Language Class Initialized
INFO - 2017-03-03 18:14:05 --> Language Class Initialized
INFO - 2017-03-03 18:14:05 --> Config Class Initialized
INFO - 2017-03-03 18:14:05 --> Loader Class Initialized
INFO - 2017-03-03 18:14:05 --> Helper loaded: form_helper
INFO - 2017-03-03 18:14:05 --> Helper loaded: url_helper
INFO - 2017-03-03 18:14:05 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:14:05 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:14:05 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:14:05 --> Template Class Initialized
INFO - 2017-03-03 18:14:05 --> Model Class Initialized
INFO - 2017-03-03 18:14:05 --> Controller Class Initialized
DEBUG - 2017-03-03 18:14:05 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:14:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:14:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:14:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:14:39 --> Config Class Initialized
INFO - 2017-03-03 18:14:39 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:14:39 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:14:39 --> Utf8 Class Initialized
INFO - 2017-03-03 18:14:39 --> URI Class Initialized
INFO - 2017-03-03 18:14:39 --> Router Class Initialized
INFO - 2017-03-03 18:14:39 --> Output Class Initialized
INFO - 2017-03-03 18:14:39 --> Security Class Initialized
DEBUG - 2017-03-03 18:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:14:39 --> Input Class Initialized
INFO - 2017-03-03 18:14:39 --> Language Class Initialized
INFO - 2017-03-03 18:14:39 --> Language Class Initialized
INFO - 2017-03-03 18:14:39 --> Config Class Initialized
INFO - 2017-03-03 18:14:39 --> Loader Class Initialized
INFO - 2017-03-03 18:14:39 --> Helper loaded: form_helper
INFO - 2017-03-03 18:14:39 --> Helper loaded: url_helper
INFO - 2017-03-03 18:14:39 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:14:39 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:14:39 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:14:39 --> Template Class Initialized
INFO - 2017-03-03 18:14:39 --> Model Class Initialized
INFO - 2017-03-03 18:14:39 --> Controller Class Initialized
DEBUG - 2017-03-03 18:14:39 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:14:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:14:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:14:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 18:14:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-03 18:14:39 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 18:14:39 --> Final output sent to browser
DEBUG - 2017-03-03 18:14:39 --> Total execution time: 0.0167
INFO - 2017-03-03 18:14:39 --> Config Class Initialized
INFO - 2017-03-03 18:14:39 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:14:39 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:14:39 --> Utf8 Class Initialized
INFO - 2017-03-03 18:14:39 --> URI Class Initialized
INFO - 2017-03-03 18:14:39 --> Router Class Initialized
INFO - 2017-03-03 18:14:39 --> Output Class Initialized
INFO - 2017-03-03 18:14:39 --> Security Class Initialized
DEBUG - 2017-03-03 18:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:14:39 --> Input Class Initialized
INFO - 2017-03-03 18:14:39 --> Language Class Initialized
INFO - 2017-03-03 18:14:39 --> Language Class Initialized
INFO - 2017-03-03 18:14:39 --> Config Class Initialized
INFO - 2017-03-03 18:14:39 --> Loader Class Initialized
INFO - 2017-03-03 18:14:39 --> Helper loaded: form_helper
INFO - 2017-03-03 18:14:39 --> Helper loaded: url_helper
INFO - 2017-03-03 18:14:39 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:14:39 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:14:39 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:14:39 --> Template Class Initialized
INFO - 2017-03-03 18:14:39 --> Model Class Initialized
INFO - 2017-03-03 18:14:39 --> Controller Class Initialized
DEBUG - 2017-03-03 18:14:39 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:14:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:14:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:14:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:16:05 --> Config Class Initialized
INFO - 2017-03-03 18:16:05 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:16:05 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:16:05 --> Utf8 Class Initialized
INFO - 2017-03-03 18:16:05 --> URI Class Initialized
INFO - 2017-03-03 18:16:05 --> Router Class Initialized
INFO - 2017-03-03 18:16:05 --> Output Class Initialized
INFO - 2017-03-03 18:16:05 --> Security Class Initialized
DEBUG - 2017-03-03 18:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:16:05 --> Input Class Initialized
INFO - 2017-03-03 18:16:05 --> Language Class Initialized
INFO - 2017-03-03 18:16:05 --> Language Class Initialized
INFO - 2017-03-03 18:16:05 --> Config Class Initialized
INFO - 2017-03-03 18:16:05 --> Loader Class Initialized
INFO - 2017-03-03 18:16:05 --> Helper loaded: form_helper
INFO - 2017-03-03 18:16:05 --> Helper loaded: url_helper
INFO - 2017-03-03 18:16:05 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:16:05 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:16:05 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:16:05 --> Template Class Initialized
INFO - 2017-03-03 18:16:05 --> Model Class Initialized
INFO - 2017-03-03 18:16:05 --> Controller Class Initialized
DEBUG - 2017-03-03 18:16:05 --> Login MX_Controller Initialized
INFO - 2017-03-03 18:16:05 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:16:05 --> Form Validation Class Initialized
INFO - 2017-03-03 18:16:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-03 18:16:05 --> Config Class Initialized
INFO - 2017-03-03 18:16:05 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:16:05 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:16:05 --> Utf8 Class Initialized
INFO - 2017-03-03 18:16:05 --> URI Class Initialized
INFO - 2017-03-03 18:16:05 --> Router Class Initialized
INFO - 2017-03-03 18:16:05 --> Output Class Initialized
INFO - 2017-03-03 18:16:05 --> Security Class Initialized
DEBUG - 2017-03-03 18:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:16:05 --> Input Class Initialized
INFO - 2017-03-03 18:16:05 --> Language Class Initialized
INFO - 2017-03-03 18:16:05 --> Language Class Initialized
INFO - 2017-03-03 18:16:05 --> Config Class Initialized
INFO - 2017-03-03 18:16:05 --> Loader Class Initialized
INFO - 2017-03-03 18:16:05 --> Helper loaded: form_helper
INFO - 2017-03-03 18:16:05 --> Helper loaded: url_helper
INFO - 2017-03-03 18:16:05 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:16:05 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:16:05 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:16:05 --> Template Class Initialized
INFO - 2017-03-03 18:16:05 --> Model Class Initialized
INFO - 2017-03-03 18:16:05 --> Controller Class Initialized
DEBUG - 2017-03-03 18:16:05 --> Dashboard MX_Controller Initialized
INFO - 2017-03-03 18:16:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:16:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:16:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:16:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:16:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-03 18:16:05 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:16:05 --> Final output sent to browser
DEBUG - 2017-03-03 18:16:05 --> Total execution time: 0.0156
INFO - 2017-03-03 18:16:45 --> Config Class Initialized
INFO - 2017-03-03 18:16:45 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:16:45 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:16:45 --> Utf8 Class Initialized
INFO - 2017-03-03 18:16:45 --> URI Class Initialized
INFO - 2017-03-03 18:16:45 --> Router Class Initialized
INFO - 2017-03-03 18:16:45 --> Output Class Initialized
INFO - 2017-03-03 18:16:45 --> Security Class Initialized
DEBUG - 2017-03-03 18:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:16:45 --> Input Class Initialized
INFO - 2017-03-03 18:16:45 --> Language Class Initialized
INFO - 2017-03-03 18:16:45 --> Language Class Initialized
INFO - 2017-03-03 18:16:45 --> Config Class Initialized
INFO - 2017-03-03 18:16:45 --> Loader Class Initialized
INFO - 2017-03-03 18:16:45 --> Helper loaded: form_helper
INFO - 2017-03-03 18:16:45 --> Helper loaded: url_helper
INFO - 2017-03-03 18:16:45 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:16:45 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:16:45 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:16:45 --> Template Class Initialized
INFO - 2017-03-03 18:16:45 --> Model Class Initialized
INFO - 2017-03-03 18:16:45 --> Controller Class Initialized
DEBUG - 2017-03-03 18:16:45 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:16:45 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:16:45 --> Model Class Initialized
DEBUG - 2017-03-03 18:16:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:16:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:16:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:16:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 18:16:45 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:16:45 --> Final output sent to browser
DEBUG - 2017-03-03 18:16:45 --> Total execution time: 0.0189
INFO - 2017-03-03 18:16:58 --> Config Class Initialized
INFO - 2017-03-03 18:16:58 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:16:58 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:16:58 --> Utf8 Class Initialized
INFO - 2017-03-03 18:16:58 --> URI Class Initialized
INFO - 2017-03-03 18:16:58 --> Router Class Initialized
INFO - 2017-03-03 18:16:58 --> Output Class Initialized
INFO - 2017-03-03 18:16:58 --> Security Class Initialized
DEBUG - 2017-03-03 18:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:16:58 --> Input Class Initialized
INFO - 2017-03-03 18:16:58 --> Language Class Initialized
INFO - 2017-03-03 18:16:58 --> Language Class Initialized
INFO - 2017-03-03 18:16:58 --> Config Class Initialized
INFO - 2017-03-03 18:16:58 --> Loader Class Initialized
INFO - 2017-03-03 18:16:58 --> Helper loaded: form_helper
INFO - 2017-03-03 18:16:58 --> Helper loaded: url_helper
INFO - 2017-03-03 18:16:58 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:16:58 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:16:58 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:16:58 --> Template Class Initialized
INFO - 2017-03-03 18:16:58 --> Model Class Initialized
INFO - 2017-03-03 18:16:58 --> Controller Class Initialized
DEBUG - 2017-03-03 18:16:58 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:16:58 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:16:58 --> Final output sent to browser
DEBUG - 2017-03-03 18:16:58 --> Total execution time: 0.0138
INFO - 2017-03-03 18:17:10 --> Config Class Initialized
INFO - 2017-03-03 18:17:10 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:17:10 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:17:10 --> Utf8 Class Initialized
INFO - 2017-03-03 18:17:10 --> URI Class Initialized
INFO - 2017-03-03 18:17:10 --> Router Class Initialized
INFO - 2017-03-03 18:17:10 --> Output Class Initialized
INFO - 2017-03-03 18:17:10 --> Security Class Initialized
DEBUG - 2017-03-03 18:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:17:10 --> Input Class Initialized
INFO - 2017-03-03 18:17:10 --> Language Class Initialized
INFO - 2017-03-03 18:17:10 --> Language Class Initialized
INFO - 2017-03-03 18:17:10 --> Config Class Initialized
INFO - 2017-03-03 18:17:10 --> Loader Class Initialized
INFO - 2017-03-03 18:17:10 --> Helper loaded: form_helper
INFO - 2017-03-03 18:17:10 --> Helper loaded: url_helper
INFO - 2017-03-03 18:17:10 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:17:10 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:17:10 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:17:10 --> Template Class Initialized
INFO - 2017-03-03 18:17:10 --> Model Class Initialized
INFO - 2017-03-03 18:17:10 --> Controller Class Initialized
DEBUG - 2017-03-03 18:17:10 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:17:10 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:17:10 --> Upload Class Initialized
INFO - 2017-03-03 18:17:10 --> Model Class Initialized
INFO - 2017-03-03 18:17:10 --> Final output sent to browser
DEBUG - 2017-03-03 18:17:10 --> Total execution time: 0.0212
INFO - 2017-03-03 18:17:29 --> Config Class Initialized
INFO - 2017-03-03 18:17:29 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:17:29 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:17:29 --> Utf8 Class Initialized
INFO - 2017-03-03 18:17:29 --> URI Class Initialized
INFO - 2017-03-03 18:17:29 --> Router Class Initialized
INFO - 2017-03-03 18:17:29 --> Output Class Initialized
INFO - 2017-03-03 18:17:29 --> Security Class Initialized
DEBUG - 2017-03-03 18:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:17:29 --> Input Class Initialized
INFO - 2017-03-03 18:17:29 --> Language Class Initialized
INFO - 2017-03-03 18:17:29 --> Language Class Initialized
INFO - 2017-03-03 18:17:29 --> Config Class Initialized
INFO - 2017-03-03 18:17:29 --> Loader Class Initialized
INFO - 2017-03-03 18:17:29 --> Helper loaded: form_helper
INFO - 2017-03-03 18:17:29 --> Helper loaded: url_helper
INFO - 2017-03-03 18:17:29 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:17:29 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:17:29 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:17:29 --> Template Class Initialized
INFO - 2017-03-03 18:17:29 --> Model Class Initialized
INFO - 2017-03-03 18:17:29 --> Controller Class Initialized
DEBUG - 2017-03-03 18:17:29 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:17:29 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:17:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:17:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:17:32 --> Config Class Initialized
INFO - 2017-03-03 18:17:32 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:17:32 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:17:32 --> Utf8 Class Initialized
INFO - 2017-03-03 18:17:32 --> URI Class Initialized
INFO - 2017-03-03 18:17:32 --> Router Class Initialized
INFO - 2017-03-03 18:17:32 --> Output Class Initialized
INFO - 2017-03-03 18:17:32 --> Security Class Initialized
DEBUG - 2017-03-03 18:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:17:32 --> Input Class Initialized
INFO - 2017-03-03 18:17:32 --> Language Class Initialized
INFO - 2017-03-03 18:17:32 --> Language Class Initialized
INFO - 2017-03-03 18:17:32 --> Config Class Initialized
INFO - 2017-03-03 18:17:32 --> Loader Class Initialized
INFO - 2017-03-03 18:17:32 --> Helper loaded: form_helper
INFO - 2017-03-03 18:17:32 --> Helper loaded: url_helper
INFO - 2017-03-03 18:17:32 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:17:32 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:17:32 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:17:32 --> Template Class Initialized
INFO - 2017-03-03 18:17:32 --> Model Class Initialized
INFO - 2017-03-03 18:17:32 --> Controller Class Initialized
DEBUG - 2017-03-03 18:17:32 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:17:32 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:17:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:17:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:17:47 --> Config Class Initialized
INFO - 2017-03-03 18:17:47 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:17:47 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:17:47 --> Utf8 Class Initialized
INFO - 2017-03-03 18:17:47 --> URI Class Initialized
INFO - 2017-03-03 18:17:47 --> Router Class Initialized
INFO - 2017-03-03 18:17:47 --> Output Class Initialized
INFO - 2017-03-03 18:17:47 --> Security Class Initialized
DEBUG - 2017-03-03 18:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:17:47 --> Input Class Initialized
INFO - 2017-03-03 18:17:47 --> Language Class Initialized
INFO - 2017-03-03 18:17:47 --> Language Class Initialized
INFO - 2017-03-03 18:17:47 --> Config Class Initialized
INFO - 2017-03-03 18:17:47 --> Loader Class Initialized
INFO - 2017-03-03 18:17:47 --> Helper loaded: form_helper
INFO - 2017-03-03 18:17:47 --> Helper loaded: url_helper
INFO - 2017-03-03 18:17:47 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:17:47 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:17:47 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:17:47 --> Template Class Initialized
INFO - 2017-03-03 18:17:47 --> Model Class Initialized
INFO - 2017-03-03 18:17:47 --> Controller Class Initialized
DEBUG - 2017-03-03 18:17:47 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:17:47 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:17:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:17:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:17:49 --> Config Class Initialized
INFO - 2017-03-03 18:17:49 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:17:49 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:17:49 --> Utf8 Class Initialized
INFO - 2017-03-03 18:17:49 --> URI Class Initialized
INFO - 2017-03-03 18:17:49 --> Router Class Initialized
INFO - 2017-03-03 18:17:49 --> Output Class Initialized
INFO - 2017-03-03 18:17:49 --> Security Class Initialized
DEBUG - 2017-03-03 18:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:17:49 --> Input Class Initialized
INFO - 2017-03-03 18:17:49 --> Language Class Initialized
INFO - 2017-03-03 18:17:49 --> Language Class Initialized
INFO - 2017-03-03 18:17:49 --> Config Class Initialized
INFO - 2017-03-03 18:17:49 --> Loader Class Initialized
INFO - 2017-03-03 18:17:49 --> Helper loaded: form_helper
INFO - 2017-03-03 18:17:49 --> Helper loaded: url_helper
INFO - 2017-03-03 18:17:49 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:17:49 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:17:49 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:17:49 --> Template Class Initialized
INFO - 2017-03-03 18:17:49 --> Model Class Initialized
INFO - 2017-03-03 18:17:49 --> Controller Class Initialized
DEBUG - 2017-03-03 18:17:49 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:17:49 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:17:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:17:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:17:51 --> Config Class Initialized
INFO - 2017-03-03 18:17:51 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:17:51 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:17:51 --> Utf8 Class Initialized
INFO - 2017-03-03 18:17:51 --> URI Class Initialized
INFO - 2017-03-03 18:17:51 --> Router Class Initialized
INFO - 2017-03-03 18:17:51 --> Output Class Initialized
INFO - 2017-03-03 18:17:51 --> Security Class Initialized
DEBUG - 2017-03-03 18:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:17:51 --> Input Class Initialized
INFO - 2017-03-03 18:17:51 --> Language Class Initialized
INFO - 2017-03-03 18:17:51 --> Language Class Initialized
INFO - 2017-03-03 18:17:51 --> Config Class Initialized
INFO - 2017-03-03 18:17:51 --> Loader Class Initialized
INFO - 2017-03-03 18:17:51 --> Helper loaded: form_helper
INFO - 2017-03-03 18:17:51 --> Helper loaded: url_helper
INFO - 2017-03-03 18:17:51 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:17:51 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:17:51 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:17:51 --> Template Class Initialized
INFO - 2017-03-03 18:17:51 --> Model Class Initialized
INFO - 2017-03-03 18:17:51 --> Controller Class Initialized
DEBUG - 2017-03-03 18:17:51 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:17:51 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:17:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:17:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:17:52 --> Config Class Initialized
INFO - 2017-03-03 18:17:52 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:17:52 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:17:52 --> Utf8 Class Initialized
INFO - 2017-03-03 18:17:52 --> URI Class Initialized
INFO - 2017-03-03 18:17:52 --> Router Class Initialized
INFO - 2017-03-03 18:17:52 --> Output Class Initialized
INFO - 2017-03-03 18:17:52 --> Security Class Initialized
DEBUG - 2017-03-03 18:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:17:52 --> Input Class Initialized
INFO - 2017-03-03 18:17:52 --> Language Class Initialized
INFO - 2017-03-03 18:17:52 --> Language Class Initialized
INFO - 2017-03-03 18:17:52 --> Config Class Initialized
INFO - 2017-03-03 18:17:52 --> Loader Class Initialized
INFO - 2017-03-03 18:17:52 --> Helper loaded: form_helper
INFO - 2017-03-03 18:17:52 --> Helper loaded: url_helper
INFO - 2017-03-03 18:17:52 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:17:52 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:17:52 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:17:52 --> Template Class Initialized
INFO - 2017-03-03 18:17:52 --> Model Class Initialized
INFO - 2017-03-03 18:17:52 --> Controller Class Initialized
DEBUG - 2017-03-03 18:17:52 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:17:52 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:17:52 --> Model Class Initialized
DEBUG - 2017-03-03 18:17:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:17:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:17:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:17:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 18:17:52 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:17:52 --> Final output sent to browser
DEBUG - 2017-03-03 18:17:52 --> Total execution time: 0.0161
INFO - 2017-03-03 18:17:53 --> Config Class Initialized
INFO - 2017-03-03 18:17:53 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:17:53 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:17:53 --> Utf8 Class Initialized
INFO - 2017-03-03 18:17:53 --> URI Class Initialized
INFO - 2017-03-03 18:17:53 --> Router Class Initialized
INFO - 2017-03-03 18:17:53 --> Output Class Initialized
INFO - 2017-03-03 18:17:53 --> Security Class Initialized
DEBUG - 2017-03-03 18:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:17:53 --> Input Class Initialized
INFO - 2017-03-03 18:17:53 --> Language Class Initialized
INFO - 2017-03-03 18:17:53 --> Language Class Initialized
INFO - 2017-03-03 18:17:53 --> Config Class Initialized
INFO - 2017-03-03 18:17:53 --> Loader Class Initialized
INFO - 2017-03-03 18:17:53 --> Helper loaded: form_helper
INFO - 2017-03-03 18:17:53 --> Helper loaded: url_helper
INFO - 2017-03-03 18:17:53 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:17:53 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:17:53 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:17:53 --> Template Class Initialized
INFO - 2017-03-03 18:17:53 --> Model Class Initialized
INFO - 2017-03-03 18:17:53 --> Controller Class Initialized
DEBUG - 2017-03-03 18:17:53 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:17:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:17:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:17:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:17:54 --> Config Class Initialized
INFO - 2017-03-03 18:17:54 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:17:54 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:17:54 --> Utf8 Class Initialized
INFO - 2017-03-03 18:17:54 --> URI Class Initialized
INFO - 2017-03-03 18:17:54 --> Router Class Initialized
INFO - 2017-03-03 18:17:54 --> Output Class Initialized
INFO - 2017-03-03 18:17:54 --> Security Class Initialized
DEBUG - 2017-03-03 18:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:17:54 --> Input Class Initialized
INFO - 2017-03-03 18:17:54 --> Language Class Initialized
INFO - 2017-03-03 18:17:54 --> Language Class Initialized
INFO - 2017-03-03 18:17:54 --> Config Class Initialized
INFO - 2017-03-03 18:17:54 --> Loader Class Initialized
INFO - 2017-03-03 18:17:54 --> Helper loaded: form_helper
INFO - 2017-03-03 18:17:54 --> Helper loaded: url_helper
INFO - 2017-03-03 18:17:54 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:17:54 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:17:54 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:17:54 --> Template Class Initialized
INFO - 2017-03-03 18:17:54 --> Model Class Initialized
INFO - 2017-03-03 18:17:54 --> Controller Class Initialized
DEBUG - 2017-03-03 18:17:54 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:17:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:17:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:17:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:17:58 --> Config Class Initialized
INFO - 2017-03-03 18:17:58 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:17:58 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:17:58 --> Utf8 Class Initialized
INFO - 2017-03-03 18:17:58 --> URI Class Initialized
INFO - 2017-03-03 18:17:58 --> Router Class Initialized
INFO - 2017-03-03 18:17:58 --> Output Class Initialized
INFO - 2017-03-03 18:17:58 --> Security Class Initialized
DEBUG - 2017-03-03 18:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:17:58 --> Input Class Initialized
INFO - 2017-03-03 18:17:58 --> Language Class Initialized
INFO - 2017-03-03 18:17:58 --> Language Class Initialized
INFO - 2017-03-03 18:17:58 --> Config Class Initialized
INFO - 2017-03-03 18:17:58 --> Loader Class Initialized
INFO - 2017-03-03 18:17:58 --> Helper loaded: form_helper
INFO - 2017-03-03 18:17:58 --> Helper loaded: url_helper
INFO - 2017-03-03 18:17:58 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:17:58 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:17:58 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:17:58 --> Template Class Initialized
INFO - 2017-03-03 18:17:58 --> Model Class Initialized
INFO - 2017-03-03 18:17:58 --> Controller Class Initialized
DEBUG - 2017-03-03 18:17:58 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:17:58 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:17:58 --> Model Class Initialized
DEBUG - 2017-03-03 18:17:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:17:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:17:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:17:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/project_list.php
DEBUG - 2017-03-03 18:17:58 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:17:58 --> Final output sent to browser
DEBUG - 2017-03-03 18:17:58 --> Total execution time: 0.0209
INFO - 2017-03-03 18:18:04 --> Config Class Initialized
INFO - 2017-03-03 18:18:04 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:18:04 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:18:04 --> Utf8 Class Initialized
INFO - 2017-03-03 18:18:04 --> URI Class Initialized
INFO - 2017-03-03 18:18:04 --> Router Class Initialized
INFO - 2017-03-03 18:18:04 --> Output Class Initialized
INFO - 2017-03-03 18:18:04 --> Security Class Initialized
DEBUG - 2017-03-03 18:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:18:04 --> Input Class Initialized
INFO - 2017-03-03 18:18:04 --> Language Class Initialized
INFO - 2017-03-03 18:18:04 --> Language Class Initialized
INFO - 2017-03-03 18:18:04 --> Config Class Initialized
INFO - 2017-03-03 18:18:04 --> Loader Class Initialized
INFO - 2017-03-03 18:18:04 --> Helper loaded: form_helper
INFO - 2017-03-03 18:18:04 --> Helper loaded: url_helper
INFO - 2017-03-03 18:18:04 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:18:04 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:18:04 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:18:04 --> Template Class Initialized
INFO - 2017-03-03 18:18:04 --> Model Class Initialized
INFO - 2017-03-03 18:18:04 --> Controller Class Initialized
DEBUG - 2017-03-03 18:18:04 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:18:04 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:18:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:18:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:18:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:18:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 18:18:04 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:18:04 --> Final output sent to browser
DEBUG - 2017-03-03 18:18:04 --> Total execution time: 0.0162
INFO - 2017-03-03 18:19:04 --> Config Class Initialized
INFO - 2017-03-03 18:19:04 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:19:04 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:19:04 --> Utf8 Class Initialized
INFO - 2017-03-03 18:19:04 --> URI Class Initialized
INFO - 2017-03-03 18:19:04 --> Router Class Initialized
INFO - 2017-03-03 18:19:04 --> Output Class Initialized
INFO - 2017-03-03 18:19:04 --> Security Class Initialized
DEBUG - 2017-03-03 18:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:19:04 --> Input Class Initialized
INFO - 2017-03-03 18:19:04 --> Language Class Initialized
INFO - 2017-03-03 18:19:04 --> Language Class Initialized
INFO - 2017-03-03 18:19:04 --> Config Class Initialized
INFO - 2017-03-03 18:19:04 --> Loader Class Initialized
INFO - 2017-03-03 18:19:04 --> Helper loaded: form_helper
INFO - 2017-03-03 18:19:04 --> Helper loaded: url_helper
INFO - 2017-03-03 18:19:04 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:19:04 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:19:04 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:19:04 --> Template Class Initialized
INFO - 2017-03-03 18:19:04 --> Model Class Initialized
INFO - 2017-03-03 18:19:04 --> Controller Class Initialized
DEBUG - 2017-03-03 18:19:04 --> Download_data MX_Controller Initialized
INFO - 2017-03-03 18:19:04 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:19:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:19:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:19:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:19:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/download_data.php
DEBUG - 2017-03-03 18:19:04 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:19:04 --> Final output sent to browser
DEBUG - 2017-03-03 18:19:04 --> Total execution time: 0.0337
INFO - 2017-03-03 18:19:09 --> Config Class Initialized
INFO - 2017-03-03 18:19:09 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:19:09 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:19:09 --> Utf8 Class Initialized
INFO - 2017-03-03 18:19:09 --> URI Class Initialized
INFO - 2017-03-03 18:19:09 --> Router Class Initialized
INFO - 2017-03-03 18:19:09 --> Output Class Initialized
INFO - 2017-03-03 18:19:09 --> Security Class Initialized
DEBUG - 2017-03-03 18:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:19:09 --> Input Class Initialized
INFO - 2017-03-03 18:19:09 --> Language Class Initialized
INFO - 2017-03-03 18:19:09 --> Language Class Initialized
INFO - 2017-03-03 18:19:09 --> Config Class Initialized
INFO - 2017-03-03 18:19:09 --> Loader Class Initialized
INFO - 2017-03-03 18:19:09 --> Helper loaded: form_helper
INFO - 2017-03-03 18:19:09 --> Helper loaded: url_helper
INFO - 2017-03-03 18:19:09 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:19:09 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:19:09 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:19:09 --> Template Class Initialized
INFO - 2017-03-03 18:19:09 --> Model Class Initialized
INFO - 2017-03-03 18:19:09 --> Controller Class Initialized
DEBUG - 2017-03-03 18:19:09 --> Download_data MX_Controller Initialized
INFO - 2017-03-03 18:19:09 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:19:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:19:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:19:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:19:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/download_data.php
DEBUG - 2017-03-03 18:19:09 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:19:09 --> Final output sent to browser
DEBUG - 2017-03-03 18:19:09 --> Total execution time: 0.0145
INFO - 2017-03-03 18:19:13 --> Config Class Initialized
INFO - 2017-03-03 18:19:13 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:19:13 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:19:13 --> Utf8 Class Initialized
INFO - 2017-03-03 18:19:13 --> URI Class Initialized
INFO - 2017-03-03 18:19:13 --> Router Class Initialized
INFO - 2017-03-03 18:19:13 --> Output Class Initialized
INFO - 2017-03-03 18:19:13 --> Security Class Initialized
DEBUG - 2017-03-03 18:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:19:13 --> Input Class Initialized
INFO - 2017-03-03 18:19:13 --> Language Class Initialized
INFO - 2017-03-03 18:19:13 --> Language Class Initialized
INFO - 2017-03-03 18:19:13 --> Config Class Initialized
INFO - 2017-03-03 18:19:13 --> Loader Class Initialized
INFO - 2017-03-03 18:19:13 --> Helper loaded: form_helper
INFO - 2017-03-03 18:19:13 --> Helper loaded: url_helper
INFO - 2017-03-03 18:19:13 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:19:13 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:19:13 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:19:13 --> Template Class Initialized
INFO - 2017-03-03 18:19:13 --> Model Class Initialized
INFO - 2017-03-03 18:19:13 --> Controller Class Initialized
DEBUG - 2017-03-03 18:19:13 --> Store MX_Controller Initialized
INFO - 2017-03-03 18:19:13 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:19:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:19:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:19:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:19:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/product_list.php
DEBUG - 2017-03-03 18:19:13 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:19:13 --> Final output sent to browser
DEBUG - 2017-03-03 18:19:13 --> Total execution time: 0.0364
INFO - 2017-03-03 18:19:17 --> Config Class Initialized
INFO - 2017-03-03 18:19:17 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:19:17 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:19:17 --> Utf8 Class Initialized
INFO - 2017-03-03 18:19:17 --> URI Class Initialized
INFO - 2017-03-03 18:19:17 --> Router Class Initialized
INFO - 2017-03-03 18:19:17 --> Output Class Initialized
INFO - 2017-03-03 18:19:17 --> Security Class Initialized
DEBUG - 2017-03-03 18:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:19:17 --> Input Class Initialized
INFO - 2017-03-03 18:19:17 --> Language Class Initialized
INFO - 2017-03-03 18:19:18 --> Language Class Initialized
INFO - 2017-03-03 18:19:18 --> Config Class Initialized
INFO - 2017-03-03 18:19:18 --> Loader Class Initialized
INFO - 2017-03-03 18:19:18 --> Helper loaded: form_helper
INFO - 2017-03-03 18:19:18 --> Helper loaded: url_helper
INFO - 2017-03-03 18:19:18 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:19:18 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:19:18 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:19:18 --> Template Class Initialized
INFO - 2017-03-03 18:19:18 --> Model Class Initialized
INFO - 2017-03-03 18:19:18 --> Controller Class Initialized
DEBUG - 2017-03-03 18:19:18 --> Setting MX_Controller Initialized
INFO - 2017-03-03 18:19:18 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:19:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:19:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:19:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:19:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/payment_details.php
DEBUG - 2017-03-03 18:19:18 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:19:18 --> Final output sent to browser
DEBUG - 2017-03-03 18:19:18 --> Total execution time: 0.0730
INFO - 2017-03-03 18:19:20 --> Config Class Initialized
INFO - 2017-03-03 18:19:20 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:19:20 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:19:20 --> Utf8 Class Initialized
INFO - 2017-03-03 18:19:20 --> URI Class Initialized
INFO - 2017-03-03 18:19:20 --> Router Class Initialized
INFO - 2017-03-03 18:19:20 --> Output Class Initialized
INFO - 2017-03-03 18:19:20 --> Security Class Initialized
DEBUG - 2017-03-03 18:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:19:20 --> Input Class Initialized
INFO - 2017-03-03 18:19:20 --> Language Class Initialized
INFO - 2017-03-03 18:19:20 --> Language Class Initialized
INFO - 2017-03-03 18:19:20 --> Config Class Initialized
INFO - 2017-03-03 18:19:20 --> Loader Class Initialized
INFO - 2017-03-03 18:19:20 --> Helper loaded: form_helper
INFO - 2017-03-03 18:19:20 --> Helper loaded: url_helper
INFO - 2017-03-03 18:19:20 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:19:20 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:19:20 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:19:20 --> Template Class Initialized
INFO - 2017-03-03 18:19:20 --> Model Class Initialized
INFO - 2017-03-03 18:19:20 --> Controller Class Initialized
DEBUG - 2017-03-03 18:19:20 --> Setting MX_Controller Initialized
INFO - 2017-03-03 18:19:20 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:19:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:19:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:19:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:19:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/set_store_name.php
DEBUG - 2017-03-03 18:19:20 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:19:20 --> Final output sent to browser
DEBUG - 2017-03-03 18:19:20 --> Total execution time: 0.0151
INFO - 2017-03-03 18:19:25 --> Config Class Initialized
INFO - 2017-03-03 18:19:25 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:19:25 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:19:25 --> Utf8 Class Initialized
INFO - 2017-03-03 18:19:25 --> URI Class Initialized
INFO - 2017-03-03 18:19:25 --> Router Class Initialized
INFO - 2017-03-03 18:19:25 --> Output Class Initialized
INFO - 2017-03-03 18:19:25 --> Security Class Initialized
DEBUG - 2017-03-03 18:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:19:25 --> Input Class Initialized
INFO - 2017-03-03 18:19:25 --> Language Class Initialized
INFO - 2017-03-03 18:19:25 --> Language Class Initialized
INFO - 2017-03-03 18:19:25 --> Config Class Initialized
INFO - 2017-03-03 18:19:25 --> Loader Class Initialized
INFO - 2017-03-03 18:19:25 --> Helper loaded: form_helper
INFO - 2017-03-03 18:19:25 --> Helper loaded: url_helper
INFO - 2017-03-03 18:19:25 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:19:25 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:19:25 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:19:25 --> Template Class Initialized
INFO - 2017-03-03 18:19:25 --> Model Class Initialized
INFO - 2017-03-03 18:19:25 --> Controller Class Initialized
DEBUG - 2017-03-03 18:19:25 --> Subscriber MX_Controller Initialized
INFO - 2017-03-03 18:19:25 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:19:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:19:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:19:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:19:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/subscriber_list.php
DEBUG - 2017-03-03 18:19:25 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:19:25 --> Final output sent to browser
DEBUG - 2017-03-03 18:19:25 --> Total execution time: 0.0245
INFO - 2017-03-03 18:19:29 --> Config Class Initialized
INFO - 2017-03-03 18:19:29 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:19:29 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:19:29 --> Utf8 Class Initialized
INFO - 2017-03-03 18:19:29 --> URI Class Initialized
INFO - 2017-03-03 18:19:29 --> Router Class Initialized
INFO - 2017-03-03 18:19:29 --> Output Class Initialized
INFO - 2017-03-03 18:19:29 --> Security Class Initialized
DEBUG - 2017-03-03 18:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:19:29 --> Input Class Initialized
INFO - 2017-03-03 18:19:29 --> Language Class Initialized
INFO - 2017-03-03 18:19:29 --> Language Class Initialized
INFO - 2017-03-03 18:19:29 --> Config Class Initialized
INFO - 2017-03-03 18:19:29 --> Loader Class Initialized
INFO - 2017-03-03 18:19:29 --> Helper loaded: form_helper
INFO - 2017-03-03 18:19:29 --> Helper loaded: url_helper
INFO - 2017-03-03 18:19:29 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:19:29 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:19:29 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:19:29 --> Template Class Initialized
INFO - 2017-03-03 18:19:29 --> Model Class Initialized
INFO - 2017-03-03 18:19:29 --> Controller Class Initialized
DEBUG - 2017-03-03 18:19:29 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:19:29 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:19:29 --> Model Class Initialized
DEBUG - 2017-03-03 18:19:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:19:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:19:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:19:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/project_list.php
DEBUG - 2017-03-03 18:19:29 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:19:29 --> Final output sent to browser
DEBUG - 2017-03-03 18:19:29 --> Total execution time: 0.0169
INFO - 2017-03-03 18:20:19 --> Config Class Initialized
INFO - 2017-03-03 18:20:19 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:19 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:19 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:19 --> URI Class Initialized
INFO - 2017-03-03 18:20:19 --> Router Class Initialized
INFO - 2017-03-03 18:20:19 --> Output Class Initialized
INFO - 2017-03-03 18:20:19 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:19 --> Input Class Initialized
INFO - 2017-03-03 18:20:19 --> Language Class Initialized
INFO - 2017-03-03 18:20:19 --> Language Class Initialized
INFO - 2017-03-03 18:20:19 --> Config Class Initialized
INFO - 2017-03-03 18:20:19 --> Loader Class Initialized
INFO - 2017-03-03 18:20:19 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:19 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:19 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:19 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:19 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:19 --> Template Class Initialized
INFO - 2017-03-03 18:20:19 --> Model Class Initialized
INFO - 2017-03-03 18:20:19 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:19 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:20:19 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:20:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:20:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:20:21 --> Config Class Initialized
INFO - 2017-03-03 18:20:21 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:21 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:21 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:21 --> URI Class Initialized
INFO - 2017-03-03 18:20:21 --> Router Class Initialized
INFO - 2017-03-03 18:20:21 --> Output Class Initialized
INFO - 2017-03-03 18:20:21 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:21 --> Input Class Initialized
INFO - 2017-03-03 18:20:21 --> Language Class Initialized
INFO - 2017-03-03 18:20:21 --> Language Class Initialized
INFO - 2017-03-03 18:20:21 --> Config Class Initialized
INFO - 2017-03-03 18:20:21 --> Loader Class Initialized
INFO - 2017-03-03 18:20:21 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:21 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:21 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:21 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:21 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:21 --> Template Class Initialized
INFO - 2017-03-03 18:20:21 --> Model Class Initialized
INFO - 2017-03-03 18:20:21 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:21 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:20:21 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:20:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:20:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:20:28 --> Config Class Initialized
INFO - 2017-03-03 18:20:28 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:28 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:28 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:28 --> URI Class Initialized
INFO - 2017-03-03 18:20:28 --> Router Class Initialized
INFO - 2017-03-03 18:20:28 --> Output Class Initialized
INFO - 2017-03-03 18:20:28 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:28 --> Input Class Initialized
INFO - 2017-03-03 18:20:28 --> Language Class Initialized
INFO - 2017-03-03 18:20:28 --> Language Class Initialized
INFO - 2017-03-03 18:20:28 --> Config Class Initialized
INFO - 2017-03-03 18:20:28 --> Loader Class Initialized
INFO - 2017-03-03 18:20:28 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:28 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:28 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:28 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:28 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:28 --> Template Class Initialized
INFO - 2017-03-03 18:20:28 --> Model Class Initialized
INFO - 2017-03-03 18:20:28 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:28 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:20:28 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:20:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:20:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:20:30 --> Config Class Initialized
INFO - 2017-03-03 18:20:30 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:30 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:30 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:30 --> URI Class Initialized
INFO - 2017-03-03 18:20:30 --> Router Class Initialized
INFO - 2017-03-03 18:20:30 --> Output Class Initialized
INFO - 2017-03-03 18:20:30 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:30 --> Input Class Initialized
INFO - 2017-03-03 18:20:30 --> Language Class Initialized
INFO - 2017-03-03 18:20:30 --> Language Class Initialized
INFO - 2017-03-03 18:20:30 --> Config Class Initialized
INFO - 2017-03-03 18:20:30 --> Loader Class Initialized
INFO - 2017-03-03 18:20:30 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:30 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:30 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:30 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:30 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:30 --> Template Class Initialized
INFO - 2017-03-03 18:20:30 --> Model Class Initialized
INFO - 2017-03-03 18:20:30 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:30 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:20:30 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:20:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:20:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:20:30 --> Config Class Initialized
INFO - 2017-03-03 18:20:30 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:30 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:30 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:30 --> URI Class Initialized
INFO - 2017-03-03 18:20:30 --> Router Class Initialized
INFO - 2017-03-03 18:20:30 --> Output Class Initialized
INFO - 2017-03-03 18:20:30 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:30 --> Input Class Initialized
INFO - 2017-03-03 18:20:30 --> Language Class Initialized
INFO - 2017-03-03 18:20:30 --> Language Class Initialized
INFO - 2017-03-03 18:20:30 --> Config Class Initialized
INFO - 2017-03-03 18:20:30 --> Loader Class Initialized
INFO - 2017-03-03 18:20:30 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:30 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:30 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:30 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:30 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:30 --> Template Class Initialized
INFO - 2017-03-03 18:20:30 --> Model Class Initialized
INFO - 2017-03-03 18:20:30 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:30 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:20:30 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:20:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:20:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:20:31 --> Config Class Initialized
INFO - 2017-03-03 18:20:31 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:31 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:31 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:31 --> URI Class Initialized
INFO - 2017-03-03 18:20:31 --> Router Class Initialized
INFO - 2017-03-03 18:20:31 --> Output Class Initialized
INFO - 2017-03-03 18:20:31 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:31 --> Input Class Initialized
INFO - 2017-03-03 18:20:31 --> Language Class Initialized
INFO - 2017-03-03 18:20:31 --> Language Class Initialized
INFO - 2017-03-03 18:20:31 --> Config Class Initialized
INFO - 2017-03-03 18:20:31 --> Loader Class Initialized
INFO - 2017-03-03 18:20:31 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:31 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:31 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:31 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:31 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:31 --> Template Class Initialized
INFO - 2017-03-03 18:20:31 --> Model Class Initialized
INFO - 2017-03-03 18:20:31 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:31 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:20:31 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:20:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:20:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:20:32 --> Config Class Initialized
INFO - 2017-03-03 18:20:32 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:32 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:32 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:32 --> URI Class Initialized
INFO - 2017-03-03 18:20:32 --> Router Class Initialized
INFO - 2017-03-03 18:20:32 --> Output Class Initialized
INFO - 2017-03-03 18:20:32 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:32 --> Input Class Initialized
INFO - 2017-03-03 18:20:32 --> Language Class Initialized
INFO - 2017-03-03 18:20:32 --> Language Class Initialized
INFO - 2017-03-03 18:20:32 --> Config Class Initialized
INFO - 2017-03-03 18:20:32 --> Loader Class Initialized
INFO - 2017-03-03 18:20:32 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:32 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:32 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:32 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:32 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:32 --> Template Class Initialized
INFO - 2017-03-03 18:20:32 --> Model Class Initialized
INFO - 2017-03-03 18:20:32 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:32 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:20:32 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:20:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:20:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:20:32 --> Config Class Initialized
INFO - 2017-03-03 18:20:32 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:32 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:32 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:32 --> URI Class Initialized
INFO - 2017-03-03 18:20:32 --> Router Class Initialized
INFO - 2017-03-03 18:20:32 --> Output Class Initialized
INFO - 2017-03-03 18:20:32 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:32 --> Input Class Initialized
INFO - 2017-03-03 18:20:32 --> Language Class Initialized
INFO - 2017-03-03 18:20:32 --> Language Class Initialized
INFO - 2017-03-03 18:20:32 --> Config Class Initialized
INFO - 2017-03-03 18:20:32 --> Loader Class Initialized
INFO - 2017-03-03 18:20:32 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:32 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:32 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:32 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:32 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:32 --> Template Class Initialized
INFO - 2017-03-03 18:20:32 --> Model Class Initialized
INFO - 2017-03-03 18:20:32 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:32 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:20:32 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:20:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:20:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:20:33 --> Config Class Initialized
INFO - 2017-03-03 18:20:33 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:33 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:33 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:33 --> URI Class Initialized
INFO - 2017-03-03 18:20:33 --> Router Class Initialized
INFO - 2017-03-03 18:20:33 --> Output Class Initialized
INFO - 2017-03-03 18:20:33 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:33 --> Input Class Initialized
INFO - 2017-03-03 18:20:33 --> Language Class Initialized
INFO - 2017-03-03 18:20:33 --> Language Class Initialized
INFO - 2017-03-03 18:20:33 --> Config Class Initialized
INFO - 2017-03-03 18:20:33 --> Loader Class Initialized
INFO - 2017-03-03 18:20:33 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:33 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:33 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:33 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:33 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:33 --> Template Class Initialized
INFO - 2017-03-03 18:20:33 --> Model Class Initialized
INFO - 2017-03-03 18:20:33 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:33 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:20:33 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:20:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:20:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:20:34 --> Config Class Initialized
INFO - 2017-03-03 18:20:34 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:34 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:34 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:34 --> URI Class Initialized
INFO - 2017-03-03 18:20:34 --> Router Class Initialized
INFO - 2017-03-03 18:20:34 --> Output Class Initialized
INFO - 2017-03-03 18:20:34 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:34 --> Input Class Initialized
INFO - 2017-03-03 18:20:34 --> Language Class Initialized
INFO - 2017-03-03 18:20:34 --> Language Class Initialized
INFO - 2017-03-03 18:20:34 --> Config Class Initialized
INFO - 2017-03-03 18:20:34 --> Loader Class Initialized
INFO - 2017-03-03 18:20:34 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:34 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:34 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:34 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:34 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:34 --> Template Class Initialized
INFO - 2017-03-03 18:20:34 --> Model Class Initialized
INFO - 2017-03-03 18:20:34 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:34 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:20:34 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:20:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:20:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:20:34 --> Config Class Initialized
INFO - 2017-03-03 18:20:34 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:34 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:34 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:34 --> URI Class Initialized
INFO - 2017-03-03 18:20:34 --> Router Class Initialized
INFO - 2017-03-03 18:20:34 --> Output Class Initialized
INFO - 2017-03-03 18:20:34 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:34 --> Input Class Initialized
INFO - 2017-03-03 18:20:34 --> Language Class Initialized
INFO - 2017-03-03 18:20:34 --> Language Class Initialized
INFO - 2017-03-03 18:20:34 --> Config Class Initialized
INFO - 2017-03-03 18:20:34 --> Loader Class Initialized
INFO - 2017-03-03 18:20:34 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:34 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:34 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:34 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:34 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:34 --> Template Class Initialized
INFO - 2017-03-03 18:20:34 --> Model Class Initialized
INFO - 2017-03-03 18:20:34 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:34 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:20:34 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:20:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:20:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:20:35 --> Config Class Initialized
INFO - 2017-03-03 18:20:35 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:35 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:35 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:35 --> URI Class Initialized
INFO - 2017-03-03 18:20:35 --> Router Class Initialized
INFO - 2017-03-03 18:20:35 --> Output Class Initialized
INFO - 2017-03-03 18:20:35 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:35 --> Input Class Initialized
INFO - 2017-03-03 18:20:35 --> Language Class Initialized
INFO - 2017-03-03 18:20:35 --> Language Class Initialized
INFO - 2017-03-03 18:20:35 --> Config Class Initialized
INFO - 2017-03-03 18:20:35 --> Loader Class Initialized
INFO - 2017-03-03 18:20:35 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:35 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:35 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:35 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:35 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:35 --> Template Class Initialized
INFO - 2017-03-03 18:20:35 --> Model Class Initialized
INFO - 2017-03-03 18:20:35 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:35 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:20:35 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:20:35 --> Model Class Initialized
DEBUG - 2017-03-03 18:20:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:20:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:20:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:20:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 18:20:35 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:20:35 --> Final output sent to browser
DEBUG - 2017-03-03 18:20:35 --> Total execution time: 0.0170
INFO - 2017-03-03 18:20:42 --> Config Class Initialized
INFO - 2017-03-03 18:20:42 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:42 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:42 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:42 --> URI Class Initialized
INFO - 2017-03-03 18:20:42 --> Router Class Initialized
INFO - 2017-03-03 18:20:42 --> Output Class Initialized
INFO - 2017-03-03 18:20:42 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:42 --> Input Class Initialized
INFO - 2017-03-03 18:20:42 --> Language Class Initialized
INFO - 2017-03-03 18:20:42 --> Language Class Initialized
INFO - 2017-03-03 18:20:42 --> Config Class Initialized
INFO - 2017-03-03 18:20:42 --> Loader Class Initialized
INFO - 2017-03-03 18:20:42 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:42 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:42 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:42 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:42 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:42 --> Template Class Initialized
INFO - 2017-03-03 18:20:42 --> Model Class Initialized
INFO - 2017-03-03 18:20:42 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:42 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:20:42 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:20:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:20:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:20:45 --> Config Class Initialized
INFO - 2017-03-03 18:20:45 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:45 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:45 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:45 --> URI Class Initialized
INFO - 2017-03-03 18:20:45 --> Router Class Initialized
INFO - 2017-03-03 18:20:45 --> Output Class Initialized
INFO - 2017-03-03 18:20:45 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:45 --> Input Class Initialized
INFO - 2017-03-03 18:20:45 --> Language Class Initialized
INFO - 2017-03-03 18:20:45 --> Language Class Initialized
INFO - 2017-03-03 18:20:45 --> Config Class Initialized
INFO - 2017-03-03 18:20:45 --> Loader Class Initialized
INFO - 2017-03-03 18:20:45 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:45 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:45 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:45 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:45 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:45 --> Template Class Initialized
INFO - 2017-03-03 18:20:45 --> Model Class Initialized
INFO - 2017-03-03 18:20:45 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:45 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:20:45 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:20:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:20:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:20:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:20:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 18:20:45 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:20:45 --> Final output sent to browser
DEBUG - 2017-03-03 18:20:45 --> Total execution time: 0.0140
INFO - 2017-03-03 18:20:46 --> Config Class Initialized
INFO - 2017-03-03 18:20:46 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:46 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:46 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:46 --> URI Class Initialized
INFO - 2017-03-03 18:20:46 --> Router Class Initialized
INFO - 2017-03-03 18:20:46 --> Output Class Initialized
INFO - 2017-03-03 18:20:46 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:46 --> Input Class Initialized
INFO - 2017-03-03 18:20:46 --> Language Class Initialized
INFO - 2017-03-03 18:20:46 --> Language Class Initialized
INFO - 2017-03-03 18:20:46 --> Config Class Initialized
INFO - 2017-03-03 18:20:46 --> Loader Class Initialized
INFO - 2017-03-03 18:20:46 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:46 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:46 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:46 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:46 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:46 --> Template Class Initialized
INFO - 2017-03-03 18:20:46 --> Model Class Initialized
INFO - 2017-03-03 18:20:46 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:46 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:20:46 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:20:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:20:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:20:48 --> Config Class Initialized
INFO - 2017-03-03 18:20:48 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:48 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:48 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:48 --> URI Class Initialized
INFO - 2017-03-03 18:20:48 --> Router Class Initialized
INFO - 2017-03-03 18:20:48 --> Output Class Initialized
INFO - 2017-03-03 18:20:48 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:48 --> Input Class Initialized
INFO - 2017-03-03 18:20:48 --> Language Class Initialized
INFO - 2017-03-03 18:20:48 --> Language Class Initialized
INFO - 2017-03-03 18:20:48 --> Config Class Initialized
INFO - 2017-03-03 18:20:48 --> Loader Class Initialized
INFO - 2017-03-03 18:20:48 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:48 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:48 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:48 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:48 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:48 --> Template Class Initialized
INFO - 2017-03-03 18:20:48 --> Model Class Initialized
INFO - 2017-03-03 18:20:48 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:48 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:20:48 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:20:48 --> Model Class Initialized
DEBUG - 2017-03-03 18:20:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:20:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:20:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:20:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/project_list.php
DEBUG - 2017-03-03 18:20:48 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:20:48 --> Final output sent to browser
DEBUG - 2017-03-03 18:20:48 --> Total execution time: 0.0169
INFO - 2017-03-03 18:20:49 --> Config Class Initialized
INFO - 2017-03-03 18:20:49 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:49 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:49 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:49 --> URI Class Initialized
INFO - 2017-03-03 18:20:49 --> Router Class Initialized
INFO - 2017-03-03 18:20:49 --> Output Class Initialized
INFO - 2017-03-03 18:20:49 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:49 --> Input Class Initialized
INFO - 2017-03-03 18:20:49 --> Language Class Initialized
INFO - 2017-03-03 18:20:49 --> Language Class Initialized
INFO - 2017-03-03 18:20:49 --> Config Class Initialized
INFO - 2017-03-03 18:20:49 --> Loader Class Initialized
INFO - 2017-03-03 18:20:49 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:49 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:49 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:49 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:49 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:49 --> Template Class Initialized
INFO - 2017-03-03 18:20:49 --> Model Class Initialized
INFO - 2017-03-03 18:20:49 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:49 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:20:49 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:20:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:20:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:20:52 --> Config Class Initialized
INFO - 2017-03-03 18:20:52 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:52 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:52 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:52 --> URI Class Initialized
INFO - 2017-03-03 18:20:52 --> Router Class Initialized
INFO - 2017-03-03 18:20:52 --> Output Class Initialized
INFO - 2017-03-03 18:20:52 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:52 --> Input Class Initialized
INFO - 2017-03-03 18:20:52 --> Language Class Initialized
INFO - 2017-03-03 18:20:52 --> Language Class Initialized
INFO - 2017-03-03 18:20:52 --> Config Class Initialized
INFO - 2017-03-03 18:20:52 --> Loader Class Initialized
INFO - 2017-03-03 18:20:52 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:52 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:52 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:52 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:52 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:52 --> Template Class Initialized
INFO - 2017-03-03 18:20:52 --> Model Class Initialized
INFO - 2017-03-03 18:20:52 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:52 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:20:52 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:20:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:20:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:20:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:20:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 18:20:52 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:20:52 --> Final output sent to browser
DEBUG - 2017-03-03 18:20:52 --> Total execution time: 0.0148
INFO - 2017-03-03 18:20:53 --> Config Class Initialized
INFO - 2017-03-03 18:20:53 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:20:53 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:20:53 --> Utf8 Class Initialized
INFO - 2017-03-03 18:20:53 --> URI Class Initialized
INFO - 2017-03-03 18:20:53 --> Router Class Initialized
INFO - 2017-03-03 18:20:53 --> Output Class Initialized
INFO - 2017-03-03 18:20:53 --> Security Class Initialized
DEBUG - 2017-03-03 18:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:20:53 --> Input Class Initialized
INFO - 2017-03-03 18:20:53 --> Language Class Initialized
INFO - 2017-03-03 18:20:53 --> Language Class Initialized
INFO - 2017-03-03 18:20:53 --> Config Class Initialized
INFO - 2017-03-03 18:20:53 --> Loader Class Initialized
INFO - 2017-03-03 18:20:53 --> Helper loaded: form_helper
INFO - 2017-03-03 18:20:53 --> Helper loaded: url_helper
INFO - 2017-03-03 18:20:53 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:20:53 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:20:53 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:20:53 --> Template Class Initialized
INFO - 2017-03-03 18:20:53 --> Model Class Initialized
INFO - 2017-03-03 18:20:53 --> Controller Class Initialized
DEBUG - 2017-03-03 18:20:53 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:20:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:20:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:20:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:21:11 --> Config Class Initialized
INFO - 2017-03-03 18:21:11 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:11 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:11 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:11 --> URI Class Initialized
INFO - 2017-03-03 18:21:11 --> Router Class Initialized
INFO - 2017-03-03 18:21:11 --> Output Class Initialized
INFO - 2017-03-03 18:21:11 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:11 --> Input Class Initialized
INFO - 2017-03-03 18:21:11 --> Language Class Initialized
INFO - 2017-03-03 18:21:11 --> Language Class Initialized
INFO - 2017-03-03 18:21:11 --> Config Class Initialized
INFO - 2017-03-03 18:21:11 --> Loader Class Initialized
INFO - 2017-03-03 18:21:11 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:11 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:11 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:11 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:11 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:11 --> Template Class Initialized
INFO - 2017-03-03 18:21:11 --> Model Class Initialized
INFO - 2017-03-03 18:21:11 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:11 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:21:11 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:21:11 --> Model Class Initialized
INFO - 2017-03-03 18:21:11 --> Config Class Initialized
INFO - 2017-03-03 18:21:11 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:11 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:11 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:11 --> URI Class Initialized
INFO - 2017-03-03 18:21:11 --> Router Class Initialized
INFO - 2017-03-03 18:21:11 --> Output Class Initialized
INFO - 2017-03-03 18:21:11 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:11 --> Input Class Initialized
INFO - 2017-03-03 18:21:11 --> Language Class Initialized
INFO - 2017-03-03 18:21:11 --> Language Class Initialized
INFO - 2017-03-03 18:21:11 --> Config Class Initialized
INFO - 2017-03-03 18:21:11 --> Loader Class Initialized
INFO - 2017-03-03 18:21:11 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:11 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:11 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:11 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:11 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:11 --> Template Class Initialized
INFO - 2017-03-03 18:21:11 --> Model Class Initialized
INFO - 2017-03-03 18:21:11 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:11 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:21:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:21:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:21:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:21:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:21:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 18:21:11 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:21:11 --> Final output sent to browser
DEBUG - 2017-03-03 18:21:11 --> Total execution time: 0.0142
INFO - 2017-03-03 18:21:12 --> Config Class Initialized
INFO - 2017-03-03 18:21:12 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:12 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:12 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:12 --> URI Class Initialized
INFO - 2017-03-03 18:21:12 --> Router Class Initialized
INFO - 2017-03-03 18:21:12 --> Output Class Initialized
INFO - 2017-03-03 18:21:12 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:12 --> Input Class Initialized
INFO - 2017-03-03 18:21:12 --> Language Class Initialized
INFO - 2017-03-03 18:21:12 --> Language Class Initialized
INFO - 2017-03-03 18:21:12 --> Config Class Initialized
INFO - 2017-03-03 18:21:12 --> Loader Class Initialized
INFO - 2017-03-03 18:21:12 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:12 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:12 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:12 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:12 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:12 --> Template Class Initialized
INFO - 2017-03-03 18:21:12 --> Model Class Initialized
INFO - 2017-03-03 18:21:12 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:12 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:21:12 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:21:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:21:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:21:15 --> Config Class Initialized
INFO - 2017-03-03 18:21:15 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:15 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:15 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:15 --> URI Class Initialized
INFO - 2017-03-03 18:21:15 --> Router Class Initialized
INFO - 2017-03-03 18:21:15 --> Output Class Initialized
INFO - 2017-03-03 18:21:15 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:15 --> Input Class Initialized
INFO - 2017-03-03 18:21:15 --> Language Class Initialized
INFO - 2017-03-03 18:21:15 --> Language Class Initialized
INFO - 2017-03-03 18:21:15 --> Config Class Initialized
INFO - 2017-03-03 18:21:15 --> Loader Class Initialized
INFO - 2017-03-03 18:21:15 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:15 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:15 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:15 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:15 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:15 --> Template Class Initialized
INFO - 2017-03-03 18:21:15 --> Model Class Initialized
INFO - 2017-03-03 18:21:15 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:15 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:21:15 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:21:15 --> Model Class Initialized
DEBUG - 2017-03-03 18:21:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:21:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:21:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:21:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/project_list.php
DEBUG - 2017-03-03 18:21:15 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:21:15 --> Final output sent to browser
DEBUG - 2017-03-03 18:21:15 --> Total execution time: 0.0153
INFO - 2017-03-03 18:21:16 --> Config Class Initialized
INFO - 2017-03-03 18:21:16 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:16 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:16 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:16 --> URI Class Initialized
INFO - 2017-03-03 18:21:16 --> Router Class Initialized
INFO - 2017-03-03 18:21:16 --> Output Class Initialized
INFO - 2017-03-03 18:21:16 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:16 --> Input Class Initialized
INFO - 2017-03-03 18:21:16 --> Language Class Initialized
INFO - 2017-03-03 18:21:16 --> Language Class Initialized
INFO - 2017-03-03 18:21:16 --> Config Class Initialized
INFO - 2017-03-03 18:21:16 --> Loader Class Initialized
INFO - 2017-03-03 18:21:16 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:16 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:16 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:16 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:16 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:16 --> Template Class Initialized
INFO - 2017-03-03 18:21:16 --> Model Class Initialized
INFO - 2017-03-03 18:21:16 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:16 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:21:16 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:21:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:21:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:21:20 --> Config Class Initialized
INFO - 2017-03-03 18:21:20 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:20 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:20 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:20 --> URI Class Initialized
INFO - 2017-03-03 18:21:20 --> Router Class Initialized
INFO - 2017-03-03 18:21:20 --> Output Class Initialized
INFO - 2017-03-03 18:21:20 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:20 --> Input Class Initialized
INFO - 2017-03-03 18:21:20 --> Language Class Initialized
INFO - 2017-03-03 18:21:20 --> Language Class Initialized
INFO - 2017-03-03 18:21:20 --> Config Class Initialized
INFO - 2017-03-03 18:21:20 --> Loader Class Initialized
INFO - 2017-03-03 18:21:20 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:20 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:20 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:20 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:20 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:20 --> Template Class Initialized
INFO - 2017-03-03 18:21:20 --> Model Class Initialized
INFO - 2017-03-03 18:21:20 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:20 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:21:20 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:21:20 --> Model Class Initialized
DEBUG - 2017-03-03 18:21:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:21:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:21:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:21:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 18:21:20 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:21:20 --> Final output sent to browser
DEBUG - 2017-03-03 18:21:20 --> Total execution time: 0.0158
INFO - 2017-03-03 18:21:21 --> Config Class Initialized
INFO - 2017-03-03 18:21:21 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:21 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:21 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:21 --> URI Class Initialized
INFO - 2017-03-03 18:21:21 --> Router Class Initialized
INFO - 2017-03-03 18:21:21 --> Output Class Initialized
INFO - 2017-03-03 18:21:21 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:21 --> Input Class Initialized
INFO - 2017-03-03 18:21:21 --> Language Class Initialized
INFO - 2017-03-03 18:21:21 --> Language Class Initialized
INFO - 2017-03-03 18:21:21 --> Config Class Initialized
INFO - 2017-03-03 18:21:21 --> Loader Class Initialized
INFO - 2017-03-03 18:21:21 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:21 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:21 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:21 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:21 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:21 --> Template Class Initialized
INFO - 2017-03-03 18:21:21 --> Model Class Initialized
INFO - 2017-03-03 18:21:21 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:21 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:21:21 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:21:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:21:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:21:24 --> Config Class Initialized
INFO - 2017-03-03 18:21:24 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:24 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:24 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:24 --> URI Class Initialized
INFO - 2017-03-03 18:21:24 --> Router Class Initialized
INFO - 2017-03-03 18:21:24 --> Output Class Initialized
INFO - 2017-03-03 18:21:24 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:24 --> Input Class Initialized
INFO - 2017-03-03 18:21:24 --> Language Class Initialized
INFO - 2017-03-03 18:21:24 --> Language Class Initialized
INFO - 2017-03-03 18:21:24 --> Config Class Initialized
INFO - 2017-03-03 18:21:24 --> Loader Class Initialized
INFO - 2017-03-03 18:21:24 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:24 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:24 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:24 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:24 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:24 --> Template Class Initialized
INFO - 2017-03-03 18:21:24 --> Model Class Initialized
INFO - 2017-03-03 18:21:24 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:24 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:21:24 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:21:24 --> Final output sent to browser
DEBUG - 2017-03-03 18:21:24 --> Total execution time: 0.0132
INFO - 2017-03-03 18:21:28 --> Config Class Initialized
INFO - 2017-03-03 18:21:28 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:28 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:28 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:28 --> URI Class Initialized
INFO - 2017-03-03 18:21:28 --> Router Class Initialized
INFO - 2017-03-03 18:21:28 --> Output Class Initialized
INFO - 2017-03-03 18:21:28 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:28 --> Input Class Initialized
INFO - 2017-03-03 18:21:28 --> Language Class Initialized
INFO - 2017-03-03 18:21:28 --> Language Class Initialized
INFO - 2017-03-03 18:21:28 --> Config Class Initialized
INFO - 2017-03-03 18:21:28 --> Loader Class Initialized
INFO - 2017-03-03 18:21:28 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:28 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:28 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:28 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:28 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:28 --> Template Class Initialized
INFO - 2017-03-03 18:21:28 --> Model Class Initialized
INFO - 2017-03-03 18:21:28 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:28 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:21:28 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:21:28 --> Upload Class Initialized
INFO - 2017-03-03 18:21:28 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-03-03 18:21:28 --> The upload path does not appear to be valid.
INFO - 2017-03-03 18:21:28 --> Model Class Initialized
INFO - 2017-03-03 18:21:28 --> Final output sent to browser
DEBUG - 2017-03-03 18:21:28 --> Total execution time: 0.0155
INFO - 2017-03-03 18:21:34 --> Config Class Initialized
INFO - 2017-03-03 18:21:34 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:34 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:34 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:34 --> URI Class Initialized
INFO - 2017-03-03 18:21:34 --> Router Class Initialized
INFO - 2017-03-03 18:21:34 --> Output Class Initialized
INFO - 2017-03-03 18:21:34 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:34 --> Input Class Initialized
INFO - 2017-03-03 18:21:34 --> Language Class Initialized
INFO - 2017-03-03 18:21:34 --> Language Class Initialized
INFO - 2017-03-03 18:21:34 --> Config Class Initialized
INFO - 2017-03-03 18:21:34 --> Loader Class Initialized
INFO - 2017-03-03 18:21:34 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:34 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:34 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:34 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:34 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:34 --> Template Class Initialized
INFO - 2017-03-03 18:21:34 --> Model Class Initialized
INFO - 2017-03-03 18:21:34 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:34 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:21:34 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:21:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:21:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:21:39 --> Config Class Initialized
INFO - 2017-03-03 18:21:39 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:39 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:39 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:39 --> URI Class Initialized
INFO - 2017-03-03 18:21:39 --> Router Class Initialized
INFO - 2017-03-03 18:21:39 --> Output Class Initialized
INFO - 2017-03-03 18:21:39 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:39 --> Input Class Initialized
INFO - 2017-03-03 18:21:39 --> Language Class Initialized
INFO - 2017-03-03 18:21:39 --> Language Class Initialized
INFO - 2017-03-03 18:21:39 --> Config Class Initialized
INFO - 2017-03-03 18:21:39 --> Loader Class Initialized
INFO - 2017-03-03 18:21:39 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:39 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:39 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:39 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:39 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:39 --> Template Class Initialized
INFO - 2017-03-03 18:21:39 --> Model Class Initialized
INFO - 2017-03-03 18:21:39 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:39 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:21:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:21:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:21:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:21:41 --> Config Class Initialized
INFO - 2017-03-03 18:21:41 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:41 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:41 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:41 --> URI Class Initialized
INFO - 2017-03-03 18:21:41 --> Router Class Initialized
INFO - 2017-03-03 18:21:41 --> Output Class Initialized
INFO - 2017-03-03 18:21:41 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:41 --> Input Class Initialized
INFO - 2017-03-03 18:21:41 --> Language Class Initialized
INFO - 2017-03-03 18:21:41 --> Language Class Initialized
INFO - 2017-03-03 18:21:41 --> Config Class Initialized
INFO - 2017-03-03 18:21:41 --> Loader Class Initialized
INFO - 2017-03-03 18:21:41 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:41 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:41 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:41 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:41 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:41 --> Template Class Initialized
INFO - 2017-03-03 18:21:41 --> Model Class Initialized
INFO - 2017-03-03 18:21:41 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:41 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:21:41 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:21:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:21:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:21:44 --> Config Class Initialized
INFO - 2017-03-03 18:21:44 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:44 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:44 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:44 --> URI Class Initialized
INFO - 2017-03-03 18:21:44 --> Router Class Initialized
INFO - 2017-03-03 18:21:44 --> Output Class Initialized
INFO - 2017-03-03 18:21:44 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:44 --> Input Class Initialized
INFO - 2017-03-03 18:21:44 --> Language Class Initialized
INFO - 2017-03-03 18:21:44 --> Language Class Initialized
INFO - 2017-03-03 18:21:44 --> Config Class Initialized
INFO - 2017-03-03 18:21:44 --> Loader Class Initialized
INFO - 2017-03-03 18:21:44 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:44 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:44 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:44 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:44 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:44 --> Template Class Initialized
INFO - 2017-03-03 18:21:44 --> Model Class Initialized
INFO - 2017-03-03 18:21:44 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:44 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:21:44 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:21:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:21:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:21:45 --> Config Class Initialized
INFO - 2017-03-03 18:21:45 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:45 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:45 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:45 --> URI Class Initialized
INFO - 2017-03-03 18:21:45 --> Router Class Initialized
INFO - 2017-03-03 18:21:45 --> Output Class Initialized
INFO - 2017-03-03 18:21:45 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:45 --> Input Class Initialized
INFO - 2017-03-03 18:21:45 --> Language Class Initialized
INFO - 2017-03-03 18:21:45 --> Language Class Initialized
INFO - 2017-03-03 18:21:45 --> Config Class Initialized
INFO - 2017-03-03 18:21:45 --> Loader Class Initialized
INFO - 2017-03-03 18:21:45 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:45 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:45 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:45 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:45 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:45 --> Template Class Initialized
INFO - 2017-03-03 18:21:45 --> Model Class Initialized
INFO - 2017-03-03 18:21:45 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:45 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:21:45 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:21:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:21:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:21:47 --> Config Class Initialized
INFO - 2017-03-03 18:21:47 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:47 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:47 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:47 --> URI Class Initialized
INFO - 2017-03-03 18:21:47 --> Router Class Initialized
INFO - 2017-03-03 18:21:47 --> Output Class Initialized
INFO - 2017-03-03 18:21:47 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:47 --> Input Class Initialized
INFO - 2017-03-03 18:21:47 --> Language Class Initialized
INFO - 2017-03-03 18:21:47 --> Language Class Initialized
INFO - 2017-03-03 18:21:47 --> Config Class Initialized
INFO - 2017-03-03 18:21:47 --> Loader Class Initialized
INFO - 2017-03-03 18:21:47 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:47 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:47 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:47 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:47 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:47 --> Template Class Initialized
INFO - 2017-03-03 18:21:47 --> Model Class Initialized
INFO - 2017-03-03 18:21:47 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:47 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:21:47 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:21:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:21:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:21:49 --> Config Class Initialized
INFO - 2017-03-03 18:21:49 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:49 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:49 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:49 --> URI Class Initialized
INFO - 2017-03-03 18:21:49 --> Router Class Initialized
INFO - 2017-03-03 18:21:49 --> Output Class Initialized
INFO - 2017-03-03 18:21:49 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:49 --> Input Class Initialized
INFO - 2017-03-03 18:21:49 --> Language Class Initialized
INFO - 2017-03-03 18:21:49 --> Language Class Initialized
INFO - 2017-03-03 18:21:49 --> Config Class Initialized
INFO - 2017-03-03 18:21:49 --> Loader Class Initialized
INFO - 2017-03-03 18:21:49 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:49 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:49 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:49 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:49 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:49 --> Template Class Initialized
INFO - 2017-03-03 18:21:49 --> Model Class Initialized
INFO - 2017-03-03 18:21:49 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:49 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:21:49 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:21:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:21:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:21:50 --> Config Class Initialized
INFO - 2017-03-03 18:21:50 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:50 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:50 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:50 --> URI Class Initialized
INFO - 2017-03-03 18:21:50 --> Router Class Initialized
INFO - 2017-03-03 18:21:50 --> Output Class Initialized
INFO - 2017-03-03 18:21:50 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:50 --> Input Class Initialized
INFO - 2017-03-03 18:21:50 --> Language Class Initialized
INFO - 2017-03-03 18:21:50 --> Language Class Initialized
INFO - 2017-03-03 18:21:50 --> Config Class Initialized
INFO - 2017-03-03 18:21:50 --> Loader Class Initialized
INFO - 2017-03-03 18:21:50 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:50 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:50 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:50 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:50 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:50 --> Template Class Initialized
INFO - 2017-03-03 18:21:50 --> Model Class Initialized
INFO - 2017-03-03 18:21:50 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:50 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:21:50 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:21:50 --> Model Class Initialized
DEBUG - 2017-03-03 18:21:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:21:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:21:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:21:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 18:21:50 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:21:50 --> Final output sent to browser
DEBUG - 2017-03-03 18:21:50 --> Total execution time: 0.0162
INFO - 2017-03-03 18:21:50 --> Config Class Initialized
INFO - 2017-03-03 18:21:50 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:50 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:50 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:50 --> URI Class Initialized
INFO - 2017-03-03 18:21:50 --> Router Class Initialized
INFO - 2017-03-03 18:21:50 --> Output Class Initialized
INFO - 2017-03-03 18:21:50 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:50 --> Input Class Initialized
INFO - 2017-03-03 18:21:50 --> Language Class Initialized
INFO - 2017-03-03 18:21:50 --> Language Class Initialized
INFO - 2017-03-03 18:21:50 --> Config Class Initialized
INFO - 2017-03-03 18:21:50 --> Loader Class Initialized
INFO - 2017-03-03 18:21:50 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:50 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:50 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:50 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:50 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:50 --> Template Class Initialized
INFO - 2017-03-03 18:21:50 --> Model Class Initialized
INFO - 2017-03-03 18:21:50 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:50 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:21:50 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:21:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:21:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:21:52 --> Config Class Initialized
INFO - 2017-03-03 18:21:52 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:52 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:52 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:52 --> URI Class Initialized
INFO - 2017-03-03 18:21:52 --> Router Class Initialized
INFO - 2017-03-03 18:21:52 --> Output Class Initialized
INFO - 2017-03-03 18:21:52 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:52 --> Input Class Initialized
INFO - 2017-03-03 18:21:52 --> Language Class Initialized
INFO - 2017-03-03 18:21:52 --> Language Class Initialized
INFO - 2017-03-03 18:21:52 --> Config Class Initialized
INFO - 2017-03-03 18:21:52 --> Loader Class Initialized
INFO - 2017-03-03 18:21:52 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:52 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:52 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:52 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:52 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:52 --> Template Class Initialized
INFO - 2017-03-03 18:21:52 --> Model Class Initialized
INFO - 2017-03-03 18:21:52 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:52 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:21:52 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:21:52 --> Model Class Initialized
DEBUG - 2017-03-03 18:21:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:21:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:21:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:21:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 18:21:52 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:21:52 --> Final output sent to browser
DEBUG - 2017-03-03 18:21:52 --> Total execution time: 0.0193
INFO - 2017-03-03 18:21:53 --> Config Class Initialized
INFO - 2017-03-03 18:21:53 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:53 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:53 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:53 --> URI Class Initialized
INFO - 2017-03-03 18:21:53 --> Router Class Initialized
INFO - 2017-03-03 18:21:53 --> Output Class Initialized
INFO - 2017-03-03 18:21:53 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:53 --> Input Class Initialized
INFO - 2017-03-03 18:21:53 --> Language Class Initialized
INFO - 2017-03-03 18:21:53 --> Language Class Initialized
INFO - 2017-03-03 18:21:53 --> Config Class Initialized
INFO - 2017-03-03 18:21:53 --> Loader Class Initialized
INFO - 2017-03-03 18:21:53 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:53 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:53 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:53 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:53 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:53 --> Template Class Initialized
INFO - 2017-03-03 18:21:53 --> Model Class Initialized
INFO - 2017-03-03 18:21:53 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:53 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:21:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:21:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:21:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:21:55 --> Config Class Initialized
INFO - 2017-03-03 18:21:55 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:55 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:55 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:55 --> URI Class Initialized
INFO - 2017-03-03 18:21:55 --> Router Class Initialized
INFO - 2017-03-03 18:21:55 --> Output Class Initialized
INFO - 2017-03-03 18:21:55 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:55 --> Input Class Initialized
INFO - 2017-03-03 18:21:55 --> Language Class Initialized
INFO - 2017-03-03 18:21:55 --> Language Class Initialized
INFO - 2017-03-03 18:21:55 --> Config Class Initialized
INFO - 2017-03-03 18:21:55 --> Loader Class Initialized
INFO - 2017-03-03 18:21:55 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:55 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:55 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:55 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:55 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:55 --> Template Class Initialized
INFO - 2017-03-03 18:21:55 --> Model Class Initialized
INFO - 2017-03-03 18:21:55 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:55 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:21:55 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:21:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:21:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:21:57 --> Config Class Initialized
INFO - 2017-03-03 18:21:57 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:57 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:57 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:57 --> URI Class Initialized
INFO - 2017-03-03 18:21:57 --> Router Class Initialized
INFO - 2017-03-03 18:21:57 --> Output Class Initialized
INFO - 2017-03-03 18:21:57 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:57 --> Input Class Initialized
INFO - 2017-03-03 18:21:57 --> Language Class Initialized
INFO - 2017-03-03 18:21:57 --> Language Class Initialized
INFO - 2017-03-03 18:21:57 --> Config Class Initialized
INFO - 2017-03-03 18:21:57 --> Loader Class Initialized
INFO - 2017-03-03 18:21:57 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:57 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:57 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:57 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:57 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:57 --> Template Class Initialized
INFO - 2017-03-03 18:21:57 --> Model Class Initialized
INFO - 2017-03-03 18:21:57 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:57 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:21:57 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:21:57 --> Model Class Initialized
DEBUG - 2017-03-03 18:21:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:21:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:21:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:21:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 18:21:57 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:21:57 --> Final output sent to browser
DEBUG - 2017-03-03 18:21:57 --> Total execution time: 0.0179
INFO - 2017-03-03 18:21:57 --> Config Class Initialized
INFO - 2017-03-03 18:21:57 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:57 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:57 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:57 --> URI Class Initialized
INFO - 2017-03-03 18:21:57 --> Router Class Initialized
INFO - 2017-03-03 18:21:57 --> Output Class Initialized
INFO - 2017-03-03 18:21:57 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:57 --> Input Class Initialized
INFO - 2017-03-03 18:21:57 --> Language Class Initialized
INFO - 2017-03-03 18:21:57 --> Language Class Initialized
INFO - 2017-03-03 18:21:57 --> Config Class Initialized
INFO - 2017-03-03 18:21:57 --> Loader Class Initialized
INFO - 2017-03-03 18:21:57 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:57 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:57 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:57 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:57 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:57 --> Template Class Initialized
INFO - 2017-03-03 18:21:57 --> Model Class Initialized
INFO - 2017-03-03 18:21:57 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:57 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:21:57 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:21:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:21:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:21:59 --> Config Class Initialized
INFO - 2017-03-03 18:21:59 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:21:59 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:21:59 --> Utf8 Class Initialized
INFO - 2017-03-03 18:21:59 --> URI Class Initialized
INFO - 2017-03-03 18:21:59 --> Router Class Initialized
INFO - 2017-03-03 18:21:59 --> Output Class Initialized
INFO - 2017-03-03 18:21:59 --> Security Class Initialized
DEBUG - 2017-03-03 18:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:21:59 --> Input Class Initialized
INFO - 2017-03-03 18:21:59 --> Language Class Initialized
INFO - 2017-03-03 18:21:59 --> Language Class Initialized
INFO - 2017-03-03 18:21:59 --> Config Class Initialized
INFO - 2017-03-03 18:21:59 --> Loader Class Initialized
INFO - 2017-03-03 18:21:59 --> Helper loaded: form_helper
INFO - 2017-03-03 18:21:59 --> Helper loaded: url_helper
INFO - 2017-03-03 18:21:59 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:21:59 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:21:59 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:21:59 --> Template Class Initialized
INFO - 2017-03-03 18:21:59 --> Model Class Initialized
INFO - 2017-03-03 18:21:59 --> Controller Class Initialized
DEBUG - 2017-03-03 18:21:59 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:21:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:21:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:21:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:21:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:21:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 18:21:59 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:21:59 --> Final output sent to browser
DEBUG - 2017-03-03 18:21:59 --> Total execution time: 0.0163
INFO - 2017-03-03 18:22:00 --> Config Class Initialized
INFO - 2017-03-03 18:22:00 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:22:00 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:22:00 --> Utf8 Class Initialized
INFO - 2017-03-03 18:22:00 --> URI Class Initialized
INFO - 2017-03-03 18:22:00 --> Router Class Initialized
INFO - 2017-03-03 18:22:00 --> Output Class Initialized
INFO - 2017-03-03 18:22:00 --> Security Class Initialized
DEBUG - 2017-03-03 18:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:22:00 --> Input Class Initialized
INFO - 2017-03-03 18:22:00 --> Language Class Initialized
INFO - 2017-03-03 18:22:00 --> Language Class Initialized
INFO - 2017-03-03 18:22:00 --> Config Class Initialized
INFO - 2017-03-03 18:22:00 --> Loader Class Initialized
INFO - 2017-03-03 18:22:00 --> Helper loaded: form_helper
INFO - 2017-03-03 18:22:00 --> Helper loaded: url_helper
INFO - 2017-03-03 18:22:00 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:22:00 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:22:00 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:22:00 --> Template Class Initialized
INFO - 2017-03-03 18:22:00 --> Model Class Initialized
INFO - 2017-03-03 18:22:00 --> Controller Class Initialized
DEBUG - 2017-03-03 18:22:00 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:22:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:22:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:22:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:22:01 --> Config Class Initialized
INFO - 2017-03-03 18:22:01 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:22:01 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:22:01 --> Utf8 Class Initialized
INFO - 2017-03-03 18:22:01 --> URI Class Initialized
INFO - 2017-03-03 18:22:01 --> Router Class Initialized
INFO - 2017-03-03 18:22:01 --> Output Class Initialized
INFO - 2017-03-03 18:22:01 --> Security Class Initialized
DEBUG - 2017-03-03 18:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:22:01 --> Input Class Initialized
INFO - 2017-03-03 18:22:01 --> Language Class Initialized
INFO - 2017-03-03 18:22:01 --> Language Class Initialized
INFO - 2017-03-03 18:22:01 --> Config Class Initialized
INFO - 2017-03-03 18:22:01 --> Loader Class Initialized
INFO - 2017-03-03 18:22:01 --> Helper loaded: form_helper
INFO - 2017-03-03 18:22:01 --> Helper loaded: url_helper
INFO - 2017-03-03 18:22:01 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:22:01 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:22:01 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:22:01 --> Template Class Initialized
INFO - 2017-03-03 18:22:01 --> Model Class Initialized
INFO - 2017-03-03 18:22:01 --> Controller Class Initialized
DEBUG - 2017-03-03 18:22:01 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:22:01 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:22:01 --> Model Class Initialized
DEBUG - 2017-03-03 18:22:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:22:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:22:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:22:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 18:22:01 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:22:01 --> Final output sent to browser
DEBUG - 2017-03-03 18:22:01 --> Total execution time: 0.0167
INFO - 2017-03-03 18:22:02 --> Config Class Initialized
INFO - 2017-03-03 18:22:02 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:22:02 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:22:02 --> Utf8 Class Initialized
INFO - 2017-03-03 18:22:02 --> URI Class Initialized
INFO - 2017-03-03 18:22:02 --> Router Class Initialized
INFO - 2017-03-03 18:22:02 --> Output Class Initialized
INFO - 2017-03-03 18:22:02 --> Security Class Initialized
DEBUG - 2017-03-03 18:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:22:02 --> Input Class Initialized
INFO - 2017-03-03 18:22:02 --> Language Class Initialized
INFO - 2017-03-03 18:22:02 --> Language Class Initialized
INFO - 2017-03-03 18:22:02 --> Config Class Initialized
INFO - 2017-03-03 18:22:02 --> Loader Class Initialized
INFO - 2017-03-03 18:22:02 --> Helper loaded: form_helper
INFO - 2017-03-03 18:22:02 --> Helper loaded: url_helper
INFO - 2017-03-03 18:22:02 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:22:02 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:22:02 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:22:02 --> Template Class Initialized
INFO - 2017-03-03 18:22:02 --> Model Class Initialized
INFO - 2017-03-03 18:22:02 --> Controller Class Initialized
DEBUG - 2017-03-03 18:22:02 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:22:02 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:22:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:22:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:22:05 --> Config Class Initialized
INFO - 2017-03-03 18:22:05 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:22:05 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:22:05 --> Utf8 Class Initialized
INFO - 2017-03-03 18:22:05 --> URI Class Initialized
INFO - 2017-03-03 18:22:05 --> Router Class Initialized
INFO - 2017-03-03 18:22:05 --> Output Class Initialized
INFO - 2017-03-03 18:22:05 --> Security Class Initialized
DEBUG - 2017-03-03 18:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:22:05 --> Input Class Initialized
INFO - 2017-03-03 18:22:05 --> Language Class Initialized
INFO - 2017-03-03 18:22:05 --> Language Class Initialized
INFO - 2017-03-03 18:22:05 --> Config Class Initialized
INFO - 2017-03-03 18:22:05 --> Loader Class Initialized
INFO - 2017-03-03 18:22:05 --> Helper loaded: form_helper
INFO - 2017-03-03 18:22:05 --> Helper loaded: url_helper
INFO - 2017-03-03 18:22:05 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:22:05 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:22:05 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:22:05 --> Template Class Initialized
INFO - 2017-03-03 18:22:05 --> Model Class Initialized
INFO - 2017-03-03 18:22:05 --> Controller Class Initialized
DEBUG - 2017-03-03 18:22:05 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:22:05 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:22:05 --> Final output sent to browser
DEBUG - 2017-03-03 18:22:05 --> Total execution time: 0.0138
INFO - 2017-03-03 18:22:11 --> Config Class Initialized
INFO - 2017-03-03 18:22:11 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:22:11 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:22:11 --> Utf8 Class Initialized
INFO - 2017-03-03 18:22:11 --> URI Class Initialized
INFO - 2017-03-03 18:22:11 --> Router Class Initialized
INFO - 2017-03-03 18:22:11 --> Output Class Initialized
INFO - 2017-03-03 18:22:11 --> Security Class Initialized
DEBUG - 2017-03-03 18:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:22:11 --> Input Class Initialized
INFO - 2017-03-03 18:22:11 --> Language Class Initialized
INFO - 2017-03-03 18:22:11 --> Language Class Initialized
INFO - 2017-03-03 18:22:11 --> Config Class Initialized
INFO - 2017-03-03 18:22:11 --> Loader Class Initialized
INFO - 2017-03-03 18:22:11 --> Helper loaded: form_helper
INFO - 2017-03-03 18:22:11 --> Helper loaded: url_helper
INFO - 2017-03-03 18:22:11 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:22:11 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:22:11 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:22:11 --> Template Class Initialized
INFO - 2017-03-03 18:22:11 --> Model Class Initialized
INFO - 2017-03-03 18:22:11 --> Controller Class Initialized
DEBUG - 2017-03-03 18:22:11 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:22:11 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:22:11 --> Upload Class Initialized
INFO - 2017-03-03 18:22:11 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-03-03 18:22:11 --> The upload path does not appear to be valid.
INFO - 2017-03-03 18:22:11 --> Model Class Initialized
INFO - 2017-03-03 18:22:11 --> Final output sent to browser
DEBUG - 2017-03-03 18:22:11 --> Total execution time: 0.0165
INFO - 2017-03-03 18:22:16 --> Config Class Initialized
INFO - 2017-03-03 18:22:16 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:22:16 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:22:16 --> Utf8 Class Initialized
INFO - 2017-03-03 18:22:16 --> URI Class Initialized
INFO - 2017-03-03 18:22:16 --> Router Class Initialized
INFO - 2017-03-03 18:22:16 --> Output Class Initialized
INFO - 2017-03-03 18:22:16 --> Security Class Initialized
DEBUG - 2017-03-03 18:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:22:16 --> Input Class Initialized
INFO - 2017-03-03 18:22:16 --> Language Class Initialized
INFO - 2017-03-03 18:22:16 --> Language Class Initialized
INFO - 2017-03-03 18:22:16 --> Config Class Initialized
INFO - 2017-03-03 18:22:16 --> Loader Class Initialized
INFO - 2017-03-03 18:22:16 --> Helper loaded: form_helper
INFO - 2017-03-03 18:22:16 --> Helper loaded: url_helper
INFO - 2017-03-03 18:22:16 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:22:16 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:22:16 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:22:16 --> Template Class Initialized
INFO - 2017-03-03 18:22:16 --> Model Class Initialized
INFO - 2017-03-03 18:22:16 --> Controller Class Initialized
DEBUG - 2017-03-03 18:22:16 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:22:16 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:22:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:22:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:22:19 --> Config Class Initialized
INFO - 2017-03-03 18:22:19 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:22:19 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:22:19 --> Utf8 Class Initialized
INFO - 2017-03-03 18:22:19 --> URI Class Initialized
INFO - 2017-03-03 18:22:19 --> Router Class Initialized
INFO - 2017-03-03 18:22:19 --> Output Class Initialized
INFO - 2017-03-03 18:22:19 --> Security Class Initialized
DEBUG - 2017-03-03 18:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:22:19 --> Input Class Initialized
INFO - 2017-03-03 18:22:19 --> Language Class Initialized
INFO - 2017-03-03 18:22:19 --> Language Class Initialized
INFO - 2017-03-03 18:22:19 --> Config Class Initialized
INFO - 2017-03-03 18:22:19 --> Loader Class Initialized
INFO - 2017-03-03 18:22:19 --> Helper loaded: form_helper
INFO - 2017-03-03 18:22:19 --> Helper loaded: url_helper
INFO - 2017-03-03 18:22:19 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:22:19 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:22:19 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:22:19 --> Template Class Initialized
INFO - 2017-03-03 18:22:19 --> Model Class Initialized
INFO - 2017-03-03 18:22:19 --> Controller Class Initialized
DEBUG - 2017-03-03 18:22:19 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:22:19 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:22:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:22:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:34:51 --> Config Class Initialized
INFO - 2017-03-03 18:34:51 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:34:51 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:34:51 --> Utf8 Class Initialized
INFO - 2017-03-03 18:34:51 --> URI Class Initialized
DEBUG - 2017-03-03 18:34:51 --> No URI present. Default controller set.
INFO - 2017-03-03 18:34:51 --> Router Class Initialized
INFO - 2017-03-03 18:34:51 --> Output Class Initialized
INFO - 2017-03-03 18:34:51 --> Security Class Initialized
DEBUG - 2017-03-03 18:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:34:51 --> Input Class Initialized
INFO - 2017-03-03 18:34:51 --> Language Class Initialized
INFO - 2017-03-03 18:34:51 --> Language Class Initialized
INFO - 2017-03-03 18:34:51 --> Config Class Initialized
INFO - 2017-03-03 18:34:51 --> Loader Class Initialized
INFO - 2017-03-03 18:34:51 --> Helper loaded: form_helper
INFO - 2017-03-03 18:34:51 --> Helper loaded: url_helper
INFO - 2017-03-03 18:34:51 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:34:51 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:34:51 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:34:51 --> Template Class Initialized
INFO - 2017-03-03 18:34:51 --> Model Class Initialized
INFO - 2017-03-03 18:34:51 --> Controller Class Initialized
DEBUG - 2017-03-03 18:34:51 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:34:51 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:34:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:34:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 18:34:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-03 18:34:51 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 18:34:51 --> Final output sent to browser
DEBUG - 2017-03-03 18:34:51 --> Total execution time: 0.0355
INFO - 2017-03-03 18:34:51 --> Config Class Initialized
INFO - 2017-03-03 18:34:51 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:34:51 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:34:51 --> Utf8 Class Initialized
INFO - 2017-03-03 18:34:51 --> URI Class Initialized
INFO - 2017-03-03 18:34:51 --> Router Class Initialized
INFO - 2017-03-03 18:34:51 --> Output Class Initialized
INFO - 2017-03-03 18:34:51 --> Security Class Initialized
DEBUG - 2017-03-03 18:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:34:51 --> Input Class Initialized
INFO - 2017-03-03 18:34:51 --> Language Class Initialized
INFO - 2017-03-03 18:34:51 --> Language Class Initialized
INFO - 2017-03-03 18:34:51 --> Config Class Initialized
INFO - 2017-03-03 18:34:51 --> Loader Class Initialized
INFO - 2017-03-03 18:34:51 --> Helper loaded: form_helper
INFO - 2017-03-03 18:34:51 --> Helper loaded: url_helper
INFO - 2017-03-03 18:34:51 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:34:51 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:34:51 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:34:51 --> Template Class Initialized
INFO - 2017-03-03 18:34:51 --> Model Class Initialized
INFO - 2017-03-03 18:34:51 --> Controller Class Initialized
DEBUG - 2017-03-03 18:34:51 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:34:51 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:34:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:34:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:34:51 --> Config Class Initialized
INFO - 2017-03-03 18:34:51 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:34:51 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:34:51 --> Utf8 Class Initialized
INFO - 2017-03-03 18:34:51 --> URI Class Initialized
INFO - 2017-03-03 18:34:51 --> Router Class Initialized
INFO - 2017-03-03 18:34:51 --> Output Class Initialized
INFO - 2017-03-03 18:34:51 --> Security Class Initialized
DEBUG - 2017-03-03 18:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:34:51 --> Input Class Initialized
INFO - 2017-03-03 18:34:51 --> Language Class Initialized
INFO - 2017-03-03 18:34:51 --> Language Class Initialized
INFO - 2017-03-03 18:34:51 --> Config Class Initialized
INFO - 2017-03-03 18:34:51 --> Loader Class Initialized
INFO - 2017-03-03 18:34:51 --> Helper loaded: form_helper
INFO - 2017-03-03 18:34:51 --> Helper loaded: url_helper
INFO - 2017-03-03 18:34:51 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:34:51 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:34:51 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:34:51 --> Template Class Initialized
INFO - 2017-03-03 18:34:51 --> Model Class Initialized
INFO - 2017-03-03 18:34:51 --> Controller Class Initialized
DEBUG - 2017-03-03 18:34:51 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:34:51 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:34:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:34:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:34:53 --> Config Class Initialized
INFO - 2017-03-03 18:34:53 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:34:53 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:34:53 --> Utf8 Class Initialized
INFO - 2017-03-03 18:34:53 --> URI Class Initialized
INFO - 2017-03-03 18:34:53 --> Router Class Initialized
INFO - 2017-03-03 18:34:53 --> Output Class Initialized
INFO - 2017-03-03 18:34:53 --> Security Class Initialized
DEBUG - 2017-03-03 18:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:34:53 --> Input Class Initialized
INFO - 2017-03-03 18:34:53 --> Language Class Initialized
INFO - 2017-03-03 18:34:53 --> Language Class Initialized
INFO - 2017-03-03 18:34:53 --> Config Class Initialized
INFO - 2017-03-03 18:34:53 --> Loader Class Initialized
INFO - 2017-03-03 18:34:53 --> Helper loaded: form_helper
INFO - 2017-03-03 18:34:53 --> Helper loaded: url_helper
INFO - 2017-03-03 18:34:53 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:34:53 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:34:53 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:34:53 --> Template Class Initialized
INFO - 2017-03-03 18:34:53 --> Model Class Initialized
INFO - 2017-03-03 18:34:53 --> Controller Class Initialized
DEBUG - 2017-03-03 18:34:53 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:34:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:34:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:34:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 18:34:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-03 18:34:53 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 18:34:53 --> Final output sent to browser
DEBUG - 2017-03-03 18:34:53 --> Total execution time: 0.0130
INFO - 2017-03-03 18:34:54 --> Config Class Initialized
INFO - 2017-03-03 18:34:54 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:34:54 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:34:54 --> Utf8 Class Initialized
INFO - 2017-03-03 18:34:54 --> URI Class Initialized
INFO - 2017-03-03 18:34:54 --> Router Class Initialized
INFO - 2017-03-03 18:34:54 --> Output Class Initialized
INFO - 2017-03-03 18:34:54 --> Security Class Initialized
DEBUG - 2017-03-03 18:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:34:54 --> Input Class Initialized
INFO - 2017-03-03 18:34:54 --> Language Class Initialized
INFO - 2017-03-03 18:34:54 --> Language Class Initialized
INFO - 2017-03-03 18:34:54 --> Config Class Initialized
INFO - 2017-03-03 18:34:54 --> Loader Class Initialized
INFO - 2017-03-03 18:34:54 --> Helper loaded: form_helper
INFO - 2017-03-03 18:34:54 --> Helper loaded: url_helper
INFO - 2017-03-03 18:34:54 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:34:54 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:34:54 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:34:54 --> Template Class Initialized
INFO - 2017-03-03 18:34:54 --> Model Class Initialized
INFO - 2017-03-03 18:34:54 --> Controller Class Initialized
DEBUG - 2017-03-03 18:34:54 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:34:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:34:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:34:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:34:54 --> Config Class Initialized
INFO - 2017-03-03 18:34:54 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:34:54 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:34:54 --> Utf8 Class Initialized
INFO - 2017-03-03 18:34:54 --> URI Class Initialized
INFO - 2017-03-03 18:34:54 --> Router Class Initialized
INFO - 2017-03-03 18:34:54 --> Output Class Initialized
INFO - 2017-03-03 18:34:54 --> Security Class Initialized
DEBUG - 2017-03-03 18:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:34:54 --> Input Class Initialized
INFO - 2017-03-03 18:34:54 --> Language Class Initialized
INFO - 2017-03-03 18:34:54 --> Language Class Initialized
INFO - 2017-03-03 18:34:54 --> Config Class Initialized
INFO - 2017-03-03 18:34:54 --> Loader Class Initialized
INFO - 2017-03-03 18:34:54 --> Helper loaded: form_helper
INFO - 2017-03-03 18:34:54 --> Helper loaded: url_helper
INFO - 2017-03-03 18:34:54 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:34:54 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:34:54 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:34:54 --> Template Class Initialized
INFO - 2017-03-03 18:34:54 --> Model Class Initialized
INFO - 2017-03-03 18:34:54 --> Controller Class Initialized
DEBUG - 2017-03-03 18:34:54 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:34:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:34:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:34:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:34:54 --> Config Class Initialized
INFO - 2017-03-03 18:34:54 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:34:54 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:34:54 --> Utf8 Class Initialized
INFO - 2017-03-03 18:34:54 --> URI Class Initialized
INFO - 2017-03-03 18:34:54 --> Router Class Initialized
INFO - 2017-03-03 18:34:54 --> Output Class Initialized
INFO - 2017-03-03 18:34:54 --> Security Class Initialized
DEBUG - 2017-03-03 18:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:34:54 --> Input Class Initialized
INFO - 2017-03-03 18:34:54 --> Language Class Initialized
INFO - 2017-03-03 18:34:54 --> Language Class Initialized
INFO - 2017-03-03 18:34:54 --> Config Class Initialized
INFO - 2017-03-03 18:34:54 --> Loader Class Initialized
INFO - 2017-03-03 18:34:54 --> Helper loaded: form_helper
INFO - 2017-03-03 18:34:54 --> Helper loaded: url_helper
INFO - 2017-03-03 18:34:54 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:34:54 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:34:54 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:34:54 --> Template Class Initialized
INFO - 2017-03-03 18:34:54 --> Model Class Initialized
INFO - 2017-03-03 18:34:54 --> Controller Class Initialized
DEBUG - 2017-03-03 18:34:54 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:34:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:34:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:34:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:35:17 --> Config Class Initialized
INFO - 2017-03-03 18:35:17 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:35:17 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:35:17 --> Utf8 Class Initialized
INFO - 2017-03-03 18:35:17 --> URI Class Initialized
INFO - 2017-03-03 18:35:17 --> Router Class Initialized
INFO - 2017-03-03 18:35:17 --> Output Class Initialized
INFO - 2017-03-03 18:35:17 --> Security Class Initialized
DEBUG - 2017-03-03 18:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:35:17 --> Input Class Initialized
INFO - 2017-03-03 18:35:17 --> Language Class Initialized
INFO - 2017-03-03 18:35:17 --> Language Class Initialized
INFO - 2017-03-03 18:35:17 --> Config Class Initialized
INFO - 2017-03-03 18:35:17 --> Loader Class Initialized
INFO - 2017-03-03 18:35:17 --> Helper loaded: form_helper
INFO - 2017-03-03 18:35:17 --> Helper loaded: url_helper
INFO - 2017-03-03 18:35:17 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:35:17 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:35:17 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:35:17 --> Template Class Initialized
INFO - 2017-03-03 18:35:17 --> Model Class Initialized
INFO - 2017-03-03 18:35:17 --> Controller Class Initialized
DEBUG - 2017-03-03 18:35:17 --> Login MX_Controller Initialized
INFO - 2017-03-03 18:35:17 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:35:17 --> Form Validation Class Initialized
INFO - 2017-03-03 18:35:17 --> Config Class Initialized
INFO - 2017-03-03 18:35:17 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:35:17 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:35:17 --> Utf8 Class Initialized
INFO - 2017-03-03 18:35:17 --> URI Class Initialized
DEBUG - 2017-03-03 18:35:17 --> No URI present. Default controller set.
INFO - 2017-03-03 18:35:17 --> Router Class Initialized
INFO - 2017-03-03 18:35:17 --> Output Class Initialized
INFO - 2017-03-03 18:35:17 --> Security Class Initialized
DEBUG - 2017-03-03 18:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:35:17 --> Input Class Initialized
INFO - 2017-03-03 18:35:17 --> Language Class Initialized
INFO - 2017-03-03 18:35:17 --> Language Class Initialized
INFO - 2017-03-03 18:35:17 --> Config Class Initialized
INFO - 2017-03-03 18:35:17 --> Loader Class Initialized
INFO - 2017-03-03 18:35:17 --> Helper loaded: form_helper
INFO - 2017-03-03 18:35:17 --> Helper loaded: url_helper
INFO - 2017-03-03 18:35:17 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:35:17 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:35:17 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:35:17 --> Template Class Initialized
INFO - 2017-03-03 18:35:17 --> Model Class Initialized
INFO - 2017-03-03 18:35:17 --> Controller Class Initialized
DEBUG - 2017-03-03 18:35:17 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:35:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:35:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:35:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 18:35:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-03 18:35:17 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 18:35:17 --> Final output sent to browser
DEBUG - 2017-03-03 18:35:17 --> Total execution time: 0.0144
INFO - 2017-03-03 18:35:18 --> Config Class Initialized
INFO - 2017-03-03 18:35:18 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:35:18 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:35:18 --> Utf8 Class Initialized
INFO - 2017-03-03 18:35:18 --> URI Class Initialized
INFO - 2017-03-03 18:35:18 --> Router Class Initialized
INFO - 2017-03-03 18:35:18 --> Output Class Initialized
INFO - 2017-03-03 18:35:18 --> Security Class Initialized
DEBUG - 2017-03-03 18:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:35:18 --> Input Class Initialized
INFO - 2017-03-03 18:35:18 --> Language Class Initialized
INFO - 2017-03-03 18:35:18 --> Language Class Initialized
INFO - 2017-03-03 18:35:18 --> Config Class Initialized
INFO - 2017-03-03 18:35:18 --> Loader Class Initialized
INFO - 2017-03-03 18:35:18 --> Helper loaded: form_helper
INFO - 2017-03-03 18:35:18 --> Helper loaded: url_helper
INFO - 2017-03-03 18:35:18 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:35:18 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:35:18 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:35:18 --> Template Class Initialized
INFO - 2017-03-03 18:35:18 --> Model Class Initialized
INFO - 2017-03-03 18:35:18 --> Controller Class Initialized
DEBUG - 2017-03-03 18:35:18 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:35:18 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:35:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:35:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:35:18 --> Config Class Initialized
INFO - 2017-03-03 18:35:18 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:35:18 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:35:18 --> Utf8 Class Initialized
INFO - 2017-03-03 18:35:18 --> URI Class Initialized
INFO - 2017-03-03 18:35:18 --> Router Class Initialized
INFO - 2017-03-03 18:35:18 --> Output Class Initialized
INFO - 2017-03-03 18:35:18 --> Security Class Initialized
DEBUG - 2017-03-03 18:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:35:18 --> Input Class Initialized
INFO - 2017-03-03 18:35:18 --> Language Class Initialized
INFO - 2017-03-03 18:35:18 --> Language Class Initialized
INFO - 2017-03-03 18:35:18 --> Config Class Initialized
INFO - 2017-03-03 18:35:18 --> Loader Class Initialized
INFO - 2017-03-03 18:35:18 --> Helper loaded: form_helper
INFO - 2017-03-03 18:35:18 --> Helper loaded: url_helper
INFO - 2017-03-03 18:35:18 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:35:18 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:35:18 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:35:18 --> Template Class Initialized
INFO - 2017-03-03 18:35:18 --> Model Class Initialized
INFO - 2017-03-03 18:35:18 --> Controller Class Initialized
DEBUG - 2017-03-03 18:35:18 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:35:18 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:35:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:35:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:35:18 --> Config Class Initialized
INFO - 2017-03-03 18:35:18 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:35:18 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:35:18 --> Utf8 Class Initialized
INFO - 2017-03-03 18:35:18 --> URI Class Initialized
INFO - 2017-03-03 18:35:18 --> Router Class Initialized
INFO - 2017-03-03 18:35:18 --> Output Class Initialized
INFO - 2017-03-03 18:35:18 --> Security Class Initialized
DEBUG - 2017-03-03 18:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:35:18 --> Input Class Initialized
INFO - 2017-03-03 18:35:18 --> Language Class Initialized
INFO - 2017-03-03 18:35:18 --> Language Class Initialized
INFO - 2017-03-03 18:35:18 --> Config Class Initialized
INFO - 2017-03-03 18:35:18 --> Loader Class Initialized
INFO - 2017-03-03 18:35:18 --> Helper loaded: form_helper
INFO - 2017-03-03 18:35:18 --> Helper loaded: url_helper
INFO - 2017-03-03 18:35:18 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:35:18 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:35:18 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:35:18 --> Template Class Initialized
INFO - 2017-03-03 18:35:18 --> Model Class Initialized
INFO - 2017-03-03 18:35:18 --> Controller Class Initialized
DEBUG - 2017-03-03 18:35:18 --> Login MX_Controller Initialized
INFO - 2017-03-03 18:35:18 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:35:18 --> Form Validation Class Initialized
INFO - 2017-03-03 18:35:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-03 18:35:18 --> Config Class Initialized
INFO - 2017-03-03 18:35:18 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:35:18 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:35:18 --> Utf8 Class Initialized
INFO - 2017-03-03 18:35:18 --> URI Class Initialized
INFO - 2017-03-03 18:35:18 --> Router Class Initialized
INFO - 2017-03-03 18:35:18 --> Output Class Initialized
INFO - 2017-03-03 18:35:18 --> Security Class Initialized
DEBUG - 2017-03-03 18:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:35:18 --> Input Class Initialized
INFO - 2017-03-03 18:35:18 --> Language Class Initialized
INFO - 2017-03-03 18:35:18 --> Language Class Initialized
INFO - 2017-03-03 18:35:18 --> Config Class Initialized
INFO - 2017-03-03 18:35:18 --> Loader Class Initialized
INFO - 2017-03-03 18:35:18 --> Helper loaded: form_helper
INFO - 2017-03-03 18:35:18 --> Helper loaded: url_helper
INFO - 2017-03-03 18:35:18 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:35:18 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:35:18 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:35:18 --> Template Class Initialized
INFO - 2017-03-03 18:35:18 --> Model Class Initialized
INFO - 2017-03-03 18:35:18 --> Controller Class Initialized
DEBUG - 2017-03-03 18:35:18 --> Dashboard MX_Controller Initialized
INFO - 2017-03-03 18:35:18 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:35:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:35:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:35:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:35:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-03 18:35:18 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:35:18 --> Final output sent to browser
DEBUG - 2017-03-03 18:35:18 --> Total execution time: 0.0165
INFO - 2017-03-03 18:35:19 --> Config Class Initialized
INFO - 2017-03-03 18:35:19 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:35:19 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:35:19 --> Utf8 Class Initialized
INFO - 2017-03-03 18:35:19 --> URI Class Initialized
INFO - 2017-03-03 18:35:19 --> Router Class Initialized
INFO - 2017-03-03 18:35:19 --> Output Class Initialized
INFO - 2017-03-03 18:35:19 --> Security Class Initialized
DEBUG - 2017-03-03 18:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:35:19 --> Input Class Initialized
INFO - 2017-03-03 18:35:19 --> Language Class Initialized
INFO - 2017-03-03 18:35:19 --> Language Class Initialized
INFO - 2017-03-03 18:35:19 --> Config Class Initialized
INFO - 2017-03-03 18:35:19 --> Loader Class Initialized
INFO - 2017-03-03 18:35:19 --> Helper loaded: form_helper
INFO - 2017-03-03 18:35:19 --> Helper loaded: url_helper
INFO - 2017-03-03 18:35:19 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:35:19 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:35:19 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:35:19 --> Template Class Initialized
INFO - 2017-03-03 18:35:19 --> Model Class Initialized
INFO - 2017-03-03 18:35:19 --> Controller Class Initialized
DEBUG - 2017-03-03 18:35:19 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:35:19 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:35:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:35:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:35:26 --> Config Class Initialized
INFO - 2017-03-03 18:35:26 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:35:26 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:35:26 --> Utf8 Class Initialized
INFO - 2017-03-03 18:35:26 --> URI Class Initialized
INFO - 2017-03-03 18:35:26 --> Router Class Initialized
INFO - 2017-03-03 18:35:26 --> Output Class Initialized
INFO - 2017-03-03 18:35:26 --> Security Class Initialized
DEBUG - 2017-03-03 18:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:35:26 --> Input Class Initialized
INFO - 2017-03-03 18:35:26 --> Language Class Initialized
INFO - 2017-03-03 18:35:26 --> Language Class Initialized
INFO - 2017-03-03 18:35:26 --> Config Class Initialized
INFO - 2017-03-03 18:35:26 --> Loader Class Initialized
INFO - 2017-03-03 18:35:26 --> Helper loaded: form_helper
INFO - 2017-03-03 18:35:26 --> Helper loaded: url_helper
INFO - 2017-03-03 18:35:26 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:35:26 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:35:26 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:35:26 --> Template Class Initialized
INFO - 2017-03-03 18:35:26 --> Model Class Initialized
INFO - 2017-03-03 18:35:26 --> Controller Class Initialized
DEBUG - 2017-03-03 18:35:26 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:35:26 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:35:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:35:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 18:35:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-03 18:35:26 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 18:35:26 --> Final output sent to browser
DEBUG - 2017-03-03 18:35:26 --> Total execution time: 0.0164
INFO - 2017-03-03 18:35:26 --> Config Class Initialized
INFO - 2017-03-03 18:35:26 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:35:26 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:35:26 --> Utf8 Class Initialized
INFO - 2017-03-03 18:35:26 --> URI Class Initialized
INFO - 2017-03-03 18:35:26 --> Router Class Initialized
INFO - 2017-03-03 18:35:26 --> Output Class Initialized
INFO - 2017-03-03 18:35:26 --> Security Class Initialized
DEBUG - 2017-03-03 18:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:35:26 --> Input Class Initialized
INFO - 2017-03-03 18:35:26 --> Language Class Initialized
INFO - 2017-03-03 18:35:26 --> Language Class Initialized
INFO - 2017-03-03 18:35:26 --> Config Class Initialized
INFO - 2017-03-03 18:35:26 --> Loader Class Initialized
INFO - 2017-03-03 18:35:26 --> Helper loaded: form_helper
INFO - 2017-03-03 18:35:26 --> Helper loaded: url_helper
INFO - 2017-03-03 18:35:26 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:35:26 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:35:26 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:35:26 --> Template Class Initialized
INFO - 2017-03-03 18:35:26 --> Model Class Initialized
INFO - 2017-03-03 18:35:26 --> Controller Class Initialized
DEBUG - 2017-03-03 18:35:26 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:35:26 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:35:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:35:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:35:36 --> Config Class Initialized
INFO - 2017-03-03 18:35:36 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:35:36 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:35:36 --> Utf8 Class Initialized
INFO - 2017-03-03 18:35:36 --> URI Class Initialized
INFO - 2017-03-03 18:35:36 --> Router Class Initialized
INFO - 2017-03-03 18:35:36 --> Output Class Initialized
INFO - 2017-03-03 18:35:36 --> Security Class Initialized
DEBUG - 2017-03-03 18:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:35:36 --> Input Class Initialized
INFO - 2017-03-03 18:35:36 --> Language Class Initialized
INFO - 2017-03-03 18:35:36 --> Language Class Initialized
INFO - 2017-03-03 18:35:36 --> Config Class Initialized
INFO - 2017-03-03 18:35:36 --> Loader Class Initialized
INFO - 2017-03-03 18:35:36 --> Helper loaded: form_helper
INFO - 2017-03-03 18:35:36 --> Helper loaded: url_helper
INFO - 2017-03-03 18:35:36 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:35:36 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:35:36 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:35:36 --> Template Class Initialized
INFO - 2017-03-03 18:35:36 --> Model Class Initialized
INFO - 2017-03-03 18:35:36 --> Controller Class Initialized
DEBUG - 2017-03-03 18:35:36 --> Login MX_Controller Initialized
INFO - 2017-03-03 18:35:36 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:35:36 --> Form Validation Class Initialized
INFO - 2017-03-03 18:35:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-03 18:35:36 --> Config Class Initialized
INFO - 2017-03-03 18:35:36 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:35:36 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:35:36 --> Utf8 Class Initialized
INFO - 2017-03-03 18:35:36 --> URI Class Initialized
INFO - 2017-03-03 18:35:36 --> Router Class Initialized
INFO - 2017-03-03 18:35:36 --> Output Class Initialized
INFO - 2017-03-03 18:35:36 --> Security Class Initialized
DEBUG - 2017-03-03 18:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:35:36 --> Input Class Initialized
INFO - 2017-03-03 18:35:36 --> Language Class Initialized
INFO - 2017-03-03 18:35:36 --> Language Class Initialized
INFO - 2017-03-03 18:35:36 --> Config Class Initialized
INFO - 2017-03-03 18:35:36 --> Loader Class Initialized
INFO - 2017-03-03 18:35:36 --> Helper loaded: form_helper
INFO - 2017-03-03 18:35:36 --> Helper loaded: url_helper
INFO - 2017-03-03 18:35:36 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:35:36 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:35:36 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:35:36 --> Template Class Initialized
INFO - 2017-03-03 18:35:36 --> Model Class Initialized
INFO - 2017-03-03 18:35:36 --> Controller Class Initialized
DEBUG - 2017-03-03 18:35:36 --> Dashboard MX_Controller Initialized
INFO - 2017-03-03 18:35:36 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:35:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:35:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:35:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:35:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-03 18:35:36 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:35:36 --> Final output sent to browser
DEBUG - 2017-03-03 18:35:36 --> Total execution time: 0.0152
INFO - 2017-03-03 18:36:17 --> Config Class Initialized
INFO - 2017-03-03 18:36:17 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:36:17 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:36:17 --> Utf8 Class Initialized
INFO - 2017-03-03 18:36:17 --> URI Class Initialized
INFO - 2017-03-03 18:36:17 --> Router Class Initialized
INFO - 2017-03-03 18:36:17 --> Output Class Initialized
INFO - 2017-03-03 18:36:17 --> Security Class Initialized
DEBUG - 2017-03-03 18:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:36:17 --> Input Class Initialized
INFO - 2017-03-03 18:36:17 --> Language Class Initialized
INFO - 2017-03-03 18:36:17 --> Language Class Initialized
INFO - 2017-03-03 18:36:17 --> Config Class Initialized
INFO - 2017-03-03 18:36:17 --> Loader Class Initialized
INFO - 2017-03-03 18:36:17 --> Helper loaded: form_helper
INFO - 2017-03-03 18:36:17 --> Helper loaded: url_helper
INFO - 2017-03-03 18:36:17 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:36:17 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:36:17 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:36:17 --> Template Class Initialized
INFO - 2017-03-03 18:36:17 --> Model Class Initialized
INFO - 2017-03-03 18:36:17 --> Controller Class Initialized
DEBUG - 2017-03-03 18:36:17 --> Dashboard MX_Controller Initialized
INFO - 2017-03-03 18:36:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:36:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:36:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:36:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:36:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-03 18:36:17 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:36:17 --> Final output sent to browser
DEBUG - 2017-03-03 18:36:17 --> Total execution time: 0.0162
INFO - 2017-03-03 18:36:32 --> Config Class Initialized
INFO - 2017-03-03 18:36:32 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:36:32 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:36:32 --> Utf8 Class Initialized
INFO - 2017-03-03 18:36:32 --> URI Class Initialized
INFO - 2017-03-03 18:36:32 --> Router Class Initialized
INFO - 2017-03-03 18:36:32 --> Output Class Initialized
INFO - 2017-03-03 18:36:32 --> Security Class Initialized
DEBUG - 2017-03-03 18:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:36:32 --> Input Class Initialized
INFO - 2017-03-03 18:36:32 --> Language Class Initialized
INFO - 2017-03-03 18:36:32 --> Language Class Initialized
INFO - 2017-03-03 18:36:32 --> Config Class Initialized
INFO - 2017-03-03 18:36:32 --> Loader Class Initialized
INFO - 2017-03-03 18:36:32 --> Helper loaded: form_helper
INFO - 2017-03-03 18:36:32 --> Helper loaded: url_helper
INFO - 2017-03-03 18:36:32 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:36:32 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:36:32 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:36:32 --> Template Class Initialized
INFO - 2017-03-03 18:36:32 --> Model Class Initialized
INFO - 2017-03-03 18:36:32 --> Controller Class Initialized
DEBUG - 2017-03-03 18:36:32 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:36:32 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:36:32 --> Model Class Initialized
DEBUG - 2017-03-03 18:36:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:36:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:36:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:36:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/project_list.php
DEBUG - 2017-03-03 18:36:32 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:36:32 --> Final output sent to browser
DEBUG - 2017-03-03 18:36:32 --> Total execution time: 0.0179
INFO - 2017-03-03 18:36:33 --> Config Class Initialized
INFO - 2017-03-03 18:36:33 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:36:33 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:36:33 --> Utf8 Class Initialized
INFO - 2017-03-03 18:36:33 --> URI Class Initialized
INFO - 2017-03-03 18:36:33 --> Router Class Initialized
INFO - 2017-03-03 18:36:33 --> Output Class Initialized
INFO - 2017-03-03 18:36:33 --> Security Class Initialized
DEBUG - 2017-03-03 18:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:36:33 --> Input Class Initialized
INFO - 2017-03-03 18:36:33 --> Language Class Initialized
INFO - 2017-03-03 18:36:33 --> Language Class Initialized
INFO - 2017-03-03 18:36:33 --> Config Class Initialized
INFO - 2017-03-03 18:36:33 --> Loader Class Initialized
INFO - 2017-03-03 18:36:33 --> Helper loaded: form_helper
INFO - 2017-03-03 18:36:33 --> Helper loaded: url_helper
INFO - 2017-03-03 18:36:33 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:36:33 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:36:33 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:36:33 --> Template Class Initialized
INFO - 2017-03-03 18:36:33 --> Model Class Initialized
INFO - 2017-03-03 18:36:33 --> Controller Class Initialized
DEBUG - 2017-03-03 18:36:33 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:36:33 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:36:33 --> Model Class Initialized
DEBUG - 2017-03-03 18:36:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:36:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:36:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:36:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/project_list.php
DEBUG - 2017-03-03 18:36:33 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:36:33 --> Final output sent to browser
DEBUG - 2017-03-03 18:36:33 --> Total execution time: 0.0172
INFO - 2017-03-03 18:36:34 --> Config Class Initialized
INFO - 2017-03-03 18:36:34 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:36:34 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:36:34 --> Utf8 Class Initialized
INFO - 2017-03-03 18:36:34 --> URI Class Initialized
INFO - 2017-03-03 18:36:34 --> Router Class Initialized
INFO - 2017-03-03 18:36:34 --> Output Class Initialized
INFO - 2017-03-03 18:36:34 --> Security Class Initialized
DEBUG - 2017-03-03 18:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:36:34 --> Input Class Initialized
INFO - 2017-03-03 18:36:34 --> Language Class Initialized
INFO - 2017-03-03 18:36:34 --> Language Class Initialized
INFO - 2017-03-03 18:36:34 --> Config Class Initialized
INFO - 2017-03-03 18:36:34 --> Loader Class Initialized
INFO - 2017-03-03 18:36:34 --> Helper loaded: form_helper
INFO - 2017-03-03 18:36:34 --> Helper loaded: url_helper
INFO - 2017-03-03 18:36:34 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:36:34 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:36:34 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:36:34 --> Template Class Initialized
INFO - 2017-03-03 18:36:34 --> Model Class Initialized
INFO - 2017-03-03 18:36:34 --> Controller Class Initialized
DEBUG - 2017-03-03 18:36:34 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:36:34 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:36:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:36:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:36:44 --> Config Class Initialized
INFO - 2017-03-03 18:36:44 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:36:44 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:36:44 --> Utf8 Class Initialized
INFO - 2017-03-03 18:36:44 --> URI Class Initialized
INFO - 2017-03-03 18:36:44 --> Router Class Initialized
INFO - 2017-03-03 18:36:44 --> Output Class Initialized
INFO - 2017-03-03 18:36:44 --> Security Class Initialized
DEBUG - 2017-03-03 18:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:36:44 --> Input Class Initialized
INFO - 2017-03-03 18:36:44 --> Language Class Initialized
INFO - 2017-03-03 18:36:44 --> Language Class Initialized
INFO - 2017-03-03 18:36:44 --> Config Class Initialized
INFO - 2017-03-03 18:36:44 --> Loader Class Initialized
INFO - 2017-03-03 18:36:44 --> Helper loaded: form_helper
INFO - 2017-03-03 18:36:44 --> Helper loaded: url_helper
INFO - 2017-03-03 18:36:44 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:36:44 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:36:44 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:36:44 --> Template Class Initialized
INFO - 2017-03-03 18:36:44 --> Model Class Initialized
INFO - 2017-03-03 18:36:44 --> Controller Class Initialized
DEBUG - 2017-03-03 18:36:44 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:36:44 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:36:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:36:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:36:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:36:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 18:36:44 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:36:44 --> Final output sent to browser
DEBUG - 2017-03-03 18:36:44 --> Total execution time: 0.0201
INFO - 2017-03-03 18:36:45 --> Config Class Initialized
INFO - 2017-03-03 18:36:45 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:36:45 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:36:45 --> Utf8 Class Initialized
INFO - 2017-03-03 18:36:45 --> URI Class Initialized
INFO - 2017-03-03 18:36:45 --> Router Class Initialized
INFO - 2017-03-03 18:36:45 --> Output Class Initialized
INFO - 2017-03-03 18:36:45 --> Security Class Initialized
DEBUG - 2017-03-03 18:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:36:45 --> Input Class Initialized
INFO - 2017-03-03 18:36:45 --> Language Class Initialized
INFO - 2017-03-03 18:36:45 --> Language Class Initialized
INFO - 2017-03-03 18:36:45 --> Config Class Initialized
INFO - 2017-03-03 18:36:45 --> Loader Class Initialized
INFO - 2017-03-03 18:36:45 --> Helper loaded: form_helper
INFO - 2017-03-03 18:36:45 --> Helper loaded: url_helper
INFO - 2017-03-03 18:36:45 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:36:45 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:36:45 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:36:45 --> Template Class Initialized
INFO - 2017-03-03 18:36:45 --> Model Class Initialized
INFO - 2017-03-03 18:36:45 --> Controller Class Initialized
DEBUG - 2017-03-03 18:36:45 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:36:45 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:36:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:36:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:36:45 --> Config Class Initialized
INFO - 2017-03-03 18:36:45 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:36:45 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:36:45 --> Utf8 Class Initialized
INFO - 2017-03-03 18:36:45 --> URI Class Initialized
INFO - 2017-03-03 18:36:45 --> Router Class Initialized
INFO - 2017-03-03 18:36:45 --> Output Class Initialized
INFO - 2017-03-03 18:36:45 --> Security Class Initialized
DEBUG - 2017-03-03 18:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:36:45 --> Input Class Initialized
INFO - 2017-03-03 18:36:45 --> Language Class Initialized
INFO - 2017-03-03 18:36:45 --> Language Class Initialized
INFO - 2017-03-03 18:36:45 --> Config Class Initialized
INFO - 2017-03-03 18:36:45 --> Loader Class Initialized
INFO - 2017-03-03 18:36:45 --> Helper loaded: form_helper
INFO - 2017-03-03 18:36:45 --> Helper loaded: url_helper
INFO - 2017-03-03 18:36:45 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:36:45 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:36:45 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:36:45 --> Template Class Initialized
INFO - 2017-03-03 18:36:45 --> Model Class Initialized
INFO - 2017-03-03 18:36:45 --> Controller Class Initialized
DEBUG - 2017-03-03 18:36:45 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:36:45 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:36:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:36:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:36:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:36:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 18:36:45 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:36:45 --> Final output sent to browser
DEBUG - 2017-03-03 18:36:45 --> Total execution time: 0.0142
INFO - 2017-03-03 18:36:51 --> Config Class Initialized
INFO - 2017-03-03 18:36:51 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:36:51 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:36:51 --> Utf8 Class Initialized
INFO - 2017-03-03 18:36:51 --> URI Class Initialized
INFO - 2017-03-03 18:36:51 --> Router Class Initialized
INFO - 2017-03-03 18:36:51 --> Output Class Initialized
INFO - 2017-03-03 18:36:51 --> Security Class Initialized
DEBUG - 2017-03-03 18:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:36:51 --> Input Class Initialized
INFO - 2017-03-03 18:36:51 --> Language Class Initialized
INFO - 2017-03-03 18:36:51 --> Language Class Initialized
INFO - 2017-03-03 18:36:51 --> Config Class Initialized
INFO - 2017-03-03 18:36:51 --> Loader Class Initialized
INFO - 2017-03-03 18:36:51 --> Helper loaded: form_helper
INFO - 2017-03-03 18:36:51 --> Helper loaded: url_helper
INFO - 2017-03-03 18:36:51 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:36:51 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:36:51 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:36:51 --> Template Class Initialized
INFO - 2017-03-03 18:36:51 --> Model Class Initialized
INFO - 2017-03-03 18:36:51 --> Controller Class Initialized
DEBUG - 2017-03-03 18:36:51 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:36:51 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:36:51 --> Model Class Initialized
DEBUG - 2017-03-03 18:36:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:36:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:36:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:36:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 18:36:51 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:36:51 --> Final output sent to browser
DEBUG - 2017-03-03 18:36:51 --> Total execution time: 0.0156
INFO - 2017-03-03 18:36:55 --> Config Class Initialized
INFO - 2017-03-03 18:36:55 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:36:55 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:36:55 --> Utf8 Class Initialized
INFO - 2017-03-03 18:36:55 --> URI Class Initialized
INFO - 2017-03-03 18:36:55 --> Router Class Initialized
INFO - 2017-03-03 18:36:55 --> Output Class Initialized
INFO - 2017-03-03 18:36:55 --> Security Class Initialized
DEBUG - 2017-03-03 18:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:36:55 --> Input Class Initialized
INFO - 2017-03-03 18:36:55 --> Language Class Initialized
INFO - 2017-03-03 18:36:55 --> Language Class Initialized
INFO - 2017-03-03 18:36:55 --> Config Class Initialized
INFO - 2017-03-03 18:36:55 --> Loader Class Initialized
INFO - 2017-03-03 18:36:55 --> Helper loaded: form_helper
INFO - 2017-03-03 18:36:55 --> Helper loaded: url_helper
INFO - 2017-03-03 18:36:55 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:36:55 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:36:55 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:36:55 --> Template Class Initialized
INFO - 2017-03-03 18:36:55 --> Model Class Initialized
INFO - 2017-03-03 18:36:55 --> Controller Class Initialized
DEBUG - 2017-03-03 18:36:55 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:36:55 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:36:55 --> Model Class Initialized
DEBUG - 2017-03-03 18:36:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:36:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:36:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:36:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 18:36:55 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:36:55 --> Final output sent to browser
DEBUG - 2017-03-03 18:36:55 --> Total execution time: 0.0204
INFO - 2017-03-03 18:36:56 --> Config Class Initialized
INFO - 2017-03-03 18:36:56 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:36:56 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:36:56 --> Utf8 Class Initialized
INFO - 2017-03-03 18:36:56 --> URI Class Initialized
INFO - 2017-03-03 18:36:56 --> Router Class Initialized
INFO - 2017-03-03 18:36:56 --> Output Class Initialized
INFO - 2017-03-03 18:36:56 --> Security Class Initialized
DEBUG - 2017-03-03 18:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:36:56 --> Input Class Initialized
INFO - 2017-03-03 18:36:56 --> Language Class Initialized
INFO - 2017-03-03 18:36:56 --> Language Class Initialized
INFO - 2017-03-03 18:36:56 --> Config Class Initialized
INFO - 2017-03-03 18:36:56 --> Loader Class Initialized
INFO - 2017-03-03 18:36:56 --> Helper loaded: form_helper
INFO - 2017-03-03 18:36:56 --> Helper loaded: url_helper
INFO - 2017-03-03 18:36:56 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:36:56 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:36:56 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:36:56 --> Template Class Initialized
INFO - 2017-03-03 18:36:56 --> Model Class Initialized
INFO - 2017-03-03 18:36:56 --> Controller Class Initialized
DEBUG - 2017-03-03 18:36:56 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:36:56 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:36:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:36:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:37:01 --> Config Class Initialized
INFO - 2017-03-03 18:37:01 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:37:01 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:37:01 --> Utf8 Class Initialized
INFO - 2017-03-03 18:37:01 --> URI Class Initialized
INFO - 2017-03-03 18:37:01 --> Router Class Initialized
INFO - 2017-03-03 18:37:01 --> Output Class Initialized
INFO - 2017-03-03 18:37:01 --> Security Class Initialized
DEBUG - 2017-03-03 18:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:37:01 --> Input Class Initialized
INFO - 2017-03-03 18:37:01 --> Language Class Initialized
INFO - 2017-03-03 18:37:01 --> Language Class Initialized
INFO - 2017-03-03 18:37:01 --> Config Class Initialized
INFO - 2017-03-03 18:37:01 --> Loader Class Initialized
INFO - 2017-03-03 18:37:01 --> Helper loaded: form_helper
INFO - 2017-03-03 18:37:01 --> Helper loaded: url_helper
INFO - 2017-03-03 18:37:01 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:37:01 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:37:01 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:37:01 --> Template Class Initialized
INFO - 2017-03-03 18:37:01 --> Model Class Initialized
INFO - 2017-03-03 18:37:01 --> Controller Class Initialized
DEBUG - 2017-03-03 18:37:01 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:37:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:37:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:37:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:37:05 --> Config Class Initialized
INFO - 2017-03-03 18:37:05 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:37:05 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:37:05 --> Utf8 Class Initialized
INFO - 2017-03-03 18:37:05 --> URI Class Initialized
INFO - 2017-03-03 18:37:05 --> Router Class Initialized
INFO - 2017-03-03 18:37:05 --> Output Class Initialized
INFO - 2017-03-03 18:37:05 --> Security Class Initialized
DEBUG - 2017-03-03 18:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:37:05 --> Input Class Initialized
INFO - 2017-03-03 18:37:05 --> Language Class Initialized
INFO - 2017-03-03 18:37:05 --> Language Class Initialized
INFO - 2017-03-03 18:37:05 --> Config Class Initialized
INFO - 2017-03-03 18:37:05 --> Loader Class Initialized
INFO - 2017-03-03 18:37:05 --> Helper loaded: form_helper
INFO - 2017-03-03 18:37:05 --> Helper loaded: url_helper
INFO - 2017-03-03 18:37:05 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:37:05 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:37:05 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:37:05 --> Template Class Initialized
INFO - 2017-03-03 18:37:05 --> Model Class Initialized
INFO - 2017-03-03 18:37:05 --> Controller Class Initialized
DEBUG - 2017-03-03 18:37:05 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:37:05 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:37:05 --> Model Class Initialized
DEBUG - 2017-03-03 18:37:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:37:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:37:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:37:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 18:37:05 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:37:05 --> Final output sent to browser
DEBUG - 2017-03-03 18:37:05 --> Total execution time: 0.0168
INFO - 2017-03-03 18:37:11 --> Config Class Initialized
INFO - 2017-03-03 18:37:11 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:37:11 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:37:11 --> Utf8 Class Initialized
INFO - 2017-03-03 18:37:11 --> URI Class Initialized
INFO - 2017-03-03 18:37:11 --> Router Class Initialized
INFO - 2017-03-03 18:37:11 --> Output Class Initialized
INFO - 2017-03-03 18:37:11 --> Security Class Initialized
DEBUG - 2017-03-03 18:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:37:11 --> Input Class Initialized
INFO - 2017-03-03 18:37:11 --> Language Class Initialized
INFO - 2017-03-03 18:37:11 --> Language Class Initialized
INFO - 2017-03-03 18:37:11 --> Config Class Initialized
INFO - 2017-03-03 18:37:11 --> Loader Class Initialized
INFO - 2017-03-03 18:37:11 --> Helper loaded: form_helper
INFO - 2017-03-03 18:37:11 --> Helper loaded: url_helper
INFO - 2017-03-03 18:37:11 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:37:11 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:37:11 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:37:11 --> Template Class Initialized
INFO - 2017-03-03 18:37:11 --> Model Class Initialized
INFO - 2017-03-03 18:37:11 --> Controller Class Initialized
DEBUG - 2017-03-03 18:37:11 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:37:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:37:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:37:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:37:17 --> Config Class Initialized
INFO - 2017-03-03 18:37:17 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:37:17 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:37:17 --> Utf8 Class Initialized
INFO - 2017-03-03 18:37:17 --> URI Class Initialized
INFO - 2017-03-03 18:37:17 --> Router Class Initialized
INFO - 2017-03-03 18:37:17 --> Output Class Initialized
INFO - 2017-03-03 18:37:17 --> Security Class Initialized
DEBUG - 2017-03-03 18:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:37:17 --> Input Class Initialized
INFO - 2017-03-03 18:37:17 --> Language Class Initialized
INFO - 2017-03-03 18:37:17 --> Language Class Initialized
INFO - 2017-03-03 18:37:17 --> Config Class Initialized
INFO - 2017-03-03 18:37:17 --> Loader Class Initialized
INFO - 2017-03-03 18:37:17 --> Helper loaded: form_helper
INFO - 2017-03-03 18:37:17 --> Helper loaded: url_helper
INFO - 2017-03-03 18:37:17 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:37:17 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:37:17 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:37:17 --> Template Class Initialized
INFO - 2017-03-03 18:37:17 --> Model Class Initialized
INFO - 2017-03-03 18:37:17 --> Controller Class Initialized
DEBUG - 2017-03-03 18:37:17 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:37:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:37:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:37:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:37:18 --> Config Class Initialized
INFO - 2017-03-03 18:37:18 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:37:18 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:37:18 --> Utf8 Class Initialized
INFO - 2017-03-03 18:37:18 --> URI Class Initialized
INFO - 2017-03-03 18:37:18 --> Router Class Initialized
INFO - 2017-03-03 18:37:18 --> Output Class Initialized
INFO - 2017-03-03 18:37:18 --> Security Class Initialized
DEBUG - 2017-03-03 18:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:37:18 --> Input Class Initialized
INFO - 2017-03-03 18:37:18 --> Language Class Initialized
INFO - 2017-03-03 18:37:18 --> Language Class Initialized
INFO - 2017-03-03 18:37:18 --> Config Class Initialized
INFO - 2017-03-03 18:37:18 --> Loader Class Initialized
INFO - 2017-03-03 18:37:18 --> Helper loaded: form_helper
INFO - 2017-03-03 18:37:18 --> Helper loaded: url_helper
INFO - 2017-03-03 18:37:18 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:37:18 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:37:18 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:37:18 --> Template Class Initialized
INFO - 2017-03-03 18:37:18 --> Model Class Initialized
INFO - 2017-03-03 18:37:18 --> Controller Class Initialized
DEBUG - 2017-03-03 18:37:18 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:37:18 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:37:18 --> Model Class Initialized
DEBUG - 2017-03-03 18:37:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:37:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:37:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:37:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 18:37:18 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:37:18 --> Final output sent to browser
DEBUG - 2017-03-03 18:37:18 --> Total execution time: 0.0171
INFO - 2017-03-03 18:37:18 --> Config Class Initialized
INFO - 2017-03-03 18:37:18 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:37:18 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:37:18 --> Utf8 Class Initialized
INFO - 2017-03-03 18:37:18 --> URI Class Initialized
INFO - 2017-03-03 18:37:18 --> Router Class Initialized
INFO - 2017-03-03 18:37:18 --> Output Class Initialized
INFO - 2017-03-03 18:37:18 --> Security Class Initialized
DEBUG - 2017-03-03 18:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:37:18 --> Input Class Initialized
INFO - 2017-03-03 18:37:18 --> Language Class Initialized
INFO - 2017-03-03 18:37:18 --> Language Class Initialized
INFO - 2017-03-03 18:37:18 --> Config Class Initialized
INFO - 2017-03-03 18:37:18 --> Loader Class Initialized
INFO - 2017-03-03 18:37:18 --> Helper loaded: form_helper
INFO - 2017-03-03 18:37:18 --> Helper loaded: url_helper
INFO - 2017-03-03 18:37:18 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:37:18 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:37:18 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:37:18 --> Template Class Initialized
INFO - 2017-03-03 18:37:18 --> Model Class Initialized
INFO - 2017-03-03 18:37:18 --> Controller Class Initialized
DEBUG - 2017-03-03 18:37:18 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:37:18 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:37:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:37:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:37:26 --> Config Class Initialized
INFO - 2017-03-03 18:37:26 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:37:26 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:37:26 --> Utf8 Class Initialized
INFO - 2017-03-03 18:37:26 --> URI Class Initialized
INFO - 2017-03-03 18:37:26 --> Router Class Initialized
INFO - 2017-03-03 18:37:26 --> Output Class Initialized
INFO - 2017-03-03 18:37:26 --> Security Class Initialized
DEBUG - 2017-03-03 18:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:37:26 --> Input Class Initialized
INFO - 2017-03-03 18:37:26 --> Language Class Initialized
INFO - 2017-03-03 18:37:26 --> Language Class Initialized
INFO - 2017-03-03 18:37:26 --> Config Class Initialized
INFO - 2017-03-03 18:37:26 --> Loader Class Initialized
INFO - 2017-03-03 18:37:26 --> Helper loaded: form_helper
INFO - 2017-03-03 18:37:26 --> Helper loaded: url_helper
INFO - 2017-03-03 18:37:26 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:37:26 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:37:26 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:37:26 --> Template Class Initialized
INFO - 2017-03-03 18:37:26 --> Model Class Initialized
INFO - 2017-03-03 18:37:26 --> Controller Class Initialized
DEBUG - 2017-03-03 18:37:26 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:37:26 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:37:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:37:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:37:27 --> Config Class Initialized
INFO - 2017-03-03 18:37:27 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:37:27 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:37:27 --> Utf8 Class Initialized
INFO - 2017-03-03 18:37:27 --> URI Class Initialized
INFO - 2017-03-03 18:37:27 --> Router Class Initialized
INFO - 2017-03-03 18:37:27 --> Output Class Initialized
INFO - 2017-03-03 18:37:27 --> Security Class Initialized
DEBUG - 2017-03-03 18:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:37:27 --> Input Class Initialized
INFO - 2017-03-03 18:37:27 --> Language Class Initialized
INFO - 2017-03-03 18:37:27 --> Language Class Initialized
INFO - 2017-03-03 18:37:27 --> Config Class Initialized
INFO - 2017-03-03 18:37:27 --> Loader Class Initialized
INFO - 2017-03-03 18:37:27 --> Helper loaded: form_helper
INFO - 2017-03-03 18:37:27 --> Helper loaded: url_helper
INFO - 2017-03-03 18:37:27 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:37:27 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:37:27 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:37:27 --> Template Class Initialized
INFO - 2017-03-03 18:37:27 --> Model Class Initialized
INFO - 2017-03-03 18:37:27 --> Controller Class Initialized
DEBUG - 2017-03-03 18:37:27 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:37:27 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:37:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:37:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:37:29 --> Config Class Initialized
INFO - 2017-03-03 18:37:29 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:37:29 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:37:29 --> Utf8 Class Initialized
INFO - 2017-03-03 18:37:29 --> URI Class Initialized
INFO - 2017-03-03 18:37:29 --> Router Class Initialized
INFO - 2017-03-03 18:37:29 --> Output Class Initialized
INFO - 2017-03-03 18:37:29 --> Security Class Initialized
DEBUG - 2017-03-03 18:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:37:29 --> Input Class Initialized
INFO - 2017-03-03 18:37:29 --> Language Class Initialized
INFO - 2017-03-03 18:37:29 --> Language Class Initialized
INFO - 2017-03-03 18:37:29 --> Config Class Initialized
INFO - 2017-03-03 18:37:29 --> Loader Class Initialized
INFO - 2017-03-03 18:37:29 --> Helper loaded: form_helper
INFO - 2017-03-03 18:37:29 --> Helper loaded: url_helper
INFO - 2017-03-03 18:37:29 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:37:29 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:37:29 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:37:29 --> Template Class Initialized
INFO - 2017-03-03 18:37:29 --> Model Class Initialized
INFO - 2017-03-03 18:37:29 --> Controller Class Initialized
DEBUG - 2017-03-03 18:37:29 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:37:29 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:37:29 --> Model Class Initialized
DEBUG - 2017-03-03 18:37:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:37:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:37:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:37:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 18:37:29 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:37:29 --> Final output sent to browser
DEBUG - 2017-03-03 18:37:29 --> Total execution time: 0.0185
INFO - 2017-03-03 18:37:32 --> Config Class Initialized
INFO - 2017-03-03 18:37:32 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:37:32 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:37:32 --> Utf8 Class Initialized
INFO - 2017-03-03 18:37:32 --> URI Class Initialized
INFO - 2017-03-03 18:37:32 --> Router Class Initialized
INFO - 2017-03-03 18:37:32 --> Output Class Initialized
INFO - 2017-03-03 18:37:32 --> Security Class Initialized
DEBUG - 2017-03-03 18:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:37:32 --> Input Class Initialized
INFO - 2017-03-03 18:37:32 --> Language Class Initialized
INFO - 2017-03-03 18:37:32 --> Language Class Initialized
INFO - 2017-03-03 18:37:32 --> Config Class Initialized
INFO - 2017-03-03 18:37:32 --> Loader Class Initialized
INFO - 2017-03-03 18:37:32 --> Helper loaded: form_helper
INFO - 2017-03-03 18:37:32 --> Helper loaded: url_helper
INFO - 2017-03-03 18:37:32 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:37:32 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:37:32 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:37:32 --> Template Class Initialized
INFO - 2017-03-03 18:37:32 --> Model Class Initialized
INFO - 2017-03-03 18:37:32 --> Controller Class Initialized
DEBUG - 2017-03-03 18:37:32 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:37:32 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:37:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:37:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:37:34 --> Config Class Initialized
INFO - 2017-03-03 18:37:34 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:37:34 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:37:34 --> Utf8 Class Initialized
INFO - 2017-03-03 18:37:34 --> URI Class Initialized
INFO - 2017-03-03 18:37:34 --> Router Class Initialized
INFO - 2017-03-03 18:37:34 --> Output Class Initialized
INFO - 2017-03-03 18:37:34 --> Security Class Initialized
DEBUG - 2017-03-03 18:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:37:34 --> Input Class Initialized
INFO - 2017-03-03 18:37:34 --> Language Class Initialized
INFO - 2017-03-03 18:37:34 --> Language Class Initialized
INFO - 2017-03-03 18:37:34 --> Config Class Initialized
INFO - 2017-03-03 18:37:34 --> Loader Class Initialized
INFO - 2017-03-03 18:37:34 --> Helper loaded: form_helper
INFO - 2017-03-03 18:37:34 --> Helper loaded: url_helper
INFO - 2017-03-03 18:37:34 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:37:34 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:37:34 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:37:34 --> Template Class Initialized
INFO - 2017-03-03 18:37:34 --> Model Class Initialized
INFO - 2017-03-03 18:37:34 --> Controller Class Initialized
DEBUG - 2017-03-03 18:37:34 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:37:34 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:37:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:37:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:37:39 --> Config Class Initialized
INFO - 2017-03-03 18:37:39 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:37:39 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:37:39 --> Utf8 Class Initialized
INFO - 2017-03-03 18:37:39 --> URI Class Initialized
INFO - 2017-03-03 18:37:39 --> Router Class Initialized
INFO - 2017-03-03 18:37:39 --> Output Class Initialized
INFO - 2017-03-03 18:37:39 --> Security Class Initialized
DEBUG - 2017-03-03 18:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:37:39 --> Input Class Initialized
INFO - 2017-03-03 18:37:39 --> Language Class Initialized
INFO - 2017-03-03 18:37:39 --> Language Class Initialized
INFO - 2017-03-03 18:37:39 --> Config Class Initialized
INFO - 2017-03-03 18:37:39 --> Loader Class Initialized
INFO - 2017-03-03 18:37:39 --> Helper loaded: form_helper
INFO - 2017-03-03 18:37:39 --> Helper loaded: url_helper
INFO - 2017-03-03 18:37:39 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:37:39 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:37:39 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:37:39 --> Template Class Initialized
INFO - 2017-03-03 18:37:39 --> Model Class Initialized
INFO - 2017-03-03 18:37:39 --> Controller Class Initialized
DEBUG - 2017-03-03 18:37:39 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:37:39 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:37:39 --> Model Class Initialized
DEBUG - 2017-03-03 18:37:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:37:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:37:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:37:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 18:37:39 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:37:39 --> Final output sent to browser
DEBUG - 2017-03-03 18:37:39 --> Total execution time: 0.0169
INFO - 2017-03-03 18:37:57 --> Config Class Initialized
INFO - 2017-03-03 18:37:57 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:37:57 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:37:57 --> Utf8 Class Initialized
INFO - 2017-03-03 18:37:57 --> URI Class Initialized
INFO - 2017-03-03 18:37:57 --> Router Class Initialized
INFO - 2017-03-03 18:37:57 --> Output Class Initialized
INFO - 2017-03-03 18:37:57 --> Security Class Initialized
DEBUG - 2017-03-03 18:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:37:57 --> Input Class Initialized
INFO - 2017-03-03 18:37:57 --> Language Class Initialized
INFO - 2017-03-03 18:37:57 --> Language Class Initialized
INFO - 2017-03-03 18:37:57 --> Config Class Initialized
INFO - 2017-03-03 18:37:57 --> Loader Class Initialized
INFO - 2017-03-03 18:37:57 --> Helper loaded: form_helper
INFO - 2017-03-03 18:37:57 --> Helper loaded: url_helper
INFO - 2017-03-03 18:37:57 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:37:57 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:37:57 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:37:57 --> Template Class Initialized
INFO - 2017-03-03 18:37:57 --> Model Class Initialized
INFO - 2017-03-03 18:37:57 --> Controller Class Initialized
DEBUG - 2017-03-03 18:37:57 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:37:57 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:37:57 --> Model Class Initialized
DEBUG - 2017-03-03 18:37:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:37:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:37:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:37:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 18:37:57 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:37:57 --> Final output sent to browser
DEBUG - 2017-03-03 18:37:57 --> Total execution time: 0.0177
INFO - 2017-03-03 18:38:03 --> Config Class Initialized
INFO - 2017-03-03 18:38:03 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:38:03 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:38:03 --> Utf8 Class Initialized
INFO - 2017-03-03 18:38:03 --> URI Class Initialized
INFO - 2017-03-03 18:38:03 --> Router Class Initialized
INFO - 2017-03-03 18:38:03 --> Output Class Initialized
INFO - 2017-03-03 18:38:03 --> Security Class Initialized
DEBUG - 2017-03-03 18:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:38:03 --> Input Class Initialized
INFO - 2017-03-03 18:38:03 --> Language Class Initialized
INFO - 2017-03-03 18:38:03 --> Language Class Initialized
INFO - 2017-03-03 18:38:03 --> Config Class Initialized
INFO - 2017-03-03 18:38:03 --> Loader Class Initialized
INFO - 2017-03-03 18:38:03 --> Helper loaded: form_helper
INFO - 2017-03-03 18:38:03 --> Helper loaded: url_helper
INFO - 2017-03-03 18:38:03 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:38:03 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:38:03 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:38:03 --> Template Class Initialized
INFO - 2017-03-03 18:38:03 --> Model Class Initialized
INFO - 2017-03-03 18:38:03 --> Controller Class Initialized
DEBUG - 2017-03-03 18:38:03 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:38:03 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:38:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:38:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:38:04 --> Config Class Initialized
INFO - 2017-03-03 18:38:04 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:38:04 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:38:04 --> Utf8 Class Initialized
INFO - 2017-03-03 18:38:04 --> URI Class Initialized
INFO - 2017-03-03 18:38:04 --> Router Class Initialized
INFO - 2017-03-03 18:38:04 --> Output Class Initialized
INFO - 2017-03-03 18:38:04 --> Security Class Initialized
DEBUG - 2017-03-03 18:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:38:04 --> Input Class Initialized
INFO - 2017-03-03 18:38:04 --> Language Class Initialized
INFO - 2017-03-03 18:38:04 --> Language Class Initialized
INFO - 2017-03-03 18:38:04 --> Config Class Initialized
INFO - 2017-03-03 18:38:04 --> Loader Class Initialized
INFO - 2017-03-03 18:38:04 --> Helper loaded: form_helper
INFO - 2017-03-03 18:38:04 --> Helper loaded: url_helper
INFO - 2017-03-03 18:38:04 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:38:04 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:38:04 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:38:04 --> Template Class Initialized
INFO - 2017-03-03 18:38:04 --> Model Class Initialized
INFO - 2017-03-03 18:38:04 --> Controller Class Initialized
DEBUG - 2017-03-03 18:38:04 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:38:04 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:38:04 --> Model Class Initialized
DEBUG - 2017-03-03 18:38:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:38:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:38:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:38:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 18:38:04 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:38:04 --> Final output sent to browser
DEBUG - 2017-03-03 18:38:04 --> Total execution time: 0.0167
INFO - 2017-03-03 18:38:05 --> Config Class Initialized
INFO - 2017-03-03 18:38:05 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:38:05 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:38:05 --> Utf8 Class Initialized
INFO - 2017-03-03 18:38:05 --> URI Class Initialized
INFO - 2017-03-03 18:38:05 --> Router Class Initialized
INFO - 2017-03-03 18:38:05 --> Output Class Initialized
INFO - 2017-03-03 18:38:05 --> Security Class Initialized
DEBUG - 2017-03-03 18:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:38:05 --> Input Class Initialized
INFO - 2017-03-03 18:38:05 --> Language Class Initialized
INFO - 2017-03-03 18:38:05 --> Language Class Initialized
INFO - 2017-03-03 18:38:05 --> Config Class Initialized
INFO - 2017-03-03 18:38:05 --> Loader Class Initialized
INFO - 2017-03-03 18:38:05 --> Helper loaded: form_helper
INFO - 2017-03-03 18:38:05 --> Helper loaded: url_helper
INFO - 2017-03-03 18:38:05 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:38:05 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:38:05 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:38:05 --> Template Class Initialized
INFO - 2017-03-03 18:38:05 --> Model Class Initialized
INFO - 2017-03-03 18:38:05 --> Controller Class Initialized
DEBUG - 2017-03-03 18:38:05 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:38:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:38:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:38:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:38:07 --> Config Class Initialized
INFO - 2017-03-03 18:38:07 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:38:07 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:38:07 --> Utf8 Class Initialized
INFO - 2017-03-03 18:38:07 --> URI Class Initialized
INFO - 2017-03-03 18:38:07 --> Router Class Initialized
INFO - 2017-03-03 18:38:07 --> Output Class Initialized
INFO - 2017-03-03 18:38:07 --> Security Class Initialized
DEBUG - 2017-03-03 18:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:38:07 --> Input Class Initialized
INFO - 2017-03-03 18:38:07 --> Language Class Initialized
INFO - 2017-03-03 18:38:07 --> Language Class Initialized
INFO - 2017-03-03 18:38:07 --> Config Class Initialized
INFO - 2017-03-03 18:38:07 --> Loader Class Initialized
INFO - 2017-03-03 18:38:07 --> Helper loaded: form_helper
INFO - 2017-03-03 18:38:07 --> Helper loaded: url_helper
INFO - 2017-03-03 18:38:07 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:38:07 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:38:07 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:38:07 --> Template Class Initialized
INFO - 2017-03-03 18:38:07 --> Model Class Initialized
INFO - 2017-03-03 18:38:07 --> Controller Class Initialized
DEBUG - 2017-03-03 18:38:07 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:38:07 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:38:07 --> Model Class Initialized
DEBUG - 2017-03-03 18:38:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:38:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:38:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:38:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 18:38:07 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:38:07 --> Final output sent to browser
DEBUG - 2017-03-03 18:38:07 --> Total execution time: 0.0152
INFO - 2017-03-03 18:38:17 --> Config Class Initialized
INFO - 2017-03-03 18:38:17 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:38:17 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:38:17 --> Utf8 Class Initialized
INFO - 2017-03-03 18:38:17 --> URI Class Initialized
INFO - 2017-03-03 18:38:17 --> Router Class Initialized
INFO - 2017-03-03 18:38:17 --> Output Class Initialized
INFO - 2017-03-03 18:38:17 --> Security Class Initialized
DEBUG - 2017-03-03 18:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:38:17 --> Input Class Initialized
INFO - 2017-03-03 18:38:17 --> Language Class Initialized
INFO - 2017-03-03 18:38:17 --> Language Class Initialized
INFO - 2017-03-03 18:38:17 --> Config Class Initialized
INFO - 2017-03-03 18:38:17 --> Loader Class Initialized
INFO - 2017-03-03 18:38:17 --> Helper loaded: form_helper
INFO - 2017-03-03 18:38:17 --> Helper loaded: url_helper
INFO - 2017-03-03 18:38:17 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:38:17 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:38:17 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:38:17 --> Template Class Initialized
INFO - 2017-03-03 18:38:17 --> Model Class Initialized
INFO - 2017-03-03 18:38:17 --> Controller Class Initialized
DEBUG - 2017-03-03 18:38:17 --> Project MX_Controller Initialized
INFO - 2017-03-03 18:38:17 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:38:17 --> Model Class Initialized
DEBUG - 2017-03-03 18:38:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 18:38:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 18:38:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 18:38:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 18:38:17 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 18:38:17 --> Final output sent to browser
DEBUG - 2017-03-03 18:38:17 --> Total execution time: 0.0175
INFO - 2017-03-03 18:39:35 --> Config Class Initialized
INFO - 2017-03-03 18:39:35 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:39:35 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:39:35 --> Utf8 Class Initialized
INFO - 2017-03-03 18:39:35 --> URI Class Initialized
INFO - 2017-03-03 18:39:35 --> Router Class Initialized
INFO - 2017-03-03 18:39:35 --> Output Class Initialized
INFO - 2017-03-03 18:39:35 --> Security Class Initialized
DEBUG - 2017-03-03 18:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:39:35 --> Input Class Initialized
INFO - 2017-03-03 18:39:35 --> Language Class Initialized
INFO - 2017-03-03 18:39:35 --> Language Class Initialized
INFO - 2017-03-03 18:39:35 --> Config Class Initialized
INFO - 2017-03-03 18:39:35 --> Loader Class Initialized
INFO - 2017-03-03 18:39:35 --> Helper loaded: form_helper
INFO - 2017-03-03 18:39:35 --> Helper loaded: url_helper
INFO - 2017-03-03 18:39:35 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:39:35 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:39:35 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:39:35 --> Template Class Initialized
INFO - 2017-03-03 18:39:35 --> Model Class Initialized
INFO - 2017-03-03 18:39:35 --> Controller Class Initialized
DEBUG - 2017-03-03 18:39:35 --> Login MX_Controller Initialized
INFO - 2017-03-03 18:39:35 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:39:35 --> Form Validation Class Initialized
INFO - 2017-03-03 18:39:35 --> Config Class Initialized
INFO - 2017-03-03 18:39:35 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:39:35 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:39:35 --> Utf8 Class Initialized
INFO - 2017-03-03 18:39:35 --> URI Class Initialized
DEBUG - 2017-03-03 18:39:35 --> No URI present. Default controller set.
INFO - 2017-03-03 18:39:35 --> Router Class Initialized
INFO - 2017-03-03 18:39:35 --> Output Class Initialized
INFO - 2017-03-03 18:39:35 --> Security Class Initialized
DEBUG - 2017-03-03 18:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:39:35 --> Input Class Initialized
INFO - 2017-03-03 18:39:35 --> Language Class Initialized
INFO - 2017-03-03 18:39:35 --> Language Class Initialized
INFO - 2017-03-03 18:39:35 --> Config Class Initialized
INFO - 2017-03-03 18:39:35 --> Loader Class Initialized
INFO - 2017-03-03 18:39:35 --> Helper loaded: form_helper
INFO - 2017-03-03 18:39:35 --> Helper loaded: url_helper
INFO - 2017-03-03 18:39:35 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:39:35 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:39:35 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:39:35 --> Template Class Initialized
INFO - 2017-03-03 18:39:35 --> Model Class Initialized
INFO - 2017-03-03 18:39:35 --> Controller Class Initialized
DEBUG - 2017-03-03 18:39:35 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:39:35 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:39:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:39:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 18:39:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-03 18:39:35 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 18:39:35 --> Final output sent to browser
DEBUG - 2017-03-03 18:39:35 --> Total execution time: 0.0143
INFO - 2017-03-03 18:39:35 --> Config Class Initialized
INFO - 2017-03-03 18:39:35 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:39:35 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:39:35 --> Utf8 Class Initialized
INFO - 2017-03-03 18:39:35 --> URI Class Initialized
INFO - 2017-03-03 18:39:35 --> Router Class Initialized
INFO - 2017-03-03 18:39:35 --> Output Class Initialized
INFO - 2017-03-03 18:39:35 --> Security Class Initialized
DEBUG - 2017-03-03 18:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:39:35 --> Input Class Initialized
INFO - 2017-03-03 18:39:35 --> Language Class Initialized
INFO - 2017-03-03 18:39:35 --> Language Class Initialized
INFO - 2017-03-03 18:39:35 --> Config Class Initialized
INFO - 2017-03-03 18:39:35 --> Loader Class Initialized
INFO - 2017-03-03 18:39:35 --> Helper loaded: form_helper
INFO - 2017-03-03 18:39:35 --> Helper loaded: url_helper
INFO - 2017-03-03 18:39:35 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:39:35 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:39:35 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:39:35 --> Template Class Initialized
INFO - 2017-03-03 18:39:35 --> Model Class Initialized
INFO - 2017-03-03 18:39:35 --> Controller Class Initialized
DEBUG - 2017-03-03 18:39:35 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:39:35 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:39:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:39:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:39:35 --> Config Class Initialized
INFO - 2017-03-03 18:39:35 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:39:35 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:39:35 --> Utf8 Class Initialized
INFO - 2017-03-03 18:39:35 --> URI Class Initialized
INFO - 2017-03-03 18:39:35 --> Router Class Initialized
INFO - 2017-03-03 18:39:35 --> Output Class Initialized
INFO - 2017-03-03 18:39:35 --> Security Class Initialized
DEBUG - 2017-03-03 18:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:39:35 --> Input Class Initialized
INFO - 2017-03-03 18:39:35 --> Language Class Initialized
INFO - 2017-03-03 18:39:35 --> Language Class Initialized
INFO - 2017-03-03 18:39:35 --> Config Class Initialized
INFO - 2017-03-03 18:39:35 --> Loader Class Initialized
INFO - 2017-03-03 18:39:35 --> Helper loaded: form_helper
INFO - 2017-03-03 18:39:35 --> Helper loaded: url_helper
INFO - 2017-03-03 18:39:35 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:39:35 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:39:35 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:39:35 --> Template Class Initialized
INFO - 2017-03-03 18:39:35 --> Model Class Initialized
INFO - 2017-03-03 18:39:35 --> Controller Class Initialized
DEBUG - 2017-03-03 18:39:35 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:39:35 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:39:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:39:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:39:36 --> Config Class Initialized
INFO - 2017-03-03 18:39:36 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:39:36 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:39:36 --> Utf8 Class Initialized
INFO - 2017-03-03 18:39:36 --> URI Class Initialized
INFO - 2017-03-03 18:39:36 --> Router Class Initialized
INFO - 2017-03-03 18:39:36 --> Output Class Initialized
INFO - 2017-03-03 18:39:36 --> Security Class Initialized
DEBUG - 2017-03-03 18:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:39:36 --> Input Class Initialized
INFO - 2017-03-03 18:39:36 --> Language Class Initialized
INFO - 2017-03-03 18:39:36 --> Language Class Initialized
INFO - 2017-03-03 18:39:36 --> Config Class Initialized
INFO - 2017-03-03 18:39:36 --> Loader Class Initialized
INFO - 2017-03-03 18:39:36 --> Helper loaded: form_helper
INFO - 2017-03-03 18:39:36 --> Helper loaded: url_helper
INFO - 2017-03-03 18:39:36 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:39:36 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:39:36 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:39:36 --> Template Class Initialized
INFO - 2017-03-03 18:39:36 --> Model Class Initialized
INFO - 2017-03-03 18:39:36 --> Controller Class Initialized
DEBUG - 2017-03-03 18:39:36 --> Login MX_Controller Initialized
INFO - 2017-03-03 18:39:36 --> Helper loaded: cookie_helper
INFO - 2017-03-03 18:39:36 --> Form Validation Class Initialized
INFO - 2017-03-03 18:39:36 --> Config Class Initialized
INFO - 2017-03-03 18:39:36 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:39:36 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:39:36 --> Utf8 Class Initialized
INFO - 2017-03-03 18:39:36 --> URI Class Initialized
DEBUG - 2017-03-03 18:39:36 --> No URI present. Default controller set.
INFO - 2017-03-03 18:39:36 --> Router Class Initialized
INFO - 2017-03-03 18:39:36 --> Output Class Initialized
INFO - 2017-03-03 18:39:36 --> Security Class Initialized
DEBUG - 2017-03-03 18:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:39:36 --> Input Class Initialized
INFO - 2017-03-03 18:39:36 --> Language Class Initialized
INFO - 2017-03-03 18:39:36 --> Language Class Initialized
INFO - 2017-03-03 18:39:36 --> Config Class Initialized
INFO - 2017-03-03 18:39:36 --> Loader Class Initialized
INFO - 2017-03-03 18:39:36 --> Helper loaded: form_helper
INFO - 2017-03-03 18:39:36 --> Helper loaded: url_helper
INFO - 2017-03-03 18:39:36 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:39:36 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:39:36 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:39:36 --> Template Class Initialized
INFO - 2017-03-03 18:39:36 --> Model Class Initialized
INFO - 2017-03-03 18:39:36 --> Controller Class Initialized
DEBUG - 2017-03-03 18:39:36 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:39:36 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:39:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:39:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 18:39:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-03 18:39:36 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 18:39:36 --> Final output sent to browser
DEBUG - 2017-03-03 18:39:36 --> Total execution time: 0.0136
INFO - 2017-03-03 18:39:36 --> Config Class Initialized
INFO - 2017-03-03 18:39:36 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:39:36 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:39:36 --> Utf8 Class Initialized
INFO - 2017-03-03 18:39:36 --> URI Class Initialized
INFO - 2017-03-03 18:39:36 --> Router Class Initialized
INFO - 2017-03-03 18:39:36 --> Output Class Initialized
INFO - 2017-03-03 18:39:36 --> Security Class Initialized
DEBUG - 2017-03-03 18:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:39:36 --> Input Class Initialized
INFO - 2017-03-03 18:39:36 --> Language Class Initialized
INFO - 2017-03-03 18:39:36 --> Language Class Initialized
INFO - 2017-03-03 18:39:36 --> Config Class Initialized
INFO - 2017-03-03 18:39:36 --> Loader Class Initialized
INFO - 2017-03-03 18:39:36 --> Helper loaded: form_helper
INFO - 2017-03-03 18:39:36 --> Helper loaded: url_helper
INFO - 2017-03-03 18:39:36 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:39:36 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:39:36 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:39:36 --> Template Class Initialized
INFO - 2017-03-03 18:39:36 --> Model Class Initialized
INFO - 2017-03-03 18:39:36 --> Controller Class Initialized
DEBUG - 2017-03-03 18:39:36 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:39:36 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:39:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:39:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:39:36 --> Config Class Initialized
INFO - 2017-03-03 18:39:36 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:39:36 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:39:36 --> Utf8 Class Initialized
INFO - 2017-03-03 18:39:36 --> URI Class Initialized
INFO - 2017-03-03 18:39:36 --> Router Class Initialized
INFO - 2017-03-03 18:39:36 --> Output Class Initialized
INFO - 2017-03-03 18:39:36 --> Security Class Initialized
DEBUG - 2017-03-03 18:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:39:36 --> Input Class Initialized
INFO - 2017-03-03 18:39:36 --> Language Class Initialized
INFO - 2017-03-03 18:39:36 --> Language Class Initialized
INFO - 2017-03-03 18:39:36 --> Config Class Initialized
INFO - 2017-03-03 18:39:36 --> Loader Class Initialized
INFO - 2017-03-03 18:39:36 --> Helper loaded: form_helper
INFO - 2017-03-03 18:39:36 --> Helper loaded: url_helper
INFO - 2017-03-03 18:39:36 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:39:36 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:39:36 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:39:36 --> Template Class Initialized
INFO - 2017-03-03 18:39:36 --> Model Class Initialized
INFO - 2017-03-03 18:39:36 --> Controller Class Initialized
DEBUG - 2017-03-03 18:39:36 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:39:36 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:39:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:39:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:39:37 --> Config Class Initialized
INFO - 2017-03-03 18:39:37 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:39:37 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:39:37 --> Utf8 Class Initialized
INFO - 2017-03-03 18:39:37 --> URI Class Initialized
INFO - 2017-03-03 18:39:37 --> Router Class Initialized
INFO - 2017-03-03 18:39:37 --> Output Class Initialized
INFO - 2017-03-03 18:39:37 --> Security Class Initialized
DEBUG - 2017-03-03 18:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:39:37 --> Input Class Initialized
INFO - 2017-03-03 18:39:37 --> Language Class Initialized
INFO - 2017-03-03 18:39:37 --> Language Class Initialized
INFO - 2017-03-03 18:39:37 --> Config Class Initialized
INFO - 2017-03-03 18:39:37 --> Loader Class Initialized
INFO - 2017-03-03 18:39:37 --> Helper loaded: form_helper
INFO - 2017-03-03 18:39:37 --> Helper loaded: url_helper
INFO - 2017-03-03 18:39:37 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:39:37 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:39:37 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:39:37 --> Template Class Initialized
INFO - 2017-03-03 18:39:37 --> Model Class Initialized
INFO - 2017-03-03 18:39:37 --> Controller Class Initialized
DEBUG - 2017-03-03 18:39:37 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:39:37 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:39:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:39:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:39:37 --> Config Class Initialized
INFO - 2017-03-03 18:39:37 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:39:37 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:39:37 --> Utf8 Class Initialized
INFO - 2017-03-03 18:39:37 --> URI Class Initialized
INFO - 2017-03-03 18:39:37 --> Router Class Initialized
INFO - 2017-03-03 18:39:37 --> Output Class Initialized
INFO - 2017-03-03 18:39:37 --> Security Class Initialized
DEBUG - 2017-03-03 18:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:39:37 --> Input Class Initialized
INFO - 2017-03-03 18:39:37 --> Language Class Initialized
INFO - 2017-03-03 18:39:37 --> Language Class Initialized
INFO - 2017-03-03 18:39:37 --> Config Class Initialized
INFO - 2017-03-03 18:39:37 --> Loader Class Initialized
INFO - 2017-03-03 18:39:37 --> Helper loaded: form_helper
INFO - 2017-03-03 18:39:37 --> Helper loaded: url_helper
INFO - 2017-03-03 18:39:37 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:39:37 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:39:37 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:39:37 --> Template Class Initialized
INFO - 2017-03-03 18:39:37 --> Model Class Initialized
INFO - 2017-03-03 18:39:37 --> Controller Class Initialized
DEBUG - 2017-03-03 18:39:37 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:39:37 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:39:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:39:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:39:39 --> Config Class Initialized
INFO - 2017-03-03 18:39:39 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:39:39 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:39:39 --> Utf8 Class Initialized
INFO - 2017-03-03 18:39:39 --> URI Class Initialized
INFO - 2017-03-03 18:39:39 --> Router Class Initialized
INFO - 2017-03-03 18:39:39 --> Output Class Initialized
INFO - 2017-03-03 18:39:39 --> Security Class Initialized
DEBUG - 2017-03-03 18:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:39:39 --> Input Class Initialized
INFO - 2017-03-03 18:39:39 --> Language Class Initialized
INFO - 2017-03-03 18:39:39 --> Language Class Initialized
INFO - 2017-03-03 18:39:39 --> Config Class Initialized
INFO - 2017-03-03 18:39:39 --> Loader Class Initialized
INFO - 2017-03-03 18:39:39 --> Helper loaded: form_helper
INFO - 2017-03-03 18:39:39 --> Helper loaded: url_helper
INFO - 2017-03-03 18:39:39 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:39:39 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:39:39 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:39:39 --> Template Class Initialized
INFO - 2017-03-03 18:39:39 --> Model Class Initialized
INFO - 2017-03-03 18:39:39 --> Controller Class Initialized
DEBUG - 2017-03-03 18:39:39 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:39:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:39:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:39:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 18:39:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-03 18:39:39 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 18:39:39 --> Final output sent to browser
DEBUG - 2017-03-03 18:39:39 --> Total execution time: 0.0150
INFO - 2017-03-03 18:39:40 --> Config Class Initialized
INFO - 2017-03-03 18:39:40 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:39:40 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:39:40 --> Utf8 Class Initialized
INFO - 2017-03-03 18:39:40 --> URI Class Initialized
INFO - 2017-03-03 18:39:40 --> Router Class Initialized
INFO - 2017-03-03 18:39:40 --> Output Class Initialized
INFO - 2017-03-03 18:39:40 --> Security Class Initialized
DEBUG - 2017-03-03 18:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:39:40 --> Input Class Initialized
INFO - 2017-03-03 18:39:40 --> Language Class Initialized
INFO - 2017-03-03 18:39:40 --> Language Class Initialized
INFO - 2017-03-03 18:39:40 --> Config Class Initialized
INFO - 2017-03-03 18:39:40 --> Loader Class Initialized
INFO - 2017-03-03 18:39:40 --> Helper loaded: form_helper
INFO - 2017-03-03 18:39:40 --> Helper loaded: url_helper
INFO - 2017-03-03 18:39:40 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:39:40 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:39:40 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:39:40 --> Template Class Initialized
INFO - 2017-03-03 18:39:40 --> Model Class Initialized
INFO - 2017-03-03 18:39:40 --> Controller Class Initialized
DEBUG - 2017-03-03 18:39:40 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:39:40 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:39:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:39:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:39:40 --> Config Class Initialized
INFO - 2017-03-03 18:39:40 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:39:40 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:39:40 --> Utf8 Class Initialized
INFO - 2017-03-03 18:39:40 --> URI Class Initialized
INFO - 2017-03-03 18:39:40 --> Router Class Initialized
INFO - 2017-03-03 18:39:40 --> Output Class Initialized
INFO - 2017-03-03 18:39:40 --> Security Class Initialized
DEBUG - 2017-03-03 18:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:39:40 --> Input Class Initialized
INFO - 2017-03-03 18:39:40 --> Language Class Initialized
INFO - 2017-03-03 18:39:40 --> Language Class Initialized
INFO - 2017-03-03 18:39:40 --> Config Class Initialized
INFO - 2017-03-03 18:39:40 --> Loader Class Initialized
INFO - 2017-03-03 18:39:40 --> Helper loaded: form_helper
INFO - 2017-03-03 18:39:40 --> Helper loaded: url_helper
INFO - 2017-03-03 18:39:40 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:39:40 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:39:40 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:39:40 --> Template Class Initialized
INFO - 2017-03-03 18:39:40 --> Model Class Initialized
INFO - 2017-03-03 18:39:40 --> Controller Class Initialized
DEBUG - 2017-03-03 18:39:40 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:39:40 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:39:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:39:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:39:40 --> Config Class Initialized
INFO - 2017-03-03 18:39:40 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:39:40 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:39:40 --> Utf8 Class Initialized
INFO - 2017-03-03 18:39:40 --> URI Class Initialized
INFO - 2017-03-03 18:39:40 --> Router Class Initialized
INFO - 2017-03-03 18:39:40 --> Output Class Initialized
INFO - 2017-03-03 18:39:40 --> Security Class Initialized
DEBUG - 2017-03-03 18:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:39:40 --> Input Class Initialized
INFO - 2017-03-03 18:39:40 --> Language Class Initialized
INFO - 2017-03-03 18:39:40 --> Language Class Initialized
INFO - 2017-03-03 18:39:40 --> Config Class Initialized
INFO - 2017-03-03 18:39:40 --> Loader Class Initialized
INFO - 2017-03-03 18:39:40 --> Helper loaded: form_helper
INFO - 2017-03-03 18:39:40 --> Helper loaded: url_helper
INFO - 2017-03-03 18:39:40 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:39:40 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:39:40 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:39:40 --> Template Class Initialized
INFO - 2017-03-03 18:39:40 --> Model Class Initialized
INFO - 2017-03-03 18:39:40 --> Controller Class Initialized
DEBUG - 2017-03-03 18:39:40 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:39:40 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:39:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:39:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:39:52 --> Config Class Initialized
INFO - 2017-03-03 18:39:52 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:39:52 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:39:52 --> Utf8 Class Initialized
INFO - 2017-03-03 18:39:52 --> URI Class Initialized
INFO - 2017-03-03 18:39:52 --> Router Class Initialized
INFO - 2017-03-03 18:39:52 --> Output Class Initialized
INFO - 2017-03-03 18:39:52 --> Security Class Initialized
DEBUG - 2017-03-03 18:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:39:52 --> Input Class Initialized
INFO - 2017-03-03 18:39:52 --> Language Class Initialized
INFO - 2017-03-03 18:39:52 --> Language Class Initialized
INFO - 2017-03-03 18:39:52 --> Config Class Initialized
INFO - 2017-03-03 18:39:52 --> Loader Class Initialized
INFO - 2017-03-03 18:39:52 --> Helper loaded: form_helper
INFO - 2017-03-03 18:39:52 --> Helper loaded: url_helper
INFO - 2017-03-03 18:39:52 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:39:52 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:39:52 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:39:52 --> Template Class Initialized
INFO - 2017-03-03 18:39:52 --> Model Class Initialized
INFO - 2017-03-03 18:39:52 --> Controller Class Initialized
DEBUG - 2017-03-03 18:39:52 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:39:52 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:39:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:39:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 18:39:53 --> Config Class Initialized
INFO - 2017-03-03 18:39:53 --> Hooks Class Initialized
DEBUG - 2017-03-03 18:39:53 --> UTF-8 Support Enabled
INFO - 2017-03-03 18:39:53 --> Utf8 Class Initialized
INFO - 2017-03-03 18:39:53 --> URI Class Initialized
INFO - 2017-03-03 18:39:53 --> Router Class Initialized
INFO - 2017-03-03 18:39:53 --> Output Class Initialized
INFO - 2017-03-03 18:39:53 --> Security Class Initialized
DEBUG - 2017-03-03 18:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 18:39:53 --> Input Class Initialized
INFO - 2017-03-03 18:39:53 --> Language Class Initialized
INFO - 2017-03-03 18:39:53 --> Language Class Initialized
INFO - 2017-03-03 18:39:53 --> Config Class Initialized
INFO - 2017-03-03 18:39:53 --> Loader Class Initialized
INFO - 2017-03-03 18:39:53 --> Helper loaded: form_helper
INFO - 2017-03-03 18:39:53 --> Helper loaded: url_helper
INFO - 2017-03-03 18:39:53 --> Helper loaded: utility_helper
INFO - 2017-03-03 18:39:53 --> Database Driver Class Initialized
DEBUG - 2017-03-03 18:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 18:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 18:39:53 --> User Agent Class Initialized
DEBUG - 2017-03-03 18:39:53 --> Template Class Initialized
INFO - 2017-03-03 18:39:53 --> Model Class Initialized
INFO - 2017-03-03 18:39:53 --> Controller Class Initialized
DEBUG - 2017-03-03 18:39:53 --> Pages MX_Controller Initialized
INFO - 2017-03-03 18:39:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 18:39:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 18:39:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:24:00 --> Config Class Initialized
INFO - 2017-03-03 20:24:00 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:24:00 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:24:00 --> Utf8 Class Initialized
INFO - 2017-03-03 20:24:00 --> URI Class Initialized
INFO - 2017-03-03 20:24:00 --> Router Class Initialized
INFO - 2017-03-03 20:24:00 --> Output Class Initialized
INFO - 2017-03-03 20:24:00 --> Security Class Initialized
DEBUG - 2017-03-03 20:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:24:00 --> Input Class Initialized
INFO - 2017-03-03 20:24:00 --> Language Class Initialized
INFO - 2017-03-03 20:24:00 --> Language Class Initialized
INFO - 2017-03-03 20:24:00 --> Config Class Initialized
INFO - 2017-03-03 20:24:00 --> Loader Class Initialized
INFO - 2017-03-03 20:24:00 --> Helper loaded: form_helper
INFO - 2017-03-03 20:24:00 --> Helper loaded: url_helper
INFO - 2017-03-03 20:24:00 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:24:00 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:24:00 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:24:00 --> Template Class Initialized
INFO - 2017-03-03 20:24:00 --> Model Class Initialized
INFO - 2017-03-03 20:24:00 --> Controller Class Initialized
DEBUG - 2017-03-03 20:24:00 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:24:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:24:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:24:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 20:24:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-03 20:24:00 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 20:24:00 --> Final output sent to browser
DEBUG - 2017-03-03 20:24:00 --> Total execution time: 0.2776
INFO - 2017-03-03 20:24:02 --> Config Class Initialized
INFO - 2017-03-03 20:24:02 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:24:02 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:24:02 --> Utf8 Class Initialized
INFO - 2017-03-03 20:24:02 --> URI Class Initialized
INFO - 2017-03-03 20:24:02 --> Router Class Initialized
INFO - 2017-03-03 20:24:02 --> Output Class Initialized
INFO - 2017-03-03 20:24:02 --> Security Class Initialized
DEBUG - 2017-03-03 20:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:24:02 --> Input Class Initialized
INFO - 2017-03-03 20:24:02 --> Language Class Initialized
INFO - 2017-03-03 20:24:02 --> Language Class Initialized
INFO - 2017-03-03 20:24:02 --> Config Class Initialized
INFO - 2017-03-03 20:24:02 --> Loader Class Initialized
INFO - 2017-03-03 20:24:02 --> Helper loaded: form_helper
INFO - 2017-03-03 20:24:02 --> Helper loaded: url_helper
INFO - 2017-03-03 20:24:02 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:24:02 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:24:02 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:24:02 --> Template Class Initialized
INFO - 2017-03-03 20:24:02 --> Model Class Initialized
INFO - 2017-03-03 20:24:02 --> Controller Class Initialized
DEBUG - 2017-03-03 20:24:02 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:24:02 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:24:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:24:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:24:07 --> Config Class Initialized
INFO - 2017-03-03 20:24:07 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:24:07 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:24:07 --> Utf8 Class Initialized
INFO - 2017-03-03 20:24:07 --> URI Class Initialized
INFO - 2017-03-03 20:24:07 --> Router Class Initialized
INFO - 2017-03-03 20:24:07 --> Output Class Initialized
INFO - 2017-03-03 20:24:07 --> Security Class Initialized
DEBUG - 2017-03-03 20:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:24:07 --> Input Class Initialized
INFO - 2017-03-03 20:24:07 --> Language Class Initialized
INFO - 2017-03-03 20:24:07 --> Language Class Initialized
INFO - 2017-03-03 20:24:07 --> Config Class Initialized
INFO - 2017-03-03 20:24:07 --> Loader Class Initialized
INFO - 2017-03-03 20:24:07 --> Helper loaded: form_helper
INFO - 2017-03-03 20:24:07 --> Helper loaded: url_helper
INFO - 2017-03-03 20:24:07 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:24:07 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:24:07 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:24:07 --> Template Class Initialized
INFO - 2017-03-03 20:24:07 --> Model Class Initialized
INFO - 2017-03-03 20:24:07 --> Controller Class Initialized
DEBUG - 2017-03-03 20:24:07 --> Login MX_Controller Initialized
INFO - 2017-03-03 20:24:07 --> Helper loaded: cookie_helper
INFO - 2017-03-03 20:24:07 --> Form Validation Class Initialized
INFO - 2017-03-03 20:24:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-03 20:24:07 --> Config Class Initialized
INFO - 2017-03-03 20:24:07 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:24:07 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:24:07 --> Utf8 Class Initialized
INFO - 2017-03-03 20:24:07 --> URI Class Initialized
INFO - 2017-03-03 20:24:07 --> Router Class Initialized
INFO - 2017-03-03 20:24:07 --> Output Class Initialized
INFO - 2017-03-03 20:24:07 --> Security Class Initialized
DEBUG - 2017-03-03 20:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:24:07 --> Input Class Initialized
INFO - 2017-03-03 20:24:07 --> Language Class Initialized
INFO - 2017-03-03 20:24:07 --> Language Class Initialized
INFO - 2017-03-03 20:24:07 --> Config Class Initialized
INFO - 2017-03-03 20:24:07 --> Loader Class Initialized
INFO - 2017-03-03 20:24:07 --> Helper loaded: form_helper
INFO - 2017-03-03 20:24:07 --> Helper loaded: url_helper
INFO - 2017-03-03 20:24:07 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:24:07 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:24:07 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:24:07 --> Template Class Initialized
INFO - 2017-03-03 20:24:07 --> Model Class Initialized
INFO - 2017-03-03 20:24:07 --> Controller Class Initialized
DEBUG - 2017-03-03 20:24:07 --> Dashboard MX_Controller Initialized
INFO - 2017-03-03 20:24:07 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:24:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 20:24:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 20:24:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 20:24:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-03 20:24:07 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 20:24:07 --> Final output sent to browser
DEBUG - 2017-03-03 20:24:07 --> Total execution time: 0.0534
INFO - 2017-03-03 20:27:34 --> Config Class Initialized
INFO - 2017-03-03 20:27:34 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:27:34 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:27:34 --> Utf8 Class Initialized
INFO - 2017-03-03 20:27:34 --> URI Class Initialized
INFO - 2017-03-03 20:27:34 --> Router Class Initialized
INFO - 2017-03-03 20:27:34 --> Output Class Initialized
INFO - 2017-03-03 20:27:34 --> Security Class Initialized
DEBUG - 2017-03-03 20:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:27:34 --> Input Class Initialized
INFO - 2017-03-03 20:27:34 --> Language Class Initialized
INFO - 2017-03-03 20:27:34 --> Language Class Initialized
INFO - 2017-03-03 20:27:34 --> Config Class Initialized
INFO - 2017-03-03 20:27:34 --> Loader Class Initialized
INFO - 2017-03-03 20:27:34 --> Helper loaded: form_helper
INFO - 2017-03-03 20:27:34 --> Helper loaded: url_helper
INFO - 2017-03-03 20:27:34 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:27:34 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:27:34 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:27:34 --> Template Class Initialized
INFO - 2017-03-03 20:27:34 --> Model Class Initialized
INFO - 2017-03-03 20:27:34 --> Controller Class Initialized
DEBUG - 2017-03-03 20:27:34 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:27:34 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:27:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:27:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 20:27:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-03 20:27:34 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 20:27:34 --> Final output sent to browser
DEBUG - 2017-03-03 20:27:34 --> Total execution time: 0.0601
INFO - 2017-03-03 20:27:35 --> Config Class Initialized
INFO - 2017-03-03 20:27:35 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:27:35 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:27:35 --> Utf8 Class Initialized
INFO - 2017-03-03 20:27:35 --> URI Class Initialized
INFO - 2017-03-03 20:27:35 --> Router Class Initialized
INFO - 2017-03-03 20:27:35 --> Output Class Initialized
INFO - 2017-03-03 20:27:35 --> Security Class Initialized
DEBUG - 2017-03-03 20:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:27:35 --> Input Class Initialized
INFO - 2017-03-03 20:27:35 --> Language Class Initialized
INFO - 2017-03-03 20:27:35 --> Language Class Initialized
INFO - 2017-03-03 20:27:35 --> Config Class Initialized
INFO - 2017-03-03 20:27:36 --> Loader Class Initialized
INFO - 2017-03-03 20:27:36 --> Helper loaded: form_helper
INFO - 2017-03-03 20:27:36 --> Helper loaded: url_helper
INFO - 2017-03-03 20:27:36 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:27:36 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:27:36 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:27:36 --> Template Class Initialized
INFO - 2017-03-03 20:27:36 --> Model Class Initialized
INFO - 2017-03-03 20:27:36 --> Controller Class Initialized
DEBUG - 2017-03-03 20:27:36 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:27:36 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:27:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:27:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:27:37 --> Config Class Initialized
INFO - 2017-03-03 20:27:37 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:27:37 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:27:37 --> Utf8 Class Initialized
INFO - 2017-03-03 20:27:37 --> URI Class Initialized
INFO - 2017-03-03 20:27:37 --> Router Class Initialized
INFO - 2017-03-03 20:27:37 --> Output Class Initialized
INFO - 2017-03-03 20:27:37 --> Security Class Initialized
DEBUG - 2017-03-03 20:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:27:37 --> Input Class Initialized
INFO - 2017-03-03 20:27:37 --> Language Class Initialized
INFO - 2017-03-03 20:27:37 --> Language Class Initialized
INFO - 2017-03-03 20:27:37 --> Config Class Initialized
INFO - 2017-03-03 20:27:37 --> Loader Class Initialized
INFO - 2017-03-03 20:27:37 --> Helper loaded: form_helper
INFO - 2017-03-03 20:27:37 --> Helper loaded: url_helper
INFO - 2017-03-03 20:27:37 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:27:37 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:27:37 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:27:37 --> Template Class Initialized
INFO - 2017-03-03 20:27:37 --> Model Class Initialized
INFO - 2017-03-03 20:27:37 --> Controller Class Initialized
DEBUG - 2017-03-03 20:27:37 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:27:37 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:27:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:27:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:27:37 --> Config Class Initialized
INFO - 2017-03-03 20:27:37 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:27:37 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:27:37 --> Utf8 Class Initialized
INFO - 2017-03-03 20:27:37 --> URI Class Initialized
INFO - 2017-03-03 20:27:37 --> Router Class Initialized
INFO - 2017-03-03 20:27:37 --> Output Class Initialized
INFO - 2017-03-03 20:27:37 --> Security Class Initialized
DEBUG - 2017-03-03 20:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:27:37 --> Input Class Initialized
INFO - 2017-03-03 20:27:37 --> Language Class Initialized
INFO - 2017-03-03 20:27:37 --> Language Class Initialized
INFO - 2017-03-03 20:27:37 --> Config Class Initialized
INFO - 2017-03-03 20:27:37 --> Loader Class Initialized
INFO - 2017-03-03 20:27:37 --> Helper loaded: form_helper
INFO - 2017-03-03 20:27:37 --> Helper loaded: url_helper
INFO - 2017-03-03 20:27:37 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:27:37 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:27:37 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:27:37 --> Template Class Initialized
INFO - 2017-03-03 20:27:37 --> Model Class Initialized
INFO - 2017-03-03 20:27:37 --> Controller Class Initialized
DEBUG - 2017-03-03 20:27:37 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:27:37 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:27:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:27:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:28:01 --> Config Class Initialized
INFO - 2017-03-03 20:28:01 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:28:01 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:28:01 --> Utf8 Class Initialized
INFO - 2017-03-03 20:28:01 --> URI Class Initialized
INFO - 2017-03-03 20:28:01 --> Router Class Initialized
INFO - 2017-03-03 20:28:01 --> Output Class Initialized
INFO - 2017-03-03 20:28:01 --> Security Class Initialized
DEBUG - 2017-03-03 20:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:28:01 --> Input Class Initialized
INFO - 2017-03-03 20:28:01 --> Language Class Initialized
INFO - 2017-03-03 20:28:01 --> Language Class Initialized
INFO - 2017-03-03 20:28:01 --> Config Class Initialized
INFO - 2017-03-03 20:28:01 --> Loader Class Initialized
INFO - 2017-03-03 20:28:01 --> Helper loaded: form_helper
INFO - 2017-03-03 20:28:01 --> Helper loaded: url_helper
INFO - 2017-03-03 20:28:01 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:28:01 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:28:01 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:28:01 --> Template Class Initialized
INFO - 2017-03-03 20:28:01 --> Model Class Initialized
INFO - 2017-03-03 20:28:01 --> Controller Class Initialized
DEBUG - 2017-03-03 20:28:01 --> Login MX_Controller Initialized
INFO - 2017-03-03 20:28:01 --> Helper loaded: cookie_helper
INFO - 2017-03-03 20:28:01 --> Form Validation Class Initialized
INFO - 2017-03-03 20:28:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-03 20:28:01 --> Config Class Initialized
INFO - 2017-03-03 20:28:01 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:28:01 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:28:01 --> Utf8 Class Initialized
INFO - 2017-03-03 20:28:01 --> URI Class Initialized
INFO - 2017-03-03 20:28:01 --> Router Class Initialized
INFO - 2017-03-03 20:28:01 --> Output Class Initialized
INFO - 2017-03-03 20:28:01 --> Security Class Initialized
DEBUG - 2017-03-03 20:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:28:01 --> Input Class Initialized
INFO - 2017-03-03 20:28:01 --> Language Class Initialized
INFO - 2017-03-03 20:28:01 --> Language Class Initialized
INFO - 2017-03-03 20:28:01 --> Config Class Initialized
INFO - 2017-03-03 20:28:01 --> Loader Class Initialized
INFO - 2017-03-03 20:28:01 --> Helper loaded: form_helper
INFO - 2017-03-03 20:28:01 --> Helper loaded: url_helper
INFO - 2017-03-03 20:28:01 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:28:01 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:28:01 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:28:01 --> Template Class Initialized
INFO - 2017-03-03 20:28:01 --> Model Class Initialized
INFO - 2017-03-03 20:28:01 --> Controller Class Initialized
DEBUG - 2017-03-03 20:28:01 --> Dashboard MX_Controller Initialized
INFO - 2017-03-03 20:28:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:28:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 20:28:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 20:28:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 20:28:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-03 20:28:01 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 20:28:01 --> Final output sent to browser
DEBUG - 2017-03-03 20:28:01 --> Total execution time: 0.0162
INFO - 2017-03-03 20:28:04 --> Config Class Initialized
INFO - 2017-03-03 20:28:04 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:28:04 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:28:04 --> Utf8 Class Initialized
INFO - 2017-03-03 20:28:04 --> URI Class Initialized
INFO - 2017-03-03 20:28:04 --> Router Class Initialized
INFO - 2017-03-03 20:28:04 --> Output Class Initialized
INFO - 2017-03-03 20:28:04 --> Security Class Initialized
DEBUG - 2017-03-03 20:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:28:04 --> Input Class Initialized
INFO - 2017-03-03 20:28:04 --> Language Class Initialized
INFO - 2017-03-03 20:28:04 --> Language Class Initialized
INFO - 2017-03-03 20:28:04 --> Config Class Initialized
INFO - 2017-03-03 20:28:04 --> Loader Class Initialized
INFO - 2017-03-03 20:28:04 --> Helper loaded: form_helper
INFO - 2017-03-03 20:28:04 --> Helper loaded: url_helper
INFO - 2017-03-03 20:28:04 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:28:04 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:28:04 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:28:04 --> Template Class Initialized
INFO - 2017-03-03 20:28:04 --> Model Class Initialized
INFO - 2017-03-03 20:28:04 --> Controller Class Initialized
DEBUG - 2017-03-03 20:28:04 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:28:04 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:28:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:28:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:28:23 --> Config Class Initialized
INFO - 2017-03-03 20:28:23 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:28:23 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:28:23 --> Utf8 Class Initialized
INFO - 2017-03-03 20:28:23 --> URI Class Initialized
INFO - 2017-03-03 20:28:23 --> Router Class Initialized
INFO - 2017-03-03 20:28:23 --> Output Class Initialized
INFO - 2017-03-03 20:28:23 --> Security Class Initialized
DEBUG - 2017-03-03 20:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:28:23 --> Input Class Initialized
INFO - 2017-03-03 20:28:23 --> Language Class Initialized
INFO - 2017-03-03 20:28:23 --> Language Class Initialized
INFO - 2017-03-03 20:28:23 --> Config Class Initialized
INFO - 2017-03-03 20:28:23 --> Loader Class Initialized
INFO - 2017-03-03 20:28:23 --> Helper loaded: form_helper
INFO - 2017-03-03 20:28:23 --> Helper loaded: url_helper
INFO - 2017-03-03 20:28:23 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:28:23 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:28:23 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:28:23 --> Template Class Initialized
INFO - 2017-03-03 20:28:23 --> Model Class Initialized
INFO - 2017-03-03 20:28:23 --> Controller Class Initialized
DEBUG - 2017-03-03 20:28:23 --> Subscriber MX_Controller Initialized
INFO - 2017-03-03 20:28:23 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:28:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 20:28:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 20:28:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 20:28:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/subscriber_list.php
DEBUG - 2017-03-03 20:28:23 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 20:28:23 --> Final output sent to browser
DEBUG - 2017-03-03 20:28:23 --> Total execution time: 0.0314
INFO - 2017-03-03 20:28:24 --> Config Class Initialized
INFO - 2017-03-03 20:28:24 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:28:24 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:28:24 --> Utf8 Class Initialized
INFO - 2017-03-03 20:28:24 --> URI Class Initialized
INFO - 2017-03-03 20:28:24 --> Router Class Initialized
INFO - 2017-03-03 20:28:24 --> Output Class Initialized
INFO - 2017-03-03 20:28:24 --> Security Class Initialized
DEBUG - 2017-03-03 20:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:28:24 --> Input Class Initialized
INFO - 2017-03-03 20:28:24 --> Language Class Initialized
INFO - 2017-03-03 20:28:24 --> Language Class Initialized
INFO - 2017-03-03 20:28:24 --> Config Class Initialized
INFO - 2017-03-03 20:28:24 --> Loader Class Initialized
INFO - 2017-03-03 20:28:24 --> Helper loaded: form_helper
INFO - 2017-03-03 20:28:24 --> Helper loaded: url_helper
INFO - 2017-03-03 20:28:24 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:28:24 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:28:24 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:28:24 --> Template Class Initialized
INFO - 2017-03-03 20:28:24 --> Model Class Initialized
INFO - 2017-03-03 20:28:24 --> Controller Class Initialized
DEBUG - 2017-03-03 20:28:24 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:28:24 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:28:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:28:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:28:27 --> Config Class Initialized
INFO - 2017-03-03 20:28:27 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:28:27 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:28:27 --> Utf8 Class Initialized
INFO - 2017-03-03 20:28:27 --> URI Class Initialized
INFO - 2017-03-03 20:28:27 --> Router Class Initialized
INFO - 2017-03-03 20:28:27 --> Output Class Initialized
INFO - 2017-03-03 20:28:27 --> Security Class Initialized
DEBUG - 2017-03-03 20:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:28:27 --> Input Class Initialized
INFO - 2017-03-03 20:28:27 --> Language Class Initialized
INFO - 2017-03-03 20:28:27 --> Language Class Initialized
INFO - 2017-03-03 20:28:27 --> Config Class Initialized
INFO - 2017-03-03 20:28:27 --> Loader Class Initialized
INFO - 2017-03-03 20:28:27 --> Helper loaded: form_helper
INFO - 2017-03-03 20:28:27 --> Helper loaded: url_helper
INFO - 2017-03-03 20:28:27 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:28:27 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:28:27 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:28:27 --> Template Class Initialized
INFO - 2017-03-03 20:28:27 --> Model Class Initialized
INFO - 2017-03-03 20:28:27 --> Controller Class Initialized
DEBUG - 2017-03-03 20:28:27 --> Project MX_Controller Initialized
INFO - 2017-03-03 20:28:27 --> Helper loaded: cookie_helper
INFO - 2017-03-03 20:28:27 --> Model Class Initialized
DEBUG - 2017-03-03 20:28:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 20:28:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 20:28:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 20:28:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/project_list.php
DEBUG - 2017-03-03 20:28:27 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 20:28:27 --> Final output sent to browser
DEBUG - 2017-03-03 20:28:27 --> Total execution time: 0.0471
INFO - 2017-03-03 20:28:30 --> Config Class Initialized
INFO - 2017-03-03 20:28:30 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:28:30 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:28:30 --> Utf8 Class Initialized
INFO - 2017-03-03 20:28:30 --> URI Class Initialized
INFO - 2017-03-03 20:28:30 --> Router Class Initialized
INFO - 2017-03-03 20:28:30 --> Output Class Initialized
INFO - 2017-03-03 20:28:30 --> Security Class Initialized
DEBUG - 2017-03-03 20:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:28:30 --> Input Class Initialized
INFO - 2017-03-03 20:28:30 --> Language Class Initialized
INFO - 2017-03-03 20:28:30 --> Language Class Initialized
INFO - 2017-03-03 20:28:30 --> Config Class Initialized
INFO - 2017-03-03 20:28:30 --> Loader Class Initialized
INFO - 2017-03-03 20:28:30 --> Helper loaded: form_helper
INFO - 2017-03-03 20:28:30 --> Helper loaded: url_helper
INFO - 2017-03-03 20:28:30 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:28:30 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:28:30 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:28:30 --> Template Class Initialized
INFO - 2017-03-03 20:28:30 --> Model Class Initialized
INFO - 2017-03-03 20:28:30 --> Controller Class Initialized
DEBUG - 2017-03-03 20:28:30 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:28:30 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:28:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:28:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:28:41 --> Config Class Initialized
INFO - 2017-03-03 20:28:41 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:28:41 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:28:41 --> Utf8 Class Initialized
INFO - 2017-03-03 20:28:41 --> URI Class Initialized
INFO - 2017-03-03 20:28:41 --> Router Class Initialized
INFO - 2017-03-03 20:28:41 --> Output Class Initialized
INFO - 2017-03-03 20:28:41 --> Security Class Initialized
DEBUG - 2017-03-03 20:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:28:41 --> Input Class Initialized
INFO - 2017-03-03 20:28:41 --> Language Class Initialized
INFO - 2017-03-03 20:28:41 --> Language Class Initialized
INFO - 2017-03-03 20:28:41 --> Config Class Initialized
INFO - 2017-03-03 20:28:41 --> Loader Class Initialized
INFO - 2017-03-03 20:28:41 --> Helper loaded: form_helper
INFO - 2017-03-03 20:28:41 --> Helper loaded: url_helper
INFO - 2017-03-03 20:28:41 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:28:41 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:28:41 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:28:41 --> Template Class Initialized
INFO - 2017-03-03 20:28:41 --> Model Class Initialized
INFO - 2017-03-03 20:28:41 --> Controller Class Initialized
DEBUG - 2017-03-03 20:28:41 --> Project MX_Controller Initialized
INFO - 2017-03-03 20:28:41 --> Helper loaded: cookie_helper
INFO - 2017-03-03 20:28:41 --> Model Class Initialized
DEBUG - 2017-03-03 20:28:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 20:28:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 20:28:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 20:28:41 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 20:28:41 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 20:28:41 --> Final output sent to browser
DEBUG - 2017-03-03 20:28:41 --> Total execution time: 0.0242
INFO - 2017-03-03 20:28:42 --> Config Class Initialized
INFO - 2017-03-03 20:28:42 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:28:42 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:28:42 --> Utf8 Class Initialized
INFO - 2017-03-03 20:28:42 --> URI Class Initialized
INFO - 2017-03-03 20:28:42 --> Router Class Initialized
INFO - 2017-03-03 20:28:42 --> Output Class Initialized
INFO - 2017-03-03 20:28:42 --> Security Class Initialized
DEBUG - 2017-03-03 20:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:28:42 --> Input Class Initialized
INFO - 2017-03-03 20:28:42 --> Language Class Initialized
INFO - 2017-03-03 20:28:42 --> Language Class Initialized
INFO - 2017-03-03 20:28:42 --> Config Class Initialized
INFO - 2017-03-03 20:28:42 --> Loader Class Initialized
INFO - 2017-03-03 20:28:42 --> Helper loaded: form_helper
INFO - 2017-03-03 20:28:42 --> Helper loaded: url_helper
INFO - 2017-03-03 20:28:42 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:28:42 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:28:42 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:28:42 --> Template Class Initialized
INFO - 2017-03-03 20:28:42 --> Model Class Initialized
INFO - 2017-03-03 20:28:42 --> Controller Class Initialized
DEBUG - 2017-03-03 20:28:42 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:28:42 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:28:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:28:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:28:47 --> Config Class Initialized
INFO - 2017-03-03 20:28:47 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:28:47 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:28:47 --> Utf8 Class Initialized
INFO - 2017-03-03 20:28:47 --> URI Class Initialized
INFO - 2017-03-03 20:28:47 --> Router Class Initialized
INFO - 2017-03-03 20:28:47 --> Output Class Initialized
INFO - 2017-03-03 20:28:47 --> Security Class Initialized
DEBUG - 2017-03-03 20:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:28:47 --> Input Class Initialized
INFO - 2017-03-03 20:28:47 --> Language Class Initialized
INFO - 2017-03-03 20:28:47 --> Language Class Initialized
INFO - 2017-03-03 20:28:47 --> Config Class Initialized
INFO - 2017-03-03 20:28:47 --> Loader Class Initialized
INFO - 2017-03-03 20:28:47 --> Helper loaded: form_helper
INFO - 2017-03-03 20:28:47 --> Helper loaded: url_helper
INFO - 2017-03-03 20:28:47 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:28:47 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:28:47 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:28:47 --> Template Class Initialized
INFO - 2017-03-03 20:28:47 --> Model Class Initialized
INFO - 2017-03-03 20:28:47 --> Controller Class Initialized
DEBUG - 2017-03-03 20:28:47 --> Project MX_Controller Initialized
INFO - 2017-03-03 20:28:47 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:28:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 20:28:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 20:28:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 20:28:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 20:28:47 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 20:28:47 --> Final output sent to browser
DEBUG - 2017-03-03 20:28:47 --> Total execution time: 0.0204
INFO - 2017-03-03 20:28:48 --> Config Class Initialized
INFO - 2017-03-03 20:28:48 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:28:48 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:28:48 --> Utf8 Class Initialized
INFO - 2017-03-03 20:28:48 --> URI Class Initialized
INFO - 2017-03-03 20:28:48 --> Router Class Initialized
INFO - 2017-03-03 20:28:48 --> Output Class Initialized
INFO - 2017-03-03 20:28:48 --> Security Class Initialized
DEBUG - 2017-03-03 20:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:28:48 --> Input Class Initialized
INFO - 2017-03-03 20:28:48 --> Language Class Initialized
INFO - 2017-03-03 20:28:48 --> Language Class Initialized
INFO - 2017-03-03 20:28:48 --> Config Class Initialized
INFO - 2017-03-03 20:28:48 --> Loader Class Initialized
INFO - 2017-03-03 20:28:48 --> Helper loaded: form_helper
INFO - 2017-03-03 20:28:48 --> Helper loaded: url_helper
INFO - 2017-03-03 20:28:48 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:28:48 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:28:48 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:28:48 --> Template Class Initialized
INFO - 2017-03-03 20:28:48 --> Model Class Initialized
INFO - 2017-03-03 20:28:48 --> Controller Class Initialized
DEBUG - 2017-03-03 20:28:48 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:28:48 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:28:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:28:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:29:00 --> Config Class Initialized
INFO - 2017-03-03 20:29:00 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:29:00 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:29:00 --> Utf8 Class Initialized
INFO - 2017-03-03 20:29:00 --> URI Class Initialized
INFO - 2017-03-03 20:29:00 --> Router Class Initialized
INFO - 2017-03-03 20:29:00 --> Output Class Initialized
INFO - 2017-03-03 20:29:00 --> Security Class Initialized
DEBUG - 2017-03-03 20:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:29:00 --> Input Class Initialized
INFO - 2017-03-03 20:29:00 --> Language Class Initialized
INFO - 2017-03-03 20:29:00 --> Language Class Initialized
INFO - 2017-03-03 20:29:00 --> Config Class Initialized
INFO - 2017-03-03 20:29:00 --> Loader Class Initialized
INFO - 2017-03-03 20:29:00 --> Helper loaded: form_helper
INFO - 2017-03-03 20:29:00 --> Helper loaded: url_helper
INFO - 2017-03-03 20:29:00 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:29:00 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:29:00 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:29:00 --> Template Class Initialized
INFO - 2017-03-03 20:29:00 --> Model Class Initialized
INFO - 2017-03-03 20:29:00 --> Controller Class Initialized
DEBUG - 2017-03-03 20:29:00 --> Download_data MX_Controller Initialized
INFO - 2017-03-03 20:29:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:29:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 20:29:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 20:29:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 20:29:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/download_data.php
DEBUG - 2017-03-03 20:29:00 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 20:29:00 --> Final output sent to browser
DEBUG - 2017-03-03 20:29:00 --> Total execution time: 0.0318
INFO - 2017-03-03 20:29:01 --> Config Class Initialized
INFO - 2017-03-03 20:29:01 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:29:01 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:29:01 --> Utf8 Class Initialized
INFO - 2017-03-03 20:29:01 --> URI Class Initialized
INFO - 2017-03-03 20:29:01 --> Router Class Initialized
INFO - 2017-03-03 20:29:01 --> Output Class Initialized
INFO - 2017-03-03 20:29:01 --> Security Class Initialized
DEBUG - 2017-03-03 20:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:29:01 --> Input Class Initialized
INFO - 2017-03-03 20:29:01 --> Language Class Initialized
INFO - 2017-03-03 20:29:01 --> Language Class Initialized
INFO - 2017-03-03 20:29:01 --> Config Class Initialized
INFO - 2017-03-03 20:29:01 --> Loader Class Initialized
INFO - 2017-03-03 20:29:01 --> Helper loaded: form_helper
INFO - 2017-03-03 20:29:01 --> Helper loaded: url_helper
INFO - 2017-03-03 20:29:01 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:29:01 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:29:01 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:29:01 --> Template Class Initialized
INFO - 2017-03-03 20:29:01 --> Model Class Initialized
INFO - 2017-03-03 20:29:01 --> Controller Class Initialized
DEBUG - 2017-03-03 20:29:01 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:29:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:29:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:29:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:29:02 --> Config Class Initialized
INFO - 2017-03-03 20:29:02 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:29:02 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:29:02 --> Utf8 Class Initialized
INFO - 2017-03-03 20:29:02 --> URI Class Initialized
INFO - 2017-03-03 20:29:02 --> Router Class Initialized
INFO - 2017-03-03 20:29:02 --> Output Class Initialized
INFO - 2017-03-03 20:29:02 --> Security Class Initialized
DEBUG - 2017-03-03 20:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:29:02 --> Input Class Initialized
INFO - 2017-03-03 20:29:02 --> Language Class Initialized
INFO - 2017-03-03 20:29:02 --> Language Class Initialized
INFO - 2017-03-03 20:29:02 --> Config Class Initialized
INFO - 2017-03-03 20:29:02 --> Loader Class Initialized
INFO - 2017-03-03 20:29:02 --> Helper loaded: form_helper
INFO - 2017-03-03 20:29:02 --> Helper loaded: url_helper
INFO - 2017-03-03 20:29:02 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:29:02 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:29:02 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:29:02 --> Template Class Initialized
INFO - 2017-03-03 20:29:02 --> Model Class Initialized
INFO - 2017-03-03 20:29:02 --> Controller Class Initialized
DEBUG - 2017-03-03 20:29:02 --> Setting MX_Controller Initialized
INFO - 2017-03-03 20:29:02 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:29:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 20:29:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 20:29:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 20:29:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/sync_with_card.php
DEBUG - 2017-03-03 20:29:02 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 20:29:02 --> Final output sent to browser
DEBUG - 2017-03-03 20:29:02 --> Total execution time: 0.0275
INFO - 2017-03-03 20:29:03 --> Config Class Initialized
INFO - 2017-03-03 20:29:03 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:29:03 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:29:03 --> Utf8 Class Initialized
INFO - 2017-03-03 20:29:03 --> URI Class Initialized
INFO - 2017-03-03 20:29:03 --> Router Class Initialized
INFO - 2017-03-03 20:29:03 --> Output Class Initialized
INFO - 2017-03-03 20:29:03 --> Security Class Initialized
DEBUG - 2017-03-03 20:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:29:03 --> Input Class Initialized
INFO - 2017-03-03 20:29:03 --> Language Class Initialized
INFO - 2017-03-03 20:29:03 --> Language Class Initialized
INFO - 2017-03-03 20:29:03 --> Config Class Initialized
INFO - 2017-03-03 20:29:03 --> Loader Class Initialized
INFO - 2017-03-03 20:29:03 --> Helper loaded: form_helper
INFO - 2017-03-03 20:29:03 --> Helper loaded: url_helper
INFO - 2017-03-03 20:29:03 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:29:03 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:29:03 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:29:03 --> Template Class Initialized
INFO - 2017-03-03 20:29:03 --> Model Class Initialized
INFO - 2017-03-03 20:29:03 --> Controller Class Initialized
DEBUG - 2017-03-03 20:29:03 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:29:03 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:29:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:29:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:29:54 --> Config Class Initialized
INFO - 2017-03-03 20:29:54 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:29:54 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:29:54 --> Utf8 Class Initialized
INFO - 2017-03-03 20:29:54 --> URI Class Initialized
INFO - 2017-03-03 20:29:54 --> Router Class Initialized
INFO - 2017-03-03 20:29:54 --> Output Class Initialized
INFO - 2017-03-03 20:29:54 --> Security Class Initialized
DEBUG - 2017-03-03 20:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:29:54 --> Input Class Initialized
INFO - 2017-03-03 20:29:54 --> Language Class Initialized
INFO - 2017-03-03 20:29:54 --> Language Class Initialized
INFO - 2017-03-03 20:29:54 --> Config Class Initialized
INFO - 2017-03-03 20:29:54 --> Loader Class Initialized
INFO - 2017-03-03 20:29:54 --> Helper loaded: form_helper
INFO - 2017-03-03 20:29:54 --> Helper loaded: url_helper
INFO - 2017-03-03 20:29:54 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:29:54 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:29:54 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:29:54 --> Template Class Initialized
INFO - 2017-03-03 20:29:54 --> Model Class Initialized
INFO - 2017-03-03 20:29:54 --> Controller Class Initialized
DEBUG - 2017-03-03 20:29:54 --> Project MX_Controller Initialized
INFO - 2017-03-03 20:29:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:29:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 20:29:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 20:29:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 20:29:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 20:29:54 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 20:29:54 --> Final output sent to browser
DEBUG - 2017-03-03 20:29:54 --> Total execution time: 0.0128
INFO - 2017-03-03 20:29:55 --> Config Class Initialized
INFO - 2017-03-03 20:29:55 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:29:55 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:29:55 --> Utf8 Class Initialized
INFO - 2017-03-03 20:29:55 --> URI Class Initialized
INFO - 2017-03-03 20:29:55 --> Router Class Initialized
INFO - 2017-03-03 20:29:55 --> Output Class Initialized
INFO - 2017-03-03 20:29:55 --> Security Class Initialized
DEBUG - 2017-03-03 20:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:29:55 --> Input Class Initialized
INFO - 2017-03-03 20:29:55 --> Language Class Initialized
INFO - 2017-03-03 20:29:55 --> Language Class Initialized
INFO - 2017-03-03 20:29:55 --> Config Class Initialized
INFO - 2017-03-03 20:29:55 --> Loader Class Initialized
INFO - 2017-03-03 20:29:55 --> Helper loaded: form_helper
INFO - 2017-03-03 20:29:55 --> Helper loaded: url_helper
INFO - 2017-03-03 20:29:55 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:29:56 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:29:56 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:29:56 --> Template Class Initialized
INFO - 2017-03-03 20:29:56 --> Model Class Initialized
INFO - 2017-03-03 20:29:56 --> Controller Class Initialized
DEBUG - 2017-03-03 20:29:56 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:29:56 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:29:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:29:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:29:59 --> Config Class Initialized
INFO - 2017-03-03 20:29:59 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:29:59 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:29:59 --> Utf8 Class Initialized
INFO - 2017-03-03 20:29:59 --> URI Class Initialized
INFO - 2017-03-03 20:29:59 --> Router Class Initialized
INFO - 2017-03-03 20:29:59 --> Output Class Initialized
INFO - 2017-03-03 20:29:59 --> Security Class Initialized
DEBUG - 2017-03-03 20:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:29:59 --> Input Class Initialized
INFO - 2017-03-03 20:29:59 --> Language Class Initialized
INFO - 2017-03-03 20:29:59 --> Language Class Initialized
INFO - 2017-03-03 20:29:59 --> Config Class Initialized
INFO - 2017-03-03 20:29:59 --> Loader Class Initialized
INFO - 2017-03-03 20:29:59 --> Helper loaded: form_helper
INFO - 2017-03-03 20:29:59 --> Helper loaded: url_helper
INFO - 2017-03-03 20:29:59 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:29:59 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:29:59 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:29:59 --> Template Class Initialized
INFO - 2017-03-03 20:29:59 --> Model Class Initialized
INFO - 2017-03-03 20:29:59 --> Controller Class Initialized
DEBUG - 2017-03-03 20:29:59 --> Download_data MX_Controller Initialized
INFO - 2017-03-03 20:29:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:29:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 20:29:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 20:29:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 20:29:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/download_data.php
DEBUG - 2017-03-03 20:29:59 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 20:29:59 --> Final output sent to browser
DEBUG - 2017-03-03 20:29:59 --> Total execution time: 0.0142
INFO - 2017-03-03 20:30:00 --> Config Class Initialized
INFO - 2017-03-03 20:30:00 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:30:00 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:30:00 --> Utf8 Class Initialized
INFO - 2017-03-03 20:30:00 --> URI Class Initialized
INFO - 2017-03-03 20:30:00 --> Router Class Initialized
INFO - 2017-03-03 20:30:00 --> Output Class Initialized
INFO - 2017-03-03 20:30:00 --> Security Class Initialized
DEBUG - 2017-03-03 20:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:30:00 --> Input Class Initialized
INFO - 2017-03-03 20:30:00 --> Language Class Initialized
INFO - 2017-03-03 20:30:00 --> Language Class Initialized
INFO - 2017-03-03 20:30:00 --> Config Class Initialized
INFO - 2017-03-03 20:30:00 --> Loader Class Initialized
INFO - 2017-03-03 20:30:00 --> Helper loaded: form_helper
INFO - 2017-03-03 20:30:00 --> Helper loaded: url_helper
INFO - 2017-03-03 20:30:00 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:30:00 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:30:00 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:30:00 --> Template Class Initialized
INFO - 2017-03-03 20:30:00 --> Model Class Initialized
INFO - 2017-03-03 20:30:00 --> Controller Class Initialized
DEBUG - 2017-03-03 20:30:00 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:30:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:30:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:30:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:30:10 --> Config Class Initialized
INFO - 2017-03-03 20:30:10 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:30:10 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:30:10 --> Utf8 Class Initialized
INFO - 2017-03-03 20:30:10 --> URI Class Initialized
INFO - 2017-03-03 20:30:10 --> Router Class Initialized
INFO - 2017-03-03 20:30:10 --> Output Class Initialized
INFO - 2017-03-03 20:30:10 --> Security Class Initialized
DEBUG - 2017-03-03 20:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:30:10 --> Input Class Initialized
INFO - 2017-03-03 20:30:10 --> Language Class Initialized
INFO - 2017-03-03 20:30:10 --> Language Class Initialized
INFO - 2017-03-03 20:30:10 --> Config Class Initialized
INFO - 2017-03-03 20:30:10 --> Loader Class Initialized
INFO - 2017-03-03 20:30:10 --> Helper loaded: form_helper
INFO - 2017-03-03 20:30:10 --> Helper loaded: url_helper
INFO - 2017-03-03 20:30:10 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:30:10 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:30:10 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:30:10 --> Template Class Initialized
INFO - 2017-03-03 20:30:10 --> Model Class Initialized
INFO - 2017-03-03 20:30:10 --> Controller Class Initialized
DEBUG - 2017-03-03 20:30:10 --> Dashboard MX_Controller Initialized
INFO - 2017-03-03 20:30:10 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:30:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 20:30:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 20:30:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 20:30:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-03 20:30:10 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 20:30:10 --> Final output sent to browser
DEBUG - 2017-03-03 20:30:10 --> Total execution time: 0.0150
INFO - 2017-03-03 20:30:12 --> Config Class Initialized
INFO - 2017-03-03 20:30:12 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:30:12 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:30:12 --> Utf8 Class Initialized
INFO - 2017-03-03 20:30:12 --> URI Class Initialized
INFO - 2017-03-03 20:30:12 --> Router Class Initialized
INFO - 2017-03-03 20:30:12 --> Output Class Initialized
INFO - 2017-03-03 20:30:12 --> Security Class Initialized
DEBUG - 2017-03-03 20:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:30:12 --> Input Class Initialized
INFO - 2017-03-03 20:30:12 --> Language Class Initialized
INFO - 2017-03-03 20:30:12 --> Language Class Initialized
INFO - 2017-03-03 20:30:12 --> Config Class Initialized
INFO - 2017-03-03 20:30:12 --> Loader Class Initialized
INFO - 2017-03-03 20:30:12 --> Helper loaded: form_helper
INFO - 2017-03-03 20:30:12 --> Helper loaded: url_helper
INFO - 2017-03-03 20:30:12 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:30:12 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:30:12 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:30:12 --> Template Class Initialized
INFO - 2017-03-03 20:30:12 --> Model Class Initialized
INFO - 2017-03-03 20:30:12 --> Controller Class Initialized
DEBUG - 2017-03-03 20:30:12 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:30:12 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:30:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:30:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:30:29 --> Config Class Initialized
INFO - 2017-03-03 20:30:29 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:30:29 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:30:29 --> Utf8 Class Initialized
INFO - 2017-03-03 20:30:29 --> URI Class Initialized
INFO - 2017-03-03 20:30:29 --> Router Class Initialized
INFO - 2017-03-03 20:30:29 --> Output Class Initialized
INFO - 2017-03-03 20:30:29 --> Security Class Initialized
DEBUG - 2017-03-03 20:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:30:29 --> Input Class Initialized
INFO - 2017-03-03 20:30:29 --> Language Class Initialized
INFO - 2017-03-03 20:30:29 --> Language Class Initialized
INFO - 2017-03-03 20:30:29 --> Config Class Initialized
INFO - 2017-03-03 20:30:29 --> Loader Class Initialized
INFO - 2017-03-03 20:30:29 --> Helper loaded: form_helper
INFO - 2017-03-03 20:30:29 --> Helper loaded: url_helper
INFO - 2017-03-03 20:30:29 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:30:29 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:30:29 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:30:29 --> Template Class Initialized
INFO - 2017-03-03 20:30:29 --> Model Class Initialized
INFO - 2017-03-03 20:30:29 --> Controller Class Initialized
DEBUG - 2017-03-03 20:30:29 --> Project MX_Controller Initialized
INFO - 2017-03-03 20:30:29 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:30:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 20:30:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 20:30:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 20:30:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-03 20:30:29 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 20:30:29 --> Final output sent to browser
DEBUG - 2017-03-03 20:30:29 --> Total execution time: 0.0151
INFO - 2017-03-03 20:30:30 --> Config Class Initialized
INFO - 2017-03-03 20:30:30 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:30:30 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:30:30 --> Utf8 Class Initialized
INFO - 2017-03-03 20:30:30 --> URI Class Initialized
INFO - 2017-03-03 20:30:30 --> Router Class Initialized
INFO - 2017-03-03 20:30:30 --> Output Class Initialized
INFO - 2017-03-03 20:30:30 --> Security Class Initialized
DEBUG - 2017-03-03 20:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:30:30 --> Input Class Initialized
INFO - 2017-03-03 20:30:30 --> Language Class Initialized
INFO - 2017-03-03 20:30:30 --> Language Class Initialized
INFO - 2017-03-03 20:30:30 --> Config Class Initialized
INFO - 2017-03-03 20:30:30 --> Loader Class Initialized
INFO - 2017-03-03 20:30:30 --> Helper loaded: form_helper
INFO - 2017-03-03 20:30:30 --> Helper loaded: url_helper
INFO - 2017-03-03 20:30:30 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:30:30 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:30:30 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:30:30 --> Template Class Initialized
INFO - 2017-03-03 20:30:30 --> Model Class Initialized
INFO - 2017-03-03 20:30:30 --> Controller Class Initialized
DEBUG - 2017-03-03 20:30:30 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:30:30 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:30:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:30:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:30:32 --> Config Class Initialized
INFO - 2017-03-03 20:30:32 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:30:32 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:30:32 --> Utf8 Class Initialized
INFO - 2017-03-03 20:30:32 --> URI Class Initialized
INFO - 2017-03-03 20:30:32 --> Router Class Initialized
INFO - 2017-03-03 20:30:32 --> Output Class Initialized
INFO - 2017-03-03 20:30:32 --> Security Class Initialized
DEBUG - 2017-03-03 20:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:30:32 --> Input Class Initialized
INFO - 2017-03-03 20:30:32 --> Language Class Initialized
INFO - 2017-03-03 20:30:32 --> Language Class Initialized
INFO - 2017-03-03 20:30:32 --> Config Class Initialized
INFO - 2017-03-03 20:30:32 --> Loader Class Initialized
INFO - 2017-03-03 20:30:32 --> Helper loaded: form_helper
INFO - 2017-03-03 20:30:32 --> Helper loaded: url_helper
INFO - 2017-03-03 20:30:32 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:30:32 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:30:32 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:30:32 --> Template Class Initialized
INFO - 2017-03-03 20:30:32 --> Model Class Initialized
INFO - 2017-03-03 20:30:32 --> Controller Class Initialized
DEBUG - 2017-03-03 20:30:32 --> Project MX_Controller Initialized
INFO - 2017-03-03 20:30:32 --> Helper loaded: cookie_helper
INFO - 2017-03-03 20:30:32 --> Model Class Initialized
DEBUG - 2017-03-03 20:30:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 20:30:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 20:30:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 20:30:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 20:30:32 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 20:30:32 --> Final output sent to browser
DEBUG - 2017-03-03 20:30:32 --> Total execution time: 0.0171
INFO - 2017-03-03 20:30:32 --> Config Class Initialized
INFO - 2017-03-03 20:30:32 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:30:32 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:30:32 --> Utf8 Class Initialized
INFO - 2017-03-03 20:30:32 --> URI Class Initialized
INFO - 2017-03-03 20:30:32 --> Router Class Initialized
INFO - 2017-03-03 20:30:32 --> Output Class Initialized
INFO - 2017-03-03 20:30:32 --> Security Class Initialized
DEBUG - 2017-03-03 20:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:30:32 --> Input Class Initialized
INFO - 2017-03-03 20:30:32 --> Language Class Initialized
INFO - 2017-03-03 20:30:32 --> Language Class Initialized
INFO - 2017-03-03 20:30:32 --> Config Class Initialized
INFO - 2017-03-03 20:30:32 --> Loader Class Initialized
INFO - 2017-03-03 20:30:33 --> Helper loaded: form_helper
INFO - 2017-03-03 20:30:33 --> Helper loaded: url_helper
INFO - 2017-03-03 20:30:33 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:30:33 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:30:33 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:30:33 --> Template Class Initialized
INFO - 2017-03-03 20:30:33 --> Model Class Initialized
INFO - 2017-03-03 20:30:33 --> Controller Class Initialized
DEBUG - 2017-03-03 20:30:33 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:30:33 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:30:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:30:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:30:35 --> Config Class Initialized
INFO - 2017-03-03 20:30:35 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:30:35 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:30:35 --> Utf8 Class Initialized
INFO - 2017-03-03 20:30:35 --> URI Class Initialized
INFO - 2017-03-03 20:30:35 --> Router Class Initialized
INFO - 2017-03-03 20:30:35 --> Output Class Initialized
INFO - 2017-03-03 20:30:35 --> Security Class Initialized
DEBUG - 2017-03-03 20:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:30:35 --> Input Class Initialized
INFO - 2017-03-03 20:30:35 --> Language Class Initialized
INFO - 2017-03-03 20:30:35 --> Language Class Initialized
INFO - 2017-03-03 20:30:35 --> Config Class Initialized
INFO - 2017-03-03 20:30:35 --> Loader Class Initialized
INFO - 2017-03-03 20:30:35 --> Helper loaded: form_helper
INFO - 2017-03-03 20:30:35 --> Helper loaded: url_helper
INFO - 2017-03-03 20:30:35 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:30:35 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:30:35 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:30:35 --> Template Class Initialized
INFO - 2017-03-03 20:30:35 --> Model Class Initialized
INFO - 2017-03-03 20:30:35 --> Controller Class Initialized
DEBUG - 2017-03-03 20:30:35 --> Project MX_Controller Initialized
INFO - 2017-03-03 20:30:35 --> Helper loaded: cookie_helper
INFO - 2017-03-03 20:30:35 --> Final output sent to browser
DEBUG - 2017-03-03 20:30:35 --> Total execution time: 0.0128
INFO - 2017-03-03 20:32:30 --> Config Class Initialized
INFO - 2017-03-03 20:32:30 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:32:30 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:32:30 --> Utf8 Class Initialized
INFO - 2017-03-03 20:32:30 --> URI Class Initialized
INFO - 2017-03-03 20:32:30 --> Router Class Initialized
INFO - 2017-03-03 20:32:30 --> Output Class Initialized
INFO - 2017-03-03 20:32:30 --> Security Class Initialized
DEBUG - 2017-03-03 20:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:32:30 --> Input Class Initialized
INFO - 2017-03-03 20:32:30 --> Language Class Initialized
INFO - 2017-03-03 20:32:30 --> Language Class Initialized
INFO - 2017-03-03 20:32:30 --> Config Class Initialized
INFO - 2017-03-03 20:32:30 --> Loader Class Initialized
INFO - 2017-03-03 20:32:30 --> Helper loaded: form_helper
INFO - 2017-03-03 20:32:30 --> Helper loaded: url_helper
INFO - 2017-03-03 20:32:30 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:32:30 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:32:30 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:32:30 --> Template Class Initialized
INFO - 2017-03-03 20:32:30 --> Model Class Initialized
INFO - 2017-03-03 20:32:30 --> Controller Class Initialized
DEBUG - 2017-03-03 20:32:30 --> Project MX_Controller Initialized
INFO - 2017-03-03 20:32:30 --> Helper loaded: cookie_helper
INFO - 2017-03-03 20:32:30 --> Upload Class Initialized
INFO - 2017-03-03 20:32:30 --> Model Class Initialized
INFO - 2017-03-03 20:32:30 --> Final output sent to browser
DEBUG - 2017-03-03 20:32:30 --> Total execution time: 0.0407
INFO - 2017-03-03 20:32:47 --> Config Class Initialized
INFO - 2017-03-03 20:32:47 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:32:47 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:32:47 --> Utf8 Class Initialized
INFO - 2017-03-03 20:32:47 --> URI Class Initialized
INFO - 2017-03-03 20:32:47 --> Router Class Initialized
INFO - 2017-03-03 20:32:47 --> Output Class Initialized
INFO - 2017-03-03 20:32:47 --> Security Class Initialized
DEBUG - 2017-03-03 20:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:32:47 --> Input Class Initialized
INFO - 2017-03-03 20:32:47 --> Language Class Initialized
INFO - 2017-03-03 20:32:47 --> Language Class Initialized
INFO - 2017-03-03 20:32:47 --> Config Class Initialized
INFO - 2017-03-03 20:32:47 --> Loader Class Initialized
INFO - 2017-03-03 20:32:47 --> Helper loaded: form_helper
INFO - 2017-03-03 20:32:47 --> Helper loaded: url_helper
INFO - 2017-03-03 20:32:47 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:32:47 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:32:47 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:32:47 --> Template Class Initialized
INFO - 2017-03-03 20:32:47 --> Model Class Initialized
INFO - 2017-03-03 20:32:47 --> Controller Class Initialized
DEBUG - 2017-03-03 20:32:47 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:32:47 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:32:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:32:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:32:51 --> Config Class Initialized
INFO - 2017-03-03 20:32:51 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:32:51 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:32:51 --> Utf8 Class Initialized
INFO - 2017-03-03 20:32:51 --> URI Class Initialized
INFO - 2017-03-03 20:32:51 --> Router Class Initialized
INFO - 2017-03-03 20:32:51 --> Output Class Initialized
INFO - 2017-03-03 20:32:51 --> Security Class Initialized
DEBUG - 2017-03-03 20:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:32:51 --> Input Class Initialized
INFO - 2017-03-03 20:32:51 --> Language Class Initialized
INFO - 2017-03-03 20:32:51 --> Language Class Initialized
INFO - 2017-03-03 20:32:51 --> Config Class Initialized
INFO - 2017-03-03 20:32:51 --> Loader Class Initialized
INFO - 2017-03-03 20:32:51 --> Helper loaded: form_helper
INFO - 2017-03-03 20:32:51 --> Helper loaded: url_helper
INFO - 2017-03-03 20:32:51 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:32:51 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:32:51 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:32:51 --> Template Class Initialized
INFO - 2017-03-03 20:32:51 --> Model Class Initialized
INFO - 2017-03-03 20:32:51 --> Controller Class Initialized
DEBUG - 2017-03-03 20:32:51 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:32:51 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:32:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:32:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:32:56 --> Config Class Initialized
INFO - 2017-03-03 20:32:56 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:32:56 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:32:56 --> Utf8 Class Initialized
INFO - 2017-03-03 20:32:56 --> URI Class Initialized
INFO - 2017-03-03 20:32:56 --> Router Class Initialized
INFO - 2017-03-03 20:32:56 --> Output Class Initialized
INFO - 2017-03-03 20:32:56 --> Security Class Initialized
DEBUG - 2017-03-03 20:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:32:56 --> Input Class Initialized
INFO - 2017-03-03 20:32:56 --> Language Class Initialized
INFO - 2017-03-03 20:32:56 --> Language Class Initialized
INFO - 2017-03-03 20:32:56 --> Config Class Initialized
INFO - 2017-03-03 20:32:56 --> Loader Class Initialized
INFO - 2017-03-03 20:32:56 --> Helper loaded: form_helper
INFO - 2017-03-03 20:32:56 --> Helper loaded: url_helper
INFO - 2017-03-03 20:32:56 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:32:56 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:32:56 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:32:56 --> Template Class Initialized
INFO - 2017-03-03 20:32:56 --> Model Class Initialized
INFO - 2017-03-03 20:32:56 --> Controller Class Initialized
DEBUG - 2017-03-03 20:32:56 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:32:56 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:32:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:32:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:32:58 --> Config Class Initialized
INFO - 2017-03-03 20:32:58 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:32:58 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:32:58 --> Utf8 Class Initialized
INFO - 2017-03-03 20:32:58 --> URI Class Initialized
INFO - 2017-03-03 20:32:58 --> Router Class Initialized
INFO - 2017-03-03 20:32:58 --> Output Class Initialized
INFO - 2017-03-03 20:32:58 --> Security Class Initialized
DEBUG - 2017-03-03 20:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:32:58 --> Input Class Initialized
INFO - 2017-03-03 20:32:58 --> Language Class Initialized
INFO - 2017-03-03 20:32:58 --> Language Class Initialized
INFO - 2017-03-03 20:32:58 --> Config Class Initialized
INFO - 2017-03-03 20:32:58 --> Loader Class Initialized
INFO - 2017-03-03 20:32:58 --> Helper loaded: form_helper
INFO - 2017-03-03 20:32:58 --> Helper loaded: url_helper
INFO - 2017-03-03 20:32:58 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:32:58 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:32:58 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:32:58 --> Template Class Initialized
INFO - 2017-03-03 20:32:58 --> Model Class Initialized
INFO - 2017-03-03 20:32:58 --> Controller Class Initialized
DEBUG - 2017-03-03 20:32:58 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:32:58 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:32:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:32:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:33:00 --> Config Class Initialized
INFO - 2017-03-03 20:33:00 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:33:00 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:33:00 --> Utf8 Class Initialized
INFO - 2017-03-03 20:33:00 --> URI Class Initialized
INFO - 2017-03-03 20:33:00 --> Router Class Initialized
INFO - 2017-03-03 20:33:00 --> Output Class Initialized
INFO - 2017-03-03 20:33:00 --> Security Class Initialized
DEBUG - 2017-03-03 20:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:33:00 --> Input Class Initialized
INFO - 2017-03-03 20:33:00 --> Language Class Initialized
INFO - 2017-03-03 20:33:00 --> Language Class Initialized
INFO - 2017-03-03 20:33:00 --> Config Class Initialized
INFO - 2017-03-03 20:33:00 --> Loader Class Initialized
INFO - 2017-03-03 20:33:00 --> Helper loaded: form_helper
INFO - 2017-03-03 20:33:00 --> Helper loaded: url_helper
INFO - 2017-03-03 20:33:00 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:33:00 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:33:00 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:33:00 --> Template Class Initialized
INFO - 2017-03-03 20:33:00 --> Model Class Initialized
INFO - 2017-03-03 20:33:00 --> Controller Class Initialized
DEBUG - 2017-03-03 20:33:00 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:33:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:33:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:33:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:33:08 --> Config Class Initialized
INFO - 2017-03-03 20:33:08 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:33:08 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:33:08 --> Utf8 Class Initialized
INFO - 2017-03-03 20:33:08 --> URI Class Initialized
INFO - 2017-03-03 20:33:08 --> Router Class Initialized
INFO - 2017-03-03 20:33:08 --> Output Class Initialized
INFO - 2017-03-03 20:33:08 --> Security Class Initialized
DEBUG - 2017-03-03 20:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:33:08 --> Input Class Initialized
INFO - 2017-03-03 20:33:08 --> Language Class Initialized
INFO - 2017-03-03 20:33:08 --> Language Class Initialized
INFO - 2017-03-03 20:33:08 --> Config Class Initialized
INFO - 2017-03-03 20:33:08 --> Loader Class Initialized
INFO - 2017-03-03 20:33:08 --> Helper loaded: form_helper
INFO - 2017-03-03 20:33:08 --> Helper loaded: url_helper
INFO - 2017-03-03 20:33:08 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:33:08 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:33:08 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:33:08 --> Template Class Initialized
INFO - 2017-03-03 20:33:08 --> Model Class Initialized
INFO - 2017-03-03 20:33:08 --> Controller Class Initialized
DEBUG - 2017-03-03 20:33:08 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:33:08 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:33:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:33:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:33:13 --> Config Class Initialized
INFO - 2017-03-03 20:33:13 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:33:13 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:33:13 --> Utf8 Class Initialized
INFO - 2017-03-03 20:33:13 --> URI Class Initialized
INFO - 2017-03-03 20:33:13 --> Router Class Initialized
INFO - 2017-03-03 20:33:13 --> Output Class Initialized
INFO - 2017-03-03 20:33:13 --> Security Class Initialized
DEBUG - 2017-03-03 20:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:33:13 --> Input Class Initialized
INFO - 2017-03-03 20:33:13 --> Language Class Initialized
INFO - 2017-03-03 20:33:13 --> Language Class Initialized
INFO - 2017-03-03 20:33:13 --> Config Class Initialized
INFO - 2017-03-03 20:33:13 --> Loader Class Initialized
INFO - 2017-03-03 20:33:13 --> Helper loaded: form_helper
INFO - 2017-03-03 20:33:13 --> Helper loaded: url_helper
INFO - 2017-03-03 20:33:13 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:33:13 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:33:13 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:33:13 --> Template Class Initialized
INFO - 2017-03-03 20:33:13 --> Model Class Initialized
INFO - 2017-03-03 20:33:13 --> Controller Class Initialized
DEBUG - 2017-03-03 20:33:13 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:33:13 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:33:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:33:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:33:19 --> Config Class Initialized
INFO - 2017-03-03 20:33:19 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:33:19 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:33:19 --> Utf8 Class Initialized
INFO - 2017-03-03 20:33:19 --> URI Class Initialized
INFO - 2017-03-03 20:33:19 --> Router Class Initialized
INFO - 2017-03-03 20:33:19 --> Output Class Initialized
INFO - 2017-03-03 20:33:19 --> Security Class Initialized
DEBUG - 2017-03-03 20:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:33:19 --> Input Class Initialized
INFO - 2017-03-03 20:33:19 --> Language Class Initialized
INFO - 2017-03-03 20:33:19 --> Language Class Initialized
INFO - 2017-03-03 20:33:19 --> Config Class Initialized
INFO - 2017-03-03 20:33:19 --> Loader Class Initialized
INFO - 2017-03-03 20:33:19 --> Helper loaded: form_helper
INFO - 2017-03-03 20:33:19 --> Helper loaded: url_helper
INFO - 2017-03-03 20:33:19 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:33:19 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:33:19 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:33:19 --> Template Class Initialized
INFO - 2017-03-03 20:33:19 --> Model Class Initialized
INFO - 2017-03-03 20:33:19 --> Controller Class Initialized
DEBUG - 2017-03-03 20:33:19 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:33:19 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:33:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:33:19 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:33:20 --> Config Class Initialized
INFO - 2017-03-03 20:33:20 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:33:20 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:33:20 --> Utf8 Class Initialized
INFO - 2017-03-03 20:33:20 --> URI Class Initialized
INFO - 2017-03-03 20:33:20 --> Router Class Initialized
INFO - 2017-03-03 20:33:20 --> Output Class Initialized
INFO - 2017-03-03 20:33:20 --> Security Class Initialized
DEBUG - 2017-03-03 20:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:33:20 --> Input Class Initialized
INFO - 2017-03-03 20:33:20 --> Language Class Initialized
INFO - 2017-03-03 20:33:20 --> Language Class Initialized
INFO - 2017-03-03 20:33:20 --> Config Class Initialized
INFO - 2017-03-03 20:33:20 --> Loader Class Initialized
INFO - 2017-03-03 20:33:20 --> Helper loaded: form_helper
INFO - 2017-03-03 20:33:20 --> Helper loaded: url_helper
INFO - 2017-03-03 20:33:20 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:33:20 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:33:20 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:33:20 --> Template Class Initialized
INFO - 2017-03-03 20:33:20 --> Model Class Initialized
INFO - 2017-03-03 20:33:20 --> Controller Class Initialized
DEBUG - 2017-03-03 20:33:20 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:33:20 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:33:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:33:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:33:22 --> Config Class Initialized
INFO - 2017-03-03 20:33:22 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:33:22 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:33:22 --> Utf8 Class Initialized
INFO - 2017-03-03 20:33:22 --> URI Class Initialized
INFO - 2017-03-03 20:33:22 --> Router Class Initialized
INFO - 2017-03-03 20:33:22 --> Output Class Initialized
INFO - 2017-03-03 20:33:22 --> Security Class Initialized
DEBUG - 2017-03-03 20:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:33:22 --> Input Class Initialized
INFO - 2017-03-03 20:33:22 --> Language Class Initialized
INFO - 2017-03-03 20:33:22 --> Language Class Initialized
INFO - 2017-03-03 20:33:22 --> Config Class Initialized
INFO - 2017-03-03 20:33:22 --> Loader Class Initialized
INFO - 2017-03-03 20:33:22 --> Helper loaded: form_helper
INFO - 2017-03-03 20:33:22 --> Helper loaded: url_helper
INFO - 2017-03-03 20:33:22 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:33:22 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:33:22 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:33:22 --> Template Class Initialized
INFO - 2017-03-03 20:33:22 --> Model Class Initialized
INFO - 2017-03-03 20:33:22 --> Controller Class Initialized
DEBUG - 2017-03-03 20:33:22 --> Project MX_Controller Initialized
INFO - 2017-03-03 20:33:22 --> Helper loaded: cookie_helper
INFO - 2017-03-03 20:33:22 --> Model Class Initialized
DEBUG - 2017-03-03 20:33:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-03 20:33:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-03 20:33:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-03 20:33:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-03 20:33:22 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-03 20:33:22 --> Final output sent to browser
DEBUG - 2017-03-03 20:33:22 --> Total execution time: 0.0126
INFO - 2017-03-03 20:33:23 --> Config Class Initialized
INFO - 2017-03-03 20:33:23 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:33:23 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:33:23 --> Utf8 Class Initialized
INFO - 2017-03-03 20:33:23 --> URI Class Initialized
INFO - 2017-03-03 20:33:23 --> Router Class Initialized
INFO - 2017-03-03 20:33:23 --> Output Class Initialized
INFO - 2017-03-03 20:33:23 --> Security Class Initialized
DEBUG - 2017-03-03 20:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:33:23 --> Input Class Initialized
INFO - 2017-03-03 20:33:23 --> Language Class Initialized
INFO - 2017-03-03 20:33:23 --> Language Class Initialized
INFO - 2017-03-03 20:33:23 --> Config Class Initialized
INFO - 2017-03-03 20:33:23 --> Loader Class Initialized
INFO - 2017-03-03 20:33:23 --> Helper loaded: form_helper
INFO - 2017-03-03 20:33:23 --> Helper loaded: url_helper
INFO - 2017-03-03 20:33:23 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:33:23 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:33:23 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:33:23 --> Template Class Initialized
INFO - 2017-03-03 20:33:23 --> Model Class Initialized
INFO - 2017-03-03 20:33:23 --> Controller Class Initialized
DEBUG - 2017-03-03 20:33:23 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:33:23 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:33:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:33:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-03 20:40:53 --> Config Class Initialized
INFO - 2017-03-03 20:40:53 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:40:53 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:40:53 --> Utf8 Class Initialized
INFO - 2017-03-03 20:40:53 --> URI Class Initialized
INFO - 2017-03-03 20:40:53 --> Router Class Initialized
INFO - 2017-03-03 20:40:53 --> Output Class Initialized
INFO - 2017-03-03 20:40:53 --> Security Class Initialized
DEBUG - 2017-03-03 20:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:40:53 --> Input Class Initialized
INFO - 2017-03-03 20:40:53 --> Language Class Initialized
INFO - 2017-03-03 20:40:53 --> Language Class Initialized
INFO - 2017-03-03 20:40:53 --> Config Class Initialized
INFO - 2017-03-03 20:40:53 --> Loader Class Initialized
INFO - 2017-03-03 20:40:53 --> Helper loaded: form_helper
INFO - 2017-03-03 20:40:53 --> Helper loaded: url_helper
INFO - 2017-03-03 20:40:53 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:40:53 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:40:53 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:40:53 --> Template Class Initialized
INFO - 2017-03-03 20:40:53 --> Model Class Initialized
INFO - 2017-03-03 20:40:53 --> Controller Class Initialized
DEBUG - 2017-03-03 20:40:53 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:40:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:40:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:40:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-03 20:40:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-03 20:40:53 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-03 20:40:53 --> Final output sent to browser
DEBUG - 2017-03-03 20:40:53 --> Total execution time: 0.0523
INFO - 2017-03-03 20:40:54 --> Config Class Initialized
INFO - 2017-03-03 20:40:54 --> Hooks Class Initialized
DEBUG - 2017-03-03 20:40:54 --> UTF-8 Support Enabled
INFO - 2017-03-03 20:40:54 --> Utf8 Class Initialized
INFO - 2017-03-03 20:40:54 --> URI Class Initialized
INFO - 2017-03-03 20:40:54 --> Router Class Initialized
INFO - 2017-03-03 20:40:54 --> Output Class Initialized
INFO - 2017-03-03 20:40:54 --> Security Class Initialized
DEBUG - 2017-03-03 20:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-03 20:40:54 --> Input Class Initialized
INFO - 2017-03-03 20:40:54 --> Language Class Initialized
INFO - 2017-03-03 20:40:54 --> Language Class Initialized
INFO - 2017-03-03 20:40:54 --> Config Class Initialized
INFO - 2017-03-03 20:40:54 --> Loader Class Initialized
INFO - 2017-03-03 20:40:54 --> Helper loaded: form_helper
INFO - 2017-03-03 20:40:54 --> Helper loaded: url_helper
INFO - 2017-03-03 20:40:54 --> Helper loaded: utility_helper
INFO - 2017-03-03 20:40:54 --> Database Driver Class Initialized
DEBUG - 2017-03-03 20:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-03 20:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-03 20:40:54 --> User Agent Class Initialized
DEBUG - 2017-03-03 20:40:54 --> Template Class Initialized
INFO - 2017-03-03 20:40:54 --> Model Class Initialized
INFO - 2017-03-03 20:40:54 --> Controller Class Initialized
DEBUG - 2017-03-03 20:40:54 --> Pages MX_Controller Initialized
INFO - 2017-03-03 20:40:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-03 20:40:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-03 20:40:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
