<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-05 03:09:03 --> Config Class Initialized
INFO - 2017-03-05 03:09:03 --> Hooks Class Initialized
DEBUG - 2017-03-05 03:09:03 --> UTF-8 Support Enabled
INFO - 2017-03-05 03:09:03 --> Utf8 Class Initialized
INFO - 2017-03-05 03:09:03 --> URI Class Initialized
INFO - 2017-03-05 03:09:03 --> Router Class Initialized
INFO - 2017-03-05 03:09:03 --> Output Class Initialized
INFO - 2017-03-05 03:09:03 --> Security Class Initialized
DEBUG - 2017-03-05 03:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 03:09:03 --> Input Class Initialized
INFO - 2017-03-05 03:09:03 --> Language Class Initialized
INFO - 2017-03-05 03:09:03 --> Language Class Initialized
INFO - 2017-03-05 03:09:03 --> Config Class Initialized
INFO - 2017-03-05 03:09:03 --> Loader Class Initialized
INFO - 2017-03-05 03:09:03 --> Helper loaded: form_helper
INFO - 2017-03-05 03:09:03 --> Helper loaded: url_helper
INFO - 2017-03-05 03:09:03 --> Helper loaded: utility_helper
INFO - 2017-03-05 03:09:03 --> Database Driver Class Initialized
DEBUG - 2017-03-05 03:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 03:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 03:09:04 --> User Agent Class Initialized
DEBUG - 2017-03-05 03:09:04 --> Template Class Initialized
INFO - 2017-03-05 03:09:04 --> Model Class Initialized
INFO - 2017-03-05 03:09:04 --> Controller Class Initialized
DEBUG - 2017-03-05 03:09:04 --> Pages MX_Controller Initialized
INFO - 2017-03-05 03:09:04 --> Helper loaded: cookie_helper
DEBUG - 2017-03-05 03:09:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-05 03:09:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-05 03:09:14 --> Config Class Initialized
INFO - 2017-03-05 03:09:14 --> Hooks Class Initialized
DEBUG - 2017-03-05 03:09:14 --> UTF-8 Support Enabled
INFO - 2017-03-05 03:09:14 --> Utf8 Class Initialized
INFO - 2017-03-05 03:09:14 --> URI Class Initialized
INFO - 2017-03-05 03:09:14 --> Router Class Initialized
INFO - 2017-03-05 03:09:14 --> Output Class Initialized
INFO - 2017-03-05 03:09:14 --> Security Class Initialized
DEBUG - 2017-03-05 03:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 03:09:14 --> Input Class Initialized
INFO - 2017-03-05 03:09:14 --> Language Class Initialized
INFO - 2017-03-05 03:09:14 --> Language Class Initialized
INFO - 2017-03-05 03:09:14 --> Config Class Initialized
INFO - 2017-03-05 03:09:14 --> Loader Class Initialized
INFO - 2017-03-05 03:09:14 --> Helper loaded: form_helper
INFO - 2017-03-05 03:09:14 --> Helper loaded: url_helper
INFO - 2017-03-05 03:09:14 --> Helper loaded: utility_helper
INFO - 2017-03-05 03:09:14 --> Database Driver Class Initialized
DEBUG - 2017-03-05 03:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 03:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 03:09:14 --> User Agent Class Initialized
DEBUG - 2017-03-05 03:09:14 --> Template Class Initialized
INFO - 2017-03-05 03:09:14 --> Model Class Initialized
INFO - 2017-03-05 03:09:14 --> Controller Class Initialized
DEBUG - 2017-03-05 03:09:14 --> Pages MX_Controller Initialized
INFO - 2017-03-05 03:09:14 --> Helper loaded: cookie_helper
DEBUG - 2017-03-05 03:09:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-05 03:09:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-05 13:54:06 --> Config Class Initialized
INFO - 2017-03-05 13:54:06 --> Hooks Class Initialized
DEBUG - 2017-03-05 13:54:06 --> UTF-8 Support Enabled
INFO - 2017-03-05 13:54:06 --> Utf8 Class Initialized
INFO - 2017-03-05 13:54:06 --> URI Class Initialized
INFO - 2017-03-05 13:54:06 --> Router Class Initialized
INFO - 2017-03-05 13:54:06 --> Output Class Initialized
INFO - 2017-03-05 13:54:06 --> Security Class Initialized
DEBUG - 2017-03-05 13:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 13:54:06 --> Input Class Initialized
INFO - 2017-03-05 13:54:06 --> Language Class Initialized
INFO - 2017-03-05 13:54:06 --> Language Class Initialized
INFO - 2017-03-05 13:54:06 --> Config Class Initialized
INFO - 2017-03-05 13:54:06 --> Loader Class Initialized
INFO - 2017-03-05 13:54:06 --> Helper loaded: form_helper
INFO - 2017-03-05 13:54:06 --> Helper loaded: url_helper
INFO - 2017-03-05 13:54:06 --> Helper loaded: utility_helper
INFO - 2017-03-05 13:54:06 --> Database Driver Class Initialized
DEBUG - 2017-03-05 13:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 13:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 13:54:06 --> User Agent Class Initialized
DEBUG - 2017-03-05 13:54:06 --> Template Class Initialized
INFO - 2017-03-05 13:54:06 --> Model Class Initialized
INFO - 2017-03-05 13:54:06 --> Controller Class Initialized
DEBUG - 2017-03-05 13:54:06 --> Pages MX_Controller Initialized
INFO - 2017-03-05 13:54:06 --> Helper loaded: cookie_helper
DEBUG - 2017-03-05 13:54:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-05 13:54:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-05 14:57:30 --> Config Class Initialized
INFO - 2017-03-05 14:57:30 --> Hooks Class Initialized
DEBUG - 2017-03-05 14:57:30 --> UTF-8 Support Enabled
INFO - 2017-03-05 14:57:30 --> Utf8 Class Initialized
INFO - 2017-03-05 14:57:30 --> URI Class Initialized
DEBUG - 2017-03-05 14:57:30 --> No URI present. Default controller set.
INFO - 2017-03-05 14:57:30 --> Router Class Initialized
INFO - 2017-03-05 14:57:30 --> Output Class Initialized
INFO - 2017-03-05 14:57:30 --> Security Class Initialized
DEBUG - 2017-03-05 14:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 14:57:30 --> Input Class Initialized
INFO - 2017-03-05 14:57:30 --> Language Class Initialized
INFO - 2017-03-05 14:57:30 --> Language Class Initialized
INFO - 2017-03-05 14:57:30 --> Config Class Initialized
INFO - 2017-03-05 14:57:30 --> Loader Class Initialized
INFO - 2017-03-05 14:57:30 --> Helper loaded: form_helper
INFO - 2017-03-05 14:57:30 --> Helper loaded: url_helper
INFO - 2017-03-05 14:57:30 --> Helper loaded: utility_helper
INFO - 2017-03-05 14:57:30 --> Database Driver Class Initialized
DEBUG - 2017-03-05 14:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 14:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 14:57:30 --> User Agent Class Initialized
DEBUG - 2017-03-05 14:57:30 --> Template Class Initialized
INFO - 2017-03-05 14:57:30 --> Model Class Initialized
INFO - 2017-03-05 14:57:30 --> Controller Class Initialized
DEBUG - 2017-03-05 14:57:30 --> Pages MX_Controller Initialized
INFO - 2017-03-05 14:57:30 --> Helper loaded: cookie_helper
DEBUG - 2017-03-05 14:57:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-05 14:57:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-05 14:57:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-05 14:57:30 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-05 14:57:30 --> Final output sent to browser
DEBUG - 2017-03-05 14:57:30 --> Total execution time: 0.3855
INFO - 2017-03-05 14:57:30 --> Config Class Initialized
INFO - 2017-03-05 14:57:30 --> Hooks Class Initialized
DEBUG - 2017-03-05 14:57:30 --> UTF-8 Support Enabled
INFO - 2017-03-05 14:57:30 --> Utf8 Class Initialized
INFO - 2017-03-05 14:57:30 --> URI Class Initialized
INFO - 2017-03-05 14:57:30 --> Router Class Initialized
INFO - 2017-03-05 14:57:30 --> Output Class Initialized
INFO - 2017-03-05 14:57:30 --> Security Class Initialized
DEBUG - 2017-03-05 14:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 14:57:30 --> Input Class Initialized
INFO - 2017-03-05 14:57:30 --> Language Class Initialized
INFO - 2017-03-05 14:57:31 --> Language Class Initialized
INFO - 2017-03-05 14:57:31 --> Config Class Initialized
INFO - 2017-03-05 14:57:31 --> Loader Class Initialized
INFO - 2017-03-05 14:57:31 --> Helper loaded: form_helper
INFO - 2017-03-05 14:57:31 --> Helper loaded: url_helper
INFO - 2017-03-05 14:57:31 --> Helper loaded: utility_helper
INFO - 2017-03-05 14:57:31 --> Database Driver Class Initialized
DEBUG - 2017-03-05 14:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 14:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 14:57:31 --> User Agent Class Initialized
DEBUG - 2017-03-05 14:57:31 --> Template Class Initialized
INFO - 2017-03-05 14:57:31 --> Model Class Initialized
INFO - 2017-03-05 14:57:31 --> Controller Class Initialized
DEBUG - 2017-03-05 14:57:31 --> Pages MX_Controller Initialized
INFO - 2017-03-05 14:57:31 --> Helper loaded: cookie_helper
DEBUG - 2017-03-05 14:57:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-05 14:57:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-05 14:57:33 --> Config Class Initialized
INFO - 2017-03-05 14:57:33 --> Hooks Class Initialized
DEBUG - 2017-03-05 14:57:33 --> UTF-8 Support Enabled
INFO - 2017-03-05 14:57:33 --> Utf8 Class Initialized
INFO - 2017-03-05 14:57:33 --> URI Class Initialized
INFO - 2017-03-05 14:57:33 --> Router Class Initialized
INFO - 2017-03-05 14:57:33 --> Output Class Initialized
INFO - 2017-03-05 14:57:33 --> Security Class Initialized
DEBUG - 2017-03-05 14:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 14:57:33 --> Input Class Initialized
INFO - 2017-03-05 14:57:33 --> Language Class Initialized
INFO - 2017-03-05 14:57:33 --> Language Class Initialized
INFO - 2017-03-05 14:57:33 --> Config Class Initialized
INFO - 2017-03-05 14:57:33 --> Loader Class Initialized
INFO - 2017-03-05 14:57:33 --> Helper loaded: form_helper
INFO - 2017-03-05 14:57:33 --> Helper loaded: url_helper
INFO - 2017-03-05 14:57:33 --> Helper loaded: utility_helper
INFO - 2017-03-05 14:57:33 --> Database Driver Class Initialized
DEBUG - 2017-03-05 14:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 14:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 14:57:33 --> User Agent Class Initialized
DEBUG - 2017-03-05 14:57:33 --> Template Class Initialized
INFO - 2017-03-05 14:57:33 --> Model Class Initialized
INFO - 2017-03-05 14:57:33 --> Controller Class Initialized
DEBUG - 2017-03-05 14:57:33 --> Pages MX_Controller Initialized
INFO - 2017-03-05 14:57:33 --> Helper loaded: cookie_helper
DEBUG - 2017-03-05 14:57:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-05 14:57:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-05 14:57:40 --> Config Class Initialized
INFO - 2017-03-05 14:57:40 --> Hooks Class Initialized
DEBUG - 2017-03-05 14:57:40 --> UTF-8 Support Enabled
INFO - 2017-03-05 14:57:40 --> Utf8 Class Initialized
INFO - 2017-03-05 14:57:40 --> URI Class Initialized
INFO - 2017-03-05 14:57:40 --> Router Class Initialized
INFO - 2017-03-05 14:57:40 --> Output Class Initialized
INFO - 2017-03-05 14:57:40 --> Security Class Initialized
DEBUG - 2017-03-05 14:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 14:57:40 --> Input Class Initialized
INFO - 2017-03-05 14:57:40 --> Language Class Initialized
INFO - 2017-03-05 14:57:40 --> Language Class Initialized
INFO - 2017-03-05 14:57:40 --> Config Class Initialized
INFO - 2017-03-05 14:57:40 --> Loader Class Initialized
INFO - 2017-03-05 14:57:40 --> Helper loaded: form_helper
INFO - 2017-03-05 14:57:40 --> Helper loaded: url_helper
INFO - 2017-03-05 14:57:40 --> Helper loaded: utility_helper
INFO - 2017-03-05 14:57:40 --> Database Driver Class Initialized
DEBUG - 2017-03-05 14:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 14:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 14:57:40 --> User Agent Class Initialized
DEBUG - 2017-03-05 14:57:40 --> Template Class Initialized
INFO - 2017-03-05 14:57:40 --> Model Class Initialized
INFO - 2017-03-05 14:57:40 --> Controller Class Initialized
DEBUG - 2017-03-05 14:57:40 --> Pages MX_Controller Initialized
INFO - 2017-03-05 14:57:40 --> Helper loaded: cookie_helper
DEBUG - 2017-03-05 14:57:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-05 14:57:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-05 14:59:11 --> Config Class Initialized
INFO - 2017-03-05 14:59:11 --> Hooks Class Initialized
DEBUG - 2017-03-05 14:59:11 --> UTF-8 Support Enabled
INFO - 2017-03-05 14:59:11 --> Utf8 Class Initialized
INFO - 2017-03-05 14:59:11 --> URI Class Initialized
INFO - 2017-03-05 14:59:11 --> Router Class Initialized
INFO - 2017-03-05 14:59:11 --> Output Class Initialized
INFO - 2017-03-05 14:59:11 --> Security Class Initialized
DEBUG - 2017-03-05 14:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 14:59:11 --> Input Class Initialized
INFO - 2017-03-05 14:59:11 --> Language Class Initialized
INFO - 2017-03-05 14:59:11 --> Language Class Initialized
INFO - 2017-03-05 14:59:11 --> Config Class Initialized
INFO - 2017-03-05 14:59:11 --> Loader Class Initialized
INFO - 2017-03-05 14:59:11 --> Helper loaded: form_helper
INFO - 2017-03-05 14:59:11 --> Helper loaded: url_helper
INFO - 2017-03-05 14:59:11 --> Helper loaded: utility_helper
INFO - 2017-03-05 14:59:11 --> Database Driver Class Initialized
DEBUG - 2017-03-05 14:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 14:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 14:59:11 --> User Agent Class Initialized
DEBUG - 2017-03-05 14:59:11 --> Template Class Initialized
INFO - 2017-03-05 14:59:11 --> Model Class Initialized
INFO - 2017-03-05 14:59:11 --> Controller Class Initialized
DEBUG - 2017-03-05 14:59:11 --> Pages MX_Controller Initialized
INFO - 2017-03-05 14:59:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-05 14:59:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-05 14:59:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-05 15:02:05 --> Config Class Initialized
INFO - 2017-03-05 15:02:05 --> Hooks Class Initialized
DEBUG - 2017-03-05 15:02:05 --> UTF-8 Support Enabled
INFO - 2017-03-05 15:02:05 --> Utf8 Class Initialized
INFO - 2017-03-05 15:02:05 --> URI Class Initialized
INFO - 2017-03-05 15:02:05 --> Router Class Initialized
INFO - 2017-03-05 15:02:05 --> Output Class Initialized
INFO - 2017-03-05 15:02:05 --> Security Class Initialized
DEBUG - 2017-03-05 15:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 15:02:05 --> Input Class Initialized
INFO - 2017-03-05 15:02:05 --> Language Class Initialized
INFO - 2017-03-05 15:02:05 --> Language Class Initialized
INFO - 2017-03-05 15:02:05 --> Config Class Initialized
INFO - 2017-03-05 15:02:05 --> Loader Class Initialized
INFO - 2017-03-05 15:02:05 --> Helper loaded: form_helper
INFO - 2017-03-05 15:02:05 --> Helper loaded: url_helper
INFO - 2017-03-05 15:02:05 --> Helper loaded: utility_helper
INFO - 2017-03-05 15:02:05 --> Database Driver Class Initialized
DEBUG - 2017-03-05 15:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 15:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 15:02:05 --> User Agent Class Initialized
DEBUG - 2017-03-05 15:02:05 --> Template Class Initialized
INFO - 2017-03-05 15:02:05 --> Model Class Initialized
INFO - 2017-03-05 15:02:05 --> Controller Class Initialized
DEBUG - 2017-03-05 15:02:05 --> Pages MX_Controller Initialized
INFO - 2017-03-05 15:02:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-05 15:02:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-05 15:02:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-05 15:02:10 --> Config Class Initialized
INFO - 2017-03-05 15:02:10 --> Hooks Class Initialized
DEBUG - 2017-03-05 15:02:10 --> UTF-8 Support Enabled
INFO - 2017-03-05 15:02:10 --> Utf8 Class Initialized
INFO - 2017-03-05 15:02:10 --> URI Class Initialized
INFO - 2017-03-05 15:02:10 --> Router Class Initialized
INFO - 2017-03-05 15:02:10 --> Output Class Initialized
INFO - 2017-03-05 15:02:10 --> Security Class Initialized
DEBUG - 2017-03-05 15:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 15:02:10 --> Input Class Initialized
INFO - 2017-03-05 15:02:10 --> Language Class Initialized
INFO - 2017-03-05 15:02:10 --> Language Class Initialized
INFO - 2017-03-05 15:02:10 --> Config Class Initialized
INFO - 2017-03-05 15:02:10 --> Loader Class Initialized
INFO - 2017-03-05 15:02:10 --> Helper loaded: form_helper
INFO - 2017-03-05 15:02:10 --> Helper loaded: url_helper
INFO - 2017-03-05 15:02:10 --> Helper loaded: utility_helper
INFO - 2017-03-05 15:02:10 --> Database Driver Class Initialized
DEBUG - 2017-03-05 15:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 15:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 15:02:10 --> User Agent Class Initialized
DEBUG - 2017-03-05 15:02:10 --> Template Class Initialized
INFO - 2017-03-05 15:02:10 --> Model Class Initialized
INFO - 2017-03-05 15:02:10 --> Controller Class Initialized
DEBUG - 2017-03-05 15:02:10 --> Pages MX_Controller Initialized
INFO - 2017-03-05 15:02:10 --> Helper loaded: cookie_helper
DEBUG - 2017-03-05 15:02:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-05 15:02:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-05 15:15:29 --> Config Class Initialized
INFO - 2017-03-05 15:15:29 --> Hooks Class Initialized
DEBUG - 2017-03-05 15:15:29 --> UTF-8 Support Enabled
INFO - 2017-03-05 15:15:29 --> Utf8 Class Initialized
INFO - 2017-03-05 15:15:29 --> URI Class Initialized
INFO - 2017-03-05 15:15:29 --> Router Class Initialized
INFO - 2017-03-05 15:15:29 --> Output Class Initialized
INFO - 2017-03-05 15:15:29 --> Security Class Initialized
DEBUG - 2017-03-05 15:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 15:15:29 --> Input Class Initialized
INFO - 2017-03-05 15:15:29 --> Language Class Initialized
INFO - 2017-03-05 15:15:29 --> Language Class Initialized
INFO - 2017-03-05 15:15:29 --> Config Class Initialized
INFO - 2017-03-05 15:15:29 --> Loader Class Initialized
INFO - 2017-03-05 15:15:29 --> Helper loaded: form_helper
INFO - 2017-03-05 15:15:29 --> Helper loaded: url_helper
INFO - 2017-03-05 15:15:29 --> Helper loaded: utility_helper
INFO - 2017-03-05 15:15:29 --> Database Driver Class Initialized
DEBUG - 2017-03-05 15:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 15:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 15:15:29 --> User Agent Class Initialized
DEBUG - 2017-03-05 15:15:29 --> Template Class Initialized
INFO - 2017-03-05 15:15:29 --> Model Class Initialized
INFO - 2017-03-05 15:15:29 --> Controller Class Initialized
DEBUG - 2017-03-05 15:15:29 --> Pages MX_Controller Initialized
INFO - 2017-03-05 15:15:29 --> Helper loaded: cookie_helper
DEBUG - 2017-03-05 15:15:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-05 15:15:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-05 15:15:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-05 15:15:29 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-05 15:15:29 --> Final output sent to browser
DEBUG - 2017-03-05 15:15:29 --> Total execution time: 0.0660
INFO - 2017-03-05 15:15:29 --> Config Class Initialized
INFO - 2017-03-05 15:15:29 --> Hooks Class Initialized
DEBUG - 2017-03-05 15:15:29 --> UTF-8 Support Enabled
INFO - 2017-03-05 15:15:29 --> Utf8 Class Initialized
INFO - 2017-03-05 15:15:29 --> URI Class Initialized
INFO - 2017-03-05 15:15:29 --> Router Class Initialized
INFO - 2017-03-05 15:15:29 --> Output Class Initialized
INFO - 2017-03-05 15:15:29 --> Security Class Initialized
DEBUG - 2017-03-05 15:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 15:15:29 --> Input Class Initialized
INFO - 2017-03-05 15:15:29 --> Language Class Initialized
INFO - 2017-03-05 15:15:29 --> Language Class Initialized
INFO - 2017-03-05 15:15:29 --> Config Class Initialized
INFO - 2017-03-05 15:15:29 --> Loader Class Initialized
INFO - 2017-03-05 15:15:29 --> Helper loaded: form_helper
INFO - 2017-03-05 15:15:29 --> Helper loaded: url_helper
INFO - 2017-03-05 15:15:29 --> Helper loaded: utility_helper
INFO - 2017-03-05 15:15:29 --> Database Driver Class Initialized
DEBUG - 2017-03-05 15:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 15:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 15:15:29 --> User Agent Class Initialized
DEBUG - 2017-03-05 15:15:29 --> Template Class Initialized
INFO - 2017-03-05 15:15:29 --> Model Class Initialized
INFO - 2017-03-05 15:15:29 --> Controller Class Initialized
DEBUG - 2017-03-05 15:15:29 --> Pages MX_Controller Initialized
INFO - 2017-03-05 15:15:29 --> Helper loaded: cookie_helper
DEBUG - 2017-03-05 15:15:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-05 15:15:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-05 21:14:01 --> Config Class Initialized
INFO - 2017-03-05 21:14:01 --> Hooks Class Initialized
DEBUG - 2017-03-05 21:14:01 --> UTF-8 Support Enabled
INFO - 2017-03-05 21:14:01 --> Utf8 Class Initialized
INFO - 2017-03-05 21:14:01 --> URI Class Initialized
INFO - 2017-03-05 21:14:01 --> Router Class Initialized
INFO - 2017-03-05 21:14:01 --> Output Class Initialized
INFO - 2017-03-05 21:14:01 --> Security Class Initialized
DEBUG - 2017-03-05 21:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-05 21:14:01 --> Input Class Initialized
INFO - 2017-03-05 21:14:01 --> Language Class Initialized
INFO - 2017-03-05 21:14:01 --> Language Class Initialized
INFO - 2017-03-05 21:14:01 --> Config Class Initialized
INFO - 2017-03-05 21:14:01 --> Loader Class Initialized
INFO - 2017-03-05 21:14:01 --> Helper loaded: form_helper
INFO - 2017-03-05 21:14:01 --> Helper loaded: url_helper
INFO - 2017-03-05 21:14:01 --> Helper loaded: utility_helper
INFO - 2017-03-05 21:14:02 --> Database Driver Class Initialized
DEBUG - 2017-03-05 21:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-05 21:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-05 21:14:02 --> User Agent Class Initialized
DEBUG - 2017-03-05 21:14:02 --> Template Class Initialized
INFO - 2017-03-05 21:14:02 --> Model Class Initialized
INFO - 2017-03-05 21:14:02 --> Controller Class Initialized
DEBUG - 2017-03-05 21:14:02 --> Pages MX_Controller Initialized
INFO - 2017-03-05 21:14:02 --> Helper loaded: cookie_helper
DEBUG - 2017-03-05 21:14:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-05 21:14:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
