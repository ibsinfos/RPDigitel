<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-06 01:13:21 --> Config Class Initialized
INFO - 2017-03-06 01:13:21 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:13:21 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:13:21 --> Utf8 Class Initialized
INFO - 2017-03-06 01:13:21 --> URI Class Initialized
INFO - 2017-03-06 01:13:21 --> Router Class Initialized
INFO - 2017-03-06 01:13:21 --> Output Class Initialized
INFO - 2017-03-06 01:13:21 --> Security Class Initialized
DEBUG - 2017-03-06 01:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:13:21 --> Input Class Initialized
INFO - 2017-03-06 01:13:21 --> Language Class Initialized
INFO - 2017-03-06 01:13:21 --> Language Class Initialized
INFO - 2017-03-06 01:13:21 --> Config Class Initialized
INFO - 2017-03-06 01:13:21 --> Loader Class Initialized
INFO - 2017-03-06 01:13:21 --> Helper loaded: form_helper
INFO - 2017-03-06 01:13:21 --> Helper loaded: url_helper
INFO - 2017-03-06 01:13:21 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:13:21 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:13:21 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:13:21 --> Template Class Initialized
INFO - 2017-03-06 01:13:21 --> Model Class Initialized
INFO - 2017-03-06 01:13:21 --> Controller Class Initialized
DEBUG - 2017-03-06 01:13:21 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:13:21 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:13:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:13:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 01:13:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-03-06 01:13:21 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 01:13:21 --> Final output sent to browser
DEBUG - 2017-03-06 01:13:21 --> Total execution time: 0.3730
INFO - 2017-03-06 01:13:26 --> Config Class Initialized
INFO - 2017-03-06 01:13:26 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:13:26 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:13:26 --> Utf8 Class Initialized
INFO - 2017-03-06 01:13:26 --> URI Class Initialized
INFO - 2017-03-06 01:13:26 --> Router Class Initialized
INFO - 2017-03-06 01:13:26 --> Output Class Initialized
INFO - 2017-03-06 01:13:26 --> Security Class Initialized
DEBUG - 2017-03-06 01:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:13:26 --> Input Class Initialized
INFO - 2017-03-06 01:13:26 --> Language Class Initialized
INFO - 2017-03-06 01:13:26 --> Language Class Initialized
INFO - 2017-03-06 01:13:26 --> Config Class Initialized
INFO - 2017-03-06 01:13:26 --> Loader Class Initialized
INFO - 2017-03-06 01:13:26 --> Helper loaded: form_helper
INFO - 2017-03-06 01:13:26 --> Helper loaded: url_helper
INFO - 2017-03-06 01:13:26 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:13:26 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:13:26 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:13:26 --> Template Class Initialized
INFO - 2017-03-06 01:13:26 --> Model Class Initialized
INFO - 2017-03-06 01:13:26 --> Controller Class Initialized
DEBUG - 2017-03-06 01:13:26 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:13:26 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:13:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:13:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:13:48 --> Config Class Initialized
INFO - 2017-03-06 01:13:48 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:13:48 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:13:48 --> Utf8 Class Initialized
INFO - 2017-03-06 01:13:48 --> URI Class Initialized
INFO - 2017-03-06 01:13:48 --> Router Class Initialized
INFO - 2017-03-06 01:13:48 --> Output Class Initialized
INFO - 2017-03-06 01:13:48 --> Security Class Initialized
DEBUG - 2017-03-06 01:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:13:48 --> Input Class Initialized
INFO - 2017-03-06 01:13:48 --> Language Class Initialized
INFO - 2017-03-06 01:13:48 --> Language Class Initialized
INFO - 2017-03-06 01:13:48 --> Config Class Initialized
INFO - 2017-03-06 01:13:48 --> Loader Class Initialized
INFO - 2017-03-06 01:13:48 --> Helper loaded: form_helper
INFO - 2017-03-06 01:13:48 --> Helper loaded: url_helper
INFO - 2017-03-06 01:13:48 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:13:48 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:13:48 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:13:48 --> Template Class Initialized
INFO - 2017-03-06 01:13:48 --> Model Class Initialized
INFO - 2017-03-06 01:13:48 --> Controller Class Initialized
DEBUG - 2017-03-06 01:13:48 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:13:48 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:13:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:13:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:13:52 --> Config Class Initialized
INFO - 2017-03-06 01:13:52 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:13:52 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:13:52 --> Utf8 Class Initialized
INFO - 2017-03-06 01:13:52 --> URI Class Initialized
INFO - 2017-03-06 01:13:52 --> Router Class Initialized
INFO - 2017-03-06 01:13:52 --> Output Class Initialized
INFO - 2017-03-06 01:13:52 --> Security Class Initialized
DEBUG - 2017-03-06 01:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:13:52 --> Input Class Initialized
INFO - 2017-03-06 01:13:52 --> Language Class Initialized
INFO - 2017-03-06 01:13:52 --> Language Class Initialized
INFO - 2017-03-06 01:13:52 --> Config Class Initialized
INFO - 2017-03-06 01:13:52 --> Loader Class Initialized
INFO - 2017-03-06 01:13:52 --> Helper loaded: form_helper
INFO - 2017-03-06 01:13:52 --> Helper loaded: url_helper
INFO - 2017-03-06 01:13:52 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:13:52 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:13:52 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:13:52 --> Template Class Initialized
INFO - 2017-03-06 01:13:52 --> Model Class Initialized
INFO - 2017-03-06 01:13:52 --> Controller Class Initialized
DEBUG - 2017-03-06 01:13:52 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:13:52 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:13:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:13:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 01:13:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-03-06 01:13:52 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 01:13:52 --> Final output sent to browser
DEBUG - 2017-03-06 01:13:52 --> Total execution time: 0.0152
INFO - 2017-03-06 01:13:53 --> Config Class Initialized
INFO - 2017-03-06 01:13:53 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:13:53 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:13:53 --> Utf8 Class Initialized
INFO - 2017-03-06 01:13:53 --> URI Class Initialized
INFO - 2017-03-06 01:13:53 --> Router Class Initialized
INFO - 2017-03-06 01:13:53 --> Output Class Initialized
INFO - 2017-03-06 01:13:53 --> Security Class Initialized
DEBUG - 2017-03-06 01:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:13:53 --> Input Class Initialized
INFO - 2017-03-06 01:13:53 --> Language Class Initialized
INFO - 2017-03-06 01:13:53 --> Language Class Initialized
INFO - 2017-03-06 01:13:53 --> Config Class Initialized
INFO - 2017-03-06 01:13:53 --> Loader Class Initialized
INFO - 2017-03-06 01:13:53 --> Helper loaded: form_helper
INFO - 2017-03-06 01:13:53 --> Helper loaded: url_helper
INFO - 2017-03-06 01:13:53 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:13:53 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:13:53 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:13:53 --> Template Class Initialized
INFO - 2017-03-06 01:13:53 --> Model Class Initialized
INFO - 2017-03-06 01:13:53 --> Controller Class Initialized
DEBUG - 2017-03-06 01:13:53 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:13:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:13:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:13:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:13:59 --> Config Class Initialized
INFO - 2017-03-06 01:13:59 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:13:59 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:13:59 --> Utf8 Class Initialized
INFO - 2017-03-06 01:13:59 --> URI Class Initialized
DEBUG - 2017-03-06 01:13:59 --> No URI present. Default controller set.
INFO - 2017-03-06 01:13:59 --> Router Class Initialized
INFO - 2017-03-06 01:13:59 --> Output Class Initialized
INFO - 2017-03-06 01:13:59 --> Security Class Initialized
DEBUG - 2017-03-06 01:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:13:59 --> Input Class Initialized
INFO - 2017-03-06 01:13:59 --> Language Class Initialized
INFO - 2017-03-06 01:13:59 --> Language Class Initialized
INFO - 2017-03-06 01:13:59 --> Config Class Initialized
INFO - 2017-03-06 01:13:59 --> Loader Class Initialized
INFO - 2017-03-06 01:13:59 --> Helper loaded: form_helper
INFO - 2017-03-06 01:13:59 --> Helper loaded: url_helper
INFO - 2017-03-06 01:13:59 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:13:59 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:13:59 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:13:59 --> Template Class Initialized
INFO - 2017-03-06 01:13:59 --> Model Class Initialized
INFO - 2017-03-06 01:13:59 --> Controller Class Initialized
DEBUG - 2017-03-06 01:13:59 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:13:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:13:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:13:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 01:13:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-06 01:13:59 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 01:13:59 --> Final output sent to browser
DEBUG - 2017-03-06 01:13:59 --> Total execution time: 0.0373
INFO - 2017-03-06 01:13:59 --> Config Class Initialized
INFO - 2017-03-06 01:13:59 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:13:59 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:13:59 --> Utf8 Class Initialized
INFO - 2017-03-06 01:13:59 --> URI Class Initialized
INFO - 2017-03-06 01:13:59 --> Router Class Initialized
INFO - 2017-03-06 01:13:59 --> Output Class Initialized
INFO - 2017-03-06 01:13:59 --> Security Class Initialized
DEBUG - 2017-03-06 01:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:13:59 --> Input Class Initialized
INFO - 2017-03-06 01:13:59 --> Language Class Initialized
INFO - 2017-03-06 01:13:59 --> Language Class Initialized
INFO - 2017-03-06 01:13:59 --> Config Class Initialized
INFO - 2017-03-06 01:13:59 --> Loader Class Initialized
INFO - 2017-03-06 01:13:59 --> Helper loaded: form_helper
INFO - 2017-03-06 01:13:59 --> Helper loaded: url_helper
INFO - 2017-03-06 01:13:59 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:13:59 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:13:59 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:13:59 --> Template Class Initialized
INFO - 2017-03-06 01:13:59 --> Model Class Initialized
INFO - 2017-03-06 01:13:59 --> Controller Class Initialized
DEBUG - 2017-03-06 01:13:59 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:14:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:14:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:14:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:14:00 --> Config Class Initialized
INFO - 2017-03-06 01:14:00 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:14:00 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:14:00 --> Utf8 Class Initialized
INFO - 2017-03-06 01:14:00 --> URI Class Initialized
INFO - 2017-03-06 01:14:00 --> Router Class Initialized
INFO - 2017-03-06 01:14:00 --> Output Class Initialized
INFO - 2017-03-06 01:14:00 --> Security Class Initialized
DEBUG - 2017-03-06 01:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:14:00 --> Input Class Initialized
INFO - 2017-03-06 01:14:00 --> Language Class Initialized
INFO - 2017-03-06 01:14:00 --> Language Class Initialized
INFO - 2017-03-06 01:14:00 --> Config Class Initialized
INFO - 2017-03-06 01:14:00 --> Loader Class Initialized
INFO - 2017-03-06 01:14:00 --> Helper loaded: form_helper
INFO - 2017-03-06 01:14:00 --> Helper loaded: url_helper
INFO - 2017-03-06 01:14:00 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:14:00 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:14:00 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:14:00 --> Template Class Initialized
INFO - 2017-03-06 01:14:00 --> Model Class Initialized
INFO - 2017-03-06 01:14:00 --> Controller Class Initialized
DEBUG - 2017-03-06 01:14:00 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:14:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:14:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:14:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:14:50 --> Config Class Initialized
INFO - 2017-03-06 01:14:50 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:14:50 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:14:50 --> Utf8 Class Initialized
INFO - 2017-03-06 01:14:50 --> URI Class Initialized
INFO - 2017-03-06 01:14:50 --> Router Class Initialized
INFO - 2017-03-06 01:14:50 --> Output Class Initialized
INFO - 2017-03-06 01:14:50 --> Security Class Initialized
DEBUG - 2017-03-06 01:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:14:50 --> Input Class Initialized
INFO - 2017-03-06 01:14:50 --> Language Class Initialized
INFO - 2017-03-06 01:14:50 --> Language Class Initialized
INFO - 2017-03-06 01:14:50 --> Config Class Initialized
INFO - 2017-03-06 01:14:50 --> Loader Class Initialized
INFO - 2017-03-06 01:14:50 --> Helper loaded: form_helper
INFO - 2017-03-06 01:14:50 --> Helper loaded: url_helper
INFO - 2017-03-06 01:14:50 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:14:50 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:14:50 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:14:50 --> Template Class Initialized
INFO - 2017-03-06 01:14:50 --> Model Class Initialized
INFO - 2017-03-06 01:14:50 --> Controller Class Initialized
DEBUG - 2017-03-06 01:14:50 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:14:50 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:14:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:14:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 01:14:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 01:14:50 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 01:14:50 --> Final output sent to browser
DEBUG - 2017-03-06 01:14:50 --> Total execution time: 0.0739
INFO - 2017-03-06 01:14:51 --> Config Class Initialized
INFO - 2017-03-06 01:14:51 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:14:51 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:14:51 --> Utf8 Class Initialized
INFO - 2017-03-06 01:14:51 --> URI Class Initialized
INFO - 2017-03-06 01:14:51 --> Router Class Initialized
INFO - 2017-03-06 01:14:51 --> Output Class Initialized
INFO - 2017-03-06 01:14:51 --> Security Class Initialized
DEBUG - 2017-03-06 01:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:14:51 --> Input Class Initialized
INFO - 2017-03-06 01:14:51 --> Language Class Initialized
INFO - 2017-03-06 01:14:51 --> Language Class Initialized
INFO - 2017-03-06 01:14:51 --> Config Class Initialized
INFO - 2017-03-06 01:14:51 --> Loader Class Initialized
INFO - 2017-03-06 01:14:51 --> Helper loaded: form_helper
INFO - 2017-03-06 01:14:51 --> Helper loaded: url_helper
INFO - 2017-03-06 01:14:51 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:14:51 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:14:51 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:14:51 --> Template Class Initialized
INFO - 2017-03-06 01:14:51 --> Model Class Initialized
INFO - 2017-03-06 01:14:51 --> Controller Class Initialized
DEBUG - 2017-03-06 01:14:51 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:14:51 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:14:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:14:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:15:08 --> Config Class Initialized
INFO - 2017-03-06 01:15:08 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:15:08 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:15:08 --> Utf8 Class Initialized
INFO - 2017-03-06 01:15:08 --> URI Class Initialized
INFO - 2017-03-06 01:15:08 --> Router Class Initialized
INFO - 2017-03-06 01:15:08 --> Output Class Initialized
INFO - 2017-03-06 01:15:08 --> Security Class Initialized
DEBUG - 2017-03-06 01:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:15:08 --> Input Class Initialized
INFO - 2017-03-06 01:15:08 --> Language Class Initialized
INFO - 2017-03-06 01:15:08 --> Language Class Initialized
INFO - 2017-03-06 01:15:08 --> Config Class Initialized
INFO - 2017-03-06 01:15:08 --> Loader Class Initialized
INFO - 2017-03-06 01:15:08 --> Helper loaded: form_helper
INFO - 2017-03-06 01:15:08 --> Helper loaded: url_helper
INFO - 2017-03-06 01:15:08 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:15:08 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:15:08 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:15:08 --> Template Class Initialized
INFO - 2017-03-06 01:15:08 --> Model Class Initialized
INFO - 2017-03-06 01:15:08 --> Controller Class Initialized
DEBUG - 2017-03-06 01:15:08 --> Login MX_Controller Initialized
INFO - 2017-03-06 01:15:08 --> Helper loaded: cookie_helper
INFO - 2017-03-06 01:15:08 --> Form Validation Class Initialized
INFO - 2017-03-06 01:15:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-06 01:15:08 --> Config Class Initialized
INFO - 2017-03-06 01:15:08 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:15:08 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:15:08 --> Utf8 Class Initialized
INFO - 2017-03-06 01:15:08 --> URI Class Initialized
INFO - 2017-03-06 01:15:08 --> Router Class Initialized
INFO - 2017-03-06 01:15:08 --> Output Class Initialized
INFO - 2017-03-06 01:15:08 --> Security Class Initialized
DEBUG - 2017-03-06 01:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:15:08 --> Input Class Initialized
INFO - 2017-03-06 01:15:08 --> Language Class Initialized
INFO - 2017-03-06 01:15:08 --> Language Class Initialized
INFO - 2017-03-06 01:15:08 --> Config Class Initialized
INFO - 2017-03-06 01:15:08 --> Loader Class Initialized
INFO - 2017-03-06 01:15:08 --> Helper loaded: form_helper
INFO - 2017-03-06 01:15:08 --> Helper loaded: url_helper
INFO - 2017-03-06 01:15:08 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:15:08 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:15:08 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:15:08 --> Template Class Initialized
INFO - 2017-03-06 01:15:08 --> Model Class Initialized
INFO - 2017-03-06 01:15:08 --> Controller Class Initialized
DEBUG - 2017-03-06 01:15:08 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:15:08 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:15:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:15:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 01:15:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 01:15:08 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 01:15:08 --> Final output sent to browser
DEBUG - 2017-03-06 01:15:08 --> Total execution time: 0.0128
INFO - 2017-03-06 01:15:09 --> Config Class Initialized
INFO - 2017-03-06 01:15:09 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:15:09 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:15:09 --> Utf8 Class Initialized
INFO - 2017-03-06 01:15:09 --> URI Class Initialized
INFO - 2017-03-06 01:15:09 --> Router Class Initialized
INFO - 2017-03-06 01:15:09 --> Output Class Initialized
INFO - 2017-03-06 01:15:09 --> Security Class Initialized
DEBUG - 2017-03-06 01:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:15:09 --> Input Class Initialized
INFO - 2017-03-06 01:15:09 --> Language Class Initialized
INFO - 2017-03-06 01:15:09 --> Language Class Initialized
INFO - 2017-03-06 01:15:09 --> Config Class Initialized
INFO - 2017-03-06 01:15:09 --> Loader Class Initialized
INFO - 2017-03-06 01:15:09 --> Helper loaded: form_helper
INFO - 2017-03-06 01:15:09 --> Helper loaded: url_helper
INFO - 2017-03-06 01:15:09 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:15:09 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:15:09 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:15:09 --> Template Class Initialized
INFO - 2017-03-06 01:15:09 --> Model Class Initialized
INFO - 2017-03-06 01:15:09 --> Controller Class Initialized
DEBUG - 2017-03-06 01:15:09 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:15:09 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:15:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:15:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:15:09 --> Config Class Initialized
INFO - 2017-03-06 01:15:09 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:15:09 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:15:09 --> Utf8 Class Initialized
INFO - 2017-03-06 01:15:09 --> URI Class Initialized
INFO - 2017-03-06 01:15:09 --> Router Class Initialized
INFO - 2017-03-06 01:15:09 --> Output Class Initialized
INFO - 2017-03-06 01:15:09 --> Security Class Initialized
DEBUG - 2017-03-06 01:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:15:09 --> Input Class Initialized
INFO - 2017-03-06 01:15:09 --> Language Class Initialized
INFO - 2017-03-06 01:15:09 --> Language Class Initialized
INFO - 2017-03-06 01:15:09 --> Config Class Initialized
INFO - 2017-03-06 01:15:09 --> Loader Class Initialized
INFO - 2017-03-06 01:15:09 --> Helper loaded: form_helper
INFO - 2017-03-06 01:15:09 --> Helper loaded: url_helper
INFO - 2017-03-06 01:15:09 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:15:09 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:15:09 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:15:09 --> Template Class Initialized
INFO - 2017-03-06 01:15:09 --> Model Class Initialized
INFO - 2017-03-06 01:15:09 --> Controller Class Initialized
DEBUG - 2017-03-06 01:15:09 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:15:09 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:15:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:15:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:15:20 --> Config Class Initialized
INFO - 2017-03-06 01:15:20 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:15:20 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:15:20 --> Utf8 Class Initialized
INFO - 2017-03-06 01:15:20 --> URI Class Initialized
INFO - 2017-03-06 01:15:20 --> Router Class Initialized
INFO - 2017-03-06 01:15:20 --> Output Class Initialized
INFO - 2017-03-06 01:15:20 --> Security Class Initialized
DEBUG - 2017-03-06 01:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:15:20 --> Input Class Initialized
INFO - 2017-03-06 01:15:20 --> Language Class Initialized
INFO - 2017-03-06 01:15:20 --> Language Class Initialized
INFO - 2017-03-06 01:15:20 --> Config Class Initialized
INFO - 2017-03-06 01:15:20 --> Loader Class Initialized
INFO - 2017-03-06 01:15:20 --> Helper loaded: form_helper
INFO - 2017-03-06 01:15:20 --> Helper loaded: url_helper
INFO - 2017-03-06 01:15:20 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:15:20 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:15:20 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:15:20 --> Template Class Initialized
INFO - 2017-03-06 01:15:20 --> Model Class Initialized
INFO - 2017-03-06 01:15:20 --> Controller Class Initialized
DEBUG - 2017-03-06 01:15:20 --> Login MX_Controller Initialized
INFO - 2017-03-06 01:15:20 --> Helper loaded: cookie_helper
INFO - 2017-03-06 01:15:20 --> Form Validation Class Initialized
INFO - 2017-03-06 01:15:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-06 01:15:20 --> Config Class Initialized
INFO - 2017-03-06 01:15:20 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:15:20 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:15:20 --> Utf8 Class Initialized
INFO - 2017-03-06 01:15:20 --> URI Class Initialized
INFO - 2017-03-06 01:15:20 --> Router Class Initialized
INFO - 2017-03-06 01:15:20 --> Output Class Initialized
INFO - 2017-03-06 01:15:20 --> Security Class Initialized
DEBUG - 2017-03-06 01:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:15:20 --> Input Class Initialized
INFO - 2017-03-06 01:15:20 --> Language Class Initialized
INFO - 2017-03-06 01:15:20 --> Language Class Initialized
INFO - 2017-03-06 01:15:20 --> Config Class Initialized
INFO - 2017-03-06 01:15:20 --> Loader Class Initialized
INFO - 2017-03-06 01:15:20 --> Helper loaded: form_helper
INFO - 2017-03-06 01:15:20 --> Helper loaded: url_helper
INFO - 2017-03-06 01:15:20 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:15:20 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:15:20 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:15:20 --> Template Class Initialized
INFO - 2017-03-06 01:15:20 --> Model Class Initialized
INFO - 2017-03-06 01:15:20 --> Controller Class Initialized
DEBUG - 2017-03-06 01:15:20 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:15:20 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:15:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:15:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 01:15:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 01:15:20 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 01:15:20 --> Final output sent to browser
DEBUG - 2017-03-06 01:15:20 --> Total execution time: 0.0487
INFO - 2017-03-06 01:15:21 --> Config Class Initialized
INFO - 2017-03-06 01:15:21 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:15:21 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:15:21 --> Utf8 Class Initialized
INFO - 2017-03-06 01:15:21 --> URI Class Initialized
INFO - 2017-03-06 01:15:21 --> Router Class Initialized
INFO - 2017-03-06 01:15:21 --> Output Class Initialized
INFO - 2017-03-06 01:15:21 --> Security Class Initialized
DEBUG - 2017-03-06 01:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:15:21 --> Input Class Initialized
INFO - 2017-03-06 01:15:21 --> Language Class Initialized
INFO - 2017-03-06 01:15:21 --> Language Class Initialized
INFO - 2017-03-06 01:15:21 --> Config Class Initialized
INFO - 2017-03-06 01:15:21 --> Loader Class Initialized
INFO - 2017-03-06 01:15:21 --> Helper loaded: form_helper
INFO - 2017-03-06 01:15:21 --> Helper loaded: url_helper
INFO - 2017-03-06 01:15:21 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:15:21 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:15:21 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:15:21 --> Template Class Initialized
INFO - 2017-03-06 01:15:21 --> Model Class Initialized
INFO - 2017-03-06 01:15:21 --> Controller Class Initialized
DEBUG - 2017-03-06 01:15:21 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:15:21 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:15:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:15:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:16:10 --> Config Class Initialized
INFO - 2017-03-06 01:16:10 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:16:10 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:16:10 --> Utf8 Class Initialized
INFO - 2017-03-06 01:16:10 --> URI Class Initialized
INFO - 2017-03-06 01:16:10 --> Router Class Initialized
INFO - 2017-03-06 01:16:10 --> Output Class Initialized
INFO - 2017-03-06 01:16:10 --> Security Class Initialized
DEBUG - 2017-03-06 01:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:16:10 --> Input Class Initialized
INFO - 2017-03-06 01:16:10 --> Language Class Initialized
INFO - 2017-03-06 01:16:10 --> Language Class Initialized
INFO - 2017-03-06 01:16:10 --> Config Class Initialized
INFO - 2017-03-06 01:16:10 --> Loader Class Initialized
INFO - 2017-03-06 01:16:10 --> Helper loaded: form_helper
INFO - 2017-03-06 01:16:10 --> Helper loaded: url_helper
INFO - 2017-03-06 01:16:10 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:16:10 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:16:10 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:16:10 --> Template Class Initialized
INFO - 2017-03-06 01:16:10 --> Model Class Initialized
INFO - 2017-03-06 01:16:10 --> Controller Class Initialized
DEBUG - 2017-03-06 01:16:10 --> Login MX_Controller Initialized
INFO - 2017-03-06 01:16:10 --> Helper loaded: cookie_helper
INFO - 2017-03-06 01:16:10 --> Form Validation Class Initialized
INFO - 2017-03-06 01:16:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-06 01:16:10 --> Config Class Initialized
INFO - 2017-03-06 01:16:10 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:16:10 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:16:10 --> Utf8 Class Initialized
INFO - 2017-03-06 01:16:10 --> URI Class Initialized
INFO - 2017-03-06 01:16:10 --> Router Class Initialized
INFO - 2017-03-06 01:16:10 --> Output Class Initialized
INFO - 2017-03-06 01:16:10 --> Security Class Initialized
DEBUG - 2017-03-06 01:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:16:10 --> Input Class Initialized
INFO - 2017-03-06 01:16:10 --> Language Class Initialized
INFO - 2017-03-06 01:16:10 --> Language Class Initialized
INFO - 2017-03-06 01:16:10 --> Config Class Initialized
INFO - 2017-03-06 01:16:10 --> Loader Class Initialized
INFO - 2017-03-06 01:16:10 --> Helper loaded: form_helper
INFO - 2017-03-06 01:16:10 --> Helper loaded: url_helper
INFO - 2017-03-06 01:16:10 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:16:10 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:16:10 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:16:10 --> Template Class Initialized
INFO - 2017-03-06 01:16:10 --> Model Class Initialized
INFO - 2017-03-06 01:16:10 --> Controller Class Initialized
DEBUG - 2017-03-06 01:16:10 --> Dashboard MX_Controller Initialized
INFO - 2017-03-06 01:16:10 --> Helper loaded: cookie_helper
INFO - 2017-03-06 01:16:11 --> Config Class Initialized
INFO - 2017-03-06 01:16:11 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:16:11 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:16:11 --> Utf8 Class Initialized
INFO - 2017-03-06 01:16:11 --> URI Class Initialized
DEBUG - 2017-03-06 01:16:11 --> No URI present. Default controller set.
INFO - 2017-03-06 01:16:11 --> Router Class Initialized
INFO - 2017-03-06 01:16:11 --> Output Class Initialized
INFO - 2017-03-06 01:16:11 --> Security Class Initialized
DEBUG - 2017-03-06 01:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:16:11 --> Input Class Initialized
INFO - 2017-03-06 01:16:11 --> Language Class Initialized
INFO - 2017-03-06 01:16:11 --> Language Class Initialized
INFO - 2017-03-06 01:16:11 --> Config Class Initialized
INFO - 2017-03-06 01:16:11 --> Loader Class Initialized
INFO - 2017-03-06 01:16:11 --> Helper loaded: form_helper
INFO - 2017-03-06 01:16:11 --> Helper loaded: url_helper
INFO - 2017-03-06 01:16:11 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:16:11 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:16:11 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:16:11 --> Template Class Initialized
INFO - 2017-03-06 01:16:11 --> Model Class Initialized
INFO - 2017-03-06 01:16:11 --> Controller Class Initialized
DEBUG - 2017-03-06 01:16:11 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:16:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:16:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:16:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 01:16:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-06 01:16:11 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 01:16:11 --> Final output sent to browser
DEBUG - 2017-03-06 01:16:11 --> Total execution time: 0.0152
INFO - 2017-03-06 01:16:12 --> Config Class Initialized
INFO - 2017-03-06 01:16:12 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:16:12 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:16:12 --> Utf8 Class Initialized
INFO - 2017-03-06 01:16:12 --> URI Class Initialized
INFO - 2017-03-06 01:16:12 --> Router Class Initialized
INFO - 2017-03-06 01:16:12 --> Output Class Initialized
INFO - 2017-03-06 01:16:12 --> Security Class Initialized
DEBUG - 2017-03-06 01:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:16:12 --> Input Class Initialized
INFO - 2017-03-06 01:16:12 --> Language Class Initialized
INFO - 2017-03-06 01:16:12 --> Language Class Initialized
INFO - 2017-03-06 01:16:12 --> Config Class Initialized
INFO - 2017-03-06 01:16:12 --> Loader Class Initialized
INFO - 2017-03-06 01:16:12 --> Helper loaded: form_helper
INFO - 2017-03-06 01:16:12 --> Helper loaded: url_helper
INFO - 2017-03-06 01:16:12 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:16:12 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:16:12 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:16:12 --> Template Class Initialized
INFO - 2017-03-06 01:16:12 --> Model Class Initialized
INFO - 2017-03-06 01:16:12 --> Controller Class Initialized
DEBUG - 2017-03-06 01:16:12 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:16:12 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:16:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:16:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:16:12 --> Config Class Initialized
INFO - 2017-03-06 01:16:12 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:16:12 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:16:12 --> Utf8 Class Initialized
INFO - 2017-03-06 01:16:12 --> URI Class Initialized
INFO - 2017-03-06 01:16:12 --> Router Class Initialized
INFO - 2017-03-06 01:16:12 --> Output Class Initialized
INFO - 2017-03-06 01:16:12 --> Security Class Initialized
DEBUG - 2017-03-06 01:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:16:12 --> Input Class Initialized
INFO - 2017-03-06 01:16:12 --> Language Class Initialized
INFO - 2017-03-06 01:16:12 --> Language Class Initialized
INFO - 2017-03-06 01:16:12 --> Config Class Initialized
INFO - 2017-03-06 01:16:12 --> Loader Class Initialized
INFO - 2017-03-06 01:16:12 --> Helper loaded: form_helper
INFO - 2017-03-06 01:16:12 --> Helper loaded: url_helper
INFO - 2017-03-06 01:16:12 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:16:12 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:16:12 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:16:12 --> Template Class Initialized
INFO - 2017-03-06 01:16:12 --> Model Class Initialized
INFO - 2017-03-06 01:16:12 --> Controller Class Initialized
DEBUG - 2017-03-06 01:16:12 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:16:12 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:16:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:16:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:16:28 --> Config Class Initialized
INFO - 2017-03-06 01:16:28 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:16:28 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:16:28 --> Utf8 Class Initialized
INFO - 2017-03-06 01:16:28 --> URI Class Initialized
INFO - 2017-03-06 01:16:28 --> Router Class Initialized
INFO - 2017-03-06 01:16:28 --> Output Class Initialized
INFO - 2017-03-06 01:16:28 --> Security Class Initialized
DEBUG - 2017-03-06 01:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:16:28 --> Input Class Initialized
INFO - 2017-03-06 01:16:28 --> Language Class Initialized
INFO - 2017-03-06 01:16:28 --> Language Class Initialized
INFO - 2017-03-06 01:16:28 --> Config Class Initialized
INFO - 2017-03-06 01:16:28 --> Loader Class Initialized
INFO - 2017-03-06 01:16:28 --> Helper loaded: form_helper
INFO - 2017-03-06 01:16:28 --> Helper loaded: url_helper
INFO - 2017-03-06 01:16:28 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:16:28 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:16:28 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:16:28 --> Template Class Initialized
INFO - 2017-03-06 01:16:28 --> Model Class Initialized
INFO - 2017-03-06 01:16:28 --> Controller Class Initialized
DEBUG - 2017-03-06 01:16:28 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:16:28 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:16:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:16:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 01:16:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 01:16:28 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 01:16:28 --> Final output sent to browser
DEBUG - 2017-03-06 01:16:28 --> Total execution time: 0.0158
INFO - 2017-03-06 01:16:29 --> Config Class Initialized
INFO - 2017-03-06 01:16:29 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:16:29 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:16:29 --> Utf8 Class Initialized
INFO - 2017-03-06 01:16:29 --> URI Class Initialized
INFO - 2017-03-06 01:16:29 --> Router Class Initialized
INFO - 2017-03-06 01:16:29 --> Output Class Initialized
INFO - 2017-03-06 01:16:29 --> Security Class Initialized
DEBUG - 2017-03-06 01:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:16:29 --> Input Class Initialized
INFO - 2017-03-06 01:16:29 --> Language Class Initialized
INFO - 2017-03-06 01:16:29 --> Language Class Initialized
INFO - 2017-03-06 01:16:29 --> Config Class Initialized
INFO - 2017-03-06 01:16:29 --> Loader Class Initialized
INFO - 2017-03-06 01:16:29 --> Helper loaded: form_helper
INFO - 2017-03-06 01:16:29 --> Helper loaded: url_helper
INFO - 2017-03-06 01:16:29 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:16:29 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:16:29 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:16:29 --> Template Class Initialized
INFO - 2017-03-06 01:16:29 --> Model Class Initialized
INFO - 2017-03-06 01:16:29 --> Controller Class Initialized
DEBUG - 2017-03-06 01:16:29 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:16:29 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:16:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:16:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:22:06 --> Config Class Initialized
INFO - 2017-03-06 01:22:06 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:22:06 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:22:06 --> Utf8 Class Initialized
INFO - 2017-03-06 01:22:06 --> URI Class Initialized
INFO - 2017-03-06 01:22:06 --> Router Class Initialized
INFO - 2017-03-06 01:22:06 --> Output Class Initialized
INFO - 2017-03-06 01:22:06 --> Security Class Initialized
DEBUG - 2017-03-06 01:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:22:06 --> Input Class Initialized
INFO - 2017-03-06 01:22:06 --> Language Class Initialized
INFO - 2017-03-06 01:22:06 --> Language Class Initialized
INFO - 2017-03-06 01:22:06 --> Config Class Initialized
INFO - 2017-03-06 01:22:06 --> Loader Class Initialized
INFO - 2017-03-06 01:22:06 --> Helper loaded: form_helper
INFO - 2017-03-06 01:22:06 --> Helper loaded: url_helper
INFO - 2017-03-06 01:22:06 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:22:06 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:22:06 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:22:06 --> Template Class Initialized
INFO - 2017-03-06 01:22:06 --> Model Class Initialized
INFO - 2017-03-06 01:22:06 --> Controller Class Initialized
DEBUG - 2017-03-06 01:22:06 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:22:06 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:22:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:22:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 01:22:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 01:22:06 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 01:22:06 --> Final output sent to browser
DEBUG - 2017-03-06 01:22:06 --> Total execution time: 0.0408
INFO - 2017-03-06 01:22:10 --> Config Class Initialized
INFO - 2017-03-06 01:22:10 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:22:10 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:22:10 --> Utf8 Class Initialized
INFO - 2017-03-06 01:22:10 --> URI Class Initialized
INFO - 2017-03-06 01:22:10 --> Router Class Initialized
INFO - 2017-03-06 01:22:10 --> Output Class Initialized
INFO - 2017-03-06 01:22:10 --> Security Class Initialized
DEBUG - 2017-03-06 01:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:22:10 --> Input Class Initialized
INFO - 2017-03-06 01:22:10 --> Language Class Initialized
INFO - 2017-03-06 01:22:10 --> Language Class Initialized
INFO - 2017-03-06 01:22:10 --> Config Class Initialized
INFO - 2017-03-06 01:22:10 --> Loader Class Initialized
INFO - 2017-03-06 01:22:10 --> Helper loaded: form_helper
INFO - 2017-03-06 01:22:10 --> Helper loaded: url_helper
INFO - 2017-03-06 01:22:10 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:22:10 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:22:10 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:22:10 --> Template Class Initialized
INFO - 2017-03-06 01:22:10 --> Model Class Initialized
INFO - 2017-03-06 01:22:10 --> Controller Class Initialized
DEBUG - 2017-03-06 01:22:10 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:22:10 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:22:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:22:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:22:10 --> Config Class Initialized
INFO - 2017-03-06 01:22:10 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:22:10 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:22:10 --> Utf8 Class Initialized
INFO - 2017-03-06 01:22:10 --> URI Class Initialized
INFO - 2017-03-06 01:22:10 --> Router Class Initialized
INFO - 2017-03-06 01:22:10 --> Output Class Initialized
INFO - 2017-03-06 01:22:10 --> Security Class Initialized
DEBUG - 2017-03-06 01:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:22:10 --> Input Class Initialized
INFO - 2017-03-06 01:22:10 --> Language Class Initialized
INFO - 2017-03-06 01:22:10 --> Language Class Initialized
INFO - 2017-03-06 01:22:10 --> Config Class Initialized
INFO - 2017-03-06 01:22:10 --> Loader Class Initialized
INFO - 2017-03-06 01:22:10 --> Helper loaded: form_helper
INFO - 2017-03-06 01:22:10 --> Helper loaded: url_helper
INFO - 2017-03-06 01:22:10 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:22:10 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:22:10 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:22:10 --> Template Class Initialized
INFO - 2017-03-06 01:22:10 --> Model Class Initialized
INFO - 2017-03-06 01:22:10 --> Controller Class Initialized
DEBUG - 2017-03-06 01:22:10 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:22:10 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:22:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:22:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:22:10 --> Config Class Initialized
INFO - 2017-03-06 01:22:10 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:22:10 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:22:10 --> Utf8 Class Initialized
INFO - 2017-03-06 01:22:10 --> URI Class Initialized
INFO - 2017-03-06 01:22:10 --> Router Class Initialized
INFO - 2017-03-06 01:22:10 --> Output Class Initialized
INFO - 2017-03-06 01:22:10 --> Security Class Initialized
DEBUG - 2017-03-06 01:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:22:10 --> Input Class Initialized
INFO - 2017-03-06 01:22:10 --> Language Class Initialized
INFO - 2017-03-06 01:22:10 --> Language Class Initialized
INFO - 2017-03-06 01:22:10 --> Config Class Initialized
INFO - 2017-03-06 01:22:10 --> Loader Class Initialized
INFO - 2017-03-06 01:22:10 --> Helper loaded: form_helper
INFO - 2017-03-06 01:22:10 --> Helper loaded: url_helper
INFO - 2017-03-06 01:22:10 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:22:10 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:22:10 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:22:10 --> Template Class Initialized
INFO - 2017-03-06 01:22:10 --> Model Class Initialized
INFO - 2017-03-06 01:22:10 --> Controller Class Initialized
DEBUG - 2017-03-06 01:22:10 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:22:10 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:22:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:22:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:22:30 --> Config Class Initialized
INFO - 2017-03-06 01:22:30 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:22:30 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:22:30 --> Utf8 Class Initialized
INFO - 2017-03-06 01:22:30 --> URI Class Initialized
INFO - 2017-03-06 01:22:30 --> Router Class Initialized
INFO - 2017-03-06 01:22:30 --> Output Class Initialized
INFO - 2017-03-06 01:22:30 --> Security Class Initialized
DEBUG - 2017-03-06 01:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:22:30 --> Input Class Initialized
INFO - 2017-03-06 01:22:30 --> Language Class Initialized
INFO - 2017-03-06 01:22:30 --> Language Class Initialized
INFO - 2017-03-06 01:22:30 --> Config Class Initialized
INFO - 2017-03-06 01:22:30 --> Loader Class Initialized
INFO - 2017-03-06 01:22:30 --> Helper loaded: form_helper
INFO - 2017-03-06 01:22:30 --> Helper loaded: url_helper
INFO - 2017-03-06 01:22:30 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:22:30 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:22:30 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:22:30 --> Template Class Initialized
INFO - 2017-03-06 01:22:30 --> Model Class Initialized
INFO - 2017-03-06 01:22:30 --> Controller Class Initialized
DEBUG - 2017-03-06 01:22:30 --> Login MX_Controller Initialized
INFO - 2017-03-06 01:22:30 --> Helper loaded: cookie_helper
INFO - 2017-03-06 01:22:30 --> Form Validation Class Initialized
INFO - 2017-03-06 01:22:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-06 01:22:30 --> Config Class Initialized
INFO - 2017-03-06 01:22:30 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:22:30 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:22:30 --> Utf8 Class Initialized
INFO - 2017-03-06 01:22:30 --> URI Class Initialized
INFO - 2017-03-06 01:22:30 --> Router Class Initialized
INFO - 2017-03-06 01:22:30 --> Output Class Initialized
INFO - 2017-03-06 01:22:30 --> Security Class Initialized
DEBUG - 2017-03-06 01:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:22:30 --> Input Class Initialized
INFO - 2017-03-06 01:22:30 --> Language Class Initialized
INFO - 2017-03-06 01:22:30 --> Language Class Initialized
INFO - 2017-03-06 01:22:30 --> Config Class Initialized
INFO - 2017-03-06 01:22:30 --> Loader Class Initialized
INFO - 2017-03-06 01:22:30 --> Helper loaded: form_helper
INFO - 2017-03-06 01:22:30 --> Helper loaded: url_helper
INFO - 2017-03-06 01:22:30 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:22:30 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:22:30 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:22:30 --> Template Class Initialized
INFO - 2017-03-06 01:22:30 --> Model Class Initialized
INFO - 2017-03-06 01:22:30 --> Controller Class Initialized
DEBUG - 2017-03-06 01:22:30 --> Dashboard MX_Controller Initialized
INFO - 2017-03-06 01:22:30 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:22:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 01:22:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 01:22:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 01:22:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-06 01:22:30 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 01:22:30 --> Final output sent to browser
DEBUG - 2017-03-06 01:22:30 --> Total execution time: 0.0678
INFO - 2017-03-06 01:22:35 --> Config Class Initialized
INFO - 2017-03-06 01:22:35 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:22:35 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:22:35 --> Utf8 Class Initialized
INFO - 2017-03-06 01:22:35 --> URI Class Initialized
INFO - 2017-03-06 01:22:35 --> Router Class Initialized
INFO - 2017-03-06 01:22:35 --> Output Class Initialized
INFO - 2017-03-06 01:22:35 --> Security Class Initialized
DEBUG - 2017-03-06 01:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:22:35 --> Input Class Initialized
INFO - 2017-03-06 01:22:35 --> Language Class Initialized
INFO - 2017-03-06 01:22:35 --> Language Class Initialized
INFO - 2017-03-06 01:22:35 --> Config Class Initialized
INFO - 2017-03-06 01:22:35 --> Loader Class Initialized
INFO - 2017-03-06 01:22:35 --> Helper loaded: form_helper
INFO - 2017-03-06 01:22:35 --> Helper loaded: url_helper
INFO - 2017-03-06 01:22:35 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:22:35 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:22:35 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:22:35 --> Template Class Initialized
INFO - 2017-03-06 01:22:35 --> Model Class Initialized
INFO - 2017-03-06 01:22:35 --> Controller Class Initialized
DEBUG - 2017-03-06 01:22:35 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:22:35 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:22:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:22:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:22:37 --> Config Class Initialized
INFO - 2017-03-06 01:22:37 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:22:37 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:22:37 --> Utf8 Class Initialized
INFO - 2017-03-06 01:22:37 --> URI Class Initialized
INFO - 2017-03-06 01:22:37 --> Router Class Initialized
INFO - 2017-03-06 01:22:37 --> Output Class Initialized
INFO - 2017-03-06 01:22:37 --> Security Class Initialized
DEBUG - 2017-03-06 01:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:22:37 --> Input Class Initialized
INFO - 2017-03-06 01:22:37 --> Language Class Initialized
INFO - 2017-03-06 01:22:37 --> Language Class Initialized
INFO - 2017-03-06 01:22:37 --> Config Class Initialized
INFO - 2017-03-06 01:22:37 --> Loader Class Initialized
INFO - 2017-03-06 01:22:37 --> Helper loaded: form_helper
INFO - 2017-03-06 01:22:37 --> Helper loaded: url_helper
INFO - 2017-03-06 01:22:37 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:22:37 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:22:37 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:22:37 --> Template Class Initialized
INFO - 2017-03-06 01:22:37 --> Model Class Initialized
INFO - 2017-03-06 01:22:37 --> Controller Class Initialized
DEBUG - 2017-03-06 01:22:37 --> Dashboard MX_Controller Initialized
INFO - 2017-03-06 01:22:37 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:22:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 01:22:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 01:22:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 01:22:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-06 01:22:37 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 01:22:37 --> Final output sent to browser
DEBUG - 2017-03-06 01:22:37 --> Total execution time: 0.0165
INFO - 2017-03-06 01:22:39 --> Config Class Initialized
INFO - 2017-03-06 01:22:39 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:22:39 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:22:39 --> Utf8 Class Initialized
INFO - 2017-03-06 01:22:39 --> URI Class Initialized
INFO - 2017-03-06 01:22:39 --> Router Class Initialized
INFO - 2017-03-06 01:22:39 --> Output Class Initialized
INFO - 2017-03-06 01:22:39 --> Security Class Initialized
DEBUG - 2017-03-06 01:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:22:39 --> Input Class Initialized
INFO - 2017-03-06 01:22:39 --> Language Class Initialized
INFO - 2017-03-06 01:22:39 --> Language Class Initialized
INFO - 2017-03-06 01:22:39 --> Config Class Initialized
INFO - 2017-03-06 01:22:39 --> Loader Class Initialized
INFO - 2017-03-06 01:22:39 --> Helper loaded: form_helper
INFO - 2017-03-06 01:22:39 --> Helper loaded: url_helper
INFO - 2017-03-06 01:22:39 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:22:39 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:22:39 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:22:39 --> Template Class Initialized
INFO - 2017-03-06 01:22:39 --> Model Class Initialized
INFO - 2017-03-06 01:22:39 --> Controller Class Initialized
DEBUG - 2017-03-06 01:22:39 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:22:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:22:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:22:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:23:16 --> Config Class Initialized
INFO - 2017-03-06 01:23:16 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:23:16 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:23:16 --> Utf8 Class Initialized
INFO - 2017-03-06 01:23:16 --> URI Class Initialized
INFO - 2017-03-06 01:23:16 --> Router Class Initialized
INFO - 2017-03-06 01:23:16 --> Output Class Initialized
INFO - 2017-03-06 01:23:16 --> Security Class Initialized
DEBUG - 2017-03-06 01:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:23:16 --> Input Class Initialized
INFO - 2017-03-06 01:23:16 --> Language Class Initialized
INFO - 2017-03-06 01:23:16 --> Language Class Initialized
INFO - 2017-03-06 01:23:16 --> Config Class Initialized
INFO - 2017-03-06 01:23:16 --> Loader Class Initialized
INFO - 2017-03-06 01:23:16 --> Helper loaded: form_helper
INFO - 2017-03-06 01:23:16 --> Helper loaded: url_helper
INFO - 2017-03-06 01:23:16 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:23:16 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:23:16 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:23:16 --> Template Class Initialized
INFO - 2017-03-06 01:23:16 --> Model Class Initialized
INFO - 2017-03-06 01:23:16 --> Controller Class Initialized
DEBUG - 2017-03-06 01:23:16 --> Dashboard MX_Controller Initialized
INFO - 2017-03-06 01:23:16 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:23:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 01:23:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 01:23:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 01:23:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-06 01:23:16 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 01:23:16 --> Final output sent to browser
DEBUG - 2017-03-06 01:23:16 --> Total execution time: 0.0176
INFO - 2017-03-06 01:23:31 --> Config Class Initialized
INFO - 2017-03-06 01:23:31 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:23:31 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:23:31 --> Utf8 Class Initialized
INFO - 2017-03-06 01:23:31 --> URI Class Initialized
INFO - 2017-03-06 01:23:31 --> Router Class Initialized
INFO - 2017-03-06 01:23:31 --> Output Class Initialized
INFO - 2017-03-06 01:23:31 --> Security Class Initialized
DEBUG - 2017-03-06 01:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:23:31 --> Input Class Initialized
INFO - 2017-03-06 01:23:31 --> Language Class Initialized
INFO - 2017-03-06 01:23:31 --> Language Class Initialized
INFO - 2017-03-06 01:23:31 --> Config Class Initialized
INFO - 2017-03-06 01:23:31 --> Loader Class Initialized
INFO - 2017-03-06 01:23:31 --> Helper loaded: form_helper
INFO - 2017-03-06 01:23:31 --> Helper loaded: url_helper
INFO - 2017-03-06 01:23:31 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:23:31 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:23:31 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:23:31 --> Template Class Initialized
INFO - 2017-03-06 01:23:31 --> Model Class Initialized
INFO - 2017-03-06 01:23:31 --> Controller Class Initialized
DEBUG - 2017-03-06 01:23:31 --> Setting MX_Controller Initialized
INFO - 2017-03-06 01:23:31 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:23:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 01:23:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 01:23:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 01:23:31 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/sync_with_card.php
DEBUG - 2017-03-06 01:23:31 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 01:23:31 --> Final output sent to browser
DEBUG - 2017-03-06 01:23:31 --> Total execution time: 0.0251
INFO - 2017-03-06 01:23:53 --> Config Class Initialized
INFO - 2017-03-06 01:23:53 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:23:53 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:23:53 --> Utf8 Class Initialized
INFO - 2017-03-06 01:23:53 --> URI Class Initialized
INFO - 2017-03-06 01:23:53 --> Router Class Initialized
INFO - 2017-03-06 01:23:53 --> Output Class Initialized
INFO - 2017-03-06 01:23:53 --> Security Class Initialized
DEBUG - 2017-03-06 01:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:23:53 --> Input Class Initialized
INFO - 2017-03-06 01:23:53 --> Language Class Initialized
INFO - 2017-03-06 01:23:53 --> Language Class Initialized
INFO - 2017-03-06 01:23:53 --> Config Class Initialized
INFO - 2017-03-06 01:23:53 --> Loader Class Initialized
INFO - 2017-03-06 01:23:53 --> Helper loaded: form_helper
INFO - 2017-03-06 01:23:53 --> Helper loaded: url_helper
INFO - 2017-03-06 01:23:53 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:23:53 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:23:53 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:23:53 --> Template Class Initialized
INFO - 2017-03-06 01:23:53 --> Model Class Initialized
INFO - 2017-03-06 01:23:53 --> Controller Class Initialized
DEBUG - 2017-03-06 01:23:53 --> Dashboard MX_Controller Initialized
INFO - 2017-03-06 01:23:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:23:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 01:23:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 01:23:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 01:23:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-06 01:23:53 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 01:23:53 --> Final output sent to browser
DEBUG - 2017-03-06 01:23:53 --> Total execution time: 0.0172
INFO - 2017-03-06 01:23:55 --> Config Class Initialized
INFO - 2017-03-06 01:23:55 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:23:55 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:23:55 --> Utf8 Class Initialized
INFO - 2017-03-06 01:23:55 --> URI Class Initialized
INFO - 2017-03-06 01:23:55 --> Router Class Initialized
INFO - 2017-03-06 01:23:55 --> Output Class Initialized
INFO - 2017-03-06 01:23:55 --> Security Class Initialized
DEBUG - 2017-03-06 01:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:23:55 --> Input Class Initialized
INFO - 2017-03-06 01:23:55 --> Language Class Initialized
INFO - 2017-03-06 01:23:55 --> Language Class Initialized
INFO - 2017-03-06 01:23:55 --> Config Class Initialized
INFO - 2017-03-06 01:23:55 --> Loader Class Initialized
INFO - 2017-03-06 01:23:55 --> Helper loaded: form_helper
INFO - 2017-03-06 01:23:55 --> Helper loaded: url_helper
INFO - 2017-03-06 01:23:55 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:23:55 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:23:55 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:23:55 --> Template Class Initialized
INFO - 2017-03-06 01:23:55 --> Model Class Initialized
INFO - 2017-03-06 01:23:55 --> Controller Class Initialized
DEBUG - 2017-03-06 01:23:55 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:23:55 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:23:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:23:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:24:09 --> Config Class Initialized
INFO - 2017-03-06 01:24:09 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:24:09 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:24:09 --> Utf8 Class Initialized
INFO - 2017-03-06 01:24:09 --> URI Class Initialized
INFO - 2017-03-06 01:24:09 --> Router Class Initialized
INFO - 2017-03-06 01:24:09 --> Output Class Initialized
INFO - 2017-03-06 01:24:09 --> Security Class Initialized
DEBUG - 2017-03-06 01:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:24:09 --> Input Class Initialized
INFO - 2017-03-06 01:24:09 --> Language Class Initialized
INFO - 2017-03-06 01:24:09 --> Language Class Initialized
INFO - 2017-03-06 01:24:09 --> Config Class Initialized
INFO - 2017-03-06 01:24:09 --> Loader Class Initialized
INFO - 2017-03-06 01:24:09 --> Helper loaded: form_helper
INFO - 2017-03-06 01:24:09 --> Helper loaded: url_helper
INFO - 2017-03-06 01:24:09 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:24:09 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:24:09 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:24:09 --> Template Class Initialized
INFO - 2017-03-06 01:24:09 --> Model Class Initialized
INFO - 2017-03-06 01:24:09 --> Controller Class Initialized
DEBUG - 2017-03-06 01:24:09 --> Project MX_Controller Initialized
INFO - 2017-03-06 01:24:09 --> Helper loaded: cookie_helper
INFO - 2017-03-06 01:24:09 --> Model Class Initialized
DEBUG - 2017-03-06 01:24:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 01:24:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 01:24:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 01:24:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-06 01:24:09 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 01:24:09 --> Final output sent to browser
DEBUG - 2017-03-06 01:24:09 --> Total execution time: 0.0455
INFO - 2017-03-06 01:24:10 --> Config Class Initialized
INFO - 2017-03-06 01:24:10 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:24:10 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:24:10 --> Utf8 Class Initialized
INFO - 2017-03-06 01:24:10 --> URI Class Initialized
INFO - 2017-03-06 01:24:10 --> Router Class Initialized
INFO - 2017-03-06 01:24:10 --> Output Class Initialized
INFO - 2017-03-06 01:24:10 --> Security Class Initialized
DEBUG - 2017-03-06 01:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:24:10 --> Input Class Initialized
INFO - 2017-03-06 01:24:10 --> Language Class Initialized
INFO - 2017-03-06 01:24:10 --> Language Class Initialized
INFO - 2017-03-06 01:24:10 --> Config Class Initialized
INFO - 2017-03-06 01:24:10 --> Loader Class Initialized
INFO - 2017-03-06 01:24:10 --> Helper loaded: form_helper
INFO - 2017-03-06 01:24:10 --> Helper loaded: url_helper
INFO - 2017-03-06 01:24:10 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:24:10 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:24:10 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:24:10 --> Template Class Initialized
INFO - 2017-03-06 01:24:10 --> Model Class Initialized
INFO - 2017-03-06 01:24:10 --> Controller Class Initialized
DEBUG - 2017-03-06 01:24:10 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:24:10 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:24:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:24:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:24:18 --> Config Class Initialized
INFO - 2017-03-06 01:24:18 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:24:18 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:24:18 --> Utf8 Class Initialized
INFO - 2017-03-06 01:24:18 --> URI Class Initialized
INFO - 2017-03-06 01:24:18 --> Router Class Initialized
INFO - 2017-03-06 01:24:18 --> Output Class Initialized
INFO - 2017-03-06 01:24:18 --> Security Class Initialized
DEBUG - 2017-03-06 01:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:24:18 --> Input Class Initialized
INFO - 2017-03-06 01:24:18 --> Language Class Initialized
INFO - 2017-03-06 01:24:18 --> Language Class Initialized
INFO - 2017-03-06 01:24:18 --> Config Class Initialized
INFO - 2017-03-06 01:24:18 --> Loader Class Initialized
INFO - 2017-03-06 01:24:18 --> Helper loaded: form_helper
INFO - 2017-03-06 01:24:18 --> Helper loaded: url_helper
INFO - 2017-03-06 01:24:18 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:24:18 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:24:18 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:24:18 --> Template Class Initialized
INFO - 2017-03-06 01:24:18 --> Model Class Initialized
INFO - 2017-03-06 01:24:18 --> Controller Class Initialized
DEBUG - 2017-03-06 01:24:18 --> Project MX_Controller Initialized
INFO - 2017-03-06 01:24:18 --> Helper loaded: cookie_helper
INFO - 2017-03-06 01:24:18 --> Final output sent to browser
DEBUG - 2017-03-06 01:24:18 --> Total execution time: 0.0153
INFO - 2017-03-06 01:24:28 --> Config Class Initialized
INFO - 2017-03-06 01:24:28 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:24:28 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:24:28 --> Utf8 Class Initialized
INFO - 2017-03-06 01:24:28 --> URI Class Initialized
INFO - 2017-03-06 01:24:28 --> Router Class Initialized
INFO - 2017-03-06 01:24:28 --> Output Class Initialized
INFO - 2017-03-06 01:24:28 --> Security Class Initialized
DEBUG - 2017-03-06 01:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:24:28 --> Input Class Initialized
INFO - 2017-03-06 01:24:28 --> Language Class Initialized
INFO - 2017-03-06 01:24:28 --> Language Class Initialized
INFO - 2017-03-06 01:24:28 --> Config Class Initialized
INFO - 2017-03-06 01:24:28 --> Loader Class Initialized
INFO - 2017-03-06 01:24:28 --> Helper loaded: form_helper
INFO - 2017-03-06 01:24:28 --> Helper loaded: url_helper
INFO - 2017-03-06 01:24:28 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:24:28 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:24:28 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:24:28 --> Template Class Initialized
INFO - 2017-03-06 01:24:28 --> Model Class Initialized
INFO - 2017-03-06 01:24:28 --> Controller Class Initialized
DEBUG - 2017-03-06 01:24:28 --> Project MX_Controller Initialized
INFO - 2017-03-06 01:24:28 --> Helper loaded: cookie_helper
INFO - 2017-03-06 01:24:28 --> Model Class Initialized
DEBUG - 2017-03-06 01:24:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 01:24:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 01:24:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 01:24:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-06 01:24:28 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 01:24:28 --> Final output sent to browser
DEBUG - 2017-03-06 01:24:28 --> Total execution time: 0.0181
INFO - 2017-03-06 01:24:30 --> Config Class Initialized
INFO - 2017-03-06 01:24:30 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:24:30 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:24:30 --> Utf8 Class Initialized
INFO - 2017-03-06 01:24:30 --> URI Class Initialized
INFO - 2017-03-06 01:24:30 --> Router Class Initialized
INFO - 2017-03-06 01:24:30 --> Output Class Initialized
INFO - 2017-03-06 01:24:30 --> Security Class Initialized
DEBUG - 2017-03-06 01:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:24:30 --> Input Class Initialized
INFO - 2017-03-06 01:24:30 --> Language Class Initialized
INFO - 2017-03-06 01:24:30 --> Language Class Initialized
INFO - 2017-03-06 01:24:30 --> Config Class Initialized
INFO - 2017-03-06 01:24:30 --> Loader Class Initialized
INFO - 2017-03-06 01:24:30 --> Helper loaded: form_helper
INFO - 2017-03-06 01:24:30 --> Helper loaded: url_helper
INFO - 2017-03-06 01:24:30 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:24:30 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:24:30 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:24:30 --> Template Class Initialized
INFO - 2017-03-06 01:24:30 --> Model Class Initialized
INFO - 2017-03-06 01:24:30 --> Controller Class Initialized
DEBUG - 2017-03-06 01:24:30 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:24:30 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:24:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:24:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:24:45 --> Config Class Initialized
INFO - 2017-03-06 01:24:45 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:24:45 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:24:45 --> Utf8 Class Initialized
INFO - 2017-03-06 01:24:45 --> URI Class Initialized
INFO - 2017-03-06 01:24:45 --> Router Class Initialized
INFO - 2017-03-06 01:24:45 --> Output Class Initialized
INFO - 2017-03-06 01:24:45 --> Security Class Initialized
DEBUG - 2017-03-06 01:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:24:45 --> Input Class Initialized
INFO - 2017-03-06 01:24:45 --> Language Class Initialized
INFO - 2017-03-06 01:24:45 --> Language Class Initialized
INFO - 2017-03-06 01:24:45 --> Config Class Initialized
INFO - 2017-03-06 01:24:45 --> Loader Class Initialized
INFO - 2017-03-06 01:24:45 --> Helper loaded: form_helper
INFO - 2017-03-06 01:24:45 --> Helper loaded: url_helper
INFO - 2017-03-06 01:24:45 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:24:45 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:24:45 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:24:45 --> Template Class Initialized
INFO - 2017-03-06 01:24:45 --> Model Class Initialized
INFO - 2017-03-06 01:24:45 --> Controller Class Initialized
DEBUG - 2017-03-06 01:24:45 --> Project MX_Controller Initialized
INFO - 2017-03-06 01:24:45 --> Helper loaded: cookie_helper
INFO - 2017-03-06 01:24:45 --> Final output sent to browser
DEBUG - 2017-03-06 01:24:45 --> Total execution time: 0.0138
INFO - 2017-03-06 01:36:05 --> Config Class Initialized
INFO - 2017-03-06 01:36:05 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:36:05 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:36:05 --> Utf8 Class Initialized
INFO - 2017-03-06 01:36:05 --> URI Class Initialized
INFO - 2017-03-06 01:36:05 --> Router Class Initialized
INFO - 2017-03-06 01:36:05 --> Output Class Initialized
INFO - 2017-03-06 01:36:05 --> Security Class Initialized
DEBUG - 2017-03-06 01:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:36:05 --> Input Class Initialized
INFO - 2017-03-06 01:36:05 --> Language Class Initialized
INFO - 2017-03-06 01:36:05 --> Language Class Initialized
INFO - 2017-03-06 01:36:05 --> Config Class Initialized
INFO - 2017-03-06 01:36:05 --> Loader Class Initialized
INFO - 2017-03-06 01:36:05 --> Helper loaded: form_helper
INFO - 2017-03-06 01:36:05 --> Helper loaded: url_helper
INFO - 2017-03-06 01:36:05 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:36:05 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:36:05 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:36:05 --> Template Class Initialized
INFO - 2017-03-06 01:36:05 --> Model Class Initialized
INFO - 2017-03-06 01:36:05 --> Controller Class Initialized
DEBUG - 2017-03-06 01:36:05 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:36:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:36:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:36:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 01:36:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 01:36:05 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 01:36:05 --> Final output sent to browser
DEBUG - 2017-03-06 01:36:05 --> Total execution time: 0.0634
INFO - 2017-03-06 01:36:06 --> Config Class Initialized
INFO - 2017-03-06 01:36:06 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:36:06 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:36:06 --> Utf8 Class Initialized
INFO - 2017-03-06 01:36:06 --> URI Class Initialized
INFO - 2017-03-06 01:36:06 --> Router Class Initialized
INFO - 2017-03-06 01:36:06 --> Output Class Initialized
INFO - 2017-03-06 01:36:06 --> Security Class Initialized
DEBUG - 2017-03-06 01:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:36:06 --> Input Class Initialized
INFO - 2017-03-06 01:36:06 --> Language Class Initialized
INFO - 2017-03-06 01:36:06 --> Language Class Initialized
INFO - 2017-03-06 01:36:06 --> Config Class Initialized
INFO - 2017-03-06 01:36:06 --> Loader Class Initialized
INFO - 2017-03-06 01:36:06 --> Helper loaded: form_helper
INFO - 2017-03-06 01:36:06 --> Helper loaded: url_helper
INFO - 2017-03-06 01:36:06 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:36:06 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:36:06 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:36:06 --> Template Class Initialized
INFO - 2017-03-06 01:36:06 --> Model Class Initialized
INFO - 2017-03-06 01:36:06 --> Controller Class Initialized
DEBUG - 2017-03-06 01:36:06 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:36:06 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:36:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:36:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:36:07 --> Config Class Initialized
INFO - 2017-03-06 01:36:07 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:36:07 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:36:07 --> Utf8 Class Initialized
INFO - 2017-03-06 01:36:07 --> URI Class Initialized
INFO - 2017-03-06 01:36:07 --> Router Class Initialized
INFO - 2017-03-06 01:36:07 --> Output Class Initialized
INFO - 2017-03-06 01:36:07 --> Security Class Initialized
DEBUG - 2017-03-06 01:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:36:07 --> Input Class Initialized
INFO - 2017-03-06 01:36:07 --> Language Class Initialized
INFO - 2017-03-06 01:36:07 --> Language Class Initialized
INFO - 2017-03-06 01:36:07 --> Config Class Initialized
INFO - 2017-03-06 01:36:07 --> Loader Class Initialized
INFO - 2017-03-06 01:36:07 --> Helper loaded: form_helper
INFO - 2017-03-06 01:36:07 --> Helper loaded: url_helper
INFO - 2017-03-06 01:36:07 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:36:07 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:36:07 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:36:07 --> Template Class Initialized
INFO - 2017-03-06 01:36:07 --> Model Class Initialized
INFO - 2017-03-06 01:36:07 --> Controller Class Initialized
DEBUG - 2017-03-06 01:36:07 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:36:07 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:36:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:36:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:36:08 --> Config Class Initialized
INFO - 2017-03-06 01:36:08 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:36:08 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:36:08 --> Utf8 Class Initialized
INFO - 2017-03-06 01:36:08 --> URI Class Initialized
INFO - 2017-03-06 01:36:08 --> Router Class Initialized
INFO - 2017-03-06 01:36:08 --> Output Class Initialized
INFO - 2017-03-06 01:36:08 --> Security Class Initialized
DEBUG - 2017-03-06 01:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:36:08 --> Input Class Initialized
INFO - 2017-03-06 01:36:08 --> Language Class Initialized
INFO - 2017-03-06 01:36:08 --> Language Class Initialized
INFO - 2017-03-06 01:36:08 --> Config Class Initialized
INFO - 2017-03-06 01:36:08 --> Loader Class Initialized
INFO - 2017-03-06 01:36:08 --> Helper loaded: form_helper
INFO - 2017-03-06 01:36:08 --> Helper loaded: url_helper
INFO - 2017-03-06 01:36:08 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:36:08 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:36:08 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:36:08 --> Template Class Initialized
INFO - 2017-03-06 01:36:08 --> Model Class Initialized
INFO - 2017-03-06 01:36:08 --> Controller Class Initialized
DEBUG - 2017-03-06 01:36:08 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:36:08 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:36:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:36:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 01:36:24 --> Config Class Initialized
INFO - 2017-03-06 01:36:24 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:36:24 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:36:24 --> Utf8 Class Initialized
INFO - 2017-03-06 01:36:24 --> URI Class Initialized
INFO - 2017-03-06 01:36:24 --> Router Class Initialized
INFO - 2017-03-06 01:36:24 --> Output Class Initialized
INFO - 2017-03-06 01:36:24 --> Security Class Initialized
DEBUG - 2017-03-06 01:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:36:24 --> Input Class Initialized
INFO - 2017-03-06 01:36:24 --> Language Class Initialized
INFO - 2017-03-06 01:36:24 --> Language Class Initialized
INFO - 2017-03-06 01:36:24 --> Config Class Initialized
INFO - 2017-03-06 01:36:24 --> Loader Class Initialized
INFO - 2017-03-06 01:36:24 --> Helper loaded: form_helper
INFO - 2017-03-06 01:36:24 --> Helper loaded: url_helper
INFO - 2017-03-06 01:36:24 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:36:24 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:36:24 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:36:24 --> Template Class Initialized
INFO - 2017-03-06 01:36:24 --> Model Class Initialized
INFO - 2017-03-06 01:36:24 --> Controller Class Initialized
DEBUG - 2017-03-06 01:36:24 --> Login MX_Controller Initialized
INFO - 2017-03-06 01:36:24 --> Helper loaded: cookie_helper
INFO - 2017-03-06 01:36:24 --> Form Validation Class Initialized
INFO - 2017-03-06 01:36:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-06 01:36:25 --> Config Class Initialized
INFO - 2017-03-06 01:36:25 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:36:25 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:36:25 --> Utf8 Class Initialized
INFO - 2017-03-06 01:36:25 --> URI Class Initialized
INFO - 2017-03-06 01:36:25 --> Router Class Initialized
INFO - 2017-03-06 01:36:25 --> Output Class Initialized
INFO - 2017-03-06 01:36:25 --> Security Class Initialized
DEBUG - 2017-03-06 01:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:36:25 --> Input Class Initialized
INFO - 2017-03-06 01:36:25 --> Language Class Initialized
INFO - 2017-03-06 01:36:25 --> Language Class Initialized
INFO - 2017-03-06 01:36:25 --> Config Class Initialized
INFO - 2017-03-06 01:36:25 --> Loader Class Initialized
INFO - 2017-03-06 01:36:25 --> Helper loaded: form_helper
INFO - 2017-03-06 01:36:25 --> Helper loaded: url_helper
INFO - 2017-03-06 01:36:25 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:36:25 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:36:25 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:36:25 --> Template Class Initialized
INFO - 2017-03-06 01:36:25 --> Model Class Initialized
INFO - 2017-03-06 01:36:25 --> Controller Class Initialized
DEBUG - 2017-03-06 01:36:25 --> Dashboard MX_Controller Initialized
INFO - 2017-03-06 01:36:25 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:36:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 01:36:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 01:36:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 01:36:25 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-06 01:36:25 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 01:36:25 --> Final output sent to browser
DEBUG - 2017-03-06 01:36:25 --> Total execution time: 0.0185
INFO - 2017-03-06 01:36:27 --> Config Class Initialized
INFO - 2017-03-06 01:36:27 --> Hooks Class Initialized
DEBUG - 2017-03-06 01:36:27 --> UTF-8 Support Enabled
INFO - 2017-03-06 01:36:27 --> Utf8 Class Initialized
INFO - 2017-03-06 01:36:27 --> URI Class Initialized
INFO - 2017-03-06 01:36:27 --> Router Class Initialized
INFO - 2017-03-06 01:36:27 --> Output Class Initialized
INFO - 2017-03-06 01:36:27 --> Security Class Initialized
DEBUG - 2017-03-06 01:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 01:36:27 --> Input Class Initialized
INFO - 2017-03-06 01:36:27 --> Language Class Initialized
INFO - 2017-03-06 01:36:27 --> Language Class Initialized
INFO - 2017-03-06 01:36:27 --> Config Class Initialized
INFO - 2017-03-06 01:36:27 --> Loader Class Initialized
INFO - 2017-03-06 01:36:27 --> Helper loaded: form_helper
INFO - 2017-03-06 01:36:27 --> Helper loaded: url_helper
INFO - 2017-03-06 01:36:27 --> Helper loaded: utility_helper
INFO - 2017-03-06 01:36:27 --> Database Driver Class Initialized
DEBUG - 2017-03-06 01:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 01:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 01:36:27 --> User Agent Class Initialized
DEBUG - 2017-03-06 01:36:27 --> Template Class Initialized
INFO - 2017-03-06 01:36:27 --> Model Class Initialized
INFO - 2017-03-06 01:36:27 --> Controller Class Initialized
DEBUG - 2017-03-06 01:36:27 --> Pages MX_Controller Initialized
INFO - 2017-03-06 01:36:27 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 01:36:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 01:36:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 03:51:46 --> Config Class Initialized
INFO - 2017-03-06 03:51:46 --> Hooks Class Initialized
DEBUG - 2017-03-06 03:51:46 --> UTF-8 Support Enabled
INFO - 2017-03-06 03:51:46 --> Utf8 Class Initialized
INFO - 2017-03-06 03:51:46 --> URI Class Initialized
DEBUG - 2017-03-06 03:51:46 --> No URI present. Default controller set.
INFO - 2017-03-06 03:51:46 --> Router Class Initialized
INFO - 2017-03-06 03:51:46 --> Output Class Initialized
INFO - 2017-03-06 03:51:46 --> Security Class Initialized
DEBUG - 2017-03-06 03:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 03:51:46 --> Input Class Initialized
INFO - 2017-03-06 03:51:46 --> Language Class Initialized
INFO - 2017-03-06 03:51:46 --> Language Class Initialized
INFO - 2017-03-06 03:51:46 --> Config Class Initialized
INFO - 2017-03-06 03:51:46 --> Loader Class Initialized
INFO - 2017-03-06 03:51:46 --> Helper loaded: form_helper
INFO - 2017-03-06 03:51:46 --> Helper loaded: url_helper
INFO - 2017-03-06 03:51:46 --> Helper loaded: utility_helper
INFO - 2017-03-06 03:51:46 --> Database Driver Class Initialized
DEBUG - 2017-03-06 03:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 03:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 03:51:47 --> User Agent Class Initialized
DEBUG - 2017-03-06 03:51:47 --> Template Class Initialized
INFO - 2017-03-06 03:51:47 --> Model Class Initialized
INFO - 2017-03-06 03:51:47 --> Controller Class Initialized
DEBUG - 2017-03-06 03:51:47 --> Pages MX_Controller Initialized
INFO - 2017-03-06 03:51:47 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 03:51:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 03:51:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 03:51:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-06 03:51:47 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 03:51:47 --> Final output sent to browser
DEBUG - 2017-03-06 03:51:47 --> Total execution time: 1.3001
INFO - 2017-03-06 03:51:54 --> Config Class Initialized
INFO - 2017-03-06 03:51:54 --> Hooks Class Initialized
DEBUG - 2017-03-06 03:51:54 --> UTF-8 Support Enabled
INFO - 2017-03-06 03:51:54 --> Utf8 Class Initialized
INFO - 2017-03-06 03:51:54 --> URI Class Initialized
INFO - 2017-03-06 03:51:54 --> Router Class Initialized
INFO - 2017-03-06 03:51:54 --> Output Class Initialized
INFO - 2017-03-06 03:51:54 --> Security Class Initialized
DEBUG - 2017-03-06 03:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 03:51:54 --> Input Class Initialized
INFO - 2017-03-06 03:51:54 --> Language Class Initialized
INFO - 2017-03-06 03:51:54 --> Language Class Initialized
INFO - 2017-03-06 03:51:54 --> Config Class Initialized
INFO - 2017-03-06 03:51:54 --> Loader Class Initialized
INFO - 2017-03-06 03:51:54 --> Helper loaded: form_helper
INFO - 2017-03-06 03:51:54 --> Helper loaded: url_helper
INFO - 2017-03-06 03:51:54 --> Helper loaded: utility_helper
INFO - 2017-03-06 03:51:54 --> Database Driver Class Initialized
DEBUG - 2017-03-06 03:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 03:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 03:51:54 --> User Agent Class Initialized
DEBUG - 2017-03-06 03:51:54 --> Template Class Initialized
INFO - 2017-03-06 03:51:54 --> Model Class Initialized
INFO - 2017-03-06 03:51:54 --> Controller Class Initialized
DEBUG - 2017-03-06 03:51:54 --> Pages MX_Controller Initialized
INFO - 2017-03-06 03:51:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 03:51:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 03:51:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 03:51:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-03-06 03:51:54 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 03:51:54 --> Final output sent to browser
DEBUG - 2017-03-06 03:51:54 --> Total execution time: 0.0200
INFO - 2017-03-06 03:53:56 --> Config Class Initialized
INFO - 2017-03-06 03:53:56 --> Hooks Class Initialized
DEBUG - 2017-03-06 03:53:56 --> UTF-8 Support Enabled
INFO - 2017-03-06 03:53:56 --> Utf8 Class Initialized
INFO - 2017-03-06 03:53:56 --> URI Class Initialized
DEBUG - 2017-03-06 03:53:56 --> No URI present. Default controller set.
INFO - 2017-03-06 03:53:56 --> Router Class Initialized
INFO - 2017-03-06 03:53:56 --> Output Class Initialized
INFO - 2017-03-06 03:53:56 --> Security Class Initialized
DEBUG - 2017-03-06 03:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 03:53:56 --> Input Class Initialized
INFO - 2017-03-06 03:53:56 --> Language Class Initialized
INFO - 2017-03-06 03:53:56 --> Language Class Initialized
INFO - 2017-03-06 03:53:56 --> Config Class Initialized
INFO - 2017-03-06 03:53:56 --> Loader Class Initialized
INFO - 2017-03-06 03:53:56 --> Helper loaded: form_helper
INFO - 2017-03-06 03:53:56 --> Helper loaded: url_helper
INFO - 2017-03-06 03:53:56 --> Helper loaded: utility_helper
INFO - 2017-03-06 03:53:56 --> Database Driver Class Initialized
DEBUG - 2017-03-06 03:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 03:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 03:53:56 --> User Agent Class Initialized
DEBUG - 2017-03-06 03:53:56 --> Template Class Initialized
INFO - 2017-03-06 03:53:56 --> Model Class Initialized
INFO - 2017-03-06 03:53:56 --> Controller Class Initialized
DEBUG - 2017-03-06 03:53:56 --> Pages MX_Controller Initialized
INFO - 2017-03-06 03:53:56 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 03:53:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 03:53:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 03:53:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-06 03:53:56 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 03:53:56 --> Final output sent to browser
DEBUG - 2017-03-06 03:53:56 --> Total execution time: 0.0158
INFO - 2017-03-06 03:54:00 --> Config Class Initialized
INFO - 2017-03-06 03:54:00 --> Hooks Class Initialized
DEBUG - 2017-03-06 03:54:00 --> UTF-8 Support Enabled
INFO - 2017-03-06 03:54:00 --> Utf8 Class Initialized
INFO - 2017-03-06 03:54:00 --> URI Class Initialized
INFO - 2017-03-06 03:54:00 --> Router Class Initialized
INFO - 2017-03-06 03:54:00 --> Output Class Initialized
INFO - 2017-03-06 03:54:00 --> Security Class Initialized
DEBUG - 2017-03-06 03:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 03:54:00 --> Input Class Initialized
INFO - 2017-03-06 03:54:00 --> Language Class Initialized
INFO - 2017-03-06 03:54:00 --> Language Class Initialized
INFO - 2017-03-06 03:54:00 --> Config Class Initialized
INFO - 2017-03-06 03:54:00 --> Loader Class Initialized
INFO - 2017-03-06 03:54:00 --> Helper loaded: form_helper
INFO - 2017-03-06 03:54:00 --> Helper loaded: url_helper
INFO - 2017-03-06 03:54:00 --> Helper loaded: utility_helper
INFO - 2017-03-06 03:54:00 --> Database Driver Class Initialized
DEBUG - 2017-03-06 03:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 03:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 03:54:00 --> User Agent Class Initialized
DEBUG - 2017-03-06 03:54:00 --> Template Class Initialized
INFO - 2017-03-06 03:54:00 --> Model Class Initialized
INFO - 2017-03-06 03:54:00 --> Controller Class Initialized
DEBUG - 2017-03-06 03:54:00 --> Pages MX_Controller Initialized
INFO - 2017-03-06 03:54:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 03:54:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 03:54:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 03:54:00 --> Config Class Initialized
INFO - 2017-03-06 03:54:00 --> Hooks Class Initialized
DEBUG - 2017-03-06 03:54:00 --> UTF-8 Support Enabled
INFO - 2017-03-06 03:54:00 --> Utf8 Class Initialized
INFO - 2017-03-06 03:54:00 --> URI Class Initialized
INFO - 2017-03-06 03:54:00 --> Router Class Initialized
INFO - 2017-03-06 03:54:00 --> Output Class Initialized
INFO - 2017-03-06 03:54:00 --> Security Class Initialized
DEBUG - 2017-03-06 03:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 03:54:00 --> Input Class Initialized
INFO - 2017-03-06 03:54:00 --> Language Class Initialized
INFO - 2017-03-06 03:54:00 --> Language Class Initialized
INFO - 2017-03-06 03:54:00 --> Config Class Initialized
INFO - 2017-03-06 03:54:00 --> Loader Class Initialized
INFO - 2017-03-06 03:54:00 --> Helper loaded: form_helper
INFO - 2017-03-06 03:54:00 --> Helper loaded: url_helper
INFO - 2017-03-06 03:54:00 --> Helper loaded: utility_helper
INFO - 2017-03-06 03:54:00 --> Database Driver Class Initialized
DEBUG - 2017-03-06 03:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 03:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 03:54:00 --> User Agent Class Initialized
DEBUG - 2017-03-06 03:54:00 --> Template Class Initialized
INFO - 2017-03-06 03:54:00 --> Model Class Initialized
INFO - 2017-03-06 03:54:00 --> Controller Class Initialized
DEBUG - 2017-03-06 03:54:00 --> Pages MX_Controller Initialized
INFO - 2017-03-06 03:54:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 03:54:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 03:54:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 03:54:01 --> Config Class Initialized
INFO - 2017-03-06 03:54:01 --> Hooks Class Initialized
DEBUG - 2017-03-06 03:54:01 --> UTF-8 Support Enabled
INFO - 2017-03-06 03:54:01 --> Utf8 Class Initialized
INFO - 2017-03-06 03:54:01 --> URI Class Initialized
INFO - 2017-03-06 03:54:01 --> Router Class Initialized
INFO - 2017-03-06 03:54:01 --> Output Class Initialized
INFO - 2017-03-06 03:54:01 --> Security Class Initialized
DEBUG - 2017-03-06 03:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 03:54:01 --> Input Class Initialized
INFO - 2017-03-06 03:54:01 --> Language Class Initialized
INFO - 2017-03-06 03:54:01 --> Language Class Initialized
INFO - 2017-03-06 03:54:01 --> Config Class Initialized
INFO - 2017-03-06 03:54:01 --> Loader Class Initialized
INFO - 2017-03-06 03:54:01 --> Helper loaded: form_helper
INFO - 2017-03-06 03:54:01 --> Helper loaded: url_helper
INFO - 2017-03-06 03:54:01 --> Helper loaded: utility_helper
INFO - 2017-03-06 03:54:01 --> Database Driver Class Initialized
DEBUG - 2017-03-06 03:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 03:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 03:54:01 --> User Agent Class Initialized
DEBUG - 2017-03-06 03:54:01 --> Template Class Initialized
INFO - 2017-03-06 03:54:01 --> Model Class Initialized
INFO - 2017-03-06 03:54:01 --> Controller Class Initialized
DEBUG - 2017-03-06 03:54:01 --> Pages MX_Controller Initialized
INFO - 2017-03-06 03:54:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 03:54:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 03:54:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 03:54:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-03-06 03:54:01 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 03:54:01 --> Final output sent to browser
DEBUG - 2017-03-06 03:54:01 --> Total execution time: 0.0212
INFO - 2017-03-06 03:54:01 --> Config Class Initialized
INFO - 2017-03-06 03:54:01 --> Hooks Class Initialized
DEBUG - 2017-03-06 03:54:01 --> UTF-8 Support Enabled
INFO - 2017-03-06 03:54:01 --> Utf8 Class Initialized
INFO - 2017-03-06 03:54:01 --> URI Class Initialized
INFO - 2017-03-06 03:54:01 --> Router Class Initialized
INFO - 2017-03-06 03:54:01 --> Output Class Initialized
INFO - 2017-03-06 03:54:01 --> Security Class Initialized
DEBUG - 2017-03-06 03:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 03:54:01 --> Input Class Initialized
INFO - 2017-03-06 03:54:01 --> Language Class Initialized
INFO - 2017-03-06 03:54:01 --> Language Class Initialized
INFO - 2017-03-06 03:54:01 --> Config Class Initialized
INFO - 2017-03-06 03:54:01 --> Loader Class Initialized
INFO - 2017-03-06 03:54:01 --> Helper loaded: form_helper
INFO - 2017-03-06 03:54:01 --> Helper loaded: url_helper
INFO - 2017-03-06 03:54:03 --> Helper loaded: utility_helper
INFO - 2017-03-06 03:54:03 --> Database Driver Class Initialized
DEBUG - 2017-03-06 03:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 03:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 03:54:03 --> User Agent Class Initialized
DEBUG - 2017-03-06 03:54:03 --> Template Class Initialized
INFO - 2017-03-06 03:54:03 --> Model Class Initialized
INFO - 2017-03-06 03:54:03 --> Controller Class Initialized
DEBUG - 2017-03-06 03:54:03 --> Pages MX_Controller Initialized
INFO - 2017-03-06 03:54:03 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 03:54:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 03:54:03 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 04:13:14 --> Config Class Initialized
INFO - 2017-03-06 04:13:14 --> Hooks Class Initialized
DEBUG - 2017-03-06 04:13:14 --> UTF-8 Support Enabled
INFO - 2017-03-06 04:13:14 --> Utf8 Class Initialized
INFO - 2017-03-06 04:13:14 --> URI Class Initialized
DEBUG - 2017-03-06 04:13:14 --> No URI present. Default controller set.
INFO - 2017-03-06 04:13:14 --> Router Class Initialized
INFO - 2017-03-06 04:13:14 --> Output Class Initialized
INFO - 2017-03-06 04:13:14 --> Security Class Initialized
DEBUG - 2017-03-06 04:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 04:13:14 --> Input Class Initialized
INFO - 2017-03-06 04:13:14 --> Language Class Initialized
INFO - 2017-03-06 04:13:14 --> Language Class Initialized
INFO - 2017-03-06 04:13:14 --> Config Class Initialized
INFO - 2017-03-06 04:13:14 --> Loader Class Initialized
INFO - 2017-03-06 04:13:14 --> Helper loaded: form_helper
INFO - 2017-03-06 04:13:14 --> Helper loaded: url_helper
INFO - 2017-03-06 04:13:14 --> Helper loaded: utility_helper
INFO - 2017-03-06 04:13:14 --> Database Driver Class Initialized
DEBUG - 2017-03-06 04:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 04:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 04:13:14 --> User Agent Class Initialized
DEBUG - 2017-03-06 04:13:14 --> Template Class Initialized
INFO - 2017-03-06 04:13:14 --> Model Class Initialized
INFO - 2017-03-06 04:13:14 --> Controller Class Initialized
DEBUG - 2017-03-06 04:13:14 --> Pages MX_Controller Initialized
INFO - 2017-03-06 04:13:14 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 04:13:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 04:13:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 04:13:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-06 04:13:14 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 04:13:14 --> Final output sent to browser
DEBUG - 2017-03-06 04:13:14 --> Total execution time: 0.0636
INFO - 2017-03-06 04:13:14 --> Config Class Initialized
INFO - 2017-03-06 04:13:14 --> Hooks Class Initialized
DEBUG - 2017-03-06 04:13:14 --> UTF-8 Support Enabled
INFO - 2017-03-06 04:13:14 --> Utf8 Class Initialized
INFO - 2017-03-06 04:13:14 --> URI Class Initialized
INFO - 2017-03-06 04:13:14 --> Router Class Initialized
INFO - 2017-03-06 04:13:14 --> Output Class Initialized
INFO - 2017-03-06 04:13:14 --> Security Class Initialized
DEBUG - 2017-03-06 04:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 04:13:14 --> Input Class Initialized
INFO - 2017-03-06 04:13:14 --> Language Class Initialized
INFO - 2017-03-06 04:13:14 --> Language Class Initialized
INFO - 2017-03-06 04:13:14 --> Config Class Initialized
INFO - 2017-03-06 04:13:14 --> Loader Class Initialized
INFO - 2017-03-06 04:13:14 --> Helper loaded: form_helper
INFO - 2017-03-06 04:13:14 --> Helper loaded: url_helper
INFO - 2017-03-06 04:13:14 --> Helper loaded: utility_helper
INFO - 2017-03-06 04:13:14 --> Database Driver Class Initialized
DEBUG - 2017-03-06 04:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 04:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 04:13:14 --> User Agent Class Initialized
DEBUG - 2017-03-06 04:13:14 --> Template Class Initialized
INFO - 2017-03-06 04:13:14 --> Model Class Initialized
INFO - 2017-03-06 04:13:14 --> Controller Class Initialized
DEBUG - 2017-03-06 04:13:14 --> Pages MX_Controller Initialized
INFO - 2017-03-06 04:13:14 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 04:13:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 04:13:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 04:13:14 --> Config Class Initialized
INFO - 2017-03-06 04:13:14 --> Hooks Class Initialized
DEBUG - 2017-03-06 04:13:14 --> UTF-8 Support Enabled
INFO - 2017-03-06 04:13:14 --> Utf8 Class Initialized
INFO - 2017-03-06 04:13:14 --> URI Class Initialized
INFO - 2017-03-06 04:13:14 --> Router Class Initialized
INFO - 2017-03-06 04:13:14 --> Output Class Initialized
INFO - 2017-03-06 04:13:14 --> Security Class Initialized
DEBUG - 2017-03-06 04:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 04:13:14 --> Input Class Initialized
INFO - 2017-03-06 04:13:14 --> Language Class Initialized
INFO - 2017-03-06 04:13:14 --> Language Class Initialized
INFO - 2017-03-06 04:13:14 --> Config Class Initialized
INFO - 2017-03-06 04:13:14 --> Loader Class Initialized
INFO - 2017-03-06 04:13:14 --> Helper loaded: form_helper
INFO - 2017-03-06 04:13:14 --> Helper loaded: url_helper
INFO - 2017-03-06 04:13:14 --> Helper loaded: utility_helper
INFO - 2017-03-06 04:13:14 --> Database Driver Class Initialized
DEBUG - 2017-03-06 04:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 04:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 04:13:14 --> User Agent Class Initialized
DEBUG - 2017-03-06 04:13:14 --> Template Class Initialized
INFO - 2017-03-06 04:13:14 --> Model Class Initialized
INFO - 2017-03-06 04:13:14 --> Controller Class Initialized
DEBUG - 2017-03-06 04:13:14 --> Pages MX_Controller Initialized
INFO - 2017-03-06 04:13:14 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 04:13:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 04:13:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:37:49 --> Config Class Initialized
INFO - 2017-03-06 06:37:49 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:37:49 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:37:49 --> Utf8 Class Initialized
INFO - 2017-03-06 06:37:49 --> URI Class Initialized
DEBUG - 2017-03-06 06:37:50 --> No URI present. Default controller set.
INFO - 2017-03-06 06:37:50 --> Router Class Initialized
INFO - 2017-03-06 06:37:50 --> Output Class Initialized
INFO - 2017-03-06 06:37:50 --> Security Class Initialized
DEBUG - 2017-03-06 06:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:37:50 --> Input Class Initialized
INFO - 2017-03-06 06:37:50 --> Language Class Initialized
INFO - 2017-03-06 06:37:50 --> Language Class Initialized
INFO - 2017-03-06 06:37:50 --> Config Class Initialized
INFO - 2017-03-06 06:37:50 --> Loader Class Initialized
INFO - 2017-03-06 06:37:50 --> Helper loaded: form_helper
INFO - 2017-03-06 06:37:50 --> Helper loaded: url_helper
INFO - 2017-03-06 06:37:50 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:37:50 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:37:50 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:37:50 --> Template Class Initialized
INFO - 2017-03-06 06:37:50 --> Model Class Initialized
INFO - 2017-03-06 06:37:50 --> Controller Class Initialized
DEBUG - 2017-03-06 06:37:50 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:37:50 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:37:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:37:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 06:37:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-06 06:37:50 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 06:37:50 --> Final output sent to browser
DEBUG - 2017-03-06 06:37:50 --> Total execution time: 0.4017
INFO - 2017-03-06 06:37:51 --> Config Class Initialized
INFO - 2017-03-06 06:37:51 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:37:51 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:37:51 --> Utf8 Class Initialized
INFO - 2017-03-06 06:37:51 --> URI Class Initialized
INFO - 2017-03-06 06:37:51 --> Router Class Initialized
INFO - 2017-03-06 06:37:51 --> Output Class Initialized
INFO - 2017-03-06 06:37:51 --> Security Class Initialized
DEBUG - 2017-03-06 06:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:37:51 --> Input Class Initialized
INFO - 2017-03-06 06:37:51 --> Language Class Initialized
INFO - 2017-03-06 06:37:51 --> Language Class Initialized
INFO - 2017-03-06 06:37:51 --> Config Class Initialized
INFO - 2017-03-06 06:37:51 --> Loader Class Initialized
INFO - 2017-03-06 06:37:51 --> Helper loaded: form_helper
INFO - 2017-03-06 06:37:51 --> Helper loaded: url_helper
INFO - 2017-03-06 06:37:51 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:37:51 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:37:51 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:37:51 --> Template Class Initialized
INFO - 2017-03-06 06:37:51 --> Model Class Initialized
INFO - 2017-03-06 06:37:51 --> Controller Class Initialized
DEBUG - 2017-03-06 06:37:51 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:37:51 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:37:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:37:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:37:51 --> Config Class Initialized
INFO - 2017-03-06 06:37:51 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:37:51 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:37:51 --> Utf8 Class Initialized
INFO - 2017-03-06 06:37:51 --> URI Class Initialized
INFO - 2017-03-06 06:37:51 --> Router Class Initialized
INFO - 2017-03-06 06:37:51 --> Output Class Initialized
INFO - 2017-03-06 06:37:51 --> Security Class Initialized
DEBUG - 2017-03-06 06:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:37:51 --> Input Class Initialized
INFO - 2017-03-06 06:37:51 --> Language Class Initialized
INFO - 2017-03-06 06:37:51 --> Language Class Initialized
INFO - 2017-03-06 06:37:51 --> Config Class Initialized
INFO - 2017-03-06 06:37:51 --> Loader Class Initialized
INFO - 2017-03-06 06:37:51 --> Helper loaded: form_helper
INFO - 2017-03-06 06:37:51 --> Helper loaded: url_helper
INFO - 2017-03-06 06:37:51 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:37:51 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:37:51 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:37:51 --> Template Class Initialized
INFO - 2017-03-06 06:37:51 --> Model Class Initialized
INFO - 2017-03-06 06:37:51 --> Controller Class Initialized
DEBUG - 2017-03-06 06:37:51 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:37:51 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:37:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:37:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:37:53 --> Config Class Initialized
INFO - 2017-03-06 06:37:53 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:37:53 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:37:53 --> Utf8 Class Initialized
INFO - 2017-03-06 06:37:53 --> URI Class Initialized
INFO - 2017-03-06 06:37:53 --> Router Class Initialized
INFO - 2017-03-06 06:37:53 --> Output Class Initialized
INFO - 2017-03-06 06:37:53 --> Security Class Initialized
DEBUG - 2017-03-06 06:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:37:53 --> Input Class Initialized
INFO - 2017-03-06 06:37:53 --> Language Class Initialized
INFO - 2017-03-06 06:37:53 --> Language Class Initialized
INFO - 2017-03-06 06:37:53 --> Config Class Initialized
INFO - 2017-03-06 06:37:53 --> Loader Class Initialized
INFO - 2017-03-06 06:37:53 --> Helper loaded: form_helper
INFO - 2017-03-06 06:37:53 --> Helper loaded: url_helper
INFO - 2017-03-06 06:37:53 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:37:53 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:37:53 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:37:53 --> Template Class Initialized
INFO - 2017-03-06 06:37:53 --> Model Class Initialized
INFO - 2017-03-06 06:37:53 --> Controller Class Initialized
DEBUG - 2017-03-06 06:37:53 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:37:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:37:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:37:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:37:57 --> Config Class Initialized
INFO - 2017-03-06 06:37:57 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:37:57 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:37:57 --> Utf8 Class Initialized
INFO - 2017-03-06 06:37:57 --> URI Class Initialized
INFO - 2017-03-06 06:37:57 --> Router Class Initialized
INFO - 2017-03-06 06:37:57 --> Output Class Initialized
INFO - 2017-03-06 06:37:57 --> Security Class Initialized
DEBUG - 2017-03-06 06:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:37:57 --> Input Class Initialized
INFO - 2017-03-06 06:37:57 --> Language Class Initialized
INFO - 2017-03-06 06:37:57 --> Language Class Initialized
INFO - 2017-03-06 06:37:57 --> Config Class Initialized
INFO - 2017-03-06 06:37:57 --> Loader Class Initialized
INFO - 2017-03-06 06:37:57 --> Helper loaded: form_helper
INFO - 2017-03-06 06:37:57 --> Helper loaded: url_helper
INFO - 2017-03-06 06:37:57 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:37:57 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:37:57 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:37:57 --> Template Class Initialized
INFO - 2017-03-06 06:37:57 --> Model Class Initialized
INFO - 2017-03-06 06:37:57 --> Controller Class Initialized
DEBUG - 2017-03-06 06:37:57 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:37:57 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:37:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:37:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:37:57 --> Config Class Initialized
INFO - 2017-03-06 06:37:57 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:37:57 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:37:57 --> Utf8 Class Initialized
INFO - 2017-03-06 06:37:57 --> URI Class Initialized
INFO - 2017-03-06 06:37:57 --> Router Class Initialized
INFO - 2017-03-06 06:37:57 --> Output Class Initialized
INFO - 2017-03-06 06:37:57 --> Security Class Initialized
DEBUG - 2017-03-06 06:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:37:57 --> Input Class Initialized
INFO - 2017-03-06 06:37:57 --> Language Class Initialized
INFO - 2017-03-06 06:37:57 --> Language Class Initialized
INFO - 2017-03-06 06:37:57 --> Config Class Initialized
INFO - 2017-03-06 06:37:57 --> Loader Class Initialized
INFO - 2017-03-06 06:37:57 --> Helper loaded: form_helper
INFO - 2017-03-06 06:37:57 --> Helper loaded: url_helper
INFO - 2017-03-06 06:37:57 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:37:57 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:37:57 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:37:57 --> Template Class Initialized
INFO - 2017-03-06 06:37:57 --> Model Class Initialized
INFO - 2017-03-06 06:37:57 --> Controller Class Initialized
DEBUG - 2017-03-06 06:37:57 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:37:57 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:37:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:37:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 06:37:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 06:37:57 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 06:37:57 --> Final output sent to browser
DEBUG - 2017-03-06 06:37:57 --> Total execution time: 0.0335
INFO - 2017-03-06 06:37:57 --> Config Class Initialized
INFO - 2017-03-06 06:37:57 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:37:57 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:37:57 --> Utf8 Class Initialized
INFO - 2017-03-06 06:37:57 --> URI Class Initialized
INFO - 2017-03-06 06:37:57 --> Router Class Initialized
INFO - 2017-03-06 06:37:57 --> Output Class Initialized
INFO - 2017-03-06 06:37:57 --> Security Class Initialized
DEBUG - 2017-03-06 06:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:37:57 --> Input Class Initialized
INFO - 2017-03-06 06:37:57 --> Language Class Initialized
INFO - 2017-03-06 06:37:57 --> Language Class Initialized
INFO - 2017-03-06 06:37:57 --> Config Class Initialized
INFO - 2017-03-06 06:37:57 --> Loader Class Initialized
INFO - 2017-03-06 06:37:57 --> Helper loaded: form_helper
INFO - 2017-03-06 06:37:57 --> Helper loaded: url_helper
INFO - 2017-03-06 06:37:57 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:37:57 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:37:57 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:37:57 --> Template Class Initialized
INFO - 2017-03-06 06:37:57 --> Model Class Initialized
INFO - 2017-03-06 06:37:57 --> Controller Class Initialized
DEBUG - 2017-03-06 06:37:57 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:37:57 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:37:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:37:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:37:58 --> Config Class Initialized
INFO - 2017-03-06 06:37:58 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:37:58 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:37:58 --> Utf8 Class Initialized
INFO - 2017-03-06 06:37:58 --> URI Class Initialized
INFO - 2017-03-06 06:37:58 --> Router Class Initialized
INFO - 2017-03-06 06:37:58 --> Output Class Initialized
INFO - 2017-03-06 06:37:58 --> Security Class Initialized
DEBUG - 2017-03-06 06:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:37:58 --> Input Class Initialized
INFO - 2017-03-06 06:37:58 --> Language Class Initialized
INFO - 2017-03-06 06:37:58 --> Language Class Initialized
INFO - 2017-03-06 06:37:58 --> Config Class Initialized
INFO - 2017-03-06 06:37:58 --> Loader Class Initialized
INFO - 2017-03-06 06:37:58 --> Helper loaded: form_helper
INFO - 2017-03-06 06:37:58 --> Helper loaded: url_helper
INFO - 2017-03-06 06:37:58 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:37:58 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:37:58 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:37:58 --> Template Class Initialized
INFO - 2017-03-06 06:37:58 --> Model Class Initialized
INFO - 2017-03-06 06:37:58 --> Controller Class Initialized
DEBUG - 2017-03-06 06:37:58 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:37:58 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:37:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:37:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:38:07 --> Config Class Initialized
INFO - 2017-03-06 06:38:07 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:07 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:07 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:07 --> URI Class Initialized
INFO - 2017-03-06 06:38:07 --> Router Class Initialized
INFO - 2017-03-06 06:38:07 --> Output Class Initialized
INFO - 2017-03-06 06:38:07 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:07 --> Input Class Initialized
INFO - 2017-03-06 06:38:07 --> Language Class Initialized
INFO - 2017-03-06 06:38:07 --> Language Class Initialized
INFO - 2017-03-06 06:38:07 --> Config Class Initialized
INFO - 2017-03-06 06:38:07 --> Loader Class Initialized
INFO - 2017-03-06 06:38:07 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:07 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:07 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:07 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:07 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:07 --> Template Class Initialized
INFO - 2017-03-06 06:38:07 --> Model Class Initialized
INFO - 2017-03-06 06:38:07 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:07 --> Login MX_Controller Initialized
INFO - 2017-03-06 06:38:07 --> Helper loaded: cookie_helper
INFO - 2017-03-06 06:38:07 --> Form Validation Class Initialized
INFO - 2017-03-06 06:38:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-06 06:38:08 --> Config Class Initialized
INFO - 2017-03-06 06:38:08 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:08 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:08 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:08 --> URI Class Initialized
INFO - 2017-03-06 06:38:08 --> Router Class Initialized
INFO - 2017-03-06 06:38:08 --> Output Class Initialized
INFO - 2017-03-06 06:38:08 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:08 --> Input Class Initialized
INFO - 2017-03-06 06:38:08 --> Language Class Initialized
INFO - 2017-03-06 06:38:08 --> Language Class Initialized
INFO - 2017-03-06 06:38:08 --> Config Class Initialized
INFO - 2017-03-06 06:38:08 --> Loader Class Initialized
INFO - 2017-03-06 06:38:08 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:08 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:08 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:08 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:08 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:08 --> Template Class Initialized
INFO - 2017-03-06 06:38:08 --> Model Class Initialized
INFO - 2017-03-06 06:38:08 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:08 --> Dashboard MX_Controller Initialized
INFO - 2017-03-06 06:38:08 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:38:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 06:38:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 06:38:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 06:38:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-06 06:38:08 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 06:38:08 --> Final output sent to browser
DEBUG - 2017-03-06 06:38:08 --> Total execution time: 0.0595
INFO - 2017-03-06 06:38:10 --> Config Class Initialized
INFO - 2017-03-06 06:38:10 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:10 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:10 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:10 --> URI Class Initialized
INFO - 2017-03-06 06:38:10 --> Router Class Initialized
INFO - 2017-03-06 06:38:10 --> Output Class Initialized
INFO - 2017-03-06 06:38:10 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:10 --> Input Class Initialized
INFO - 2017-03-06 06:38:10 --> Language Class Initialized
INFO - 2017-03-06 06:38:10 --> Language Class Initialized
INFO - 2017-03-06 06:38:10 --> Config Class Initialized
INFO - 2017-03-06 06:38:10 --> Loader Class Initialized
INFO - 2017-03-06 06:38:10 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:10 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:10 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:10 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:10 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:10 --> Template Class Initialized
INFO - 2017-03-06 06:38:10 --> Model Class Initialized
INFO - 2017-03-06 06:38:10 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:10 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:38:10 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:38:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:38:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:38:16 --> Config Class Initialized
INFO - 2017-03-06 06:38:16 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:16 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:16 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:16 --> URI Class Initialized
INFO - 2017-03-06 06:38:16 --> Router Class Initialized
INFO - 2017-03-06 06:38:16 --> Output Class Initialized
INFO - 2017-03-06 06:38:16 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:16 --> Input Class Initialized
INFO - 2017-03-06 06:38:16 --> Language Class Initialized
INFO - 2017-03-06 06:38:16 --> Language Class Initialized
INFO - 2017-03-06 06:38:16 --> Config Class Initialized
INFO - 2017-03-06 06:38:16 --> Loader Class Initialized
INFO - 2017-03-06 06:38:16 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:16 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:16 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:16 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:16 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:16 --> Template Class Initialized
INFO - 2017-03-06 06:38:16 --> Model Class Initialized
INFO - 2017-03-06 06:38:16 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:16 --> Project MX_Controller Initialized
INFO - 2017-03-06 06:38:16 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:38:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 06:38:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 06:38:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 06:38:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-06 06:38:16 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 06:38:16 --> Final output sent to browser
DEBUG - 2017-03-06 06:38:16 --> Total execution time: 0.0323
INFO - 2017-03-06 06:38:17 --> Config Class Initialized
INFO - 2017-03-06 06:38:17 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:17 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:17 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:17 --> URI Class Initialized
INFO - 2017-03-06 06:38:17 --> Router Class Initialized
INFO - 2017-03-06 06:38:17 --> Output Class Initialized
INFO - 2017-03-06 06:38:17 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:17 --> Input Class Initialized
INFO - 2017-03-06 06:38:17 --> Language Class Initialized
INFO - 2017-03-06 06:38:17 --> Language Class Initialized
INFO - 2017-03-06 06:38:17 --> Config Class Initialized
INFO - 2017-03-06 06:38:17 --> Loader Class Initialized
INFO - 2017-03-06 06:38:17 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:17 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:17 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:17 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:17 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:17 --> Template Class Initialized
INFO - 2017-03-06 06:38:17 --> Model Class Initialized
INFO - 2017-03-06 06:38:17 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:17 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:38:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:38:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:38:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:38:21 --> Config Class Initialized
INFO - 2017-03-06 06:38:21 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:21 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:21 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:21 --> URI Class Initialized
INFO - 2017-03-06 06:38:21 --> Router Class Initialized
INFO - 2017-03-06 06:38:21 --> Output Class Initialized
INFO - 2017-03-06 06:38:21 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:21 --> Input Class Initialized
INFO - 2017-03-06 06:38:21 --> Language Class Initialized
INFO - 2017-03-06 06:38:21 --> Language Class Initialized
INFO - 2017-03-06 06:38:21 --> Config Class Initialized
INFO - 2017-03-06 06:38:21 --> Loader Class Initialized
INFO - 2017-03-06 06:38:21 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:21 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:21 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:21 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:21 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:21 --> Template Class Initialized
INFO - 2017-03-06 06:38:21 --> Model Class Initialized
INFO - 2017-03-06 06:38:21 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:21 --> Project MX_Controller Initialized
INFO - 2017-03-06 06:38:21 --> Helper loaded: cookie_helper
INFO - 2017-03-06 06:38:21 --> Model Class Initialized
INFO - 2017-03-06 06:38:21 --> Config Class Initialized
INFO - 2017-03-06 06:38:21 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:21 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:21 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:21 --> URI Class Initialized
INFO - 2017-03-06 06:38:21 --> Router Class Initialized
INFO - 2017-03-06 06:38:21 --> Output Class Initialized
INFO - 2017-03-06 06:38:21 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:21 --> Input Class Initialized
INFO - 2017-03-06 06:38:21 --> Language Class Initialized
INFO - 2017-03-06 06:38:21 --> Language Class Initialized
INFO - 2017-03-06 06:38:21 --> Config Class Initialized
INFO - 2017-03-06 06:38:21 --> Loader Class Initialized
INFO - 2017-03-06 06:38:21 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:21 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:21 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:21 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:21 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:21 --> Template Class Initialized
INFO - 2017-03-06 06:38:21 --> Model Class Initialized
INFO - 2017-03-06 06:38:21 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:21 --> Project MX_Controller Initialized
INFO - 2017-03-06 06:38:21 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:38:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 06:38:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 06:38:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 06:38:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-06 06:38:21 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 06:38:21 --> Final output sent to browser
DEBUG - 2017-03-06 06:38:21 --> Total execution time: 0.0134
INFO - 2017-03-06 06:38:21 --> Config Class Initialized
INFO - 2017-03-06 06:38:21 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:21 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:21 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:21 --> URI Class Initialized
INFO - 2017-03-06 06:38:21 --> Router Class Initialized
INFO - 2017-03-06 06:38:21 --> Output Class Initialized
INFO - 2017-03-06 06:38:21 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:21 --> Input Class Initialized
INFO - 2017-03-06 06:38:21 --> Language Class Initialized
INFO - 2017-03-06 06:38:21 --> Language Class Initialized
INFO - 2017-03-06 06:38:21 --> Config Class Initialized
INFO - 2017-03-06 06:38:21 --> Loader Class Initialized
INFO - 2017-03-06 06:38:21 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:21 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:21 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:21 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:21 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:21 --> Template Class Initialized
INFO - 2017-03-06 06:38:21 --> Model Class Initialized
INFO - 2017-03-06 06:38:21 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:21 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:38:21 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:38:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:38:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:38:24 --> Config Class Initialized
INFO - 2017-03-06 06:38:24 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:24 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:24 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:24 --> URI Class Initialized
INFO - 2017-03-06 06:38:24 --> Router Class Initialized
INFO - 2017-03-06 06:38:24 --> Output Class Initialized
INFO - 2017-03-06 06:38:24 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:24 --> Input Class Initialized
INFO - 2017-03-06 06:38:24 --> Language Class Initialized
INFO - 2017-03-06 06:38:24 --> Language Class Initialized
INFO - 2017-03-06 06:38:24 --> Config Class Initialized
INFO - 2017-03-06 06:38:24 --> Loader Class Initialized
INFO - 2017-03-06 06:38:24 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:24 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:24 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:24 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:24 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:24 --> Template Class Initialized
INFO - 2017-03-06 06:38:24 --> Model Class Initialized
INFO - 2017-03-06 06:38:24 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:24 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:38:24 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:38:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:38:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:38:34 --> Config Class Initialized
INFO - 2017-03-06 06:38:34 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:34 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:34 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:34 --> URI Class Initialized
INFO - 2017-03-06 06:38:34 --> Router Class Initialized
INFO - 2017-03-06 06:38:34 --> Output Class Initialized
INFO - 2017-03-06 06:38:34 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:34 --> Input Class Initialized
INFO - 2017-03-06 06:38:34 --> Language Class Initialized
INFO - 2017-03-06 06:38:34 --> Language Class Initialized
INFO - 2017-03-06 06:38:34 --> Config Class Initialized
INFO - 2017-03-06 06:38:34 --> Loader Class Initialized
INFO - 2017-03-06 06:38:34 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:34 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:34 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:34 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:34 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:34 --> Template Class Initialized
INFO - 2017-03-06 06:38:34 --> Model Class Initialized
INFO - 2017-03-06 06:38:34 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:34 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:38:34 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:38:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:38:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:38:34 --> Config Class Initialized
INFO - 2017-03-06 06:38:34 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:34 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:34 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:34 --> URI Class Initialized
INFO - 2017-03-06 06:38:34 --> Router Class Initialized
INFO - 2017-03-06 06:38:34 --> Output Class Initialized
INFO - 2017-03-06 06:38:34 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:34 --> Input Class Initialized
INFO - 2017-03-06 06:38:34 --> Language Class Initialized
INFO - 2017-03-06 06:38:34 --> Language Class Initialized
INFO - 2017-03-06 06:38:34 --> Config Class Initialized
INFO - 2017-03-06 06:38:34 --> Loader Class Initialized
INFO - 2017-03-06 06:38:34 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:34 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:34 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:34 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:34 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:34 --> Template Class Initialized
INFO - 2017-03-06 06:38:34 --> Model Class Initialized
INFO - 2017-03-06 06:38:34 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:34 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:38:34 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:38:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:38:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:38:40 --> Config Class Initialized
INFO - 2017-03-06 06:38:40 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:40 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:40 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:40 --> URI Class Initialized
INFO - 2017-03-06 06:38:40 --> Router Class Initialized
INFO - 2017-03-06 06:38:40 --> Output Class Initialized
INFO - 2017-03-06 06:38:40 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:40 --> Input Class Initialized
INFO - 2017-03-06 06:38:40 --> Language Class Initialized
INFO - 2017-03-06 06:38:40 --> Language Class Initialized
INFO - 2017-03-06 06:38:40 --> Config Class Initialized
INFO - 2017-03-06 06:38:40 --> Loader Class Initialized
INFO - 2017-03-06 06:38:40 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:40 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:40 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:40 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:40 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:40 --> Template Class Initialized
INFO - 2017-03-06 06:38:40 --> Model Class Initialized
INFO - 2017-03-06 06:38:40 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:40 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:38:40 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:38:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:38:40 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:38:42 --> Config Class Initialized
INFO - 2017-03-06 06:38:42 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:42 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:42 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:42 --> URI Class Initialized
INFO - 2017-03-06 06:38:42 --> Router Class Initialized
INFO - 2017-03-06 06:38:42 --> Output Class Initialized
INFO - 2017-03-06 06:38:42 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:42 --> Input Class Initialized
INFO - 2017-03-06 06:38:42 --> Language Class Initialized
INFO - 2017-03-06 06:38:42 --> Language Class Initialized
INFO - 2017-03-06 06:38:42 --> Config Class Initialized
INFO - 2017-03-06 06:38:42 --> Loader Class Initialized
INFO - 2017-03-06 06:38:42 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:42 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:42 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:42 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:42 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:42 --> Template Class Initialized
INFO - 2017-03-06 06:38:42 --> Model Class Initialized
INFO - 2017-03-06 06:38:42 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:42 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:38:42 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:38:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:38:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:38:45 --> Config Class Initialized
INFO - 2017-03-06 06:38:45 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:45 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:45 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:45 --> URI Class Initialized
INFO - 2017-03-06 06:38:45 --> Router Class Initialized
INFO - 2017-03-06 06:38:45 --> Output Class Initialized
INFO - 2017-03-06 06:38:45 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:45 --> Input Class Initialized
INFO - 2017-03-06 06:38:45 --> Language Class Initialized
INFO - 2017-03-06 06:38:45 --> Language Class Initialized
INFO - 2017-03-06 06:38:45 --> Config Class Initialized
INFO - 2017-03-06 06:38:45 --> Loader Class Initialized
INFO - 2017-03-06 06:38:45 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:45 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:45 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:45 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:45 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:45 --> Template Class Initialized
INFO - 2017-03-06 06:38:45 --> Model Class Initialized
INFO - 2017-03-06 06:38:45 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:45 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:38:45 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:38:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:38:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:38:46 --> Config Class Initialized
INFO - 2017-03-06 06:38:46 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:46 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:46 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:46 --> URI Class Initialized
INFO - 2017-03-06 06:38:46 --> Router Class Initialized
INFO - 2017-03-06 06:38:46 --> Output Class Initialized
INFO - 2017-03-06 06:38:46 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:46 --> Input Class Initialized
INFO - 2017-03-06 06:38:46 --> Language Class Initialized
INFO - 2017-03-06 06:38:46 --> Language Class Initialized
INFO - 2017-03-06 06:38:46 --> Config Class Initialized
INFO - 2017-03-06 06:38:46 --> Loader Class Initialized
INFO - 2017-03-06 06:38:46 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:46 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:46 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:46 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:46 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:46 --> Template Class Initialized
INFO - 2017-03-06 06:38:46 --> Model Class Initialized
INFO - 2017-03-06 06:38:46 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:46 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:38:46 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:38:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:38:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:38:47 --> Config Class Initialized
INFO - 2017-03-06 06:38:47 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:47 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:47 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:47 --> URI Class Initialized
INFO - 2017-03-06 06:38:47 --> Router Class Initialized
INFO - 2017-03-06 06:38:47 --> Output Class Initialized
INFO - 2017-03-06 06:38:47 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:47 --> Input Class Initialized
INFO - 2017-03-06 06:38:47 --> Language Class Initialized
INFO - 2017-03-06 06:38:47 --> Language Class Initialized
INFO - 2017-03-06 06:38:47 --> Config Class Initialized
INFO - 2017-03-06 06:38:47 --> Loader Class Initialized
INFO - 2017-03-06 06:38:47 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:47 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:47 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:47 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:47 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:47 --> Template Class Initialized
INFO - 2017-03-06 06:38:47 --> Model Class Initialized
INFO - 2017-03-06 06:38:47 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:47 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:38:47 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:38:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:38:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:38:52 --> Config Class Initialized
INFO - 2017-03-06 06:38:52 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:52 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:52 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:52 --> URI Class Initialized
INFO - 2017-03-06 06:38:52 --> Router Class Initialized
INFO - 2017-03-06 06:38:52 --> Output Class Initialized
INFO - 2017-03-06 06:38:52 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:52 --> Input Class Initialized
INFO - 2017-03-06 06:38:52 --> Language Class Initialized
INFO - 2017-03-06 06:38:52 --> Language Class Initialized
INFO - 2017-03-06 06:38:52 --> Config Class Initialized
INFO - 2017-03-06 06:38:52 --> Loader Class Initialized
INFO - 2017-03-06 06:38:52 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:52 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:52 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:52 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:52 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:52 --> Template Class Initialized
INFO - 2017-03-06 06:38:52 --> Model Class Initialized
INFO - 2017-03-06 06:38:52 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:52 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:38:52 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:38:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:38:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:38:52 --> Config Class Initialized
INFO - 2017-03-06 06:38:52 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:52 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:52 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:52 --> URI Class Initialized
INFO - 2017-03-06 06:38:52 --> Router Class Initialized
INFO - 2017-03-06 06:38:52 --> Output Class Initialized
INFO - 2017-03-06 06:38:52 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:52 --> Input Class Initialized
INFO - 2017-03-06 06:38:52 --> Language Class Initialized
INFO - 2017-03-06 06:38:52 --> Language Class Initialized
INFO - 2017-03-06 06:38:52 --> Config Class Initialized
INFO - 2017-03-06 06:38:52 --> Loader Class Initialized
INFO - 2017-03-06 06:38:52 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:52 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:52 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:52 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:52 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:52 --> Template Class Initialized
INFO - 2017-03-06 06:38:52 --> Model Class Initialized
INFO - 2017-03-06 06:38:52 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:52 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:38:52 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:38:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:38:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:38:56 --> Config Class Initialized
INFO - 2017-03-06 06:38:56 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:56 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:56 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:56 --> URI Class Initialized
INFO - 2017-03-06 06:38:56 --> Router Class Initialized
INFO - 2017-03-06 06:38:56 --> Output Class Initialized
INFO - 2017-03-06 06:38:56 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:56 --> Input Class Initialized
INFO - 2017-03-06 06:38:56 --> Language Class Initialized
INFO - 2017-03-06 06:38:56 --> Language Class Initialized
INFO - 2017-03-06 06:38:56 --> Config Class Initialized
INFO - 2017-03-06 06:38:56 --> Loader Class Initialized
INFO - 2017-03-06 06:38:56 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:56 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:56 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:56 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:56 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:56 --> Template Class Initialized
INFO - 2017-03-06 06:38:56 --> Model Class Initialized
INFO - 2017-03-06 06:38:56 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:56 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:38:56 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:38:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:38:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:38:58 --> Config Class Initialized
INFO - 2017-03-06 06:38:58 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:38:58 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:38:58 --> Utf8 Class Initialized
INFO - 2017-03-06 06:38:58 --> URI Class Initialized
INFO - 2017-03-06 06:38:58 --> Router Class Initialized
INFO - 2017-03-06 06:38:58 --> Output Class Initialized
INFO - 2017-03-06 06:38:58 --> Security Class Initialized
DEBUG - 2017-03-06 06:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:38:58 --> Input Class Initialized
INFO - 2017-03-06 06:38:58 --> Language Class Initialized
INFO - 2017-03-06 06:38:58 --> Language Class Initialized
INFO - 2017-03-06 06:38:58 --> Config Class Initialized
INFO - 2017-03-06 06:38:58 --> Loader Class Initialized
INFO - 2017-03-06 06:38:58 --> Helper loaded: form_helper
INFO - 2017-03-06 06:38:58 --> Helper loaded: url_helper
INFO - 2017-03-06 06:38:58 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:38:58 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:38:58 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:38:58 --> Template Class Initialized
INFO - 2017-03-06 06:38:58 --> Model Class Initialized
INFO - 2017-03-06 06:38:58 --> Controller Class Initialized
DEBUG - 2017-03-06 06:38:58 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:38:58 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:38:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:38:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:39:00 --> Config Class Initialized
INFO - 2017-03-06 06:39:00 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:39:00 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:39:00 --> Utf8 Class Initialized
INFO - 2017-03-06 06:39:00 --> URI Class Initialized
INFO - 2017-03-06 06:39:00 --> Router Class Initialized
INFO - 2017-03-06 06:39:00 --> Output Class Initialized
INFO - 2017-03-06 06:39:00 --> Security Class Initialized
DEBUG - 2017-03-06 06:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:39:00 --> Input Class Initialized
INFO - 2017-03-06 06:39:00 --> Language Class Initialized
INFO - 2017-03-06 06:39:00 --> Language Class Initialized
INFO - 2017-03-06 06:39:00 --> Config Class Initialized
INFO - 2017-03-06 06:39:00 --> Loader Class Initialized
INFO - 2017-03-06 06:39:00 --> Helper loaded: form_helper
INFO - 2017-03-06 06:39:00 --> Helper loaded: url_helper
INFO - 2017-03-06 06:39:00 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:39:00 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:39:00 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:39:00 --> Template Class Initialized
INFO - 2017-03-06 06:39:00 --> Model Class Initialized
INFO - 2017-03-06 06:39:00 --> Controller Class Initialized
DEBUG - 2017-03-06 06:39:00 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:39:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:39:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:39:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:39:06 --> Config Class Initialized
INFO - 2017-03-06 06:39:06 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:39:06 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:39:06 --> Utf8 Class Initialized
INFO - 2017-03-06 06:39:06 --> URI Class Initialized
INFO - 2017-03-06 06:39:06 --> Router Class Initialized
INFO - 2017-03-06 06:39:06 --> Output Class Initialized
INFO - 2017-03-06 06:39:06 --> Security Class Initialized
DEBUG - 2017-03-06 06:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:39:06 --> Input Class Initialized
INFO - 2017-03-06 06:39:06 --> Language Class Initialized
INFO - 2017-03-06 06:39:06 --> Language Class Initialized
INFO - 2017-03-06 06:39:06 --> Config Class Initialized
INFO - 2017-03-06 06:39:06 --> Loader Class Initialized
INFO - 2017-03-06 06:39:06 --> Helper loaded: form_helper
INFO - 2017-03-06 06:39:06 --> Helper loaded: url_helper
INFO - 2017-03-06 06:39:06 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:39:06 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:39:06 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:39:06 --> Template Class Initialized
INFO - 2017-03-06 06:39:06 --> Model Class Initialized
INFO - 2017-03-06 06:39:06 --> Controller Class Initialized
DEBUG - 2017-03-06 06:39:06 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:39:06 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:39:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:39:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:39:07 --> Config Class Initialized
INFO - 2017-03-06 06:39:07 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:39:07 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:39:07 --> Utf8 Class Initialized
INFO - 2017-03-06 06:39:07 --> URI Class Initialized
INFO - 2017-03-06 06:39:07 --> Router Class Initialized
INFO - 2017-03-06 06:39:07 --> Output Class Initialized
INFO - 2017-03-06 06:39:07 --> Security Class Initialized
DEBUG - 2017-03-06 06:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:39:07 --> Input Class Initialized
INFO - 2017-03-06 06:39:07 --> Language Class Initialized
INFO - 2017-03-06 06:39:07 --> Language Class Initialized
INFO - 2017-03-06 06:39:07 --> Config Class Initialized
INFO - 2017-03-06 06:39:07 --> Loader Class Initialized
INFO - 2017-03-06 06:39:07 --> Helper loaded: form_helper
INFO - 2017-03-06 06:39:07 --> Helper loaded: url_helper
INFO - 2017-03-06 06:39:07 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:39:07 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:39:07 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:39:07 --> Template Class Initialized
INFO - 2017-03-06 06:39:07 --> Model Class Initialized
INFO - 2017-03-06 06:39:07 --> Controller Class Initialized
DEBUG - 2017-03-06 06:39:07 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:39:07 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:39:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:39:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:42:57 --> Config Class Initialized
INFO - 2017-03-06 06:42:57 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:42:57 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:42:57 --> Utf8 Class Initialized
INFO - 2017-03-06 06:42:57 --> URI Class Initialized
INFO - 2017-03-06 06:42:57 --> Router Class Initialized
INFO - 2017-03-06 06:42:57 --> Output Class Initialized
INFO - 2017-03-06 06:42:57 --> Security Class Initialized
DEBUG - 2017-03-06 06:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:42:57 --> Input Class Initialized
INFO - 2017-03-06 06:42:57 --> Language Class Initialized
INFO - 2017-03-06 06:42:57 --> Language Class Initialized
INFO - 2017-03-06 06:42:57 --> Config Class Initialized
INFO - 2017-03-06 06:42:57 --> Loader Class Initialized
INFO - 2017-03-06 06:42:57 --> Helper loaded: form_helper
INFO - 2017-03-06 06:42:57 --> Helper loaded: url_helper
INFO - 2017-03-06 06:42:57 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:42:57 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:42:57 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:42:57 --> Template Class Initialized
INFO - 2017-03-06 06:42:57 --> Model Class Initialized
INFO - 2017-03-06 06:42:57 --> Controller Class Initialized
DEBUG - 2017-03-06 06:42:57 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:42:57 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:42:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:42:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:42:59 --> Config Class Initialized
INFO - 2017-03-06 06:42:59 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:42:59 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:42:59 --> Utf8 Class Initialized
INFO - 2017-03-06 06:42:59 --> URI Class Initialized
INFO - 2017-03-06 06:42:59 --> Router Class Initialized
INFO - 2017-03-06 06:42:59 --> Output Class Initialized
INFO - 2017-03-06 06:42:59 --> Security Class Initialized
DEBUG - 2017-03-06 06:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:42:59 --> Input Class Initialized
INFO - 2017-03-06 06:42:59 --> Language Class Initialized
INFO - 2017-03-06 06:42:59 --> Language Class Initialized
INFO - 2017-03-06 06:42:59 --> Config Class Initialized
INFO - 2017-03-06 06:42:59 --> Loader Class Initialized
INFO - 2017-03-06 06:42:59 --> Helper loaded: form_helper
INFO - 2017-03-06 06:42:59 --> Helper loaded: url_helper
INFO - 2017-03-06 06:42:59 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:42:59 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:42:59 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:42:59 --> Template Class Initialized
INFO - 2017-03-06 06:42:59 --> Model Class Initialized
INFO - 2017-03-06 06:42:59 --> Controller Class Initialized
DEBUG - 2017-03-06 06:42:59 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:42:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:42:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:42:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:43:12 --> Config Class Initialized
INFO - 2017-03-06 06:43:12 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:43:12 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:43:12 --> Utf8 Class Initialized
INFO - 2017-03-06 06:43:12 --> URI Class Initialized
INFO - 2017-03-06 06:43:12 --> Router Class Initialized
INFO - 2017-03-06 06:43:12 --> Output Class Initialized
INFO - 2017-03-06 06:43:12 --> Security Class Initialized
DEBUG - 2017-03-06 06:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:43:12 --> Input Class Initialized
INFO - 2017-03-06 06:43:12 --> Language Class Initialized
INFO - 2017-03-06 06:43:12 --> Language Class Initialized
INFO - 2017-03-06 06:43:12 --> Config Class Initialized
INFO - 2017-03-06 06:43:12 --> Loader Class Initialized
INFO - 2017-03-06 06:43:12 --> Helper loaded: form_helper
INFO - 2017-03-06 06:43:12 --> Helper loaded: url_helper
INFO - 2017-03-06 06:43:12 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:43:12 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:43:12 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:43:12 --> Template Class Initialized
INFO - 2017-03-06 06:43:12 --> Model Class Initialized
INFO - 2017-03-06 06:43:12 --> Controller Class Initialized
DEBUG - 2017-03-06 06:43:12 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:43:12 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:43:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:43:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:43:13 --> Config Class Initialized
INFO - 2017-03-06 06:43:13 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:43:13 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:43:13 --> Utf8 Class Initialized
INFO - 2017-03-06 06:43:13 --> URI Class Initialized
INFO - 2017-03-06 06:43:13 --> Router Class Initialized
INFO - 2017-03-06 06:43:13 --> Output Class Initialized
INFO - 2017-03-06 06:43:13 --> Security Class Initialized
DEBUG - 2017-03-06 06:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:43:13 --> Input Class Initialized
INFO - 2017-03-06 06:43:13 --> Language Class Initialized
INFO - 2017-03-06 06:43:13 --> Language Class Initialized
INFO - 2017-03-06 06:43:13 --> Config Class Initialized
INFO - 2017-03-06 06:43:13 --> Loader Class Initialized
INFO - 2017-03-06 06:43:13 --> Helper loaded: form_helper
INFO - 2017-03-06 06:43:13 --> Helper loaded: url_helper
INFO - 2017-03-06 06:43:13 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:43:13 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:43:13 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:43:13 --> Template Class Initialized
INFO - 2017-03-06 06:43:13 --> Model Class Initialized
INFO - 2017-03-06 06:43:13 --> Controller Class Initialized
DEBUG - 2017-03-06 06:43:13 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:43:13 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:43:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:43:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 06:43:14 --> Config Class Initialized
INFO - 2017-03-06 06:43:14 --> Hooks Class Initialized
DEBUG - 2017-03-06 06:43:14 --> UTF-8 Support Enabled
INFO - 2017-03-06 06:43:14 --> Utf8 Class Initialized
INFO - 2017-03-06 06:43:14 --> URI Class Initialized
INFO - 2017-03-06 06:43:14 --> Router Class Initialized
INFO - 2017-03-06 06:43:14 --> Output Class Initialized
INFO - 2017-03-06 06:43:14 --> Security Class Initialized
DEBUG - 2017-03-06 06:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 06:43:14 --> Input Class Initialized
INFO - 2017-03-06 06:43:14 --> Language Class Initialized
INFO - 2017-03-06 06:43:14 --> Language Class Initialized
INFO - 2017-03-06 06:43:14 --> Config Class Initialized
INFO - 2017-03-06 06:43:14 --> Loader Class Initialized
INFO - 2017-03-06 06:43:14 --> Helper loaded: form_helper
INFO - 2017-03-06 06:43:14 --> Helper loaded: url_helper
INFO - 2017-03-06 06:43:14 --> Helper loaded: utility_helper
INFO - 2017-03-06 06:43:14 --> Database Driver Class Initialized
DEBUG - 2017-03-06 06:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 06:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 06:43:14 --> User Agent Class Initialized
DEBUG - 2017-03-06 06:43:14 --> Template Class Initialized
INFO - 2017-03-06 06:43:14 --> Model Class Initialized
INFO - 2017-03-06 06:43:14 --> Controller Class Initialized
DEBUG - 2017-03-06 06:43:14 --> Pages MX_Controller Initialized
INFO - 2017-03-06 06:43:14 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 06:43:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 06:43:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 07:28:00 --> Config Class Initialized
INFO - 2017-03-06 07:28:00 --> Hooks Class Initialized
DEBUG - 2017-03-06 07:28:00 --> UTF-8 Support Enabled
INFO - 2017-03-06 07:28:00 --> Utf8 Class Initialized
INFO - 2017-03-06 07:28:01 --> URI Class Initialized
INFO - 2017-03-06 07:28:01 --> Router Class Initialized
INFO - 2017-03-06 07:28:01 --> Output Class Initialized
INFO - 2017-03-06 07:28:01 --> Security Class Initialized
DEBUG - 2017-03-06 07:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 07:28:01 --> Input Class Initialized
INFO - 2017-03-06 07:28:01 --> Language Class Initialized
INFO - 2017-03-06 07:28:01 --> Language Class Initialized
INFO - 2017-03-06 07:28:01 --> Config Class Initialized
INFO - 2017-03-06 07:28:01 --> Loader Class Initialized
INFO - 2017-03-06 07:28:01 --> Helper loaded: form_helper
INFO - 2017-03-06 07:28:01 --> Helper loaded: url_helper
INFO - 2017-03-06 07:28:01 --> Helper loaded: utility_helper
INFO - 2017-03-06 07:28:01 --> Database Driver Class Initialized
DEBUG - 2017-03-06 07:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 07:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 07:28:01 --> User Agent Class Initialized
DEBUG - 2017-03-06 07:28:01 --> Template Class Initialized
INFO - 2017-03-06 07:28:01 --> Model Class Initialized
INFO - 2017-03-06 07:28:01 --> Controller Class Initialized
DEBUG - 2017-03-06 07:28:01 --> Pages MX_Controller Initialized
INFO - 2017-03-06 07:28:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 07:28:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 07:28:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 07:28:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-03-06 07:28:01 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 07:28:01 --> Final output sent to browser
DEBUG - 2017-03-06 07:28:01 --> Total execution time: 0.2713
INFO - 2017-03-06 07:28:02 --> Config Class Initialized
INFO - 2017-03-06 07:28:02 --> Hooks Class Initialized
DEBUG - 2017-03-06 07:28:02 --> UTF-8 Support Enabled
INFO - 2017-03-06 07:28:02 --> Utf8 Class Initialized
INFO - 2017-03-06 07:28:02 --> URI Class Initialized
INFO - 2017-03-06 07:28:02 --> Router Class Initialized
INFO - 2017-03-06 07:28:02 --> Output Class Initialized
INFO - 2017-03-06 07:28:02 --> Security Class Initialized
DEBUG - 2017-03-06 07:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 07:28:02 --> Input Class Initialized
INFO - 2017-03-06 07:28:02 --> Language Class Initialized
INFO - 2017-03-06 07:28:02 --> Language Class Initialized
INFO - 2017-03-06 07:28:02 --> Config Class Initialized
INFO - 2017-03-06 07:28:02 --> Loader Class Initialized
INFO - 2017-03-06 07:28:02 --> Helper loaded: form_helper
INFO - 2017-03-06 07:28:02 --> Helper loaded: url_helper
INFO - 2017-03-06 07:28:02 --> Helper loaded: utility_helper
INFO - 2017-03-06 07:28:02 --> Database Driver Class Initialized
DEBUG - 2017-03-06 07:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 07:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 07:28:02 --> User Agent Class Initialized
DEBUG - 2017-03-06 07:28:02 --> Template Class Initialized
INFO - 2017-03-06 07:28:02 --> Model Class Initialized
INFO - 2017-03-06 07:28:02 --> Controller Class Initialized
DEBUG - 2017-03-06 07:28:02 --> Pages MX_Controller Initialized
INFO - 2017-03-06 07:28:02 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 07:28:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 07:28:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 07:28:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-03-06 07:28:02 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 07:28:02 --> Final output sent to browser
DEBUG - 2017-03-06 07:28:02 --> Total execution time: 0.0284
INFO - 2017-03-06 11:33:38 --> Config Class Initialized
INFO - 2017-03-06 11:33:38 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:33:38 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:33:38 --> Utf8 Class Initialized
INFO - 2017-03-06 11:33:38 --> URI Class Initialized
INFO - 2017-03-06 11:33:38 --> Router Class Initialized
INFO - 2017-03-06 11:33:38 --> Output Class Initialized
INFO - 2017-03-06 11:33:38 --> Security Class Initialized
DEBUG - 2017-03-06 11:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:33:38 --> Input Class Initialized
INFO - 2017-03-06 11:33:38 --> Language Class Initialized
INFO - 2017-03-06 11:33:38 --> Language Class Initialized
INFO - 2017-03-06 11:33:38 --> Config Class Initialized
INFO - 2017-03-06 11:33:38 --> Loader Class Initialized
INFO - 2017-03-06 11:33:38 --> Helper loaded: form_helper
INFO - 2017-03-06 11:33:38 --> Helper loaded: url_helper
INFO - 2017-03-06 11:33:38 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:33:39 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:33:39 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:33:39 --> Template Class Initialized
INFO - 2017-03-06 11:33:39 --> Model Class Initialized
INFO - 2017-03-06 11:33:39 --> Controller Class Initialized
DEBUG - 2017-03-06 11:33:39 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:33:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:33:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:33:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:33:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 11:33:39 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:33:39 --> Final output sent to browser
DEBUG - 2017-03-06 11:33:39 --> Total execution time: 0.2498
INFO - 2017-03-06 11:33:39 --> Config Class Initialized
INFO - 2017-03-06 11:33:39 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:33:39 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:33:39 --> Utf8 Class Initialized
INFO - 2017-03-06 11:33:39 --> URI Class Initialized
INFO - 2017-03-06 11:33:39 --> Router Class Initialized
INFO - 2017-03-06 11:33:39 --> Output Class Initialized
INFO - 2017-03-06 11:33:39 --> Security Class Initialized
DEBUG - 2017-03-06 11:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:33:39 --> Input Class Initialized
INFO - 2017-03-06 11:33:39 --> Language Class Initialized
INFO - 2017-03-06 11:33:39 --> Language Class Initialized
INFO - 2017-03-06 11:33:39 --> Config Class Initialized
INFO - 2017-03-06 11:33:39 --> Loader Class Initialized
INFO - 2017-03-06 11:33:39 --> Helper loaded: form_helper
INFO - 2017-03-06 11:33:39 --> Helper loaded: url_helper
INFO - 2017-03-06 11:33:39 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:33:39 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:33:39 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:33:39 --> Template Class Initialized
INFO - 2017-03-06 11:33:39 --> Model Class Initialized
INFO - 2017-03-06 11:33:39 --> Controller Class Initialized
DEBUG - 2017-03-06 11:33:39 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:33:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:33:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:33:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:33:43 --> Config Class Initialized
INFO - 2017-03-06 11:33:43 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:33:43 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:33:43 --> Utf8 Class Initialized
INFO - 2017-03-06 11:33:43 --> URI Class Initialized
INFO - 2017-03-06 11:33:43 --> Router Class Initialized
INFO - 2017-03-06 11:33:43 --> Output Class Initialized
INFO - 2017-03-06 11:33:43 --> Security Class Initialized
DEBUG - 2017-03-06 11:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:33:43 --> Input Class Initialized
INFO - 2017-03-06 11:33:43 --> Language Class Initialized
INFO - 2017-03-06 11:33:43 --> Language Class Initialized
INFO - 2017-03-06 11:33:43 --> Config Class Initialized
INFO - 2017-03-06 11:33:43 --> Loader Class Initialized
INFO - 2017-03-06 11:33:43 --> Helper loaded: form_helper
INFO - 2017-03-06 11:33:43 --> Helper loaded: url_helper
INFO - 2017-03-06 11:33:43 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:33:43 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:33:43 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:33:43 --> Template Class Initialized
INFO - 2017-03-06 11:33:43 --> Model Class Initialized
INFO - 2017-03-06 11:33:43 --> Controller Class Initialized
DEBUG - 2017-03-06 11:33:43 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:33:43 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:33:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:33:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:33:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 11:33:43 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:33:43 --> Final output sent to browser
DEBUG - 2017-03-06 11:33:43 --> Total execution time: 0.0618
INFO - 2017-03-06 11:33:44 --> Config Class Initialized
INFO - 2017-03-06 11:33:44 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:33:44 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:33:44 --> Utf8 Class Initialized
INFO - 2017-03-06 11:33:44 --> URI Class Initialized
INFO - 2017-03-06 11:33:44 --> Router Class Initialized
INFO - 2017-03-06 11:33:44 --> Output Class Initialized
INFO - 2017-03-06 11:33:44 --> Security Class Initialized
DEBUG - 2017-03-06 11:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:33:44 --> Input Class Initialized
INFO - 2017-03-06 11:33:44 --> Language Class Initialized
INFO - 2017-03-06 11:33:44 --> Language Class Initialized
INFO - 2017-03-06 11:33:44 --> Config Class Initialized
INFO - 2017-03-06 11:33:44 --> Loader Class Initialized
INFO - 2017-03-06 11:33:44 --> Helper loaded: form_helper
INFO - 2017-03-06 11:33:44 --> Helper loaded: url_helper
INFO - 2017-03-06 11:33:44 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:33:44 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:33:44 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:33:44 --> Template Class Initialized
INFO - 2017-03-06 11:33:44 --> Model Class Initialized
INFO - 2017-03-06 11:33:44 --> Controller Class Initialized
DEBUG - 2017-03-06 11:33:44 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:33:44 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:33:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:33:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:33:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 11:33:44 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:33:44 --> Final output sent to browser
DEBUG - 2017-03-06 11:33:44 --> Total execution time: 0.0276
INFO - 2017-03-06 11:33:45 --> Config Class Initialized
INFO - 2017-03-06 11:33:45 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:33:45 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:33:45 --> Utf8 Class Initialized
INFO - 2017-03-06 11:33:45 --> URI Class Initialized
INFO - 2017-03-06 11:33:45 --> Router Class Initialized
INFO - 2017-03-06 11:33:45 --> Output Class Initialized
INFO - 2017-03-06 11:33:45 --> Security Class Initialized
DEBUG - 2017-03-06 11:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:33:45 --> Input Class Initialized
INFO - 2017-03-06 11:33:45 --> Language Class Initialized
INFO - 2017-03-06 11:33:45 --> Language Class Initialized
INFO - 2017-03-06 11:33:45 --> Config Class Initialized
INFO - 2017-03-06 11:33:45 --> Loader Class Initialized
INFO - 2017-03-06 11:33:45 --> Helper loaded: form_helper
INFO - 2017-03-06 11:33:45 --> Helper loaded: url_helper
INFO - 2017-03-06 11:33:45 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:33:45 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:33:45 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:33:45 --> Template Class Initialized
INFO - 2017-03-06 11:33:45 --> Model Class Initialized
INFO - 2017-03-06 11:33:45 --> Controller Class Initialized
DEBUG - 2017-03-06 11:33:45 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:33:45 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:33:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:33:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:33:45 --> Config Class Initialized
INFO - 2017-03-06 11:33:45 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:33:45 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:33:45 --> Utf8 Class Initialized
INFO - 2017-03-06 11:33:45 --> URI Class Initialized
INFO - 2017-03-06 11:33:45 --> Router Class Initialized
INFO - 2017-03-06 11:33:45 --> Output Class Initialized
INFO - 2017-03-06 11:33:45 --> Security Class Initialized
DEBUG - 2017-03-06 11:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:33:45 --> Input Class Initialized
INFO - 2017-03-06 11:33:45 --> Language Class Initialized
INFO - 2017-03-06 11:33:45 --> Language Class Initialized
INFO - 2017-03-06 11:33:45 --> Config Class Initialized
INFO - 2017-03-06 11:33:45 --> Loader Class Initialized
INFO - 2017-03-06 11:33:45 --> Helper loaded: form_helper
INFO - 2017-03-06 11:33:45 --> Helper loaded: url_helper
INFO - 2017-03-06 11:33:45 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:33:45 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:33:45 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:33:45 --> Template Class Initialized
INFO - 2017-03-06 11:33:45 --> Model Class Initialized
INFO - 2017-03-06 11:33:45 --> Controller Class Initialized
DEBUG - 2017-03-06 11:33:45 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:33:45 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:33:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:33:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:33:46 --> Config Class Initialized
INFO - 2017-03-06 11:33:46 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:33:46 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:33:46 --> Utf8 Class Initialized
INFO - 2017-03-06 11:33:46 --> URI Class Initialized
INFO - 2017-03-06 11:33:46 --> Router Class Initialized
INFO - 2017-03-06 11:33:46 --> Output Class Initialized
INFO - 2017-03-06 11:33:46 --> Security Class Initialized
DEBUG - 2017-03-06 11:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:33:46 --> Input Class Initialized
INFO - 2017-03-06 11:33:46 --> Language Class Initialized
INFO - 2017-03-06 11:33:46 --> Language Class Initialized
INFO - 2017-03-06 11:33:46 --> Config Class Initialized
INFO - 2017-03-06 11:33:46 --> Loader Class Initialized
INFO - 2017-03-06 11:33:46 --> Helper loaded: form_helper
INFO - 2017-03-06 11:33:46 --> Helper loaded: url_helper
INFO - 2017-03-06 11:33:46 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:33:46 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:33:46 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:33:46 --> Template Class Initialized
INFO - 2017-03-06 11:33:46 --> Model Class Initialized
INFO - 2017-03-06 11:33:46 --> Controller Class Initialized
DEBUG - 2017-03-06 11:33:46 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:33:46 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:33:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:33:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:33:46 --> Config Class Initialized
INFO - 2017-03-06 11:33:46 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:33:46 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:33:46 --> Utf8 Class Initialized
INFO - 2017-03-06 11:33:46 --> URI Class Initialized
INFO - 2017-03-06 11:33:46 --> Router Class Initialized
INFO - 2017-03-06 11:33:46 --> Output Class Initialized
INFO - 2017-03-06 11:33:46 --> Security Class Initialized
DEBUG - 2017-03-06 11:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:33:46 --> Input Class Initialized
INFO - 2017-03-06 11:33:46 --> Language Class Initialized
INFO - 2017-03-06 11:33:46 --> Language Class Initialized
INFO - 2017-03-06 11:33:46 --> Config Class Initialized
INFO - 2017-03-06 11:33:46 --> Loader Class Initialized
INFO - 2017-03-06 11:33:46 --> Helper loaded: form_helper
INFO - 2017-03-06 11:33:46 --> Helper loaded: url_helper
INFO - 2017-03-06 11:33:46 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:33:46 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:33:46 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:33:46 --> Template Class Initialized
INFO - 2017-03-06 11:33:46 --> Model Class Initialized
INFO - 2017-03-06 11:33:46 --> Controller Class Initialized
DEBUG - 2017-03-06 11:33:46 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:33:46 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:33:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:33:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:33:46 --> Config Class Initialized
INFO - 2017-03-06 11:33:46 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:33:46 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:33:46 --> Utf8 Class Initialized
INFO - 2017-03-06 11:33:46 --> URI Class Initialized
INFO - 2017-03-06 11:33:46 --> Router Class Initialized
INFO - 2017-03-06 11:33:46 --> Output Class Initialized
INFO - 2017-03-06 11:33:46 --> Security Class Initialized
DEBUG - 2017-03-06 11:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:33:46 --> Input Class Initialized
INFO - 2017-03-06 11:33:46 --> Language Class Initialized
INFO - 2017-03-06 11:33:46 --> Language Class Initialized
INFO - 2017-03-06 11:33:46 --> Config Class Initialized
INFO - 2017-03-06 11:33:46 --> Loader Class Initialized
INFO - 2017-03-06 11:33:46 --> Helper loaded: form_helper
INFO - 2017-03-06 11:33:46 --> Helper loaded: url_helper
INFO - 2017-03-06 11:33:46 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:33:46 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:33:46 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:33:46 --> Template Class Initialized
INFO - 2017-03-06 11:33:46 --> Model Class Initialized
INFO - 2017-03-06 11:33:46 --> Controller Class Initialized
DEBUG - 2017-03-06 11:33:46 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:33:46 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:33:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:33:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:33:46 --> Config Class Initialized
INFO - 2017-03-06 11:33:46 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:33:46 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:33:46 --> Utf8 Class Initialized
INFO - 2017-03-06 11:33:46 --> URI Class Initialized
INFO - 2017-03-06 11:33:46 --> Router Class Initialized
INFO - 2017-03-06 11:33:46 --> Output Class Initialized
INFO - 2017-03-06 11:33:46 --> Security Class Initialized
DEBUG - 2017-03-06 11:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:33:46 --> Input Class Initialized
INFO - 2017-03-06 11:33:46 --> Language Class Initialized
INFO - 2017-03-06 11:33:46 --> Language Class Initialized
INFO - 2017-03-06 11:33:46 --> Config Class Initialized
INFO - 2017-03-06 11:33:46 --> Loader Class Initialized
INFO - 2017-03-06 11:33:46 --> Helper loaded: form_helper
INFO - 2017-03-06 11:33:46 --> Helper loaded: url_helper
INFO - 2017-03-06 11:33:46 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:33:46 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:33:46 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:33:46 --> Template Class Initialized
INFO - 2017-03-06 11:33:46 --> Model Class Initialized
INFO - 2017-03-06 11:33:46 --> Controller Class Initialized
DEBUG - 2017-03-06 11:33:46 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:33:46 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:33:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:33:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:33:54 --> Config Class Initialized
INFO - 2017-03-06 11:33:54 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:33:54 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:33:54 --> Utf8 Class Initialized
INFO - 2017-03-06 11:33:54 --> URI Class Initialized
INFO - 2017-03-06 11:33:55 --> Router Class Initialized
INFO - 2017-03-06 11:33:55 --> Output Class Initialized
INFO - 2017-03-06 11:33:55 --> Security Class Initialized
DEBUG - 2017-03-06 11:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:33:55 --> Input Class Initialized
INFO - 2017-03-06 11:33:55 --> Language Class Initialized
INFO - 2017-03-06 11:33:55 --> Language Class Initialized
INFO - 2017-03-06 11:33:55 --> Config Class Initialized
INFO - 2017-03-06 11:33:55 --> Loader Class Initialized
INFO - 2017-03-06 11:33:55 --> Helper loaded: form_helper
INFO - 2017-03-06 11:33:55 --> Helper loaded: url_helper
INFO - 2017-03-06 11:33:55 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:33:55 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:33:55 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:33:55 --> Template Class Initialized
INFO - 2017-03-06 11:33:55 --> Model Class Initialized
INFO - 2017-03-06 11:33:55 --> Controller Class Initialized
DEBUG - 2017-03-06 11:33:55 --> Login MX_Controller Initialized
INFO - 2017-03-06 11:33:55 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:33:55 --> Form Validation Class Initialized
INFO - 2017-03-06 11:33:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-06 11:33:55 --> Config Class Initialized
INFO - 2017-03-06 11:33:55 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:33:55 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:33:55 --> Utf8 Class Initialized
INFO - 2017-03-06 11:33:55 --> URI Class Initialized
INFO - 2017-03-06 11:33:55 --> Router Class Initialized
INFO - 2017-03-06 11:33:55 --> Output Class Initialized
INFO - 2017-03-06 11:33:55 --> Security Class Initialized
DEBUG - 2017-03-06 11:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:33:55 --> Input Class Initialized
INFO - 2017-03-06 11:33:55 --> Language Class Initialized
INFO - 2017-03-06 11:33:55 --> Language Class Initialized
INFO - 2017-03-06 11:33:55 --> Config Class Initialized
INFO - 2017-03-06 11:33:55 --> Loader Class Initialized
INFO - 2017-03-06 11:33:55 --> Helper loaded: form_helper
INFO - 2017-03-06 11:33:55 --> Helper loaded: url_helper
INFO - 2017-03-06 11:33:55 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:33:55 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:33:55 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:33:55 --> Template Class Initialized
INFO - 2017-03-06 11:33:55 --> Model Class Initialized
INFO - 2017-03-06 11:33:55 --> Controller Class Initialized
DEBUG - 2017-03-06 11:33:55 --> Dashboard MX_Controller Initialized
INFO - 2017-03-06 11:33:55 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:33:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:33:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:33:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:33:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-06 11:33:55 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:33:55 --> Final output sent to browser
DEBUG - 2017-03-06 11:33:55 --> Total execution time: 0.0659
INFO - 2017-03-06 11:33:58 --> Config Class Initialized
INFO - 2017-03-06 11:33:58 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:33:58 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:33:58 --> Utf8 Class Initialized
INFO - 2017-03-06 11:33:58 --> URI Class Initialized
INFO - 2017-03-06 11:33:58 --> Router Class Initialized
INFO - 2017-03-06 11:33:58 --> Output Class Initialized
INFO - 2017-03-06 11:33:58 --> Security Class Initialized
DEBUG - 2017-03-06 11:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:33:58 --> Input Class Initialized
INFO - 2017-03-06 11:33:58 --> Language Class Initialized
INFO - 2017-03-06 11:33:58 --> Language Class Initialized
INFO - 2017-03-06 11:33:58 --> Config Class Initialized
INFO - 2017-03-06 11:33:58 --> Loader Class Initialized
INFO - 2017-03-06 11:33:58 --> Helper loaded: form_helper
INFO - 2017-03-06 11:33:58 --> Helper loaded: url_helper
INFO - 2017-03-06 11:33:58 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:33:58 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:33:58 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:33:58 --> Template Class Initialized
INFO - 2017-03-06 11:33:58 --> Model Class Initialized
INFO - 2017-03-06 11:33:58 --> Controller Class Initialized
DEBUG - 2017-03-06 11:33:58 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:33:58 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:33:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:33:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:33:58 --> Config Class Initialized
INFO - 2017-03-06 11:33:58 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:33:58 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:33:58 --> Utf8 Class Initialized
INFO - 2017-03-06 11:33:58 --> URI Class Initialized
INFO - 2017-03-06 11:33:58 --> Router Class Initialized
INFO - 2017-03-06 11:33:58 --> Output Class Initialized
INFO - 2017-03-06 11:33:58 --> Security Class Initialized
DEBUG - 2017-03-06 11:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:33:58 --> Input Class Initialized
INFO - 2017-03-06 11:33:58 --> Language Class Initialized
INFO - 2017-03-06 11:33:58 --> Language Class Initialized
INFO - 2017-03-06 11:33:58 --> Config Class Initialized
INFO - 2017-03-06 11:33:58 --> Loader Class Initialized
INFO - 2017-03-06 11:33:58 --> Helper loaded: form_helper
INFO - 2017-03-06 11:33:58 --> Helper loaded: url_helper
INFO - 2017-03-06 11:33:58 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:33:58 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:33:58 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:33:58 --> Template Class Initialized
INFO - 2017-03-06 11:33:58 --> Model Class Initialized
INFO - 2017-03-06 11:33:58 --> Controller Class Initialized
DEBUG - 2017-03-06 11:33:58 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:33:58 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:33:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:33:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:34:12 --> Config Class Initialized
INFO - 2017-03-06 11:34:12 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:34:12 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:34:12 --> Utf8 Class Initialized
INFO - 2017-03-06 11:34:12 --> URI Class Initialized
INFO - 2017-03-06 11:34:12 --> Router Class Initialized
INFO - 2017-03-06 11:34:12 --> Output Class Initialized
INFO - 2017-03-06 11:34:12 --> Security Class Initialized
DEBUG - 2017-03-06 11:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:34:12 --> Input Class Initialized
INFO - 2017-03-06 11:34:12 --> Language Class Initialized
INFO - 2017-03-06 11:34:12 --> Language Class Initialized
INFO - 2017-03-06 11:34:12 --> Config Class Initialized
INFO - 2017-03-06 11:34:12 --> Loader Class Initialized
INFO - 2017-03-06 11:34:12 --> Helper loaded: form_helper
INFO - 2017-03-06 11:34:12 --> Helper loaded: url_helper
INFO - 2017-03-06 11:34:12 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:34:12 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:34:12 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:34:12 --> Template Class Initialized
INFO - 2017-03-06 11:34:12 --> Model Class Initialized
INFO - 2017-03-06 11:34:12 --> Controller Class Initialized
DEBUG - 2017-03-06 11:34:12 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:34:12 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:34:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:34:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:34:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:34:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-06 11:34:12 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:34:12 --> Final output sent to browser
DEBUG - 2017-03-06 11:34:12 --> Total execution time: 0.0884
INFO - 2017-03-06 11:34:13 --> Config Class Initialized
INFO - 2017-03-06 11:34:13 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:34:13 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:34:13 --> Utf8 Class Initialized
INFO - 2017-03-06 11:34:13 --> URI Class Initialized
INFO - 2017-03-06 11:34:13 --> Router Class Initialized
INFO - 2017-03-06 11:34:14 --> Output Class Initialized
INFO - 2017-03-06 11:34:14 --> Security Class Initialized
DEBUG - 2017-03-06 11:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:34:14 --> Input Class Initialized
INFO - 2017-03-06 11:34:14 --> Language Class Initialized
INFO - 2017-03-06 11:34:14 --> Language Class Initialized
INFO - 2017-03-06 11:34:14 --> Config Class Initialized
INFO - 2017-03-06 11:34:14 --> Loader Class Initialized
INFO - 2017-03-06 11:34:14 --> Helper loaded: form_helper
INFO - 2017-03-06 11:34:14 --> Helper loaded: url_helper
INFO - 2017-03-06 11:34:14 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:34:14 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:34:14 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:34:14 --> Template Class Initialized
INFO - 2017-03-06 11:34:14 --> Model Class Initialized
INFO - 2017-03-06 11:34:14 --> Controller Class Initialized
DEBUG - 2017-03-06 11:34:14 --> Login MX_Controller Initialized
INFO - 2017-03-06 11:34:14 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:34:14 --> Form Validation Class Initialized
INFO - 2017-03-06 11:34:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-06 11:34:14 --> Config Class Initialized
INFO - 2017-03-06 11:34:14 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:34:14 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:34:14 --> Utf8 Class Initialized
INFO - 2017-03-06 11:34:14 --> URI Class Initialized
INFO - 2017-03-06 11:34:14 --> Router Class Initialized
INFO - 2017-03-06 11:34:14 --> Output Class Initialized
INFO - 2017-03-06 11:34:14 --> Security Class Initialized
DEBUG - 2017-03-06 11:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:34:14 --> Input Class Initialized
INFO - 2017-03-06 11:34:14 --> Language Class Initialized
INFO - 2017-03-06 11:34:14 --> Language Class Initialized
INFO - 2017-03-06 11:34:14 --> Config Class Initialized
INFO - 2017-03-06 11:34:14 --> Loader Class Initialized
INFO - 2017-03-06 11:34:14 --> Helper loaded: form_helper
INFO - 2017-03-06 11:34:14 --> Helper loaded: url_helper
INFO - 2017-03-06 11:34:14 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:34:14 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:34:14 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:34:14 --> Template Class Initialized
INFO - 2017-03-06 11:34:14 --> Model Class Initialized
INFO - 2017-03-06 11:34:14 --> Controller Class Initialized
DEBUG - 2017-03-06 11:34:14 --> Dashboard MX_Controller Initialized
INFO - 2017-03-06 11:34:14 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:34:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:34:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:34:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:34:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-06 11:34:14 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:34:14 --> Final output sent to browser
DEBUG - 2017-03-06 11:34:14 --> Total execution time: 0.0170
INFO - 2017-03-06 11:34:16 --> Config Class Initialized
INFO - 2017-03-06 11:34:16 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:34:16 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:34:16 --> Utf8 Class Initialized
INFO - 2017-03-06 11:34:16 --> URI Class Initialized
INFO - 2017-03-06 11:34:16 --> Router Class Initialized
INFO - 2017-03-06 11:34:16 --> Output Class Initialized
INFO - 2017-03-06 11:34:16 --> Security Class Initialized
DEBUG - 2017-03-06 11:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:34:16 --> Input Class Initialized
INFO - 2017-03-06 11:34:16 --> Language Class Initialized
INFO - 2017-03-06 11:34:16 --> Language Class Initialized
INFO - 2017-03-06 11:34:16 --> Config Class Initialized
INFO - 2017-03-06 11:34:16 --> Loader Class Initialized
INFO - 2017-03-06 11:34:16 --> Helper loaded: form_helper
INFO - 2017-03-06 11:34:16 --> Helper loaded: url_helper
INFO - 2017-03-06 11:34:16 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:34:16 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:34:16 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:34:16 --> Template Class Initialized
INFO - 2017-03-06 11:34:16 --> Model Class Initialized
INFO - 2017-03-06 11:34:16 --> Controller Class Initialized
DEBUG - 2017-03-06 11:34:16 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:34:16 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:34:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:34:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:34:24 --> Config Class Initialized
INFO - 2017-03-06 11:34:24 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:34:24 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:34:24 --> Utf8 Class Initialized
INFO - 2017-03-06 11:34:24 --> URI Class Initialized
INFO - 2017-03-06 11:34:24 --> Router Class Initialized
INFO - 2017-03-06 11:34:24 --> Output Class Initialized
INFO - 2017-03-06 11:34:24 --> Security Class Initialized
DEBUG - 2017-03-06 11:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:34:24 --> Input Class Initialized
INFO - 2017-03-06 11:34:24 --> Language Class Initialized
INFO - 2017-03-06 11:34:24 --> Language Class Initialized
INFO - 2017-03-06 11:34:24 --> Config Class Initialized
INFO - 2017-03-06 11:34:24 --> Loader Class Initialized
INFO - 2017-03-06 11:34:24 --> Helper loaded: form_helper
INFO - 2017-03-06 11:34:24 --> Helper loaded: url_helper
INFO - 2017-03-06 11:34:24 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:34:24 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:34:24 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:34:24 --> Template Class Initialized
INFO - 2017-03-06 11:34:24 --> Model Class Initialized
INFO - 2017-03-06 11:34:24 --> Controller Class Initialized
DEBUG - 2017-03-06 11:34:24 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:34:24 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:34:24 --> Model Class Initialized
INFO - 2017-03-06 11:34:24 --> Config Class Initialized
INFO - 2017-03-06 11:34:24 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:34:24 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:34:24 --> Utf8 Class Initialized
INFO - 2017-03-06 11:34:24 --> URI Class Initialized
INFO - 2017-03-06 11:34:24 --> Router Class Initialized
INFO - 2017-03-06 11:34:24 --> Output Class Initialized
INFO - 2017-03-06 11:34:24 --> Security Class Initialized
DEBUG - 2017-03-06 11:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:34:24 --> Input Class Initialized
INFO - 2017-03-06 11:34:24 --> Language Class Initialized
INFO - 2017-03-06 11:34:24 --> Language Class Initialized
INFO - 2017-03-06 11:34:24 --> Config Class Initialized
INFO - 2017-03-06 11:34:24 --> Loader Class Initialized
INFO - 2017-03-06 11:34:24 --> Helper loaded: form_helper
INFO - 2017-03-06 11:34:24 --> Helper loaded: url_helper
INFO - 2017-03-06 11:34:24 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:34:24 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:34:24 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:34:24 --> Template Class Initialized
INFO - 2017-03-06 11:34:24 --> Model Class Initialized
INFO - 2017-03-06 11:34:24 --> Controller Class Initialized
DEBUG - 2017-03-06 11:34:24 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:34:24 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:34:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:34:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:34:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:34:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-06 11:34:24 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:34:24 --> Final output sent to browser
DEBUG - 2017-03-06 11:34:24 --> Total execution time: 0.0932
INFO - 2017-03-06 11:34:26 --> Config Class Initialized
INFO - 2017-03-06 11:34:26 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:34:26 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:34:26 --> Utf8 Class Initialized
INFO - 2017-03-06 11:34:26 --> URI Class Initialized
INFO - 2017-03-06 11:34:26 --> Router Class Initialized
INFO - 2017-03-06 11:34:26 --> Output Class Initialized
INFO - 2017-03-06 11:34:26 --> Security Class Initialized
DEBUG - 2017-03-06 11:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:34:26 --> Input Class Initialized
INFO - 2017-03-06 11:34:26 --> Language Class Initialized
INFO - 2017-03-06 11:34:26 --> Language Class Initialized
INFO - 2017-03-06 11:34:26 --> Config Class Initialized
INFO - 2017-03-06 11:34:26 --> Loader Class Initialized
INFO - 2017-03-06 11:34:26 --> Helper loaded: form_helper
INFO - 2017-03-06 11:34:26 --> Helper loaded: url_helper
INFO - 2017-03-06 11:34:26 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:34:26 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:34:26 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:34:26 --> Template Class Initialized
INFO - 2017-03-06 11:34:26 --> Model Class Initialized
INFO - 2017-03-06 11:34:26 --> Controller Class Initialized
DEBUG - 2017-03-06 11:34:26 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:34:26 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:34:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:34:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:34:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:34:26 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-06 11:34:26 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:34:26 --> Final output sent to browser
DEBUG - 2017-03-06 11:34:26 --> Total execution time: 0.1215
INFO - 2017-03-06 11:34:27 --> Config Class Initialized
INFO - 2017-03-06 11:34:27 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:34:27 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:34:27 --> Utf8 Class Initialized
INFO - 2017-03-06 11:34:27 --> URI Class Initialized
INFO - 2017-03-06 11:34:27 --> Router Class Initialized
INFO - 2017-03-06 11:34:27 --> Output Class Initialized
INFO - 2017-03-06 11:34:27 --> Security Class Initialized
DEBUG - 2017-03-06 11:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:34:27 --> Input Class Initialized
INFO - 2017-03-06 11:34:27 --> Language Class Initialized
INFO - 2017-03-06 11:34:27 --> Language Class Initialized
INFO - 2017-03-06 11:34:27 --> Config Class Initialized
INFO - 2017-03-06 11:34:27 --> Loader Class Initialized
INFO - 2017-03-06 11:34:27 --> Helper loaded: form_helper
INFO - 2017-03-06 11:34:27 --> Helper loaded: url_helper
INFO - 2017-03-06 11:34:27 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:34:27 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:34:27 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:34:27 --> Template Class Initialized
INFO - 2017-03-06 11:34:27 --> Model Class Initialized
INFO - 2017-03-06 11:34:27 --> Controller Class Initialized
DEBUG - 2017-03-06 11:34:27 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:34:27 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:34:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:34:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:34:28 --> Config Class Initialized
INFO - 2017-03-06 11:34:28 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:34:28 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:34:28 --> Utf8 Class Initialized
INFO - 2017-03-06 11:34:28 --> URI Class Initialized
INFO - 2017-03-06 11:34:28 --> Router Class Initialized
INFO - 2017-03-06 11:34:28 --> Output Class Initialized
INFO - 2017-03-06 11:34:28 --> Security Class Initialized
DEBUG - 2017-03-06 11:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:34:28 --> Input Class Initialized
INFO - 2017-03-06 11:34:28 --> Language Class Initialized
INFO - 2017-03-06 11:34:28 --> Language Class Initialized
INFO - 2017-03-06 11:34:28 --> Config Class Initialized
INFO - 2017-03-06 11:34:28 --> Loader Class Initialized
INFO - 2017-03-06 11:34:28 --> Helper loaded: form_helper
INFO - 2017-03-06 11:34:28 --> Helper loaded: url_helper
INFO - 2017-03-06 11:34:28 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:34:28 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:34:28 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:34:28 --> Template Class Initialized
INFO - 2017-03-06 11:34:28 --> Model Class Initialized
INFO - 2017-03-06 11:34:28 --> Controller Class Initialized
DEBUG - 2017-03-06 11:34:28 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:34:28 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:34:28 --> Model Class Initialized
DEBUG - 2017-03-06 11:34:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:34:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:34:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:34:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/project_list.php
DEBUG - 2017-03-06 11:34:28 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:34:28 --> Final output sent to browser
DEBUG - 2017-03-06 11:34:28 --> Total execution time: 0.0626
INFO - 2017-03-06 11:34:37 --> Config Class Initialized
INFO - 2017-03-06 11:34:37 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:34:37 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:34:37 --> Utf8 Class Initialized
INFO - 2017-03-06 11:34:37 --> URI Class Initialized
INFO - 2017-03-06 11:34:37 --> Router Class Initialized
INFO - 2017-03-06 11:34:37 --> Output Class Initialized
INFO - 2017-03-06 11:34:37 --> Security Class Initialized
DEBUG - 2017-03-06 11:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:34:37 --> Input Class Initialized
INFO - 2017-03-06 11:34:37 --> Language Class Initialized
INFO - 2017-03-06 11:34:37 --> Language Class Initialized
INFO - 2017-03-06 11:34:37 --> Config Class Initialized
INFO - 2017-03-06 11:34:37 --> Loader Class Initialized
INFO - 2017-03-06 11:34:37 --> Helper loaded: form_helper
INFO - 2017-03-06 11:34:37 --> Helper loaded: url_helper
INFO - 2017-03-06 11:34:37 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:34:37 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:34:37 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:34:37 --> Template Class Initialized
INFO - 2017-03-06 11:34:37 --> Model Class Initialized
INFO - 2017-03-06 11:34:37 --> Controller Class Initialized
DEBUG - 2017-03-06 11:34:37 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:34:37 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:34:37 --> Model Class Initialized
INFO - 2017-03-06 11:34:37 --> Config Class Initialized
INFO - 2017-03-06 11:34:37 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:34:37 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:34:37 --> Utf8 Class Initialized
INFO - 2017-03-06 11:34:37 --> URI Class Initialized
INFO - 2017-03-06 11:34:37 --> Router Class Initialized
INFO - 2017-03-06 11:34:37 --> Output Class Initialized
INFO - 2017-03-06 11:34:37 --> Security Class Initialized
DEBUG - 2017-03-06 11:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:34:37 --> Input Class Initialized
INFO - 2017-03-06 11:34:37 --> Language Class Initialized
INFO - 2017-03-06 11:34:37 --> Language Class Initialized
INFO - 2017-03-06 11:34:37 --> Config Class Initialized
INFO - 2017-03-06 11:34:37 --> Loader Class Initialized
INFO - 2017-03-06 11:34:37 --> Helper loaded: form_helper
INFO - 2017-03-06 11:34:37 --> Helper loaded: url_helper
INFO - 2017-03-06 11:34:37 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:34:37 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:34:37 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:34:37 --> Template Class Initialized
INFO - 2017-03-06 11:34:37 --> Model Class Initialized
INFO - 2017-03-06 11:34:37 --> Controller Class Initialized
DEBUG - 2017-03-06 11:34:37 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:34:37 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:34:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:34:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:34:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:34:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-06 11:34:37 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:34:37 --> Final output sent to browser
DEBUG - 2017-03-06 11:34:37 --> Total execution time: 0.0105
INFO - 2017-03-06 11:34:38 --> Config Class Initialized
INFO - 2017-03-06 11:34:38 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:34:38 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:34:38 --> Utf8 Class Initialized
INFO - 2017-03-06 11:34:38 --> URI Class Initialized
INFO - 2017-03-06 11:34:38 --> Router Class Initialized
INFO - 2017-03-06 11:34:38 --> Output Class Initialized
INFO - 2017-03-06 11:34:38 --> Security Class Initialized
DEBUG - 2017-03-06 11:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:34:38 --> Input Class Initialized
INFO - 2017-03-06 11:34:38 --> Language Class Initialized
INFO - 2017-03-06 11:34:38 --> Language Class Initialized
INFO - 2017-03-06 11:34:38 --> Config Class Initialized
INFO - 2017-03-06 11:34:38 --> Loader Class Initialized
INFO - 2017-03-06 11:34:38 --> Helper loaded: form_helper
INFO - 2017-03-06 11:34:38 --> Helper loaded: url_helper
INFO - 2017-03-06 11:34:38 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:34:38 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:34:38 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:34:38 --> Template Class Initialized
INFO - 2017-03-06 11:34:38 --> Model Class Initialized
INFO - 2017-03-06 11:34:38 --> Controller Class Initialized
DEBUG - 2017-03-06 11:34:38 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:34:38 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:34:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:34:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:34:42 --> Config Class Initialized
INFO - 2017-03-06 11:34:42 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:34:42 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:34:42 --> Utf8 Class Initialized
INFO - 2017-03-06 11:34:42 --> URI Class Initialized
INFO - 2017-03-06 11:34:42 --> Router Class Initialized
INFO - 2017-03-06 11:34:42 --> Output Class Initialized
INFO - 2017-03-06 11:34:42 --> Security Class Initialized
DEBUG - 2017-03-06 11:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:34:42 --> Input Class Initialized
INFO - 2017-03-06 11:34:42 --> Language Class Initialized
INFO - 2017-03-06 11:34:42 --> Language Class Initialized
INFO - 2017-03-06 11:34:42 --> Config Class Initialized
INFO - 2017-03-06 11:34:42 --> Loader Class Initialized
INFO - 2017-03-06 11:34:42 --> Helper loaded: form_helper
INFO - 2017-03-06 11:34:42 --> Helper loaded: url_helper
INFO - 2017-03-06 11:34:42 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:34:42 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:34:42 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:34:42 --> Template Class Initialized
INFO - 2017-03-06 11:34:42 --> Model Class Initialized
INFO - 2017-03-06 11:34:42 --> Controller Class Initialized
DEBUG - 2017-03-06 11:34:42 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:34:42 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:34:42 --> Model Class Initialized
DEBUG - 2017-03-06 11:34:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:34:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:34:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:34:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-06 11:34:42 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:34:42 --> Final output sent to browser
DEBUG - 2017-03-06 11:34:42 --> Total execution time: 0.0280
INFO - 2017-03-06 11:34:46 --> Config Class Initialized
INFO - 2017-03-06 11:34:46 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:34:46 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:34:46 --> Utf8 Class Initialized
INFO - 2017-03-06 11:34:46 --> URI Class Initialized
INFO - 2017-03-06 11:34:46 --> Router Class Initialized
INFO - 2017-03-06 11:34:46 --> Output Class Initialized
INFO - 2017-03-06 11:34:46 --> Security Class Initialized
DEBUG - 2017-03-06 11:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:34:46 --> Input Class Initialized
INFO - 2017-03-06 11:34:46 --> Language Class Initialized
INFO - 2017-03-06 11:34:46 --> Language Class Initialized
INFO - 2017-03-06 11:34:46 --> Config Class Initialized
INFO - 2017-03-06 11:34:46 --> Loader Class Initialized
INFO - 2017-03-06 11:34:46 --> Helper loaded: form_helper
INFO - 2017-03-06 11:34:46 --> Helper loaded: url_helper
INFO - 2017-03-06 11:34:46 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:34:46 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:34:46 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:34:46 --> Template Class Initialized
INFO - 2017-03-06 11:34:46 --> Model Class Initialized
INFO - 2017-03-06 11:34:46 --> Controller Class Initialized
DEBUG - 2017-03-06 11:34:46 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:34:46 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:34:46 --> Final output sent to browser
DEBUG - 2017-03-06 11:34:46 --> Total execution time: 0.0126
INFO - 2017-03-06 11:34:51 --> Config Class Initialized
INFO - 2017-03-06 11:34:51 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:34:51 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:34:51 --> Utf8 Class Initialized
INFO - 2017-03-06 11:34:51 --> URI Class Initialized
INFO - 2017-03-06 11:34:51 --> Router Class Initialized
INFO - 2017-03-06 11:34:51 --> Output Class Initialized
INFO - 2017-03-06 11:34:51 --> Security Class Initialized
DEBUG - 2017-03-06 11:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:34:51 --> Input Class Initialized
INFO - 2017-03-06 11:34:51 --> Language Class Initialized
INFO - 2017-03-06 11:34:51 --> Language Class Initialized
INFO - 2017-03-06 11:34:51 --> Config Class Initialized
INFO - 2017-03-06 11:34:51 --> Loader Class Initialized
INFO - 2017-03-06 11:34:51 --> Helper loaded: form_helper
INFO - 2017-03-06 11:34:51 --> Helper loaded: url_helper
INFO - 2017-03-06 11:34:51 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:34:51 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:34:51 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:34:51 --> Template Class Initialized
INFO - 2017-03-06 11:34:51 --> Model Class Initialized
INFO - 2017-03-06 11:34:51 --> Controller Class Initialized
DEBUG - 2017-03-06 11:34:51 --> Dashboard MX_Controller Initialized
INFO - 2017-03-06 11:34:51 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:34:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:34:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:34:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:34:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-06 11:34:51 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:34:51 --> Final output sent to browser
DEBUG - 2017-03-06 11:34:51 --> Total execution time: 0.0419
INFO - 2017-03-06 11:34:53 --> Config Class Initialized
INFO - 2017-03-06 11:34:53 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:34:53 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:34:53 --> Utf8 Class Initialized
INFO - 2017-03-06 11:34:53 --> URI Class Initialized
INFO - 2017-03-06 11:34:53 --> Router Class Initialized
INFO - 2017-03-06 11:34:53 --> Output Class Initialized
INFO - 2017-03-06 11:34:53 --> Security Class Initialized
DEBUG - 2017-03-06 11:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:34:53 --> Input Class Initialized
INFO - 2017-03-06 11:34:53 --> Language Class Initialized
INFO - 2017-03-06 11:34:53 --> Language Class Initialized
INFO - 2017-03-06 11:34:53 --> Config Class Initialized
INFO - 2017-03-06 11:34:53 --> Loader Class Initialized
INFO - 2017-03-06 11:34:53 --> Helper loaded: form_helper
INFO - 2017-03-06 11:34:53 --> Helper loaded: url_helper
INFO - 2017-03-06 11:34:53 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:34:53 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:34:53 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:34:53 --> Template Class Initialized
INFO - 2017-03-06 11:34:53 --> Model Class Initialized
INFO - 2017-03-06 11:34:53 --> Controller Class Initialized
DEBUG - 2017-03-06 11:34:53 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:34:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:34:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:34:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:35:14 --> Config Class Initialized
INFO - 2017-03-06 11:35:14 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:35:14 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:35:14 --> Utf8 Class Initialized
INFO - 2017-03-06 11:35:14 --> URI Class Initialized
INFO - 2017-03-06 11:35:14 --> Router Class Initialized
INFO - 2017-03-06 11:35:14 --> Output Class Initialized
INFO - 2017-03-06 11:35:14 --> Security Class Initialized
DEBUG - 2017-03-06 11:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:35:14 --> Input Class Initialized
INFO - 2017-03-06 11:35:14 --> Language Class Initialized
INFO - 2017-03-06 11:35:14 --> Language Class Initialized
INFO - 2017-03-06 11:35:14 --> Config Class Initialized
INFO - 2017-03-06 11:35:14 --> Loader Class Initialized
INFO - 2017-03-06 11:35:14 --> Helper loaded: form_helper
INFO - 2017-03-06 11:35:14 --> Helper loaded: url_helper
INFO - 2017-03-06 11:35:14 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:35:14 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:35:14 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:35:14 --> Template Class Initialized
INFO - 2017-03-06 11:35:14 --> Model Class Initialized
INFO - 2017-03-06 11:35:14 --> Controller Class Initialized
DEBUG - 2017-03-06 11:35:14 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:35:14 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:35:14 --> Model Class Initialized
DEBUG - 2017-03-06 11:35:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:35:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:35:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:35:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/project_list.php
DEBUG - 2017-03-06 11:35:14 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:35:14 --> Final output sent to browser
DEBUG - 2017-03-06 11:35:14 --> Total execution time: 0.0495
INFO - 2017-03-06 11:35:17 --> Config Class Initialized
INFO - 2017-03-06 11:35:17 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:35:17 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:35:17 --> Utf8 Class Initialized
INFO - 2017-03-06 11:35:17 --> URI Class Initialized
INFO - 2017-03-06 11:35:17 --> Router Class Initialized
INFO - 2017-03-06 11:35:17 --> Output Class Initialized
INFO - 2017-03-06 11:35:17 --> Security Class Initialized
DEBUG - 2017-03-06 11:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:35:17 --> Input Class Initialized
INFO - 2017-03-06 11:35:17 --> Language Class Initialized
INFO - 2017-03-06 11:35:17 --> Language Class Initialized
INFO - 2017-03-06 11:35:17 --> Config Class Initialized
INFO - 2017-03-06 11:35:17 --> Loader Class Initialized
INFO - 2017-03-06 11:35:17 --> Helper loaded: form_helper
INFO - 2017-03-06 11:35:17 --> Helper loaded: url_helper
INFO - 2017-03-06 11:35:17 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:35:17 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:35:17 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:35:17 --> Template Class Initialized
INFO - 2017-03-06 11:35:17 --> Model Class Initialized
INFO - 2017-03-06 11:35:17 --> Controller Class Initialized
DEBUG - 2017-03-06 11:35:17 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:35:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:35:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:35:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:35:22 --> Config Class Initialized
INFO - 2017-03-06 11:35:22 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:35:22 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:35:22 --> Utf8 Class Initialized
INFO - 2017-03-06 11:35:22 --> URI Class Initialized
INFO - 2017-03-06 11:35:22 --> Router Class Initialized
INFO - 2017-03-06 11:35:22 --> Output Class Initialized
INFO - 2017-03-06 11:35:22 --> Security Class Initialized
DEBUG - 2017-03-06 11:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:35:22 --> Input Class Initialized
INFO - 2017-03-06 11:35:22 --> Language Class Initialized
INFO - 2017-03-06 11:35:22 --> Language Class Initialized
INFO - 2017-03-06 11:35:22 --> Config Class Initialized
INFO - 2017-03-06 11:35:22 --> Loader Class Initialized
INFO - 2017-03-06 11:35:22 --> Helper loaded: form_helper
INFO - 2017-03-06 11:35:22 --> Helper loaded: url_helper
INFO - 2017-03-06 11:35:22 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:35:22 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:35:22 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:35:22 --> Template Class Initialized
INFO - 2017-03-06 11:35:22 --> Model Class Initialized
INFO - 2017-03-06 11:35:22 --> Controller Class Initialized
DEBUG - 2017-03-06 11:35:22 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:35:22 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:35:22 --> Upload Class Initialized
INFO - 2017-03-06 11:35:22 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-03-06 11:35:22 --> The upload path does not appear to be valid.
INFO - 2017-03-06 11:35:22 --> Model Class Initialized
INFO - 2017-03-06 11:35:22 --> Final output sent to browser
DEBUG - 2017-03-06 11:35:22 --> Total execution time: 0.0749
INFO - 2017-03-06 11:35:45 --> Config Class Initialized
INFO - 2017-03-06 11:35:45 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:35:45 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:35:45 --> Utf8 Class Initialized
INFO - 2017-03-06 11:35:45 --> URI Class Initialized
INFO - 2017-03-06 11:35:45 --> Router Class Initialized
INFO - 2017-03-06 11:35:45 --> Output Class Initialized
INFO - 2017-03-06 11:35:45 --> Security Class Initialized
DEBUG - 2017-03-06 11:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:35:45 --> Input Class Initialized
INFO - 2017-03-06 11:35:45 --> Language Class Initialized
INFO - 2017-03-06 11:35:45 --> Language Class Initialized
INFO - 2017-03-06 11:35:45 --> Config Class Initialized
INFO - 2017-03-06 11:35:45 --> Loader Class Initialized
INFO - 2017-03-06 11:35:45 --> Helper loaded: form_helper
INFO - 2017-03-06 11:35:45 --> Helper loaded: url_helper
INFO - 2017-03-06 11:35:45 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:35:45 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:35:45 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:35:45 --> Template Class Initialized
INFO - 2017-03-06 11:35:45 --> Model Class Initialized
INFO - 2017-03-06 11:35:45 --> Controller Class Initialized
DEBUG - 2017-03-06 11:35:45 --> Dashboard MX_Controller Initialized
INFO - 2017-03-06 11:35:45 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:35:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:35:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:35:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:35:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-06 11:35:45 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:35:45 --> Final output sent to browser
DEBUG - 2017-03-06 11:35:45 --> Total execution time: 0.0956
INFO - 2017-03-06 11:35:46 --> Config Class Initialized
INFO - 2017-03-06 11:35:46 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:35:46 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:35:46 --> Utf8 Class Initialized
INFO - 2017-03-06 11:35:46 --> URI Class Initialized
INFO - 2017-03-06 11:35:46 --> Router Class Initialized
INFO - 2017-03-06 11:35:46 --> Output Class Initialized
INFO - 2017-03-06 11:35:46 --> Security Class Initialized
DEBUG - 2017-03-06 11:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:35:46 --> Input Class Initialized
INFO - 2017-03-06 11:35:46 --> Language Class Initialized
INFO - 2017-03-06 11:35:46 --> Language Class Initialized
INFO - 2017-03-06 11:35:46 --> Config Class Initialized
INFO - 2017-03-06 11:35:46 --> Loader Class Initialized
INFO - 2017-03-06 11:35:46 --> Helper loaded: form_helper
INFO - 2017-03-06 11:35:46 --> Helper loaded: url_helper
INFO - 2017-03-06 11:35:46 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:35:46 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:35:46 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:35:46 --> Template Class Initialized
INFO - 2017-03-06 11:35:46 --> Model Class Initialized
INFO - 2017-03-06 11:35:46 --> Controller Class Initialized
DEBUG - 2017-03-06 11:35:46 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:35:46 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:35:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:35:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:35:50 --> Config Class Initialized
INFO - 2017-03-06 11:35:50 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:35:50 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:35:50 --> Utf8 Class Initialized
INFO - 2017-03-06 11:35:50 --> URI Class Initialized
INFO - 2017-03-06 11:35:50 --> Router Class Initialized
INFO - 2017-03-06 11:35:50 --> Output Class Initialized
INFO - 2017-03-06 11:35:50 --> Security Class Initialized
DEBUG - 2017-03-06 11:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:35:50 --> Input Class Initialized
INFO - 2017-03-06 11:35:50 --> Language Class Initialized
INFO - 2017-03-06 11:35:50 --> Language Class Initialized
INFO - 2017-03-06 11:35:50 --> Config Class Initialized
INFO - 2017-03-06 11:35:50 --> Loader Class Initialized
INFO - 2017-03-06 11:35:50 --> Helper loaded: form_helper
INFO - 2017-03-06 11:35:50 --> Helper loaded: url_helper
INFO - 2017-03-06 11:35:50 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:35:50 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:35:50 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:35:50 --> Template Class Initialized
INFO - 2017-03-06 11:35:50 --> Model Class Initialized
INFO - 2017-03-06 11:35:50 --> Controller Class Initialized
DEBUG - 2017-03-06 11:35:50 --> Download_data MX_Controller Initialized
INFO - 2017-03-06 11:35:50 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:35:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:35:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:35:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:35:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/download_data.php
DEBUG - 2017-03-06 11:35:50 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:35:50 --> Final output sent to browser
DEBUG - 2017-03-06 11:35:50 --> Total execution time: 0.0258
INFO - 2017-03-06 11:35:51 --> Config Class Initialized
INFO - 2017-03-06 11:35:51 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:35:51 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:35:51 --> Utf8 Class Initialized
INFO - 2017-03-06 11:35:51 --> URI Class Initialized
INFO - 2017-03-06 11:35:51 --> Router Class Initialized
INFO - 2017-03-06 11:35:51 --> Output Class Initialized
INFO - 2017-03-06 11:35:51 --> Security Class Initialized
DEBUG - 2017-03-06 11:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:35:51 --> Input Class Initialized
INFO - 2017-03-06 11:35:51 --> Language Class Initialized
INFO - 2017-03-06 11:35:51 --> Language Class Initialized
INFO - 2017-03-06 11:35:51 --> Config Class Initialized
INFO - 2017-03-06 11:35:51 --> Loader Class Initialized
INFO - 2017-03-06 11:35:51 --> Helper loaded: form_helper
INFO - 2017-03-06 11:35:51 --> Helper loaded: url_helper
INFO - 2017-03-06 11:35:51 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:35:51 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:35:51 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:35:51 --> Template Class Initialized
INFO - 2017-03-06 11:35:51 --> Model Class Initialized
INFO - 2017-03-06 11:35:51 --> Controller Class Initialized
DEBUG - 2017-03-06 11:35:51 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:35:51 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:35:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:35:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:35:52 --> Config Class Initialized
INFO - 2017-03-06 11:35:52 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:35:52 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:35:52 --> Utf8 Class Initialized
INFO - 2017-03-06 11:35:52 --> URI Class Initialized
INFO - 2017-03-06 11:35:52 --> Router Class Initialized
INFO - 2017-03-06 11:35:52 --> Output Class Initialized
INFO - 2017-03-06 11:35:52 --> Security Class Initialized
DEBUG - 2017-03-06 11:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:35:52 --> Input Class Initialized
INFO - 2017-03-06 11:35:52 --> Language Class Initialized
INFO - 2017-03-06 11:35:52 --> Language Class Initialized
INFO - 2017-03-06 11:35:52 --> Config Class Initialized
INFO - 2017-03-06 11:35:52 --> Loader Class Initialized
INFO - 2017-03-06 11:35:52 --> Helper loaded: form_helper
INFO - 2017-03-06 11:35:52 --> Helper loaded: url_helper
INFO - 2017-03-06 11:35:52 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:35:52 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:35:52 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:35:52 --> Template Class Initialized
INFO - 2017-03-06 11:35:52 --> Model Class Initialized
INFO - 2017-03-06 11:35:52 --> Controller Class Initialized
DEBUG - 2017-03-06 11:35:52 --> Login MX_Controller Initialized
INFO - 2017-03-06 11:35:52 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:35:52 --> Form Validation Class Initialized
INFO - 2017-03-06 11:35:53 --> Config Class Initialized
INFO - 2017-03-06 11:35:53 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:35:53 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:35:53 --> Utf8 Class Initialized
INFO - 2017-03-06 11:35:53 --> URI Class Initialized
DEBUG - 2017-03-06 11:35:53 --> No URI present. Default controller set.
INFO - 2017-03-06 11:35:53 --> Router Class Initialized
INFO - 2017-03-06 11:35:53 --> Output Class Initialized
INFO - 2017-03-06 11:35:53 --> Security Class Initialized
DEBUG - 2017-03-06 11:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:35:53 --> Input Class Initialized
INFO - 2017-03-06 11:35:53 --> Language Class Initialized
INFO - 2017-03-06 11:35:53 --> Language Class Initialized
INFO - 2017-03-06 11:35:53 --> Config Class Initialized
INFO - 2017-03-06 11:35:53 --> Loader Class Initialized
INFO - 2017-03-06 11:35:53 --> Helper loaded: form_helper
INFO - 2017-03-06 11:35:53 --> Helper loaded: url_helper
INFO - 2017-03-06 11:35:53 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:35:53 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:35:53 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:35:53 --> Template Class Initialized
INFO - 2017-03-06 11:35:53 --> Model Class Initialized
INFO - 2017-03-06 11:35:53 --> Controller Class Initialized
DEBUG - 2017-03-06 11:35:53 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:35:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:35:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:35:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:35:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-06 11:35:53 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:35:53 --> Final output sent to browser
DEBUG - 2017-03-06 11:35:53 --> Total execution time: 0.0185
INFO - 2017-03-06 11:35:53 --> Config Class Initialized
INFO - 2017-03-06 11:35:53 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:35:53 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:35:53 --> Utf8 Class Initialized
INFO - 2017-03-06 11:35:53 --> URI Class Initialized
INFO - 2017-03-06 11:35:53 --> Router Class Initialized
INFO - 2017-03-06 11:35:53 --> Output Class Initialized
INFO - 2017-03-06 11:35:53 --> Security Class Initialized
DEBUG - 2017-03-06 11:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:35:53 --> Input Class Initialized
INFO - 2017-03-06 11:35:53 --> Language Class Initialized
INFO - 2017-03-06 11:35:53 --> Language Class Initialized
INFO - 2017-03-06 11:35:53 --> Config Class Initialized
INFO - 2017-03-06 11:35:53 --> Loader Class Initialized
INFO - 2017-03-06 11:35:53 --> Helper loaded: form_helper
INFO - 2017-03-06 11:35:53 --> Helper loaded: url_helper
INFO - 2017-03-06 11:35:53 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:35:53 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:35:53 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:35:53 --> Template Class Initialized
INFO - 2017-03-06 11:35:53 --> Model Class Initialized
INFO - 2017-03-06 11:35:53 --> Controller Class Initialized
DEBUG - 2017-03-06 11:35:53 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:35:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:35:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:35:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:35:53 --> Config Class Initialized
INFO - 2017-03-06 11:35:53 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:35:53 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:35:53 --> Utf8 Class Initialized
INFO - 2017-03-06 11:35:53 --> URI Class Initialized
INFO - 2017-03-06 11:35:53 --> Router Class Initialized
INFO - 2017-03-06 11:35:53 --> Output Class Initialized
INFO - 2017-03-06 11:35:53 --> Security Class Initialized
INFO - 2017-03-06 11:35:53 --> Config Class Initialized
INFO - 2017-03-06 11:35:53 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:35:53 --> Input Class Initialized
INFO - 2017-03-06 11:35:53 --> Language Class Initialized
DEBUG - 2017-03-06 11:35:53 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:35:53 --> Utf8 Class Initialized
INFO - 2017-03-06 11:35:53 --> URI Class Initialized
INFO - 2017-03-06 11:35:53 --> Language Class Initialized
INFO - 2017-03-06 11:35:53 --> Config Class Initialized
INFO - 2017-03-06 11:35:53 --> Loader Class Initialized
INFO - 2017-03-06 11:35:53 --> Router Class Initialized
INFO - 2017-03-06 11:35:53 --> Helper loaded: form_helper
INFO - 2017-03-06 11:35:53 --> Output Class Initialized
INFO - 2017-03-06 11:35:53 --> Helper loaded: url_helper
INFO - 2017-03-06 11:35:53 --> Security Class Initialized
INFO - 2017-03-06 11:35:53 --> Helper loaded: utility_helper
DEBUG - 2017-03-06 11:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:35:53 --> Input Class Initialized
INFO - 2017-03-06 11:35:53 --> Language Class Initialized
INFO - 2017-03-06 11:35:53 --> Database Driver Class Initialized
INFO - 2017-03-06 11:35:53 --> Language Class Initialized
INFO - 2017-03-06 11:35:53 --> Config Class Initialized
INFO - 2017-03-06 11:35:53 --> Loader Class Initialized
INFO - 2017-03-06 11:35:53 --> Helper loaded: form_helper
INFO - 2017-03-06 11:35:53 --> Helper loaded: url_helper
DEBUG - 2017-03-06 11:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:35:53 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:35:53 --> Database Driver Class Initialized
INFO - 2017-03-06 11:35:53 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:35:53 --> Template Class Initialized
INFO - 2017-03-06 11:35:53 --> Model Class Initialized
INFO - 2017-03-06 11:35:53 --> Controller Class Initialized
DEBUG - 2017-03-06 11:35:53 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:35:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:35:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:35:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:35:53 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:35:53 --> Template Class Initialized
INFO - 2017-03-06 11:35:53 --> Model Class Initialized
INFO - 2017-03-06 11:35:53 --> Controller Class Initialized
DEBUG - 2017-03-06 11:35:53 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:35:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:35:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:35:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:35:57 --> Config Class Initialized
INFO - 2017-03-06 11:35:57 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:35:57 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:35:57 --> Utf8 Class Initialized
INFO - 2017-03-06 11:35:57 --> URI Class Initialized
INFO - 2017-03-06 11:35:57 --> Router Class Initialized
INFO - 2017-03-06 11:35:57 --> Output Class Initialized
INFO - 2017-03-06 11:35:57 --> Security Class Initialized
DEBUG - 2017-03-06 11:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:35:57 --> Input Class Initialized
INFO - 2017-03-06 11:35:57 --> Language Class Initialized
INFO - 2017-03-06 11:35:57 --> Language Class Initialized
INFO - 2017-03-06 11:35:57 --> Config Class Initialized
INFO - 2017-03-06 11:35:57 --> Loader Class Initialized
INFO - 2017-03-06 11:35:57 --> Helper loaded: form_helper
INFO - 2017-03-06 11:35:57 --> Helper loaded: url_helper
INFO - 2017-03-06 11:35:57 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:35:57 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:35:57 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:35:57 --> Template Class Initialized
INFO - 2017-03-06 11:35:57 --> Model Class Initialized
INFO - 2017-03-06 11:35:57 --> Controller Class Initialized
DEBUG - 2017-03-06 11:35:57 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:35:57 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:35:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:35:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:35:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 11:35:57 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:35:57 --> Final output sent to browser
DEBUG - 2017-03-06 11:35:57 --> Total execution time: 0.0120
INFO - 2017-03-06 11:35:58 --> Config Class Initialized
INFO - 2017-03-06 11:35:58 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:35:58 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:35:58 --> Utf8 Class Initialized
INFO - 2017-03-06 11:35:58 --> URI Class Initialized
INFO - 2017-03-06 11:35:58 --> Router Class Initialized
INFO - 2017-03-06 11:35:58 --> Output Class Initialized
INFO - 2017-03-06 11:35:58 --> Security Class Initialized
DEBUG - 2017-03-06 11:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:35:58 --> Input Class Initialized
INFO - 2017-03-06 11:35:58 --> Language Class Initialized
INFO - 2017-03-06 11:35:58 --> Language Class Initialized
INFO - 2017-03-06 11:35:58 --> Config Class Initialized
INFO - 2017-03-06 11:35:58 --> Loader Class Initialized
INFO - 2017-03-06 11:35:58 --> Helper loaded: form_helper
INFO - 2017-03-06 11:35:58 --> Helper loaded: url_helper
INFO - 2017-03-06 11:35:58 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:35:58 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:35:58 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:35:58 --> Template Class Initialized
INFO - 2017-03-06 11:35:58 --> Model Class Initialized
INFO - 2017-03-06 11:35:58 --> Controller Class Initialized
DEBUG - 2017-03-06 11:35:58 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:35:58 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:35:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:35:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:35:59 --> Config Class Initialized
INFO - 2017-03-06 11:35:59 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:35:59 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:35:59 --> Utf8 Class Initialized
INFO - 2017-03-06 11:35:59 --> URI Class Initialized
INFO - 2017-03-06 11:35:59 --> Router Class Initialized
INFO - 2017-03-06 11:35:59 --> Output Class Initialized
INFO - 2017-03-06 11:35:59 --> Security Class Initialized
DEBUG - 2017-03-06 11:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:35:59 --> Input Class Initialized
INFO - 2017-03-06 11:35:59 --> Language Class Initialized
INFO - 2017-03-06 11:35:59 --> Language Class Initialized
INFO - 2017-03-06 11:35:59 --> Config Class Initialized
INFO - 2017-03-06 11:35:59 --> Loader Class Initialized
INFO - 2017-03-06 11:35:59 --> Helper loaded: form_helper
INFO - 2017-03-06 11:35:59 --> Helper loaded: url_helper
INFO - 2017-03-06 11:35:59 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:35:59 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:35:59 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:35:59 --> Template Class Initialized
INFO - 2017-03-06 11:35:59 --> Model Class Initialized
INFO - 2017-03-06 11:35:59 --> Controller Class Initialized
DEBUG - 2017-03-06 11:35:59 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:35:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:35:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:35:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:36:04 --> Config Class Initialized
INFO - 2017-03-06 11:36:04 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:36:04 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:36:04 --> Utf8 Class Initialized
INFO - 2017-03-06 11:36:04 --> URI Class Initialized
INFO - 2017-03-06 11:36:04 --> Router Class Initialized
INFO - 2017-03-06 11:36:04 --> Output Class Initialized
INFO - 2017-03-06 11:36:04 --> Security Class Initialized
DEBUG - 2017-03-06 11:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:36:04 --> Input Class Initialized
INFO - 2017-03-06 11:36:04 --> Language Class Initialized
INFO - 2017-03-06 11:36:04 --> Language Class Initialized
INFO - 2017-03-06 11:36:04 --> Config Class Initialized
INFO - 2017-03-06 11:36:04 --> Loader Class Initialized
INFO - 2017-03-06 11:36:04 --> Helper loaded: form_helper
INFO - 2017-03-06 11:36:04 --> Helper loaded: url_helper
INFO - 2017-03-06 11:36:04 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:36:04 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:36:04 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:36:04 --> Template Class Initialized
INFO - 2017-03-06 11:36:04 --> Model Class Initialized
INFO - 2017-03-06 11:36:04 --> Controller Class Initialized
DEBUG - 2017-03-06 11:36:04 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:36:04 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:36:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:36:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:36:05 --> Config Class Initialized
INFO - 2017-03-06 11:36:05 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:36:05 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:36:05 --> Utf8 Class Initialized
INFO - 2017-03-06 11:36:05 --> URI Class Initialized
INFO - 2017-03-06 11:36:05 --> Router Class Initialized
INFO - 2017-03-06 11:36:05 --> Output Class Initialized
INFO - 2017-03-06 11:36:05 --> Security Class Initialized
DEBUG - 2017-03-06 11:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:36:05 --> Input Class Initialized
INFO - 2017-03-06 11:36:05 --> Language Class Initialized
INFO - 2017-03-06 11:36:05 --> Language Class Initialized
INFO - 2017-03-06 11:36:05 --> Config Class Initialized
INFO - 2017-03-06 11:36:05 --> Loader Class Initialized
INFO - 2017-03-06 11:36:05 --> Helper loaded: form_helper
INFO - 2017-03-06 11:36:05 --> Helper loaded: url_helper
INFO - 2017-03-06 11:36:05 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:36:05 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:36:05 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:36:05 --> Template Class Initialized
INFO - 2017-03-06 11:36:05 --> Model Class Initialized
INFO - 2017-03-06 11:36:05 --> Controller Class Initialized
DEBUG - 2017-03-06 11:36:05 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:36:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:36:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:36:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:36:06 --> Config Class Initialized
INFO - 2017-03-06 11:36:06 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:36:06 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:36:06 --> Utf8 Class Initialized
INFO - 2017-03-06 11:36:06 --> URI Class Initialized
INFO - 2017-03-06 11:36:06 --> Router Class Initialized
INFO - 2017-03-06 11:36:06 --> Output Class Initialized
INFO - 2017-03-06 11:36:06 --> Security Class Initialized
DEBUG - 2017-03-06 11:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:36:06 --> Input Class Initialized
INFO - 2017-03-06 11:36:06 --> Language Class Initialized
INFO - 2017-03-06 11:36:06 --> Language Class Initialized
INFO - 2017-03-06 11:36:06 --> Config Class Initialized
INFO - 2017-03-06 11:36:06 --> Loader Class Initialized
INFO - 2017-03-06 11:36:06 --> Helper loaded: form_helper
INFO - 2017-03-06 11:36:06 --> Helper loaded: url_helper
INFO - 2017-03-06 11:36:06 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:36:06 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:36:06 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:36:06 --> Template Class Initialized
INFO - 2017-03-06 11:36:06 --> Model Class Initialized
INFO - 2017-03-06 11:36:06 --> Controller Class Initialized
DEBUG - 2017-03-06 11:36:06 --> Download_data MX_Controller Initialized
INFO - 2017-03-06 11:36:06 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:36:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:36:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:36:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:36:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/download_data.php
DEBUG - 2017-03-06 11:36:06 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:36:06 --> Final output sent to browser
DEBUG - 2017-03-06 11:36:06 --> Total execution time: 0.0189
INFO - 2017-03-06 11:36:07 --> Config Class Initialized
INFO - 2017-03-06 11:36:07 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:36:07 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:36:07 --> Utf8 Class Initialized
INFO - 2017-03-06 11:36:07 --> URI Class Initialized
INFO - 2017-03-06 11:36:07 --> Router Class Initialized
INFO - 2017-03-06 11:36:07 --> Output Class Initialized
INFO - 2017-03-06 11:36:07 --> Security Class Initialized
DEBUG - 2017-03-06 11:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:36:07 --> Input Class Initialized
INFO - 2017-03-06 11:36:07 --> Language Class Initialized
INFO - 2017-03-06 11:36:07 --> Language Class Initialized
INFO - 2017-03-06 11:36:07 --> Config Class Initialized
INFO - 2017-03-06 11:36:07 --> Loader Class Initialized
INFO - 2017-03-06 11:36:07 --> Helper loaded: form_helper
INFO - 2017-03-06 11:36:07 --> Helper loaded: url_helper
INFO - 2017-03-06 11:36:07 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:36:07 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:36:07 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:36:07 --> Template Class Initialized
INFO - 2017-03-06 11:36:07 --> Model Class Initialized
INFO - 2017-03-06 11:36:07 --> Controller Class Initialized
DEBUG - 2017-03-06 11:36:07 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:36:07 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:36:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:36:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:36:34 --> Config Class Initialized
INFO - 2017-03-06 11:36:34 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:36:34 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:36:34 --> Utf8 Class Initialized
INFO - 2017-03-06 11:36:34 --> URI Class Initialized
INFO - 2017-03-06 11:36:34 --> Router Class Initialized
INFO - 2017-03-06 11:36:34 --> Output Class Initialized
INFO - 2017-03-06 11:36:34 --> Security Class Initialized
DEBUG - 2017-03-06 11:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:36:34 --> Input Class Initialized
INFO - 2017-03-06 11:36:34 --> Language Class Initialized
INFO - 2017-03-06 11:36:34 --> Language Class Initialized
INFO - 2017-03-06 11:36:34 --> Config Class Initialized
INFO - 2017-03-06 11:36:34 --> Loader Class Initialized
INFO - 2017-03-06 11:36:34 --> Helper loaded: form_helper
INFO - 2017-03-06 11:36:34 --> Helper loaded: url_helper
INFO - 2017-03-06 11:36:34 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:36:34 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:36:34 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:36:34 --> Template Class Initialized
INFO - 2017-03-06 11:36:34 --> Model Class Initialized
INFO - 2017-03-06 11:36:34 --> Controller Class Initialized
DEBUG - 2017-03-06 11:36:34 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:36:34 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:36:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:36:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:36:34 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 11:36:34 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:36:34 --> Final output sent to browser
DEBUG - 2017-03-06 11:36:34 --> Total execution time: 0.0165
INFO - 2017-03-06 11:36:37 --> Config Class Initialized
INFO - 2017-03-06 11:36:37 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:36:37 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:36:37 --> Utf8 Class Initialized
INFO - 2017-03-06 11:36:37 --> URI Class Initialized
INFO - 2017-03-06 11:36:37 --> Router Class Initialized
INFO - 2017-03-06 11:36:37 --> Output Class Initialized
INFO - 2017-03-06 11:36:37 --> Security Class Initialized
DEBUG - 2017-03-06 11:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:36:37 --> Input Class Initialized
INFO - 2017-03-06 11:36:37 --> Language Class Initialized
INFO - 2017-03-06 11:36:37 --> Language Class Initialized
INFO - 2017-03-06 11:36:37 --> Config Class Initialized
INFO - 2017-03-06 11:36:37 --> Loader Class Initialized
INFO - 2017-03-06 11:36:37 --> Helper loaded: form_helper
INFO - 2017-03-06 11:36:37 --> Helper loaded: url_helper
INFO - 2017-03-06 11:36:37 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:36:37 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:36:37 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:36:37 --> Template Class Initialized
INFO - 2017-03-06 11:36:37 --> Model Class Initialized
INFO - 2017-03-06 11:36:37 --> Controller Class Initialized
DEBUG - 2017-03-06 11:36:37 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:36:37 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:36:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:36:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:38:22 --> Config Class Initialized
INFO - 2017-03-06 11:38:22 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:38:22 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:38:22 --> Utf8 Class Initialized
INFO - 2017-03-06 11:38:22 --> URI Class Initialized
INFO - 2017-03-06 11:38:22 --> Router Class Initialized
INFO - 2017-03-06 11:38:22 --> Output Class Initialized
INFO - 2017-03-06 11:38:22 --> Security Class Initialized
DEBUG - 2017-03-06 11:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:38:22 --> Input Class Initialized
INFO - 2017-03-06 11:38:22 --> Language Class Initialized
INFO - 2017-03-06 11:38:22 --> Language Class Initialized
INFO - 2017-03-06 11:38:22 --> Config Class Initialized
INFO - 2017-03-06 11:38:22 --> Loader Class Initialized
INFO - 2017-03-06 11:38:22 --> Helper loaded: form_helper
INFO - 2017-03-06 11:38:22 --> Helper loaded: url_helper
INFO - 2017-03-06 11:38:22 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:38:22 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:38:22 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:38:22 --> Template Class Initialized
INFO - 2017-03-06 11:38:22 --> Model Class Initialized
INFO - 2017-03-06 11:38:22 --> Controller Class Initialized
DEBUG - 2017-03-06 11:38:22 --> Login MX_Controller Initialized
INFO - 2017-03-06 11:38:22 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:38:22 --> Form Validation Class Initialized
INFO - 2017-03-06 11:38:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-06 11:38:22 --> Config Class Initialized
INFO - 2017-03-06 11:38:22 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:38:22 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:38:22 --> Utf8 Class Initialized
INFO - 2017-03-06 11:38:22 --> URI Class Initialized
INFO - 2017-03-06 11:38:22 --> Router Class Initialized
INFO - 2017-03-06 11:38:22 --> Output Class Initialized
INFO - 2017-03-06 11:38:22 --> Security Class Initialized
DEBUG - 2017-03-06 11:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:38:22 --> Input Class Initialized
INFO - 2017-03-06 11:38:22 --> Language Class Initialized
INFO - 2017-03-06 11:38:22 --> Language Class Initialized
INFO - 2017-03-06 11:38:22 --> Config Class Initialized
INFO - 2017-03-06 11:38:22 --> Loader Class Initialized
INFO - 2017-03-06 11:38:22 --> Helper loaded: form_helper
INFO - 2017-03-06 11:38:22 --> Helper loaded: url_helper
INFO - 2017-03-06 11:38:22 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:38:22 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:38:22 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:38:22 --> Template Class Initialized
INFO - 2017-03-06 11:38:22 --> Model Class Initialized
INFO - 2017-03-06 11:38:22 --> Controller Class Initialized
DEBUG - 2017-03-06 11:38:22 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:38:22 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:38:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:38:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:38:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 11:38:22 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:38:22 --> Final output sent to browser
DEBUG - 2017-03-06 11:38:22 --> Total execution time: 0.0118
INFO - 2017-03-06 11:38:22 --> Config Class Initialized
INFO - 2017-03-06 11:38:22 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:38:22 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:38:22 --> Utf8 Class Initialized
INFO - 2017-03-06 11:38:22 --> URI Class Initialized
INFO - 2017-03-06 11:38:22 --> Router Class Initialized
INFO - 2017-03-06 11:38:22 --> Output Class Initialized
INFO - 2017-03-06 11:38:22 --> Security Class Initialized
DEBUG - 2017-03-06 11:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:38:22 --> Input Class Initialized
INFO - 2017-03-06 11:38:22 --> Language Class Initialized
INFO - 2017-03-06 11:38:22 --> Language Class Initialized
INFO - 2017-03-06 11:38:22 --> Config Class Initialized
INFO - 2017-03-06 11:38:22 --> Loader Class Initialized
INFO - 2017-03-06 11:38:22 --> Helper loaded: form_helper
INFO - 2017-03-06 11:38:22 --> Helper loaded: url_helper
INFO - 2017-03-06 11:38:22 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:38:22 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:38:22 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:38:22 --> Template Class Initialized
INFO - 2017-03-06 11:38:22 --> Model Class Initialized
INFO - 2017-03-06 11:38:22 --> Controller Class Initialized
DEBUG - 2017-03-06 11:38:22 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:38:22 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:38:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:38:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:38:23 --> Config Class Initialized
INFO - 2017-03-06 11:38:23 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:38:23 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:38:23 --> Utf8 Class Initialized
INFO - 2017-03-06 11:38:23 --> URI Class Initialized
INFO - 2017-03-06 11:38:23 --> Router Class Initialized
INFO - 2017-03-06 11:38:23 --> Output Class Initialized
INFO - 2017-03-06 11:38:23 --> Security Class Initialized
DEBUG - 2017-03-06 11:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:38:23 --> Input Class Initialized
INFO - 2017-03-06 11:38:23 --> Language Class Initialized
INFO - 2017-03-06 11:38:23 --> Language Class Initialized
INFO - 2017-03-06 11:38:23 --> Config Class Initialized
INFO - 2017-03-06 11:38:23 --> Loader Class Initialized
INFO - 2017-03-06 11:38:23 --> Helper loaded: form_helper
INFO - 2017-03-06 11:38:23 --> Helper loaded: url_helper
INFO - 2017-03-06 11:38:23 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:38:23 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:38:23 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:38:23 --> Template Class Initialized
INFO - 2017-03-06 11:38:23 --> Model Class Initialized
INFO - 2017-03-06 11:38:23 --> Controller Class Initialized
DEBUG - 2017-03-06 11:38:23 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:38:23 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:38:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:38:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:38:34 --> Config Class Initialized
INFO - 2017-03-06 11:38:34 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:38:34 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:38:34 --> Utf8 Class Initialized
INFO - 2017-03-06 11:38:34 --> URI Class Initialized
INFO - 2017-03-06 11:38:34 --> Router Class Initialized
INFO - 2017-03-06 11:38:34 --> Output Class Initialized
INFO - 2017-03-06 11:38:34 --> Security Class Initialized
DEBUG - 2017-03-06 11:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:38:34 --> Input Class Initialized
INFO - 2017-03-06 11:38:34 --> Language Class Initialized
INFO - 2017-03-06 11:38:34 --> Language Class Initialized
INFO - 2017-03-06 11:38:34 --> Config Class Initialized
INFO - 2017-03-06 11:38:34 --> Loader Class Initialized
INFO - 2017-03-06 11:38:34 --> Helper loaded: form_helper
INFO - 2017-03-06 11:38:34 --> Helper loaded: url_helper
INFO - 2017-03-06 11:38:34 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:38:34 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:38:34 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:38:34 --> Template Class Initialized
INFO - 2017-03-06 11:38:34 --> Model Class Initialized
INFO - 2017-03-06 11:38:34 --> Controller Class Initialized
DEBUG - 2017-03-06 11:38:34 --> Login MX_Controller Initialized
INFO - 2017-03-06 11:38:34 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:38:34 --> Form Validation Class Initialized
INFO - 2017-03-06 11:38:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-06 11:38:36 --> Config Class Initialized
INFO - 2017-03-06 11:38:36 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:38:36 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:38:36 --> Utf8 Class Initialized
INFO - 2017-03-06 11:38:36 --> URI Class Initialized
INFO - 2017-03-06 11:38:36 --> Router Class Initialized
INFO - 2017-03-06 11:38:36 --> Output Class Initialized
INFO - 2017-03-06 11:38:36 --> Security Class Initialized
DEBUG - 2017-03-06 11:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:38:36 --> Input Class Initialized
INFO - 2017-03-06 11:38:36 --> Language Class Initialized
INFO - 2017-03-06 11:38:36 --> Language Class Initialized
INFO - 2017-03-06 11:38:36 --> Config Class Initialized
INFO - 2017-03-06 11:38:36 --> Loader Class Initialized
INFO - 2017-03-06 11:38:36 --> Helper loaded: form_helper
INFO - 2017-03-06 11:38:36 --> Helper loaded: url_helper
INFO - 2017-03-06 11:38:36 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:38:36 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:38:36 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:38:36 --> Template Class Initialized
INFO - 2017-03-06 11:38:36 --> Model Class Initialized
INFO - 2017-03-06 11:38:36 --> Controller Class Initialized
DEBUG - 2017-03-06 11:38:36 --> Dashboard MX_Controller Initialized
INFO - 2017-03-06 11:38:36 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:38:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:38:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:38:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:38:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-06 11:38:36 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:38:36 --> Final output sent to browser
DEBUG - 2017-03-06 11:38:36 --> Total execution time: 0.0175
INFO - 2017-03-06 11:38:53 --> Config Class Initialized
INFO - 2017-03-06 11:38:53 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:38:53 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:38:53 --> Utf8 Class Initialized
INFO - 2017-03-06 11:38:53 --> URI Class Initialized
INFO - 2017-03-06 11:38:53 --> Router Class Initialized
INFO - 2017-03-06 11:38:53 --> Output Class Initialized
INFO - 2017-03-06 11:38:53 --> Security Class Initialized
DEBUG - 2017-03-06 11:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:38:53 --> Input Class Initialized
INFO - 2017-03-06 11:38:53 --> Language Class Initialized
INFO - 2017-03-06 11:38:53 --> Language Class Initialized
INFO - 2017-03-06 11:38:53 --> Config Class Initialized
INFO - 2017-03-06 11:38:53 --> Loader Class Initialized
INFO - 2017-03-06 11:38:53 --> Helper loaded: form_helper
INFO - 2017-03-06 11:38:53 --> Helper loaded: url_helper
INFO - 2017-03-06 11:38:53 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:38:53 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:38:53 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:38:53 --> Template Class Initialized
INFO - 2017-03-06 11:38:53 --> Model Class Initialized
INFO - 2017-03-06 11:38:53 --> Controller Class Initialized
DEBUG - 2017-03-06 11:38:53 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:38:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:38:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:38:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:38:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 11:38:53 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:38:53 --> Final output sent to browser
DEBUG - 2017-03-06 11:38:53 --> Total execution time: 0.0422
INFO - 2017-03-06 11:38:54 --> Config Class Initialized
INFO - 2017-03-06 11:38:54 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:38:54 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:38:54 --> Utf8 Class Initialized
INFO - 2017-03-06 11:38:54 --> URI Class Initialized
INFO - 2017-03-06 11:38:54 --> Router Class Initialized
INFO - 2017-03-06 11:38:54 --> Output Class Initialized
INFO - 2017-03-06 11:38:54 --> Security Class Initialized
DEBUG - 2017-03-06 11:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:38:54 --> Input Class Initialized
INFO - 2017-03-06 11:38:54 --> Language Class Initialized
INFO - 2017-03-06 11:38:54 --> Language Class Initialized
INFO - 2017-03-06 11:38:54 --> Config Class Initialized
INFO - 2017-03-06 11:38:54 --> Loader Class Initialized
INFO - 2017-03-06 11:38:54 --> Helper loaded: form_helper
INFO - 2017-03-06 11:38:54 --> Helper loaded: url_helper
INFO - 2017-03-06 11:38:54 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:38:54 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:38:54 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:38:54 --> Template Class Initialized
INFO - 2017-03-06 11:38:54 --> Model Class Initialized
INFO - 2017-03-06 11:38:54 --> Controller Class Initialized
DEBUG - 2017-03-06 11:38:54 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:38:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:38:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:38:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:38:56 --> Config Class Initialized
INFO - 2017-03-06 11:38:56 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:38:56 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:38:56 --> Utf8 Class Initialized
INFO - 2017-03-06 11:38:56 --> URI Class Initialized
DEBUG - 2017-03-06 11:38:56 --> No URI present. Default controller set.
INFO - 2017-03-06 11:38:56 --> Router Class Initialized
INFO - 2017-03-06 11:38:56 --> Output Class Initialized
INFO - 2017-03-06 11:38:56 --> Security Class Initialized
DEBUG - 2017-03-06 11:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:38:56 --> Input Class Initialized
INFO - 2017-03-06 11:38:56 --> Language Class Initialized
INFO - 2017-03-06 11:38:56 --> Language Class Initialized
INFO - 2017-03-06 11:38:56 --> Config Class Initialized
INFO - 2017-03-06 11:38:56 --> Loader Class Initialized
INFO - 2017-03-06 11:38:56 --> Helper loaded: form_helper
INFO - 2017-03-06 11:38:56 --> Helper loaded: url_helper
INFO - 2017-03-06 11:38:56 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:38:56 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:38:56 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:38:56 --> Template Class Initialized
INFO - 2017-03-06 11:38:56 --> Model Class Initialized
INFO - 2017-03-06 11:38:56 --> Controller Class Initialized
DEBUG - 2017-03-06 11:38:56 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:38:56 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:38:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:38:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:38:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-06 11:38:56 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:38:56 --> Final output sent to browser
DEBUG - 2017-03-06 11:38:56 --> Total execution time: 0.0106
INFO - 2017-03-06 11:38:56 --> Config Class Initialized
INFO - 2017-03-06 11:38:56 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:38:56 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:38:56 --> Utf8 Class Initialized
INFO - 2017-03-06 11:38:56 --> URI Class Initialized
INFO - 2017-03-06 11:38:56 --> Router Class Initialized
INFO - 2017-03-06 11:38:56 --> Output Class Initialized
INFO - 2017-03-06 11:38:56 --> Security Class Initialized
DEBUG - 2017-03-06 11:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:38:56 --> Input Class Initialized
INFO - 2017-03-06 11:38:56 --> Language Class Initialized
INFO - 2017-03-06 11:38:56 --> Language Class Initialized
INFO - 2017-03-06 11:38:56 --> Config Class Initialized
INFO - 2017-03-06 11:38:56 --> Loader Class Initialized
INFO - 2017-03-06 11:38:56 --> Helper loaded: form_helper
INFO - 2017-03-06 11:38:56 --> Helper loaded: url_helper
INFO - 2017-03-06 11:38:56 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:38:56 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:38:56 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:38:56 --> Template Class Initialized
INFO - 2017-03-06 11:38:56 --> Model Class Initialized
INFO - 2017-03-06 11:38:56 --> Controller Class Initialized
DEBUG - 2017-03-06 11:38:56 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:38:56 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:38:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:38:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:38:56 --> Config Class Initialized
INFO - 2017-03-06 11:38:56 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:38:56 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:38:56 --> Utf8 Class Initialized
INFO - 2017-03-06 11:38:56 --> URI Class Initialized
INFO - 2017-03-06 11:38:56 --> Router Class Initialized
INFO - 2017-03-06 11:38:56 --> Output Class Initialized
INFO - 2017-03-06 11:38:56 --> Security Class Initialized
DEBUG - 2017-03-06 11:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:38:56 --> Input Class Initialized
INFO - 2017-03-06 11:38:56 --> Language Class Initialized
INFO - 2017-03-06 11:38:56 --> Language Class Initialized
INFO - 2017-03-06 11:38:56 --> Config Class Initialized
INFO - 2017-03-06 11:38:56 --> Loader Class Initialized
INFO - 2017-03-06 11:38:56 --> Helper loaded: form_helper
INFO - 2017-03-06 11:38:56 --> Helper loaded: url_helper
INFO - 2017-03-06 11:38:56 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:38:56 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:38:56 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:38:56 --> Template Class Initialized
INFO - 2017-03-06 11:38:56 --> Model Class Initialized
INFO - 2017-03-06 11:38:56 --> Controller Class Initialized
DEBUG - 2017-03-06 11:38:56 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:38:56 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:38:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:38:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:38:56 --> Config Class Initialized
INFO - 2017-03-06 11:38:56 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:38:56 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:38:56 --> Utf8 Class Initialized
INFO - 2017-03-06 11:38:56 --> URI Class Initialized
INFO - 2017-03-06 11:38:56 --> Router Class Initialized
INFO - 2017-03-06 11:38:56 --> Output Class Initialized
INFO - 2017-03-06 11:38:56 --> Security Class Initialized
DEBUG - 2017-03-06 11:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:38:56 --> Input Class Initialized
INFO - 2017-03-06 11:38:56 --> Language Class Initialized
INFO - 2017-03-06 11:38:56 --> Language Class Initialized
INFO - 2017-03-06 11:38:56 --> Config Class Initialized
INFO - 2017-03-06 11:38:56 --> Loader Class Initialized
INFO - 2017-03-06 11:38:56 --> Helper loaded: form_helper
INFO - 2017-03-06 11:38:56 --> Helper loaded: url_helper
INFO - 2017-03-06 11:38:56 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:38:56 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:38:56 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:38:56 --> Template Class Initialized
INFO - 2017-03-06 11:38:56 --> Model Class Initialized
INFO - 2017-03-06 11:38:56 --> Controller Class Initialized
DEBUG - 2017-03-06 11:38:56 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:38:56 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:38:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:38:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:11 --> Config Class Initialized
INFO - 2017-03-06 11:41:11 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:11 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:11 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:11 --> URI Class Initialized
DEBUG - 2017-03-06 11:41:11 --> No URI present. Default controller set.
INFO - 2017-03-06 11:41:11 --> Router Class Initialized
INFO - 2017-03-06 11:41:11 --> Output Class Initialized
INFO - 2017-03-06 11:41:11 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:11 --> Input Class Initialized
INFO - 2017-03-06 11:41:11 --> Language Class Initialized
INFO - 2017-03-06 11:41:11 --> Language Class Initialized
INFO - 2017-03-06 11:41:11 --> Config Class Initialized
INFO - 2017-03-06 11:41:11 --> Loader Class Initialized
INFO - 2017-03-06 11:41:11 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:11 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:11 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:11 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:11 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:11 --> Template Class Initialized
INFO - 2017-03-06 11:41:11 --> Model Class Initialized
INFO - 2017-03-06 11:41:11 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:11 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:41:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-06 11:41:11 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:41:11 --> Final output sent to browser
DEBUG - 2017-03-06 11:41:11 --> Total execution time: 0.0461
INFO - 2017-03-06 11:41:11 --> Config Class Initialized
INFO - 2017-03-06 11:41:11 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:11 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:11 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:11 --> URI Class Initialized
INFO - 2017-03-06 11:41:11 --> Router Class Initialized
INFO - 2017-03-06 11:41:11 --> Output Class Initialized
INFO - 2017-03-06 11:41:11 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:11 --> Input Class Initialized
INFO - 2017-03-06 11:41:11 --> Language Class Initialized
INFO - 2017-03-06 11:41:11 --> Language Class Initialized
INFO - 2017-03-06 11:41:11 --> Config Class Initialized
INFO - 2017-03-06 11:41:11 --> Loader Class Initialized
INFO - 2017-03-06 11:41:11 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:11 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:11 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:11 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:11 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:11 --> Template Class Initialized
INFO - 2017-03-06 11:41:11 --> Model Class Initialized
INFO - 2017-03-06 11:41:11 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:11 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:11 --> Config Class Initialized
INFO - 2017-03-06 11:41:11 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:11 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:11 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:11 --> URI Class Initialized
INFO - 2017-03-06 11:41:11 --> Router Class Initialized
INFO - 2017-03-06 11:41:11 --> Output Class Initialized
INFO - 2017-03-06 11:41:11 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:11 --> Input Class Initialized
INFO - 2017-03-06 11:41:11 --> Language Class Initialized
INFO - 2017-03-06 11:41:11 --> Language Class Initialized
INFO - 2017-03-06 11:41:11 --> Config Class Initialized
INFO - 2017-03-06 11:41:11 --> Loader Class Initialized
INFO - 2017-03-06 11:41:11 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:11 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:11 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:11 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:11 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:11 --> Template Class Initialized
INFO - 2017-03-06 11:41:11 --> Model Class Initialized
INFO - 2017-03-06 11:41:11 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:11 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:12 --> Config Class Initialized
INFO - 2017-03-06 11:41:12 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:12 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:12 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:12 --> URI Class Initialized
INFO - 2017-03-06 11:41:12 --> Router Class Initialized
INFO - 2017-03-06 11:41:12 --> Output Class Initialized
INFO - 2017-03-06 11:41:12 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:12 --> Input Class Initialized
INFO - 2017-03-06 11:41:12 --> Language Class Initialized
INFO - 2017-03-06 11:41:12 --> Language Class Initialized
INFO - 2017-03-06 11:41:12 --> Config Class Initialized
INFO - 2017-03-06 11:41:12 --> Loader Class Initialized
INFO - 2017-03-06 11:41:12 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:12 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:12 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:12 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:12 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:12 --> Template Class Initialized
INFO - 2017-03-06 11:41:12 --> Model Class Initialized
INFO - 2017-03-06 11:41:12 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:12 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:12 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:28 --> Config Class Initialized
INFO - 2017-03-06 11:41:28 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:28 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:28 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:28 --> URI Class Initialized
INFO - 2017-03-06 11:41:28 --> Router Class Initialized
INFO - 2017-03-06 11:41:28 --> Output Class Initialized
INFO - 2017-03-06 11:41:28 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:28 --> Input Class Initialized
INFO - 2017-03-06 11:41:28 --> Language Class Initialized
INFO - 2017-03-06 11:41:28 --> Language Class Initialized
INFO - 2017-03-06 11:41:28 --> Config Class Initialized
INFO - 2017-03-06 11:41:28 --> Loader Class Initialized
INFO - 2017-03-06 11:41:28 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:28 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:28 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:28 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:28 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:28 --> Template Class Initialized
INFO - 2017-03-06 11:41:28 --> Model Class Initialized
INFO - 2017-03-06 11:41:28 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:28 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:28 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:41:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 11:41:28 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:41:28 --> Final output sent to browser
DEBUG - 2017-03-06 11:41:28 --> Total execution time: 0.0152
INFO - 2017-03-06 11:41:28 --> Config Class Initialized
INFO - 2017-03-06 11:41:28 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:28 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:28 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:28 --> URI Class Initialized
INFO - 2017-03-06 11:41:28 --> Router Class Initialized
INFO - 2017-03-06 11:41:28 --> Output Class Initialized
INFO - 2017-03-06 11:41:28 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:28 --> Input Class Initialized
INFO - 2017-03-06 11:41:28 --> Language Class Initialized
INFO - 2017-03-06 11:41:28 --> Language Class Initialized
INFO - 2017-03-06 11:41:28 --> Config Class Initialized
INFO - 2017-03-06 11:41:28 --> Loader Class Initialized
INFO - 2017-03-06 11:41:28 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:28 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:28 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:28 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:28 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:28 --> Template Class Initialized
INFO - 2017-03-06 11:41:28 --> Model Class Initialized
INFO - 2017-03-06 11:41:28 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:28 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:28 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:41:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 11:41:28 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:41:28 --> Final output sent to browser
DEBUG - 2017-03-06 11:41:28 --> Total execution time: 0.0151
INFO - 2017-03-06 11:41:29 --> Config Class Initialized
INFO - 2017-03-06 11:41:29 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:29 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:29 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:29 --> URI Class Initialized
INFO - 2017-03-06 11:41:29 --> Router Class Initialized
INFO - 2017-03-06 11:41:29 --> Output Class Initialized
INFO - 2017-03-06 11:41:29 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:29 --> Input Class Initialized
INFO - 2017-03-06 11:41:29 --> Language Class Initialized
INFO - 2017-03-06 11:41:29 --> Language Class Initialized
INFO - 2017-03-06 11:41:29 --> Config Class Initialized
INFO - 2017-03-06 11:41:29 --> Loader Class Initialized
INFO - 2017-03-06 11:41:29 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:29 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:29 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:29 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:29 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:29 --> Template Class Initialized
INFO - 2017-03-06 11:41:29 --> Model Class Initialized
INFO - 2017-03-06 11:41:29 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:29 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:29 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:29 --> Config Class Initialized
INFO - 2017-03-06 11:41:29 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:29 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:29 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:29 --> URI Class Initialized
INFO - 2017-03-06 11:41:29 --> Router Class Initialized
INFO - 2017-03-06 11:41:29 --> Output Class Initialized
INFO - 2017-03-06 11:41:29 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:29 --> Input Class Initialized
INFO - 2017-03-06 11:41:29 --> Language Class Initialized
INFO - 2017-03-06 11:41:29 --> Language Class Initialized
INFO - 2017-03-06 11:41:29 --> Config Class Initialized
INFO - 2017-03-06 11:41:29 --> Loader Class Initialized
INFO - 2017-03-06 11:41:29 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:29 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:29 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:29 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:29 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:29 --> Template Class Initialized
INFO - 2017-03-06 11:41:29 --> Model Class Initialized
INFO - 2017-03-06 11:41:29 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:29 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:29 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:29 --> Config Class Initialized
INFO - 2017-03-06 11:41:29 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:29 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:29 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:29 --> URI Class Initialized
INFO - 2017-03-06 11:41:29 --> Router Class Initialized
INFO - 2017-03-06 11:41:29 --> Output Class Initialized
INFO - 2017-03-06 11:41:29 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:29 --> Input Class Initialized
INFO - 2017-03-06 11:41:29 --> Language Class Initialized
INFO - 2017-03-06 11:41:29 --> Language Class Initialized
INFO - 2017-03-06 11:41:29 --> Config Class Initialized
INFO - 2017-03-06 11:41:29 --> Loader Class Initialized
INFO - 2017-03-06 11:41:29 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:29 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:29 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:29 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:29 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:29 --> Template Class Initialized
INFO - 2017-03-06 11:41:29 --> Model Class Initialized
INFO - 2017-03-06 11:41:29 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:29 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:29 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:29 --> Config Class Initialized
INFO - 2017-03-06 11:41:29 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:29 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:29 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:29 --> URI Class Initialized
INFO - 2017-03-06 11:41:29 --> Router Class Initialized
INFO - 2017-03-06 11:41:29 --> Output Class Initialized
INFO - 2017-03-06 11:41:29 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:29 --> Input Class Initialized
INFO - 2017-03-06 11:41:29 --> Language Class Initialized
INFO - 2017-03-06 11:41:29 --> Language Class Initialized
INFO - 2017-03-06 11:41:29 --> Config Class Initialized
INFO - 2017-03-06 11:41:29 --> Loader Class Initialized
INFO - 2017-03-06 11:41:29 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:29 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:29 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:29 --> Database Driver Class Initialized
INFO - 2017-03-06 11:41:30 --> Config Class Initialized
INFO - 2017-03-06 11:41:30 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:30 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:30 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:30 --> URI Class Initialized
DEBUG - 2017-03-06 11:41:30 --> No URI present. Default controller set.
INFO - 2017-03-06 11:41:30 --> Router Class Initialized
INFO - 2017-03-06 11:41:30 --> Output Class Initialized
INFO - 2017-03-06 11:41:30 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:30 --> Input Class Initialized
INFO - 2017-03-06 11:41:30 --> Language Class Initialized
INFO - 2017-03-06 11:41:30 --> Language Class Initialized
INFO - 2017-03-06 11:41:30 --> Config Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:30 --> Loader Class Initialized
INFO - 2017-03-06 11:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:30 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Template Class Initialized
INFO - 2017-03-06 11:41:30 --> Model Class Initialized
INFO - 2017-03-06 11:41:30 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:30 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:41:30 --> Helper loaded: form_helper
DEBUG - 2017-03-06 11:41:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:30 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:30 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:30 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:30 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Template Class Initialized
INFO - 2017-03-06 11:41:30 --> Model Class Initialized
INFO - 2017-03-06 11:41:30 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:30 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:41:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-06 11:41:30 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:41:30 --> Final output sent to browser
DEBUG - 2017-03-06 11:41:30 --> Total execution time: 0.0410
INFO - 2017-03-06 11:41:30 --> Config Class Initialized
INFO - 2017-03-06 11:41:30 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:30 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:30 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:30 --> URI Class Initialized
INFO - 2017-03-06 11:41:30 --> Router Class Initialized
INFO - 2017-03-06 11:41:30 --> Output Class Initialized
INFO - 2017-03-06 11:41:30 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:30 --> Input Class Initialized
INFO - 2017-03-06 11:41:30 --> Language Class Initialized
INFO - 2017-03-06 11:41:30 --> Language Class Initialized
INFO - 2017-03-06 11:41:30 --> Config Class Initialized
INFO - 2017-03-06 11:41:30 --> Loader Class Initialized
INFO - 2017-03-06 11:41:30 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:30 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:30 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:30 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:30 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Template Class Initialized
INFO - 2017-03-06 11:41:30 --> Model Class Initialized
INFO - 2017-03-06 11:41:30 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:30 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:30 --> Config Class Initialized
INFO - 2017-03-06 11:41:30 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:30 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:30 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:30 --> URI Class Initialized
INFO - 2017-03-06 11:41:30 --> Router Class Initialized
INFO - 2017-03-06 11:41:30 --> Output Class Initialized
INFO - 2017-03-06 11:41:30 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:30 --> Input Class Initialized
INFO - 2017-03-06 11:41:30 --> Language Class Initialized
INFO - 2017-03-06 11:41:30 --> Language Class Initialized
INFO - 2017-03-06 11:41:30 --> Config Class Initialized
INFO - 2017-03-06 11:41:30 --> Loader Class Initialized
INFO - 2017-03-06 11:41:30 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:30 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:30 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:30 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:30 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Template Class Initialized
INFO - 2017-03-06 11:41:30 --> Model Class Initialized
INFO - 2017-03-06 11:41:30 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:30 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:30 --> Config Class Initialized
INFO - 2017-03-06 11:41:30 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:30 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:30 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:30 --> URI Class Initialized
INFO - 2017-03-06 11:41:30 --> Router Class Initialized
INFO - 2017-03-06 11:41:30 --> Output Class Initialized
INFO - 2017-03-06 11:41:30 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:30 --> Input Class Initialized
INFO - 2017-03-06 11:41:30 --> Language Class Initialized
INFO - 2017-03-06 11:41:30 --> Language Class Initialized
INFO - 2017-03-06 11:41:30 --> Config Class Initialized
INFO - 2017-03-06 11:41:30 --> Loader Class Initialized
INFO - 2017-03-06 11:41:30 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:30 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:30 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:30 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:30 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Template Class Initialized
INFO - 2017-03-06 11:41:30 --> Model Class Initialized
INFO - 2017-03-06 11:41:30 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:30 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:30 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:30 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:32 --> Config Class Initialized
INFO - 2017-03-06 11:41:32 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:32 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:32 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:32 --> URI Class Initialized
INFO - 2017-03-06 11:41:32 --> Router Class Initialized
INFO - 2017-03-06 11:41:32 --> Output Class Initialized
INFO - 2017-03-06 11:41:32 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:32 --> Input Class Initialized
INFO - 2017-03-06 11:41:32 --> Language Class Initialized
INFO - 2017-03-06 11:41:32 --> Language Class Initialized
INFO - 2017-03-06 11:41:32 --> Config Class Initialized
INFO - 2017-03-06 11:41:32 --> Loader Class Initialized
INFO - 2017-03-06 11:41:32 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:32 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:32 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:32 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:32 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:32 --> Template Class Initialized
INFO - 2017-03-06 11:41:32 --> Model Class Initialized
INFO - 2017-03-06 11:41:32 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:32 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:32 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:32 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:35 --> Config Class Initialized
INFO - 2017-03-06 11:41:35 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:35 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:35 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:35 --> URI Class Initialized
INFO - 2017-03-06 11:41:35 --> Router Class Initialized
INFO - 2017-03-06 11:41:35 --> Output Class Initialized
INFO - 2017-03-06 11:41:35 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:35 --> Input Class Initialized
INFO - 2017-03-06 11:41:35 --> Language Class Initialized
INFO - 2017-03-06 11:41:35 --> Language Class Initialized
INFO - 2017-03-06 11:41:35 --> Config Class Initialized
INFO - 2017-03-06 11:41:35 --> Loader Class Initialized
INFO - 2017-03-06 11:41:35 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:35 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:35 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:35 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:35 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:35 --> Template Class Initialized
INFO - 2017-03-06 11:41:35 --> Model Class Initialized
INFO - 2017-03-06 11:41:35 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:35 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:35 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:44 --> Config Class Initialized
INFO - 2017-03-06 11:41:44 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:44 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:44 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:44 --> URI Class Initialized
INFO - 2017-03-06 11:41:44 --> Router Class Initialized
INFO - 2017-03-06 11:41:44 --> Output Class Initialized
INFO - 2017-03-06 11:41:44 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:44 --> Input Class Initialized
INFO - 2017-03-06 11:41:44 --> Language Class Initialized
INFO - 2017-03-06 11:41:44 --> Language Class Initialized
INFO - 2017-03-06 11:41:44 --> Config Class Initialized
INFO - 2017-03-06 11:41:44 --> Loader Class Initialized
INFO - 2017-03-06 11:41:44 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:44 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:44 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:44 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:44 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:44 --> Template Class Initialized
INFO - 2017-03-06 11:41:44 --> Model Class Initialized
INFO - 2017-03-06 11:41:44 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:44 --> Login MX_Controller Initialized
INFO - 2017-03-06 11:41:44 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:41:44 --> Form Validation Class Initialized
INFO - 2017-03-06 11:41:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-06 11:41:44 --> Config Class Initialized
INFO - 2017-03-06 11:41:44 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:44 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:44 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:44 --> URI Class Initialized
INFO - 2017-03-06 11:41:44 --> Router Class Initialized
INFO - 2017-03-06 11:41:44 --> Output Class Initialized
INFO - 2017-03-06 11:41:44 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:44 --> Input Class Initialized
INFO - 2017-03-06 11:41:44 --> Language Class Initialized
INFO - 2017-03-06 11:41:44 --> Language Class Initialized
INFO - 2017-03-06 11:41:44 --> Config Class Initialized
INFO - 2017-03-06 11:41:44 --> Loader Class Initialized
INFO - 2017-03-06 11:41:44 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:44 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:44 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:44 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:44 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:44 --> Template Class Initialized
INFO - 2017-03-06 11:41:44 --> Model Class Initialized
INFO - 2017-03-06 11:41:44 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:44 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:44 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:41:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 11:41:44 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:41:44 --> Final output sent to browser
DEBUG - 2017-03-06 11:41:44 --> Total execution time: 0.0136
INFO - 2017-03-06 11:41:44 --> Config Class Initialized
INFO - 2017-03-06 11:41:44 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:44 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:44 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:44 --> URI Class Initialized
INFO - 2017-03-06 11:41:44 --> Router Class Initialized
INFO - 2017-03-06 11:41:44 --> Output Class Initialized
INFO - 2017-03-06 11:41:44 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:44 --> Input Class Initialized
INFO - 2017-03-06 11:41:44 --> Language Class Initialized
INFO - 2017-03-06 11:41:44 --> Language Class Initialized
INFO - 2017-03-06 11:41:44 --> Config Class Initialized
INFO - 2017-03-06 11:41:44 --> Loader Class Initialized
INFO - 2017-03-06 11:41:44 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:44 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:44 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:44 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:44 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:44 --> Template Class Initialized
INFO - 2017-03-06 11:41:44 --> Model Class Initialized
INFO - 2017-03-06 11:41:44 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:44 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:44 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:44 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:44 --> Config Class Initialized
INFO - 2017-03-06 11:41:44 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:44 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:44 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:44 --> URI Class Initialized
INFO - 2017-03-06 11:41:44 --> Router Class Initialized
INFO - 2017-03-06 11:41:44 --> Output Class Initialized
INFO - 2017-03-06 11:41:44 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:44 --> Input Class Initialized
INFO - 2017-03-06 11:41:44 --> Language Class Initialized
INFO - 2017-03-06 11:41:45 --> Language Class Initialized
INFO - 2017-03-06 11:41:45 --> Config Class Initialized
INFO - 2017-03-06 11:41:45 --> Loader Class Initialized
INFO - 2017-03-06 11:41:45 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:45 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:45 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:45 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:45 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:45 --> Template Class Initialized
INFO - 2017-03-06 11:41:45 --> Model Class Initialized
INFO - 2017-03-06 11:41:45 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:45 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:45 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:45 --> Config Class Initialized
INFO - 2017-03-06 11:41:45 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:45 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:45 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:45 --> URI Class Initialized
INFO - 2017-03-06 11:41:45 --> Router Class Initialized
INFO - 2017-03-06 11:41:45 --> Output Class Initialized
INFO - 2017-03-06 11:41:45 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:45 --> Input Class Initialized
INFO - 2017-03-06 11:41:45 --> Language Class Initialized
INFO - 2017-03-06 11:41:45 --> Language Class Initialized
INFO - 2017-03-06 11:41:45 --> Config Class Initialized
INFO - 2017-03-06 11:41:45 --> Loader Class Initialized
INFO - 2017-03-06 11:41:45 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:45 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:45 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:45 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:45 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:45 --> Template Class Initialized
INFO - 2017-03-06 11:41:45 --> Model Class Initialized
INFO - 2017-03-06 11:41:45 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:45 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:45 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:47 --> Config Class Initialized
INFO - 2017-03-06 11:41:47 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:47 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:47 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:47 --> URI Class Initialized
INFO - 2017-03-06 11:41:47 --> Router Class Initialized
INFO - 2017-03-06 11:41:47 --> Output Class Initialized
INFO - 2017-03-06 11:41:47 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:47 --> Input Class Initialized
INFO - 2017-03-06 11:41:47 --> Language Class Initialized
INFO - 2017-03-06 11:41:47 --> Language Class Initialized
INFO - 2017-03-06 11:41:47 --> Config Class Initialized
INFO - 2017-03-06 11:41:47 --> Loader Class Initialized
INFO - 2017-03-06 11:41:47 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:47 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:47 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:47 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:47 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:47 --> Template Class Initialized
INFO - 2017-03-06 11:41:47 --> Model Class Initialized
INFO - 2017-03-06 11:41:47 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:47 --> Login MX_Controller Initialized
INFO - 2017-03-06 11:41:47 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:41:47 --> Form Validation Class Initialized
INFO - 2017-03-06 11:41:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-06 11:41:47 --> Config Class Initialized
INFO - 2017-03-06 11:41:47 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:47 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:47 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:47 --> URI Class Initialized
INFO - 2017-03-06 11:41:47 --> Router Class Initialized
INFO - 2017-03-06 11:41:47 --> Output Class Initialized
INFO - 2017-03-06 11:41:47 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:47 --> Input Class Initialized
INFO - 2017-03-06 11:41:47 --> Language Class Initialized
INFO - 2017-03-06 11:41:47 --> Language Class Initialized
INFO - 2017-03-06 11:41:47 --> Config Class Initialized
INFO - 2017-03-06 11:41:47 --> Loader Class Initialized
INFO - 2017-03-06 11:41:47 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:47 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:47 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:47 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:47 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:47 --> Template Class Initialized
INFO - 2017-03-06 11:41:47 --> Model Class Initialized
INFO - 2017-03-06 11:41:47 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:47 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:47 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:41:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 11:41:47 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:41:47 --> Final output sent to browser
DEBUG - 2017-03-06 11:41:47 --> Total execution time: 0.0145
INFO - 2017-03-06 11:41:48 --> Config Class Initialized
INFO - 2017-03-06 11:41:48 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:48 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:48 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:48 --> URI Class Initialized
INFO - 2017-03-06 11:41:48 --> Router Class Initialized
INFO - 2017-03-06 11:41:48 --> Output Class Initialized
INFO - 2017-03-06 11:41:48 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:48 --> Input Class Initialized
INFO - 2017-03-06 11:41:48 --> Language Class Initialized
INFO - 2017-03-06 11:41:48 --> Language Class Initialized
INFO - 2017-03-06 11:41:48 --> Config Class Initialized
INFO - 2017-03-06 11:41:48 --> Loader Class Initialized
INFO - 2017-03-06 11:41:48 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:48 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:48 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:48 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:48 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:48 --> Template Class Initialized
INFO - 2017-03-06 11:41:48 --> Model Class Initialized
INFO - 2017-03-06 11:41:48 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:48 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:48 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:48 --> Config Class Initialized
INFO - 2017-03-06 11:41:48 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:48 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:48 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:48 --> URI Class Initialized
INFO - 2017-03-06 11:41:48 --> Router Class Initialized
INFO - 2017-03-06 11:41:48 --> Output Class Initialized
INFO - 2017-03-06 11:41:48 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:48 --> Input Class Initialized
INFO - 2017-03-06 11:41:48 --> Language Class Initialized
INFO - 2017-03-06 11:41:48 --> Language Class Initialized
INFO - 2017-03-06 11:41:48 --> Config Class Initialized
INFO - 2017-03-06 11:41:48 --> Loader Class Initialized
INFO - 2017-03-06 11:41:48 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:48 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:48 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:48 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:48 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:48 --> Template Class Initialized
INFO - 2017-03-06 11:41:48 --> Model Class Initialized
INFO - 2017-03-06 11:41:48 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:48 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:48 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:48 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:51 --> Config Class Initialized
INFO - 2017-03-06 11:41:51 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:51 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:51 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:51 --> URI Class Initialized
DEBUG - 2017-03-06 11:41:51 --> No URI present. Default controller set.
INFO - 2017-03-06 11:41:51 --> Router Class Initialized
INFO - 2017-03-06 11:41:51 --> Output Class Initialized
INFO - 2017-03-06 11:41:51 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:51 --> Input Class Initialized
INFO - 2017-03-06 11:41:51 --> Language Class Initialized
INFO - 2017-03-06 11:41:51 --> Language Class Initialized
INFO - 2017-03-06 11:41:51 --> Config Class Initialized
INFO - 2017-03-06 11:41:51 --> Loader Class Initialized
INFO - 2017-03-06 11:41:51 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:51 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:51 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:51 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:51 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:51 --> Template Class Initialized
INFO - 2017-03-06 11:41:51 --> Model Class Initialized
INFO - 2017-03-06 11:41:51 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:51 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:51 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:41:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-06 11:41:51 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:41:51 --> Final output sent to browser
DEBUG - 2017-03-06 11:41:51 --> Total execution time: 0.0168
INFO - 2017-03-06 11:41:52 --> Config Class Initialized
INFO - 2017-03-06 11:41:52 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:52 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:52 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:52 --> URI Class Initialized
INFO - 2017-03-06 11:41:52 --> Router Class Initialized
INFO - 2017-03-06 11:41:52 --> Output Class Initialized
INFO - 2017-03-06 11:41:52 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:52 --> Input Class Initialized
INFO - 2017-03-06 11:41:52 --> Language Class Initialized
INFO - 2017-03-06 11:41:52 --> Language Class Initialized
INFO - 2017-03-06 11:41:52 --> Config Class Initialized
INFO - 2017-03-06 11:41:52 --> Loader Class Initialized
INFO - 2017-03-06 11:41:52 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:52 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:52 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:52 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:52 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:52 --> Template Class Initialized
INFO - 2017-03-06 11:41:52 --> Model Class Initialized
INFO - 2017-03-06 11:41:52 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:52 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:52 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:54 --> Config Class Initialized
INFO - 2017-03-06 11:41:54 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:54 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:54 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:54 --> URI Class Initialized
INFO - 2017-03-06 11:41:54 --> Router Class Initialized
INFO - 2017-03-06 11:41:54 --> Output Class Initialized
INFO - 2017-03-06 11:41:54 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:54 --> Input Class Initialized
INFO - 2017-03-06 11:41:54 --> Language Class Initialized
INFO - 2017-03-06 11:41:54 --> Language Class Initialized
INFO - 2017-03-06 11:41:54 --> Config Class Initialized
INFO - 2017-03-06 11:41:54 --> Loader Class Initialized
INFO - 2017-03-06 11:41:54 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:54 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:54 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:54 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:54 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:54 --> Template Class Initialized
INFO - 2017-03-06 11:41:54 --> Model Class Initialized
INFO - 2017-03-06 11:41:54 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:54 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:41:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/about_us.php
DEBUG - 2017-03-06 11:41:54 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:41:54 --> Final output sent to browser
DEBUG - 2017-03-06 11:41:54 --> Total execution time: 0.0224
INFO - 2017-03-06 11:41:54 --> Config Class Initialized
INFO - 2017-03-06 11:41:54 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:54 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:54 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:54 --> URI Class Initialized
INFO - 2017-03-06 11:41:54 --> Router Class Initialized
INFO - 2017-03-06 11:41:54 --> Output Class Initialized
INFO - 2017-03-06 11:41:54 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:54 --> Input Class Initialized
INFO - 2017-03-06 11:41:54 --> Language Class Initialized
INFO - 2017-03-06 11:41:54 --> Language Class Initialized
INFO - 2017-03-06 11:41:54 --> Config Class Initialized
INFO - 2017-03-06 11:41:54 --> Loader Class Initialized
INFO - 2017-03-06 11:41:54 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:54 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:54 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:54 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:54 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:54 --> Template Class Initialized
INFO - 2017-03-06 11:41:54 --> Model Class Initialized
INFO - 2017-03-06 11:41:54 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:54 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:54 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:54 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:41:55 --> Config Class Initialized
INFO - 2017-03-06 11:41:55 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:41:55 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:41:55 --> Utf8 Class Initialized
INFO - 2017-03-06 11:41:55 --> URI Class Initialized
INFO - 2017-03-06 11:41:55 --> Router Class Initialized
INFO - 2017-03-06 11:41:55 --> Output Class Initialized
INFO - 2017-03-06 11:41:55 --> Security Class Initialized
DEBUG - 2017-03-06 11:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:41:55 --> Input Class Initialized
INFO - 2017-03-06 11:41:55 --> Language Class Initialized
INFO - 2017-03-06 11:41:55 --> Language Class Initialized
INFO - 2017-03-06 11:41:55 --> Config Class Initialized
INFO - 2017-03-06 11:41:55 --> Loader Class Initialized
INFO - 2017-03-06 11:41:55 --> Helper loaded: form_helper
INFO - 2017-03-06 11:41:55 --> Helper loaded: url_helper
INFO - 2017-03-06 11:41:55 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:41:55 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:41:55 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:41:55 --> Template Class Initialized
INFO - 2017-03-06 11:41:55 --> Model Class Initialized
INFO - 2017-03-06 11:41:55 --> Controller Class Initialized
DEBUG - 2017-03-06 11:41:55 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:41:55 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:41:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:41:55 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:42:04 --> Config Class Initialized
INFO - 2017-03-06 11:42:04 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:42:04 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:42:04 --> Utf8 Class Initialized
INFO - 2017-03-06 11:42:04 --> URI Class Initialized
INFO - 2017-03-06 11:42:04 --> Router Class Initialized
INFO - 2017-03-06 11:42:04 --> Output Class Initialized
INFO - 2017-03-06 11:42:04 --> Security Class Initialized
DEBUG - 2017-03-06 11:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:42:04 --> Input Class Initialized
INFO - 2017-03-06 11:42:04 --> Language Class Initialized
INFO - 2017-03-06 11:42:04 --> Language Class Initialized
INFO - 2017-03-06 11:42:04 --> Config Class Initialized
INFO - 2017-03-06 11:42:04 --> Loader Class Initialized
INFO - 2017-03-06 11:42:04 --> Helper loaded: form_helper
INFO - 2017-03-06 11:42:04 --> Helper loaded: url_helper
INFO - 2017-03-06 11:42:04 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:42:04 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:42:04 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:42:04 --> Template Class Initialized
INFO - 2017-03-06 11:42:04 --> Model Class Initialized
INFO - 2017-03-06 11:42:04 --> Controller Class Initialized
DEBUG - 2017-03-06 11:42:04 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:42:04 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:42:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:42:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:42:05 --> Config Class Initialized
INFO - 2017-03-06 11:42:05 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:42:05 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:42:05 --> Utf8 Class Initialized
INFO - 2017-03-06 11:42:05 --> URI Class Initialized
INFO - 2017-03-06 11:42:05 --> Router Class Initialized
INFO - 2017-03-06 11:42:05 --> Output Class Initialized
INFO - 2017-03-06 11:42:05 --> Security Class Initialized
DEBUG - 2017-03-06 11:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:42:05 --> Input Class Initialized
INFO - 2017-03-06 11:42:05 --> Language Class Initialized
INFO - 2017-03-06 11:42:05 --> Language Class Initialized
INFO - 2017-03-06 11:42:05 --> Config Class Initialized
INFO - 2017-03-06 11:42:05 --> Loader Class Initialized
INFO - 2017-03-06 11:42:05 --> Helper loaded: form_helper
INFO - 2017-03-06 11:42:05 --> Helper loaded: url_helper
INFO - 2017-03-06 11:42:05 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:42:05 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:42:05 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:42:05 --> Template Class Initialized
INFO - 2017-03-06 11:42:05 --> Model Class Initialized
INFO - 2017-03-06 11:42:05 --> Controller Class Initialized
DEBUG - 2017-03-06 11:42:05 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:42:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:42:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:42:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:42:07 --> Config Class Initialized
INFO - 2017-03-06 11:42:07 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:42:07 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:42:07 --> Utf8 Class Initialized
INFO - 2017-03-06 11:42:07 --> URI Class Initialized
INFO - 2017-03-06 11:42:07 --> Router Class Initialized
INFO - 2017-03-06 11:42:07 --> Output Class Initialized
INFO - 2017-03-06 11:42:07 --> Security Class Initialized
DEBUG - 2017-03-06 11:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:42:07 --> Input Class Initialized
INFO - 2017-03-06 11:42:07 --> Language Class Initialized
INFO - 2017-03-06 11:42:07 --> Language Class Initialized
INFO - 2017-03-06 11:42:07 --> Config Class Initialized
INFO - 2017-03-06 11:42:07 --> Loader Class Initialized
INFO - 2017-03-06 11:42:07 --> Helper loaded: form_helper
INFO - 2017-03-06 11:42:07 --> Helper loaded: url_helper
INFO - 2017-03-06 11:42:07 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:42:07 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:42:07 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:42:07 --> Template Class Initialized
INFO - 2017-03-06 11:42:07 --> Model Class Initialized
INFO - 2017-03-06 11:42:07 --> Controller Class Initialized
DEBUG - 2017-03-06 11:42:07 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:42:07 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:42:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:42:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:42:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/about_us.php
DEBUG - 2017-03-06 11:42:07 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:42:07 --> Final output sent to browser
DEBUG - 2017-03-06 11:42:07 --> Total execution time: 0.0620
INFO - 2017-03-06 11:42:07 --> Config Class Initialized
INFO - 2017-03-06 11:42:07 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:42:07 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:42:07 --> Utf8 Class Initialized
INFO - 2017-03-06 11:42:07 --> URI Class Initialized
INFO - 2017-03-06 11:42:07 --> Router Class Initialized
INFO - 2017-03-06 11:42:07 --> Output Class Initialized
INFO - 2017-03-06 11:42:07 --> Security Class Initialized
DEBUG - 2017-03-06 11:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:42:07 --> Input Class Initialized
INFO - 2017-03-06 11:42:07 --> Language Class Initialized
INFO - 2017-03-06 11:42:07 --> Language Class Initialized
INFO - 2017-03-06 11:42:07 --> Config Class Initialized
INFO - 2017-03-06 11:42:07 --> Loader Class Initialized
INFO - 2017-03-06 11:42:07 --> Helper loaded: form_helper
INFO - 2017-03-06 11:42:07 --> Helper loaded: url_helper
INFO - 2017-03-06 11:42:07 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:42:07 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:42:08 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:42:08 --> Template Class Initialized
INFO - 2017-03-06 11:42:08 --> Model Class Initialized
INFO - 2017-03-06 11:42:08 --> Controller Class Initialized
DEBUG - 2017-03-06 11:42:08 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:42:08 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:42:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:42:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:42:08 --> Config Class Initialized
INFO - 2017-03-06 11:42:08 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:42:08 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:42:08 --> Utf8 Class Initialized
INFO - 2017-03-06 11:42:08 --> URI Class Initialized
INFO - 2017-03-06 11:42:08 --> Router Class Initialized
INFO - 2017-03-06 11:42:08 --> Output Class Initialized
INFO - 2017-03-06 11:42:08 --> Security Class Initialized
DEBUG - 2017-03-06 11:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:42:08 --> Input Class Initialized
INFO - 2017-03-06 11:42:08 --> Language Class Initialized
INFO - 2017-03-06 11:42:08 --> Language Class Initialized
INFO - 2017-03-06 11:42:08 --> Config Class Initialized
INFO - 2017-03-06 11:42:08 --> Loader Class Initialized
INFO - 2017-03-06 11:42:08 --> Helper loaded: form_helper
INFO - 2017-03-06 11:42:08 --> Helper loaded: url_helper
INFO - 2017-03-06 11:42:08 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:42:08 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:42:08 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:42:08 --> Template Class Initialized
INFO - 2017-03-06 11:42:08 --> Model Class Initialized
INFO - 2017-03-06 11:42:08 --> Controller Class Initialized
DEBUG - 2017-03-06 11:42:08 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:42:08 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:42:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:42:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:42:08 --> Config Class Initialized
INFO - 2017-03-06 11:42:08 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:42:08 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:42:08 --> Utf8 Class Initialized
INFO - 2017-03-06 11:42:08 --> URI Class Initialized
INFO - 2017-03-06 11:42:08 --> Router Class Initialized
INFO - 2017-03-06 11:42:08 --> Output Class Initialized
INFO - 2017-03-06 11:42:08 --> Security Class Initialized
DEBUG - 2017-03-06 11:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:42:08 --> Input Class Initialized
INFO - 2017-03-06 11:42:08 --> Language Class Initialized
INFO - 2017-03-06 11:42:08 --> Language Class Initialized
INFO - 2017-03-06 11:42:08 --> Config Class Initialized
INFO - 2017-03-06 11:42:08 --> Loader Class Initialized
INFO - 2017-03-06 11:42:08 --> Helper loaded: form_helper
INFO - 2017-03-06 11:42:08 --> Helper loaded: url_helper
INFO - 2017-03-06 11:42:08 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:42:08 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:42:08 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:42:08 --> Template Class Initialized
INFO - 2017-03-06 11:42:08 --> Model Class Initialized
INFO - 2017-03-06 11:42:08 --> Controller Class Initialized
DEBUG - 2017-03-06 11:42:08 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:42:08 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:42:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:42:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:42:11 --> Config Class Initialized
INFO - 2017-03-06 11:42:11 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:42:11 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:42:11 --> Utf8 Class Initialized
INFO - 2017-03-06 11:42:11 --> URI Class Initialized
INFO - 2017-03-06 11:42:11 --> Router Class Initialized
INFO - 2017-03-06 11:42:11 --> Output Class Initialized
INFO - 2017-03-06 11:42:11 --> Security Class Initialized
DEBUG - 2017-03-06 11:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:42:11 --> Input Class Initialized
INFO - 2017-03-06 11:42:11 --> Language Class Initialized
INFO - 2017-03-06 11:42:11 --> Language Class Initialized
INFO - 2017-03-06 11:42:11 --> Config Class Initialized
INFO - 2017-03-06 11:42:11 --> Loader Class Initialized
INFO - 2017-03-06 11:42:11 --> Helper loaded: form_helper
INFO - 2017-03-06 11:42:11 --> Helper loaded: url_helper
INFO - 2017-03-06 11:42:11 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:42:11 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:42:11 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:42:11 --> Template Class Initialized
INFO - 2017-03-06 11:42:11 --> Model Class Initialized
INFO - 2017-03-06 11:42:11 --> Controller Class Initialized
DEBUG - 2017-03-06 11:42:11 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:42:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:42:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:42:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:42:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-03-06 11:42:11 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:42:11 --> Final output sent to browser
DEBUG - 2017-03-06 11:42:11 --> Total execution time: 0.0293
INFO - 2017-03-06 11:42:11 --> Config Class Initialized
INFO - 2017-03-06 11:42:11 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:42:11 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:42:11 --> Utf8 Class Initialized
INFO - 2017-03-06 11:42:11 --> URI Class Initialized
INFO - 2017-03-06 11:42:11 --> Router Class Initialized
INFO - 2017-03-06 11:42:11 --> Output Class Initialized
INFO - 2017-03-06 11:42:11 --> Security Class Initialized
DEBUG - 2017-03-06 11:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:42:11 --> Input Class Initialized
INFO - 2017-03-06 11:42:11 --> Language Class Initialized
INFO - 2017-03-06 11:42:11 --> Language Class Initialized
INFO - 2017-03-06 11:42:11 --> Config Class Initialized
INFO - 2017-03-06 11:42:11 --> Loader Class Initialized
INFO - 2017-03-06 11:42:11 --> Helper loaded: form_helper
INFO - 2017-03-06 11:42:11 --> Helper loaded: url_helper
INFO - 2017-03-06 11:42:11 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:42:11 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:42:11 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:42:11 --> Template Class Initialized
INFO - 2017-03-06 11:42:11 --> Model Class Initialized
INFO - 2017-03-06 11:42:11 --> Controller Class Initialized
DEBUG - 2017-03-06 11:42:11 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:42:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:42:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:42:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:42:12 --> Config Class Initialized
INFO - 2017-03-06 11:42:12 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:42:12 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:42:12 --> Utf8 Class Initialized
INFO - 2017-03-06 11:42:12 --> URI Class Initialized
INFO - 2017-03-06 11:42:12 --> Router Class Initialized
INFO - 2017-03-06 11:42:12 --> Output Class Initialized
INFO - 2017-03-06 11:42:12 --> Security Class Initialized
DEBUG - 2017-03-06 11:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:42:12 --> Input Class Initialized
INFO - 2017-03-06 11:42:12 --> Language Class Initialized
INFO - 2017-03-06 11:42:12 --> Language Class Initialized
INFO - 2017-03-06 11:42:12 --> Config Class Initialized
INFO - 2017-03-06 11:42:12 --> Loader Class Initialized
INFO - 2017-03-06 11:42:12 --> Helper loaded: form_helper
INFO - 2017-03-06 11:42:12 --> Helper loaded: url_helper
INFO - 2017-03-06 11:42:12 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:42:12 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:42:12 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:42:12 --> Template Class Initialized
INFO - 2017-03-06 11:42:12 --> Model Class Initialized
INFO - 2017-03-06 11:42:12 --> Controller Class Initialized
DEBUG - 2017-03-06 11:42:12 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:42:12 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:42:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:42:12 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:42:14 --> Config Class Initialized
INFO - 2017-03-06 11:42:14 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:42:14 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:42:14 --> Utf8 Class Initialized
INFO - 2017-03-06 11:42:14 --> URI Class Initialized
INFO - 2017-03-06 11:42:14 --> Router Class Initialized
INFO - 2017-03-06 11:42:14 --> Output Class Initialized
INFO - 2017-03-06 11:42:14 --> Security Class Initialized
DEBUG - 2017-03-06 11:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:42:14 --> Input Class Initialized
INFO - 2017-03-06 11:42:14 --> Language Class Initialized
INFO - 2017-03-06 11:42:14 --> Language Class Initialized
INFO - 2017-03-06 11:42:14 --> Config Class Initialized
INFO - 2017-03-06 11:42:14 --> Loader Class Initialized
INFO - 2017-03-06 11:42:14 --> Helper loaded: form_helper
INFO - 2017-03-06 11:42:14 --> Helper loaded: url_helper
INFO - 2017-03-06 11:42:14 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:42:14 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:42:14 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:42:14 --> Template Class Initialized
INFO - 2017-03-06 11:42:14 --> Model Class Initialized
INFO - 2017-03-06 11:42:14 --> Controller Class Initialized
DEBUG - 2017-03-06 11:42:14 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:42:14 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:42:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:42:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:42:14 --> Config Class Initialized
INFO - 2017-03-06 11:42:14 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:42:14 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:42:14 --> Utf8 Class Initialized
INFO - 2017-03-06 11:42:14 --> URI Class Initialized
INFO - 2017-03-06 11:42:14 --> Router Class Initialized
INFO - 2017-03-06 11:42:14 --> Output Class Initialized
INFO - 2017-03-06 11:42:14 --> Security Class Initialized
DEBUG - 2017-03-06 11:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:42:14 --> Input Class Initialized
INFO - 2017-03-06 11:42:14 --> Language Class Initialized
INFO - 2017-03-06 11:42:14 --> Language Class Initialized
INFO - 2017-03-06 11:42:14 --> Config Class Initialized
INFO - 2017-03-06 11:42:14 --> Loader Class Initialized
INFO - 2017-03-06 11:42:14 --> Helper loaded: form_helper
INFO - 2017-03-06 11:42:14 --> Helper loaded: url_helper
INFO - 2017-03-06 11:42:14 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:42:14 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:42:14 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:42:14 --> Template Class Initialized
INFO - 2017-03-06 11:42:14 --> Model Class Initialized
INFO - 2017-03-06 11:42:14 --> Controller Class Initialized
DEBUG - 2017-03-06 11:42:14 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:42:14 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:42:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:42:14 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:42:17 --> Config Class Initialized
INFO - 2017-03-06 11:42:17 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:42:17 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:42:17 --> Utf8 Class Initialized
INFO - 2017-03-06 11:42:17 --> URI Class Initialized
INFO - 2017-03-06 11:42:17 --> Router Class Initialized
INFO - 2017-03-06 11:42:17 --> Output Class Initialized
INFO - 2017-03-06 11:42:17 --> Security Class Initialized
DEBUG - 2017-03-06 11:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:42:17 --> Input Class Initialized
INFO - 2017-03-06 11:42:17 --> Language Class Initialized
INFO - 2017-03-06 11:42:17 --> Language Class Initialized
INFO - 2017-03-06 11:42:17 --> Config Class Initialized
INFO - 2017-03-06 11:42:17 --> Loader Class Initialized
INFO - 2017-03-06 11:42:17 --> Helper loaded: form_helper
INFO - 2017-03-06 11:42:17 --> Helper loaded: url_helper
INFO - 2017-03-06 11:42:17 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:42:17 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:42:17 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:42:17 --> Template Class Initialized
INFO - 2017-03-06 11:42:17 --> Model Class Initialized
INFO - 2017-03-06 11:42:17 --> Controller Class Initialized
DEBUG - 2017-03-06 11:42:17 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:42:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:42:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:42:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:42:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-03-06 11:42:17 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:42:17 --> Final output sent to browser
DEBUG - 2017-03-06 11:42:17 --> Total execution time: 0.0144
INFO - 2017-03-06 11:42:17 --> Config Class Initialized
INFO - 2017-03-06 11:42:17 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:42:17 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:42:17 --> Utf8 Class Initialized
INFO - 2017-03-06 11:42:17 --> URI Class Initialized
INFO - 2017-03-06 11:42:17 --> Router Class Initialized
INFO - 2017-03-06 11:42:17 --> Output Class Initialized
INFO - 2017-03-06 11:42:17 --> Security Class Initialized
DEBUG - 2017-03-06 11:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:42:17 --> Input Class Initialized
INFO - 2017-03-06 11:42:17 --> Language Class Initialized
INFO - 2017-03-06 11:42:17 --> Language Class Initialized
INFO - 2017-03-06 11:42:17 --> Config Class Initialized
INFO - 2017-03-06 11:42:17 --> Loader Class Initialized
INFO - 2017-03-06 11:42:17 --> Helper loaded: form_helper
INFO - 2017-03-06 11:42:17 --> Helper loaded: url_helper
INFO - 2017-03-06 11:42:17 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:42:17 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:42:17 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:42:17 --> Template Class Initialized
INFO - 2017-03-06 11:42:17 --> Model Class Initialized
INFO - 2017-03-06 11:42:17 --> Controller Class Initialized
DEBUG - 2017-03-06 11:42:17 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:42:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:42:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:42:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:42:17 --> Config Class Initialized
INFO - 2017-03-06 11:42:17 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:42:17 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:42:17 --> Utf8 Class Initialized
INFO - 2017-03-06 11:42:17 --> URI Class Initialized
INFO - 2017-03-06 11:42:17 --> Router Class Initialized
INFO - 2017-03-06 11:42:17 --> Output Class Initialized
INFO - 2017-03-06 11:42:17 --> Security Class Initialized
DEBUG - 2017-03-06 11:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:42:17 --> Input Class Initialized
INFO - 2017-03-06 11:42:17 --> Language Class Initialized
INFO - 2017-03-06 11:42:17 --> Language Class Initialized
INFO - 2017-03-06 11:42:17 --> Config Class Initialized
INFO - 2017-03-06 11:42:17 --> Loader Class Initialized
INFO - 2017-03-06 11:42:17 --> Helper loaded: form_helper
INFO - 2017-03-06 11:42:17 --> Helper loaded: url_helper
INFO - 2017-03-06 11:42:17 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:42:17 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:42:17 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:42:17 --> Template Class Initialized
INFO - 2017-03-06 11:42:17 --> Model Class Initialized
INFO - 2017-03-06 11:42:17 --> Controller Class Initialized
DEBUG - 2017-03-06 11:42:17 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:42:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:42:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:42:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:42:21 --> Config Class Initialized
INFO - 2017-03-06 11:42:21 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:42:21 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:42:21 --> Utf8 Class Initialized
INFO - 2017-03-06 11:42:21 --> URI Class Initialized
DEBUG - 2017-03-06 11:42:21 --> No URI present. Default controller set.
INFO - 2017-03-06 11:42:21 --> Router Class Initialized
INFO - 2017-03-06 11:42:21 --> Output Class Initialized
INFO - 2017-03-06 11:42:21 --> Security Class Initialized
DEBUG - 2017-03-06 11:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:42:21 --> Input Class Initialized
INFO - 2017-03-06 11:42:21 --> Language Class Initialized
INFO - 2017-03-06 11:42:21 --> Language Class Initialized
INFO - 2017-03-06 11:42:21 --> Config Class Initialized
INFO - 2017-03-06 11:42:21 --> Loader Class Initialized
INFO - 2017-03-06 11:42:21 --> Helper loaded: form_helper
INFO - 2017-03-06 11:42:21 --> Helper loaded: url_helper
INFO - 2017-03-06 11:42:21 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:42:21 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:42:21 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:42:21 --> Template Class Initialized
INFO - 2017-03-06 11:42:21 --> Model Class Initialized
INFO - 2017-03-06 11:42:21 --> Controller Class Initialized
DEBUG - 2017-03-06 11:42:21 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:42:21 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:42:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:42:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:42:21 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-06 11:42:21 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:42:21 --> Final output sent to browser
DEBUG - 2017-03-06 11:42:21 --> Total execution time: 0.0161
INFO - 2017-03-06 11:43:10 --> Config Class Initialized
INFO - 2017-03-06 11:43:10 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:43:10 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:43:10 --> Utf8 Class Initialized
INFO - 2017-03-06 11:43:10 --> URI Class Initialized
DEBUG - 2017-03-06 11:43:10 --> No URI present. Default controller set.
INFO - 2017-03-06 11:43:10 --> Router Class Initialized
INFO - 2017-03-06 11:43:10 --> Output Class Initialized
INFO - 2017-03-06 11:43:10 --> Security Class Initialized
DEBUG - 2017-03-06 11:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:43:10 --> Input Class Initialized
INFO - 2017-03-06 11:43:10 --> Language Class Initialized
INFO - 2017-03-06 11:43:10 --> Language Class Initialized
INFO - 2017-03-06 11:43:10 --> Config Class Initialized
INFO - 2017-03-06 11:43:10 --> Loader Class Initialized
INFO - 2017-03-06 11:43:10 --> Helper loaded: form_helper
INFO - 2017-03-06 11:43:10 --> Helper loaded: url_helper
INFO - 2017-03-06 11:43:10 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:43:11 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:43:11 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:43:11 --> Template Class Initialized
INFO - 2017-03-06 11:43:11 --> Model Class Initialized
INFO - 2017-03-06 11:43:11 --> Controller Class Initialized
DEBUG - 2017-03-06 11:43:11 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:43:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:43:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:43:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:43:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-06 11:43:11 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:43:11 --> Final output sent to browser
DEBUG - 2017-03-06 11:43:11 --> Total execution time: 0.0554
INFO - 2017-03-06 11:43:11 --> Config Class Initialized
INFO - 2017-03-06 11:43:11 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:43:11 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:43:11 --> Utf8 Class Initialized
INFO - 2017-03-06 11:43:11 --> URI Class Initialized
INFO - 2017-03-06 11:43:11 --> Router Class Initialized
INFO - 2017-03-06 11:43:11 --> Output Class Initialized
INFO - 2017-03-06 11:43:11 --> Security Class Initialized
DEBUG - 2017-03-06 11:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:43:11 --> Input Class Initialized
INFO - 2017-03-06 11:43:11 --> Language Class Initialized
INFO - 2017-03-06 11:43:11 --> Language Class Initialized
INFO - 2017-03-06 11:43:11 --> Config Class Initialized
INFO - 2017-03-06 11:43:11 --> Loader Class Initialized
INFO - 2017-03-06 11:43:11 --> Helper loaded: form_helper
INFO - 2017-03-06 11:43:11 --> Helper loaded: url_helper
INFO - 2017-03-06 11:43:11 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:43:11 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:43:11 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:43:11 --> Template Class Initialized
INFO - 2017-03-06 11:43:11 --> Model Class Initialized
INFO - 2017-03-06 11:43:11 --> Controller Class Initialized
DEBUG - 2017-03-06 11:43:11 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:43:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:43:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:43:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:43:11 --> Config Class Initialized
INFO - 2017-03-06 11:43:11 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:43:11 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:43:11 --> Utf8 Class Initialized
INFO - 2017-03-06 11:43:11 --> URI Class Initialized
INFO - 2017-03-06 11:43:11 --> Router Class Initialized
INFO - 2017-03-06 11:43:11 --> Output Class Initialized
INFO - 2017-03-06 11:43:11 --> Security Class Initialized
DEBUG - 2017-03-06 11:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:43:11 --> Input Class Initialized
INFO - 2017-03-06 11:43:11 --> Language Class Initialized
INFO - 2017-03-06 11:43:11 --> Language Class Initialized
INFO - 2017-03-06 11:43:11 --> Config Class Initialized
INFO - 2017-03-06 11:43:11 --> Loader Class Initialized
INFO - 2017-03-06 11:43:11 --> Helper loaded: form_helper
INFO - 2017-03-06 11:43:11 --> Helper loaded: url_helper
INFO - 2017-03-06 11:43:11 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:43:11 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:43:11 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:43:11 --> Template Class Initialized
INFO - 2017-03-06 11:43:11 --> Model Class Initialized
INFO - 2017-03-06 11:43:11 --> Controller Class Initialized
DEBUG - 2017-03-06 11:43:11 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:43:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:43:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:43:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:43:58 --> Config Class Initialized
INFO - 2017-03-06 11:43:58 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:43:58 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:43:58 --> Utf8 Class Initialized
INFO - 2017-03-06 11:43:58 --> URI Class Initialized
DEBUG - 2017-03-06 11:43:58 --> No URI present. Default controller set.
INFO - 2017-03-06 11:43:58 --> Router Class Initialized
INFO - 2017-03-06 11:43:58 --> Output Class Initialized
INFO - 2017-03-06 11:43:58 --> Security Class Initialized
DEBUG - 2017-03-06 11:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:43:58 --> Input Class Initialized
INFO - 2017-03-06 11:43:58 --> Language Class Initialized
INFO - 2017-03-06 11:43:58 --> Language Class Initialized
INFO - 2017-03-06 11:43:58 --> Config Class Initialized
INFO - 2017-03-06 11:43:58 --> Loader Class Initialized
INFO - 2017-03-06 11:43:58 --> Helper loaded: form_helper
INFO - 2017-03-06 11:43:58 --> Helper loaded: url_helper
INFO - 2017-03-06 11:43:58 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:43:58 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:43:58 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:43:58 --> Template Class Initialized
INFO - 2017-03-06 11:43:58 --> Model Class Initialized
INFO - 2017-03-06 11:43:58 --> Controller Class Initialized
DEBUG - 2017-03-06 11:43:58 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:43:58 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:43:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:43:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:43:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-06 11:43:58 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:43:58 --> Final output sent to browser
DEBUG - 2017-03-06 11:43:58 --> Total execution time: 0.0148
INFO - 2017-03-06 11:43:59 --> Config Class Initialized
INFO - 2017-03-06 11:43:59 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:43:59 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:43:59 --> Utf8 Class Initialized
INFO - 2017-03-06 11:43:59 --> URI Class Initialized
INFO - 2017-03-06 11:43:59 --> Router Class Initialized
INFO - 2017-03-06 11:43:59 --> Output Class Initialized
INFO - 2017-03-06 11:43:59 --> Security Class Initialized
DEBUG - 2017-03-06 11:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:43:59 --> Input Class Initialized
INFO - 2017-03-06 11:43:59 --> Language Class Initialized
INFO - 2017-03-06 11:43:59 --> Language Class Initialized
INFO - 2017-03-06 11:43:59 --> Config Class Initialized
INFO - 2017-03-06 11:43:59 --> Loader Class Initialized
INFO - 2017-03-06 11:43:59 --> Helper loaded: form_helper
INFO - 2017-03-06 11:43:59 --> Helper loaded: url_helper
INFO - 2017-03-06 11:43:59 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:43:59 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:43:59 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:43:59 --> Template Class Initialized
INFO - 2017-03-06 11:43:59 --> Model Class Initialized
INFO - 2017-03-06 11:43:59 --> Controller Class Initialized
DEBUG - 2017-03-06 11:43:59 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:43:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:43:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:43:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:43:59 --> Config Class Initialized
INFO - 2017-03-06 11:43:59 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:43:59 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:43:59 --> Utf8 Class Initialized
INFO - 2017-03-06 11:43:59 --> URI Class Initialized
INFO - 2017-03-06 11:43:59 --> Router Class Initialized
INFO - 2017-03-06 11:43:59 --> Output Class Initialized
INFO - 2017-03-06 11:43:59 --> Security Class Initialized
DEBUG - 2017-03-06 11:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:43:59 --> Input Class Initialized
INFO - 2017-03-06 11:43:59 --> Language Class Initialized
INFO - 2017-03-06 11:43:59 --> Language Class Initialized
INFO - 2017-03-06 11:43:59 --> Config Class Initialized
INFO - 2017-03-06 11:43:59 --> Loader Class Initialized
INFO - 2017-03-06 11:43:59 --> Helper loaded: form_helper
INFO - 2017-03-06 11:43:59 --> Helper loaded: url_helper
INFO - 2017-03-06 11:43:59 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:43:59 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:43:59 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:43:59 --> Template Class Initialized
INFO - 2017-03-06 11:43:59 --> Model Class Initialized
INFO - 2017-03-06 11:43:59 --> Controller Class Initialized
DEBUG - 2017-03-06 11:43:59 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:43:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:43:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:43:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:44:00 --> Config Class Initialized
INFO - 2017-03-06 11:44:00 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:00 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:00 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:00 --> URI Class Initialized
INFO - 2017-03-06 11:44:00 --> Router Class Initialized
INFO - 2017-03-06 11:44:00 --> Output Class Initialized
INFO - 2017-03-06 11:44:00 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:00 --> Input Class Initialized
INFO - 2017-03-06 11:44:00 --> Language Class Initialized
INFO - 2017-03-06 11:44:00 --> Language Class Initialized
INFO - 2017-03-06 11:44:00 --> Config Class Initialized
INFO - 2017-03-06 11:44:00 --> Loader Class Initialized
INFO - 2017-03-06 11:44:00 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:00 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:00 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:00 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:01 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:01 --> Template Class Initialized
INFO - 2017-03-06 11:44:01 --> Model Class Initialized
INFO - 2017-03-06 11:44:01 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:01 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:44:01 --> Config Class Initialized
INFO - 2017-03-06 11:44:01 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:01 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:01 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:01 --> URI Class Initialized
INFO - 2017-03-06 11:44:01 --> Router Class Initialized
INFO - 2017-03-06 11:44:01 --> Output Class Initialized
INFO - 2017-03-06 11:44:01 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:01 --> Input Class Initialized
INFO - 2017-03-06 11:44:01 --> Language Class Initialized
INFO - 2017-03-06 11:44:01 --> Language Class Initialized
INFO - 2017-03-06 11:44:01 --> Config Class Initialized
INFO - 2017-03-06 11:44:01 --> Loader Class Initialized
INFO - 2017-03-06 11:44:01 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:01 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:01 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:01 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:01 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:01 --> Template Class Initialized
INFO - 2017-03-06 11:44:01 --> Model Class Initialized
INFO - 2017-03-06 11:44:01 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:01 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:44:01 --> Config Class Initialized
INFO - 2017-03-06 11:44:01 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:01 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:01 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:01 --> URI Class Initialized
INFO - 2017-03-06 11:44:01 --> Router Class Initialized
INFO - 2017-03-06 11:44:01 --> Output Class Initialized
INFO - 2017-03-06 11:44:01 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:01 --> Input Class Initialized
INFO - 2017-03-06 11:44:01 --> Language Class Initialized
INFO - 2017-03-06 11:44:01 --> Language Class Initialized
INFO - 2017-03-06 11:44:01 --> Config Class Initialized
INFO - 2017-03-06 11:44:01 --> Loader Class Initialized
INFO - 2017-03-06 11:44:01 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:01 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:01 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:01 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:01 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:01 --> Template Class Initialized
INFO - 2017-03-06 11:44:01 --> Model Class Initialized
INFO - 2017-03-06 11:44:01 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:01 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:44:04 --> Config Class Initialized
INFO - 2017-03-06 11:44:04 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:04 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:04 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:04 --> URI Class Initialized
INFO - 2017-03-06 11:44:04 --> Router Class Initialized
INFO - 2017-03-06 11:44:04 --> Output Class Initialized
INFO - 2017-03-06 11:44:04 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:04 --> Input Class Initialized
INFO - 2017-03-06 11:44:04 --> Language Class Initialized
INFO - 2017-03-06 11:44:04 --> Language Class Initialized
INFO - 2017-03-06 11:44:04 --> Config Class Initialized
INFO - 2017-03-06 11:44:04 --> Loader Class Initialized
INFO - 2017-03-06 11:44:04 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:04 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:04 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:04 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:04 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:04 --> Template Class Initialized
INFO - 2017-03-06 11:44:04 --> Model Class Initialized
INFO - 2017-03-06 11:44:04 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:04 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:04 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:44:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 11:44:04 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:44:04 --> Final output sent to browser
DEBUG - 2017-03-06 11:44:04 --> Total execution time: 0.0169
INFO - 2017-03-06 11:44:05 --> Config Class Initialized
INFO - 2017-03-06 11:44:05 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:05 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:05 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:05 --> URI Class Initialized
INFO - 2017-03-06 11:44:05 --> Router Class Initialized
INFO - 2017-03-06 11:44:05 --> Output Class Initialized
INFO - 2017-03-06 11:44:05 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:05 --> Input Class Initialized
INFO - 2017-03-06 11:44:05 --> Language Class Initialized
INFO - 2017-03-06 11:44:05 --> Language Class Initialized
INFO - 2017-03-06 11:44:05 --> Config Class Initialized
INFO - 2017-03-06 11:44:05 --> Loader Class Initialized
INFO - 2017-03-06 11:44:05 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:05 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:05 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:05 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:05 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:05 --> Template Class Initialized
INFO - 2017-03-06 11:44:05 --> Model Class Initialized
INFO - 2017-03-06 11:44:05 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:05 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:44:07 --> Config Class Initialized
INFO - 2017-03-06 11:44:07 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:07 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:07 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:07 --> URI Class Initialized
INFO - 2017-03-06 11:44:07 --> Router Class Initialized
INFO - 2017-03-06 11:44:07 --> Output Class Initialized
INFO - 2017-03-06 11:44:07 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:07 --> Input Class Initialized
INFO - 2017-03-06 11:44:07 --> Language Class Initialized
INFO - 2017-03-06 11:44:07 --> Language Class Initialized
INFO - 2017-03-06 11:44:07 --> Config Class Initialized
INFO - 2017-03-06 11:44:07 --> Loader Class Initialized
INFO - 2017-03-06 11:44:07 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:07 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:07 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:07 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:07 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:07 --> Template Class Initialized
INFO - 2017-03-06 11:44:07 --> Model Class Initialized
INFO - 2017-03-06 11:44:07 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:07 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:07 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:44:07 --> Config Class Initialized
INFO - 2017-03-06 11:44:07 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:07 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:07 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:07 --> URI Class Initialized
INFO - 2017-03-06 11:44:07 --> Router Class Initialized
INFO - 2017-03-06 11:44:07 --> Output Class Initialized
INFO - 2017-03-06 11:44:07 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:07 --> Input Class Initialized
INFO - 2017-03-06 11:44:07 --> Language Class Initialized
INFO - 2017-03-06 11:44:07 --> Language Class Initialized
INFO - 2017-03-06 11:44:07 --> Config Class Initialized
INFO - 2017-03-06 11:44:07 --> Loader Class Initialized
INFO - 2017-03-06 11:44:07 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:07 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:07 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:07 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:07 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:07 --> Template Class Initialized
INFO - 2017-03-06 11:44:07 --> Model Class Initialized
INFO - 2017-03-06 11:44:07 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:07 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:07 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:07 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:44:16 --> Config Class Initialized
INFO - 2017-03-06 11:44:16 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:16 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:16 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:16 --> URI Class Initialized
INFO - 2017-03-06 11:44:16 --> Router Class Initialized
INFO - 2017-03-06 11:44:16 --> Output Class Initialized
INFO - 2017-03-06 11:44:16 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:16 --> Input Class Initialized
INFO - 2017-03-06 11:44:16 --> Language Class Initialized
INFO - 2017-03-06 11:44:16 --> Language Class Initialized
INFO - 2017-03-06 11:44:16 --> Config Class Initialized
INFO - 2017-03-06 11:44:16 --> Loader Class Initialized
INFO - 2017-03-06 11:44:16 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:16 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:16 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:16 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:16 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:16 --> Template Class Initialized
INFO - 2017-03-06 11:44:16 --> Model Class Initialized
INFO - 2017-03-06 11:44:16 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:16 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:16 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:44:16 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 11:44:16 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:44:16 --> Final output sent to browser
DEBUG - 2017-03-06 11:44:16 --> Total execution time: 0.0165
INFO - 2017-03-06 11:44:17 --> Config Class Initialized
INFO - 2017-03-06 11:44:17 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:17 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:17 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:17 --> URI Class Initialized
INFO - 2017-03-06 11:44:17 --> Router Class Initialized
INFO - 2017-03-06 11:44:17 --> Output Class Initialized
INFO - 2017-03-06 11:44:17 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:17 --> Input Class Initialized
INFO - 2017-03-06 11:44:17 --> Language Class Initialized
INFO - 2017-03-06 11:44:17 --> Language Class Initialized
INFO - 2017-03-06 11:44:17 --> Config Class Initialized
INFO - 2017-03-06 11:44:17 --> Loader Class Initialized
INFO - 2017-03-06 11:44:17 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:17 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:17 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:17 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:17 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:17 --> Template Class Initialized
INFO - 2017-03-06 11:44:17 --> Model Class Initialized
INFO - 2017-03-06 11:44:17 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:17 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:44:17 --> Config Class Initialized
INFO - 2017-03-06 11:44:17 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:17 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:17 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:17 --> URI Class Initialized
INFO - 2017-03-06 11:44:17 --> Router Class Initialized
INFO - 2017-03-06 11:44:17 --> Output Class Initialized
INFO - 2017-03-06 11:44:17 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:17 --> Input Class Initialized
INFO - 2017-03-06 11:44:17 --> Language Class Initialized
INFO - 2017-03-06 11:44:17 --> Language Class Initialized
INFO - 2017-03-06 11:44:17 --> Config Class Initialized
INFO - 2017-03-06 11:44:17 --> Loader Class Initialized
INFO - 2017-03-06 11:44:17 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:17 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:17 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:17 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:17 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:17 --> Template Class Initialized
INFO - 2017-03-06 11:44:17 --> Model Class Initialized
INFO - 2017-03-06 11:44:17 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:17 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:44:35 --> Config Class Initialized
INFO - 2017-03-06 11:44:35 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:35 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:35 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:35 --> URI Class Initialized
DEBUG - 2017-03-06 11:44:35 --> No URI present. Default controller set.
INFO - 2017-03-06 11:44:35 --> Router Class Initialized
INFO - 2017-03-06 11:44:35 --> Output Class Initialized
INFO - 2017-03-06 11:44:35 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:35 --> Input Class Initialized
INFO - 2017-03-06 11:44:35 --> Language Class Initialized
INFO - 2017-03-06 11:44:35 --> Language Class Initialized
INFO - 2017-03-06 11:44:35 --> Config Class Initialized
INFO - 2017-03-06 11:44:35 --> Loader Class Initialized
INFO - 2017-03-06 11:44:35 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:35 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:35 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:35 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:35 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:35 --> Template Class Initialized
INFO - 2017-03-06 11:44:35 --> Model Class Initialized
INFO - 2017-03-06 11:44:35 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:35 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:35 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:44:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-06 11:44:35 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:44:35 --> Final output sent to browser
DEBUG - 2017-03-06 11:44:35 --> Total execution time: 0.0146
INFO - 2017-03-06 11:44:35 --> Config Class Initialized
INFO - 2017-03-06 11:44:35 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:35 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:35 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:35 --> URI Class Initialized
INFO - 2017-03-06 11:44:35 --> Router Class Initialized
INFO - 2017-03-06 11:44:35 --> Output Class Initialized
INFO - 2017-03-06 11:44:35 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:35 --> Input Class Initialized
INFO - 2017-03-06 11:44:35 --> Language Class Initialized
INFO - 2017-03-06 11:44:35 --> Language Class Initialized
INFO - 2017-03-06 11:44:35 --> Config Class Initialized
INFO - 2017-03-06 11:44:35 --> Loader Class Initialized
INFO - 2017-03-06 11:44:35 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:35 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:35 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:35 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:35 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:35 --> Template Class Initialized
INFO - 2017-03-06 11:44:35 --> Model Class Initialized
INFO - 2017-03-06 11:44:35 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:35 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:35 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:44:35 --> Config Class Initialized
INFO - 2017-03-06 11:44:35 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:35 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:35 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:35 --> URI Class Initialized
INFO - 2017-03-06 11:44:35 --> Router Class Initialized
INFO - 2017-03-06 11:44:35 --> Output Class Initialized
INFO - 2017-03-06 11:44:35 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:35 --> Input Class Initialized
INFO - 2017-03-06 11:44:35 --> Language Class Initialized
INFO - 2017-03-06 11:44:35 --> Language Class Initialized
INFO - 2017-03-06 11:44:35 --> Config Class Initialized
INFO - 2017-03-06 11:44:35 --> Loader Class Initialized
INFO - 2017-03-06 11:44:35 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:35 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:35 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:35 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:35 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:35 --> Template Class Initialized
INFO - 2017-03-06 11:44:35 --> Model Class Initialized
INFO - 2017-03-06 11:44:35 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:35 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:35 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:35 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:44:38 --> Config Class Initialized
INFO - 2017-03-06 11:44:38 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:38 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:38 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:38 --> URI Class Initialized
INFO - 2017-03-06 11:44:38 --> Router Class Initialized
INFO - 2017-03-06 11:44:38 --> Output Class Initialized
INFO - 2017-03-06 11:44:38 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:38 --> Input Class Initialized
INFO - 2017-03-06 11:44:38 --> Language Class Initialized
INFO - 2017-03-06 11:44:38 --> Language Class Initialized
INFO - 2017-03-06 11:44:38 --> Config Class Initialized
INFO - 2017-03-06 11:44:38 --> Loader Class Initialized
INFO - 2017-03-06 11:44:38 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:38 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:38 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:38 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:38 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:38 --> Template Class Initialized
INFO - 2017-03-06 11:44:38 --> Model Class Initialized
INFO - 2017-03-06 11:44:38 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:38 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:38 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:44:57 --> Config Class Initialized
INFO - 2017-03-06 11:44:57 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:57 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:57 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:57 --> URI Class Initialized
INFO - 2017-03-06 11:44:57 --> Router Class Initialized
INFO - 2017-03-06 11:44:57 --> Output Class Initialized
INFO - 2017-03-06 11:44:57 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:57 --> Input Class Initialized
INFO - 2017-03-06 11:44:57 --> Language Class Initialized
INFO - 2017-03-06 11:44:57 --> Language Class Initialized
INFO - 2017-03-06 11:44:57 --> Config Class Initialized
INFO - 2017-03-06 11:44:57 --> Loader Class Initialized
INFO - 2017-03-06 11:44:57 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:57 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:57 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:57 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:57 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:57 --> Template Class Initialized
INFO - 2017-03-06 11:44:57 --> Model Class Initialized
INFO - 2017-03-06 11:44:57 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:57 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:57 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:44:58 --> Config Class Initialized
INFO - 2017-03-06 11:44:58 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:58 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:58 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:58 --> URI Class Initialized
INFO - 2017-03-06 11:44:58 --> Router Class Initialized
INFO - 2017-03-06 11:44:58 --> Output Class Initialized
INFO - 2017-03-06 11:44:58 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:58 --> Input Class Initialized
INFO - 2017-03-06 11:44:58 --> Language Class Initialized
INFO - 2017-03-06 11:44:58 --> Language Class Initialized
INFO - 2017-03-06 11:44:58 --> Config Class Initialized
INFO - 2017-03-06 11:44:58 --> Loader Class Initialized
INFO - 2017-03-06 11:44:58 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:58 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:58 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:58 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:58 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:58 --> Template Class Initialized
INFO - 2017-03-06 11:44:58 --> Model Class Initialized
INFO - 2017-03-06 11:44:58 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:58 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:58 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:44:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 11:44:58 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:44:58 --> Final output sent to browser
DEBUG - 2017-03-06 11:44:58 --> Total execution time: 0.0144
INFO - 2017-03-06 11:44:58 --> Config Class Initialized
INFO - 2017-03-06 11:44:58 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:58 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:58 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:58 --> URI Class Initialized
INFO - 2017-03-06 11:44:58 --> Router Class Initialized
INFO - 2017-03-06 11:44:58 --> Output Class Initialized
INFO - 2017-03-06 11:44:58 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:58 --> Input Class Initialized
INFO - 2017-03-06 11:44:58 --> Language Class Initialized
INFO - 2017-03-06 11:44:58 --> Language Class Initialized
INFO - 2017-03-06 11:44:58 --> Config Class Initialized
INFO - 2017-03-06 11:44:58 --> Loader Class Initialized
INFO - 2017-03-06 11:44:58 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:58 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:58 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:58 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:58 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:58 --> Template Class Initialized
INFO - 2017-03-06 11:44:58 --> Model Class Initialized
INFO - 2017-03-06 11:44:58 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:58 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:58 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:44:59 --> Config Class Initialized
INFO - 2017-03-06 11:44:59 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:59 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:59 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:59 --> URI Class Initialized
INFO - 2017-03-06 11:44:59 --> Router Class Initialized
INFO - 2017-03-06 11:44:59 --> Output Class Initialized
INFO - 2017-03-06 11:44:59 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:59 --> Input Class Initialized
INFO - 2017-03-06 11:44:59 --> Language Class Initialized
INFO - 2017-03-06 11:44:59 --> Language Class Initialized
INFO - 2017-03-06 11:44:59 --> Config Class Initialized
INFO - 2017-03-06 11:44:59 --> Loader Class Initialized
INFO - 2017-03-06 11:44:59 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:59 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:59 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:59 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:59 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:59 --> Template Class Initialized
INFO - 2017-03-06 11:44:59 --> Model Class Initialized
INFO - 2017-03-06 11:44:59 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:59 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:44:59 --> Config Class Initialized
INFO - 2017-03-06 11:44:59 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:44:59 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:44:59 --> Utf8 Class Initialized
INFO - 2017-03-06 11:44:59 --> URI Class Initialized
INFO - 2017-03-06 11:44:59 --> Router Class Initialized
INFO - 2017-03-06 11:44:59 --> Output Class Initialized
INFO - 2017-03-06 11:44:59 --> Security Class Initialized
DEBUG - 2017-03-06 11:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:44:59 --> Input Class Initialized
INFO - 2017-03-06 11:44:59 --> Language Class Initialized
INFO - 2017-03-06 11:44:59 --> Language Class Initialized
INFO - 2017-03-06 11:44:59 --> Config Class Initialized
INFO - 2017-03-06 11:44:59 --> Loader Class Initialized
INFO - 2017-03-06 11:44:59 --> Helper loaded: form_helper
INFO - 2017-03-06 11:44:59 --> Helper loaded: url_helper
INFO - 2017-03-06 11:44:59 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:44:59 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:44:59 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:44:59 --> Template Class Initialized
INFO - 2017-03-06 11:44:59 --> Model Class Initialized
INFO - 2017-03-06 11:44:59 --> Controller Class Initialized
DEBUG - 2017-03-06 11:44:59 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:44:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:44:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:44:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:45:02 --> Config Class Initialized
INFO - 2017-03-06 11:45:02 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:45:02 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:45:02 --> Utf8 Class Initialized
INFO - 2017-03-06 11:45:02 --> URI Class Initialized
INFO - 2017-03-06 11:45:02 --> Router Class Initialized
INFO - 2017-03-06 11:45:02 --> Output Class Initialized
INFO - 2017-03-06 11:45:02 --> Security Class Initialized
DEBUG - 2017-03-06 11:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:45:02 --> Input Class Initialized
INFO - 2017-03-06 11:45:02 --> Language Class Initialized
INFO - 2017-03-06 11:45:02 --> Language Class Initialized
INFO - 2017-03-06 11:45:02 --> Config Class Initialized
INFO - 2017-03-06 11:45:02 --> Loader Class Initialized
INFO - 2017-03-06 11:45:02 --> Helper loaded: form_helper
INFO - 2017-03-06 11:45:02 --> Helper loaded: url_helper
INFO - 2017-03-06 11:45:02 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:45:02 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:45:02 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:45:02 --> Template Class Initialized
INFO - 2017-03-06 11:45:02 --> Model Class Initialized
INFO - 2017-03-06 11:45:02 --> Controller Class Initialized
DEBUG - 2017-03-06 11:45:02 --> Login MX_Controller Initialized
INFO - 2017-03-06 11:45:02 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:45:02 --> Form Validation Class Initialized
INFO - 2017-03-06 11:45:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-06 11:45:02 --> Config Class Initialized
INFO - 2017-03-06 11:45:02 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:45:02 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:45:02 --> Utf8 Class Initialized
INFO - 2017-03-06 11:45:02 --> URI Class Initialized
INFO - 2017-03-06 11:45:02 --> Router Class Initialized
INFO - 2017-03-06 11:45:02 --> Output Class Initialized
INFO - 2017-03-06 11:45:02 --> Security Class Initialized
DEBUG - 2017-03-06 11:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:45:02 --> Input Class Initialized
INFO - 2017-03-06 11:45:02 --> Language Class Initialized
INFO - 2017-03-06 11:45:02 --> Language Class Initialized
INFO - 2017-03-06 11:45:02 --> Config Class Initialized
INFO - 2017-03-06 11:45:02 --> Loader Class Initialized
INFO - 2017-03-06 11:45:02 --> Helper loaded: form_helper
INFO - 2017-03-06 11:45:02 --> Helper loaded: url_helper
INFO - 2017-03-06 11:45:02 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:45:02 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:45:02 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:45:02 --> Template Class Initialized
INFO - 2017-03-06 11:45:02 --> Model Class Initialized
INFO - 2017-03-06 11:45:02 --> Controller Class Initialized
DEBUG - 2017-03-06 11:45:02 --> Dashboard MX_Controller Initialized
INFO - 2017-03-06 11:45:02 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:45:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:45:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:45:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:45:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-06 11:45:02 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:45:02 --> Final output sent to browser
DEBUG - 2017-03-06 11:45:02 --> Total execution time: 0.0175
INFO - 2017-03-06 11:45:05 --> Config Class Initialized
INFO - 2017-03-06 11:45:05 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:45:05 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:45:05 --> Utf8 Class Initialized
INFO - 2017-03-06 11:45:05 --> URI Class Initialized
INFO - 2017-03-06 11:45:05 --> Router Class Initialized
INFO - 2017-03-06 11:45:05 --> Output Class Initialized
INFO - 2017-03-06 11:45:05 --> Security Class Initialized
DEBUG - 2017-03-06 11:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:45:05 --> Input Class Initialized
INFO - 2017-03-06 11:45:05 --> Language Class Initialized
INFO - 2017-03-06 11:45:05 --> Language Class Initialized
INFO - 2017-03-06 11:45:05 --> Config Class Initialized
INFO - 2017-03-06 11:45:05 --> Loader Class Initialized
INFO - 2017-03-06 11:45:05 --> Helper loaded: form_helper
INFO - 2017-03-06 11:45:05 --> Helper loaded: url_helper
INFO - 2017-03-06 11:45:05 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:45:05 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:45:05 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:45:05 --> Template Class Initialized
INFO - 2017-03-06 11:45:05 --> Model Class Initialized
INFO - 2017-03-06 11:45:05 --> Controller Class Initialized
DEBUG - 2017-03-06 11:45:05 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:45:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:45:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:45:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:45:05 --> Config Class Initialized
INFO - 2017-03-06 11:45:05 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:45:05 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:45:05 --> Utf8 Class Initialized
INFO - 2017-03-06 11:45:05 --> URI Class Initialized
INFO - 2017-03-06 11:45:05 --> Router Class Initialized
INFO - 2017-03-06 11:45:05 --> Output Class Initialized
INFO - 2017-03-06 11:45:05 --> Security Class Initialized
DEBUG - 2017-03-06 11:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:45:05 --> Input Class Initialized
INFO - 2017-03-06 11:45:05 --> Language Class Initialized
INFO - 2017-03-06 11:45:05 --> Language Class Initialized
INFO - 2017-03-06 11:45:05 --> Config Class Initialized
INFO - 2017-03-06 11:45:05 --> Loader Class Initialized
INFO - 2017-03-06 11:45:05 --> Helper loaded: form_helper
INFO - 2017-03-06 11:45:05 --> Helper loaded: url_helper
INFO - 2017-03-06 11:45:05 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:45:05 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:45:05 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:45:05 --> Template Class Initialized
INFO - 2017-03-06 11:45:05 --> Model Class Initialized
INFO - 2017-03-06 11:45:05 --> Controller Class Initialized
DEBUG - 2017-03-06 11:45:05 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:45:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:45:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:45:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:45:09 --> Config Class Initialized
INFO - 2017-03-06 11:45:09 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:45:09 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:45:09 --> Utf8 Class Initialized
INFO - 2017-03-06 11:45:09 --> URI Class Initialized
INFO - 2017-03-06 11:45:09 --> Router Class Initialized
INFO - 2017-03-06 11:45:09 --> Output Class Initialized
INFO - 2017-03-06 11:45:09 --> Security Class Initialized
DEBUG - 2017-03-06 11:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:45:09 --> Input Class Initialized
INFO - 2017-03-06 11:45:09 --> Language Class Initialized
INFO - 2017-03-06 11:45:09 --> Language Class Initialized
INFO - 2017-03-06 11:45:09 --> Config Class Initialized
INFO - 2017-03-06 11:45:09 --> Loader Class Initialized
INFO - 2017-03-06 11:45:09 --> Helper loaded: form_helper
INFO - 2017-03-06 11:45:09 --> Helper loaded: url_helper
INFO - 2017-03-06 11:45:09 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:45:09 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:45:09 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:45:09 --> Template Class Initialized
INFO - 2017-03-06 11:45:09 --> Model Class Initialized
INFO - 2017-03-06 11:45:09 --> Controller Class Initialized
DEBUG - 2017-03-06 11:45:09 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:45:09 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:45:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:45:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:45:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 11:45:09 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:45:09 --> Final output sent to browser
DEBUG - 2017-03-06 11:45:09 --> Total execution time: 0.0146
INFO - 2017-03-06 11:45:09 --> Config Class Initialized
INFO - 2017-03-06 11:45:09 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:45:09 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:45:09 --> Utf8 Class Initialized
INFO - 2017-03-06 11:45:09 --> URI Class Initialized
INFO - 2017-03-06 11:45:09 --> Router Class Initialized
INFO - 2017-03-06 11:45:09 --> Output Class Initialized
INFO - 2017-03-06 11:45:09 --> Security Class Initialized
DEBUG - 2017-03-06 11:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:45:09 --> Input Class Initialized
INFO - 2017-03-06 11:45:09 --> Language Class Initialized
INFO - 2017-03-06 11:45:09 --> Language Class Initialized
INFO - 2017-03-06 11:45:09 --> Config Class Initialized
INFO - 2017-03-06 11:45:09 --> Loader Class Initialized
INFO - 2017-03-06 11:45:09 --> Helper loaded: form_helper
INFO - 2017-03-06 11:45:09 --> Helper loaded: url_helper
INFO - 2017-03-06 11:45:09 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:45:09 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:45:09 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:45:09 --> Template Class Initialized
INFO - 2017-03-06 11:45:09 --> Model Class Initialized
INFO - 2017-03-06 11:45:09 --> Controller Class Initialized
DEBUG - 2017-03-06 11:45:09 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:45:09 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:45:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:45:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:45:09 --> Config Class Initialized
INFO - 2017-03-06 11:45:09 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:45:09 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:45:09 --> Utf8 Class Initialized
INFO - 2017-03-06 11:45:09 --> URI Class Initialized
INFO - 2017-03-06 11:45:09 --> Router Class Initialized
INFO - 2017-03-06 11:45:09 --> Output Class Initialized
INFO - 2017-03-06 11:45:09 --> Security Class Initialized
DEBUG - 2017-03-06 11:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:45:09 --> Input Class Initialized
INFO - 2017-03-06 11:45:09 --> Language Class Initialized
INFO - 2017-03-06 11:45:09 --> Language Class Initialized
INFO - 2017-03-06 11:45:09 --> Config Class Initialized
INFO - 2017-03-06 11:45:09 --> Loader Class Initialized
INFO - 2017-03-06 11:45:09 --> Helper loaded: form_helper
INFO - 2017-03-06 11:45:09 --> Helper loaded: url_helper
INFO - 2017-03-06 11:45:09 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:45:09 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:45:09 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:45:09 --> Template Class Initialized
INFO - 2017-03-06 11:45:09 --> Model Class Initialized
INFO - 2017-03-06 11:45:09 --> Controller Class Initialized
DEBUG - 2017-03-06 11:45:09 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:45:09 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:45:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:45:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:45:10 --> Config Class Initialized
INFO - 2017-03-06 11:45:10 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:45:10 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:45:10 --> Utf8 Class Initialized
INFO - 2017-03-06 11:45:10 --> URI Class Initialized
INFO - 2017-03-06 11:45:10 --> Router Class Initialized
INFO - 2017-03-06 11:45:10 --> Output Class Initialized
INFO - 2017-03-06 11:45:10 --> Security Class Initialized
DEBUG - 2017-03-06 11:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:45:10 --> Input Class Initialized
INFO - 2017-03-06 11:45:10 --> Language Class Initialized
INFO - 2017-03-06 11:45:10 --> Language Class Initialized
INFO - 2017-03-06 11:45:10 --> Config Class Initialized
INFO - 2017-03-06 11:45:10 --> Loader Class Initialized
INFO - 2017-03-06 11:45:10 --> Helper loaded: form_helper
INFO - 2017-03-06 11:45:10 --> Helper loaded: url_helper
INFO - 2017-03-06 11:45:10 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:45:10 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:45:10 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:45:10 --> Template Class Initialized
INFO - 2017-03-06 11:45:10 --> Model Class Initialized
INFO - 2017-03-06 11:45:10 --> Controller Class Initialized
DEBUG - 2017-03-06 11:45:10 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:45:10 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:45:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:45:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:45:15 --> Config Class Initialized
INFO - 2017-03-06 11:45:15 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:45:15 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:45:15 --> Utf8 Class Initialized
INFO - 2017-03-06 11:45:15 --> URI Class Initialized
INFO - 2017-03-06 11:45:15 --> Router Class Initialized
INFO - 2017-03-06 11:45:15 --> Output Class Initialized
INFO - 2017-03-06 11:45:15 --> Security Class Initialized
DEBUG - 2017-03-06 11:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:45:15 --> Input Class Initialized
INFO - 2017-03-06 11:45:15 --> Language Class Initialized
INFO - 2017-03-06 11:45:15 --> Language Class Initialized
INFO - 2017-03-06 11:45:15 --> Config Class Initialized
INFO - 2017-03-06 11:45:15 --> Loader Class Initialized
INFO - 2017-03-06 11:45:15 --> Helper loaded: form_helper
INFO - 2017-03-06 11:45:15 --> Helper loaded: url_helper
INFO - 2017-03-06 11:45:15 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:45:15 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:45:15 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:45:15 --> Template Class Initialized
INFO - 2017-03-06 11:45:15 --> Model Class Initialized
INFO - 2017-03-06 11:45:15 --> Controller Class Initialized
DEBUG - 2017-03-06 11:45:15 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:45:15 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:45:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:45:15 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:45:20 --> Config Class Initialized
INFO - 2017-03-06 11:45:20 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:45:20 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:45:20 --> Utf8 Class Initialized
INFO - 2017-03-06 11:45:20 --> URI Class Initialized
INFO - 2017-03-06 11:45:20 --> Router Class Initialized
INFO - 2017-03-06 11:45:20 --> Output Class Initialized
INFO - 2017-03-06 11:45:20 --> Security Class Initialized
DEBUG - 2017-03-06 11:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:45:20 --> Input Class Initialized
INFO - 2017-03-06 11:45:20 --> Language Class Initialized
INFO - 2017-03-06 11:45:20 --> Language Class Initialized
INFO - 2017-03-06 11:45:20 --> Config Class Initialized
INFO - 2017-03-06 11:45:20 --> Loader Class Initialized
INFO - 2017-03-06 11:45:20 --> Helper loaded: form_helper
INFO - 2017-03-06 11:45:20 --> Helper loaded: url_helper
INFO - 2017-03-06 11:45:20 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:45:20 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:45:20 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:45:20 --> Template Class Initialized
INFO - 2017-03-06 11:45:20 --> Model Class Initialized
INFO - 2017-03-06 11:45:20 --> Controller Class Initialized
DEBUG - 2017-03-06 11:45:20 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:45:20 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:45:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:45:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:45:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 11:45:20 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:45:20 --> Final output sent to browser
DEBUG - 2017-03-06 11:45:20 --> Total execution time: 0.0178
INFO - 2017-03-06 11:45:20 --> Config Class Initialized
INFO - 2017-03-06 11:45:20 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:45:20 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:45:20 --> Utf8 Class Initialized
INFO - 2017-03-06 11:45:20 --> URI Class Initialized
INFO - 2017-03-06 11:45:20 --> Router Class Initialized
INFO - 2017-03-06 11:45:20 --> Output Class Initialized
INFO - 2017-03-06 11:45:20 --> Security Class Initialized
DEBUG - 2017-03-06 11:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:45:20 --> Input Class Initialized
INFO - 2017-03-06 11:45:20 --> Language Class Initialized
INFO - 2017-03-06 11:45:20 --> Language Class Initialized
INFO - 2017-03-06 11:45:20 --> Config Class Initialized
INFO - 2017-03-06 11:45:20 --> Loader Class Initialized
INFO - 2017-03-06 11:45:20 --> Helper loaded: form_helper
INFO - 2017-03-06 11:45:20 --> Helper loaded: url_helper
INFO - 2017-03-06 11:45:20 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:45:20 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:45:20 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:45:20 --> Template Class Initialized
INFO - 2017-03-06 11:45:20 --> Model Class Initialized
INFO - 2017-03-06 11:45:20 --> Controller Class Initialized
DEBUG - 2017-03-06 11:45:20 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:45:20 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:45:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:45:20 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:45:49 --> Config Class Initialized
INFO - 2017-03-06 11:45:49 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:45:49 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:45:49 --> Utf8 Class Initialized
INFO - 2017-03-06 11:45:49 --> URI Class Initialized
INFO - 2017-03-06 11:45:49 --> Router Class Initialized
INFO - 2017-03-06 11:45:49 --> Output Class Initialized
INFO - 2017-03-06 11:45:49 --> Security Class Initialized
DEBUG - 2017-03-06 11:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:45:49 --> Input Class Initialized
INFO - 2017-03-06 11:45:49 --> Language Class Initialized
INFO - 2017-03-06 11:45:49 --> Language Class Initialized
INFO - 2017-03-06 11:45:49 --> Config Class Initialized
INFO - 2017-03-06 11:45:49 --> Loader Class Initialized
INFO - 2017-03-06 11:45:49 --> Helper loaded: form_helper
INFO - 2017-03-06 11:45:49 --> Helper loaded: url_helper
INFO - 2017-03-06 11:45:49 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:45:49 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:45:49 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:45:49 --> Template Class Initialized
INFO - 2017-03-06 11:45:49 --> Model Class Initialized
INFO - 2017-03-06 11:45:49 --> Controller Class Initialized
DEBUG - 2017-03-06 11:45:49 --> Dashboard MX_Controller Initialized
INFO - 2017-03-06 11:45:49 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:45:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:45:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:45:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:45:49 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-06 11:45:49 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:45:49 --> Final output sent to browser
DEBUG - 2017-03-06 11:45:49 --> Total execution time: 0.0609
INFO - 2017-03-06 11:45:50 --> Config Class Initialized
INFO - 2017-03-06 11:45:50 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:45:50 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:45:50 --> Utf8 Class Initialized
INFO - 2017-03-06 11:45:50 --> URI Class Initialized
INFO - 2017-03-06 11:45:50 --> Router Class Initialized
INFO - 2017-03-06 11:45:50 --> Output Class Initialized
INFO - 2017-03-06 11:45:50 --> Security Class Initialized
DEBUG - 2017-03-06 11:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:45:50 --> Input Class Initialized
INFO - 2017-03-06 11:45:50 --> Language Class Initialized
INFO - 2017-03-06 11:45:50 --> Language Class Initialized
INFO - 2017-03-06 11:45:50 --> Config Class Initialized
INFO - 2017-03-06 11:45:50 --> Loader Class Initialized
INFO - 2017-03-06 11:45:50 --> Helper loaded: form_helper
INFO - 2017-03-06 11:45:50 --> Helper loaded: url_helper
INFO - 2017-03-06 11:45:50 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:45:50 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:45:50 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:45:50 --> Template Class Initialized
INFO - 2017-03-06 11:45:50 --> Model Class Initialized
INFO - 2017-03-06 11:45:50 --> Controller Class Initialized
DEBUG - 2017-03-06 11:45:50 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:45:50 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:45:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:45:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:46:05 --> Config Class Initialized
INFO - 2017-03-06 11:46:05 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:46:05 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:46:05 --> Utf8 Class Initialized
INFO - 2017-03-06 11:46:05 --> URI Class Initialized
INFO - 2017-03-06 11:46:05 --> Router Class Initialized
INFO - 2017-03-06 11:46:05 --> Output Class Initialized
INFO - 2017-03-06 11:46:05 --> Security Class Initialized
DEBUG - 2017-03-06 11:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:46:05 --> Input Class Initialized
INFO - 2017-03-06 11:46:05 --> Language Class Initialized
INFO - 2017-03-06 11:46:05 --> Language Class Initialized
INFO - 2017-03-06 11:46:05 --> Config Class Initialized
INFO - 2017-03-06 11:46:05 --> Loader Class Initialized
INFO - 2017-03-06 11:46:05 --> Helper loaded: form_helper
INFO - 2017-03-06 11:46:05 --> Helper loaded: url_helper
INFO - 2017-03-06 11:46:05 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:46:05 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:46:05 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:46:05 --> Template Class Initialized
INFO - 2017-03-06 11:46:05 --> Model Class Initialized
INFO - 2017-03-06 11:46:05 --> Controller Class Initialized
DEBUG - 2017-03-06 11:46:05 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:46:05 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:46:05 --> Model Class Initialized
DEBUG - 2017-03-06 11:46:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:46:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:46:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:46:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/project_list.php
DEBUG - 2017-03-06 11:46:05 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:46:05 --> Final output sent to browser
DEBUG - 2017-03-06 11:46:05 --> Total execution time: 0.0222
INFO - 2017-03-06 11:46:08 --> Config Class Initialized
INFO - 2017-03-06 11:46:08 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:46:08 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:46:08 --> Utf8 Class Initialized
INFO - 2017-03-06 11:46:08 --> URI Class Initialized
INFO - 2017-03-06 11:46:08 --> Router Class Initialized
INFO - 2017-03-06 11:46:08 --> Output Class Initialized
INFO - 2017-03-06 11:46:08 --> Security Class Initialized
DEBUG - 2017-03-06 11:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:46:08 --> Input Class Initialized
INFO - 2017-03-06 11:46:08 --> Language Class Initialized
INFO - 2017-03-06 11:46:08 --> Language Class Initialized
INFO - 2017-03-06 11:46:08 --> Config Class Initialized
INFO - 2017-03-06 11:46:08 --> Loader Class Initialized
INFO - 2017-03-06 11:46:08 --> Helper loaded: form_helper
INFO - 2017-03-06 11:46:08 --> Helper loaded: url_helper
INFO - 2017-03-06 11:46:08 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:46:08 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:46:08 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:46:08 --> Template Class Initialized
INFO - 2017-03-06 11:46:08 --> Model Class Initialized
INFO - 2017-03-06 11:46:08 --> Controller Class Initialized
DEBUG - 2017-03-06 11:46:08 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:46:08 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:46:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:46:08 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:46:44 --> Config Class Initialized
INFO - 2017-03-06 11:46:44 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:46:44 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:46:44 --> Utf8 Class Initialized
INFO - 2017-03-06 11:46:45 --> URI Class Initialized
INFO - 2017-03-06 11:46:45 --> Router Class Initialized
INFO - 2017-03-06 11:46:45 --> Output Class Initialized
INFO - 2017-03-06 11:46:45 --> Security Class Initialized
DEBUG - 2017-03-06 11:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:46:45 --> Input Class Initialized
INFO - 2017-03-06 11:46:45 --> Language Class Initialized
INFO - 2017-03-06 11:46:45 --> Language Class Initialized
INFO - 2017-03-06 11:46:45 --> Config Class Initialized
INFO - 2017-03-06 11:46:45 --> Loader Class Initialized
INFO - 2017-03-06 11:46:45 --> Helper loaded: form_helper
INFO - 2017-03-06 11:46:45 --> Helper loaded: url_helper
INFO - 2017-03-06 11:46:45 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:46:45 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:46:45 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:46:45 --> Template Class Initialized
INFO - 2017-03-06 11:46:45 --> Model Class Initialized
INFO - 2017-03-06 11:46:45 --> Controller Class Initialized
DEBUG - 2017-03-06 11:46:45 --> Setting MX_Controller Initialized
INFO - 2017-03-06 11:46:45 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:46:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:46:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:46:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:46:45 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/sync_with_card.php
DEBUG - 2017-03-06 11:46:45 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:46:45 --> Final output sent to browser
DEBUG - 2017-03-06 11:46:45 --> Total execution time: 0.1320
INFO - 2017-03-06 11:46:46 --> Config Class Initialized
INFO - 2017-03-06 11:46:46 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:46:46 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:46:46 --> Utf8 Class Initialized
INFO - 2017-03-06 11:46:46 --> URI Class Initialized
INFO - 2017-03-06 11:46:46 --> Router Class Initialized
INFO - 2017-03-06 11:46:46 --> Output Class Initialized
INFO - 2017-03-06 11:46:46 --> Security Class Initialized
DEBUG - 2017-03-06 11:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:46:46 --> Input Class Initialized
INFO - 2017-03-06 11:46:46 --> Language Class Initialized
INFO - 2017-03-06 11:46:46 --> Language Class Initialized
INFO - 2017-03-06 11:46:46 --> Config Class Initialized
INFO - 2017-03-06 11:46:46 --> Loader Class Initialized
INFO - 2017-03-06 11:46:46 --> Helper loaded: form_helper
INFO - 2017-03-06 11:46:46 --> Helper loaded: url_helper
INFO - 2017-03-06 11:46:46 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:46:46 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:46:46 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:46:46 --> Template Class Initialized
INFO - 2017-03-06 11:46:46 --> Model Class Initialized
INFO - 2017-03-06 11:46:46 --> Controller Class Initialized
DEBUG - 2017-03-06 11:46:46 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:46:46 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:46:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:46:46 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:46:56 --> Config Class Initialized
INFO - 2017-03-06 11:46:56 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:46:56 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:46:56 --> Utf8 Class Initialized
INFO - 2017-03-06 11:46:56 --> URI Class Initialized
INFO - 2017-03-06 11:46:56 --> Router Class Initialized
INFO - 2017-03-06 11:46:56 --> Output Class Initialized
INFO - 2017-03-06 11:46:56 --> Security Class Initialized
DEBUG - 2017-03-06 11:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:46:56 --> Input Class Initialized
INFO - 2017-03-06 11:46:56 --> Language Class Initialized
INFO - 2017-03-06 11:46:56 --> Language Class Initialized
INFO - 2017-03-06 11:46:56 --> Config Class Initialized
INFO - 2017-03-06 11:46:56 --> Loader Class Initialized
INFO - 2017-03-06 11:46:56 --> Helper loaded: form_helper
INFO - 2017-03-06 11:46:56 --> Helper loaded: url_helper
INFO - 2017-03-06 11:46:56 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:46:56 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:46:56 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:46:56 --> Template Class Initialized
INFO - 2017-03-06 11:46:56 --> Model Class Initialized
INFO - 2017-03-06 11:46:56 --> Controller Class Initialized
DEBUG - 2017-03-06 11:46:56 --> Setting MX_Controller Initialized
INFO - 2017-03-06 11:46:56 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:46:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:46:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:46:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:46:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/set_store_name.php
DEBUG - 2017-03-06 11:46:56 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:46:56 --> Final output sent to browser
DEBUG - 2017-03-06 11:46:56 --> Total execution time: 0.0243
INFO - 2017-03-06 11:46:57 --> Config Class Initialized
INFO - 2017-03-06 11:46:57 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:46:57 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:46:57 --> Utf8 Class Initialized
INFO - 2017-03-06 11:46:57 --> URI Class Initialized
INFO - 2017-03-06 11:46:57 --> Router Class Initialized
INFO - 2017-03-06 11:46:57 --> Output Class Initialized
INFO - 2017-03-06 11:46:57 --> Security Class Initialized
DEBUG - 2017-03-06 11:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:46:57 --> Input Class Initialized
INFO - 2017-03-06 11:46:57 --> Language Class Initialized
INFO - 2017-03-06 11:46:57 --> Language Class Initialized
INFO - 2017-03-06 11:46:57 --> Config Class Initialized
INFO - 2017-03-06 11:46:57 --> Loader Class Initialized
INFO - 2017-03-06 11:46:57 --> Helper loaded: form_helper
INFO - 2017-03-06 11:46:57 --> Helper loaded: url_helper
INFO - 2017-03-06 11:46:57 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:46:57 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:46:57 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:46:57 --> Template Class Initialized
INFO - 2017-03-06 11:46:57 --> Model Class Initialized
INFO - 2017-03-06 11:46:57 --> Controller Class Initialized
DEBUG - 2017-03-06 11:46:57 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:46:57 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:46:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:46:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:47:00 --> Config Class Initialized
INFO - 2017-03-06 11:47:00 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:47:00 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:47:00 --> Utf8 Class Initialized
INFO - 2017-03-06 11:47:00 --> URI Class Initialized
INFO - 2017-03-06 11:47:00 --> Router Class Initialized
INFO - 2017-03-06 11:47:00 --> Output Class Initialized
INFO - 2017-03-06 11:47:00 --> Security Class Initialized
DEBUG - 2017-03-06 11:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:47:00 --> Input Class Initialized
INFO - 2017-03-06 11:47:00 --> Language Class Initialized
INFO - 2017-03-06 11:47:00 --> Language Class Initialized
INFO - 2017-03-06 11:47:00 --> Config Class Initialized
INFO - 2017-03-06 11:47:00 --> Loader Class Initialized
INFO - 2017-03-06 11:47:00 --> Helper loaded: form_helper
INFO - 2017-03-06 11:47:00 --> Helper loaded: url_helper
INFO - 2017-03-06 11:47:00 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:47:00 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:47:00 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:47:00 --> Template Class Initialized
INFO - 2017-03-06 11:47:00 --> Model Class Initialized
INFO - 2017-03-06 11:47:00 --> Controller Class Initialized
DEBUG - 2017-03-06 11:47:00 --> Setting MX_Controller Initialized
INFO - 2017-03-06 11:47:00 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:47:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:47:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:47:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:47:00 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/payment_details.php
DEBUG - 2017-03-06 11:47:00 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:47:00 --> Final output sent to browser
DEBUG - 2017-03-06 11:47:00 --> Total execution time: 0.0320
INFO - 2017-03-06 11:47:01 --> Config Class Initialized
INFO - 2017-03-06 11:47:01 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:47:01 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:47:01 --> Utf8 Class Initialized
INFO - 2017-03-06 11:47:01 --> URI Class Initialized
INFO - 2017-03-06 11:47:01 --> Router Class Initialized
INFO - 2017-03-06 11:47:01 --> Output Class Initialized
INFO - 2017-03-06 11:47:01 --> Security Class Initialized
DEBUG - 2017-03-06 11:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:47:01 --> Input Class Initialized
INFO - 2017-03-06 11:47:01 --> Language Class Initialized
INFO - 2017-03-06 11:47:01 --> Language Class Initialized
INFO - 2017-03-06 11:47:01 --> Config Class Initialized
INFO - 2017-03-06 11:47:01 --> Loader Class Initialized
INFO - 2017-03-06 11:47:01 --> Helper loaded: form_helper
INFO - 2017-03-06 11:47:01 --> Helper loaded: url_helper
INFO - 2017-03-06 11:47:01 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:47:01 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:47:01 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:47:01 --> Template Class Initialized
INFO - 2017-03-06 11:47:01 --> Model Class Initialized
INFO - 2017-03-06 11:47:01 --> Controller Class Initialized
DEBUG - 2017-03-06 11:47:01 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:47:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:47:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:47:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:47:05 --> Config Class Initialized
INFO - 2017-03-06 11:47:05 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:47:05 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:47:05 --> Utf8 Class Initialized
INFO - 2017-03-06 11:47:05 --> URI Class Initialized
INFO - 2017-03-06 11:47:05 --> Router Class Initialized
INFO - 2017-03-06 11:47:05 --> Output Class Initialized
INFO - 2017-03-06 11:47:05 --> Security Class Initialized
DEBUG - 2017-03-06 11:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:47:05 --> Input Class Initialized
INFO - 2017-03-06 11:47:05 --> Language Class Initialized
INFO - 2017-03-06 11:47:05 --> Language Class Initialized
INFO - 2017-03-06 11:47:05 --> Config Class Initialized
INFO - 2017-03-06 11:47:05 --> Loader Class Initialized
INFO - 2017-03-06 11:47:05 --> Helper loaded: form_helper
INFO - 2017-03-06 11:47:05 --> Helper loaded: url_helper
INFO - 2017-03-06 11:47:05 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:47:05 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:47:05 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:47:05 --> Template Class Initialized
INFO - 2017-03-06 11:47:05 --> Model Class Initialized
INFO - 2017-03-06 11:47:05 --> Controller Class Initialized
DEBUG - 2017-03-06 11:47:05 --> Store MX_Controller Initialized
INFO - 2017-03-06 11:47:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:47:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:47:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:47:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:47:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/product_list.php
DEBUG - 2017-03-06 11:47:05 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:47:05 --> Final output sent to browser
DEBUG - 2017-03-06 11:47:05 --> Total execution time: 0.0274
INFO - 2017-03-06 11:47:06 --> Config Class Initialized
INFO - 2017-03-06 11:47:06 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:47:06 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:47:06 --> Utf8 Class Initialized
INFO - 2017-03-06 11:47:06 --> URI Class Initialized
INFO - 2017-03-06 11:47:06 --> Router Class Initialized
INFO - 2017-03-06 11:47:06 --> Output Class Initialized
INFO - 2017-03-06 11:47:06 --> Security Class Initialized
DEBUG - 2017-03-06 11:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:47:06 --> Input Class Initialized
INFO - 2017-03-06 11:47:06 --> Language Class Initialized
INFO - 2017-03-06 11:47:06 --> Language Class Initialized
INFO - 2017-03-06 11:47:06 --> Config Class Initialized
INFO - 2017-03-06 11:47:06 --> Loader Class Initialized
INFO - 2017-03-06 11:47:06 --> Helper loaded: form_helper
INFO - 2017-03-06 11:47:06 --> Helper loaded: url_helper
INFO - 2017-03-06 11:47:06 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:47:06 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:47:06 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:47:06 --> Template Class Initialized
INFO - 2017-03-06 11:47:06 --> Model Class Initialized
INFO - 2017-03-06 11:47:06 --> Controller Class Initialized
DEBUG - 2017-03-06 11:47:06 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:47:06 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:47:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:47:06 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:47:09 --> Config Class Initialized
INFO - 2017-03-06 11:47:09 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:47:09 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:47:09 --> Utf8 Class Initialized
INFO - 2017-03-06 11:47:09 --> URI Class Initialized
INFO - 2017-03-06 11:47:09 --> Router Class Initialized
INFO - 2017-03-06 11:47:09 --> Output Class Initialized
INFO - 2017-03-06 11:47:09 --> Security Class Initialized
DEBUG - 2017-03-06 11:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:47:09 --> Input Class Initialized
INFO - 2017-03-06 11:47:09 --> Language Class Initialized
INFO - 2017-03-06 11:47:09 --> Language Class Initialized
INFO - 2017-03-06 11:47:09 --> Config Class Initialized
INFO - 2017-03-06 11:47:09 --> Loader Class Initialized
INFO - 2017-03-06 11:47:09 --> Helper loaded: form_helper
INFO - 2017-03-06 11:47:09 --> Helper loaded: url_helper
INFO - 2017-03-06 11:47:09 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:47:09 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:47:09 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:47:09 --> Template Class Initialized
INFO - 2017-03-06 11:47:09 --> Model Class Initialized
INFO - 2017-03-06 11:47:09 --> Controller Class Initialized
DEBUG - 2017-03-06 11:47:09 --> Store MX_Controller Initialized
INFO - 2017-03-06 11:47:09 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:47:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:47:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:47:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:47:09 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/pending_orders.php
DEBUG - 2017-03-06 11:47:09 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:47:09 --> Final output sent to browser
DEBUG - 2017-03-06 11:47:09 --> Total execution time: 0.0236
INFO - 2017-03-06 11:47:10 --> Config Class Initialized
INFO - 2017-03-06 11:47:10 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:47:10 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:47:10 --> Utf8 Class Initialized
INFO - 2017-03-06 11:47:10 --> URI Class Initialized
INFO - 2017-03-06 11:47:10 --> Router Class Initialized
INFO - 2017-03-06 11:47:10 --> Output Class Initialized
INFO - 2017-03-06 11:47:10 --> Security Class Initialized
DEBUG - 2017-03-06 11:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:47:10 --> Input Class Initialized
INFO - 2017-03-06 11:47:10 --> Language Class Initialized
INFO - 2017-03-06 11:47:10 --> Language Class Initialized
INFO - 2017-03-06 11:47:10 --> Config Class Initialized
INFO - 2017-03-06 11:47:10 --> Loader Class Initialized
INFO - 2017-03-06 11:47:10 --> Helper loaded: form_helper
INFO - 2017-03-06 11:47:10 --> Helper loaded: url_helper
INFO - 2017-03-06 11:47:10 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:47:10 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:47:10 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:47:10 --> Template Class Initialized
INFO - 2017-03-06 11:47:10 --> Model Class Initialized
INFO - 2017-03-06 11:47:10 --> Controller Class Initialized
DEBUG - 2017-03-06 11:47:10 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:47:10 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:47:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:47:10 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:47:22 --> Config Class Initialized
INFO - 2017-03-06 11:47:22 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:47:22 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:47:22 --> Utf8 Class Initialized
INFO - 2017-03-06 11:47:22 --> URI Class Initialized
INFO - 2017-03-06 11:47:22 --> Router Class Initialized
INFO - 2017-03-06 11:47:22 --> Output Class Initialized
INFO - 2017-03-06 11:47:22 --> Security Class Initialized
DEBUG - 2017-03-06 11:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:47:22 --> Input Class Initialized
INFO - 2017-03-06 11:47:22 --> Language Class Initialized
INFO - 2017-03-06 11:47:22 --> Language Class Initialized
INFO - 2017-03-06 11:47:22 --> Config Class Initialized
INFO - 2017-03-06 11:47:22 --> Loader Class Initialized
INFO - 2017-03-06 11:47:22 --> Helper loaded: form_helper
INFO - 2017-03-06 11:47:22 --> Helper loaded: url_helper
INFO - 2017-03-06 11:47:22 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:47:22 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:47:22 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:47:22 --> Template Class Initialized
INFO - 2017-03-06 11:47:22 --> Model Class Initialized
INFO - 2017-03-06 11:47:22 --> Controller Class Initialized
DEBUG - 2017-03-06 11:47:22 --> Download_data MX_Controller Initialized
INFO - 2017-03-06 11:47:22 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:47:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:47:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:47:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:47:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/download_data.php
DEBUG - 2017-03-06 11:47:22 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:47:22 --> Final output sent to browser
DEBUG - 2017-03-06 11:47:22 --> Total execution time: 0.0356
INFO - 2017-03-06 11:47:22 --> Config Class Initialized
INFO - 2017-03-06 11:47:22 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:47:22 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:47:22 --> Utf8 Class Initialized
INFO - 2017-03-06 11:47:22 --> URI Class Initialized
INFO - 2017-03-06 11:47:22 --> Router Class Initialized
INFO - 2017-03-06 11:47:22 --> Output Class Initialized
INFO - 2017-03-06 11:47:22 --> Security Class Initialized
DEBUG - 2017-03-06 11:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:47:22 --> Input Class Initialized
INFO - 2017-03-06 11:47:22 --> Language Class Initialized
INFO - 2017-03-06 11:47:22 --> Language Class Initialized
INFO - 2017-03-06 11:47:22 --> Config Class Initialized
INFO - 2017-03-06 11:47:22 --> Loader Class Initialized
INFO - 2017-03-06 11:47:22 --> Helper loaded: form_helper
INFO - 2017-03-06 11:47:22 --> Helper loaded: url_helper
INFO - 2017-03-06 11:47:22 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:47:22 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:47:22 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:47:22 --> Template Class Initialized
INFO - 2017-03-06 11:47:22 --> Model Class Initialized
INFO - 2017-03-06 11:47:22 --> Controller Class Initialized
DEBUG - 2017-03-06 11:47:22 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:47:22 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:47:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:47:22 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:47:23 --> Config Class Initialized
INFO - 2017-03-06 11:47:23 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:47:23 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:47:23 --> Utf8 Class Initialized
INFO - 2017-03-06 11:47:23 --> URI Class Initialized
INFO - 2017-03-06 11:47:23 --> Router Class Initialized
INFO - 2017-03-06 11:47:23 --> Output Class Initialized
INFO - 2017-03-06 11:47:23 --> Security Class Initialized
DEBUG - 2017-03-06 11:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:47:23 --> Input Class Initialized
INFO - 2017-03-06 11:47:23 --> Language Class Initialized
INFO - 2017-03-06 11:47:23 --> Language Class Initialized
INFO - 2017-03-06 11:47:23 --> Config Class Initialized
INFO - 2017-03-06 11:47:23 --> Loader Class Initialized
INFO - 2017-03-06 11:47:23 --> Helper loaded: form_helper
INFO - 2017-03-06 11:47:23 --> Helper loaded: url_helper
INFO - 2017-03-06 11:47:23 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:47:23 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:47:23 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:47:23 --> Template Class Initialized
INFO - 2017-03-06 11:47:23 --> Model Class Initialized
INFO - 2017-03-06 11:47:23 --> Controller Class Initialized
DEBUG - 2017-03-06 11:47:23 --> Download_data MX_Controller Initialized
INFO - 2017-03-06 11:47:23 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:47:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:47:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:47:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:47:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/download_data.php
DEBUG - 2017-03-06 11:47:23 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:47:23 --> Final output sent to browser
DEBUG - 2017-03-06 11:47:23 --> Total execution time: 0.0181
INFO - 2017-03-06 11:47:23 --> Config Class Initialized
INFO - 2017-03-06 11:47:23 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:47:23 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:47:23 --> Utf8 Class Initialized
INFO - 2017-03-06 11:47:23 --> URI Class Initialized
INFO - 2017-03-06 11:47:23 --> Router Class Initialized
INFO - 2017-03-06 11:47:23 --> Output Class Initialized
INFO - 2017-03-06 11:47:24 --> Security Class Initialized
DEBUG - 2017-03-06 11:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:47:24 --> Input Class Initialized
INFO - 2017-03-06 11:47:24 --> Language Class Initialized
INFO - 2017-03-06 11:47:24 --> Language Class Initialized
INFO - 2017-03-06 11:47:24 --> Config Class Initialized
INFO - 2017-03-06 11:47:24 --> Loader Class Initialized
INFO - 2017-03-06 11:47:24 --> Helper loaded: form_helper
INFO - 2017-03-06 11:47:24 --> Helper loaded: url_helper
INFO - 2017-03-06 11:47:24 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:47:24 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:47:24 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:47:24 --> Template Class Initialized
INFO - 2017-03-06 11:47:24 --> Model Class Initialized
INFO - 2017-03-06 11:47:24 --> Controller Class Initialized
DEBUG - 2017-03-06 11:47:24 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:47:24 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:47:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:47:24 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:48:27 --> Config Class Initialized
INFO - 2017-03-06 11:48:27 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:48:27 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:48:27 --> Utf8 Class Initialized
INFO - 2017-03-06 11:48:27 --> URI Class Initialized
INFO - 2017-03-06 11:48:27 --> Router Class Initialized
INFO - 2017-03-06 11:48:27 --> Output Class Initialized
INFO - 2017-03-06 11:48:27 --> Security Class Initialized
DEBUG - 2017-03-06 11:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:48:27 --> Input Class Initialized
INFO - 2017-03-06 11:48:27 --> Language Class Initialized
INFO - 2017-03-06 11:48:27 --> Language Class Initialized
INFO - 2017-03-06 11:48:27 --> Config Class Initialized
INFO - 2017-03-06 11:48:27 --> Loader Class Initialized
INFO - 2017-03-06 11:48:27 --> Helper loaded: form_helper
INFO - 2017-03-06 11:48:27 --> Helper loaded: url_helper
INFO - 2017-03-06 11:48:27 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:48:27 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:48:27 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:48:27 --> Template Class Initialized
INFO - 2017-03-06 11:48:27 --> Model Class Initialized
INFO - 2017-03-06 11:48:27 --> Controller Class Initialized
DEBUG - 2017-03-06 11:48:27 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:48:27 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:48:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:48:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:48:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:48:27 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-06 11:48:27 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:48:27 --> Final output sent to browser
DEBUG - 2017-03-06 11:48:27 --> Total execution time: 0.0212
INFO - 2017-03-06 11:48:29 --> Config Class Initialized
INFO - 2017-03-06 11:48:29 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:48:29 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:48:29 --> Utf8 Class Initialized
INFO - 2017-03-06 11:48:29 --> URI Class Initialized
INFO - 2017-03-06 11:48:29 --> Router Class Initialized
INFO - 2017-03-06 11:48:29 --> Output Class Initialized
INFO - 2017-03-06 11:48:29 --> Security Class Initialized
DEBUG - 2017-03-06 11:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:48:29 --> Input Class Initialized
INFO - 2017-03-06 11:48:29 --> Language Class Initialized
INFO - 2017-03-06 11:48:29 --> Language Class Initialized
INFO - 2017-03-06 11:48:29 --> Config Class Initialized
INFO - 2017-03-06 11:48:29 --> Loader Class Initialized
INFO - 2017-03-06 11:48:29 --> Helper loaded: form_helper
INFO - 2017-03-06 11:48:29 --> Helper loaded: url_helper
INFO - 2017-03-06 11:48:29 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:48:29 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:48:29 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:48:29 --> Template Class Initialized
INFO - 2017-03-06 11:48:29 --> Model Class Initialized
INFO - 2017-03-06 11:48:29 --> Controller Class Initialized
DEBUG - 2017-03-06 11:48:29 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:48:29 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:48:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:48:29 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:48:37 --> Config Class Initialized
INFO - 2017-03-06 11:48:37 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:48:37 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:48:37 --> Utf8 Class Initialized
INFO - 2017-03-06 11:48:37 --> URI Class Initialized
INFO - 2017-03-06 11:48:37 --> Router Class Initialized
INFO - 2017-03-06 11:48:37 --> Output Class Initialized
INFO - 2017-03-06 11:48:37 --> Security Class Initialized
DEBUG - 2017-03-06 11:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:48:37 --> Input Class Initialized
INFO - 2017-03-06 11:48:37 --> Language Class Initialized
INFO - 2017-03-06 11:48:37 --> Language Class Initialized
INFO - 2017-03-06 11:48:37 --> Config Class Initialized
INFO - 2017-03-06 11:48:37 --> Loader Class Initialized
INFO - 2017-03-06 11:48:37 --> Helper loaded: form_helper
INFO - 2017-03-06 11:48:37 --> Helper loaded: url_helper
INFO - 2017-03-06 11:48:37 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:48:37 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:48:37 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:48:37 --> Template Class Initialized
INFO - 2017-03-06 11:48:37 --> Model Class Initialized
INFO - 2017-03-06 11:48:37 --> Controller Class Initialized
DEBUG - 2017-03-06 11:48:37 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:48:37 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:48:37 --> Model Class Initialized
INFO - 2017-03-06 11:48:37 --> Config Class Initialized
INFO - 2017-03-06 11:48:37 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:48:37 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:48:37 --> Utf8 Class Initialized
INFO - 2017-03-06 11:48:37 --> URI Class Initialized
INFO - 2017-03-06 11:48:37 --> Router Class Initialized
INFO - 2017-03-06 11:48:37 --> Output Class Initialized
INFO - 2017-03-06 11:48:37 --> Security Class Initialized
DEBUG - 2017-03-06 11:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:48:37 --> Input Class Initialized
INFO - 2017-03-06 11:48:37 --> Language Class Initialized
INFO - 2017-03-06 11:48:37 --> Language Class Initialized
INFO - 2017-03-06 11:48:37 --> Config Class Initialized
INFO - 2017-03-06 11:48:37 --> Loader Class Initialized
INFO - 2017-03-06 11:48:37 --> Helper loaded: form_helper
INFO - 2017-03-06 11:48:37 --> Helper loaded: url_helper
INFO - 2017-03-06 11:48:37 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:48:37 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:48:37 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:48:37 --> Template Class Initialized
INFO - 2017-03-06 11:48:37 --> Model Class Initialized
INFO - 2017-03-06 11:48:37 --> Controller Class Initialized
DEBUG - 2017-03-06 11:48:37 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:48:37 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:48:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:48:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:48:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:48:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_project.php
DEBUG - 2017-03-06 11:48:37 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:48:37 --> Final output sent to browser
DEBUG - 2017-03-06 11:48:37 --> Total execution time: 0.0184
INFO - 2017-03-06 11:48:38 --> Config Class Initialized
INFO - 2017-03-06 11:48:38 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:48:38 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:48:38 --> Utf8 Class Initialized
INFO - 2017-03-06 11:48:38 --> URI Class Initialized
INFO - 2017-03-06 11:48:38 --> Router Class Initialized
INFO - 2017-03-06 11:48:38 --> Output Class Initialized
INFO - 2017-03-06 11:48:38 --> Security Class Initialized
DEBUG - 2017-03-06 11:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:48:38 --> Input Class Initialized
INFO - 2017-03-06 11:48:38 --> Language Class Initialized
INFO - 2017-03-06 11:48:38 --> Language Class Initialized
INFO - 2017-03-06 11:48:38 --> Config Class Initialized
INFO - 2017-03-06 11:48:38 --> Loader Class Initialized
INFO - 2017-03-06 11:48:38 --> Helper loaded: form_helper
INFO - 2017-03-06 11:48:38 --> Helper loaded: url_helper
INFO - 2017-03-06 11:48:38 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:48:38 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:48:38 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:48:38 --> Template Class Initialized
INFO - 2017-03-06 11:48:38 --> Model Class Initialized
INFO - 2017-03-06 11:48:38 --> Controller Class Initialized
DEBUG - 2017-03-06 11:48:38 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:48:38 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:48:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:48:38 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:48:43 --> Config Class Initialized
INFO - 2017-03-06 11:48:43 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:48:43 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:48:43 --> Utf8 Class Initialized
INFO - 2017-03-06 11:48:43 --> URI Class Initialized
INFO - 2017-03-06 11:48:43 --> Router Class Initialized
INFO - 2017-03-06 11:48:43 --> Output Class Initialized
INFO - 2017-03-06 11:48:43 --> Security Class Initialized
DEBUG - 2017-03-06 11:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:48:43 --> Input Class Initialized
INFO - 2017-03-06 11:48:43 --> Language Class Initialized
INFO - 2017-03-06 11:48:43 --> Language Class Initialized
INFO - 2017-03-06 11:48:43 --> Config Class Initialized
INFO - 2017-03-06 11:48:43 --> Loader Class Initialized
INFO - 2017-03-06 11:48:43 --> Helper loaded: form_helper
INFO - 2017-03-06 11:48:43 --> Helper loaded: url_helper
INFO - 2017-03-06 11:48:43 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:48:43 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:48:43 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:48:43 --> Template Class Initialized
INFO - 2017-03-06 11:48:43 --> Model Class Initialized
INFO - 2017-03-06 11:48:43 --> Controller Class Initialized
DEBUG - 2017-03-06 11:48:43 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:48:43 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:48:43 --> Model Class Initialized
DEBUG - 2017-03-06 11:48:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:48:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:48:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:48:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-06 11:48:43 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:48:43 --> Final output sent to browser
DEBUG - 2017-03-06 11:48:43 --> Total execution time: 0.0301
INFO - 2017-03-06 11:48:43 --> Config Class Initialized
INFO - 2017-03-06 11:48:43 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:48:43 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:48:43 --> Utf8 Class Initialized
INFO - 2017-03-06 11:48:43 --> URI Class Initialized
INFO - 2017-03-06 11:48:43 --> Router Class Initialized
INFO - 2017-03-06 11:48:43 --> Output Class Initialized
INFO - 2017-03-06 11:48:43 --> Security Class Initialized
DEBUG - 2017-03-06 11:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:48:43 --> Input Class Initialized
INFO - 2017-03-06 11:48:43 --> Language Class Initialized
INFO - 2017-03-06 11:48:43 --> Language Class Initialized
INFO - 2017-03-06 11:48:43 --> Config Class Initialized
INFO - 2017-03-06 11:48:43 --> Loader Class Initialized
INFO - 2017-03-06 11:48:43 --> Helper loaded: form_helper
INFO - 2017-03-06 11:48:43 --> Helper loaded: url_helper
INFO - 2017-03-06 11:48:43 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:48:43 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:48:43 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:48:43 --> Template Class Initialized
INFO - 2017-03-06 11:48:43 --> Model Class Initialized
INFO - 2017-03-06 11:48:43 --> Controller Class Initialized
DEBUG - 2017-03-06 11:48:43 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:48:43 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:48:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:48:43 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:48:48 --> Config Class Initialized
INFO - 2017-03-06 11:48:48 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:48:48 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:48:48 --> Utf8 Class Initialized
INFO - 2017-03-06 11:48:48 --> URI Class Initialized
INFO - 2017-03-06 11:48:48 --> Router Class Initialized
INFO - 2017-03-06 11:48:48 --> Output Class Initialized
INFO - 2017-03-06 11:48:48 --> Security Class Initialized
DEBUG - 2017-03-06 11:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:48:48 --> Input Class Initialized
INFO - 2017-03-06 11:48:48 --> Language Class Initialized
INFO - 2017-03-06 11:48:48 --> Language Class Initialized
INFO - 2017-03-06 11:48:48 --> Config Class Initialized
INFO - 2017-03-06 11:48:48 --> Loader Class Initialized
INFO - 2017-03-06 11:48:48 --> Helper loaded: form_helper
INFO - 2017-03-06 11:48:48 --> Helper loaded: url_helper
INFO - 2017-03-06 11:48:48 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:48:48 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:48:48 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:48:48 --> Template Class Initialized
INFO - 2017-03-06 11:48:48 --> Model Class Initialized
INFO - 2017-03-06 11:48:48 --> Controller Class Initialized
DEBUG - 2017-03-06 11:48:48 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:48:48 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:48:48 --> Final output sent to browser
DEBUG - 2017-03-06 11:48:48 --> Total execution time: 0.0150
INFO - 2017-03-06 11:49:00 --> Config Class Initialized
INFO - 2017-03-06 11:49:00 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:49:00 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:49:00 --> Utf8 Class Initialized
INFO - 2017-03-06 11:49:00 --> URI Class Initialized
INFO - 2017-03-06 11:49:00 --> Router Class Initialized
INFO - 2017-03-06 11:49:00 --> Output Class Initialized
INFO - 2017-03-06 11:49:00 --> Security Class Initialized
DEBUG - 2017-03-06 11:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:49:00 --> Input Class Initialized
INFO - 2017-03-06 11:49:00 --> Language Class Initialized
INFO - 2017-03-06 11:49:00 --> Language Class Initialized
INFO - 2017-03-06 11:49:00 --> Config Class Initialized
INFO - 2017-03-06 11:49:00 --> Loader Class Initialized
INFO - 2017-03-06 11:49:00 --> Helper loaded: form_helper
INFO - 2017-03-06 11:49:00 --> Helper loaded: url_helper
INFO - 2017-03-06 11:49:00 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:49:00 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:49:00 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:49:00 --> Template Class Initialized
INFO - 2017-03-06 11:49:00 --> Model Class Initialized
INFO - 2017-03-06 11:49:00 --> Controller Class Initialized
DEBUG - 2017-03-06 11:49:00 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:49:00 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:49:00 --> Upload Class Initialized
INFO - 2017-03-06 11:49:00 --> Language file loaded: language/english/upload_lang.php
ERROR - 2017-03-06 11:49:00 --> The upload path does not appear to be valid.
INFO - 2017-03-06 11:49:00 --> Model Class Initialized
INFO - 2017-03-06 11:49:00 --> Final output sent to browser
DEBUG - 2017-03-06 11:49:00 --> Total execution time: 0.0633
INFO - 2017-03-06 11:49:13 --> Config Class Initialized
INFO - 2017-03-06 11:49:13 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:49:13 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:49:13 --> Utf8 Class Initialized
INFO - 2017-03-06 11:49:13 --> URI Class Initialized
INFO - 2017-03-06 11:49:13 --> Router Class Initialized
INFO - 2017-03-06 11:49:13 --> Output Class Initialized
INFO - 2017-03-06 11:49:13 --> Security Class Initialized
DEBUG - 2017-03-06 11:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:49:13 --> Input Class Initialized
INFO - 2017-03-06 11:49:13 --> Language Class Initialized
INFO - 2017-03-06 11:49:13 --> Language Class Initialized
INFO - 2017-03-06 11:49:13 --> Config Class Initialized
INFO - 2017-03-06 11:49:13 --> Loader Class Initialized
INFO - 2017-03-06 11:49:13 --> Helper loaded: form_helper
INFO - 2017-03-06 11:49:13 --> Helper loaded: url_helper
INFO - 2017-03-06 11:49:13 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:49:13 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:49:13 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:49:13 --> Template Class Initialized
INFO - 2017-03-06 11:49:13 --> Model Class Initialized
INFO - 2017-03-06 11:49:13 --> Controller Class Initialized
DEBUG - 2017-03-06 11:49:13 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:49:13 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:49:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:49:13 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:49:23 --> Config Class Initialized
INFO - 2017-03-06 11:49:23 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:49:23 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:49:23 --> Utf8 Class Initialized
INFO - 2017-03-06 11:49:23 --> URI Class Initialized
INFO - 2017-03-06 11:49:23 --> Router Class Initialized
INFO - 2017-03-06 11:49:23 --> Output Class Initialized
INFO - 2017-03-06 11:49:23 --> Security Class Initialized
DEBUG - 2017-03-06 11:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:49:23 --> Input Class Initialized
INFO - 2017-03-06 11:49:23 --> Language Class Initialized
INFO - 2017-03-06 11:49:23 --> Language Class Initialized
INFO - 2017-03-06 11:49:23 --> Config Class Initialized
INFO - 2017-03-06 11:49:23 --> Loader Class Initialized
INFO - 2017-03-06 11:49:23 --> Helper loaded: form_helper
INFO - 2017-03-06 11:49:23 --> Helper loaded: url_helper
INFO - 2017-03-06 11:49:23 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:49:23 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:49:23 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:49:23 --> Template Class Initialized
INFO - 2017-03-06 11:49:23 --> Model Class Initialized
INFO - 2017-03-06 11:49:23 --> Controller Class Initialized
DEBUG - 2017-03-06 11:49:23 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:49:23 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:49:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:49:23 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:49:28 --> Config Class Initialized
INFO - 2017-03-06 11:49:28 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:49:28 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:49:28 --> Utf8 Class Initialized
INFO - 2017-03-06 11:49:28 --> URI Class Initialized
INFO - 2017-03-06 11:49:28 --> Router Class Initialized
INFO - 2017-03-06 11:49:28 --> Output Class Initialized
INFO - 2017-03-06 11:49:28 --> Security Class Initialized
DEBUG - 2017-03-06 11:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:49:28 --> Input Class Initialized
INFO - 2017-03-06 11:49:28 --> Language Class Initialized
INFO - 2017-03-06 11:49:28 --> Language Class Initialized
INFO - 2017-03-06 11:49:28 --> Config Class Initialized
INFO - 2017-03-06 11:49:28 --> Loader Class Initialized
INFO - 2017-03-06 11:49:28 --> Helper loaded: form_helper
INFO - 2017-03-06 11:49:28 --> Helper loaded: url_helper
INFO - 2017-03-06 11:49:28 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:49:28 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:49:28 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:49:28 --> Template Class Initialized
INFO - 2017-03-06 11:49:28 --> Model Class Initialized
INFO - 2017-03-06 11:49:28 --> Controller Class Initialized
DEBUG - 2017-03-06 11:49:28 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:49:28 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:49:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:49:28 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:49:33 --> Config Class Initialized
INFO - 2017-03-06 11:49:33 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:49:33 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:49:33 --> Utf8 Class Initialized
INFO - 2017-03-06 11:49:33 --> URI Class Initialized
INFO - 2017-03-06 11:49:33 --> Router Class Initialized
INFO - 2017-03-06 11:49:33 --> Output Class Initialized
INFO - 2017-03-06 11:49:33 --> Security Class Initialized
DEBUG - 2017-03-06 11:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:49:33 --> Input Class Initialized
INFO - 2017-03-06 11:49:33 --> Language Class Initialized
INFO - 2017-03-06 11:49:33 --> Language Class Initialized
INFO - 2017-03-06 11:49:33 --> Config Class Initialized
INFO - 2017-03-06 11:49:33 --> Loader Class Initialized
INFO - 2017-03-06 11:49:33 --> Helper loaded: form_helper
INFO - 2017-03-06 11:49:33 --> Helper loaded: url_helper
INFO - 2017-03-06 11:49:33 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:49:33 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:49:33 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:49:33 --> Template Class Initialized
INFO - 2017-03-06 11:49:33 --> Model Class Initialized
INFO - 2017-03-06 11:49:33 --> Controller Class Initialized
DEBUG - 2017-03-06 11:49:33 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:49:33 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:49:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:49:33 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:49:36 --> Config Class Initialized
INFO - 2017-03-06 11:49:36 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:49:36 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:49:36 --> Utf8 Class Initialized
INFO - 2017-03-06 11:49:36 --> URI Class Initialized
INFO - 2017-03-06 11:49:36 --> Router Class Initialized
INFO - 2017-03-06 11:49:36 --> Output Class Initialized
INFO - 2017-03-06 11:49:36 --> Security Class Initialized
DEBUG - 2017-03-06 11:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:49:36 --> Input Class Initialized
INFO - 2017-03-06 11:49:36 --> Language Class Initialized
INFO - 2017-03-06 11:49:36 --> Language Class Initialized
INFO - 2017-03-06 11:49:36 --> Config Class Initialized
INFO - 2017-03-06 11:49:36 --> Loader Class Initialized
INFO - 2017-03-06 11:49:36 --> Helper loaded: form_helper
INFO - 2017-03-06 11:49:36 --> Helper loaded: url_helper
INFO - 2017-03-06 11:49:36 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:49:36 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:49:36 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:49:36 --> Template Class Initialized
INFO - 2017-03-06 11:49:36 --> Model Class Initialized
INFO - 2017-03-06 11:49:36 --> Controller Class Initialized
DEBUG - 2017-03-06 11:49:36 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:49:36 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:49:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:49:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:49:39 --> Config Class Initialized
INFO - 2017-03-06 11:49:39 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:49:39 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:49:39 --> Utf8 Class Initialized
INFO - 2017-03-06 11:49:39 --> URI Class Initialized
INFO - 2017-03-06 11:49:39 --> Router Class Initialized
INFO - 2017-03-06 11:49:39 --> Output Class Initialized
INFO - 2017-03-06 11:49:39 --> Security Class Initialized
DEBUG - 2017-03-06 11:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:49:39 --> Input Class Initialized
INFO - 2017-03-06 11:49:39 --> Language Class Initialized
INFO - 2017-03-06 11:49:39 --> Language Class Initialized
INFO - 2017-03-06 11:49:39 --> Config Class Initialized
INFO - 2017-03-06 11:49:39 --> Loader Class Initialized
INFO - 2017-03-06 11:49:39 --> Helper loaded: form_helper
INFO - 2017-03-06 11:49:39 --> Helper loaded: url_helper
INFO - 2017-03-06 11:49:39 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:49:39 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:49:39 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:49:39 --> Template Class Initialized
INFO - 2017-03-06 11:49:39 --> Model Class Initialized
INFO - 2017-03-06 11:49:39 --> Controller Class Initialized
DEBUG - 2017-03-06 11:49:39 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:49:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:49:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:49:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:49:42 --> Config Class Initialized
INFO - 2017-03-06 11:49:42 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:49:42 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:49:42 --> Utf8 Class Initialized
INFO - 2017-03-06 11:49:42 --> URI Class Initialized
INFO - 2017-03-06 11:49:42 --> Router Class Initialized
INFO - 2017-03-06 11:49:42 --> Output Class Initialized
INFO - 2017-03-06 11:49:42 --> Security Class Initialized
DEBUG - 2017-03-06 11:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:49:42 --> Input Class Initialized
INFO - 2017-03-06 11:49:42 --> Language Class Initialized
INFO - 2017-03-06 11:49:42 --> Language Class Initialized
INFO - 2017-03-06 11:49:42 --> Config Class Initialized
INFO - 2017-03-06 11:49:42 --> Loader Class Initialized
INFO - 2017-03-06 11:49:42 --> Helper loaded: form_helper
INFO - 2017-03-06 11:49:42 --> Helper loaded: url_helper
INFO - 2017-03-06 11:49:42 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:49:42 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:49:42 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:49:42 --> Template Class Initialized
INFO - 2017-03-06 11:49:42 --> Model Class Initialized
INFO - 2017-03-06 11:49:42 --> Controller Class Initialized
DEBUG - 2017-03-06 11:49:42 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:49:42 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:49:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:49:42 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:49:50 --> Config Class Initialized
INFO - 2017-03-06 11:49:50 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:49:50 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:49:50 --> Utf8 Class Initialized
INFO - 2017-03-06 11:49:50 --> URI Class Initialized
INFO - 2017-03-06 11:49:50 --> Router Class Initialized
INFO - 2017-03-06 11:49:50 --> Output Class Initialized
INFO - 2017-03-06 11:49:50 --> Security Class Initialized
DEBUG - 2017-03-06 11:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:49:50 --> Input Class Initialized
INFO - 2017-03-06 11:49:50 --> Language Class Initialized
INFO - 2017-03-06 11:49:50 --> Language Class Initialized
INFO - 2017-03-06 11:49:50 --> Config Class Initialized
INFO - 2017-03-06 11:49:50 --> Loader Class Initialized
INFO - 2017-03-06 11:49:50 --> Helper loaded: form_helper
INFO - 2017-03-06 11:49:50 --> Helper loaded: url_helper
INFO - 2017-03-06 11:49:50 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:49:50 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:49:50 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:49:50 --> Template Class Initialized
INFO - 2017-03-06 11:49:50 --> Model Class Initialized
INFO - 2017-03-06 11:49:50 --> Controller Class Initialized
DEBUG - 2017-03-06 11:49:50 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:49:50 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:49:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:49:50 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:49:51 --> Config Class Initialized
INFO - 2017-03-06 11:49:51 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:49:51 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:49:51 --> Utf8 Class Initialized
INFO - 2017-03-06 11:49:51 --> URI Class Initialized
INFO - 2017-03-06 11:49:51 --> Router Class Initialized
INFO - 2017-03-06 11:49:51 --> Output Class Initialized
INFO - 2017-03-06 11:49:51 --> Security Class Initialized
DEBUG - 2017-03-06 11:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:49:51 --> Input Class Initialized
INFO - 2017-03-06 11:49:51 --> Language Class Initialized
INFO - 2017-03-06 11:49:51 --> Language Class Initialized
INFO - 2017-03-06 11:49:51 --> Config Class Initialized
INFO - 2017-03-06 11:49:51 --> Loader Class Initialized
INFO - 2017-03-06 11:49:51 --> Helper loaded: form_helper
INFO - 2017-03-06 11:49:51 --> Helper loaded: url_helper
INFO - 2017-03-06 11:49:51 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:49:51 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:49:51 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:49:51 --> Template Class Initialized
INFO - 2017-03-06 11:49:51 --> Model Class Initialized
INFO - 2017-03-06 11:49:51 --> Controller Class Initialized
DEBUG - 2017-03-06 11:49:51 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:49:51 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:49:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:49:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:49:52 --> Config Class Initialized
INFO - 2017-03-06 11:49:52 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:49:52 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:49:52 --> Utf8 Class Initialized
INFO - 2017-03-06 11:49:52 --> URI Class Initialized
INFO - 2017-03-06 11:49:52 --> Router Class Initialized
INFO - 2017-03-06 11:49:52 --> Output Class Initialized
INFO - 2017-03-06 11:49:52 --> Security Class Initialized
DEBUG - 2017-03-06 11:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:49:52 --> Input Class Initialized
INFO - 2017-03-06 11:49:52 --> Language Class Initialized
INFO - 2017-03-06 11:49:52 --> Language Class Initialized
INFO - 2017-03-06 11:49:52 --> Config Class Initialized
INFO - 2017-03-06 11:49:52 --> Loader Class Initialized
INFO - 2017-03-06 11:49:52 --> Helper loaded: form_helper
INFO - 2017-03-06 11:49:52 --> Helper loaded: url_helper
INFO - 2017-03-06 11:49:52 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:49:52 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:49:52 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:49:52 --> Template Class Initialized
INFO - 2017-03-06 11:49:52 --> Model Class Initialized
INFO - 2017-03-06 11:49:52 --> Controller Class Initialized
DEBUG - 2017-03-06 11:49:52 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:49:52 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:49:52 --> Model Class Initialized
DEBUG - 2017-03-06 11:49:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:49:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:49:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:49:52 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/upload_files.php
DEBUG - 2017-03-06 11:49:52 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:49:52 --> Final output sent to browser
DEBUG - 2017-03-06 11:49:52 --> Total execution time: 0.0145
INFO - 2017-03-06 11:49:53 --> Config Class Initialized
INFO - 2017-03-06 11:49:53 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:49:53 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:49:53 --> Utf8 Class Initialized
INFO - 2017-03-06 11:49:53 --> URI Class Initialized
INFO - 2017-03-06 11:49:53 --> Router Class Initialized
INFO - 2017-03-06 11:49:53 --> Output Class Initialized
INFO - 2017-03-06 11:49:53 --> Security Class Initialized
DEBUG - 2017-03-06 11:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:49:53 --> Input Class Initialized
INFO - 2017-03-06 11:49:53 --> Language Class Initialized
INFO - 2017-03-06 11:49:53 --> Language Class Initialized
INFO - 2017-03-06 11:49:53 --> Config Class Initialized
INFO - 2017-03-06 11:49:53 --> Loader Class Initialized
INFO - 2017-03-06 11:49:53 --> Helper loaded: form_helper
INFO - 2017-03-06 11:49:53 --> Helper loaded: url_helper
INFO - 2017-03-06 11:49:53 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:49:53 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:49:53 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:49:53 --> Template Class Initialized
INFO - 2017-03-06 11:49:53 --> Model Class Initialized
INFO - 2017-03-06 11:49:53 --> Controller Class Initialized
DEBUG - 2017-03-06 11:49:53 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:49:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:49:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:49:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:49:58 --> Config Class Initialized
INFO - 2017-03-06 11:49:58 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:49:58 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:49:58 --> Utf8 Class Initialized
INFO - 2017-03-06 11:49:58 --> URI Class Initialized
INFO - 2017-03-06 11:49:58 --> Router Class Initialized
INFO - 2017-03-06 11:49:58 --> Output Class Initialized
INFO - 2017-03-06 11:49:58 --> Security Class Initialized
DEBUG - 2017-03-06 11:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:49:58 --> Input Class Initialized
INFO - 2017-03-06 11:49:58 --> Language Class Initialized
INFO - 2017-03-06 11:49:58 --> Language Class Initialized
INFO - 2017-03-06 11:49:58 --> Config Class Initialized
INFO - 2017-03-06 11:49:58 --> Loader Class Initialized
INFO - 2017-03-06 11:49:58 --> Helper loaded: form_helper
INFO - 2017-03-06 11:49:58 --> Helper loaded: url_helper
INFO - 2017-03-06 11:49:58 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:49:58 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:49:58 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:49:58 --> Template Class Initialized
INFO - 2017-03-06 11:49:58 --> Model Class Initialized
INFO - 2017-03-06 11:49:58 --> Controller Class Initialized
DEBUG - 2017-03-06 11:49:58 --> Project MX_Controller Initialized
INFO - 2017-03-06 11:49:58 --> Helper loaded: cookie_helper
INFO - 2017-03-06 11:49:58 --> Model Class Initialized
DEBUG - 2017-03-06 11:49:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:49:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:49:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:49:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/project_list.php
DEBUG - 2017-03-06 11:49:58 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:49:58 --> Final output sent to browser
DEBUG - 2017-03-06 11:49:58 --> Total execution time: 0.0162
INFO - 2017-03-06 11:49:59 --> Config Class Initialized
INFO - 2017-03-06 11:49:59 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:49:59 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:49:59 --> Utf8 Class Initialized
INFO - 2017-03-06 11:49:59 --> URI Class Initialized
INFO - 2017-03-06 11:49:59 --> Router Class Initialized
INFO - 2017-03-06 11:49:59 --> Output Class Initialized
INFO - 2017-03-06 11:49:59 --> Security Class Initialized
DEBUG - 2017-03-06 11:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:49:59 --> Input Class Initialized
INFO - 2017-03-06 11:49:59 --> Language Class Initialized
INFO - 2017-03-06 11:49:59 --> Language Class Initialized
INFO - 2017-03-06 11:49:59 --> Config Class Initialized
INFO - 2017-03-06 11:49:59 --> Loader Class Initialized
INFO - 2017-03-06 11:49:59 --> Helper loaded: form_helper
INFO - 2017-03-06 11:49:59 --> Helper loaded: url_helper
INFO - 2017-03-06 11:49:59 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:49:59 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:49:59 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:49:59 --> Template Class Initialized
INFO - 2017-03-06 11:49:59 --> Model Class Initialized
INFO - 2017-03-06 11:49:59 --> Controller Class Initialized
DEBUG - 2017-03-06 11:49:59 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:49:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:49:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:49:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:50:56 --> Config Class Initialized
INFO - 2017-03-06 11:50:56 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:50:56 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:50:56 --> Utf8 Class Initialized
INFO - 2017-03-06 11:50:56 --> URI Class Initialized
INFO - 2017-03-06 11:50:56 --> Router Class Initialized
INFO - 2017-03-06 11:50:56 --> Output Class Initialized
INFO - 2017-03-06 11:50:56 --> Security Class Initialized
DEBUG - 2017-03-06 11:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:50:56 --> Input Class Initialized
INFO - 2017-03-06 11:50:56 --> Language Class Initialized
INFO - 2017-03-06 11:50:56 --> Language Class Initialized
INFO - 2017-03-06 11:50:56 --> Config Class Initialized
INFO - 2017-03-06 11:50:56 --> Loader Class Initialized
INFO - 2017-03-06 11:50:56 --> Helper loaded: form_helper
INFO - 2017-03-06 11:50:56 --> Helper loaded: url_helper
INFO - 2017-03-06 11:50:56 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:50:56 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:50:56 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:50:56 --> Template Class Initialized
INFO - 2017-03-06 11:50:56 --> Model Class Initialized
INFO - 2017-03-06 11:50:56 --> Controller Class Initialized
DEBUG - 2017-03-06 11:50:56 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:50:56 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:50:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:50:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-06 11:50:56 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/login.php
DEBUG - 2017-03-06 11:50:56 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-06 11:50:56 --> Final output sent to browser
DEBUG - 2017-03-06 11:50:56 --> Total execution time: 0.0161
INFO - 2017-03-06 11:51:05 --> Config Class Initialized
INFO - 2017-03-06 11:51:05 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:51:05 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:51:05 --> Utf8 Class Initialized
INFO - 2017-03-06 11:51:05 --> URI Class Initialized
INFO - 2017-03-06 11:51:05 --> Router Class Initialized
INFO - 2017-03-06 11:51:05 --> Output Class Initialized
INFO - 2017-03-06 11:51:05 --> Security Class Initialized
DEBUG - 2017-03-06 11:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:51:05 --> Input Class Initialized
INFO - 2017-03-06 11:51:05 --> Language Class Initialized
INFO - 2017-03-06 11:51:05 --> Language Class Initialized
INFO - 2017-03-06 11:51:05 --> Config Class Initialized
INFO - 2017-03-06 11:51:05 --> Loader Class Initialized
INFO - 2017-03-06 11:51:05 --> Helper loaded: form_helper
INFO - 2017-03-06 11:51:05 --> Helper loaded: url_helper
INFO - 2017-03-06 11:51:05 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:51:05 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:51:05 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:51:05 --> Template Class Initialized
INFO - 2017-03-06 11:51:05 --> Model Class Initialized
INFO - 2017-03-06 11:51:05 --> Controller Class Initialized
DEBUG - 2017-03-06 11:51:05 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:51:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:51:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:51:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:51:11 --> Config Class Initialized
INFO - 2017-03-06 11:51:11 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:51:11 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:51:11 --> Utf8 Class Initialized
INFO - 2017-03-06 11:51:11 --> URI Class Initialized
INFO - 2017-03-06 11:51:11 --> Router Class Initialized
INFO - 2017-03-06 11:51:11 --> Output Class Initialized
INFO - 2017-03-06 11:51:11 --> Security Class Initialized
DEBUG - 2017-03-06 11:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:51:11 --> Input Class Initialized
INFO - 2017-03-06 11:51:11 --> Language Class Initialized
INFO - 2017-03-06 11:51:11 --> Language Class Initialized
INFO - 2017-03-06 11:51:11 --> Config Class Initialized
INFO - 2017-03-06 11:51:11 --> Loader Class Initialized
INFO - 2017-03-06 11:51:11 --> Helper loaded: form_helper
INFO - 2017-03-06 11:51:11 --> Helper loaded: url_helper
INFO - 2017-03-06 11:51:11 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:51:11 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:51:11 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:51:11 --> Template Class Initialized
INFO - 2017-03-06 11:51:11 --> Model Class Initialized
INFO - 2017-03-06 11:51:11 --> Controller Class Initialized
DEBUG - 2017-03-06 11:51:11 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:51:11 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:51:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:51:11 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:51:51 --> Config Class Initialized
INFO - 2017-03-06 11:51:51 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:51:51 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:51:51 --> Utf8 Class Initialized
INFO - 2017-03-06 11:51:51 --> URI Class Initialized
INFO - 2017-03-06 11:51:51 --> Router Class Initialized
INFO - 2017-03-06 11:51:51 --> Output Class Initialized
INFO - 2017-03-06 11:51:51 --> Security Class Initialized
DEBUG - 2017-03-06 11:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:51:51 --> Input Class Initialized
INFO - 2017-03-06 11:51:51 --> Language Class Initialized
INFO - 2017-03-06 11:51:51 --> Language Class Initialized
INFO - 2017-03-06 11:51:51 --> Config Class Initialized
INFO - 2017-03-06 11:51:51 --> Loader Class Initialized
INFO - 2017-03-06 11:51:51 --> Helper loaded: form_helper
INFO - 2017-03-06 11:51:51 --> Helper loaded: url_helper
INFO - 2017-03-06 11:51:51 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:51:51 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:51:51 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:51:51 --> Template Class Initialized
INFO - 2017-03-06 11:51:51 --> Model Class Initialized
INFO - 2017-03-06 11:51:51 --> Controller Class Initialized
DEBUG - 2017-03-06 11:51:51 --> Subscriber MX_Controller Initialized
INFO - 2017-03-06 11:51:51 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:51:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:51:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:51:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:51:51 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/subscriber_list.php
DEBUG - 2017-03-06 11:51:51 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:51:51 --> Final output sent to browser
DEBUG - 2017-03-06 11:51:51 --> Total execution time: 0.0294
INFO - 2017-03-06 11:51:53 --> Config Class Initialized
INFO - 2017-03-06 11:51:53 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:51:53 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:51:53 --> Utf8 Class Initialized
INFO - 2017-03-06 11:51:53 --> URI Class Initialized
INFO - 2017-03-06 11:51:53 --> Router Class Initialized
INFO - 2017-03-06 11:51:53 --> Output Class Initialized
INFO - 2017-03-06 11:51:53 --> Security Class Initialized
DEBUG - 2017-03-06 11:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:51:53 --> Input Class Initialized
INFO - 2017-03-06 11:51:53 --> Language Class Initialized
INFO - 2017-03-06 11:51:53 --> Language Class Initialized
INFO - 2017-03-06 11:51:53 --> Config Class Initialized
INFO - 2017-03-06 11:51:53 --> Loader Class Initialized
INFO - 2017-03-06 11:51:53 --> Helper loaded: form_helper
INFO - 2017-03-06 11:51:53 --> Helper loaded: url_helper
INFO - 2017-03-06 11:51:53 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:51:53 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:51:53 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:51:53 --> Template Class Initialized
INFO - 2017-03-06 11:51:53 --> Model Class Initialized
INFO - 2017-03-06 11:51:53 --> Controller Class Initialized
DEBUG - 2017-03-06 11:51:53 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:51:53 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:51:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:51:53 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:51:58 --> Config Class Initialized
INFO - 2017-03-06 11:51:58 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:51:58 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:51:58 --> Utf8 Class Initialized
INFO - 2017-03-06 11:51:58 --> URI Class Initialized
INFO - 2017-03-06 11:51:58 --> Router Class Initialized
INFO - 2017-03-06 11:51:58 --> Output Class Initialized
INFO - 2017-03-06 11:51:58 --> Security Class Initialized
DEBUG - 2017-03-06 11:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:51:58 --> Input Class Initialized
INFO - 2017-03-06 11:51:58 --> Language Class Initialized
INFO - 2017-03-06 11:51:58 --> Language Class Initialized
INFO - 2017-03-06 11:51:58 --> Config Class Initialized
INFO - 2017-03-06 11:51:58 --> Loader Class Initialized
INFO - 2017-03-06 11:51:58 --> Helper loaded: form_helper
INFO - 2017-03-06 11:51:58 --> Helper loaded: url_helper
INFO - 2017-03-06 11:51:58 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:51:58 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:51:58 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:51:58 --> Template Class Initialized
INFO - 2017-03-06 11:51:58 --> Model Class Initialized
INFO - 2017-03-06 11:51:58 --> Controller Class Initialized
DEBUG - 2017-03-06 11:51:58 --> Subscriber MX_Controller Initialized
INFO - 2017-03-06 11:51:58 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:51:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:51:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:51:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:51:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/subscriber_list.php
DEBUG - 2017-03-06 11:51:58 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:51:58 --> Final output sent to browser
DEBUG - 2017-03-06 11:51:58 --> Total execution time: 0.0151
INFO - 2017-03-06 11:51:58 --> Config Class Initialized
INFO - 2017-03-06 11:51:58 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:51:58 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:51:58 --> Utf8 Class Initialized
INFO - 2017-03-06 11:51:58 --> URI Class Initialized
INFO - 2017-03-06 11:51:58 --> Router Class Initialized
INFO - 2017-03-06 11:51:58 --> Output Class Initialized
INFO - 2017-03-06 11:51:58 --> Security Class Initialized
DEBUG - 2017-03-06 11:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:51:58 --> Input Class Initialized
INFO - 2017-03-06 11:51:58 --> Language Class Initialized
INFO - 2017-03-06 11:51:58 --> Language Class Initialized
INFO - 2017-03-06 11:51:58 --> Config Class Initialized
INFO - 2017-03-06 11:51:58 --> Loader Class Initialized
INFO - 2017-03-06 11:51:58 --> Helper loaded: form_helper
INFO - 2017-03-06 11:51:58 --> Helper loaded: url_helper
INFO - 2017-03-06 11:51:58 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:51:58 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:51:58 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:51:58 --> Template Class Initialized
INFO - 2017-03-06 11:51:58 --> Model Class Initialized
INFO - 2017-03-06 11:51:58 --> Controller Class Initialized
DEBUG - 2017-03-06 11:51:58 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:51:58 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:51:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:51:58 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:52:01 --> Config Class Initialized
INFO - 2017-03-06 11:52:01 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:52:01 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:52:01 --> Utf8 Class Initialized
INFO - 2017-03-06 11:52:01 --> URI Class Initialized
INFO - 2017-03-06 11:52:01 --> Router Class Initialized
INFO - 2017-03-06 11:52:01 --> Output Class Initialized
INFO - 2017-03-06 11:52:01 --> Security Class Initialized
DEBUG - 2017-03-06 11:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:52:01 --> Input Class Initialized
INFO - 2017-03-06 11:52:01 --> Language Class Initialized
INFO - 2017-03-06 11:52:01 --> Language Class Initialized
INFO - 2017-03-06 11:52:01 --> Config Class Initialized
INFO - 2017-03-06 11:52:01 --> Loader Class Initialized
INFO - 2017-03-06 11:52:01 --> Helper loaded: form_helper
INFO - 2017-03-06 11:52:01 --> Helper loaded: url_helper
INFO - 2017-03-06 11:52:01 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:52:01 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:52:01 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:52:01 --> Template Class Initialized
INFO - 2017-03-06 11:52:01 --> Model Class Initialized
INFO - 2017-03-06 11:52:01 --> Controller Class Initialized
DEBUG - 2017-03-06 11:52:01 --> Subscriber MX_Controller Initialized
INFO - 2017-03-06 11:52:01 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:52:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:52:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:52:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:52:01 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/add_subscriber.php
DEBUG - 2017-03-06 11:52:01 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:52:01 --> Final output sent to browser
DEBUG - 2017-03-06 11:52:01 --> Total execution time: 0.1111
INFO - 2017-03-06 11:52:02 --> Config Class Initialized
INFO - 2017-03-06 11:52:02 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:52:02 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:52:02 --> Utf8 Class Initialized
INFO - 2017-03-06 11:52:02 --> URI Class Initialized
INFO - 2017-03-06 11:52:02 --> Router Class Initialized
INFO - 2017-03-06 11:52:02 --> Output Class Initialized
INFO - 2017-03-06 11:52:02 --> Security Class Initialized
DEBUG - 2017-03-06 11:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:52:02 --> Input Class Initialized
INFO - 2017-03-06 11:52:02 --> Language Class Initialized
INFO - 2017-03-06 11:52:02 --> Language Class Initialized
INFO - 2017-03-06 11:52:02 --> Config Class Initialized
INFO - 2017-03-06 11:52:02 --> Loader Class Initialized
INFO - 2017-03-06 11:52:02 --> Helper loaded: form_helper
INFO - 2017-03-06 11:52:02 --> Helper loaded: url_helper
INFO - 2017-03-06 11:52:02 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:52:02 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:52:02 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:52:02 --> Template Class Initialized
INFO - 2017-03-06 11:52:02 --> Model Class Initialized
INFO - 2017-03-06 11:52:02 --> Controller Class Initialized
DEBUG - 2017-03-06 11:52:02 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:52:02 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:52:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:52:02 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 11:52:04 --> Config Class Initialized
INFO - 2017-03-06 11:52:04 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:52:04 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:52:04 --> Utf8 Class Initialized
INFO - 2017-03-06 11:52:04 --> URI Class Initialized
INFO - 2017-03-06 11:52:04 --> Router Class Initialized
INFO - 2017-03-06 11:52:04 --> Output Class Initialized
INFO - 2017-03-06 11:52:04 --> Security Class Initialized
DEBUG - 2017-03-06 11:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:52:04 --> Input Class Initialized
INFO - 2017-03-06 11:52:04 --> Language Class Initialized
INFO - 2017-03-06 11:52:04 --> Language Class Initialized
INFO - 2017-03-06 11:52:04 --> Config Class Initialized
INFO - 2017-03-06 11:52:04 --> Loader Class Initialized
INFO - 2017-03-06 11:52:04 --> Helper loaded: form_helper
INFO - 2017-03-06 11:52:04 --> Helper loaded: url_helper
INFO - 2017-03-06 11:52:04 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:52:04 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:52:04 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:52:04 --> Template Class Initialized
INFO - 2017-03-06 11:52:04 --> Model Class Initialized
INFO - 2017-03-06 11:52:04 --> Controller Class Initialized
DEBUG - 2017-03-06 11:52:04 --> Dashboard MX_Controller Initialized
INFO - 2017-03-06 11:52:04 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:52:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 11:52:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 11:52:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 11:52:04 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/dashboard.php
DEBUG - 2017-03-06 11:52:04 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 11:52:04 --> Final output sent to browser
DEBUG - 2017-03-06 11:52:04 --> Total execution time: 0.0172
INFO - 2017-03-06 11:52:05 --> Config Class Initialized
INFO - 2017-03-06 11:52:05 --> Hooks Class Initialized
DEBUG - 2017-03-06 11:52:05 --> UTF-8 Support Enabled
INFO - 2017-03-06 11:52:05 --> Utf8 Class Initialized
INFO - 2017-03-06 11:52:05 --> URI Class Initialized
INFO - 2017-03-06 11:52:05 --> Router Class Initialized
INFO - 2017-03-06 11:52:05 --> Output Class Initialized
INFO - 2017-03-06 11:52:05 --> Security Class Initialized
DEBUG - 2017-03-06 11:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 11:52:05 --> Input Class Initialized
INFO - 2017-03-06 11:52:05 --> Language Class Initialized
INFO - 2017-03-06 11:52:05 --> Language Class Initialized
INFO - 2017-03-06 11:52:05 --> Config Class Initialized
INFO - 2017-03-06 11:52:05 --> Loader Class Initialized
INFO - 2017-03-06 11:52:05 --> Helper loaded: form_helper
INFO - 2017-03-06 11:52:05 --> Helper loaded: url_helper
INFO - 2017-03-06 11:52:05 --> Helper loaded: utility_helper
INFO - 2017-03-06 11:52:05 --> Database Driver Class Initialized
DEBUG - 2017-03-06 11:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 11:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 11:52:05 --> User Agent Class Initialized
DEBUG - 2017-03-06 11:52:05 --> Template Class Initialized
INFO - 2017-03-06 11:52:05 --> Model Class Initialized
INFO - 2017-03-06 11:52:05 --> Controller Class Initialized
DEBUG - 2017-03-06 11:52:05 --> Pages MX_Controller Initialized
INFO - 2017-03-06 11:52:05 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 11:52:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 11:52:05 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 12:24:57 --> Config Class Initialized
INFO - 2017-03-06 12:24:57 --> Hooks Class Initialized
DEBUG - 2017-03-06 12:24:57 --> UTF-8 Support Enabled
INFO - 2017-03-06 12:24:57 --> Utf8 Class Initialized
INFO - 2017-03-06 12:24:57 --> URI Class Initialized
INFO - 2017-03-06 12:24:57 --> Router Class Initialized
INFO - 2017-03-06 12:24:57 --> Output Class Initialized
INFO - 2017-03-06 12:24:57 --> Security Class Initialized
DEBUG - 2017-03-06 12:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 12:24:57 --> Input Class Initialized
INFO - 2017-03-06 12:24:57 --> Language Class Initialized
INFO - 2017-03-06 12:24:57 --> Language Class Initialized
INFO - 2017-03-06 12:24:57 --> Config Class Initialized
INFO - 2017-03-06 12:24:57 --> Loader Class Initialized
INFO - 2017-03-06 12:24:57 --> Helper loaded: form_helper
INFO - 2017-03-06 12:24:57 --> Helper loaded: url_helper
INFO - 2017-03-06 12:24:57 --> Helper loaded: utility_helper
INFO - 2017-03-06 12:24:57 --> Database Driver Class Initialized
DEBUG - 2017-03-06 12:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 12:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 12:24:57 --> User Agent Class Initialized
DEBUG - 2017-03-06 12:24:57 --> Template Class Initialized
INFO - 2017-03-06 12:24:57 --> Model Class Initialized
INFO - 2017-03-06 12:24:57 --> Controller Class Initialized
DEBUG - 2017-03-06 12:24:57 --> Subscriber MX_Controller Initialized
INFO - 2017-03-06 12:24:57 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 12:24:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/header.php
DEBUG - 2017-03-06 12:24:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/hosting_sidebar.php
DEBUG - 2017-03-06 12:24:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/partials/footer.php
DEBUG - 2017-03-06 12:24:57 --> File loaded: /home/rebelute/public_html/silohost/application/modules/backend/views/subscriber_list.php
DEBUG - 2017-03-06 12:24:57 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/backend.php
INFO - 2017-03-06 12:24:57 --> Final output sent to browser
DEBUG - 2017-03-06 12:24:57 --> Total execution time: 0.2754
INFO - 2017-03-06 12:24:58 --> Config Class Initialized
INFO - 2017-03-06 12:24:58 --> Hooks Class Initialized
DEBUG - 2017-03-06 12:24:58 --> UTF-8 Support Enabled
INFO - 2017-03-06 12:24:58 --> Utf8 Class Initialized
INFO - 2017-03-06 12:24:58 --> URI Class Initialized
INFO - 2017-03-06 12:24:58 --> Router Class Initialized
INFO - 2017-03-06 12:24:58 --> Output Class Initialized
INFO - 2017-03-06 12:24:58 --> Security Class Initialized
DEBUG - 2017-03-06 12:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 12:24:58 --> Input Class Initialized
INFO - 2017-03-06 12:24:58 --> Language Class Initialized
INFO - 2017-03-06 12:24:58 --> Language Class Initialized
INFO - 2017-03-06 12:24:58 --> Config Class Initialized
INFO - 2017-03-06 12:24:58 --> Loader Class Initialized
INFO - 2017-03-06 12:24:58 --> Helper loaded: form_helper
INFO - 2017-03-06 12:24:58 --> Helper loaded: url_helper
INFO - 2017-03-06 12:24:58 --> Helper loaded: utility_helper
INFO - 2017-03-06 12:24:59 --> Database Driver Class Initialized
DEBUG - 2017-03-06 12:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 12:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 12:24:59 --> User Agent Class Initialized
DEBUG - 2017-03-06 12:24:59 --> Template Class Initialized
INFO - 2017-03-06 12:24:59 --> Model Class Initialized
INFO - 2017-03-06 12:24:59 --> Controller Class Initialized
DEBUG - 2017-03-06 12:24:59 --> Pages MX_Controller Initialized
INFO - 2017-03-06 12:24:59 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 12:24:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 12:24:59 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 12:58:36 --> Config Class Initialized
INFO - 2017-03-06 12:58:36 --> Hooks Class Initialized
DEBUG - 2017-03-06 12:58:36 --> UTF-8 Support Enabled
INFO - 2017-03-06 12:58:36 --> Utf8 Class Initialized
INFO - 2017-03-06 12:58:36 --> URI Class Initialized
INFO - 2017-03-06 12:58:36 --> Router Class Initialized
INFO - 2017-03-06 12:58:36 --> Output Class Initialized
INFO - 2017-03-06 12:58:36 --> Security Class Initialized
DEBUG - 2017-03-06 12:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 12:58:36 --> Input Class Initialized
INFO - 2017-03-06 12:58:36 --> Language Class Initialized
INFO - 2017-03-06 12:58:36 --> Language Class Initialized
INFO - 2017-03-06 12:58:36 --> Config Class Initialized
INFO - 2017-03-06 12:58:36 --> Loader Class Initialized
INFO - 2017-03-06 12:58:36 --> Helper loaded: form_helper
INFO - 2017-03-06 12:58:36 --> Helper loaded: url_helper
INFO - 2017-03-06 12:58:36 --> Helper loaded: utility_helper
INFO - 2017-03-06 12:58:36 --> Database Driver Class Initialized
DEBUG - 2017-03-06 12:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 12:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 12:58:36 --> User Agent Class Initialized
DEBUG - 2017-03-06 12:58:36 --> Template Class Initialized
INFO - 2017-03-06 12:58:36 --> Model Class Initialized
INFO - 2017-03-06 12:58:36 --> Controller Class Initialized
DEBUG - 2017-03-06 12:58:36 --> Pages MX_Controller Initialized
INFO - 2017-03-06 12:58:36 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 12:58:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 12:58:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-06 12:58:37 --> Config Class Initialized
INFO - 2017-03-06 12:58:37 --> Hooks Class Initialized
DEBUG - 2017-03-06 12:58:37 --> UTF-8 Support Enabled
INFO - 2017-03-06 12:58:37 --> Utf8 Class Initialized
INFO - 2017-03-06 12:58:37 --> URI Class Initialized
INFO - 2017-03-06 12:58:37 --> Router Class Initialized
INFO - 2017-03-06 12:58:37 --> Output Class Initialized
INFO - 2017-03-06 12:58:37 --> Security Class Initialized
DEBUG - 2017-03-06 12:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-06 12:58:37 --> Input Class Initialized
INFO - 2017-03-06 12:58:37 --> Language Class Initialized
INFO - 2017-03-06 12:58:37 --> Language Class Initialized
INFO - 2017-03-06 12:58:37 --> Config Class Initialized
INFO - 2017-03-06 12:58:37 --> Loader Class Initialized
INFO - 2017-03-06 12:58:37 --> Helper loaded: form_helper
INFO - 2017-03-06 12:58:37 --> Helper loaded: url_helper
INFO - 2017-03-06 12:58:37 --> Helper loaded: utility_helper
INFO - 2017-03-06 12:58:37 --> Database Driver Class Initialized
DEBUG - 2017-03-06 12:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-06 12:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-06 12:58:37 --> User Agent Class Initialized
DEBUG - 2017-03-06 12:58:37 --> Template Class Initialized
INFO - 2017-03-06 12:58:37 --> Model Class Initialized
INFO - 2017-03-06 12:58:37 --> Controller Class Initialized
DEBUG - 2017-03-06 12:58:37 --> Pages MX_Controller Initialized
INFO - 2017-03-06 12:58:37 --> Helper loaded: cookie_helper
DEBUG - 2017-03-06 12:58:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-06 12:58:37 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
