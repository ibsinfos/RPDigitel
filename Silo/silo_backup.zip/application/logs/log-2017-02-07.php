<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-07 14:16:59 --> Config Class Initialized
INFO - 2017-02-07 14:16:59 --> Hooks Class Initialized
DEBUG - 2017-02-07 14:17:00 --> UTF-8 Support Enabled
INFO - 2017-02-07 14:17:00 --> Utf8 Class Initialized
INFO - 2017-02-07 14:17:00 --> URI Class Initialized
DEBUG - 2017-02-07 14:17:00 --> No URI present. Default controller set.
INFO - 2017-02-07 14:17:00 --> Router Class Initialized
INFO - 2017-02-07 14:17:00 --> Output Class Initialized
INFO - 2017-02-07 14:17:00 --> Security Class Initialized
DEBUG - 2017-02-07 14:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 14:17:00 --> Input Class Initialized
INFO - 2017-02-07 14:17:00 --> Language Class Initialized
INFO - 2017-02-07 14:17:00 --> Language Class Initialized
INFO - 2017-02-07 14:17:00 --> Config Class Initialized
INFO - 2017-02-07 14:17:00 --> Loader Class Initialized
INFO - 2017-02-07 14:17:00 --> Helper loaded: form_helper
INFO - 2017-02-07 14:17:00 --> Helper loaded: url_helper
INFO - 2017-02-07 14:17:00 --> Helper loaded: utility_helper
INFO - 2017-02-07 14:17:00 --> Database Driver Class Initialized
INFO - 2017-02-07 14:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 14:17:01 --> User Agent Class Initialized
DEBUG - 2017-02-07 14:17:01 --> Template Class Initialized
INFO - 2017-02-07 14:17:01 --> Controller Class Initialized
INFO - 2017-02-07 14:17:01 --> Form Validation Class Initialized
DEBUG - 2017-02-07 14:17:01 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-07 14:17:01 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-07 14:17:01 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-07 14:17:01 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-07 14:17:01 --> Final output sent to browser
DEBUG - 2017-02-07 14:17:01 --> Total execution time: 1.5326
INFO - 2017-02-07 14:17:02 --> Config Class Initialized
INFO - 2017-02-07 14:17:02 --> Hooks Class Initialized
DEBUG - 2017-02-07 14:17:02 --> UTF-8 Support Enabled
INFO - 2017-02-07 14:17:02 --> Utf8 Class Initialized
INFO - 2017-02-07 14:17:02 --> URI Class Initialized
INFO - 2017-02-07 14:17:02 --> Router Class Initialized
INFO - 2017-02-07 14:17:02 --> Output Class Initialized
INFO - 2017-02-07 14:17:02 --> Security Class Initialized
DEBUG - 2017-02-07 14:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 14:17:02 --> Input Class Initialized
INFO - 2017-02-07 14:17:02 --> Language Class Initialized
ERROR - 2017-02-07 14:17:02 --> 404 Page Not Found: /index
INFO - 2017-02-07 14:17:08 --> Config Class Initialized
INFO - 2017-02-07 14:17:08 --> Hooks Class Initialized
DEBUG - 2017-02-07 14:17:08 --> UTF-8 Support Enabled
INFO - 2017-02-07 14:17:08 --> Utf8 Class Initialized
INFO - 2017-02-07 14:17:08 --> URI Class Initialized
INFO - 2017-02-07 14:17:08 --> Router Class Initialized
INFO - 2017-02-07 14:17:08 --> Output Class Initialized
INFO - 2017-02-07 14:17:08 --> Security Class Initialized
DEBUG - 2017-02-07 14:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 14:17:08 --> Input Class Initialized
INFO - 2017-02-07 14:17:08 --> Language Class Initialized
ERROR - 2017-02-07 14:17:08 --> 404 Page Not Found: /index
INFO - 2017-02-07 14:19:07 --> Config Class Initialized
INFO - 2017-02-07 14:19:07 --> Hooks Class Initialized
DEBUG - 2017-02-07 14:19:07 --> UTF-8 Support Enabled
INFO - 2017-02-07 14:19:07 --> Utf8 Class Initialized
INFO - 2017-02-07 14:19:07 --> URI Class Initialized
INFO - 2017-02-07 14:19:07 --> Router Class Initialized
INFO - 2017-02-07 14:19:07 --> Output Class Initialized
INFO - 2017-02-07 14:19:07 --> Security Class Initialized
DEBUG - 2017-02-07 14:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 14:19:07 --> Input Class Initialized
INFO - 2017-02-07 14:19:07 --> Language Class Initialized
INFO - 2017-02-07 14:19:07 --> Language Class Initialized
INFO - 2017-02-07 14:19:07 --> Config Class Initialized
INFO - 2017-02-07 14:19:07 --> Loader Class Initialized
INFO - 2017-02-07 14:19:07 --> Helper loaded: form_helper
INFO - 2017-02-07 14:19:07 --> Helper loaded: url_helper
INFO - 2017-02-07 14:19:07 --> Helper loaded: utility_helper
INFO - 2017-02-07 14:19:07 --> Database Driver Class Initialized
INFO - 2017-02-07 14:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 14:19:07 --> User Agent Class Initialized
DEBUG - 2017-02-07 14:19:07 --> Template Class Initialized
INFO - 2017-02-07 14:19:07 --> Controller Class Initialized
INFO - 2017-02-07 14:19:07 --> Form Validation Class Initialized
DEBUG - 2017-02-07 14:19:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-07 14:19:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-07 14:19:07 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-07 14:19:07 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-07 14:19:07 --> Final output sent to browser
DEBUG - 2017-02-07 14:19:07 --> Total execution time: 0.4484
INFO - 2017-02-07 14:19:07 --> Config Class Initialized
INFO - 2017-02-07 14:19:07 --> Hooks Class Initialized
DEBUG - 2017-02-07 14:19:07 --> UTF-8 Support Enabled
INFO - 2017-02-07 14:19:07 --> Utf8 Class Initialized
INFO - 2017-02-07 14:19:07 --> URI Class Initialized
INFO - 2017-02-07 14:19:07 --> Router Class Initialized
INFO - 2017-02-07 14:19:07 --> Output Class Initialized
INFO - 2017-02-07 14:19:07 --> Security Class Initialized
DEBUG - 2017-02-07 14:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 14:19:07 --> Input Class Initialized
INFO - 2017-02-07 14:19:07 --> Language Class Initialized
ERROR - 2017-02-07 14:19:07 --> 404 Page Not Found: /index
INFO - 2017-02-07 14:19:07 --> Config Class Initialized
INFO - 2017-02-07 14:19:07 --> Hooks Class Initialized
DEBUG - 2017-02-07 14:19:07 --> UTF-8 Support Enabled
INFO - 2017-02-07 14:19:07 --> Utf8 Class Initialized
INFO - 2017-02-07 14:19:07 --> URI Class Initialized
INFO - 2017-02-07 14:19:07 --> Router Class Initialized
INFO - 2017-02-07 14:19:07 --> Output Class Initialized
INFO - 2017-02-07 14:19:07 --> Security Class Initialized
DEBUG - 2017-02-07 14:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 14:19:07 --> Input Class Initialized
INFO - 2017-02-07 14:19:07 --> Language Class Initialized
ERROR - 2017-02-07 14:19:07 --> 404 Page Not Found: /index
INFO - 2017-02-07 15:33:59 --> Config Class Initialized
INFO - 2017-02-07 15:33:59 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:33:59 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:33:59 --> Utf8 Class Initialized
INFO - 2017-02-07 15:33:59 --> URI Class Initialized
DEBUG - 2017-02-07 15:33:59 --> No URI present. Default controller set.
INFO - 2017-02-07 15:33:59 --> Router Class Initialized
INFO - 2017-02-07 15:33:59 --> Output Class Initialized
INFO - 2017-02-07 15:33:59 --> Security Class Initialized
DEBUG - 2017-02-07 15:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:33:59 --> Input Class Initialized
INFO - 2017-02-07 15:33:59 --> Language Class Initialized
INFO - 2017-02-07 15:33:59 --> Language Class Initialized
INFO - 2017-02-07 15:33:59 --> Config Class Initialized
INFO - 2017-02-07 15:33:59 --> Loader Class Initialized
INFO - 2017-02-07 15:33:59 --> Helper loaded: form_helper
INFO - 2017-02-07 15:34:00 --> Helper loaded: url_helper
INFO - 2017-02-07 15:34:00 --> Helper loaded: utility_helper
INFO - 2017-02-07 15:34:00 --> Database Driver Class Initialized
INFO - 2017-02-07 15:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 15:34:01 --> User Agent Class Initialized
DEBUG - 2017-02-07 15:34:01 --> Template Class Initialized
INFO - 2017-02-07 15:34:01 --> Controller Class Initialized
INFO - 2017-02-07 15:34:02 --> Form Validation Class Initialized
DEBUG - 2017-02-07 15:34:02 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-07 15:34:02 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-07 15:34:02 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/homepage.php
DEBUG - 2017-02-07 15:34:02 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-07 15:34:02 --> Final output sent to browser
DEBUG - 2017-02-07 15:34:02 --> Total execution time: 3.5378
INFO - 2017-02-07 15:34:03 --> Config Class Initialized
INFO - 2017-02-07 15:34:03 --> Hooks Class Initialized
DEBUG - 2017-02-07 15:34:04 --> UTF-8 Support Enabled
INFO - 2017-02-07 15:34:04 --> Utf8 Class Initialized
INFO - 2017-02-07 15:34:04 --> URI Class Initialized
INFO - 2017-02-07 15:34:04 --> Router Class Initialized
INFO - 2017-02-07 15:34:04 --> Output Class Initialized
INFO - 2017-02-07 15:34:04 --> Security Class Initialized
DEBUG - 2017-02-07 15:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 15:34:04 --> Input Class Initialized
INFO - 2017-02-07 15:34:04 --> Language Class Initialized
ERROR - 2017-02-07 15:34:04 --> 404 Page Not Found: /index
INFO - 2017-02-07 16:00:27 --> Config Class Initialized
INFO - 2017-02-07 16:00:27 --> Hooks Class Initialized
DEBUG - 2017-02-07 16:00:27 --> UTF-8 Support Enabled
INFO - 2017-02-07 16:00:27 --> Utf8 Class Initialized
INFO - 2017-02-07 16:00:27 --> URI Class Initialized
INFO - 2017-02-07 16:00:27 --> Router Class Initialized
INFO - 2017-02-07 16:00:27 --> Output Class Initialized
INFO - 2017-02-07 16:00:27 --> Security Class Initialized
DEBUG - 2017-02-07 16:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-07 16:00:27 --> Input Class Initialized
INFO - 2017-02-07 16:00:27 --> Language Class Initialized
INFO - 2017-02-07 16:00:27 --> Language Class Initialized
INFO - 2017-02-07 16:00:27 --> Config Class Initialized
INFO - 2017-02-07 16:00:27 --> Loader Class Initialized
INFO - 2017-02-07 16:00:27 --> Helper loaded: form_helper
INFO - 2017-02-07 16:00:27 --> Helper loaded: url_helper
INFO - 2017-02-07 16:00:27 --> Helper loaded: utility_helper
INFO - 2017-02-07 16:00:28 --> Database Driver Class Initialized
INFO - 2017-02-07 16:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-07 16:00:28 --> User Agent Class Initialized
DEBUG - 2017-02-07 16:00:28 --> Template Class Initialized
INFO - 2017-02-07 16:00:28 --> Controller Class Initialized
INFO - 2017-02-07 16:00:28 --> Form Validation Class Initialized
DEBUG - 2017-02-07 16:00:28 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/header.php
DEBUG - 2017-02-07 16:00:28 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/partials/footer.php
DEBUG - 2017-02-07 16:00:28 --> File loaded: C:\xampp\htdocs\mobile\application\modules/frontend/views/contact_us.php
DEBUG - 2017-02-07 16:00:28 --> File loaded: C:\xampp\htdocs\mobile\application\themes/default_theme/views/layouts/default.php
INFO - 2017-02-07 16:00:28 --> Final output sent to browser
DEBUG - 2017-02-07 16:00:28 --> Total execution time: 0.8226
