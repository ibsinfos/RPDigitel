<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-04 02:33:47 --> Config Class Initialized
INFO - 2017-03-04 02:33:47 --> Hooks Class Initialized
DEBUG - 2017-03-04 02:33:47 --> UTF-8 Support Enabled
INFO - 2017-03-04 02:33:47 --> Utf8 Class Initialized
INFO - 2017-03-04 02:33:47 --> URI Class Initialized
DEBUG - 2017-03-04 02:33:47 --> No URI present. Default controller set.
INFO - 2017-03-04 02:33:47 --> Router Class Initialized
INFO - 2017-03-04 02:33:47 --> Output Class Initialized
INFO - 2017-03-04 02:33:47 --> Security Class Initialized
DEBUG - 2017-03-04 02:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 02:33:47 --> Input Class Initialized
INFO - 2017-03-04 02:33:47 --> Language Class Initialized
INFO - 2017-03-04 02:33:47 --> Language Class Initialized
INFO - 2017-03-04 02:33:47 --> Config Class Initialized
INFO - 2017-03-04 02:33:47 --> Loader Class Initialized
INFO - 2017-03-04 02:33:47 --> Helper loaded: form_helper
INFO - 2017-03-04 02:33:47 --> Helper loaded: url_helper
INFO - 2017-03-04 02:33:47 --> Helper loaded: utility_helper
INFO - 2017-03-04 02:33:47 --> Database Driver Class Initialized
DEBUG - 2017-03-04 02:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-04 02:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 02:33:47 --> User Agent Class Initialized
DEBUG - 2017-03-04 02:33:47 --> Template Class Initialized
INFO - 2017-03-04 02:33:47 --> Model Class Initialized
INFO - 2017-03-04 02:33:47 --> Controller Class Initialized
DEBUG - 2017-03-04 02:33:47 --> Pages MX_Controller Initialized
INFO - 2017-03-04 02:33:47 --> Helper loaded: cookie_helper
DEBUG - 2017-03-04 02:33:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-04 02:33:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-04 02:33:47 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/homepage.php
DEBUG - 2017-03-04 02:33:47 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-04 02:33:47 --> Final output sent to browser
DEBUG - 2017-03-04 02:33:47 --> Total execution time: 0.3969
INFO - 2017-03-04 19:16:36 --> Config Class Initialized
INFO - 2017-03-04 19:16:36 --> Hooks Class Initialized
DEBUG - 2017-03-04 19:16:36 --> UTF-8 Support Enabled
INFO - 2017-03-04 19:16:36 --> Utf8 Class Initialized
INFO - 2017-03-04 19:16:36 --> URI Class Initialized
INFO - 2017-03-04 19:16:36 --> Router Class Initialized
INFO - 2017-03-04 19:16:36 --> Output Class Initialized
INFO - 2017-03-04 19:16:36 --> Security Class Initialized
DEBUG - 2017-03-04 19:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 19:16:36 --> Input Class Initialized
INFO - 2017-03-04 19:16:36 --> Language Class Initialized
INFO - 2017-03-04 19:16:36 --> Language Class Initialized
INFO - 2017-03-04 19:16:36 --> Config Class Initialized
INFO - 2017-03-04 19:16:36 --> Loader Class Initialized
INFO - 2017-03-04 19:16:36 --> Helper loaded: form_helper
INFO - 2017-03-04 19:16:36 --> Helper loaded: url_helper
INFO - 2017-03-04 19:16:36 --> Helper loaded: utility_helper
INFO - 2017-03-04 19:16:36 --> Database Driver Class Initialized
DEBUG - 2017-03-04 19:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-04 19:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 19:16:36 --> User Agent Class Initialized
DEBUG - 2017-03-04 19:16:36 --> Template Class Initialized
INFO - 2017-03-04 19:16:36 --> Model Class Initialized
INFO - 2017-03-04 19:16:36 --> Controller Class Initialized
DEBUG - 2017-03-04 19:16:36 --> Pages MX_Controller Initialized
INFO - 2017-03-04 19:16:36 --> Helper loaded: cookie_helper
DEBUG - 2017-03-04 19:16:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-04 19:16:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-04 19:16:36 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/contact_us.php
DEBUG - 2017-03-04 19:16:36 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-04 19:16:36 --> Final output sent to browser
DEBUG - 2017-03-04 19:16:36 --> Total execution time: 0.4190
INFO - 2017-03-04 20:35:18 --> Config Class Initialized
INFO - 2017-03-04 20:35:18 --> Hooks Class Initialized
DEBUG - 2017-03-04 20:35:18 --> UTF-8 Support Enabled
INFO - 2017-03-04 20:35:18 --> Utf8 Class Initialized
INFO - 2017-03-04 20:35:18 --> URI Class Initialized
INFO - 2017-03-04 20:35:18 --> Router Class Initialized
INFO - 2017-03-04 20:35:18 --> Output Class Initialized
INFO - 2017-03-04 20:35:18 --> Security Class Initialized
DEBUG - 2017-03-04 20:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 20:35:18 --> Input Class Initialized
INFO - 2017-03-04 20:35:18 --> Language Class Initialized
INFO - 2017-03-04 20:35:18 --> Language Class Initialized
INFO - 2017-03-04 20:35:18 --> Config Class Initialized
INFO - 2017-03-04 20:35:18 --> Loader Class Initialized
INFO - 2017-03-04 20:35:18 --> Helper loaded: form_helper
INFO - 2017-03-04 20:35:18 --> Helper loaded: url_helper
INFO - 2017-03-04 20:35:18 --> Helper loaded: utility_helper
INFO - 2017-03-04 20:35:18 --> Database Driver Class Initialized
DEBUG - 2017-03-04 20:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-04 20:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 20:35:18 --> User Agent Class Initialized
DEBUG - 2017-03-04 20:35:18 --> Template Class Initialized
INFO - 2017-03-04 20:35:18 --> Model Class Initialized
INFO - 2017-03-04 20:35:18 --> Controller Class Initialized
DEBUG - 2017-03-04 20:35:18 --> Pages MX_Controller Initialized
INFO - 2017-03-04 20:35:18 --> Helper loaded: cookie_helper
DEBUG - 2017-03-04 20:35:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-04 20:35:18 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-04 21:01:39 --> Config Class Initialized
INFO - 2017-03-04 21:01:39 --> Hooks Class Initialized
DEBUG - 2017-03-04 21:01:39 --> UTF-8 Support Enabled
INFO - 2017-03-04 21:01:39 --> Utf8 Class Initialized
INFO - 2017-03-04 21:01:39 --> URI Class Initialized
INFO - 2017-03-04 21:01:39 --> Router Class Initialized
INFO - 2017-03-04 21:01:39 --> Output Class Initialized
INFO - 2017-03-04 21:01:39 --> Security Class Initialized
DEBUG - 2017-03-04 21:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 21:01:39 --> Input Class Initialized
INFO - 2017-03-04 21:01:39 --> Language Class Initialized
INFO - 2017-03-04 21:01:39 --> Language Class Initialized
INFO - 2017-03-04 21:01:39 --> Config Class Initialized
INFO - 2017-03-04 21:01:39 --> Loader Class Initialized
INFO - 2017-03-04 21:01:39 --> Helper loaded: form_helper
INFO - 2017-03-04 21:01:39 --> Helper loaded: url_helper
INFO - 2017-03-04 21:01:39 --> Helper loaded: utility_helper
INFO - 2017-03-04 21:01:39 --> Database Driver Class Initialized
DEBUG - 2017-03-04 21:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-04 21:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 21:01:39 --> User Agent Class Initialized
DEBUG - 2017-03-04 21:01:39 --> Template Class Initialized
INFO - 2017-03-04 21:01:39 --> Model Class Initialized
INFO - 2017-03-04 21:01:39 --> Controller Class Initialized
DEBUG - 2017-03-04 21:01:39 --> Pages MX_Controller Initialized
INFO - 2017-03-04 21:01:39 --> Helper loaded: cookie_helper
DEBUG - 2017-03-04 21:01:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-04 21:01:39 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
INFO - 2017-03-04 22:59:17 --> Config Class Initialized
INFO - 2017-03-04 22:59:17 --> Hooks Class Initialized
DEBUG - 2017-03-04 22:59:17 --> UTF-8 Support Enabled
INFO - 2017-03-04 22:59:17 --> Utf8 Class Initialized
INFO - 2017-03-04 22:59:17 --> URI Class Initialized
INFO - 2017-03-04 22:59:17 --> Router Class Initialized
INFO - 2017-03-04 22:59:17 --> Output Class Initialized
INFO - 2017-03-04 22:59:17 --> Security Class Initialized
DEBUG - 2017-03-04 22:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-04 22:59:17 --> Input Class Initialized
INFO - 2017-03-04 22:59:17 --> Language Class Initialized
INFO - 2017-03-04 22:59:17 --> Language Class Initialized
INFO - 2017-03-04 22:59:17 --> Config Class Initialized
INFO - 2017-03-04 22:59:17 --> Loader Class Initialized
INFO - 2017-03-04 22:59:17 --> Helper loaded: form_helper
INFO - 2017-03-04 22:59:17 --> Helper loaded: url_helper
INFO - 2017-03-04 22:59:17 --> Helper loaded: utility_helper
INFO - 2017-03-04 22:59:17 --> Database Driver Class Initialized
DEBUG - 2017-03-04 22:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2017-03-04 22:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-04 22:59:17 --> User Agent Class Initialized
DEBUG - 2017-03-04 22:59:17 --> Template Class Initialized
INFO - 2017-03-04 22:59:17 --> Model Class Initialized
INFO - 2017-03-04 22:59:17 --> Controller Class Initialized
DEBUG - 2017-03-04 22:59:17 --> Pages MX_Controller Initialized
INFO - 2017-03-04 22:59:17 --> Helper loaded: cookie_helper
DEBUG - 2017-03-04 22:59:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/header.php
DEBUG - 2017-03-04 22:59:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/partials/footer.php
DEBUG - 2017-03-04 22:59:17 --> File loaded: /home/rebelute/public_html/silohost/application/modules/frontend/views/register.php
DEBUG - 2017-03-04 22:59:17 --> File loaded: /home/rebelute/public_html/silohost/application/themes/default_theme/views/layouts/frontend.php
INFO - 2017-03-04 22:59:17 --> Final output sent to browser
DEBUG - 2017-03-04 22:59:17 --> Total execution time: 0.0776
