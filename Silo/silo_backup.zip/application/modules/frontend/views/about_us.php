 
<div class="slider">
    <div class="titlebar">
        <div class="container">
            <div class="breadcrumb">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6"><h1> About Us</h1></div>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="pagenation">
                            <a href="index.html">Home</a> 

                            <i class="fa fa-angle-double-right"></i> About Us</div></div>
                </div></div></div>

        <img src="<?php echo frontend_asset_url() ?>/images/about-new-bg.png" class="img-responsive"> 

    </div>
</div>

<div class="margin-top2"></div> 

<div class="clearfix"></div>



<!--end section-->
<div class="clearfix"></div>


<section class="section_category15 section-side-image">
    <div class="container">
        <h1 class="uppercase text-center text-dark2">About Us</h1>
        <p class="uppercase text-center">Use this section to showcase important details about you.</p>
        <div class="clearfix"></div>

        <div class="margin-top5"></div>

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-8  col-sm-12 col-xs-12 text-inner clearfix align-left">
                    <div class="text-box light padding-3">

                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla nec massa enim. Aliquam viverra at est ullamcorper sollicitudin. Proin a leo sit amet nunc malesuada imperdiet pharetra ut eros. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla nec massa enim. Aliquam viverra at est ullamcorper sollicitudin. Proin a leo sit amet nunc malesuada imperdiet pharetra ut eros.</p>

                        <p>Mauris vel nunc at ipsum fermentum pellentesque quis ut massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Maecenas non adipiscing massa. Sed ut fringilla sapien. Cras sollicitudin, lectus sed tincidunt cursus, magna lectus vehicula augue, a lobortis dui orci et est. Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p> 
                        <br/>

                        <a href="#" class="btn">View More</a> </div>
                </div>
            </div>
        </div>

        <div class="img-holder col-md-6 col-md-offset-3 col-sm-offset-2 pull-right">
            <div class="background-imgholder" style="background:url(<?php echo frontend_asset_url() ?>/images/img2.jpg);"> <img class="nodisplay-image" src="<?php echo frontend_asset_url() ?>/images/img2.jpg" alt=""/> </div>
        </div>

    </div>


    <div class="margin-top2"></div>



</section>

<!--end section-->
<div class="clearfix"></div>

<section class="section_category27 center">
    <div class="tab-style" >
        <div class="container">
            <ul class="tabs1">
                <li><a href="#example-1-tab-1" target="_self"><i class="fa fa-desktop"></i><br>Lorem ipsum</a></li>
                <li><a href="#example-1-tab-2" target="_self"><i class="fa fa-database"></i><br>Lorem ipsum</a></li>
                <li><a href="#example-1-tab-3" target="_self"><i class="fa fa-pie-chart"></i><br>Lorem ipsum</a></li>
                <li><a href="#example-1-tab-4" target="_self"><i class="fa fa-comments-o"></i><br>Lorem ipsum</a></li>
                <li><a href="#example-1-tab-5" target="_self"><i class="fa fa-cloud-upload"></i><br>Lorem ipsum</a></li>
            </ul>
        </div></div>
    <div class="clearfix"></div>

    <div class="container">
        <div class="tabs-content1">
            <div id="example-1-tab-1" class="tabs-panel1">
                <div class="row">
                    <div class="col-md-6 padding-left-3">
                        <h3>Maecenas maximus elit sit</h3>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Suspendisse et justo. Praesent mattis commyolk augue Aliquam ornare hendrerit augue Cras tellus In pulvinar lectus a est Curabitur eget orci Cras laoreet.</p>
                        <ul class="iconlist">
                            <li><i class="fa fa-check-circle-o"></i> Sed massa tellus aliquam rhoncus venenatis quis. </li>
                            <li><i class="fa fa-check-circle-o"></i> Development dolor sit amet consectetur adipiscing elit Phasellus </li>
                            <li><i class="fa fa-check-circle-o"></i> Etiam dictum Nunc enim Sed massa tellus aliquam rhoncus venenatis</li>
                            <li><i class="fa fa-check-circle-o"></i> Magna eget scelerisque metus massa in neque sit consectetur </li>
                            <li><i class="fa fa-check-circle-o"></i> Vitae hendrerit condimentum dapibus ac nulla. </li>
                            <li><i class="fa fa-check-circle-o"></i> Magna, eget scelerisque metus massa in neque dapibus </li>
                        </ul>
                        <div class="bottom-margin3"></div>
                        <a class="btn btn-border btn-red-6" href="#">View More</a> </div>
                    <div class="col-md-6"><img src="<?php echo frontend_asset_url() ?>/images/img3.jpg" alt="" class="img-responsive" /></div>
                </div></div>
            <!-- end tab 1 -->

            <div id="example-1-tab-2" class="tabs-panel1">
                <div class="row">
                    <div class="col-md-6"><img src="<?php echo frontend_asset_url() ?>/images/blog-img9.jpg" alt="" class="img-responsive"/></div>
                    <div class="col-md-6 padding-left-3">
                        <h3>Praesent Mattis</h3>

                        <ul class="iconlist">
                            <li><i class="fa fa-check-circle-o"></i> Sed massa tellus aliquam rhoncus venenatis quis. </li>
                            <li><i class="fa fa-check-circle-o"></i> Development dolor sit amet consectetur adipiscing elit Phasellus </li>
                            <li><i class="fa fa-check-circle-o"></i> Etiam dictum Nunc enim Sed massa tellus aliquam rhoncus venenatis</li>
                            <li><i class="fa fa-check-circle-o"></i> Magna eget scelerisque metus massa in neque sit consectetur </li>
                            <li><i class="fa fa-check-circle-o"></i> Vitae hendrerit condimentum dapibus ac nulla. </li>
                            <li><i class="fa fa-check-circle-o"></i> Magna, eget scelerisque metus massa in neque dapibus </li>
                        </ul>
                        <div class="bottom-margin5"></div>
                        <a class="btn btn-border gray" href="#">View More</a> <a class="btn btn-border btn-red-6" href="#">Buy Now !</a></div>
                </div></div>
            <!-- end tab 2 -->

            <div id="example-1-tab-3" class="tabs-panel1">
                <div class="row">
                    <div class="col-md-6"><img src="<?php echo frontend_asset_url() ?>/images/blog-img9.jpg" alt="" class="img-responsive"/></div>
                    <div class="col-md-6 padding-left-3">
                        <h3>Lorem ipsum dolor sit amet consectetuer ornare 
                            hendrerit Suspendisse et justo.</h3>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Suspendisse et justo. Praesent mattis commyolk augue Aliquam ornare hendrerit augue Cras tellus In pulvinar lectus a est Curabitur eget orci Cras laoreet.</p>
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Suspendisse et justo. Praesent mattis commyolk augue. Aliquam ornare hendrerit augue. Cras tellus In pulvinar lectus a est Curabitur eget orci. Cras laoreet.</p>
                        <div class="bottom-margin5"></div>
                        <a class="btn btn-border btn-red-6" href="#">View More</a> </div>
                </div></div>
            <!-- end tab 3 -->

            <div id="example-1-tab-4" class="tabs-panel1">
                <div class="col-md-12">
                    <h3 class="center">Excellent Support</h3>
                    <br/>
                    <p class="center">Development dolor sit amet, consectetur adipiscing elit. Phasellus ac fringilla nulla, sit amet consequat eros. Pellentesque pharetra blandit commyolk. Phasellus massa nisl, feugiat ac bibendum et, dictum id ipsum. <span class="orange-hilight">Quisque sit amet accumsan tortor It has survived not only five centuries</span>, but also the leap into electronic typesetting, remaining essentially unchanged many web sites.</p>
                    <br/>
                    <p class="center">Nullam turpis. Cras dapibus, orci rutrum adipiscing luctus, nisl magna tempus urna, id porttitor nunc arcu et mauris. Suspendisse id justo id nisi suscipit porttitor. Pellentesque aliquet, leo id vestibulum eleifend, magna sem iaculis risus, quis volutpat turpis quam in tortor. Morbi euismod nulla aliquet felis. Sed nisi neque, fermentum sit amet, vestibulum et, pretium sit amet, tortor. Nulla egestas pede. Phasellus ac enim. Vivamus risus. Aliquam lacinia ante quis nibh. Curabitur velit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. </p>
                </div>
            </div>
            <!-- end tab 4 --> 

            <div id="example-1-tab-5" class="tabs-panel1">
                <div class="row">
                    <div class="col-md-6 padding-left-3">
                        <h3>Praesent Mattis</h3>

                        <ul class="iconlist">
                            <li><i class="fa fa-check-circle-o"></i> Sed massa tellus aliquam rhoncus venenatis quis. </li>
                            <li><i class="fa fa-check-circle-o"></i> Development dolor sit amet consectetur adipiscing elit Phasellus </li>
                            <li><i class="fa fa-check-circle-o"></i> Etiam dictum Nunc enim Sed massa tellus aliquam rhoncus venenatis</li>
                            <li><i class="fa fa-check-circle-o"></i> Magna eget scelerisque metus massa in neque sit consectetur </li>
                            <li><i class="fa fa-check-circle-o"></i> Vitae hendrerit condimentum dapibus ac nulla. </li>
                            <li><i class="fa fa-check-circle-o"></i> Magna, eget scelerisque metus massa in neque dapibus </li>
                        </ul>
                        <div class="bottom-margin5"></div>
                        <a class="btn btn-border gray" href="#">View More</a> <a class="btn btn-border btn-red-6" href="#">Buy Now !</a></div>
                    <div class="col-md-6"><img src="<?php echo frontend_asset_url() ?>/images/blog-img8.jpg" alt="" class="img-responsive" /></div>
                </div></div>
            <!-- end tab 2 -->

        </div>
        <!-- end all tabs --> 
    </div>
</section>

<!--end section-->